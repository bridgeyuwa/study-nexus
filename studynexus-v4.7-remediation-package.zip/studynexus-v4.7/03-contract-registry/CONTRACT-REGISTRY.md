# StudyNexus V4.6 → V4.7 — Contract Registry

**Document:** 03 — Contract Registry (V4.7 §76 item 5, §79 record format)
**Remediation Agent:** Super Z (Remediation Executor)
**Date:** 2026-08-26

---

## Registry Status Summary

| Status | Count |
|--------|-------|
| REGISTERED (existing in V4.6 — verified) | 8 |
| NEW (added by V4.7 remediation — contract language ready) | 32 |
| PROPOSED (skeleton only — requires user approval for values) | 1 |
| **Total** | **41** |

V4.7 §3 (Authority Model): "Contract authority overrides document tier, without exception. Tier-1 prose that happens to contain stale executable information does not override the current executable contract. Narrative documents should reference contracts rather than independently duplicate executable facts. Unauthorized executable facts discovered outside registered contracts are violations to remediate, not new contracts. Never autonomously promote discovered material into the contract registry."

V4.7 §79: "Every contract must contain: CONTRACT-ID, concern, authority, version, status, source decision, executable truth, affected files, dependencies, validation mechanism, regression guard. Do not create duplicate contracts for the same concern."

---

## Existing Registered Contracts (verified in V4.6)

### CON-001 — INV-EI1 External Identifier Unique Composite Index

```text
CONTRACT-ID: INV-EI1
concern: External identifier uniqueness for idempotent import upsert.
authority: V4.6 MANIFEST §4.10; canonical/05-implementation.md §4.10.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: ADR-21 (BD-5 External identifiers)
executable truth:
  Table `external_identifiers` has a partial UNIQUE INDEX on `(authority_id, identifier_type, identifier) WHERE status = 'active'`.
  Import upsert uses `ON CONFLICT DO UPDATE` keyed on this index.
  Retired identifiers (status = 'retired') do not participate in uniqueness.
affected files: canonical/05-implementation.md (§4.10), canonical/06-data-acquisition.md (§11.1)
dependencies: CON-022 (UPSERT-001 contract)
validation mechanism: Migration creates the partial UNIQUE INDEX; CI migration test verifies constraint exists in pg_constraint.
regression guard: CI migration test on fresh DB: `\d external_identifiers` shows the partial UNIQUE INDEX.
```

### CON-002 — INV-PI1 ProgrammeInstance Identity

```text
CONTRACT-ID: INV-PI1
concern: ProgrammeInstance identity dimensions.
authority: V4.6 MANIFEST §4.10; canonical/03-domain.md §10.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.6 ARBITRATION-FINAL
executable truth:
  ProgrammeInstance identity = (programme, campus, delivery_mode, academic_year).
  Fee category is NOT an identity dimension.
  Indigene/non-indigene tuition tiers are NOT separate ProgrammeInstances.
affected files: canonical/03-domain.md §10, canonical/05-implementation.md §4.3, GLOSSARY.md
dependencies: CON-007 (TYPESENSE-001) for nested instances[] design
validation mechanism: DB UNIQUE INDEX on (programme_id, campus_id, delivery_mode, academic_year).
regression guard: CI test: attempting to insert duplicate ProgrammeInstance identity → 422.
```

### CON-003 — ProgrammeInstance Owns Admission

```text
CONTRACT-ID: CON-003
concern: AdmissionPolicy ownership.
authority: V4.6; canonical/03-domain.md §3 §10; canonical/05-implementation.md §4.3.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.5 decision; V4.6 ARBITRATION-FINAL retained.
executable truth:
  AdmissionPolicy belongs to ProgrammeInstance, not Programme.
  Cut-off marks are per-instance (Online vs OnCampus can have different requirements).
  The `admission_requirements` column is removed from the `programmes` table.
affected files: canonical/03-domain.md §3 §10, canonical/05-implementation.md §4.3, README.md, V4.2-REMEDIATION-REPORT.md
dependencies: CON-007 (TYPESENSE-001) for nested instances[].admission fields
validation mechanism: Schema audit; `programmes` table has no `admission_requirements` column; `admission_policies` table has `programme_instance_id` FK.
regression guard: CI schema assertion.
```

### CON-004 — Publication Predicate

```text
CONTRACT-ID: CON-004
concern: Programme visibility in public search.
authority: V4.6; canonical/04-architecture.md.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.5 decision.
executable truth:
  A Programme is visible in public search iff `programmes.is_published = TRUE AND EXISTS ProgrammeInstance.is_published = TRUE`.
  One card per Programme, with aggregated instances.
affected files: canonical/04-architecture.md, canonical/05-implementation.md §8, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md
dependencies: CON-007 (TYPESENSE-001) for is_published field in programme search document
validation mechanism: Search query filter test.
regression guard: Scenario test S-7 (Programme with no published instances → not in search).
```

### CON-005 — URL Contract (slug vs UUID)

```text
CONTRACT-ID: CON-005
concern: Public URL vs internal routing identifier.
authority: V4.6; canonical/04-architecture.md; canonical/05-implementation.md.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.5 decision.
executable truth:
  Slugs for all public-facing URLs (SEO).
  `public_id` UUID for internal routing/API/JSON payloads only — never in public-facing URLs.
affected files: canonical/04-architecture.md, canonical/05-implementation.md, product-experience/FIRST-VERTICAL-SLICE-UX.md
dependencies: CON-014 (SEO-002) for indexable URL rules
validation mechanism: Route audit; no public route contains UUID pattern.
regression guard: CI route audit.
```

### CON-006 — Pending Revisions Table

```text
CONTRACT-ID: CON-006
concern: Pending revisions storage.
authority: V4.6; canonical/05-implementation.md.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.2 decision; V4.6 retained.
executable truth:
  Dedicated `pending_revisions` table (not Activitylog).
  Organization Portal saves edits as PendingRevisions → Admin approves via Filament → data written to canonical tables → activitylog records audit trail.
affected files: canonical/05-implementation.md §4
dependencies: CON-021 (REV-001) for polymorphic validation + lifecycle
validation mechanism: Schema audit; activitylog table separate from pending_revisions.
regression guard: CI schema assertion.
```

### CON-007 — Auth Stack (Fortify + Livewire + Flux Pro, NOT Breeze)

```text
CONTRACT-ID: CON-007
concern: Authentication stack.
authority: V4.6; canonical/04-architecture.md §2; canonical/05-implementation.md §2.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: ADR (Breeze rejected; Fortify + Livewire + Flux Pro mandated).
executable truth:
  Laravel Fortify + Livewire + Flux Pro.
  Laravel Breeze is NOT used.
  Fortify backend; Livewire + Flux Pro UI.
affected files: canonical/04-architecture.md §2, canonical/05-implementation.md §2, README.md
dependencies: CON-018 (DEP-001) for Fortify version
validation mechanism: composer.lock audit; no `laravel/breeze` package.
regression guard: CI composer audit.
```

### CON-008 — Color System (OKLCH)

```text
CONTRACT-ID: CON-008
concern: Color system.
authority: V4.6; product-experience/FIRST-VERTICAL-SLICE-UI.md.
version: 1.0 (V4.6)
status: REGISTERED — VERIFIED
source decision: V4.5 decision.
executable truth:
  OKLCH color space mandated.
  No HEX or HSL color codes.
  Use semantic Tailwind classes (bg-surface, border-border, etc.).
affected files: product-experience/FIRST-VERTICAL-SLICE-UI.md
dependencies: None
validation mechanism: CSS audit; no `#[0-9a-f]{6}` color codes in source CSS.
regression guard: CI CSS audit.
```

---

## New Contracts (added by V4.7 remediation)

### SEARCH-001 — Frozen Search/Projection Architecture

```text
CONTRACT-ID: SEARCH-001
concern: Public search engine selection and PostgreSQL role.
authority: V4.7 §12.
version: 1.0 (V4.7)
status: NEW — contract language ready; awaiting file propagation
source decision: DEC-001, DEC-039
executable truth:
  PostgreSQL is canonical.
  Typesense is a derived public-discovery projection.
  Public search: Typesense is the sole V1 public discovery/search engine. Applies to: free-text programme search; faceted search; relevance-based result discovery; "similar/related programmes" discovery. There is no PostgreSQL public-search fallback.
  Public browse/detail: deterministic relational browse routes may use PostgreSQL directly. Examples: institution → its programmes; canonical curated discovery page; canonical detail page. These are not treated as search-engine operations merely because they produce lists.
  Admin/internal search: may use PostgreSQL directly. Do not route internal search through Typesense merely for architectural symmetry.
affected files: README.md, GLOSSARY.md, 00-ORIENTATION/AUTHORITY-HIERARCHY.md, canonical/02-decisions.md, canonical/04-architecture.md, canonical/05-implementation.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, MANIFEST.md
dependencies: OUTAGE-001, TYPESENSE-001, PROJECTION-001 through PROJECTION-017
validation mechanism: Grep assertion: zero matches for `PostgreSQL FTS.*fallback|FTS fallback` in active-tier files (archive exempt). Grep assertion: zero matches for `database.*driver.*fallback` in active-tier files.
regression guard: CI grep per validation mechanism.
```

### OUTAGE-001 — Typesense Outage Contract

```text
CONTRACT-ID: OUTAGE-001
concern: Behavior when Typesense is unavailable.
authority: V4.7 §13.
version: 1.0 (V4.7)
status: NEW — contract language ready
source decision: DEC-040
executable truth:
  For primary public Typesense search: Typesense unavailable → explicit unavailable/search-failure state; do not return zero results as a disguise; do not silently switch to PostgreSQL.
  For optional search-powered components: canonical page remains available; failed optional discovery component fails closed or is omitted.
  For canonical browse/detail pages: continue using PostgreSQL.
affected files: canonical/04-architecture.md (new §Typesense Outage Contract), canonical/05-implementation.md §8, MANIFEST.md §4.30 (rewrite), product-experience/FIRST-VERTICAL-SLICE-UX.md (outage UX)
dependencies: SEARCH-001
validation mechanism: Scenario tests S-35 (Typesense unavailable on primary search), S-36 (Typesense unavailable on optional related-programme component) pass.
regression guard: Scenario tests S-35, S-36.
```

### PROJECTION-001 — Projection Event Ordering

```text
CONTRACT-ID: PROJECTION-001
concern: Immutable projection event revision ordering.
authority: V4.7 §14.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-002, DEC-041
executable truth:
  A projection-affecting canonical transaction receives an immutable `projection_event_revision` inside the same PostgreSQL transaction as: canonical mutation, projection event, affected-target persistence.
  Use a single PostgreSQL global transactional serialization point.
  Ordering: if T1 commits before T2, T2 must not receive a lower projection_event_revision.
  Sequence values do not need to be gap-free.
  Projection workers never allocate a new freshness revision for an existing event.
  Retries reuse the exact same immutable event revision.
  Do not use worker execution order as freshness order.
  Do not use a worker-time sequence.
  Do not use PostgreSQL WAL/CDC merely to solve this ordering problem.
  Do not derive the projection freshness number from an individual contributor revision.
affected files: canonical/05-implementation.md (new §8.5 Projection Event Architecture; new tables: projection_events, projection_event_targets, pending_projection_requests, projection_states), canonical/04-architecture.md §3 §6
dependencies: PROJECTION-002, PROJECTION-004
validation mechanism: DB schema audit; projection_events table has `revision` BIGINT UNIQUE column populated by a global sequence.
regression guard: Concurrency test: two concurrent projection-affecting transactions T1, T2; assert revision(T2) > revision(T1) iff T1 commits before T2.
```

### PROJECTION-002 — Projection Event Targets

```text
CONTRACT-ID: PROJECTION-002
concern: Normalized target rows for projection events.
authority: V4.7 §17.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-002, DEC-042
executable truth:
  Affected projection identities must be captured at mutation time, not rediscovered later from current relationships.
  Persist normalized target rows: projection_events, projection_event_targets.
  Do not put enormous fan-out target arrays into opaque JSON when normalized target rows are appropriate.
  A canonical mutation + projection event + affected target rows must commit atomically.
  Target inserts may be internally batched/chunked within the transaction.
  Do not impose a semantic fan-out cap.
  Do not dispatch queue jobs from inside the canonical transaction.
affected files: canonical/05-implementation.md (§8.5; new tables)
dependencies: PROJECTION-001, PROJECTION-003
validation mechanism: DB schema audit; projection_event_targets table has (projection_event_id, projection_type, projection_id) FK structure.
regression guard: Scenario test S-13 (Institution mutation affecting hundreds of Programmes) — all affected Programme IDs captured at mutation time.
```

### PROJECTION-003 — Historical Affectedness

```text
CONTRACT-ID: PROJECTION-003
concern: Historical affected-target set immutability.
authority: V4.7 §18.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-043
executable truth:
  If Institution 55 affected Programme 101 at mutation time, the event retains Programme 101 as a target even if Programme 101 moves elsewhere before asynchronous processing.
  Current relationships must not rewrite the historical affected-target set.
  Reconciliation is recovery, not historical affectedness discovery.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-002
validation mechanism: Scenario test S-14 (Programme mutation during Institution fan-out) — historical affectedness preserved.
regression guard: S-14.
```

### PROJECTION-004 — Runtime Projection Coalescing

```text
CONTRACT-ID: PROJECTION-004
concern: pending_projection_requests coalescing.
authority: V4.7 §19.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-044
executable truth:
  pending_projection_requests is an optimization. It is not correctness authority. Durable event/outbox state is correctness authority.
  Per logical projection identity: one pending/running job at a time; newer pending revision updates coalescing state; no stale candidate should be written when a newer pending revision is already known; newest state is processed; completion rechecks whether a newer revision arrived during execution; if yes, schedule the newest work.
  Laravel ShouldBeUnique may be used only in a way that does not suppress durable work signals.
  WithoutOverlapping provides execution serialization.
affected files: canonical/05-implementation.md §8.5 (new table: pending_projection_requests)
dependencies: PROJECTION-001, SERIAL-001
validation mechanism: Concurrency test S-12 (two concurrent projection mutations) — only one job runs at a time per identity; newest revision processed.
regression guard: S-12.
```

### PROJECTION-005 — Projection Snapshot

```text
CONTRACT-ID: PROJECTION-005
concern: REPEATABLE READ snapshot for projection materialization.
authority: V4.7 §20.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-045
executable truth:
  BEGIN REPEATABLE READ → read all projection dependencies → materialize immutable ProjectionInput → COMMIT.
  After ProjectionInput is materialized: no additional canonical database reads are permitted during transformation.
  Do not hold a database snapshot open during: transformation, Typesense network calls, retries, external API calls.
  Projection transformation should be deterministic from ProjectionInput.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-006
validation mechanism: Code review; transformation function has no DB read calls.
regression guard: CI static analysis: transformation function calls no Eloquent `::find()` / `::where()->get()` methods.
```

### PROJECTION-006 — Projection Builder

```text
CONTRACT-ID: PROJECTION-006
concern: Complete deterministic document rebuilds.
authority: V4.7 §21.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-046
executable truth:
  V1 projections are complete deterministic document rebuilds.
  No V1 patch language (remove nested item, increment count, patch tuition, modify one facet field).
  A contributing mutation causes a complete rebuild of the affected document.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-005
validation mechanism: Code review; projection builder function returns complete document.
regression guard: CI assertion: builder function signature returns array with all TYPESENSE-001 registered fields.
```

### PROJECTION-007 — Projection Dependency Registry (= TYPESENSE-001)

```text
CONTRACT-ID: PROJECTION-007 (= TYPESENSE-001)
concern: Field-level dependency registry for projection documents.
authority: V4.7 §22.
version: 1.0 (V4.7)
status: NEW (same as TYPESENSE-001)
source decision: DEC-007
executable truth: See TYPESENSE-001.
affected files: canonical/05-implementation.md §8.6 (new TYPESENSE-001 section)
dependencies: PROJECTION-001, PROJECTION-008
validation mechanism: CI script: union of field dependencies == declared document dependencies; non-match = build failure.
regression guard: CI script per validation mechanism.
```

### PROJECTION-008 — Projection Relevance

```text
CONTRACT-ID: PROJECTION-008
concern: Skip projection jobs for irrelevant mutations.
authority: V4.7 §23.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-047
executable truth:
  All canonical mutations use the normal projection event pathway.
  Before the expensive snapshot, projection machinery may determine whether the event's changed-field/dependency set can affect the projection.
  Authoritative mechanism: event type + changed-field/dependency set + TYPESENSE-001 dependency registry.
  If definitely irrelevant: terminate the projection job without rebuilding.
  Do not create a second unrelated dispatch pathway.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-001, TYPESENSE-001
validation mechanism: Scenario test: mutation that does not affect any projection field → no Typesense write.
regression guard: CI test.
```

### PROJECTION-009 — Projection Fingerprint

```text
CONTRACT-ID: PROJECTION-009
concern: Change detection for projection output.
authority: V4.7 §24.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-048
executable truth:
  Fingerprint = normalized logical projection output; transport-independent; excludes volatile metadata; deterministic across key ordering/serialization representation.
  Equivalent logical documents must produce identical fingerprints.
  Fingerprint is change detection, not freshness ordering.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-006
validation mechanism: Hash function test; same input → same fingerprint.
regression guard: CI test.
```

### PROJECTION-010 — Projection Apply State (projection_states table)

```text
CONTRACT-ID: PROJECTION-010
concern: Durable PostgreSQL application-side projection lifecycle state.
authority: V4.7 §25.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-002
executable truth:
  projection_states is the durable PostgreSQL application-side projection lifecycle state.
  Fields: projection_type, projection_id, last_applied_projection_revision, lifecycle_state, terminal_revision, projection_contract_version, collection_generation, last_applied_fingerprint.
  Equivalent names are acceptable only if semantics remain identical.
  projection_states is not the projection revision allocator.
affected files: canonical/05-implementation.md §8.5 (new table: projection_states)
dependencies: PROJECTION-001
validation mechanism: Schema audit.
regression guard: CI schema assertion.
```

### PROJECTION-011 — Projection Apply State Machine

```text
CONTRACT-ID: PROJECTION-011
concern: APPLYING → APPLIED transition.
authority: V4.7 §26.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-049
executable truth:
  Use explicit transition state: APPLYING → APPLIED.
  If failure occurs: current apply remains uncertain until reconciliation; do not allocate another freshness revision; retry the same immutable event/projection candidate.
  last_applied_projection_revision advances only when the corresponding apply is accepted as completed.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-010, PROJECTION-012
validation mechanism: State machine test.
regression guard: CI test.
```

### PROJECTION-012 — Apply Crash Recovery

```text
CONTRACT-ID: PROJECTION-012
concern: Worker crash after Typesense write.
authority: V4.7 §27.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-050
executable truth:
  If worker dies after Typesense accepts a revision but before PostgreSQL records APPLIED:
    1. reconciliation inspects Typesense;
    2. checks actual document revision/fingerprint;
    3. checks durable event history;
    4. if correct revision already exists, mark the application state APPLIED;
    5. if missing/older/invalid, retry the same immutable projection event;
    6. never invent a replacement freshness revision because of the crash.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-011, PROJECTION-013
validation mechanism: Scenario test S-15 (Projection worker crash after Typesense write).
regression guard: S-15.
```

### PROJECTION-013 — PostgreSQL/Typesense Discrepancy Reconciliation

```text
CONTRACT-ID: PROJECTION-013
concern: Reconcile PostgreSQL vs Typesense state.
authority: V4.7 §28.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-051
executable truth:
  PostgreSQL: canonical truth; lifecycle intent; accepted projection state; event history.
  Typesense: physical search-serving document state.
  If they disagree: do not blindly trust either side. Reconcile against: durable event history; projection lifecycle state; document revision; document fingerprint; collection generation. Then repair through the normal projection pipeline.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-012
validation mechanism: Reconciliation job test.
regression guard: Scenario test.
```

### PROJECTION-014 — Terminal/Ineligible Projections

```text
CONTRACT-ID: PROJECTION-014
concern: Publicly ineligible but canonically retained projections.
authority: V4.7 §29.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-052
executable truth:
  Publicly ineligible but canonically retained: Typesense document remains with is_searchable = false; excluded from all ordinary public search.
  Admin/internal discovery continues to use PostgreSQL.
  For actual hard deletion: emit explicit deletion event; retain durable projection tombstone/state; physically delete the Typesense document; stale older revisions must not recreate it.
affected files: canonical/05-implementation.md §8.5, canonical/04-architecture.md §6
dependencies: PROJECTION-001
validation mechanism: Scenario test S-10 (Hard-deleted projection).
regression guard: S-10.
```

### PROJECTION-015 — Collection Contract Versioning

```text
CONTRACT-ID: PROJECTION-015
concern: Typesense collection versioning model.
authority: V4.7 §30.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-020
executable truth:
  Typesense collections are tied to projection contract versions. Example: programmes_v7, programmes_v8.
  Logical projection identity remains: programme:123.
  Collection/version naming is separate physical routing metadata.
  Contract version does not redefine logical identity.
  A contract change produces a new collection generation rather than silently mutating the semantic meaning of an existing collection.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-016
validation mechanism: Collection naming audit.
regression guard: Scenario test S-17 (collection v7→v8 rebuild).
```

### PROJECTION-016 — Collection Rebuild / Cutover

```text
CONTRACT-ID: PROJECTION-016
concern: V1 rebuild transition.
authority: V4.7 §31.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-020
executable truth:
  V1 rebuild transition: current live collection → consistent canonical snapshot S → build new collection generation → retain durable projection-event stream → replay/catch up events > S → verify new collection watermark/currentness → alias switch → previous known-good collection retained.
  No new permanent dual-write mode is introduced.
  The alias is the physical routing authority.
  Old collection deletion is a separate operational action.
  At least one previous known-good collection must remain available during transition.
  Exact retention duration is operational policy.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-015
validation mechanism: Scenario test S-17, S-18 (rebuild catch-up).
regression guard: S-17, S-18.
```

### PROJECTION-017 — Typesense Nested Schema

```text
CONTRACT-ID: PROJECTION-017
concern: Typesense nested_fields schema for programme instances.
authority: V4.7 §32.
version: 1.0 (V4.7)
status: NEW (V4.6 has partial implementation per MANIFEST §71; verify and complete)
source decision: DEC-053
executable truth:
  The programme collection must explicitly define: enable_nested_fields = true; instances = object[].
  Explicitly enumerate required nested fields.
  Same-element nested filtering is mandatory where the UI requires multiple conditions to apply to the same ProgrammeInstance.
  Do not independently filter nested properties in a way that can match different array elements.
affected files: canonical/05-implementation.md §8.3.1 (verify), §8.5
dependencies: TYPESENSE-001
validation mechanism: Typesense collection schema audit.
regression guard: Scenario tests S-6 (search filter matching only one instance), Case A/B/C/D-I.
```

### TYPESENSE-001 — Programme Search Schema + Dependency Registry

```text
CONTRACT-ID: TYPESENSE-001
concern: Programme search document schema + field dependency registry.
authority: V4.7 §22, §33-§36.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-007, DEC-010, DEC-043, DEC-044
executable truth:
  Field registry (per V4.7 §22) — 10 columns per field:
    field name, canonical source, transformation, type, searchable, filterable, sortable, facet behavior, null behavior, dependency.
  Document dependency declaration: CI must mechanically verify union of field dependencies == declared document dependencies.
  A projection field without a registered dependency is a Tier-1 finding.
  An incorrectly declared dependency is a Tier-1 finding.
  
  Programme Search Schema (per V4.7 §33) — must resolve:
    - programme identity fields
    - display name
    - sort name
    - institution identity/name
    - institution state
    - institution city
    - ownership type
    - discipline/discovery fields
    - nested instances
    - instance location/mode/year
    - instance admission state
    - instance contextual cutoffs
    - admission-open semantics
    - programme-count aggregate only where explicitly used
    - publication/searchability state
  There is NO generic ambiguous `status` field. Use explicit semantic fields.
  
  Admission Open Semantics (per V4.7 §34):
    - instances[].is_admission_open is authoritative for contextual filtering.
    - A top-level aggregate is_admission_open may exist only as a separately defined projection concept.
    - If present, its meaning is: "at least one publicly searchable eligible instance is currently admission-open."
    - It must never be interpreted as the status of an arbitrary matched instance.
  
  Programme Result Status (per V4.7 §35):
    - Admission status is contextual to the matching instance set.
    - If search context narrows to a specific instance subset: result status reflects those matching instances.
    - If all matching instances share one state: display that state.
    - If multiple admission states remain: display a neutral state such as "Multiple admission states."
    - Do not apply an arbitrary precedence rule.
    - Do not resurrect a Programme-level ProgrammeStatus as though it were canonical admission truth.
  
  Cut-off Semantics (per V4.7 §36):
    - Remove top-level cut_off_latest.
    - Use contextual nested cutoff values.
    - Cutoff must be associated with: applicable ProgrammeInstance; applicable admission cycle; applicable pathway/context; published/current validity according to the canonical cutoff contract.
    - Do not invent a misleading aggregate.
    - If future UX needs a top-level cutoff aggregate, that requires an explicit new decision.
affected files: canonical/05-implementation.md (new §8.6 TYPESENSE-001 section), canonical/04-architecture.md §6, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md (remove cut_off_latest), product-experience/FIRST-VERTICAL-SLICE-UX.md (remove cut_off_latest), product-experience/FIRST-VERTICAL-SLICE-UI.md (remove cut_off_latest)
dependencies: PROJECTION-001, PROJECTION-008, PROJECTION-017
validation mechanism: (1) CI script parses TYPESENSE-001 field registry and asserts union of field dependencies == declared document dependencies; (2) grep assertion: zero matches for `cut_off_latest` in active-tier files; (3) grep assertion: zero matches for `status` as a Typesense field name (must be explicit semantic fields like `programme_lifecycle`, `instance_admission_state` etc.).
regression guard: All three validation mechanisms.
```

### SERIAL-001 — Projection Serialization

```text
CONTRACT-ID: SERIAL-001
concern: Execution serialization for projection jobs.
authority: V4.7 §58.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-008
executable truth:
  Use Laravel WithoutOverlapping with a shared logical identity: projection_type + projection_id.
  It is execution serialization, not correctness authority.
  The hard job timeout must be lower than lock expiry.
  Every external call must have its own timeout.
  A hung worker is a failed job, not an excuse for indefinite lock renewal.
affected files: canonical/05-implementation.md §8.5
dependencies: PROJECTION-001, QUEUE-001
validation mechanism: Code review; job class uses WithoutOverlapping with key.
regression guard: CI assertion: projection job class uses WithoutOverlapping.
```

### QUEUE-001 — Queue Policy

```text
CONTRACT-ID: QUEUE-001
concern: Queue infrastructure and policy.
authority: V4.7 §57.
version: 1.0 (V4.7) — SKELETON ONLY; concrete values require user approval
status: PROPOSED — BLOCKED on user approval of concrete values
source decision: DEC-009
executable truth:
  Redis is required V1 infrastructure.
  Public canonical mutation → projection uses Redis-backed Laravel queues.
  No database queue alternative remains deferred.
  At minimum: bounded retries; exponential backoff with jitter; hard timeout; exception cap; failed-job retention; alerting; manual replay.
  
  CONCRETE VALUES [TO BE APPROVED BY USER PER V4.7 §57]:
    - retries: [TBD]
    - backoff base: [TBD] seconds
    - backoff multiplier: [TBD]
    - jitter: [TBD] milliseconds
    - hard timeout: [TBD] seconds
    - exception cap: [TBD] exceptions
    - failed-job retention: [TBD] days
    - alerting threshold: [TBD]
    - alerting channel: [TBD]
  
  Do not introduce a second projection scheduling path.
affected files: canonical/05-implementation.md (new §12 QUEUE-001 section), canonical/04-architecture.md §2
dependencies: PROJECTION-001, SERIAL-001
validation mechanism: Config file audit; queue config matches QUEUE-001 values.
regression guard: CI assertion: config/queue.php matches QUEUE-001 contract values.
```

### TRUST-001 — Human Approval Trust Model

```text
CONTRACT-ID: TRUST-001
concern: Two-stage authorization for import approval.
authority: V4.7 §40.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-003
executable truth:
  Two-stage authorization:
    1. Acquisition environment authenticates artifact origin (HMAC or mTLS for transport integrity ONLY; this is NOT the approval signature).
    2. Independent human approval occurs through the trusted StudyNexus control plane (Filament v5 resource; Fortify 2FA required).
  The acquisition environment must not possess the private approval signing credential.
  Human approval must bind to the exact artifact hash.
  At minimum the signed approval binds: artifact ID; artifact hash; artifact/schema version; approval action; approver identity; approval timestamp.
  Strong human authentication is required for the approval action.
affected files: canonical/06-data-acquisition.md §13 (rewrite), canonical/05-implementation.md §5 (Filament approval resource)
dependencies: TRUST-002, INGEST-001, INGEST-002, INGEST-003
validation mechanism: Code review; acquisition worker .env audit (no signing key); Filament approval resource audit.
regression guard: Scenario tests S-23 (forged approval), S-28 (unauthorized approval).
```

### TRUST-002 — Approval Replay

```text
CONTRACT-ID: TRUST-002
concern: Replay of already-consumed approved artifacts.
authority: V4.7 §41.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-003
executable truth:
  Normal production ingestion of an already-consumed approved artifact is rejected.
  Explicit administrative replay is allowed.
  Original approval remains valid for the same immutable artifact hash.
  Replay must record: operator; timestamp; reason; artifact hash; replay execution identity.
  Do not mutate the original execution history.
affected files: canonical/06-data-acquisition.md §13, canonical/05-implementation.md §4 (canonical_imports table)
dependencies: TRUST-001, INGEST-003
validation mechanism: Scenario test S-22 (explicit artifact replay).
regression guard: S-22.
```

### INGEST-001 — Import Atomicity

```text
CONTRACT-ID: INGEST-001
concern: Artifact-level atomicity for import application.
authority: V4.7 §37.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-004
executable truth:
  Approved artifacts use artifact-level atomicity.
  Lifecycle: raw/source → normalize → validate all → classify warnings/errors → approve → atomic canonical application.
  Any blocking validation error → entire artifact rejected; zero canonical records committed.
  Warnings may coexist with successful application.
  Never turn warnings into blocking errors merely to simplify implementation.
  Never turn blocking errors into partial acceptance.
affected files: canonical/06-data-acquisition.md §7, §13
dependencies: INGEST-002, INGEST-003
validation mechanism: Scenario tests S-19 (warning only → applied), S-20 (one blocking error → entire artifact rejected).
regression guard: S-19, S-20.
```

### INGEST-002 — Import Execution Identity

```text
CONTRACT-ID: INGEST-002
concern: Three distinct import identities.
authority: V4.7 §38.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-003
executable truth:
  Maintain three distinct identities:
    - immutable artifact identity (content hash);
    - approval identity (signed by approver);
    - import execution identity (one per attempt).
  Artifact identity should be based on immutable content identity, including artifact hash.
  Retry of the same failed execution reuses the same execution ID.
  Explicit replay creates a new execution ID.
affected files: canonical/06-data-acquisition.md §7, canonical/05-implementation.md §4
dependencies: INGEST-003
validation mechanism: Schema audit; canonical_imports table has artifact_hash + execution_id columns.
regression guard: Scenario test S-21 (import retry after crash — same execution ID reused).
```

### INGEST-003 — Canonical Import State

```text
CONTRACT-ID: INGEST-003
concern: Durable canonical_imports state.
authority: V4.7 §39.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-019
executable truth:
  Use a durable `canonical_imports` state committed atomically with canonical state and its projection events/outbox.
  Do not pretend an external worker-status row is transactionally identical to the canonical commit.
  The import execution state must distinguish: RECEIVED, VALIDATING, VALIDATION_FAILED, APPROVED, REVOKED, APPLYING, FAILED, APPLIED.
  APPLIED is terminal.
  Failed execution can retry under the same execution identity if canonical application did not commit.
  Replay is a new execution.
affected files: canonical/05-implementation.md §4 (new table: canonical_imports), canonical/06-data-acquisition.md §7
dependencies: PROJECTION-001 (atomic transaction with projection events)
validation mechanism: Schema audit; state machine test.
regression guard: Scenario tests S-21, S-22.
```

### LIFE-001 — Programme Lifecycle (no CLOSED)

```text
CONTRACT-ID: LIFE-001
concern: Programme lifecycle vocabulary.
authority: V4.7 §49.
version: 1.0 (V4.7)
status: NEW — depends on DEC-035 user approval for V4.6 ProgrammeStatus reconciliation
source decision: DEC-012, DEC-035
executable truth:
  Canonical lifecycle does not include ambiguous CLOSED.
  Use the existing relevant lifecycle concepts, including: ACTIVE, SUSPENDED, DISCONTINUED plus publication state.
  Programme itself may be discontinued while historical content remains accessible.
  Instance-specific offerings may also have their own status.
  Do not reintroduce CLOSED as a generic substitute.
  
  Mapping (pending DEC-035 user approval — recommended Option A):
    ProgrammeStatus::Prospective + is_published=true → ACTIVE
    ProgrammeStatus::Admitting + is_published=true → ACTIVE
    ProgrammeStatus::Suspended → SUSPENDED
    ProgrammeStatus::Discontinued → DISCONTINUED
    is_published=false → DRAFT/UNPUBLISHED
  
  InstitutionStatus (pending DEC-012 user approval — recommended Option A):
    Provisional, Operational, Suspended, Discontinued (rename from Closed)
  
  ScholarshipStatus: deferred to Phase 2 per V4.6 §4.24.
affected files: canonical/03-domain.md, canonical/05-implementation.md §4, GLOSSARY.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md
dependencies: SEO-001
validation mechanism: Grep assertion: zero matches for `InstitutionStatus::Closed` in active-tier files (post-remediation).
regression guard: CI grep assertion.
```

### SEO-001 — Terminal/Historical Public Page Matrix

```text
CONTRACT-ID: SEO-001
concern: Lifecycle × Public search × Canonical URL × HTTP × Indexability × Sitemap matrix.
authority: V4.7 §50.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-013
executable truth:
  Single explicit contract matrix:
  
  | Lifecycle         | Public search                | Canonical URL                     | HTTP               | Indexability              | Sitemap                   |
  | ACTIVE            | yes where published/eligible | yes                               | 200                | according to SEO registry | according to SEO registry |
  | SUSPENDED         | normally no                  | normally yes                      | 200                | explicit SEO policy       | explicit                  |
  | DISCONTINUED      | no                           | yes when historical value remains | 200 where retained | explicit                  | explicit                  |
  | DRAFT/UNPUBLISHED | no                           | not public                        | 404/noindex        | no                        | no                        |
  
  Do not infer missing states.
  The registry must supply the exact route/SEO behavior.
affected files: canonical/04-architecture.md (new §SEO Lifecycle Matrix), canonical/05-implementation.md (reference)
dependencies: LIFE-001, SEO-002
validation mechanism: Matrix exists as single contract section; 4 rows × 6 columns.
regression guard: CI assertion.
```

### SEO-002 — SEO Indexability Registry

```text
CONTRACT-ID: SEO-002
concern: Indexable route registry.
authority: V4.7 §51.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-014
executable truth:
  Only explicitly registered curated discovery routes are indexable.
  Indexable categories may include: canonical Programme pages; canonical Institution pages; explicitly curated discipline pages; explicitly curated institution discovery pages; other specifically registered curated discovery pages.
  Potential location/ownership/delivery pages are NOT indexable merely because filters exist.
  Non-indexable by default: free-text results; arbitrary filter combinations; arbitrary query-string combinations; arbitrary sort URLs; arbitrary pagination; empty combinations.
  The SEO registry must define: path; page type; canonical URL; indexable; sitemap eligibility; metadata policy; structured-data policy.
  Do not redesign the V4.6 SEO registry. Extract it first, then reconcile contradictions.
affected files: canonical/04-architecture.md (new §SEO Indexability Registry)
dependencies: SEO-001, SEO-003
validation mechanism: Route audit; no route is indexable unless listed in SEO-002.
regression guard: CI assertion.
```

### SEO-003 — Sitemap Eligibility

```text
CONTRACT-ID: SEO-003
concern: Sitemap inclusion criteria.
authority: V4.7 §52.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-015
executable truth:
  Eligibility: published AND public AND indexable AND SEO-contract-approved.
  Pagination is not a V1 sitemap candidate.
  Scholarships remain excluded from the V1 sitemap unless the actual public scholarship SEO surface is explicitly brought into V1 scope.
  Do not add scholarship sitemap output merely because the domain model exists.
affected files: canonical/04-architecture.md (new §Sitemap Eligibility)
dependencies: SEO-002
validation mechanism: Sitemap generator audit.
regression guard: CI sitemap generator output matches SEO-003.
```

### SEO-004 — Structured Data

```text
CONTRACT-ID: SEO-004
concern: Structured data (JSON-LD / schema.org) contract.
authority: V4.7 §53.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-016
executable truth:
  Structured data and indexability are separate concepts.
  Structured data must: accurately represent visible page content; use the page-type schema contract; never falsely claim current availability; never contain hidden/misleading content.
  For canonical indexable pages with supported schema: structured data is required where the page contract calls for it.
  For historical/discontinued pages: represent historical truth accurately and do not imply current admission/open availability when it is not true.
  A noindex state is not itself a reason to declare structured data invalid.
affected files: canonical/04-architecture.md (new §Structured Data Contract)
dependencies: None
validation mechanism: Structured-data validator per page type.
regression guard: CI validator.
```

### SEO-005 — URL Redirects

```text
CONTRACT-ID: SEO-005
concern: URL redirect contract.
authority: V4.7 §54.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-017
executable truth:
  V1 redirect contract:
    - arbitrary normalized old URL → new URL mappings;
    - HTTP 301;
    - source URL globally unique;
    - fragments excluded;
    - semantically relevant query parameters may be part of normalized identity;
    - tracking-only query parameters are not redirect keys;
    - redirect loops forbidden;
    - redirect chains forbidden;
    - one source cannot have multiple active destinations;
    - invalid destinations require explicit remediation;
    - redirects retained indefinitely unless explicitly retired;
    - creation of a new redirect that would form a chain is rejected.
  Historical redirects are not automatically rewritten.
affected files: canonical/04-architecture.md (new §URL Redirect Contract), canonical/05-implementation.md (new url_redirects table)
dependencies: None
validation mechanism: DB UNIQUE constraint on source_url; CI test: redirect chain attempt → rejected; redirect loop → rejected.
regression guard: CI tests.
```

### DEP-001 — Dependency Contract

```text
CONTRACT-ID: DEP-001
concern: Authoritative dependency registry.
authority: V4.7 §55.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-018
executable truth:
  Authoritative dependency contract contains:
    - direct runtime dependencies;
    - direct build dependencies;
    - exact verified version;
    - allowed constraint;
    - framework compatibility;
    - verification date/source;
    - criticality/materiality;
    - upgrade policy.
  Transitive dependency truth is supplied by lockfiles.
  Pure test/dev-only dependencies need not be treated as production runtime dependencies, but direct build dependencies required to produce production artifacts are included.
affected files: canonical/05-implementation.md (new §12 DEP-001 contract section)
dependencies: DEP-002
validation mechanism: Composer audit; lockfile diff; external evidence register.
regression guard: CI composer audit + lockfile diff triggers Tier-appropriate verification.
```

### DEP-002 — Dependency Verification

```text
CONTRACT-ID: DEP-002
concern: Dependency verification policy.
authority: V4.7 §56.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-018
executable truth:
  Allowed version range ≠ verified version ≠ architectural approval.
  Material lockfile changes trigger Tier-appropriate verification.
  A lockfile change does not automatically mean architecture changed.
  A resolved dependency that becomes incompatible with a frozen architectural requirement becomes a frozen-decision challenge.
  Do not silently edit version contracts merely because a newer transitive package appeared.
affected files: canonical/05-implementation.md (new §12 DEP-002 subsection)
dependencies: DEP-001
validation mechanism: External Evidence Register; frozen-decision challenge log.
regression guard: CI lockfile diff → Tier-appropriate verification triggered.
```

### RBAC-001 — Self-Approval Prevention

```text
CONTRACT-ID: RBAC-001
concern: Self-approval prevention for pending revisions.
authority: V4.7 §45.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-021
executable truth:
  Use capability + scope matrix. Roles are implementation groupings, not the authority model itself.
  Do not redesign the RBAC inventory from scratch. Extract the V4.6 capability inventory.
  A user may not approve their own revision. Submitter cannot review or approve their own revision.
  Do not invent missing capabilities without surfacing them as decisions.
affected files: canonical/05-implementation.md §5
dependencies: REV-001
validation mechanism: Code review; PendingRevision submitter_id ≠ approver_id.
regression guard: CI test: user submits PendingRevision, then attempts to approve own revision → 403.
```

### UPSERT-001 — Unique Upsert Constraint Audit

```text
CONTRACT-ID: UPSERT-001
concern: Matching PostgreSQL constraints for every ON CONFLICT target.
authority: V4.7 §47.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-022, DEC-037
executable truth:
  Every ON CONFLICT target requires a matching PostgreSQL unique/exclusion constraint.
  Do not rely solely on application-level uniqueness for ordinary relational uniqueness.
  Audit all import upserts, including:
    - external_identifiers (authority_id, identifier_type, identifier) WHERE status = 'active' [existing INV-EI1]
    - cut_off_marks (programme_instance_id, admission_cycle_id, pathway) [existing per V4.6 §4.10]
    - accreditation_records (accreditable_type, accreditable_id, authority_id) [existing per V4.6 §4.10]
    - admission_policies (programme_instance_id, admission_cycle_id, pathway) [NEW per DEC-037]
    - every additional natural-key upsert target
  If polymorphism prevents a normal DB constraint, the contract must explicitly define the application-level invariant.
affected files: canonical/05-implementation.md §4 (schema), canonical/06-data-acquisition.md §11
dependencies: None
validation mechanism: CI migration test: every ON CONFLICT target listed in UPSERT-001 must have a matching constraint in pg_constraint.
regression guard: CI migration test.
```

### MIGR-001 — Migration Dependency-Correctness

```text
CONTRACT-ID: MIGR-001
concern: Migration order and dependency correctness.
authority: V4.7 §46.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-023
executable truth:
  Migrations must be dependency-correct.
  Referenced tables must be created before dependent foreign keys.
  For example: education_authorities → admission_cycles, accreditation_records.
  Do not use deferred FK creation merely to preserve an incorrect sequence unless a genuine circular dependency exists.
  Migrations themselves are executable authority.
  Documentation may explain migration dependency order but is not a second source of truth.
  A fresh-database migration test must pass.
affected files: canonical/05-implementation.md §4.6 (promote to contract)
dependencies: PROJECTION-001, INGEST-003, UPSERT-001 (new tables must be in correct migration order)
validation mechanism: php artisan migrate:fresh on empty DB succeeds; FK dependency graph has no cycles except documented exceptions.
regression guard: CI fresh-DB migration test.
```

### CACHE-001 — Cache Invalidation

```text
CONTRACT-ID: CACHE-001
concern: Event-driven cache invalidation.
authority: V4.7 §59.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-024
executable truth:
  Caching is a separate runtime contract.
  Cache invalidation is durable and event-driven through the same canonical event/outbox mechanism.
  TTL is a safety net, not the primary invalidation mechanism.
  Do not make cache invalidation part of the canonical transaction itself unless explicitly required.
affected files: canonical/04-architecture.md (new §Cache Contract)
dependencies: PROJECTION-001 (uses same canonical event/outbox mechanism)
validation mechanism: Code review; cache invalidation triggered by event listener, not by canonical mutation code.
regression guard: CI test.
```

### PERF-001 — Performance Measurement

```text
CONTRACT-ID: PERF-001
concern: Performance claims require measurement metadata.
authority: V4.7 §60.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-025
executable truth:
  Unmeasured performance claims must not be presented as achieved facts.
  For important performance numbers, the package should provide: target; measurement method; threshold; test environment.
  "Sub-millisecond" may appear only if it is explicitly a target or accompanied by actual evidence.
affected files: canonical/04-architecture.md (new §Performance Contract), MANIFEST.md §4.33-4.34
dependencies: None
validation mechanism: Grep assertion: zero matches for `sub-millisecond|sub-ms` not adjacent to "target" or "evidence".
regression guard: CI grep assertion.
```

### FVS-001 — FVS Boundary

```text
CONTRACT-ID: FVS-001
concern: FVS implementation scope.
authority: V4.7 §61.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-026
executable truth:
  Keep the complete conceptual StudyNexus model.
  Implementation eligibility is limited to: FVS requirements; foundational platform requirements; security/operations required by FVS.
  Non-FVS conceptual domains remain documented but deferred.
  Do not create migrations/models/actions/routes/projections for deferred domains merely because their conceptual tables exist.
  Foundational infrastructure required by the FVS may support future domains.
  
  FVS-eligible: Programme discovery, search, detail, application foundational capabilities, security/operations required by FVS.
  Deferred: scholarship public search (per V4.6 §4.24); institution self-service admin (per DEF-002); comparison view (per V4.6 §4.25 — post-FVS MVP expansion); historical cut-off display (per V4.6 §4.25 — post-FVS MVP expansion).
affected files: canonical/04-architecture.md (new §FVS Boundary), MANIFEST.md §4.25
dependencies: None
validation mechanism: CI assertion: migration count for deferred domains = 0 (or explicitly flagged as foundational infrastructure).
regression guard: CI assertion.
```

### GOV-001 — Governance Status Normalization

```text
CONTRACT-ID: GOV-001
concern: Frozen package governance labels.
authority: V4.7 §62.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-011
executable truth:
  A frozen package must not have active product documents labeled "awaiting approval."
  Normalize V4.6 Tier-2 statuses to the final frozen state.
  Do not preserve contradictory governance labels.
affected files: product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/FIRST-VERTICAL-SLICE-UI.md
dependencies: None
validation mechanism: Grep assertion: zero matches for `awaiting human approval` in active-tier files.
regression guard: CI grep assertion.
```

### GOV-002 — Decision Taxonomy

```text
CONTRACT-ID: GOV-002
concern: ADR status vocabulary.
authority: V4.7 §63.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-027
executable truth:
  Use a clear taxonomy: PROPOSED, APPROVED, FROZEN, DEFERRED, SUPERSEDED, REOPENED, REJECTED.
  A chosen implementation detail may be: frozen decision + separately adjustable implementation parameter.
  Do not call a selected architecture decision "deferred" merely because a tuning value remains operationally adjustable.
affected files: canonical/02-decisions.md (ADR status normalization)
dependencies: None
validation mechanism: Grep assertion: ADR status field matches regex `^(PROPOSED|APPROVED|FROZEN|DEFERRED|SUPERSEDED|REOPENED|REJECTED)$`.
regression guard: CI grep assertion.
```

### GOV-003 — Finding Disposition

```text
CONTRACT-ID: GOV-003
concern: Duplicate finding traceability.
authority: V4.7 §66.
version: 1.0 (V4.7)
status: NEW (this Finding Ledger implements it)
source decision: DEC-029
executable truth:
  A duplicate finding remains as a traceability record. It points to the canonical/root finding. Do not erase evidence merely because two findings share the same underlying issue.
affected files: 01-finding-ledger/FINDING-LEDGER.md
dependencies: None
validation mechanism: Finding Ledger JSON parseable; every finding has all 13 V4.7 §77 fields.
regression guard: CI parse assertion.
```

### GOV-004 — Frozen-Decision Challenge

```text
CONTRACT-ID: GOV-004
concern: Reopening frozen decisions.
authority: V4.7 §67.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-030
executable truth:
  A frozen decision remains authoritative until explicitly reopened.
  A challenge may be raised when strong evidence suggests: security defect; implementation impossibility; serious external contradiction; material architectural invalidity.
  Only the user may issue: `REOPEN DEC-xxx`.
  Reopening does not automatically discard downstream contracts.
  Affected contracts become: `CHALLENGED`.
  Current runtime truth remains intact until the replacement decision is approved.
affected files: canonical/02-decisions.md (new §Frozen-Decision Challenge Protocol)
dependencies: None
validation mechanism: Audit log assertion: any status change to CHALLENGED must reference an explicit `REOPEN DEC-xxx` user action.
regression guard: CI assertion.
```

### GOV-005 — External-Fact Policy

```text
CONTRACT-ID: GOV-005
concern: External facts are evidence, not authority.
authority: V4.7 §9-§10.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-031
executable truth:
  External facts are evidence, not authority.
  For material external facts: cite exact source; identify version/date; identify the exact claim; identify evidence tier; record corroboration where required.
  Tier 1 external facts include: dependency compatibility; security properties; package availability; protocol semantics; critical third-party behavior.
  Tier 1 requires authoritative primary evidence plus corroboration where practically available.
  External facts do not automatically reopen frozen decisions.
  A contradiction between external reality and a frozen decision becomes a frozen-decision challenge.
  Only the user may issue: `REOPEN DEC-xxx`.
  A frozen-decision challenge is urgent when security or implementation feasibility is materially affected.
  Tier 1/high-volatility external facts are reverified according to the external operational process, including appropriate event-triggered verification.
  Reverification may generate a challenge. It must never silently mutate the frozen contract.
affected files: canonical/02-decisions.md (new §External-Fact Policy), 09-external-evidence/EXTERNAL-EVIDENCE-REGISTER.md
dependencies: DEP-001
validation mechanism: External Evidence Register maintained.
regression guard: Audit assertion.
```

### GOV-006 — Narrative Duplication

```text
CONTRACT-ID: GOV-006
concern: Narrative documents vs contracts.
authority: V4.7 §64.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-032
executable truth:
  Narrative documents may explain a contract.
  They must not introduce independently actionable executable values.
  Examples are allowed only when clearly labeled non-authoritative.
  Contracts are the executable truth.
affected files: governance/, product-experience/ (all narrative docs)
dependencies: None
validation mechanism: Audit assertion: narrative documents do not contain executable values not present in registered contracts.
regression guard: CI assertion.
```

### GOV-007 — Two-Engineer Implementation-Determinism Simulation

```text
CONTRACT-ID: GOV-007
concern: Implementation determinism verification.
authority: V4.7 §74.
version: 1.0 (V4.7)
status: NEW (deliverable #16 implements it)
source decision: DEC-038
executable truth:
  Perform a scenario-based simulation as though two engineers independently received the final package.
  For each major subsystem, ask: Would both engineers have enough authority/contracts to choose the same behavior?
  At minimum: database; import; approval; projection; Typesense; search; lifecycle; SEO; RBAC; cache; queues.
  Any legitimate divergence is a material finding.
affected files: 11-implementation-determinism/IMPLEMENTATION-DETERMINISM-REPORT.md
dependencies: None
validation mechanism: Report exists.
regression guard: Future remediations reproduce the simulation.
```

### ARCHIVE-001 — Archive Labeling

```text
CONTRACT-ID: ARCHIVE-001
concern: Archive file labeling requirements.
authority: V4.7 §65.
version: 1.0 (V4.7)
status: NEW (existing V4.6 labeling is adequate; formalize as contract)
source decision: DEC-028
executable truth:
  Archived documents must have: archive placement; explicit archived/superseded metadata; pointer to the superseding decision or contract.
  An active reference to archived material is a finding only if it creates a live path to confusion.
  Do not rewrite properly archived historical content merely to remove old decisions.
affected files: archive/HISTORICAL-README.md (formalize as contract)
dependencies: None
validation mechanism: CI assertion: every file under archive/ has "Archived" or "Superseded" metadata in first 5 lines.
regression guard: CI assertion.
```

### REV-001 — Pending Revisions

```text
CONTRACT-ID: REV-001
concern: Pending revisions polymorphic validation + lifecycle.
authority: V4.7 §44.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-033
executable truth:
  The existing pending_revisions concept remains.
  Polymorphic entity references are validated at the application/domain boundary.
  A conventional generic PostgreSQL FK is not assumed.
  Historical orphaned revisions may remain for audit history.
  Active pending revisions must not reference invalid/deleted targets.
  Pending revisions are immutable after submission.
  Use an explicit lifecycle with: draft/submitted; stale; conflict; approved; rejected; cancelled; superseded.
  A newer revision may supersede an older unresolved revision according to the existing governance rules.
  Do not invent a competing revision model if V4.6 already contains one; extract and reconcile it.
affected files: canonical/05-implementation.md §4, §5
dependencies: RBAC-001
validation mechanism: CI test: pending_revision submitter attempts to mutate after submission → 409; pending_revision references deleted target → 422.
regression guard: CI tests.
```

### SRC-001 — Source Priority

```text
CONTRACT-ID: SRC-001
concern: Source priority for conflict resolution.
authority: V4.7 §42.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-034
executable truth:
  Source priority is governed by a dedicated data-governance capability.
  Priority resolves conflicts between same-scope assertions.
  Source priority does not override domain scope.
  Example: instance-specific policy cannot be overridden by an institution-wide policy merely because the institution source has greater source priority.
  Priority changes affect future resolution unless explicit re-reconciliation is performed.
affected files: canonical/05-implementation.md §4 (information_sources.priority column), canonical/06-data-acquisition.md
dependencies: SRC-002
validation mechanism: Reconciliation test.
regression guard: Scenario tests S-25, S-26.
```

### SRC-002 — Admission Policy Precedence

```text
CONTRACT-ID: SRC-002
concern: Admission policy precedence.
authority: V4.7 §43.
version: 1.0 (V4.7)
status: NEW
source decision: DEC-034
executable truth:
  Canonical precedence: instance-specific policy > institution-level policy > no applicable policy.
  No implicit fabricated default admission policy.
  Same-scope conflicts that cannot be deterministically resolved are blocking reconciliation errors.
  Source priority may resolve competing assertions at the same scope.
affected files: canonical/03-domain.md, canonical/05-implementation.md §4, canonical/06-data-acquisition.md
dependencies: SRC-001
validation mechanism: Reconciliation test.
regression guard: Scenario tests S-25, S-26.
```

---

## Contract Propagation Matrix (summary)

| Contract | Affected Active-Tier Files (count) | Propagation Status |
|----------|------------------------------------|--------------------|
| SEARCH-001 | 9 | PENDING |
| OUTAGE-001 | 4 | PENDING |
| PROJECTION-001 through PROJECTION-017 | 2 canonical + 4 product-experience | PENDING |
| TYPESENSE-001 | 1 canonical + 3 product-experience | PENDING |
| SERIAL-001 | 1 | PENDING |
| QUEUE-001 | 2 | SKELETON ONLY |
| TRUST-001, TRUST-002 | 2 | PENDING |
| INGEST-001, INGEST-002, INGEST-003 | 2 | PENDING |
| LIFE-001 | 6 | BLOCKED on DEC-012, DEC-035 |
| SEO-001 through SEO-005 | 2 canonical + 3 product-experience | PENDING |
| DEP-001, DEP-002 | 1 | PENDING |
| RBAC-001 | 1 | PENDING |
| UPSERT-001 | 2 | PENDING |
| MIGR-001 | 1 | PENDING |
| CACHE-001 | 1 | PENDING |
| PERF-001 | 2 | PENDING |
| FVS-001 | 2 | PENDING |
| GOV-001 | 4 product-experience | PENDING |
| GOV-002 | 1 | PENDING |
| GOV-003, GOV-004, GOV-005, GOV-006, GOV-007 | 1-2 each | PENDING |
| ARCHIVE-001 | 1 (formalize) | PENDING |
| REV-001 | 1 | PENDING |
| SRC-001, SRC-002 | 3 | PENDING |

Full propagation matrix in deliverable #13.

---

*End of Contract Registry. 41 contracts registered: 8 existing (verified), 32 new (contract language ready, awaiting file propagation), 1 proposed (QUEUE-001 skeleton, blocked on user approval). No duplicate contracts.*
