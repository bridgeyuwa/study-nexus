# StudyNexus V4.6 → V4.7 — Final Implementation-Determinism Report (Two-Engineer Simulation)

**Document:** 11 — Final Implementation-Determinism Report (V4.7 §76 item 16, §74)
**Date:** 2026-08-26

This report simulates two competent engineers independently receiving the V4.6 package + V4.7 remediation contracts and asks: **Would both engineers have enough authority/contracts to choose the same behavior for each major subsystem?**

Per V4.7 §74: "Any legitimate divergence is a material finding."

---

## Simulation Methodology

For each major subsystem, the simulation asks:
1. What decision(s) govern this subsystem?
2. Is the decision FROZEN, APPROVED, PROPOSED, or missing?
3. If FROZEN: are contracts fully propagated to active-tier files?
4. If PROPOSED or missing: would two engineers diverge?

**Subsystems audited (per V4.7 §74):** database, import, approval, projection, Typesense, search, lifecycle, SEO, RBAC, cache, queues.

---

## Subsystem-by-Subsystem Simulation

### 1. Database

```text
Decision: DEC-023 (MIGR-001 — migration dependency-correctness)
Status: FROZEN
Contract propagation: PARTIAL — MIGR-001 contract language ready; canonical/05-implementation.md §4.6 not yet promoted to contract; new tables (projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects) not yet in migration order.
Final audit findings: FA-002, FA-004, FA-005, FA-006, FA-009, FA-010, FA-011, FA-012, FA-013 (9 migration order gaps).

Two-engineer simulation:
  Engineer A reads canonical/05-implementation.md §4.6 and follows the listed order. She adds the 6 new tables in an order she considers reasonable (e.g., canonical_imports before projection_events because imports trigger projections).
  Engineer B reads canonical/05-implementation.md §4.6 and follows the listed order. He adds the 6 new tables in a different order (e.g., projection_events before canonical_imports because projections are mentioned first in §8.5).
  
  Both engineers pass `php artisan migrate:fresh` on a fresh DB because the new tables have no inter-table FK dependencies EXCEPT:
  - projection_event_targets.projection_event_id → projection_events(id) — projection_events MUST be before projection_event_targets.
  - pending_projection_requests has no FK to projection_events (it stores pending_revision directly).
  - projection_states has no FK to projection_events (it stores last_applied_projection_revision directly).

  However, the migration order for disciplines, external_identifiers, field_provenance, pending_revisions, organization_members, campuses, programme_instances, scholarships, accreditation_records, cut_off_marks is NOT explicitly listed in V4.6 §4.6. Two engineers would likely order these differently.

Divergence risk: HIGH for migration order of existing tables; LOW for new tables (FK dependencies are clear).

Verdict: ❌ DIVERGENCE — two engineers would produce different migration sequences. MIGR-001 contract must be propagated with explicit full migration order.

Required remediation: Complete MIGR-001 contract with full migration order list (all 61 existing tables + 6 new tables) in canonical/05-implementation.md §4.6.
```

### 2. Import

```text
Decisions: DEC-003 (TRUST-001 two-stage approval), DEC-004 (INGEST-001 artifact-level atomicity), DEC-019 (INGEST-003 canonical_imports state)
Status: All FROZEN
Contract propagation: NOT YET APPLIED — canonical/06-data-acquisition.md §13 still has V4.6 HMAC-only + per-record atomicity language.

Two-engineer simulation:
  Engineer A reads V4.6 §13 and implements HMAC-shared-secret approval with per-record atomicity.
  Engineer B reads V4.7 prompt §37, §40 and implements two-stage approval with artifact-level atomicity.
  
  The two implementations would have completely different security postures (Engineer A's is forgeable; Engineer B's is not) and different data integrity guarantees (Engineer A's allows partial application; Engineer B's does not).

Divergence risk: CRITICAL.

Verdict: ❌ DIVERGENCE — V4.6 §13 directly contradicts V4.7 §37, §40. Contract propagation is required.

Required remediation: Rewrite canonical/06-data-acquisition.md §13 per TRUST-001, INGEST-001, INGEST-002, INGEST-003 contracts.
```

### 3. Approval

```text
Decisions: DEC-003 (TRUST-001), DEC-019 (INGEST-003 canonical_imports state)
Status: FROZEN
Contract propagation: NOT YET APPLIED.

Two-engineer simulation:
  Engineer A implements V4.6 HMAC-only approval (acquisition worker signs with shared secret; production verifies).
  Engineer B implements V4.7 two-stage approval (transport HMAC for integrity + Filament human approval with separate signing key).
  
  Divergence: Engineer A's design grants the acquisition environment the approval signing credential (forbidden by V4.7 §40). Engineer B's design correctly separates transport integrity from approval signature.

Divergence risk: CRITICAL (security defect in Engineer A's approach).

Verdict: ❌ DIVERGENCE.

Required remediation: Same as Import — rewrite §13.
```

### 4. Projection

```text
Decisions: DEC-002 (PROJECTION-001 through PROJECTION-017), DEC-008 (SERIAL-001)
Status: FROZEN
Contract propagation: NOT YET APPLIED — canonical/04-architecture.md and canonical/05-implementation.md still describe the "UpdateSearchIndex listener → queued Scout job" pathway.

Two-engineer simulation:
  Engineer A reads V4.6 §8 and implements Eloquent event listener + Scout queue (V4.6 approach). No projection_events table. No projection_event_revision. No historical affectedness. No crash recovery.
  Engineer B reads V4.7 §14-§32 and implements the full projection event architecture with 4 new tables, immutable revision, REPEATABLE READ snapshot, APPLYING→APPLIED state machine, crash recovery.
  
  Divergence: Engineer A's design has runtime races (S-11, S-12, S-15) and no crash recovery. Engineer B's design is deterministic and recoverable. The two implementations produce different runtime behavior under concurrency and failure.

Divergence risk: CRITICAL.

Verdict: ❌ DIVERGENCE — the most significant divergence in the package.

Required remediation: Add PROJECTION-001 through PROJECTION-017 and SERIAL-001 contract sections to canonical/05-implementation.md §8.5. Replace UpdateSearchIndex listener language in canonical/04-architecture.md §3, §6.
```

### 5. Typesense

```text
Decisions: DEC-007 (TYPESENSE-001 field registry), DEC-053 (PROJECTION-017 nested schema), DEC-010 (cut_off_latest removal), DEC-043 (admission-open semantics), DEC-044 (programme result status)
Status: All FROZEN
Contract propagation: PARTIAL — V4.6 §8.3.1 has nested filter syntax (per MANIFEST §71); TYPESENSE-001 field registry not yet added.

Two-engineer simulation:
  Engineer A reads V4.6 §8.3, §8.4 and implements Typesense collections with informal field documentation. She keeps `cut_off_latest` as a top-level field. She does not implement Programme Result Status contextual display.
  Engineer B reads V4.7 §22, §33-§36 and implements TYPESENSE-001 field registry, removes `cut_off_latest`, adds contextual nested cutoffs, implements Programme Result Status with "Multiple admission states" display.
  
  Divergence: Engineer A's Typesense schema has `cut_off_latest` (forbidden by V4.7 §36). Engineer B's does not. Engineer A's search results display Programme-level admission status (forbidden by V4.7 §35). Engineer B's display contextual instance-set status.

Divergence risk: HIGH.

Verdict: ❌ DIVERGENCE.

Required remediation: Add TYPESENSE-001 contract section to canonical/05-implementation.md §8.6. Remove `cut_off_latest` from product-experience files (3 files, 8 occurrences per F-010).
```

### 6. Search

```text
Decisions: DEC-001 (SEARCH-001 — no PostgreSQL fallback), DEC-040 (OUTAGE-001 — Typesense outage contract)
Status: FROZEN
Contract propagation: NOT YET APPLIED — 14 active-tier files still contain "PostgreSQL FTS fallback" language.

Two-engineer simulation:
  Engineer A reads V4.6 and implements PostgreSQL FTS fallback for degraded public search (V4.6 §4.30: "basic facets remain functional via PostgreSQL query-builder").
  Engineer B reads V4.7 §12-§13 and implements explicit unavailable/search-failure state (no silent switch to PostgreSQL).
  
  Divergence: Engineer A's design silently switches to PostgreSQL during outages (forbidden by V4.7 §13). Engineer B's design returns an explicit unavailable state. The two implementations produce different user experiences during Typesense outages (S-35).

Divergence risk: CRITICAL.

Verdict: ❌ DIVERGENCE.

Required remediation: Apply SEARCH-001 and OUTAGE-001 contracts across 14 active-tier files per F-001 remediation plan.
```

### 7. Lifecycle

```text
Decisions: DEC-012 (InstitutionStatus::Closed replacement — PROPOSED), DEC-035 (ProgrammeStatus reconciliation — PROPOSED), DEC-013 (SEO-001 matrix)
Status: 2 PROPOSED (BLOCKED on user approval), 1 FROZEN
Contract propagation: BLOCKED on user decisions.

Two-engineer simulation:
  Engineer A reads V4.6 and keeps InstitutionStatus::Closed and ProgrammeStatus (Prospective, Admitting, Suspended, Discontinued) as-is.
  Engineer B reads V4.7 §49 and renames InstitutionStatus::Closed to Discontinued; she also renames ProgrammeStatus to (ACTIVE, SUSPENDED, DISCONTINUED) per V4.7 §50 matrix.
  
  Divergence: Engineer A's enums include Closed (forbidden by V4.7 §49). Engineer B's enums do not. The two implementations have different lifecycle state machines.

Divergence risk: HIGH.

Verdict: ❌ DIVERGENCE — cannot be resolved without user decisions on DEC-012 and DEC-035.

Required remediation: User must approve DEC-012 (recommended: rename Closed → Discontinued) and DEC-035 (recommended: keep V4.6 enum + document mapping).
```

### 8. SEO

```text
Decisions: DEC-013 (SEO-001 matrix), DEC-014 (SEO-002 indexability registry), DEC-015 (SEO-003 sitemap), DEC-016 (SEO-004 structured data), DEC-017 (SEO-005 redirects)
Status: All FROZEN
Contract propagation: NOT YET APPLIED — no SEO contract sections in canonical/04-architecture.md.

Two-engineer simulation:
  Engineer A reads V4.6 product-experience files and implements informal SEO rules (some pages indexable, some not, based on ad-hoc decisions).
  Engineer B reads V4.7 §50-§54 and implements formal SEO-001 through SEO-005 contracts with explicit registry.
  
  Divergence: Engineer A's implementation has arbitrary indexability decisions (forbidden by V4.7 §51). Engineer B's implementation has a registered indexability registry. The two implementations produce different sitemap contents and different robots meta tags.

Divergence risk: HIGH.

Verdict: ❌ DIVERGENCE.

Required remediation: Add SEO-001 through SEO-005 contract sections to canonical/04-architecture.md. Add `url_redirects` table to canonical/05-implementation.md §4.
```

### 9. RBAC

```text
Decisions: DEC-021 (RBAC-001 self-approval prevention), DEC-033 (REV-001 pending revisions lifecycle)
Status: FROZEN
Contract propagation: NOT YET APPLIED — canonical/05-implementation.md §5 lacks self-approval prevention rule.

Two-engineer simulation:
  Engineer A reads V4.6 §5 and implements RBAC with 11 roles + organization scoping but no self-approval prevention.
  Engineer B reads V4.7 §45 and adds `PendingRevision.submitter_id ≠ approver_id` enforcement.
  
  Divergence: Engineer A's implementation allows a user to approve their own revision (forbidden by V4.7 §45). Engineer B's does not. The two implementations have different security postures for the pending revisions workflow (S-27).

Divergence risk: HIGH.

Verdict: ❌ DIVERGENCE.

Required remediation: Add RBAC-001 and REV-001 contract sections to canonical/05-implementation.md §5.
```

### 10. Cache

```text
Decisions: DEC-024 (CACHE-001 event-driven invalidation)
Status: FROZEN
Contract propagation: NOT YET APPLIED — no cache contract in canonical/04-architecture.md.

Two-engineer simulation:
  Engineer A reads V4.6 and implements TTL-based cache invalidation (no event-driven invalidation).
  Engineer B reads V4.7 §59 and implements event-driven cache invalidation through the canonical event/outbox mechanism.
  
  Divergence: Engineer A's cache may serve stale data between TTL expirations. Engineer B's cache is invalidated immediately on canonical mutation. The two implementations produce different cache consistency behavior.

Divergence risk: MEDIUM.

Verdict: ❌ DIVERGENCE.

Required remediation: Add CACHE-001 contract section to canonical/04-architecture.md. Depends on PROJECTION-001 (canonical event/outbox mechanism).
```

### 11. Queues

```text
Decisions: DEC-009 (QUEUE-001 — concrete values PROPOSED, requires user approval)
Status: PROPOSED — BLOCKED on user approval of concrete values
Contract propagation: SKELETON only — concrete values not yet approved.

Two-engineer simulation:
  Engineer A reads V4.6 and uses Laravel default queue config (retries=3, backoff=90s, no exception cap, no failed-job retention policy).
  Engineer B reads V4.7 §57 and implements QUEUE-001 skeleton with V4.7-mandated elements but invents concrete values (retries=5, backoff=10s, timeout=300s, etc.).
  
  Divergence: Engineer A's queue has default retry behavior. Engineer B's queue has different retry behavior. The two implementations produce different runtime behavior under failure (S-12, S-15).

Divergence risk: HIGH.

Verdict: ❌ DIVERGENCE — cannot be resolved without user approval of QUEUE-001 concrete values.

Required remediation: User must approve QUEUE-001 concrete values per DEC-009.
```

---

## Simulation Summary

| Subsystem | Decision Status | Contract Propagation | Divergence Risk | Verdict |
|-----------|----------------|----------------------|-----------------|---------|
| Database | FROZEN | PARTIAL | HIGH | ❌ DIVERGENCE |
| Import | FROZEN | NOT APPLIED | CRITICAL | ❌ DIVERGENCE |
| Approval | FROZEN | NOT APPLIED | CRITICAL | ❌ DIVERGENCE |
| Projection | FROZEN | NOT APPLIED | CRITICAL | ❌ DIVERGENCE |
| Typesense | FROZEN | PARTIAL | HIGH | ❌ DIVERGENCE |
| Search | FROZEN | NOT APPLIED | CRITICAL | ❌ DIVERGENCE |
| Lifecycle | 2 PROPOSED, 1 FROZEN | BLOCKED | HIGH | ❌ DIVERGENCE |
| SEO | FROZEN | NOT APPLIED | HIGH | ❌ DIVERGENCE |
| RBAC | FROZEN | NOT APPLIED | HIGH | ❌ DIVERGENCE |
| Cache | FROZEN | NOT APPLIED | MEDIUM | ❌ DIVERGENCE |
| Queues | PROPOSED | SKELETON | HIGH | ❌ DIVERGENCE |

**All 11 subsystems exhibit implementation divergence.**

---

## Root Cause Analysis

The divergence across all 11 subsystems has two root causes:

1. **Contract propagation is incomplete.** The V4.7 prompt provides FROZEN contract language for 32 new contracts (per Contract Registry), but these contracts have NOT been propagated to the active-tier files. V4.6 files still contain V4.5/V4.6-era language that contradicts V4.7.

2. **4 user decisions are unresolved.** DEC-006 (filament-shield version), DEC-009 (QUEUE-001 values), DEC-012 (InstitutionStatus::Closed), DEC-035 (ProgrammeStatus reconciliation) require user approval before contract language can be finalized.

3. **3 new user decisions surfaced in final audit.** DEC-040 (projection_events retention), DEC-041 (canonical_imports retention), DEC-042 (collection_generation update mechanism) require user approval.

---

## Resolution Path

To eliminate implementation divergence:

1. **User resolves 7 decisions** (DEC-006, DEC-009, DEC-012, DEC-035, DEC-040, DEC-041, DEC-042).
2. **Remediation agent propagates 32 new contracts** to active-tier files per Change Manifest (deliverable #4).
3. **Remediation agent applies 47 finding remediations** (22 Tier-1 + 18 Tier-2 + 7 Tier-3) per Finding Ledger (deliverable #1).
4. **Remediation agent verifies** via 36 scenario tests (deliverable #6) and final adversarial audit (deliverable #7).
5. **Remediation agent re-runs two-engineer simulation** to confirm zero divergence.

Until all 5 steps are complete, the package is NO-GO.

---

## Final Determinism Verdict

**Per V4.7 §74: "Any legitimate divergence is a material finding."**

All 11 subsystems exhibit legitimate divergence. Therefore: **11 material findings remain.**

The V4.7 §80 GO condition requires:
- "zero missing implementation-critical decisions" → 7 decisions missing (DEC-006, DEC-009, DEC-012, DEC-035, DEC-040, DEC-041, DEC-042)
- "two-engineer implementation simulation passes" → 11 subsystems FAIL

**Implementation-determinism simulation verdict: FAIL.**

---

*End of Implementation-Determinism Report. 11 subsystems audited; all 11 exhibit implementation divergence. 7 user decisions required to resolve. Final verdict: FAIL — package is NO-GO.*
