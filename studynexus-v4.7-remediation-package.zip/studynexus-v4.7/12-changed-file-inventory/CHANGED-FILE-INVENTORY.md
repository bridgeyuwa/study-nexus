# StudyNexus V4.6 → V4.7 — Changed-File Inventory

**Document:** 12 — Changed-File Inventory (V4.7 §76 item 8)
**Date:** 2026-08-26

This document lists every file that requires modification to elevate V4.6 to V4.7, with the specific changes required per file.

---

## Summary

| Category | Files Modified | Files Created | Files Deleted |
|----------|----------------|---------------|---------------|
| Canonical (Tier 1) | 5 (01-business.md unchanged) | 0 | 0 |
| Product Experience (Tier 2) | 4 | 0 | 0 |
| Governance (Tier 4) | 1 (DISCOVERY-CLOSURE.md) | 0 | 0 |
| Orientation | 1 (AUTHORITY-HIERARCHY.md) | 0 | 0 |
| Root | 4 (README, GLOSSARY, MANIFEST, V4.2-REMEDIATION-REPORT unchanged) | 0 | 0 |
| Archive (Tier 6) | 1 (HISTORICAL-README.md formalize) | 0 | 0 |
| **TOTAL** | **16 unique files** | 0 | 0 |

**File count remains 57** (no files created or deleted; only modifications).

---

## Detailed File-by-File Change List

### Files Requiring MAJOR Changes (multiple sections, multiple contracts)

#### 1. canonical/05-implementation.md
- **Lines affected:** 51, 104, 346, 348, 354, 869, 882, 884, 886, 888, 893, 906, 907, 1148, 1288, 1322, 1373, 1384, 1423, 1443, 1479, 1484, 1507
- **Sections affected:** §2 package table, §3 folder structure, §4 schema (programmes table search_vector description), §8.0 idempotent upsert, §8.1 PostgreSQL FTS Fallback (DELETE subsection), §8.2-§8.4 search sections, §10.1 phase plan, §12 forbidden-actions
- **New sections to add:**
  - §8.5 Projection Event Architecture (PROJECTION-001 through PROJECTION-017, SERIAL-001)
  - §8.6 TYPESENSE-001 Contract (field registry, Programme Search Schema, Admission Open Semantics, Programme Result Status, Cut-off Semantics)
  - §8.7 Trust Model (TRUST-001, TRUST-002)
  - §8.8 Import Atomicity (INGEST-001, INGEST-002, INGEST-003)
  - §4 new table schemas: projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects, admission_policies (explicit)
  - §4.6 MIGR-001 contract promotion (full migration order with new tables)
  - §4 UPSERT-001 contract (every ON CONFLICT target audit)
  - §5 RBAC-001 self-approval prevention
  - §5 REV-001 pending revisions lifecycle
  - §12 DEP-001 contract (8-column dependency registry)
  - §12 QUEUE-001 contract skeleton (concrete values pending user approval)
  - §12 LIFE-001 contract (pending DEC-012, DEC-035)
  - §12 SRC-001, SRC-002 contracts
  - §12 FVS-001 contract
- **Driver findings:** F-001, F-002, F-005, F-006, F-007, F-008, F-009, F-010, F-019, F-020, F-021, F-022, F-023, F-024, F-025, F-026, F-033, F-034, F-037, F-042, F-043, F-044
- **Estimated change volume:** ~2000-3000 lines added/modified

#### 2. canonical/04-architecture.md
- **Lines affected:** 27, 52, 59, 67, 78, 139, 273, 281, 294, 298, 309, 334-343, 396, 475, 501, 727, 757
- **Sections affected:** §1 P9 principle, §2 Technology Stack table, §2 Canonical Stack Summary, §3 Application Architecture (UpdateSearchIndex listener), §6 Read Model (PostgreSQL FTS Fallback Implementation subsection DELETE), §6 read model table, §6 line 396, 475, 501, 727, 757
- **New sections to add:**
  - §Typesense Outage Contract (OUTAGE-001)
  - §SEO Lifecycle Matrix (SEO-001)
  - §SEO Indexability Registry (SEO-002)
  - §Sitemap Eligibility (SEO-003)
  - §Structured Data Contract (SEO-004)
  - §URL Redirect Contract (SEO-005)
  - §Cache Contract (CACHE-001)
  - §Performance Contract (PERF-001)
  - §FVS Boundary (FVS-001)
  - §Projection Event Architecture reference (PROJECTION-001 through PROJECTION-017)
- **Driver findings:** F-001, F-002, F-005, F-006, F-013, F-014, F-015, F-016, F-017, F-024, F-025, F-026, F-042
- **Estimated change volume:** ~800-1200 lines added/modified

#### 3. canonical/06-data-acquisition.md
- **Lines affected:** 476, 534, 567-610 (§13 Ingestion API Endpoint), 598, 607, 609
- **Sections affected:** §7 Import Workflow (rewrite for artifact-level atomicity), §11.1 ON CONFLICT targets (add UPSERT-001 audit), §13 Ingestion API Endpoint (REWRITE for two-stage trust model), §14 Code-Sharing Does Not Equal Trust-Sharing (add TRUST-001 note)
- **Driver findings:** F-003, F-004, F-019, F-022, F-037
- **Estimated change volume:** ~300-500 lines modified

#### 4. canonical/02-decisions.md
- **Lines affected:** 237, 263, 455, 459, 495, 559, 611, 613
- **Sections affected:** ADR-6 Search Engine Selection (rewrite), ADR for PostgreSQL (rewrite), ADR statuses (normalize to V4.7 §63 taxonomy)
- **New sections to add:**
  - §Frozen-Decision Challenge Protocol (GOV-004)
  - §External-Fact Policy (GOV-005)
  - §Narrative Duplication Policy (GOV-006)
- **Driver findings:** F-001, F-027, F-030, F-031, F-032
- **Estimated change volume:** ~200-400 lines added/modified

#### 5. canonical/03-domain.md
- **Lines affected:** InstitutionStatus enum (verify line), ProgrammeStatus enum (verify line)
- **Sections affected:** §3 §10 enum declarations
- **Driver findings:** F-012, F-035
- **Status:** BLOCKED on DEC-012, DEC-035 user approval
- **Estimated change volume:** ~10-50 lines (depending on user decisions)

#### 6. product-experience/FIRST-VERTICAL-SLICE-UX.md
- **Lines affected:** 4, 7, 348-351, 361, 362, 531-532, 582, 593, 635, 655, 738, 740, 741, 744, 752, 757, 815, 928, 955, 1055, 1065
- **Sections affected:** Line 4 status, Line 7 PostgreSQL FTS fallback note, §17.3 Discontinued/Closed Page Behavior, sort table (cut_off_latest removal), lifecycle filtering
- **Driver findings:** F-001, F-010, F-011, F-012
- **Status:** Partially BLOCKED on DEC-012 for Closed references
- **Estimated change volume:** ~50-100 lines modified

#### 7. product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md
- **Lines affected:** 4, 1152, 1179, 1211, 1689, 820, 863-866
- **Sections affected:** Line 4 status, B-14 result card (cut_off_latest removal), Typesense field table (cut_off_latest removal), Computed/derived attributes (cut_off_latest removal), §12.2 Closed/Suspended Institution (pending DEC-012), ProgrammeStatus mapping (pending DEC-035)
- **Driver findings:** F-010, F-011, F-012, F-035
- **Status:** Partially BLOCKED on DEC-012, DEC-035
- **Estimated change volume:** ~30-60 lines modified

#### 8. product-experience/FIRST-VERTICAL-SLICE-UI.md
- **Lines affected:** 4, 853, 866
- **Sections affected:** Line 4 status, Result card field list (cut_off_latest removal), Sort fields (cut_off_latest removal)
- **Driver findings:** F-010, F-011
- **Estimated change volume:** ~10-20 lines modified

#### 9. product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md
- **Lines affected:** 4
- **Sections affected:** Line 4 status
- **Driver findings:** F-011
- **Estimated change volume:** 1 line modified

#### 10. README.md
- **Lines affected:** 27, 31, 40, 42, 74, 78
- **Sections affected:** §Mandated Technology Stack (PostgreSQL row, Fortify row, Search V1 hard constraint, Package Directory Structure comments)
- **Driver findings:** F-001, F-005
- **Estimated change volume:** ~10-20 lines modified

#### 11. GLOSSARY.md
- **Lines affected:** 80, 82, 122, 124
- **Sections affected:** PostgreSQL FTS entry, InstitutionStatus entry (pending DEC-012)
- **Driver findings:** F-001, F-012
- **Status:** Partially BLOCKED on DEC-012
- **Estimated change volume:** ~5-15 lines modified

#### 12. 00-ORIENTATION/AUTHORITY-HIERARCHY.md
- **Lines affected:** 68, 97, 113
- **Sections affected:** Tier 4 Discovery Closure row, V4.6 Key Decisions item 7, V4.6 ARBITRATION-FINAL item 18 (Typesense fallback UX)
- **Driver findings:** F-001, F-042
- **Estimated change volume:** ~10-20 lines modified

#### 13. governance/DISCOVERY-CLOSURE.md
- **Lines affected:** 7, 44, 381, 382, 500, 549-552
- **Sections affected:** Line 7 PostgreSQL FTS fallback note, InstitutionStatus enum references (pending DEC-012)
- **Driver findings:** F-001, F-012
- **Status:** Partially BLOCKED on DEC-012
- **Estimated change volume:** ~10-20 lines modified

#### 14. MANIFEST.md
- **Lines affected:** 5, §4.30
- **Sections affected:** Header status line (add V4.7 remediation note), §4.30 Typesense fallback UX (rewrite per OUTAGE-001)
- **New sections to add:** §V4.7 Remediation Summary
- **Driver findings:** F-001, F-042
- **Estimated change volume:** ~30-50 lines added/modified

#### 15. archive/HISTORICAL-README.md
- **Sections affected:** Formalize as ARCHIVE-001 contract
- **Driver findings:** F-028
- **Estimated change volume:** ~20-30 lines added

#### 16. canonical/01-business.md — NO CHANGE

---

## Files NOT Modified

The following 41 files require NO modification:

### Canonical (1 file unchanged)
- canonical/01-business.md (no findings)

### Governance (9 files unchanged)
- governance/CANONICAL-CONSISTENCY-AUDIT.md (V4.6 already corrected)
- governance/CANONICAL-UPDATE-REPORT.md (V4.6 already corrected)
- governance/FOUNDATIONAL-DECISIONS-BRIEF.md (V4.6 already annotated)
- governance/ADVERSARIAL-DECISION-REVIEW.md (no findings)
- governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md (no findings)
- governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md (no findings)
- governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md (no findings)
- governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md (no findings)
- governance/CANONICAL-AMENDMENT-REPORT.md (V4.6 already annotated)

### Root (2 files unchanged)
- V4.2-REMEDIATION-REPORT.md (historical document; PostgreSQL FTS fallback references are in past-tense V4.2-era context)
- PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md (historical baseline report)

### Archive (30 files unchanged)
- All 30 archive files except HISTORICAL-README.md (properly labeled Tier 6 Historical per ARCHIVE-001; no remediation required per V4.7 §2, §65)

---

## SHA-256 Recomputation Plan

After all file modifications are applied, all 57 SHA-256 hashes in MANIFEST.md File Inventory table must be recomputed. The MANIFEST.md self-hash (entry #3) must be recomputed using the zeroed-field method described in V4.6 MANIFEST.md §"Self-hash note."

Files whose SHA-256 will change:
1. canonical/02-decisions.md
2. canonical/03-domain.md (if DEC-012, DEC-035 approved)
3. canonical/04-architecture.md
4. canonical/05-implementation.md
5. canonical/06-data-acquisition.md
6. governance/DISCOVERY-CLOSURE.md
7. product-experience/FIRST-VERTICAL-SLICE-UI.md
8. product-experience/FIRST-VERTICAL-SLICE-UX.md
9. product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md
10. product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md
11. README.md
12. GLOSSARY.md
13. 00-ORIENTATION/AUTHORITY-HIERARCHY.md
14. MANIFEST.md (self-hash via zeroed-field method)
15. archive/HISTORICAL-README.md

Files whose SHA-256 will NOT change: 42 files (all other canonical, governance, root, and archive files).

---

## Execution Order (per V4.7 §69 Required Execution Order)

The 16 file modifications must be applied in the following order to maintain package coherence:

1. **Phase 3 — Dependency/package contract:**
   - canonical/04-architecture.md §2 (Fortify version fix per DEC-005)
   - canonical/05-implementation.md §2 (filament-shield version fix per DEC-006 — BLOCKED on external verification)

2. **Phase 4 — Database/migration contract:**
   - canonical/05-implementation.md §4 (new table schemas: projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects, admission_policies)
   - canonical/05-implementation.md §4.6 (MIGR-001 contract promotion with full migration order)
   - canonical/05-implementation.md §4 (UPSERT-001 contract — admission_policies UNIQUE constraint)

3. **Phase 5 — Ingestion/trust contract:**
   - canonical/06-data-acquisition.md §13 (rewrite for TRUST-001, INGEST-001, INGEST-002, INGEST-003)
   - canonical/06-data-acquisition.md §7, §11.1, §14 (updates)

4. **Phase 6 — Projection/search contract:**
   - canonical/05-implementation.md §8.5 (new Projection Event Architecture section)
   - canonical/05-implementation.md §8.6 (new TYPESENSE-001 section)
   - canonical/05-implementation.md §8.1 (DELETE PostgreSQL FTS Fallback subsection)
   - canonical/05-implementation.md §8.0, §8.2-§8.4, §10.1, §12 (PostgreSQL FTS fallback removal)
   - canonical/04-architecture.md §3, §6 (UpdateSearchIndex listener replacement; PostgreSQL FTS Fallback Implementation subsection DELETE)
   - product-experience/FIRST-VERTICAL-SLICE-UX.md (cut_off_latest removal)
   - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md (cut_off_latest removal)
   - product-experience/FIRST-VERTICAL-SLICE-UI.md (cut_off_latest removal)

5. **Phase 7 — SEO:**
   - canonical/04-architecture.md (new SEO-001 through SEO-005 sections)
   - canonical/05-implementation.md §4 (url_redirects table schema)

6. **Phase 8 — RBAC:**
   - canonical/05-implementation.md §5 (RBAC-001, REV-001 contracts)

7. **Phase 9 — FVS boundary:**
   - canonical/04-architecture.md (new FVS-001 section)
   - canonical/05-implementation.md §12 (new FVS-001 contract)

8. **Phase 10 — Governance normalization:**
   - product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md (line 4 status)
   - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md (line 4 status)
   - product-experience/FIRST-VERTICAL-SLICE-UX.md (line 4 status)
   - product-experience/FIRST-VERTICAL-SLICE-UI.md (line 4 status)
   - canonical/02-decisions.md (ADR status normalization; GOV-004, GOV-005, GOV-006 sections)
   - canonical/03-domain.md (InstitutionStatus, ProgrammeStatus — BLOCKED on DEC-012, DEC-035)
   - canonical/05-implementation.md §12 (LIFE-001, SRC-001, SRC-002, GOV-002, GOV-003, GOV-007, ARCHIVE-001, CACHE-001, PERF-001, DEP-001, DEP-002, QUEUE-001 contracts)
   - canonical/04-architecture.md (CACHE-001, PERF-001 sections)
   - governance/DISCOVERY-CLOSURE.md (PostgreSQL FTS fallback removal; InstitutionStatus — BLOCKED on DEC-012)
   - GLOSSARY.md (PostgreSQL FTS entry; InstitutionStatus — BLOCKED on DEC-012)
   - 00-ORIENTATION/AUTHORITY-HIERARCHY.md (PostgreSQL FTS fallback removal; OUTAGE-001 reference)
   - README.md (PostgreSQL FTS fallback removal)
   - MANIFEST.md (§4.30 rewrite; V4.7 Remediation Summary section; SHA-256 recomputation)
   - archive/HISTORICAL-README.md (ARCHIVE-001 contract formalization)

---

## File Count Integrity

| Category | V4.6 Count | V4.7 Count | Change |
|----------|------------|------------|--------|
| Root | 5 | 5 | 0 |
| 00-ORIENTATION | 1 | 1 | 0 |
| canonical | 6 | 6 | 0 |
| product-experience | 4 | 4 | 0 |
| governance | 10 | 10 | 0 |
| archive | 31 | 31 | 0 |
| **Total** | **57** | **57** | **0** |

File count is unchanged. No files created or deleted. Only modifications.

---

*End of Changed-File Inventory. 16 files require modification; 41 files unchanged; file count remains 57.*
