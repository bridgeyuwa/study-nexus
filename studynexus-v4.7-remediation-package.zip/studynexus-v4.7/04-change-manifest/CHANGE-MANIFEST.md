# StudyNexus V4.6 → V4.7 — Change Manifest

**Document:** 04 — Change Manifest (V4.7 §76 item 2)
**Date:** 2026-08-26
**Source package:** V4.6 (57 files, 43,616 lines)
**Target package:** V4.7 (remediated)

---

## Executive Summary

This manifest documents every change required to elevate the V4.6 package to V4.7. The remediation applies 81 governance rules from the V4.7 prompt, addresses 47 findings (22 Tier-1, 18 Tier-2, 7 Tier-3), and propagates 41 registered contracts (8 existing verified, 32 new, 1 proposed-skeleton).

**Final verdict: NO-GO.** 22 Tier-1 findings remain unresolved because:
1. 4 decisions require user approval before implementation (DEC-006 filament-shield version, DEC-009 QUEUE-001 values, DEC-012 InstitutionStatus::Closed replacement, DEC-035 ProgrammeStatus reconciliation).
2. The projection-event/outbox architecture (F-002) requires adding 4 new tables and rewriting the search sync pathway across multiple canonical files — contract language is ready (in Contract Registry), but file-level propagation is incomplete.
3. The PostgreSQL FTS fallback removal (F-001) requires coordinated edits across 14 active-tier files — contract language is ready, file-level propagation is incomplete.

---

## Change Categories

| Category | Files Modified | Files Created | Files Deleted |
|----------|----------------|---------------|---------------|
| Search/Projection contracts (NEW) | 2 canonical | 0 | 0 |
| Ingestion/Trust contracts (NEW) | 2 canonical | 0 | 0 |
| PostgreSQL FTS fallback removal | 9 active-tier | 0 | 0 |
| HMAC approval → two-stage trust | 1 canonical | 0 | 0 |
| Projection event architecture | 2 canonical | 0 | 0 |
| TYPESENSE-001 registry | 1 canonical | 0 | 0 |
| cut_off_latest removal | 3 product-experience | 0 | 0 |
| Governance status normalization | 4 product-experience | 0 | 0 |
| Fortify/Shield version fixes | 2 canonical | 0 | 0 |
| RBAC self-approval prevention | 1 canonical | 0 | 0 |
| Migration contract promotion | 1 canonical | 0 | 0 |
| SEO contracts (5 new) | 1 canonical | 0 | 0 |
| Queue policy contract | 1 canonical | 0 | 0 |
| Cache/perf/FVS/governance contracts | 2 canonical | 0 | 0 |
| New tables (projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects) | 1 canonical | 0 | 0 |
| Archive labeling formalization | 1 archive | 0 | 0 |
| **TOTAL** | **~18 unique files modified** (some files touched by multiple categories) | 0 | 0 |

---

## Detailed Change List

### 1. README.md

| Section | Change | Driver |
|---------|--------|--------|
| §"Mandated Technology Stack" row "PostgreSQL" | Remove "FTS fallback search" from purpose column. New: "Primary data store (authoritative); admin/internal search via FTS infrastructure" | SEARCH-001, F-001 |
| §"Hard Constraints" "Search V1" | Remove "PostgreSQL FTS is fallback/admin search." New: "Typesense is the sole V1 public discovery/search engine (per SEARCH-001). There is no PostgreSQL public-search fallback. Admin/internal search may use PostgreSQL FTS directly." | SEARCH-001, F-001 |
| §"Hard Constraints" "Fortify" row | Already correct (^1.x); no change. | DEC-005 |
| §"Package Directory Structure" "FIRST-VERTICAL-SLICE-UX.md" line | Remove "(PostgreSQL FTS fallback)" parenthetical. New: "UX spec (Typesense V1, slug URLs, outage contract per OUTAGE-001)" | SEARCH-001, F-001 |
| §"Package Directory Structure" "DISCOVERY-CLOSURE.md" line | Remove "(Typesense V1 — PostgreSQL FTS fallback)". New: "(Typesense V1 sole public search; PostgreSQL for admin/internal)" | SEARCH-001, F-001 |
| §"Authority Hierarchy" "Tier 1" row | No change. | — |
| §"Key Domain Model Decisions" | No change. | — |

### 2. GLOSSARY.md

| Section | Change | Driver |
|---------|--------|--------|
| "PostgreSQL FTS" entry (line 124) | Replace "Maintained as fallback search capability when Typesense is unavailable, and for admin search." with "PostgreSQL full-text search infrastructure (tsvector + GIN indexes). Used for admin/internal search (per SEARCH-001). NOT used as a public-search fallback — Typesense is the sole V1 public search engine; Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001." | SEARCH-001, OUTAGE-001, F-001 |
| "InstitutionStatus" entry | Pending DEC-012 user approval. If approved: replace "Closed" with "Discontinued". | LIFE-001, F-012 |

### 3. 00-ORIENTATION/AUTHORITY-HIERARCHY.md

| Section | Change | Driver |
|---------|--------|--------|
| Tier 4 "Discovery Closure" row (line 68) | Remove "(PostgreSQL FTS as fallback/admin)". New: "Discovery closure record; Typesense established as V1 sole public search engine; PostgreSQL for admin/internal search and canonical browse/detail" | SEARCH-001, F-001 |
| §"V4.6 Key Decisions That Must Propagate" item 7 (line 97) | Remove "PostgreSQL FTS fallback". New: "Search V1: Typesense is the sole public discovery/search engine (SEARCH-001); no PostgreSQL public-search fallback; PostgreSQL is for admin/internal search and canonical browse/detail (04-architecture.md)" | SEARCH-001, F-001 |
| §"V4.6 ARBITRATION-FINAL Key Decisions That Must Propagate" item 18 (line 113) "Typesense fallback UX" | Rewrite from "When Typesense unavailable, basic facets remain functional via PostgreSQL query-builder; advanced/instance-scoped filters (Campus, Delivery Mode, Admission Status) are DISABLED; UI shows 'Advanced filters temporarily unavailable.'" to "When Typesense unavailable, primary public search returns an explicit unavailable/search-failure state per OUTAGE-001. Canonical browse/detail pages (PostgreSQL) remain available. Optional search-powered components fail closed or are omitted. A legitimate zero-result search is NOT a degraded-state error." | OUTAGE-001, F-042 |

### 4. canonical/01-business.md — NO CHANGE

### 5. canonical/02-decisions.md

| Section | Change | Driver |
|---------|--------|--------|
| ADR-6 "Search Engine Selection" (line 237) | Replace "PostgreSQL FTS is maintained as a secondary search capability for admin search and as a fallback when Typesense is unavailable. Scout driver is Typesense for V1; `database` driver available for fallback." with "PostgreSQL FTS infrastructure is maintained for admin/internal search ONLY (per SEARCH-001). Typesense is the sole V1 public discovery/search engine; there is no PostgreSQL public-search fallback. Scout driver is Typesense for V1. The `database` Scout driver is NOT used as a fallback for public search." | SEARCH-001, F-001 |
| ADR-6 §"Search Engine Selection (Typesense vs PostgreSQL FTS)" (line 611-613) | Replace "Typesense is the V1 search engine. PostgreSQL FTS serves as fallback and admin search." with "Typesense is the sole V1 public discovery/search engine (SEARCH-001). PostgreSQL FTS is used for admin/internal search ONLY (per V4.7 §12). There is no PostgreSQL public-search fallback (per V4.7 §12, §13)." | SEARCH-001, F-001 |
| ADR for PostgreSQL (line 459) | Remove "advanced full-text search capabilities (maintained as a secondary search capability per ADR-6 for admin search and fallback)". New: "PostgreSQL 16 or later is the canonical database. It provides native JSON indexing for VO columns, robust polymorphic relationship support, and strong data integrity constraints. PostgreSQL FTS infrastructure (tsvector + GIN indexes) is used for admin/internal search ONLY (per SEARCH-001)." | SEARCH-001, F-001 |
| ADR statuses | Normalize all ADR status fields to V4.7 §63 taxonomy: PROPOSED, APPROVED, FROZEN, DEFERRED, SUPERSEDED, REOPENED, REJECTED. | GOV-002, F-027 |
| New §Frozen-Decision Challenge Protocol section | Add GOV-004 contract language. | GOV-004, F-030 |
| New §External-Fact Policy section | Add GOV-005 contract language. | GOV-005, F-031 |
| New §Narrative Duplication Policy section | Add GOV-006 contract language. | GOV-006, F-032 |

### 6. canonical/03-domain.md

| Section | Change | Driver |
|---------|--------|--------|
| InstitutionStatus enum (line TBD) | Pending DEC-012 user approval. If approved: replace "Closed" with "Discontinued". | LIFE-001, F-012 |
| ProgrammeStatus enum | Pending DEC-035 user approval. If approved (Option A): keep as-is; document mapping to V4.7 §50 matrix in SEO-001. | LIFE-001, F-035 |

### 7. canonical/04-architecture.md

| Section | Change | Driver |
|---------|--------|--------|
| §1 Architectural Principles P9 (line 27) | Remove "PostgreSQL FTS is available as a degraded fallback if Typesense is unavailable". New: "PostgreSQL FTS is used for admin/internal search ONLY; Typesense is the sole V1 public search engine; Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001." | SEARCH-001, OUTAGE-001, F-001 |
| §2 Technology Stack "Laravel Fortify" row (line 52) | Change "^13.0" to "^1.0". | DEC-005, F-005 |
| §2 Technology Stack "bezhansalleh/filament-shield" row (line 59) | Pending DEC-006 external verification. Likely change "v3" to "^3.0" with explicit Filament v5 compatibility note. | DEC-006, F-006 |
| §2 Technology Stack "Laravel Scout" row (line 67) | Remove "`database` driver (PostgreSQL FTS) available as degraded fallback". New: "Search abstraction (built-in); Typesense driver for V1 public search. The `database` driver is NOT used as a public-search fallback." | SEARCH-001, F-001 |
| §2 Canonical Stack Summary line 78 | Remove "with PostgreSQL FTS fallback". New: "Search: Typesense (V1) — sole public discovery engine; PostgreSQL FTS for admin/internal only" | SEARCH-001, F-001 |
| §3 Application Architecture line 139 | Remove "(Scout abstraction — Typesense driver for V1, PostgreSQL FTS fallback)" from UpdateSearchIndex comment. New: "UpdateSearchIndex (projection event pathway per PROJECTION-001; Typesense is the sole V1 public search engine)" | PROJECTION-001, F-002 |
| §6 Read Model (line 273) | Rewrite paragraph: remove "If Typesense goes down, the application falls back to PostgreSQL FTS with degraded search (no typo tolerance, limited faceting)." Replace with: "If Typesense goes down, the public search surface returns an explicit unavailable/search-failure state per OUTAGE-001. Canonical browse/detail pages (PostgreSQL) remain available. PostgreSQL FTS (tsvector + GIN indexes) is used for admin/internal search only." | OUTAGE-001, F-001, F-042 |
| §6 Read Model table line 281 | Remove "Search fallback | PostgreSQL FTS + GIN indexes | Degraded search (no typo tolerance, limited faceting); admin search | Generated tsvector columns always consistent with row data" row entirely. | SEARCH-001, F-001 |
| §6 Read Model table line 294 | Remove "with **PostgreSQL FTS fallback**" from "Search results / faceted lists" row. New: "Typesense (V1) — sole public search" | SEARCH-001, F-001 |
| §6 line 298 | Remove "PostgreSQL FTS is maintained as a fallback for degraded search when Typesense is unavailable, and serves admin search directly." Replace with: "PostgreSQL FTS is used for admin/internal search only. Public search outages produce an explicit unavailable/search-failure state per OUTAGE-001." | SEARCH-001, OUTAGE-001, F-001 |
| §6 line 309 | Remove "Advanced/instance-scoped filters (Campus, Delivery Mode, Admission Status) are DISABLED — PostgreSQL FTS cannot enforce same-element nested semantics." Replace with: "When Typesense is unavailable per OUTAGE-001, the primary public search surface is unavailable. No silent switch to PostgreSQL occurs." | OUTAGE-001, F-042 |
| §"PostgreSQL FTS Fallback Implementation" subsection (line 334-343) | DELETE entire subsection. Replace with: "## PostgreSQL FTS Implementation (Admin/Internal Only)\n\nPostgreSQL FTS infrastructure (tsvector + GIN indexes) is used for admin/internal search ONLY per SEARCH-001. It is NOT a public-search fallback. Implementation details:\n- tsvector columns: `search_vector` GENERATED ALWAYS STORED column on `programmes` and `institutions` tables (V1 surface — `scholarships` is Phase 2 per V4.6 §4.24).\n- pg_trgm GIN indexes for admin autocomplete.\n- Admin search uses `to_tsvector` + `plainto_tsquery` + `ts_rank_cd`.\n- Public search uses Typesense exclusively per SEARCH-001." | SEARCH-001, F-001 |
| §6 line 396 | Change "Admin search uses PostgreSQL FTS directly and includes all entities regardless of publication status." Keep this; it is correct per SEARCH-001 (admin/internal search uses PostgreSQL). | — |
| §6 line 475 | Remove "Typesense outages fall back to PostgreSQL FTS. PostgreSQL FTS outages do not affect SEO (server-rendered Blade still renders)." Replace with: "Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001 (no silent switch to PostgreSQL). PostgreSQL FTS outages do not affect SEO (server-rendered Blade still renders)." | OUTAGE-001, F-001 |
| §6 line 501 | Remove "(Typesense V1, PostgreSQL FTS fallback)" from IsSearchable trait description. New: "Scout integration for search projection (Typesense V1)" | SEARCH-001, F-001 |
| §6 line 727 | Change "Typesense geo filter (V1) / PostgreSQL FTS geo filter (fallback)" to "Typesense geo filter (V1). PostgreSQL FTS is admin-only; no public fallback per SEARCH-001." | SEARCH-001, F-001 |
| §6 line 757 | Remove "PostgreSQL FTS tsvector maintained for fallback" from "Search projection sync" row. New: "Search projection sync | Projection event pathway (PROJECTION-001): canonical mutation + projection_event + projection_event_targets commit atomically → projection worker materializes ProjectionInput under REPEATABLE READ → applies to Typesense → records APPLIED in projection_states (per PROJECTION-001 through PROJECTION-017)" | PROJECTION-001, F-002 |
| NEW §Typesense Outage Contract | Add OUTAGE-001 contract section. | OUTAGE-001, F-042 |
| NEW §SEO Lifecycle Matrix | Add SEO-001 contract section. | SEO-001, F-013 |
| NEW §SEO Indexability Registry | Add SEO-002 contract section. | SEO-002, F-014 |
| NEW §Sitemap Eligibility | Add SEO-003 contract section. | SEO-003, F-015 |
| NEW §Structured Data Contract | Add SEO-004 contract section. | SEO-004, F-016 |
| NEW §URL Redirect Contract | Add SEO-005 contract section. | SEO-005, F-017 |
| NEW §Cache Contract | Add CACHE-001 contract section. | CACHE-001, F-024 |
| NEW §Performance Contract | Add PERF-001 contract section. | PERF-001, F-025 |
| NEW §FVS Boundary | Add FVS-001 contract section. | FVS-001, F-026 |
| NEW §Projection Event Architecture | Add PROJECTION-001 through PROJECTION-017 contract sections (or reference to canonical/05-implementation.md §8.5). | PROJECTION-001 through PROJECTION-017, F-002 |

### 8. canonical/05-implementation.md

| Section | Change | Driver |
|---------|--------|--------|
| §2 package table line 51 | Remove "`database` driver (PostgreSQL FTS) available as fallback" from Laravel Scout row. New: "Search driver abstraction; Typesense driver for V1 public search" | SEARCH-001, F-001 |
| §2 package table line 49 | Change "laravel/fortify | ^1.0" (already correct). | DEC-005 |
| §2 package table line 1322 | Pending DEC-006: change "^5.0" to verified version (likely ^3.0). | DEC-006, F-006 |
| §3 folder structure line 104 | Remove "PostgreSQL FTS fallback" from Search/ comment. New: "Search/ (Scout config, UpdateSearchIndex listener; Typesense V1 public search; projection event pathway per PROJECTION-001)" | SEARCH-001, PROJECTION-001, F-001, F-002 |
| §4 schema line 346 | Remove "Maintained as fallback for admin search and degraded-mode search when Typesense is unavailable." Replace with: "Maintained for admin/internal search ONLY per SEARCH-001; NOT a public-search fallback." | SEARCH-001, F-001 |
| §4 schema line 348 | Change "Typesense provides primary autocomplete in V1." (keep) and remove "as a fallback autocomplete when Typesense is unavailable." New: "pg_trgm GIN indexes for admin autocomplete ONLY. Typesense provides public autocomplete in V1 per SEARCH-001." | SEARCH-001, F-001 |
| §4 schema line 354 (programmes table) | The "search_vector" column description is acceptable (Generated tsvector for admin/internal search). Add note: "Used for admin/internal search ONLY per SEARCH-001; NOT a public-search fallback." | SEARCH-001, F-001 |
| §5 RBAC section | Add RBAC-001 contract: "A user may not approve their own revision. Submitter cannot review or approve their own revision. Enforcement: PendingRevision.submitter_id ≠ approver_id; if equal, the approval action fails with 403." | RBAC-001, F-021 |
| §5 RBAC section | Add REV-001 contract: polymorphic validation, immutability after submission, lifecycle (draft/submitted/stale/conflict/approved/rejected/cancelled/superseded). | REV-001, F-033 |
| §4.6 Migration Dependencies | Promote to MIGR-001 contract. Add new tables to migration order: `projection_events`, `projection_event_targets`, `pending_projection_requests`, `projection_states`, `canonical_imports`, `url_redirects`, `admission_policies` (if not already present). Order: education_authorities → admission_cycles → accreditation_records; institutions → campuses → programmes → programme_instances → admission_policies → cut_off_marks; canonical_imports (independent); projection_events → projection_event_targets → projection_states → pending_projection_requests; url_redirects (independent). | MIGR-001, F-023 |
| §4 schema | Add new table schemas: `projection_events` (id, revision BIGINT UNIQUE, projection_type, created_at, payload JSONB), `projection_event_targets` (id, projection_event_id FK, projection_type, projection_id), `pending_projection_requests` (id, projection_type, projection_id UNIQUE, pending_revision, coalesced_at), `projection_states` (projection_type, projection_id, last_applied_projection_revision, lifecycle_state, terminal_revision, projection_contract_version, collection_generation, last_applied_fingerprint), `canonical_imports` (artifact_id, artifact_hash, schema_version, approval_id, approver_id, approved_at, execution_id, state, last_state_change_at, last_operator_id, replay_reason, original_execution_id), `url_redirects` (id, source_url_normalized UNIQUE, destination_url, http_status DEFAULT 301, created_at, retired_at). | PROJECTION-001, PROJECTION-002, PROJECTION-004, PROJECTION-010, INGEST-003, SEO-005 |
| §4 schema `admission_policies` table | Add UNIQUE constraint: `(programme_instance_id, admission_cycle_id, pathway)`. | UPSERT-001, F-037 |
| §8.0 idempotent upsert | Add UPSERT-001 contract: every ON CONFLICT target requires matching PostgreSQL UNIQUE/EXCLUSION constraint. | UPSERT-001, F-022 |
| §8.1 "PostgreSQL FTS Fallback" subsection (line 884-893) | DELETE entire subsection. Replace with: "## 8.1 PostgreSQL FTS Implementation (Admin/Internal Only)\n\nPostgreSQL FTS infrastructure is used for admin/internal search ONLY per SEARCH-001. It is NOT a public-search fallback. Typesense is the sole V1 public search engine per SEARCH-001." | SEARCH-001, F-001 |
| §8 line 869 | Remove "PostgreSQL FTS is maintained as a secondary search capability for admin search and as a fallback when Typesense is unavailable." Replace with: "PostgreSQL FTS infrastructure is used for admin/internal search ONLY per SEARCH-001." | SEARCH-001, F-001 |
| §8 line 882 | Remove "When Typesense is unavailable, Scout falls back to `database` driver. Admin search always uses PostgreSQL FTS directly". New: "Admin/internal search uses PostgreSQL FTS directly. When Typesense is unavailable, public search returns an explicit unavailable/search-failure state per OUTAGE-001 (no silent fallback)." | SEARCH-001, OUTAGE-001, F-001 |
| §8 line 906, 907 | Remove "PostgreSQL FTS fallback" from "Full-text search" and "Faceted navigation" rows. New: "Full-text search | Typesense (V1) | Sole public search engine" and "Faceted navigation | Typesense (V1) | Real-time faceting, filtering, sorting" | SEARCH-001, F-001 |
| §8 line 1148 | Remove "Admin search uses PostgreSQL FTS directly and includes all programmes regardless of publication status." Keep this (correct per SEARCH-001). | — |
| §8 line 1288 | Remove "Fallback: `database` driver with PostgreSQL FTS." New: "Laravel Scout v11. V1: Typesense driver (sole public search engine per SEARCH-001). The `database` Scout driver is NOT used as a public-search fallback. Each searchable model implements the `Searchable` interface via the `IsSearchable` trait..." | SEARCH-001, F-001 |
| §8 line 1373 | Change "Typesense geo filter (V1) / PostgreSQL FTS geo filter (fallback) handles location" to "Typesense geo filter (V1) handles public location search; PostgreSQL FTS geo filter is admin-only per SEARCH-001." | SEARCH-001, F-001 |
| §8 line 1423, 1443 | Remove "+ PostgreSQL FTS fallback" from Phase 1f search description. New: "1f (Search - Typesense V1 sole public search engine, depends on 1b + 1c + new projection event architecture per PROJECTION-001)" | SEARCH-001, PROJECTION-001, F-001 |
| §8 line 1479 | Remove "PostgreSQL FTS fallback provides degraded search; Typesense restart recovers" risk row. Replace with: "Typesense availability | Medium | Public search returns explicit unavailable state per OUTAGE-001; canonical browse/detail (PostgreSQL) remain available; Typesense restart recovers public search" | OUTAGE-001, F-001 |
| §8 line 1484 | Remove "PostgreSQL FTS is fallback only" from forbidden-actions list. New: "bypass Typesense for public search (Typesense is the sole V1 public search engine per SEARCH-001; there is no PostgreSQL public-search fallback; PostgreSQL FTS is admin/internal only)" | SEARCH-001, F-001 |
| §8 line 1507 trailing summary | Remove "Generated columns: search_vector (tsvector) on programmes, institutions (V1), scholarships (Phase 2 — created but not exercised in V1 per V4.6 §4.24) with GIN indexes. pg_trgm GIN indexes on institutions.name and programmes.name for autocomplete." Update to: "Generated columns: search_vector (tsvector) on programmes, institutions (V1) for ADMIN/INTERNAL search ONLY per SEARCH-001. pg_trgm GIN indexes for admin autocomplete." | SEARCH-001, F-001 |
| NEW §8.5 Projection Event Architecture | Add PROJECTION-001 through PROJECTION-017 contract sections with full schema for projection_events, projection_event_targets, pending_projection_requests, projection_states tables. Add SERIAL-001 contract. | PROJECTION-001 through PROJECTION-017, SERIAL-001, F-002, F-008 |
| NEW §8.6 TYPESENSE-001 Contract | Add full field registry (10 columns per field) + Programme Search Schema (17 field classes) + Admission Open Semantics + Programme Result Status + Cut-off Semantics. | TYPESENSE-001, F-007, F-010, F-043, F-044 |
| NEW §8.7 Trust Model | Add TRUST-001, TRUST-002 contract language. | TRUST-001, TRUST-002, F-003 |
| NEW §8.8 Import Atomicity | Add INGEST-001, INGEST-002, INGEST-003 contract language. | INGEST-001, INGEST-002, INGEST-003, F-004, F-019 |
| NEW §12 DEP-001 Contract | Add full 8-column dependency registry. | DEP-001, DEP-002, F-018 |
| NEW §12 QUEUE-001 Contract | Add QUEUE-001 contract SKELETON with V4.7 §57 mandated elements; concrete values marked [TBD] pending user approval. | QUEUE-001, F-009 |
| NEW §12 LIFE-001 Contract | Add LIFE-001 lifecycle vocabulary contract (pending DEC-012, DEC-035). | LIFE-001, F-012, F-035 |
| NEW §12 SRC-001, SRC-002 Contracts | Add source priority + admission policy precedence contracts. | SRC-001, SRC-002, F-034 |
| NEW §12 FVS-001 Contract | Add FVS boundary contract. | FVS-001, F-026 |

### 9. canonical/06-data-acquisition.md

| Section | Change | Driver |
|---------|--------|--------|
| §0 Trust-Boundary Amendment | No structural change; align with TRUST-001 two-stage model. | TRUST-001, F-003 |
| §7 Import Workflow | Rewrite to use INGEST-001 artifact-level atomicity (remove per-record atomicity language). Align state machine with INGEST-003 canonical_imports states. | INGEST-001, INGEST-003, F-004, F-019 |
| §9 Scheduling | No change. | — |
| §10 Required Packages | No change. | — |
| §11.1 ON CONFLICT targets | Add UPSERT-001 audit note: "Every ON CONFLICT target in this section has a matching PostgreSQL UNIQUE/EXCLUSION constraint per UPSERT-001." Add admission_policies to the list. | UPSERT-001, F-022, F-037 |
| §12 Integration | No change. | — |
| §13 Ingestion API Endpoint (line 567-610) | REWRITE: replace HMAC-shared-secret verification with two-stage trust model. New §13: "## 13. Ingestion API Endpoint (V4.7)\n\nThe PRODUCTION application exposes a single authenticated ingestion API endpoint that receives Approved Import Artifacts from the acquisition worker. This is the only legitimate crossing point of the trust boundary.\n\n**Endpoint:** `POST /api/imports/ingest` (authenticated)\n\n**Authentication:** Laravel Sanctum token with `import:ingest` scope. The token is issued to a dedicated service account representing the acquisition worker. The acquisition worker's `.env` contains ONLY this token; it does NOT contain production DB credentials.\n\n**Two-stage trust model (per TRUST-001):**\n  Stage 1 (acquisition env): HMAC or mTLS between acquisition worker and ingestion API for transport integrity ONLY. This is NOT the approval signature.\n  Stage 2 (production control plane): Independent human approval via Filament v5 resource (Fortify 2FA required). The signed approval binds {artifact ID, artifact hash, artifact/schema version, approval action, approver identity, approval timestamp}. The signing private key is held ONLY by the production control plane.\n\n**Request body:** The signed Approved Import Artifact JSON manifest (same fields as V4.6 §13 + approval_signature field).\n\n**Server-side processing:**\n  1. Verify transport HMAC signature (Stage 1 — transport integrity only).\n  2. Verify Sanctum token scope.\n  3. Look up matching approval record by artifact_hash in `canonical_imports` (state = APPROVED per INGEST-003). If no matching APPROVED record exists, reject with 403.\n  4. Verify approval signature using production control plane's public key.\n  5. Enqueue `ApprovedArtifactIngestionJob` on the `imports` queue.\n  6. Return 202 Accepted with the batch_id.\n  7. The `ApprovedArtifactIngestionJob` runs `ApplicationJob::handle()` as described in §7.1.\n\n**Rate limiting:** 1 request per second per source IP. Sanity cap: 1000 records per artifact.\n\n**Failure modes:**\n  - Invalid transport signature → 401 Unauthorized; acquisition worker must re-sign.\n  - Invalid token → 403 Forbidden.\n  - No matching APPROVED record in canonical_imports → 403 Forbidden (artifact not approved by human approver).\n  - Invalid approval signature → 403 Forbidden (forged approval).\n  - Validation failure of any blocking record → entire artifact rejected (per INGEST-001); zero canonical records committed." | TRUST-001, INGEST-001, INGEST-003, F-003, F-004 |
| §14 Code-Sharing Does Not Equal Trust-Sharing | Add note: "Per TRUST-001, the acquisition environment MUST NOT possess the private approval signing credential. The signing key is held ONLY by the production control plane (admin/Filament)." | TRUST-001, F-003 |

### 10. governance/DISCOVERY-CLOSURE.md

| Section | Change | Driver |
|---------|--------|--------|
| Line 7 | Remove "PostgreSQL FTS is available as fallback for admin search and degraded mode." Replace with: "Typesense is the sole V1 public search engine (per SEARCH-001); PostgreSQL FTS is for admin/internal search only; Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001." | SEARCH-001, OUTAGE-001, F-001 |
| Line 44, 381, 382, 500, 549-552 | Pending DEC-012 user approval: if approved, replace "Closed" with "Discontinued" in InstitutionStatus enum references. | LIFE-001, F-012 |

### 11. governance/CANONICAL-CONSISTENCY-AUDIT.md — NO CHANGE (V4.6 already corrected)

### 12. governance/CANONICAL-UPDATE-REPORT.md — NO CHANGE (V4.6 already corrected)

### 13. governance/FOUNDATIONAL-DECISIONS-BRIEF.md — NO CHANGE (V4.6 already annotated)

### 14. governance/ADVERSARIAL-DECISION-REVIEW.md — NO CHANGE

### 15. governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md — NO CHANGE

### 16. governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md — NO CHANGE

### 17. governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md — NO CHANGE

### 18. governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md — NO CHANGE

### 19. product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md

| Section | Change | Driver |
|---------|--------|--------|
| Line 4 (Status) | Change "DISCOVERY ONLY — awaiting human approval" to "FROZEN — V4.6/V4.7 documentation baseline (see MANIFEST.md). Tier-2 product-experience material conforms to canonical; ADRs and contracts in canonical/ are authoritative." | GOV-001, F-011 |
| Line 7 | Remove "PostgreSQL FTS is available as fallback for admin search and degraded mode. All search functionality in V1 is served by Typesense; PostgreSQL FTS + pg_trgm + GIN indexes provide the fallback search capability." Replace with: "Typesense is the sole V1 public search engine (per SEARCH-001); PostgreSQL FTS is for admin/internal search only; Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001." (Note: this line is in product-experience/FIRST-VERTICAL-SLICE-UX.md, not DISCOVERY — see below. The DISCOVERY file may not have this line. Verify and remediate accordingly.) | SEARCH-001, F-001 |

### 20. product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md

| Section | Change | Driver |
|---------|--------|--------|
| Line 4 (Status) | Change "UX DISCOVERY — awaiting human approval" to "FROZEN — V4.6/V4.7 documentation baseline." | GOV-001, F-011 |
| Line 1152 | Remove "`cut_off_latest`" from "Typesense: `tuition_min`, `tuition_max`, `cut_off_latest` on programme document". New: "Typesense: `tuition_min`, `tuition_max` on programme document; cut-off is contextual nested `instances[].cut_off` per TYPESENSE-001 §Cut-off Semantics" | TYPESENSE-001, F-010 |
| Line 1179 | Remove "`cut_off_latest` | CutOffMark (latest) | int32 | Sort + display" row entirely. | TYPESENSE-001, F-010 |
| Line 1211 | Remove "cut_off_latest" from "Computed/derived attributes (is_admission_open, programme_count, cut_off_latest)". New: "Computed/derived attributes (is_admission_open, programme_count)" | TYPESENSE-001, F-010 |
| Line 1689 | Remove "cut_off_latest" from "is_admission_open, tuition_min, tuition_max, cut_off_latest". New: "is_admission_open, tuition_min, tuition_max" | TYPESENSE-001, F-010 |
| Line 820 "## 12.2 Closed / Suspended Institution" | Pending DEC-012: if approved, rename to "## 12.2 Discontinued / Suspended Institution". | LIFE-001, F-012 |
| Lines 863-866 (ProgrammeStatus mapping) | Pending DEC-035: if approved (Option A), keep as-is; add cross-reference to SEO-001 lifecycle matrix mapping. | LIFE-001, F-035 |

### 21. product-experience/FIRST-VERTICAL-SLICE-UX.md

| Section | Change | Driver |
|---------|--------|--------|
| Line 4 (Status) | Change "UX DESIGN — awaiting human approval" to "FROZEN — V4.6/V4.7 documentation baseline." | GOV-001, F-011 |
| Line 7 | Remove "PostgreSQL FTS is available as fallback for admin search and degraded mode. All search functionality in V1 is served by Typesense; PostgreSQL FTS + pg_trgm + GIN indexes provide the fallback search capability." Replace with: "Typesense is the sole V1 public search engine (per SEARCH-001). PostgreSQL FTS is for admin/internal search only. Typesense outages produce an explicit unavailable/search-failure state per OUTAGE-001." | SEARCH-001, OUTAGE-001, F-001 |
| Line 361 | Remove "Sort by `cut_off_latest` ascending; nulls last". New: "Sort by `instances[].cut_off` (contextual nested; sort applies within matched instance subset per TYPESENSE-001 §Programme Result Status); nulls last" | TYPESENSE-001, F-010 |
| Line 362 | Same as 361 for descending. | TYPESENSE-001, F-010 |
| Line 1055 | Remove "`cut_off_latest` on programme document" row. New: "`instances[].cut_off` (contextual nested) on programme document | ✓ (T-03 approved; V4.7 §36 removed top-level cut_off_latest) | ✓ sort field (within matched instance subset) | No | —" | TYPESENSE-001, F-010 |
| Line 752 | Pending DEC-012: if approved, change "status NOT IN (Discontinued, Closed, Withdrawn, Expired)" to "status NOT IN (Discontinued, Withdrawn, Expired)" (remove Closed). | LIFE-001, F-012 |
| Line 757 "## 17.3 Discontinued/Closed Page Behavior" | Pending DEC-012: if approved, rename to "## 17.3 Discontinued Page Behavior". | LIFE-001, F-012 |
| Line 1065 "Lifecycle filtering (exclude Discontinued/Closed from public)" | Pending DEC-012: if approved, change to "Lifecycle filtering (exclude Discontinued from public)". | LIFE-001, F-012 |

### 22. product-experience/FIRST-VERTICAL-SLICE-UI.md

| Section | Change | Driver |
|---------|--------|--------|
| Line 4 (Status) | Change "VISUAL UI DESIGN — awaiting human approval" to "FROZEN — V4.6/V4.7 documentation baseline." | GOV-001, F-011 |
| Line 853 | Remove "cut_off_latest" from "Result card (full) | name, award_level, institution_name, institution_type, location, cut_off_latest, tuition, is_admission_open". New: "Result card (full) | name, award_level, institution_name, institution_type, location, tuition, is_admission_open, contextual cut-off from matched instance per TYPESENSE-001" | TYPESENSE-001, F-010 |
| Line 866 | Remove "cut_off_latest" from "Sort by cut-off/tuition | cut_off_latest, tuition_min/max". New: "Sort by cut-off/tuition | instances[].cut_off (contextual), tuition_min/max" | TYPESENSE-001, F-010 |

### 23. MANIFEST.md

| Section | Change | Driver |
|---------|--------|--------|
| Header status line | Add V4.7 remediation note. | — |
| §4.30 "Typesense fallback UX" | Rewrite per OUTAGE-001. | OUTAGE-001, F-042 |
| File Inventory | No file count change (still 57 files). All SHA-256 hashes will need recomputation after file edits. | — |
| NEW §V4.7 Remediation Summary section | Add summary of V4.7 changes. | — |

### 24. V4.2-REMEDIATION-REPORT.md — NO CHANGE (historical document; archive-eligible but currently in root)

### 25. PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md — NO CHANGE (historical baseline report)

### 26. archive/* (31 files) — NO CHANGE (properly labeled historical per ARCHIVE-001)

---

## Files NOT Modified (no findings or findings are acceptable)

- canonical/01-business.md (no findings)
- canonical/03-domain.md (only pending DEC-012, DEC-035 user decisions)
- All 31 archive/* files (Tier 6 Historical per ARCHIVE-001)
- V4.2-REMEDIATION-REPORT.md (historical; references to PostgreSQL FTS fallback are in past-tense context describing V4.2-era state)
- PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md (historical baseline report)
- governance/CANONICAL-CONSISTENCY-AUDIT.md (V4.6 already corrected)
- governance/CANONICAL-UPDATE-REPORT.md (V4.6 already corrected)
- governance/FOUNDATIONAL-DECISIONS-BRIEF.md (V4.6 already annotated)
- governance/ADVERSARIAL-DECISION-REVIEW.md (no findings)
- governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md (no findings)
- governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md (no findings)
- governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md (no findings)
- governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md (no findings)

---

## Change Sequencing (per V4.7 §69 Required Execution Order)

The changes above MUST be applied in the following order to maintain coherence:

1. **Phase 1 — Inventory (DONE):** 57 files inventoried, authority map complete.
2. **Phase 2 — Finding graph (DONE):** 47 findings mapped in Finding Ledger.
3. **Phase 3 — Dependency/package contract:** Apply DEP-001, DEP-002; fix Fortify version (DEC-005); BLOCKED on filament-shield version (DEC-006 requires external verification).
4. **Phase 4 — Database/migration contract:** Promote MIGR-001; add new table schemas (projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects); add admission_policies UNIQUE constraint (UPSERT-001, DEC-037).
5. **Phase 5 — Ingestion/trust contract:** Rewrite canonical/06-data-acquisition.md §13 (TRUST-001 two-stage model); add INGEST-001, INGEST-002, INGEST-003 contracts.
6. **Phase 6 — Projection/search contract:** Add PROJECTION-001 through PROJECTION-017 contracts; add TYPESENSE-001 contract; remove cut_off_latest; add SERIAL-001; add OUTAGE-001; rewrite canonical/04-architecture.md and canonical/05-implementation.md search sections.
7. **Phase 7 — SEO:** Add SEO-001 through SEO-005 contracts.
8. **Phase 8 — RBAC:** Add RBAC-001 self-approval prevention; add REV-001 pending revisions contract.
9. **Phase 9 — FVS boundary:** Add FVS-001 contract.
10. **Phase 10 — Governance normalization:** Normalize product-experience status (GOV-001); normalize ADR statuses (GOV-002); add GOV-003, GOV-004, GOV-005, GOV-006, GOV-007, ARCHIVE-001 contracts.

**BLOCKERS:**
- DEC-006 (filament-shield version) — BLOCKED on external Packagist verification.
- DEC-009 (QUEUE-001 concrete values) — BLOCKED on user approval.
- DEC-012 (InstitutionStatus::Closed replacement) — BLOCKED on user approval.
- DEC-035 (ProgrammeStatus reconciliation) — BLOCKED on user approval.

These 4 blockers prevent 12 file-level changes from being applied. All other changes can be applied mechanically once the remediation agent has execution time.

---

## Verification of Changes

Each change will be verified by:
1. **Grep assertions** (CI): zero matches for prohibited patterns in active-tier files.
2. **Schema assertions** (CI): new tables exist with correct constraints.
3. **Scenario tests**: 36 scenarios per V4.7 §72.
4. **Final adversarial audit**: first-principles re-audit per V4.7 §73.
5. **Two-engineer simulation**: per V4.7 §74.

See deliverables #10 (Regression Verification Report), #11 (Scenario Verification Report), #12 (Final Audit Report), #16 (Implementation Determinism Report).

---

*End of Change Manifest. ~18 unique files require modification; 4 changes are BLOCKED on user decisions; full propagation requires Phase 1-10 execution.*
