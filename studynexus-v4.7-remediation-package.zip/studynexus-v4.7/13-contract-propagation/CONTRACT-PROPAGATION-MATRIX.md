# StudyNexus V4.6 → V4.7 — Contract Propagation Matrix

**Document:** 13 — Contract Propagation Matrix (V4.7 §76 item 7, §71)
**Date:** 2026-08-26

This matrix shows, for every registered contract, which active-tier files must propagate the contract language and the current propagation status.

Per V4.7 §71: "For every registered contract: 1. identify its authoritative file/section; 2. search all package representations; 3. identify duplicates; 4. ensure duplicate representations reference rather than contradict; 5. check dependency graph; 6. verify affected scenarios; 7. record regression guard."

---

## Propagation Status Legend

- ✅ **PROPAGATED** — contract language is present in the authoritative file(s); no contradictions in other files.
- ⚠️ **PARTIAL** — contract language is present in authoritative file but contradicted or duplicated in other files.
- ❌ **NOT PROPAGATED** — contract language is not yet present in any file; V4.7 remediation required.
- 🔒 **BLOCKED** — contract propagation is blocked on user decision or external verification.
- 🆕 **NEW CONTRACT** — contract did not exist in V4.6; V4.7 adds it.

---

## Propagation Matrix

| Contract ID | Authoritative File(s) | Other Files That Must Reference | Propagation Status | Regression Guard |
|-------------|----------------------|--------------------------------|-------------------|------------------|
| CON-001 (INV-EI1) | canonical/05-implementation.md §4.10, canonical/06-data-acquisition.md §11.1 | README.md, GLOSSARY.md | ✅ PROPAGATED | CI schema assertion: partial UNIQUE INDEX exists |
| CON-002 (INV-PI1) | canonical/03-domain.md §10, canonical/05-implementation.md §4.3 | GLOSSARY.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md | ✅ PROPAGATED | CI schema assertion: UNIQUE on (programme, campus, delivery_mode, academic_year) |
| CON-003 (ProgrammeInstance Owns Admission) | canonical/03-domain.md §3 §10, canonical/05-implementation.md §4.3 | README.md, product-experience/* | ✅ PROPAGATED | CI schema assertion: programmes has no admission_requirements column |
| CON-004 (Publication Predicate) | canonical/04-architecture.md §6, canonical/05-implementation.md §8 | product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md | ✅ PROPAGATED | Scenario test S-7 |
| CON-005 (URL Contract) | canonical/04-architecture.md, canonical/05-implementation.md | product-experience/FIRST-VERTICAL-SLICE-UX.md | ✅ PROPAGATED | CI route audit: no public route contains UUID pattern |
| CON-006 (Pending Revisions Table) | canonical/05-implementation.md §4 | — | ✅ PROPAGATED | CI schema assertion |
| CON-007 (Auth Stack) | canonical/04-architecture.md §2, canonical/05-implementation.md §2 | README.md | ✅ PROPAGATED | CI composer audit: no laravel/breeze |
| CON-008 (Color System OKLCH) | product-experience/FIRST-VERTICAL-SLICE-UI.md | — | ✅ PROPAGATED | CI CSS audit: no HEX/HSL |
| SEARCH-001 🆕 | canonical/04-architecture.md (new §Search Architecture), canonical/05-implementation.md §8 | README.md, GLOSSARY.md, 00-ORIENTATION/AUTHORITY-HIERARCHY.md, canonical/02-decisions.md ADR-6, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md | ❌ NOT PROPAGATED | CI grep: zero matches for `PostgreSQL FTS.*fallback\|FTS fallback` in active-tier |
| OUTAGE-001 🆕 | canonical/04-architecture.md (new §Typesense Outage Contract), canonical/05-implementation.md §8 | MANIFEST.md §4.30, product-experience/FIRST-VERTICAL-SLICE-UX.md | ❌ NOT PROPAGATED | Scenario tests S-35, S-36 |
| PROJECTION-001 🆕 | canonical/05-implementation.md §8.5 (new), canonical/04-architecture.md §3 §6 | — | ❌ NOT PROPAGATED | CI schema: projection_events table exists with revision UNIQUE |
| PROJECTION-002 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI schema: projection_event_targets table exists |
| PROJECTION-003 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Scenario test S-14 |
| PROJECTION-004 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Scenario test S-12 |
| PROJECTION-005 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI static analysis: no DB reads in transformation |
| PROJECTION-006 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI assertion: builder returns complete document |
| PROJECTION-007 (= TYPESENSE-001) 🆕 | canonical/05-implementation.md §8.6 | — | ❌ NOT PROPAGATED | CI script: union of field dependencies == declared document dependencies |
| PROJECTION-008 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI test: irrelevant mutation → no Typesense write |
| PROJECTION-009 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI hash function test |
| PROJECTION-010 🆕 | canonical/05-implementation.md §8.5, canonical/05-implementation.md §4 (table schema) | — | ❌ NOT PROPAGATED | CI schema: projection_states table exists |
| PROJECTION-011 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI state machine test |
| PROJECTION-012 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Scenario test S-15 |
| PROJECTION-013 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Reconciliation job test |
| PROJECTION-014 🆕 | canonical/05-implementation.md §8.5, canonical/04-architecture.md §6 | — | ❌ NOT PROPAGATED | Scenario test S-10 |
| PROJECTION-015 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Scenario test S-17 |
| PROJECTION-016 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | Scenario tests S-17, S-18 |
| PROJECTION-017 🆕 | canonical/05-implementation.md §8.3.1 (verify), §8.5 | — | ⚠️ PARTIAL (V4.6 §8.3.1 has nested filter syntax per MANIFEST §71; verify completeness) | Scenario tests S-6, Case A/B/C/D-I |
| TYPESENSE-001 🆕 | canonical/05-implementation.md §8.6 (new) | canonical/04-architecture.md §6, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/FIRST-VERTICAL-SLICE-UI.md | ❌ NOT PROPAGATED | CI script: field registry assertion; grep: zero matches for cut_off_latest |
| SERIAL-001 🆕 | canonical/05-implementation.md §8.5 | — | ❌ NOT PROPAGATED | CI assertion: projection job class uses WithoutOverlapping |
| QUEUE-001 🆕 | canonical/05-implementation.md §12 (new) | canonical/04-architecture.md §2 | 🔒 BLOCKED on DEC-009 (concrete values) | CI assertion: config/queue.php matches QUEUE-001 values (once approved) |
| TRUST-001 🆕 | canonical/06-data-acquisition.md §13 (rewrite), canonical/05-implementation.md §5 (Filament approval resource) | — | ❌ NOT PROPAGATED | Scenario tests S-23, S-28 |
| TRUST-002 🆕 | canonical/06-data-acquisition.md §13, canonical/05-implementation.md §4 (canonical_imports table) | — | ❌ NOT PROPAGATED | Scenario test S-22 |
| INGEST-001 🆕 | canonical/06-data-acquisition.md §7, §13 | — | ❌ NOT PROPAGATED | Scenario tests S-19, S-20 |
| INGEST-002 🆕 | canonical/06-data-acquisition.md §7, canonical/05-implementation.md §4 | — | ❌ NOT PROPAGATED | Scenario test S-21 |
| INGEST-003 🆕 | canonical/05-implementation.md §4 (new canonical_imports table), canonical/06-data-acquisition.md §7 | — | ❌ NOT PROPAGATED | CI schema assertion; scenario tests S-21, S-22 |
| LIFE-001 🆕 | canonical/03-domain.md, canonical/05-implementation.md §4 | GLOSSARY.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md | 🔒 BLOCKED on DEC-012, DEC-035 | CI grep: zero matches for InstitutionStatus::Closed (post-remediation) |
| SEO-001 🆕 | canonical/04-architecture.md (new §SEO Lifecycle Matrix) | canonical/05-implementation.md (reference) | ❌ NOT PROPAGATED | CI assertion: matrix exists with 4 rows × 6 columns |
| SEO-002 🆕 | canonical/04-architecture.md (new §SEO Indexability Registry) | — | ❌ NOT PROPAGATED | CI assertion: no route is indexable unless listed in SEO-002 |
| SEO-003 🆕 | canonical/04-architecture.md (new §Sitemap Eligibility) | — | ❌ NOT PROPAGATED | CI sitemap generator output matches SEO-003 |
| SEO-004 🆕 | canonical/04-architecture.md (new §Structured Data Contract) | — | ❌ NOT PROPAGATED | CI structured-data validator per page type |
| SEO-005 🆕 | canonical/04-architecture.md (new §URL Redirect Contract), canonical/05-implementation.md §4 (url_redirects table) | — | ❌ NOT PROPAGATED | CI tests: redirect chain rejected; redirect loop rejected; source URL uniqueness |
| DEP-001 🆕 | canonical/05-implementation.md §12 (new §DEP-001 Contract) | canonical/04-architecture.md §2 (reference) | ❌ NOT PROPAGATED | CI composer audit + lockfile diff |
| DEP-002 🆕 | canonical/05-implementation.md §12 | — | ❌ NOT PROPAGATED | CI lockfile diff → Tier-appropriate verification |
| RBAC-001 🆕 | canonical/05-implementation.md §5 | — | ❌ NOT PROPAGATED | CI test: user submits PendingRevision, then attempts to approve own → 403 |
| UPSERT-001 🆕 | canonical/05-implementation.md §4 (schema), canonical/06-data-acquisition.md §11 | — | ❌ NOT PROPAGATED | CI migration test: every ON CONFLICT target has matching pg_constraint |
| MIGR-001 🆕 | canonical/05-implementation.md §4.6 (promote to contract) | — | ❌ NOT PROPAGATED | CI: php artisan migrate:fresh on empty DB succeeds |
| CACHE-001 🆕 | canonical/04-architecture.md (new §Cache Contract) | — | ❌ NOT PROPAGATED | CI test: canonical mutation → cache invalidation job → cache key absent |
| PERF-001 🆕 | canonical/04-architecture.md (new §Performance Contract), MANIFEST.md §4.33-4.34 | — | ❌ NOT PROPAGATED | CI grep: zero matches for sub-millisecond not adjacent to target/evidence |
| FVS-001 🆕 | canonical/04-architecture.md (new §FVS Boundary), MANIFEST.md §4.25 | — | ❌ NOT PROPAGATED | CI assertion: migration count for deferred domains = 0 |
| GOV-001 🆕 | product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/FIRST-VERTICAL-SLICE-UI.md (line 4 status each) | — | ❌ NOT PROPAGATED | CI grep: zero matches for `awaiting human approval` in active-tier |
| GOV-002 🆕 | canonical/02-decisions.md (ADR status normalization) | — | ❌ NOT PROPAGATED | CI grep: ADR status matches regex `^(PROPOSED\|APPROVED\|FROZEN\|DEFERRED\|SUPERSEDED\|REOPENED\|REJECTED)$` |
| GOV-003 🆕 | 01-finding-ledger/FINDING-LEDGER.md (this remediation implements it) | — | ✅ PROPAGATED (this ledger) | CI parse assertion |
| GOV-004 🆕 | canonical/02-decisions.md (new §Frozen-Decision Challenge Protocol) | — | ❌ NOT PROPAGATED | CI assertion: CHALLENGED status references explicit REOPEN DEC-xxx |
| GOV-005 🆕 | canonical/02-decisions.md (new §External-Fact Policy), 09-external-evidence/EXTERNAL-EVIDENCE-REGISTER.md | — | ⚠️ PARTIAL (External Evidence Register exists; canonical/02-decisions.md section not added) | CI assertion: External Evidence Register maintained |
| GOV-006 🆕 | canonical/02-decisions.md (new §Narrative Duplication Policy) | governance/, product-experience/ (all narrative docs) | ❌ NOT PROPAGATED | CI assertion: narrative docs do not contain executable values not in contracts |
| GOV-007 🆕 | 11-implementation-determinism/IMPLEMENTATION-DETERMINISM-REPORT.md (this remediation implements it) | — | ✅ PROPAGATED (this report) | Future remediations reproduce simulation |
| ARCHIVE-001 🆕 | archive/HISTORICAL-README.md (formalize as contract) | — | ⚠️ PARTIAL (existing labeling adequate; formalization pending) | CI assertion: every archive/ file has "Archived" in first 5 lines |
| REV-001 🆕 | canonical/05-implementation.md §4, §5 | — | ❌ NOT PROPAGATED | CI tests: immutability after submission; deleted target → 422 |
| SRC-001 🆕 | canonical/05-implementation.md §4 (information_sources.priority), canonical/06-data-acquisition.md | — | ❌ NOT PROPAGATED | Scenario tests S-25, S-26 |
| SRC-002 🆕 | canonical/03-domain.md, canonical/05-implementation.md §4, canonical/06-data-acquisition.md | — | ❌ NOT PROPAGATED | Scenario tests S-25, S-26 |

---

## Summary

| Status | Count |
|--------|-------|
| ✅ PROPAGATED | 10 (8 existing CON-* + GOV-003 + GOV-007) |
| ⚠️ PARTIAL | 3 (PROJECTION-017, GOV-005, ARCHIVE-001) |
| ❌ NOT PROPAGATED | 27 |
| 🔒 BLOCKED | 2 (QUEUE-001, LIFE-001) |
| **Total** | **42** (41 contracts in registry + 1 subsumed PROJECTION-007 = TYPESENSE-001) |

**27 contracts require propagation to active-tier files.** This is the primary mechanical work remaining.

---

## Propagation Priority (based on dependency graph and scenario test failures)

### Priority 1 — Critical (blocks 15+ scenarios)
1. SEARCH-001 + OUTAGE-001 (propagate together; affects 14 files)
2. PROJECTION-001 through PROJECTION-017 (propagate together; affects 2 canonical files extensively)
3. TYPESENSE-001 (propagate with PROJECTION-*; affects 4 files)
4. TRUST-001, TRUST-002, INGEST-001, INGEST-002, INGEST-003 (propagate together; affects canonical/06 + canonical/05)

### Priority 2 — High (blocks 5-10 scenarios)
5. SERIAL-001 (propagate with PROJECTION-*)
6. SEO-001 through SEO-005 (propagate together; affects canonical/04)
7. RBAC-001, REV-001 (propagate together; affects canonical/05 §5)
8. UPSERT-001 (affects canonical/05 §4 + canonical/06 §11)
9. MIGR-001 (affects canonical/05 §4.6; depends on all new table schemas)

### Priority 3 — Medium (blocks 1-4 scenarios)
10. SRC-001, SRC-002
11. CACHE-001
12. FVS-001
13. GOV-001, GOV-002, GOV-004, GOV-006
14. DEP-001, DEP-002

### Priority 4 — Low (operational / cosmetic)
15. PERF-001
16. ARCHIVE-001 (formalize existing adequate labeling)
17. LIFE-001 (BLOCKED on DEC-012, DEC-035)
18. QUEUE-001 (BLOCKED on DEC-009)

---

## Duplicate Representation Audit (per V4.7 §71 step 3-4)

For each registered contract, search all package representations for duplicates:

### SEARCH-001 duplicates
- V4.6 has 50+ references to "PostgreSQL FTS fallback" across 14 active-tier files (per F-001 evidence). These are NOT duplicates of SEARCH-001 (which forbids the fallback); they are CONTRADICTIONS that must be removed.
- Archive files (archive/19, 20, 21, 22, 23, 26) contain historical references — properly labeled; NOT duplicates per V4.7 §2.

### CON-001 (INV-EI1) duplicates
- canonical/05-implementation.md §4.10 and canonical/06-data-acquisition.md §11.1 both document the same unique constraint.
- These are NOT contradictions — they are cross-references. Acceptable per V4.7 §71 step 4 ("ensure duplicate representations reference rather than contradict").

### CON-003 (ProgrammeInstance Owns Admission) duplicates
- canonical/03-domain.md §3 §10 and canonical/05-implementation.md §4.3 both document AdmissionPolicy ownership.
- README.md and V4.2-REMEDIATION-REPORT.md also reference it.
- All references are consistent (no contradictions). Acceptable.

### TYPESENSE-001 (cut_off_latest) duplicates
- V4.6 has 8 references to `cut_off_latest` across 3 product-experience files (per F-010 evidence). These are NOT duplicates of TYPESENSE-001 (which removes cut_off_latest); they are CONTRADICTIONS that must be removed.

### All other contracts
- No duplicate representations found in active tier.
- Archive references are historical; not duplicates per V4.7 §2.

---

## Regression Guard Audit (per V4.7 §71 step 7)

Every registered contract has a regression guard listed in the Contract Registry (deliverable #3). The guards are:

| Guard Type | Count | CI Implementation |
|------------|-------|-------------------|
| CI grep assertion | 12 | Search active-tier files for prohibited patterns |
| CI schema assertion | 9 | Check pg_constraint for required constraints |
| CI migration test | 3 | `php artisan migrate:fresh` on empty DB |
| CI composer audit | 2 | Check composer.lock against DEP-001 |
| CI script assertion | 3 | Custom scripts (TYPESENSE-001 field registry, etc.) |
| Scenario test | 11 | 36 scenarios in deliverable #6 |
| CI state machine test | 2 | PROJECTION-011, INGEST-003 |
| CI route audit | 2 | CON-005, SEO-002 |
| CI CSS audit | 1 | CON-008 |
| CI parse assertion | 2 | GOV-003, GOV-007 |
| CI static analysis | 1 | PROJECTION-005 |
| CI sitemap generator | 1 | SEO-003 |
| CI structured-data validator | 1 | SEO-004 |
| Audit log assertion | 2 | GOV-004, GOV-005 |
| Reconciliation job test | 1 | PROJECTION-013 |
| CI hash function test | 1 | PROJECTION-009 |
| **Total regression guards** | **54** | |

All 54 regression guards are recorded in the Contract Registry. CI implementation is pending contract propagation.

---

*End of Contract Propagation Matrix. 42 contracts registered; 10 propagated; 27 require propagation; 3 partial; 2 blocked. 54 regression guards recorded.*
