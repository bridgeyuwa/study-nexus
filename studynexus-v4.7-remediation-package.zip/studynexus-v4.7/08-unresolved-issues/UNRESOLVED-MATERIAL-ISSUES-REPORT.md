# StudyNexus V4.6 → V4.7 — Unresolved Material Issues Report

**Document:** 08 — Unresolved Material Issues Report (V4.7 §76 item 13, §75)
**Date:** 2026-08-26

This report lists all material decisions that are NOT explicitly resolved by the V4.7 prompt and require user approval before remediation can be completed.

Per V4.7 §75: "If the final audit finds a material unresolved decision that is not explicitly resolved by this prompt: do not improvise; do not patch around it; do not declare GO; record the issue; identify affected contracts; propose options; stop affected remediation; continue safe unrelated mechanical work only. The user must resolve the new decision."

---

## Unresolved Material Decisions

### DEC-006 — filament-shield version constraint (EXTERNAL VERIFICATION REQUIRED)

```text
Decision ID: DEC-006
Origin: F-006 (finding)
Status: BLOCKED on external Packagist/GitHub verification
Affected contracts: DEP-001, DEP-002
Affected files: canonical/04-architecture.md line 59, canonical/05-implementation.md line 1322

Question: What is the canonical version constraint for bezhansalleh/filament-shield?

V4.6 contradiction:
  - canonical/04-architecture.md line 59 says v3
  - canonical/05-implementation.md line 1322 says ^5.0

Constraints:
  - Must be compatible with Filament v5, Laravel ^13.0, PHP ^8.5.
  - Must be a real Packagist package.

Viable options:
  - A: ^3.0 (canonical/04-architecture.md claim; filament-shield v3 line supports Filament v3 AND v5).
  - B: ^5.0 (canonical/05-implementation.md claim; may not exist on Packagist as of 2026-08-26).
  - C: Some other version determined by external verification.

Recommended option: A (^3.0) — most likely based on filament-shield's historical versioning pattern.

Verification required:
  1. Packagist URL: https://packagist.org/packages/bezhansalleh/filament-shield
  2. GitHub URL: https://github.com/bezhansalleh/filament-shield
  3. Confirm latest stable version compatible with Filament v5 + Laravel ^13.0 + PHP ^8.5.
  4. Record verification in External Evidence Register.

Impact if unresolved:
  - composer require will fail for whichever version is wrong.
  - Two engineers installing the package would get different results.
  - Implementation-determinism simulation FAILS for the dependency subsystem.

User action required: Verify externally and approve the correct version.
```

### DEC-009 — QUEUE-001 concrete values (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-009
Origin: F-009 (finding)
Status: BLOCKED on user approval of concrete values
Affected contracts: QUEUE-001
Affected files: canonical/05-implementation.md (new §12 QUEUE-001 section)

Question: What are the concrete class-specific values for QUEUE-001?

V4.7 §57 explicitly states: "The exact class-specific values must be those explicitly approved in the final QUEUE-001 contract, not invented by the remediation agent."

Constraints:
  - Redis-backed Laravel queues (no database queue alternative).
  - At minimum: bounded retries; exponential backoff with jitter; hard timeout; exception cap; failed-job retention; alerting; manual replay.

V4.7-mandated QUEUE-001 skeleton (contract language ready; values pending):
  - retries: [TBD]
  - backoff base: [TBD] seconds
  - backoff multiplier: [TBD]
  - jitter: [TBD] milliseconds
  - hard timeout: [TBD] seconds
  - exception cap: [TBD] exceptions
  - failed-job retention: [TBD] days
  - alerting threshold: [TBD]
  - alerting channel: [TBD]

Viable options:
  - A: Conservative values (retries=3, backoff=5s base * 2^n multiplier, jitter=500ms, timeout=60s, exception cap=5, retention=30 days, alert threshold=10 failed jobs/hour, channel=email).
  - B: Aggressive values (retries=5, backoff=2s base * 1.5^n multiplier, jitter=200ms, timeout=120s, exception cap=10, retention=90 days, alert threshold=20 failed jobs/hour, channel=Slack).
  - C: User-specified values.

Recommended option: A (conservative; safe defaults).

Impact if unresolved:
  - Two engineers would pick different retry/backoff values.
  - Implementation-determinism simulation FAILS for the queue subsystem.
  - Scenario tests S-12, S-15 (concurrent mutations, crash recovery) cannot be verified.

User action required: Approve concrete values or specify alternatives.
```

### DEC-012 — InstitutionStatus::Closed replacement (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-012
Origin: F-012 (finding)
Status: BLOCKED on user approval
Affected contracts: LIFE-001, SEO-001
Affected files: GLOSSARY.md, canonical/03-domain.md, canonical/05-implementation.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md

Question: Should V4.6 rename InstitutionStatus::Closed to align with V4.7 §49?

V4.7 §49: "Canonical lifecycle does not include ambiguous CLOSED. Do not reintroduce CLOSED as a generic substitute."

V4.6 InstitutionStatus: Provisional, Operational, Suspended, Closed.

Constraints:
  - V4.7 §49 forbids CLOSED as a generic substitute.
  - V4.7 §50 matrix uses ACTIVE / SUSPENDED / DISCONTINUED / DRAFT-UNPUBLISHED.
  - V4.7 §49 specifically discusses Programme lifecycle; whether the rule extends to Institution lifecycle is ambiguous.

Viable options:
  - A: Rename Closed → Discontinued (parallel to ProgrammeStatus; aligns with V4.7 §50 matrix).
  - B: Rename Closed → Inactive (less semantically loaded).
  - C: Keep Closed as institution-specific lifecycle state (defensible reading of V4.7 §49 as Programme-focused).

Recommended option: A (Discontinued) — safest; aligns with V4.7 §50 matrix vocabulary; preserves the "no longer operating" semantic without using forbidden CLOSED.

Impact if unresolved:
  - Two engineers would model Institution lifecycle differently.
  - Implementation-determinism simulation FAILS for the lifecycle subsystem.
  - SEO-001 matrix contract cannot be finalized.

User action required: Approve Option A, B, or C (or specify alternative).
```

### DEC-035 — ProgrammeStatus reconciliation with V4.7 §50 matrix (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-035
Origin: F-035 (finding)
Status: BLOCKED on user approval
Affected contracts: LIFE-001, SEO-001
Affected files: canonical/03-domain.md, canonical/05-implementation.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md (lines 863-866 ProgrammeStatus mapping)

Question: How should V4.6 ProgrammeStatus (Prospective, Admitting, Suspended, Discontinued) reconcile with V4.7 §50 matrix (ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED)?

V4.7 §49: "Use the existing relevant lifecycle concepts, including: ACTIVE, SUSPENDED, DISCONTINUED plus publication state. Do not resurrect a Programme-level ProgrammeStatus as though it were canonical admission truth."

V4.7 §50 matrix: 4 rows — ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED.

V4.6 ProgrammeStatus: 4 values — Prospective, Admitting, Suspended, Discontinued.
  - Prospective + Admitting both map to V4.7 ACTIVE.
  - V4.6 has no DRAFT/UNPUBLISHED enum value (relies on is_published=false).
  - Suspended → SUSPENDED (1:1).
  - Discontinued → DISCONTINUED (1:1).

Constraints:
  - V4.6 product-experience UX explicitly uses Prospective vs Admitting distinction (FIRST-VERTICAL-SLICE-UX.md:348-349: "[Open]" Admitting vs "[Not yet admitting]" Prospective).
  - V4.7 §49 says "Use the existing relevant lifecycle concepts" — the word "existing" suggests preservation is acceptable.
  - V4.7 §35 says "Do not resurrect a Programme-level ProgrammeStatus as though it were canonical admission truth" — ProgrammeStatus is editorial lifecycle, NOT applicant-facing admission truth (which is on ProgrammeInstance).

Viable options:
  - A: Keep V4.6 ProgrammeStatus enum as-is; document the mapping to V4.7 §50 matrix in SEO-001 contract.
    - Prospective or Admitting + is_published=true → ACTIVE
    - Suspended → SUSPENDED
    - Discontinued → DISCONTINUED
    - is_published=false → DRAFT/UNPUBLISHED
  - B: Rename ProgrammeStatus enum values to align with V4.7 §50 vocabulary (ACTIVE, SUSPENDED, DISCONTINUED) and use is_published for DRAFT/UNPUBLISHED. Loses Prospective/Admitting distinction.

Recommended option: A — preserves the V4.6 enum (which has semantic value in the Nigerian admission cycle context: Prospective = "not yet admitting"; Admitting = "currently accepting applications") and documents the mapping.

Impact if unresolved:
  - Two engineers would model Programme lifecycle differently.
  - Implementation-determinism simulation FAILS for the lifecycle subsystem.
  - SEO-001 matrix contract cannot be finalized.
  - Product-experience UX badges ([Open] vs [Not yet admitting]) depend on the decision.

User action required: Approve Option A or B (or specify alternative).
```

### DEC-040 — projection_events retention policy (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-040
Origin: FA-015 (final audit finding)
Status: BLOCKED on user approval
Affected contracts: PROJECTION-001
Affected files: canonical/05-implementation.md §8.5

Question: What is the retention policy for the projection_events table?

The projection_events table will grow indefinitely (one row per projection-affecting mutation). V4.7 §17 says "Do not impose a semantic fan-out cap" but does not address projection_events table growth.

Viable options:
  - A: Retain indefinitely (simple; storage cost grows; replay capability preserved).
  - B: Retain for N days after APPLIED (requires retention job; replay limited to N days).
  - C: Compact old events (merge consecutive events for the same projection identity; complex).

Recommended option: A (retain indefinitely) — storage is cheap; replay capability is valuable for crash recovery and audit.

Impact if unresolved:
  - Two engineers would implement different retention jobs.
  - Implementation-determinism simulation FAILS for the projection subsystem (operational aspect).

User action required: Approve Option A, B, or C (or specify alternative). If B, specify N.
```

### DEC-041 — canonical_imports retention policy (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-041
Origin: FA-017 (final audit finding)
Status: BLOCKED on user approval
Affected contracts: INGEST-003
Affected files: canonical/05-implementation.md §4

Question: What is the retention policy for the canonical_imports table?

The canonical_imports table will grow with each import artifact.

Viable options:
  - A: Retain indefinitely (audit history preserved).
  - B: Retain for N days after APPLIED (requires retention job).
  - C: Compact (merge replay executions into original; loses replay history).

Recommended option: A (retain indefinitely) — audit history is valuable for compliance.

Impact if unresolved:
  - Two engineers would implement different retention jobs.
  - Implementation-determinism simulation FAILS for the import subsystem (operational aspect).

User action required: Approve Option A, B, or C (or specify alternative). If B, specify N.
```

### DEC-042 — projection_states collection_generation update mechanism (USER APPROVAL REQUIRED)

```text
Decision ID: DEC-042
Origin: FA-019 (final audit finding)
Status: BLOCKED on user approval
Affected contracts: PROJECTION-010, PROJECTION-016
Affected files: canonical/05-implementation.md §8.5

Question: During collection cutover (v7→v8), how is projection_states.collection_generation updated?

projection_states has `collection_generation` column per PROJECTION-010. V4.7 §31 describes the rebuild/cutover process but does not specify when collection_generation is updated.

Viable options:
  - A: Update existing projection_states rows in place (collection_generation column advanced). Loses historical generation info.
  - B: Create new projection_states rows for the new generation; old rows retained as historical. Preserves history.

Recommended option: B (create new rows) — preserves history; aligns with the "retain previous known-good collection" principle in V4.7 §31.

Impact if unresolved:
  - Two engineers would implement different cutover mechanisms.
  - Implementation-determinism simulation FAILS for the collection versioning subsystem.
  - Scenario tests S-17, S-18 (collection rebuild) cannot be verified.

User action required: Approve Option A or B (or specify alternative).
```

---

## Summary of Unresolved Material Decisions

| Decision ID | Origin | Status | Recommended Option | Impact |
|-------------|--------|--------|-------------------|--------|
| DEC-006 | F-006 | External verification required | ^3.0 | Dependency subsystem |
| DEC-009 | F-009 | User approval required (concrete values) | Conservative defaults | Queue subsystem |
| DEC-012 | F-012 | User approval required | Discontinued (Option A) | Lifecycle subsystem |
| DEC-035 | F-035 | User approval required | Keep V4.6 enum + mapping (Option A) | Lifecycle subsystem |
| DEC-040 | FA-015 | User approval required | Retain indefinitely (Option A) | Projection operations |
| DEC-041 | FA-017 | User approval required | Retain indefinitely (Option A) | Import operations |
| DEC-042 | FA-019 | User approval required | Create new rows (Option B) | Collection versioning |

**Total: 7 unresolved material decisions.** All 7 require user action. None can be resolved by the remediation agent per V4.7 §68 ("invent architecture" prohibition) and §75 ("do not improvise; do not patch around it; do not declare GO").

---

## Safe Mechanical Work That Can Continue (per V4.7 §75 step 7)

The following remediation work does NOT depend on any of the 7 unresolved decisions and can proceed:

1. **PostgreSQL FTS fallback removal** (F-001) — SEARCH-001 contract is FROZEN; removal is mechanical across 14 active-tier files.
2. **HMAC approval → two-stage trust model** (F-003) — TRUST-001 contract is FROZEN; rewrite of canonical/06-data-acquisition.md §13 is mechanical.
3. **Per-record → artifact-level atomicity** (F-004) — INGEST-001 contract is FROZEN; rewrite of §13 failure modes is mechanical.
4. **Fortify version fix** (F-005) — DEC-005 is FROZEN; single-line fix in canonical/04-architecture.md.
5. **cut_off_latest removal** (F-010) — TYPESENSE-001 §Cut-off Semantics is FROZEN; removal is mechanical across 3 product-experience files.
6. **Governance status normalization** (F-011) — GOV-001 contract is FROZEN; status line updates are mechanical across 4 product-experience files.
7. **RBAC self-approval prevention** (F-021) — RBAC-001 contract is FROZEN; addition to canonical/05-implementation.md §5 is mechanical.
8. **Pending revisions lifecycle** (F-033) — REV-001 contract is FROZEN; addition to §5 is mechanical.
9. **Source priority + admission policy precedence** (F-034) — SRC-001, SRC-002 contracts are FROZEN; additions are mechanical.
10. **Projection event architecture** (F-002) — PROJECTION-001 through PROJECTION-017 contracts are FROZEN; addition of new §8.5 to canonical/05-implementation.md is mechanical (though extensive).
11. **TYPESENSE-001 field registry** (F-007) — contract is FROZEN; addition of new §8.6 is mechanical.
12. **All SEO contracts** (F-013 through F-017) — SEO-001 through SEO-005 contracts are FROZEN; additions to canonical/04-architecture.md are mechanical.
13. **All governance contracts** (GOV-002 through GOV-007, ARCHIVE-001) — contracts are FROZEN; additions are mechanical.
14. **Migration order completeness** (FA-002 through FA-013) — MIGR-001 contract is FROZEN; completion of migration order list is mechanical.
15. **Polymorphic invariant documentation** (FA-007, FA-008) — UPSERT-001 and REV-001 contracts are FROZEN; explicit invariant documentation is mechanical.

**Work that is BLOCKED:**
- Any file-level change that depends on DEC-006 (filament-shield version): 2 file changes in canonical/04-architecture.md and canonical/05-implementation.md.
- Any file-level change that depends on DEC-009 (QUEUE-001 values): QUEUE-001 contract section in canonical/05-implementation.md (skeleton can be added; values cannot).
- Any file-level change that depends on DEC-012 (InstitutionStatus::Closed): 6 file changes across GLOSSARY, canonical, governance, product-experience.
- Any file-level change that depends on DEC-035 (ProgrammeStatus): SEO-001 matrix contract section; product-experience ProgrammeStatus mapping.
- Any file-level change that depends on DEC-040, DEC-041, DEC-042: retention/cutover operational details in PROJECTION-001, INGEST-003, PROJECTION-010/016 contracts.

---

## Remediation Agent's Statement (per V4.7 §75)

I, the Remediation Executor, do **NOT** declare GO. I have:
1. Stopped the affected work (file-level changes that depend on the 7 unresolved decisions).
2. Recorded the issues (this report).
3. Identified affected contracts (DEP-001, QUEUE-001, LIFE-001, SEO-001, PROJECTION-001, INGEST-003, PROJECTION-010, PROJECTION-016).
4. Proposed options (each decision has 2-3 viable options with a recommended option).
5. Continued safe unrelated mechanical work (the 15 items listed above can proceed).
6. Did NOT declare GO.

The user must resolve the 7 decisions before remediation can be completed.

---

*End of Unresolved Material Issues Report. 7 decisions require user action. Remediation is BLOCKED on these 7 decisions; all other work can proceed mechanically.*
