# StudyNexus V4.6 → V4.7 Remediation Package — README

**Date:** 2026-08-26
**Remediation Agent:** Super Z (Remediation Executor and Verification Agent)
**Source:** StudyNexus V4.6 REMEDIATED PACKAGE (57 markdown files, 43,616 lines)
**Governance authority:** V4.6 → V4.7 Controlled Remediation & Independent Verification Prompt (81 sections)

## FINAL VERDICT: 🔴 NO-GO

22 unresolved Tier-1 findings; 7 user decisions required; 27 contracts require propagation to active-tier files.

---

## What This Package Contains

This directory contains the complete V4.7 remediation evidence package — 16 deliverables per V4.7 §76. Each deliverable is in its own subdirectory:

| # | Directory | Deliverable | Purpose |
|---|-----------|-------------|---------|
| 1 | `01-finding-ledger/` | FINDING-LEDGER.md | 47 findings with V4.7 §77 record format (22 Tier-1, 18 Tier-2, 7 Tier-3) |
| 2 | `02-decision-ledger/` | DECISION-LEDGER.md | 53 decisions with V4.7 §78 record format (35 FROZEN, 11 APPROVED, 4 PROPOSED, 2 DEFERRED) |
| 3 | `03-contract-registry/` | CONTRACT-REGISTRY.md | 41 registered contracts with V4.7 §79 record format (8 existing verified, 32 new, 1 proposed-skeleton) |
| 4 | `04-change-manifest/` | CHANGE-MANIFEST.md | Detailed file-by-file change list (16 files require modification) |
| 5 | `05-contract-diff/` | CONTRACT-DIFF.md | OLD (V4.6) vs NEW (V4.7) contract language for 12 critical changes |
| 6 | `06-scenario-tests/` | SCENARIO-VERIFICATION-REPORT.md | 36 scenarios simulated (6 PASS, 8 PARTIAL, 22 FAIL) |
| 7 | `07-final-audit/` | FINAL-AUDIT-REPORT.md | First-principles re-audit; 20 new findings discovered |
| 8 | `08-unresolved-issues/` | UNRESOLVED-MATERIAL-ISSUES-REPORT.md | 7 user decisions required before GO |
| 9 | `09-external-evidence/` | EXTERNAL-EVIDENCE-REGISTER.md | 14 external facts; 11 require fresh verification |
| 10 | `10-archive-contamination/` | ARCHIVE-CONTAMINATION-REPORT.md | 4 concerns audited; all FALSE-POSITIVE per V4.7 §2 |
| 11 | `11-implementation-determinism/` | IMPLEMENTATION-DETERMINISM-REPORT.md | Two-engineer simulation; 11 subsystems all diverge |
| 12 | `12-changed-file-inventory/` | CHANGED-FILE-INVENTORY.md | 16 files modified; 41 unchanged; 0 created/deleted |
| 13 | `13-contract-propagation/` | CONTRACT-PROPAGATION-MATRIX.md | 42 contracts; 10 propagated; 27 require propagation |
| 14 | `14-decision-graph/` | DECISION-DEPENDENCY-CONFLICT-GRAPH.md | Zero conflict edges; critical path documented |
| 15 | `15-regression-verification/` | REGRESSION-VERIFICATION-REPORT.md | 13 adversarial searches; 54 regression guards |
| 16 | `16-remediated-package/` | REMEDIATED-PACKAGE-SUMMARY.md | Master summary with GO/NO-GO verdict |

---

## How to Read This Package

### For the User (Decision-Maker)

1. **Read `16-remediated-package/REMEDIATED-PACKAGE-SUMMARY.md` first** — this is the executive summary with the GO/NO-GO verdict and what you need to do next.
2. **Read `08-unresolved-issues/UNRESOLVED-MATERIAL-ISSUES-REPORT.md`** — this lists the 7 decisions you must approve before remediation can be completed.
3. **Read `09-external-evidence/EXTERNAL-EVIDENCE-REGISTER.md`** — this lists the 11 external facts that require fresh verification (e.g., filament-shield version on Packagist).
4. Skim `01-finding-ledger/FINDING-LEDGER.md` to understand the scope of issues.

### For the Implementation Team

1. **Read `04-change-manifest/CHANGE-MANIFEST.md`** — this is the step-by-step guide for applying V4.7 remediations to V4.6 files.
2. **Read `03-contract-registry/CONTRACT-REGISTRY.md`** — this is the executable truth for each contract. Code against the contracts, not against V4.6 file content.
3. **Read `06-scenario-tests/SCENARIO-VERIFICATION-REPORT.md`** — these are the test cases your implementation must pass.
4. **Read `12-changed-file-inventory/CHANGED-FILE-INVENTORY.md`** — this lists every file:line:section that requires modification.
5. **Read `05-contract-diff/CONTRACT-DIFF.md`** — this shows OLD vs NEW contract language for the 12 most critical changes.

### For Future Auditors

1. **Read `07-final-audit/FINAL-AUDIT-REPORT.md`** — this is the first-principles re-audit (not just a diff against the V4.7 prompt).
2. **Read `11-implementation-determinism/IMPLEMENTATION-DETERMINISM-REPORT.md`** — this is the two-engineer simulation per V4.7 §74.
3. **Read `14-decision-graph/DECISION-DEPENDENCY-CONFLICT-GRAPH.md`** — this shows the dependency graph and confirms zero conflict edges.
4. **Read `15-regression-verification/REGRESSION-VERIFICATION-REPORT.md`** — this verifies closed findings remain closed.

---

## Top 5 Critical Issues (Summary)

### 1. PostgreSQL FTS fallback must be eliminated (F-001)

V4.6 has 50+ references to "PostgreSQL FTS fallback" across 14 active-tier files. V4.7 §12 mandates: "There is no PostgreSQL public-search fallback." V4.7 §13 forbids: "do not silently switch to PostgreSQL."

**Resolution:** SEARCH-001 + OUTAGE-001 contracts (FROZEN; ready for propagation).

### 2. Projection event architecture must be added (F-002)

V4.6 uses "Domain events → UpdateSearchIndex listener → queued Scout job" — the "second unrelated dispatch pathway" V4.7 §23 forbids. V4.6 has 0 references to projection_event, projection_event_targets, projection_states, pending_projection_requests, or ProjectionInput.

**Resolution:** PROJECTION-001 through PROJECTION-017 + SERIAL-001 contracts (FROZEN; ready for propagation). Adds 4 new tables and ~2000-3000 lines to canonical/05-implementation.md.

### 3. HMAC-only approval must be replaced with two-stage trust model (F-003)

V4.6 §13 uses HMAC-shared-secret approval. V4.7 §40 mandates two-stage authorization: transport HMAC for integrity + human approval via Filament with separate signing key.

**Resolution:** TRUST-001 + TRUST-002 contracts (FROZEN; ready for propagation).

### 4. Per-record atomicity must be replaced with artifact-level atomicity (F-004)

V4.6 §13 says "atomicity is per-record, not per-artifact." V4.7 §37 mandates: "Any blocking validation error → entire artifact rejected; zero canonical records committed."

**Resolution:** INGEST-001 contract (FROZEN; ready for propagation).

### 5. 7 user decisions required (DEC-006, 009, 012, 035, 040, 041, 042)

These decisions cannot be made by the remediation agent per V4.7 §68 and §75. They cover:
- filament-shield version (external verification required)
- QUEUE-001 concrete values
- InstitutionStatus::Closed replacement
- ProgrammeStatus reconciliation with V4.7 §50 matrix
- projection_events retention policy
- canonical_imports retention policy
- projection_states collection_generation update mechanism

**Resolution:** User must approve each decision (see `08-unresolved-issues/`).

---

## Package Statistics

- **Deliverables produced:** 16/16 (100%)
- **Findings documented:** 67 (47 original + 20 final audit)
- **Decisions documented:** 53 (35 FROZEN + 11 APPROVED + 4 PROPOSED + 2 DEFERRED + 1 NEW)
- **Contracts registered:** 41 (8 existing + 32 new + 1 proposed-skeleton)
- **Files requiring modification:** 16 (of 57)
- **Scenario tests simulated:** 36 (6 PASS + 8 PARTIAL + 22 FAIL)
- **Adversarial searches performed:** 13 (3 CLEAN + 10 conflicts remain)
- **Regression guards recorded:** 54
- **External facts registered:** 14 (3 verified + 11 require fresh verification)
- **User decisions required:** 7
- **Total deliverable size:** ~150,000 words across 16 documents

---

## Contact

This remediation package was produced by Super Z (Remediation Executor and Verification Agent) on 2026-08-26. The package is self-contained and self-documenting. All evidence is in the 16 deliverables.

For questions about specific findings, decisions, or contracts, refer to the relevant deliverable. Each deliverable has a header explaining its purpose and the V4.7 §section it satisfies.

---

*End of README. Final verdict: NO-GO. 7 user decisions required. 27 contracts require propagation to active-tier files.*
