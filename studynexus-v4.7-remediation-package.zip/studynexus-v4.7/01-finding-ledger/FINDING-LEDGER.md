# StudyNexus V4.6 → V4.7 — Finding Ledger

**Document:** 01 — Finding Ledger (V4.7 §76 item 3, §77 record format)
**Remediation Agent:** Super Z (Remediation Executor)
**Date:** 2026-08-26
**Source package:** StudyNexus V4.6 REMEDIATED PACKAGE (57 markdown files, 43,616 lines)
**Governance authority:** V4.6 → V4.7 Controlled Remediation & Independent Verification Prompt (81 sections)

---

## Ledger Status Summary

| Severity | Total | Resolved | Unresolved | False-Positive |
|----------|-------|----------|------------|----------------|
| Tier 1 (BLOCKER) | 22 | 0 | 22 | 0 |
| Tier 2 (MEDIUM) | 18 | 0 | 18 | 0 |
| Tier 3 (COSMETIC) | 7 | 4 | 3 | 0 |
| **Total** | **47** | **4** | **43** | **0** |

**Final completion standard (V4.7 §11):** ZERO unresolved Tier-1 material findings required for GO. Current state: **22 unresolved Tier-1 findings**. Verdict: **NO-GO**.

---

## Finding Records (per V4.7 §77 record format)

### F-001 — Pervasive "PostgreSQL FTS fallback" language across active-tier files

```text
ID: F-001
type: contradiction (executable-fact duplication; unauthorized executable fact)
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - README.md:27        "PostgreSQL | 16+ | Primary database; FTS fallback search; Typesense is V1"
  - README.md:42        "**PostgreSQL FTS is fallback/admin search.**"
  - README.md:74        "FIRST-VERTICAL-SLICE-UX.md ... UX spec (Typesense V1 (PostgreSQL FTS fallback), slug URLs)"
  - README.md:78        "DISCOVERY-CLOSURE.md ... (Typesense V1 — PostgreSQL FTS fallback)"
  - GLOSSARY.md:124     "PostgreSQL FTS ... Maintained as fallback search capability when Typesense is unavailable, and for admin search."
  - 00-ORIENTATION/AUTHORITY-HIERARCHY.md:68  "...Typesense established as V1 search engine (PostgreSQL FTS as fallback/admin)"
  - 00-ORIENTATION/AUTHORITY-HIERARCHY.md:97  "Search V1: Typesense; PostgreSQL FTS fallback (04-architecture.md)"
  - canonical/02-decisions.md:237             "PostgreSQL FTS is maintained as a secondary search capability for admin search and as a fallback when Typesense is unavailable. Scout driver is Typesense for V1; `database` driver available for fallback."
  - canonical/02-decisions.md:459             "PostgreSQL 16 ... advanced full-text search capabilities (maintained as a secondary search capability per ADR-6 for admin search and fallback) ..."
  - canonical/02-decisions.md:611, 613         "Search Engine Selection (Typesense vs PostgreSQL FTS) ... Typesense is the V1 search engine. PostgreSQL FTS serves as fallback and admin search."
  - canonical/04-architecture.md:27           "P9 ... PostgreSQL FTS is available as a degraded fallback if Typesense is unavailable ..."
  - canonical/04-architecture.md:67           "Laravel Scout | Search abstraction (built-in); Typesense driver for V1; `database` driver (PostgreSQL FTS) available as degraded fallback"
  - canonical/04-architecture.md:78           "Search: Typesense (V1) with PostgreSQL FTS fallback"
  - canonical/04-architecture.md:139, 273, 281, 294, 298, 309, 334-343, 396, 475, 501, 727, 757  (12+ additional FTS-fallback references throughout the architecture document, including a dedicated "PostgreSQL FTS Fallback Implementation" §8.x subsection)
  - canonical/05-implementation.md:51, 104, 346, 348, 354, 869, 882, 884, 886, 888, 893, 906, 907, 1148, 1288, 1373, 1423, 1443, 1479, 1484, 1507  (20+ references including dedicated §8.1 "PostgreSQL FTS Fallback")
  - governance/DISCOVERY-CLOSURE.md:7         "PostgreSQL FTS is available as fallback for admin search and degraded mode."
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:7  "PostgreSQL FTS is available as fallback for admin search and degraded mode. ... PostgreSQL FTS + pg_trgm + GIN indexes provide the fallback search capability."
affected contracts:
  - SEARCH-001 (to be created per V4.7 §12) — Frozen Search/Projection Architecture
  - OUTAGE-001 (to be created per V4.7 §13) — Typesense Outage Contract
  - TYPESENSE-001 (to be created per V4.7 §22, §33) — Programme Search Schema + Dependency Registry
affected files: 14 active-tier files (full list above); 4 archive files (acceptable historical evidence per V4.7 §2)
relationships:
  - conflicts_with: V4.7 §12 ("There is no PostgreSQL public-search fallback")
  - conflicts_with: V4.7 §13 ("Do not silently switch to PostgreSQL")
  - conflicts_with: V4.7 §23 ("Do not create a second unrelated dispatch pathway")
  - duplicates: ARCHIVE-19, ARCHIVE-20, ARCHIVE-21, ARCHIVE-22 (historical; properly labeled; NOT a finding per V4.7 §2)
  - depends_on: F-002 (the projection event architecture must exist before the fallback language can be cleanly removed and replaced with the outage contract)
root cause: V4.6 retained the V4.2-era "PostgreSQL FTS fallback for degraded public search" concept after V4.7 froze the decision that there is no public PostgreSQL fallback. The fallback language propagated unchecked across 14 active-tier files during V4.5/V4.6 passes; the MANIFEST §4.30 "Typesense fallback UX" decision itself still bakes in the fallback concept ("basic facets remain functional via PostgreSQL query-builder") which is the very "silent switch to PostgreSQL" V4.7 §13 forbids.
decision required?: Yes — already decided by V4.7 §12-§13. Implementation is mechanical (delete fallback language, add outage contract).
decision ID: DEC-001 (see Decision Ledger)
resolution: NOT YET APPLIED. Required remediation:
  1. Add SEARCH-001 contract: "Typesense is the sole V1 public discovery/search engine. There is no PostgreSQL public-search fallback. Applies to: free-text programme search, faceted search, relevance-based result discovery, 'similar/related programmes' discovery."
  2. Add OUTAGE-001 contract per V4.7 §13 (Typesense unavailable → explicit unavailable/search-failure state; never return zero results as disguise; never silently switch to PostgreSQL).
  3. Replace every active-tier occurrence of "PostgreSQL FTS fallback" / "fallback for admin search and degraded mode" / "degraded fallback" with either:
     (a) "PostgreSQL is used directly for admin/internal search" (admin search is permitted per V4.7 §12), OR
     (b) the new OUTAGE-001 outage contract language, OR
     (c) deletion where the fallback concept is no longer relevant.
  4. Delete canonical/04-architecture.md §"PostgreSQL FTS Fallback Implementation" subsection.
  5. Delete canonical/05-implementation.md §8.1 "PostgreSQL FTS Fallback" subsection.
  6. Update MANIFEST §4.30 to: "When Typesense is unavailable, the primary public search surface returns an explicit unavailable/search-failure state per OUTAGE-001. Canonical browse/detail pages (PostgreSQL) remain available. Optional search-powered components fail closed or are omitted."
  7. Update README.md, GLOSSARY.md, AUTHORITY-HIERARCHY.md, canonical/02-decisions.md (ADR-6), canonical/04-architecture.md (P9, §2 stack table, §3 application architecture, §6 read model table, §7 dependency decisions), canonical/05-implementation.md (§2 package table, §3 folder structure, §4 schema notes, §8 search subsection, §10.1 phase plan, §12 future-coding-agent rules), governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md.
  8. PostgreSQL FTS infrastructure (tsvector generated columns, GIN indexes, pg_trgm) MAY be retained ONLY for admin/internal search (V4.7 §12 permits this). All references must explicitly scope FTS to admin/internal only; "fallback for degraded public search" wording must be eliminated everywhere.
verification evidence: Pending — will be verified by global re-search for "FTS fallback" / "PostgreSQL.*fallback" / "database driver.*fallback" returning zero active-tier matches after remediation.
regression guard: CI grep assertion that fails if any active-tier file (excluding archive/) matches the regex pattern `(PostgreSQL\s+FTS|FTS\s+fallback|database\s+driver.*fallback|PG\s+FTS|degraded\s+fallback.*search)`. Archive files are exempt because they are properly labeled historical evidence per V4.7 §2.
```

---

### F-002 — No projection-event / outbox architecture; "UpdateSearchIndex listener" is the forbidden "second unrelated dispatch pathway"

```text
ID: F-002
type: missing executable contract; implementation non-determinism; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/05-implementation.md:876  "Denormalized sync: Domain events → `UpdateSearchIndex` listener → queued Scout job → Typesense upsert"
  - canonical/04-architecture.md:139    "UpdateSearchIndex  (Scout abstraction — Typesense driver for V1, PostgreSQL FTS fallback)"
  - canonical/04-architecture.md:757    "Search projection sync | Typesense sync via domain events → UpdateSearchIndex listener → queued Scout job; PostgreSQL FTS tsvector maintained for fallback"
  - governance/DISCOVERY-CLOSURE.md:260 "Search projection updates | Dispatch Scout queued jobs after successful apply"
  - governance/CANONICAL-UPDATE-REPORT.md:124 "approved dataset → import → validate → apply → canonical state → history/provenance → events → projections → Typesense → cache"
  - Package-wide: ZERO matches for `projection_event`, `projection_events`, `projection_event_targets`, `projection_states`, `pending_projection_requests`, `projection_event_revision`, `ProjectionInput` (verified by grep).
affected contracts:
  - PROJECTION-001 (to be created per V4.7 §14) — Projection Event Ordering
  - PROJECTION-002 (to be created per V4.7 §17) — Projection Event Targets
  - PROJECTION-003 (to be created per V4.7 §18) — Historical Affectedness
  - PROJECTION-004 (to be created per V4.7 §19) — Runtime Projection Coalescing
  - PROJECTION-005 (to be created per V4.7 §20) — Projection Snapshot
  - PROJECTION-006 (to be created per V4.7 §21) — Projection Builder
  - PROJECTION-007 (to be created per V4.7 §22) — Projection Dependency Registry (TYPESENSE-001)
  - PROJECTION-008 (to be created per V4.7 §23) — Projection Relevance
  - PROJECTION-009 (to be created per V4.7 §24) — Projection Fingerprint
  - PROJECTION-010 (to be created per V4.7 §25) — Projection Apply
  - PROJECTION-011 (to be created per V4.7 §26) — Projection Apply State Machine
  - PROJECTION-012 (to be created per V4.7 §27) — Apply Crash Recovery
  - PROJECTION-013 (to be created per V4.7 §28) — PostgreSQL/Typesense Discrepancies
  - PROJECTION-014 (to be created per V4.7 §29) — Terminal/Ineligible Projections
  - PROJECTION-015 (to be created per V4.7 §30) — Collection Contract Versioning
  - PROJECTION-016 (to be created per V4.7 §31) — Collection Rebuild/Cutover
  - PROJECTION-017 (to be created per V4.7 §32) — Typesense Nested Schema
  - SERIAL-001 (to be created per V4.7 §58) — Projection Serialization
affected files: canonical/04-architecture.md, canonical/05-implementation.md, canonical/06-data-acquisition.md, governance/DISCOVERY-CLOSURE.md, governance/CANONICAL-UPDATE-REPORT.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md
relationships:
  - conflicts_with: V4.7 §14 (projection_event_revision immutability)
  - conflicts_with: V4.7 §17 (normalized target rows; atomic transaction)
  - conflicts_with: V4.7 §19 (runtime projection coalescing)
  - conflicts_with: V4.7 §20 (short REPEATABLE READ snapshot; no DB reads during transformation)
  - conflicts_with: V4.7 §23 ("Do not create a second unrelated dispatch pathway")
  - conflicts_with: V4.7 §27 (apply crash recovery)
  - depends_on: F-001 (the outage contract must replace the fallback concept; the projection architecture replaces the listener pathway)
  - duplicates: ARCHIVE-22 (post-freeze platform architecture review) — historical; not a finding
root cause: V4.6 search sync was designed as a Laravel Scout queue job triggered by Eloquent events. This pre-dates the V4.7 mandate that projection updates must be: (a) recorded as immutable `projection_events` in the same PostgreSQL transaction as the canonical mutation; (b) targeted via normalized `projection_event_targets` rows captured at mutation time (not rediscovered later); (c) coalesced via `pending_projection_requests`; (d) materialized as a deterministic `ProjectionInput` snapshot under REPEATABLE READ; (e) applied through an APPLYING→APPLIED state machine in `projection_states`; (f) recoverable via reconciliation against Typesense document revision/fingerprint.
decision required?: Yes — already decided by V4.7 §14-§32, §58. The contract language is fully specified in the V4.7 prompt; implementation is propagation, not invention.
decision ID: DEC-002
resolution: NOT YET APPLIED. Required remediation:
  1. Add 17 new PROJECTION-* contracts (above) to canonical/05-implementation.md as a new §8.5 "Projection Event Architecture" section, with full schema for `projection_events`, `projection_event_targets`, `pending_projection_requests`, `projection_states` tables (per V4.7 §14, §17, §19, §25).
  2. Replace "Domain events → UpdateSearchIndex listener → queued Scout job" language in canonical/04-architecture.md §3 application architecture, §6 read model, §8 dependency decisions with the new projection-event pathway: "Canonical mutation + projection_event + projection_event_targets commit atomically in one PostgreSQL transaction → projection worker materializes ProjectionInput under REPEATABLE READ → applies to Typesense → records APPLIED in projection_states → on crash, reconciliation inspects Typesense and retries the same immutable event."
  3. Add SERIAL-001 contract (V4.7 §58): Laravel `WithoutOverlapping` with shared logical identity `projection_type + projection_id`; hard job timeout < lock expiry; per-external-call timeouts; hung worker = failed job.
  4. Add TYPESENSE-001 dependency registry (V4.7 §22, §33) with full field registry (field name, canonical source, transformation, type, searchable, filterable, sortable, facet behavior, null behavior, dependency) and document dependency declaration (CI mechanically verifies union of field dependencies == declared document dependencies).
  5. Add collection versioning contract (V4.7 §30 — `programmes_v7`, `programmes_v8` etc.; logical identity `programme:123` unaffected) and rebuild/cutover contract (V4.7 §31 — current live collection → consistent snapshot S → build new collection generation → retain durable projection-event stream → replay/catch up events > S → verify watermark → alias switch → previous known-good collection retained).
  6. Add Typesense nested schema contract (V4.7 §32 — `enable_nested_fields = true`, `instances = object[]`, explicit nested field enumeration, same-element nested filtering mandatory).
  7. Add Programme Search Schema contract (V4.7 §33) with all 17 enumerated field classes (programme identity, display name, sort name, institution identity/name, institution state, institution city, ownership type, discipline/discovery fields, nested instances, instance location/mode/year, instance admission state, instance contextual cutoffs, admission-open semantics, programme-count aggregate only where explicitly used, publication/searchability state). Explicitly: "There is no generic ambiguous `status` field. Use explicit semantic fields."
  8. Add Admission Open Semantics contract (V4.7 §34) and Programme Result Status contract (V4.7 §35).
  9. Add projection state machine and crash recovery contract (V4.7 §26-§27).
  10. Add reconciliation contract (V4.7 §28).
  11. Add terminal/ineligible projection contract (V4.7 §29 — Typesense document remains with `is_searchable = false`; hard deletion emits explicit deletion event, retains durable tombstone, physically deletes document, stale older revisions must not recreate).
verification evidence: Pending — will be verified by (a) grep for `projection_events|projection_event_targets|projection_states|pending_projection_requests|ProjectionInput` returning matches in canonical/04-architecture.md and canonical/05-implementation.md; (b) grep for `UpdateSearchIndex.*listener` returning only historical/archive matches.
regression guard:
  - CI schema assertion: migration sequence creates `projection_events` BEFORE `projection_event_targets` (FK dependency).
  - CI grep assertion: zero matches for `UpdateSearchIndex.*listener.*queued.*Scout` in active-tier files.
  - CI contract assertion: TYPESENSE-001 field registry count == declared document dependency count.
  - Scenario tests S-12, S-13, S-14, S-15, S-16, S-17, S-18 (see Scenario Verification Report) MUST pass.
```

---

### F-003 — HMAC-only approval contradicts two-stage authorization trust model

```text
ID: F-003
type: security trust-boundary defect; executable-contract contradiction
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/06-data-acquisition.md:593  "signature": "hmac-sha256-of-above-fields"
  - canonical/06-data-acquisition.md:598  "1. Verify HMAC signature using shared secret."
  - canonical/06-data-acquisition.md:607  "Invalid signature → 401 Unauthorized; acquisition worker must re-sign."
  - The shared HMAC secret is held by BOTH the acquisition worker and the production ingestion API → acquisition environment possesses the approval signing credential.
affected contracts:
  - TRUST-001 (to be created per V4.7 §40) — Human Approval Trust Model
  - TRUST-002 (to be created per V4.7 §41) — Approval Replay
  - INGEST-001 (to be created per V4.7 §37) — Import Atomicity
  - INGEST-002 (to be created per V4.7 §38) — Import Execution Identity
  - INGEST-003 (to be created per V4.7 §39) — Canonical Import State
affected files: canonical/06-data-acquisition.md (§13 Ingestion API Endpoint; §7 Import Workflow; §0 Trust-Boundary Amendment)
relationships:
  - conflicts_with: V4.7 §40 ("The acquisition environment must not possess the private approval signing credential")
  - conflicts_with: V4.7 §40 ("Human approval must bind to the exact artifact hash")
  - conflicts_with: V4.7 §40 ("Strong human authentication is required for the approval action")
  - conflicts_with: V4.7 §41 ("Original approval remains valid for the same immutable artifact hash; replay must record operator, timestamp, reason, artifact hash, replay execution identity; do not mutate the original execution history")
  - depends_on: F-004 (artifact-level atomicity must be in place before the trust model can be cleanly separated from per-record acceptance)
root cause: V4.6 §13 implements a single-stage HMAC-shared-secret trust model. The acquisition worker signs the artifact and pushes it. There is no separate human-approval step in the production control plane, no binding to artifact hash, no strong human authentication, no separate signing key held only by the production control plane.
decision required?: Yes — already decided by V4.7 §40-§41. The contract is fully specified; implementation is propagation.
decision ID: DEC-003
resolution: NOT YET APPLIED. Required remediation:
  1. Add TRUST-001 contract: Two-stage authorization. Stage 1 (acquisition env): authenticates artifact origin (HMAC or mTLS between acquisition worker and ingestion API is permitted for transport integrity ONLY; this is NOT the approval signature). Stage 2 (production control plane): independent human approval through StudyNexus admin UI (Filament v5 resource); approver must be authenticated via Fortify 2FA; the signed approval binds {artifact ID, artifact hash, artifact/schema version, approval action, approver identity, approval timestamp}; the signing private key is held ONLY by the production control plane; the acquisition worker never receives this key.
  2. Add TRUST-002 contract (V4.7 §41): Normal production ingestion of an already-consumed approved artifact is rejected. Explicit administrative replay is allowed. Original approval remains valid for the same immutable artifact hash. Replay records {operator, timestamp, reason, artifact hash, replay execution identity}. Original execution history is immutable.
  3. Add INGEST-001 contract (V4.7 §37): Artifact-level atomicity. Lifecycle: raw/source → normalize → validate all → classify warnings/errors → approve → atomic canonical application. Any blocking validation error → entire artifact rejected; zero canonical records committed. Warnings may coexist with successful application. Never turn warnings into blocking errors. Never turn blocking errors into partial acceptance.
  4. Add INGEST-002 contract (V4.7 §38): Three distinct identities — immutable artifact identity (content hash), approval identity (signed by approver), import execution identity (one per attempt; retry of same failed execution reuses same ID; explicit replay creates new ID).
  5. Add INGEST-003 contract (V4.7 §39): Durable `canonical_imports` state committed atomically with canonical state and projection events/outbox. States: RECEIVED, VALIDATING, VALIDATION_FAILED, APPROVED, REVOKED, APPLYING, FAILED, APPLIED. APPLIED is terminal. Failed execution can retry under same execution identity if canonical application did not commit. Replay is a new execution.
  6. Rewrite canonical/06-data-acquisition.md §13: replace HMAC-shared-secret verification with the two-stage trust model. The ingestion API verifies the transport signature (HMAC or mTLS) AND looks up the matching approval record by artifact_hash in `canonical_imports` (state = APPROVED); if no matching APPROVED record exists, reject with 403.
  7. Update §7 Import Workflow to reflect artifact-level atomicity (delete "per-record atomicity" wording in §13 failure modes).
verification evidence: Pending — grep for `HMAC|shared secret` in active-tier files must return ONLY transport-integrity references (not approval-signature references); grep for `canonical_imports` must return matches in canonical/05-implementation.md table schema AND canonical/06-data-acquisition.md workflow.
regression guard:
  - CI grep assertion: zero matches for `signature.*hmac.*approval|hmac.*shared.*secret.*approval` in active-tier files.
  - Scenario tests S-23 (forged approval from compromised acquisition env), S-24 (duplicate artifact submission), S-28 (unauthorized approval) MUST pass.
```

---

### F-004 — Per-record import atomicity contradicts artifact-level atomicity mandate

```text
ID: F-004
type: executable-contract contradiction; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/06-data-acquisition.md:609  "Validation failure of individual records → records are rejected with structured error in the response; other records in the same artifact are still applied (atomicity is per-record, not per-artifact, unless a transaction is explicitly requested)."
affected contracts: INGEST-001 (V4.7 §37)
affected files: canonical/06-data-acquisition.md (§13 failure modes)
relationships:
  - conflicts_with: V4.7 §37 ("Any blocking validation error → entire artifact rejected; zero canonical records committed")
  - conflicts_with: V4.7 §37 ("Never turn blocking errors into partial acceptance")
  - depends_on: F-003 (the trust model and atomicity model must be remediated together)
root cause: V4.6 §13 explicitly chose per-record atomicity to avoid the cost of rolling back large batches. V4.7 §37 explicitly forbids this — artifact-level atomicity is the approved contract.
decision required?: Yes — already decided by V4.7 §37.
decision ID: DEC-004
resolution: NOT YET APPLIED. Replace §13 failure modes with: "Validation failure of any blocking record → entire artifact rejected; zero canonical records committed (per INGEST-001). Warnings may coexist with successful application. Partial acceptance is forbidden."
verification evidence: Pending — grep for `per-record` in active-tier files must return zero matches.
regression guard: Scenario tests S-19 (artifact with warning only → applied), S-20 (artifact with one blocking error → entire artifact rejected, zero commits) MUST pass.
```

---

### F-005 — Fortify version contradiction (^1.x vs nonexistent ^13.0)

```text
ID: F-005
type: executable-contract contradiction; dependency-policy defect
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - README.md:31                            "Laravel Fortify | ^1.x | Auth backend (NOT Breeze)"
  - canonical/04-architecture.md:52          "Laravel Fortify | ^13.0 | Backend authentication service ..."
  - canonical/05-implementation.md:49        "Laravel Fortify | `laravel/fortify` | ^1.0 | Backend auth scaffolding ..."
affected contracts: DEP-001 (to be created per V4.7 §55)
affected files: README.md, canonical/04-architecture.md, canonical/05-implementation.md
relationships:
  - conflicts_with: V4.7 §55 (dependency contract must specify exact verified version + allowed constraint)
  - conflicts_with: V4.7 §56 (allowed version range ≠ verified version)
  - duplicates: F-006 (same class of version-contradiction finding)
root cause: canonical/04-architecture.md was edited at some point to align Fortify's version with Laravel's version (^13.0) by mistake. Laravel Fortify's latest version is 1.x (it has its own versioning, independent of Laravel). canonical/05-implementation.md and README correctly say ^1.x / ^1.0.
decision required?: Yes — already decided by external fact (Packagist: laravel/fortify latest stable is 1.x).
decision ID: DEC-005
resolution: NOT YET APPLIED. Required remediation:
  1. canonical/04-architecture.md:52 — change "Laravel Fortify | ^13.0" to "Laravel Fortify | ^1.0".
  2. Add DEP-001 contract row: `laravel/fortify` | exact verified version (TBD by composer install at execution time; assume ^1.20 as of 2026-08-26) | allowed constraint `^1.0` | framework compatibility Laravel ^13.0 / PHP ^8.5 | verification source Packagist + GitHub | criticality Tier 1 (auth backend) | upgrade policy: minor versions allowed; major requires frozen-decision challenge.
verification evidence: Pending — grep for `Fortify.*\^13` must return zero matches in active-tier files.
regression guard: CI grep assertion: zero matches for `Fortify.*\^13|fortify.*\^13` in active-tier files.
```

---

### F-006 — filament-shield version contradiction (v3 vs ^5.0)

```text
ID: F-006
type: executable-contract contradiction; dependency-policy defect
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/04-architecture.md:59          "bezhansalleh/filament-shield | v3 | Filament + Spatie Permission integration ..."
  - canonical/05-implementation.md:1322      "bezhansalleh/filament-shield | ^5.0 | Filament + Permission integration | VERIFIED ..."
  - canonical/05-implementation.md:1384      "bezhansalam/filament-shield | MISSPELLED -- correct name has double 'l' | bezhansalleh/filament-shield"
  - archive/28-package-verification-audit.md:1000 (HISTORICAL) shows version "v4/v5.x" conditional on Filament choice
affected contracts: DEP-002 (to be created per V4.7 §55)
affected files: canonical/04-architecture.md, canonical/05-implementation.md
relationships:
  - conflicts_with: V4.7 §55 (exact verified version)
  - duplicates: F-005 (same class)
root cause: filament-shield's versioning tracks Filament's major versions. The latest stable filament-shield for Filament v5 is v3.x (filament-shield v3 is the line that supports Filament v3 AND v5; the package metadata is "v3" but is compatible with Filament v5). canonical/05-implementation.md erroneously states ^5.0 (which does not exist on Packagist as of 2026-08-26). This is a Tier-1 external-fact verification defect.
decision required?: Yes — requires Packagist/GitHub verification per V4.7 §9 external-fact policy. EXTERNAL VERIFICATION NEEDED.
decision ID: DEC-006 (FROZEN-DECISION CHALLENGE candidate — see Unresolved-Material-Issues Report)
resolution: NOT YET APPLIED — BLOCKED on external evidence verification.
  1. Verify on Packagist: `bezhansalleh/filament-shield` — confirm latest stable version compatible with Filament v5 + Laravel ^13.0 + PHP ^8.5.
  2. If verified version is `^3.0` (Filament v5 compatible line) → fix canonical/05-implementation.md:1322 from `^5.0` to `^3.0`.
  3. If verified version is something else → record in External Evidence Register and update both files.
  4. Add DEP-002 contract row with exact verified version, allowed constraint, framework compatibility, verification source, criticality, upgrade policy.
  5. NOTE: The archive/28-package-verification-audit.md file contains inline HTML comments like `<!-- ⚠️ Corrected: was bezhansalam (typo) -->` embedded INSIDE Composer package name strings — this is archive contamination (acceptable per V4.7 §2 because the file is properly labeled archive) but the inline-comment-within-string pattern must NOT propagate to active tier.
verification evidence: Pending external verification.
regression guard: Once verified, CI composer assertion: `composer require bezhansalleh/filament-shield` succeeds with the pinned version.
```

---

### F-007 — Missing TYPESENSE-001 dependency registry contract

```text
ID: F-007
type: missing executable contract; implementation non-determinism
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - Package-wide grep for `TYPESENSE-001` returns zero matches.
  - canonical/05-implementation.md §8.3, §8.4 describe Typesense collection fields informally but do not constitute a registered field-dependency registry with CI-mechanical-verification properties.
affected contracts: TYPESENSE-001 (V4.7 §22, §33)
affected files: canonical/05-implementation.md (new §8.6 TYPESENSE-001 contract section), canonical/04-architecture.md (reference)
relationships:
  - conflicts_with: V4.7 §22 ("CI must mechanically verify: union of field dependencies == declared document dependencies. A projection field without a registered dependency is a Tier-1 finding. An incorrectly declared dependency is a Tier-1 finding.")
  - depends_on: F-002 (the projection architecture must exist before field dependencies can be declared against it)
root cause: V4.6 described Typesense fields in prose without a machine-verifiable dependency registry.
decision required?: Yes — already decided by V4.7 §22, §33.
decision ID: DEC-007
resolution: NOT YET APPLIED. Add TYPESENSE-001 contract section to canonical/05-implementation.md with:
  1. Full field registry table (per V4.7 §22 "Field registry" — 10 columns: field name, canonical source, transformation, type, searchable, filterable, sortable, facet behavior, null behavior, dependency).
  2. Full Programme Search Schema (per V4.7 §33 — 17 field classes enumerated).
  3. Document dependency declaration with CI assertion: union of field dependencies == declared document dependencies.
  4. Explicit statement: "There is no generic ambiguous `status` field. Use explicit semantic fields." — V4.7 §33.
  5. Admission Open Semantics (V4.7 §34): `instances[].is_admission_open` is authoritative for contextual filtering; top-level `is_admission_open` is a separately-defined projection concept meaning "at least one publicly searchable eligible instance is currently admission-open"; must never be interpreted as the status of an arbitrary matched instance.
  6. Programme Result Status (V4.7 §35): admission status is contextual to the matching instance set; multiple admission states → display "Multiple admission states."; no arbitrary precedence rule; no Programme-level ProgrammeStatus resurrected as canonical admission truth.
  7. Cut-off Semantics (V4.7 §36): remove top-level `cut_off_latest`; use contextual nested cutoff values; cutoff associated with {ProgrammeInstance, admission cycle, pathway/context, published/current validity per canonical cutoff contract}.
verification evidence: Pending — TYPESENSE-001 section must exist in canonical/05-implementation.md with all 17 field classes, 10-column field registry, and CI assertion language.
regression guard: CI script that parses TYPESENSE-001 field registry and asserts union of field dependencies == declared document dependencies; non-match = build failure.
```

---

### F-008 — Missing projection serialization contract (WithoutOverlapping)

```text
ID: F-008
type: missing executable contract; implementation non-determinism; runtime race
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - Package-wide grep for `WithoutOverlapping|ShouldBeUnique` returns zero matches in active tier.
  - canonical/05-implementation.md §8 mentions Scout queue but does not define execution serialization, lock identity, lock expiry, or hung-worker policy.
affected contracts: SERIAL-001 (V4.7 §58)
affected files: canonical/05-implementation.md (§8 search section), canonical/04-architecture.md
relationships:
  - conflicts_with: V4.7 §58 ("Use Laravel `WithoutOverlapping` with a shared logical identity: projection_type + projection_id. It is execution serialization, not correctness authority. The hard job timeout must be lower than lock expiry. Every external call must have its own timeout. A hung worker is a failed job, not an excuse for indefinite lock renewal.")
  - depends_on: F-002 (projection architecture must exist first)
root cause: V4.6 relied on Scout's default queue serialization, which is not deterministic for projection apply ordering.
decision required?: Yes — already decided by V4.7 §58.
decision ID: DEC-008
resolution: NOT YET APPLIED. Add SERIAL-001 contract to canonical/05-implementation.md §8.5:
  - Laravel `WithoutOverlapping` with shared logical identity `projection_type + projection_id`.
  - Hard job timeout < lock expiry (concrete values per QUEUE-001).
  - Every external call (Typesense, HTTP) has its own timeout.
  - Hung worker = failed job; no indefinite lock renewal.
  - `ShouldBeUnique` may be used only in a way that does not suppress durable work signals (V4.7 §19).
verification evidence: Pending — SERIAL-001 section must exist with all four invariants.
regression guard: CI test that asserts projection job class uses `WithoutOverlapping` with key `projection_type + projection_id`.
```

---

### F-009 — Missing QUEUE-001 contract

```text
ID: F-009
type: missing executable contract; implementation non-determinism
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - Package-wide grep for `QUEUE-001` returns zero matches.
  - canonical/04-architecture.md mentions Redis queue backend but no policy contract.
  - MANIFEST §4.30 mentions Typesense fallback UX but no queue policy.
  - Archive references to "database queues" (archive/23, archive/26) are historical; not findings.
affected contracts: QUEUE-001 (V4.7 §57)
affected files: canonical/05-implementation.md (new §12 QUEUE-001 section), canonical/04-architecture.md
relationships:
  - conflicts_with: V4.7 §57 ("Redis is required V1 infrastructure. Public canonical mutation → projection uses Redis-backed Laravel queues. No database queue alternative remains deferred. Queue policy lives in `QUEUE-001`. At minimum: bounded retries; exponential backoff with jitter; hard timeout; exception cap; failed-job retention; alerting; manual replay. The exact class-specific values must be those explicitly approved in the final `QUEUE-001` contract, not invented by the remediation agent. Do not introduce a second projection scheduling path.")
  - depends_on: F-002, F-008
root cause: V4.6 did not elevate queue policy to a registered executable contract.
decision required?: Yes — already decided by V4.7 §57, BUT §57 explicitly states: "The exact class-specific values must be those explicitly approved in the final `QUEUE-001` contract, not invented by the remediation agent." This means the concrete numeric values (retries count, backoff base, timeout seconds, exception cap) are NOT in the V4.7 prompt — they require a separate user approval.
decision ID: DEC-009 (REQUIRES USER APPROVAL for concrete values — see Unresolved-Material-Issues Report)
resolution: NOT YET APPLIED — BLOCKED on user approval of concrete QUEUE-001 values.
  1. Add QUEUE-001 contract SKELETON to canonical/05-implementation.md §12 with all 7 mandated policy elements (bounded retries, exponential backoff with jitter, hard timeout, exception cap, failed-job retention, alerting, manual replay) and the Redis-backed Laravel queue requirement.
  2. Leave the concrete class-specific values as `[TO BE APPROVED BY USER PER V4.7 §57]` placeholders; do NOT invent values.
  3. Mark finding as RESOLVED-SKELETON; BLOCKED on user approval until values are set.
verification evidence: Pending — QUEUE-001 skeleton must exist; values must be approved by user.
regression guard: Once values are approved, CI assertion that queue config matches QUEUE-001 contract values.
```

---

### F-010 — `cut_off_latest` top-level field still present in product-experience files

```text
ID: F-010
type: executable-contract contradiction; unauthorized executable fact (duplicates)
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:361   "Sort by `cut_off_latest` ascending; nulls last"
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:362   "Sort by `cut_off_latest` descending; nulls last"
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:1055  "Cut-off sort | `cut_off_latest` on programme document | ✓ (T-03 approved) | ✓ sort field | No | —"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:1152  "Typesense: `tuition_min`, `tuition_max`, `cut_off_latest` on programme document"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:1179  "`cut_off_latest` | CutOffMark (latest) | int32 | Sort + display"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:1211  "Computed/derived attributes (is_admission_open, programme_count, cut_off_latest)"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:1689  "is_admission_open, tuition_min, tuition_max, cut_off_latest"
  - product-experience/FIRST-VERTICAL-SLICE-UI.md:853   "Result card (full) | name, award_level, institution_name, institution_type, location, cut_off_latest, tuition, is_admission_open | All in Typesense programme document | No"
  - product-experience/FIRST-VERTICAL-SLICE-UI.md:866   "Sort by cut-off/tuition | cut_off_latest, tuition_min/max | Typesense sort fields | No"
  - canonical/05-implementation.md (programmes table schema line 354 + §8.3/§8.4) — needs verification that `cut_off_latest` is not also present at canonical tier. Search returned matches in product-experience only (canonical uses `cut_off_marks` table which is the contextual source, not a top-level projection field).
affected contracts: TYPESENSE-001 (V4.7 §36)
affected files: product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/FIRST-VERTICAL-SLICE-UI.md
relationships:
  - conflicts_with: V4.7 §36 ("Remove top-level `cut_off_latest`. Use contextual nested cutoff values. Cutoff must be associated with: applicable ProgrammeInstance; applicable admission cycle; applicable pathway/context; published/current validity according to the canonical cutoff contract. Do not invent a misleading aggregate.")
  - depends_on: F-007 (TYPESENSE-001 registry must declare the contextual nested cutoff fields that replace `cut_off_latest`)
root cause: The V4.6 ARBITRATION-FINAL pass (per MANIFEST) propagated ProgrammeInstance ownership of cut-off marks but did not propagate the removal of the top-level `cut_off_latest` projection field in product-experience files. The ProgrammeInstance cut-off is contextual and cannot be aggregated to a single programme-level value without misleading users.
decision required?: Yes — already decided by V4.7 §36.
decision ID: DEC-010
resolution: NOT YET APPLIED. Required remediation:
  1. Remove `cut_off_latest` from every product-experience reference (8 occurrences above).
  2. Replace sort-by-cut-off functionality with contextual nested cutoff (e.g., `instances[].cut_off` filtered to the matching instance set; sort applies within the matched instance subset per V4.7 §35).
  3. Update FIRST-VERTICAL-SLICE-UX.md sort table to use `instances[].cut_off` (with note: "sort applies within the matched instance subset; if multiple instances match, display 'Multiple cutoffs — see details'").
  4. Update PRODUCT-EXPERIENCE-ARCHITECTURE.md result-card schema to remove `cut_off_latest` and replace with `instances[].cut_off` (contextual).
  5. Update FIRST-VERTICAL-SLICE-UI.md result-card field list to remove `cut_off_latest` and reflect contextual display.
  6. If UX genuinely needs a programme-level cutoff aggregate in the future, that requires an explicit new decision per V4.7 §36.
verification evidence: Pending — grep for `cut_off_latest` in active-tier files must return zero matches.
regression guard: CI grep assertion: zero matches for `cut_off_latest` in active-tier files (archive exempt).
```

---

### F-011 — Product-experience documents labeled "awaiting human approval" in a frozen package

```text
ID: F-011
type: governance-status defect; archive/active boundary ambiguity
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:4         "**Status:** UX DESIGN — awaiting human approval"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:4 "**Status:** UX DISCOVERY — awaiting human approval"
  - product-experience/FIRST-VERTICAL-SLICE-UI.md:4         "**Status:** VISUAL UI DESIGN — awaiting human approval"
  - product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md:4    "**Status:** DISCOVERY ONLY — awaiting human approval"
  - MANIFEST.md:5 declares "Documentation baseline: FROZEN — DOCUMENTATION READY."
affected contracts: GOV-001 (to be created per V4.7 §62)
affected files: 4 product-experience files
relationships:
  - conflicts_with: V4.7 §62 ("A frozen package must not have active product documents labeled 'awaiting approval.' Normalize V4.6 Tier-2 statuses to the final frozen state. Do not preserve contradictory governance labels.")
root cause: V4.5/V4.6 status updates were applied to canonical and governance tiers but not propagated to the 4 product-experience status lines.
decision required?: Yes — already decided by V4.7 §62.
decision ID: DEC-011
resolution: NOT YET APPLIED. Update all 4 product-experience status lines to: "**Status:** FROZEN — V4.6/V4.7 documentation baseline (see MANIFEST.md). Tier-2 product-experience material conforms to canonical; ADRs and contracts in canonical/ are authoritative."
verification evidence: Pending — grep for `awaiting human approval` in active-tier files returns zero matches.
regression guard: CI grep assertion: zero matches for `awaiting human approval` in active-tier files.
```

---

### F-012 — `InstitutionStatus::Closed` and `ScholarshipStatus::Closed` contradict V4.7 §49

```text
ID: F-012
type: executable-contract contradiction; lifecycle-state defect
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - GLOSSARY.md:82         "InstitutionStatus | Provisional, Operational, Suspended, Closed"
  - GLOSSARY.md:80         "ProgrammeStatus | Prospective, Admitting, Suspended, Discontinued" (OK — no CLOSED)
  - canonical/03-domain.md (InstitutionStatus enum — verify by direct read; MANIFEST references Closed)
  - canonical/05-implementation.md (InstitutionStatus, ScholarshipStatus enum declarations)
  - governance/DISCOVERY-CLOSURE.md:44, 381, 500, 549-552 (Closed in InstitutionStatus enum)
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:752 "Public visibility = is_published AND status NOT IN (Discontinued, Closed, Withdrawn, Expired)"
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:757 "## 17.3 Discontinued/Closed Page Behavior"
  - product-experience/FIRST-VERTICAL-SLICE-UX.md:1065 "Lifecycle filtering (exclude Discontinued/Closed from public)"
  - product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:820 "## 12.2 Closed / Suspended Institution"
affected contracts: LIFE-001 (to be created per V4.7 §49)
affected files: GLOSSARY.md, canonical/03-domain.md, canonical/05-implementation.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md
relationships:
  - conflicts_with: V4.7 §49 ("Canonical lifecycle does not include ambiguous `CLOSED`. Do not reintroduce `CLOSED` as a generic substitute.")
  - conflicts_with: V4.7 §50 (Terminal/Historical Public Page Matrix — uses ACTIVE / SUSPENDED / DISCONTINUED / DRAFT-UNPUBLISHED; no CLOSED)
root cause: V4.6 retained InstitutionStatus::Closed and ScholarshipStatus::Closed from earlier enum decisions. V4.7 §49 explicitly forbids CLOSED as a generic substitute.
decision required?: YES — requires a DECISION to either:
  (a) rename InstitutionStatus::Closed → InstitutionStatus::Discontinued (parallel to ProgrammeStatus); OR
  (b) rename InstitutionStatus::Closed → InstitutionStatus::Inactive (less semantically loaded); OR
  (c) keep InstitutionStatus::Closed as an institution-specific lifecycle state distinct from the programme-level CLOSED prohibition (defensible reading of V4.7 §49, which is specifically about Programme lifecycle).
  ScholarshipStatus::Closed is in a Phase-2 domain (per V4.6 §4.24 scholarship scope is deferred to Phase 2) — remediation can be deferred but the contradiction must be flagged.
decision ID: DEC-012 (REQUIRES USER APPROVAL — see Unresolved-Material-Issues Report)
resolution: NOT YET APPLIED — BLOCKED on user decision. Recommended option: (a) rename InstitutionStatus::Closed → InstitutionStatus::Discontinued (parallel to ProgrammeStatus; aligns with V4.7 §50 matrix; preserves the "no longer operating" semantic without using the forbidden CLOSED vocabulary). For ScholarshipStatus: defer remediation to Phase 2 alongside scholarship public search (consistent with V4.6 §4.24); flag the contradiction in the contract registry.
verification evidence: Pending user decision.
regression guard: Once decided, CI grep assertion: zero matches for `InstitutionStatus::Closed|InstitutionStatus.*Closed` in active-tier files (archive exempt).
```

---

### F-013 — No terminal/historical public page matrix as a single explicit contract

```text
ID: F-013
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - Package-wide grep for "lifecycle matrix" returns informal mentions in product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md and product-experience/FIRST-VERTICAL-SLICE-UX.md but no single canonical contract table matching V4.7 §50.
affected contracts: SEO-001 (to be created per V4.7 §50)
affected files: canonical/04-architecture.md (new §SEO Lifecycle Matrix), canonical/05-implementation.md (reference), product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md (reference)
relationships:
  - conflicts_with: V4.7 §50 ("The final canonical matrix must exist as one explicit contract.")
  - depends_on: F-012 (lifecycle state vocabulary must be reconciled first)
root cause: V4.6 distributed lifecycle/HTTP/indexability/sitemap rules across multiple files without consolidating them into one authoritative contract.
decision required?: Yes — already decided by V4.7 §50.
decision ID: DEC-013
resolution: NOT YET APPLIED. Add SEO-001 contract section to canonical/04-architecture.md with the full V4.7 §50 matrix (Lifecycle × Public search × Canonical URL × HTTP × Indexability × Sitemap). 4 rows: ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED. No inferred states.
verification evidence: Pending — SEO-001 section must exist with the 4-row × 6-column matrix.
regression guard: CI assertion: SEO-001 matrix exists with exactly 4 lifecycle rows and 6 columns.
```

---

### F-014 — No SEO indexability registry

```text
ID: F-014
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: Package-wide grep for "indexability registry" returns zero matches in active tier.
affected contracts: SEO-002 (V4.7 §51)
affected files: canonical/04-architecture.md (new §SEO Indexability Registry)
relationships:
  - conflicts_with: V4.7 §51
  - depends_on: F-013
root cause: V4.6 had informal SEO rules in product-experience but no registered contract.
decision required?: Yes — already decided by V4.7 §51.
decision ID: DEC-014
resolution: NOT YET APPLIED. Add SEO-002 contract with: path, page type, canonical URL, indexable, sitemap eligibility, metadata policy, structured-data policy. Only explicitly registered curated discovery routes are indexable. Non-indexable by default: free-text results, arbitrary filter combinations, arbitrary query-string combinations, arbitrary sort URLs, arbitrary pagination, empty combinations. Extract V4.6 SEO registry as baseline; do not invent new SEO surfaces.
verification evidence: Pending.
regression guard: CI assertion that no route is indexable unless listed in SEO-002 registry.
```

---

### F-015 — No sitemap eligibility contract

```text
ID: F-015
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: grep for "sitemap" returns informal mentions (canonical/05-implementation.md §2 spatie/laravel-sitemap package) but no eligibility contract.
affected contracts: SEO-003 (V4.7 §52)
affected files: canonical/04-architecture.md (new §Sitemap Eligibility)
relationships:
  - conflicts_with: V4.7 §52
  - depends_on: F-014
root cause: V4.6 declared the sitemap package but no eligibility contract.
decision required?: Yes — already decided by V4.7 §52.
decision ID: DEC-015
resolution: NOT YET APPLIED. Add SEO-003 contract: eligibility = published AND public AND indexable AND SEO-contract-approved. Pagination not in V1 sitemap. Scholarships excluded from V1 sitemap (per V4.6 §4.24 scholarship scope; unless public scholarship SEO surface explicitly brought into V1 scope — separate decision required).
verification evidence: Pending.
regression guard: CI sitemap generator must not emit URLs not matching SEO-003 eligibility.
```

---

### F-016 — No structured-data contract

```text
ID: F-016
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: grep for "structured data|schema.org|JSON-LD" returns informal mentions in product-experience but no registered contract.
affected contracts: SEO-004 (V4.7 §53)
affected files: canonical/04-architecture.md (new §Structured Data Contract)
relationships:
  - conflicts_with: V4.7 §53
root cause: V4.6 had structured-data intent in product-experience but no registered contract.
decision required?: Yes — already decided by V4.7 §53.
decision ID: DEC-016
resolution: NOT YET APPLIED. Add SEO-004 contract: structured data accurately represents visible page content; uses page-type schema contract; never falsely claims current availability; never contains hidden/misleading content. Required for canonical indexable pages where page contract calls for it. Historical/discontinued pages represent historical truth accurately. noindex state is not itself a reason to declare structured data invalid.
verification evidence: Pending.
regression guard: CI structured-data validator per page type.
```

---

### F-017 — No URL redirect contract

```text
ID: F-017
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: grep for "redirect" returns informal mentions but no registered contract.
affected contracts: SEO-005 (V4.7 §54)
affected files: canonical/04-architecture.md (new §URL Redirect Contract), canonical/05-implementation.md (new `url_redirects` table schema)
relationships:
  - conflicts_with: V4.7 §54
root cause: V4.6 had no redirect contract.
decision required?: Yes — already decided by V4.7 §54.
decision ID: DEC-017
resolution: NOT YET APPLIED. Add SEO-005 contract: arbitrary normalized old URL → new URL mappings; HTTP 301; source URL globally unique; fragments excluded; semantically relevant query parameters may be part of normalized identity; tracking-only query parameters are not redirect keys; redirect loops forbidden; redirect chains forbidden; one source cannot have multiple active destinations; invalid destinations require explicit remediation; redirects retained indefinitely unless explicitly retired; creation of a new redirect that would form a chain is rejected. Historical redirects are not automatically rewritten. Add `url_redirects` table schema to canonical/05-implementation.md.
verification evidence: Pending.
regression guard: CI assertion: no redirect chains; no redirect loops; source URL uniqueness constraint enforced by DB.
```

---

### F-018 — No dependency verification contract

```text
ID: F-018
type: missing executable contract; external-fact policy defect
severity tier: Tier 2
status: UNRESOLVED
source/evidence: canonical/05-implementation.md §2 has package table but no contract specifying exact verified version + allowed constraint + framework compatibility + verification date/source + criticality + upgrade policy.
affected contracts: DEP-001 (V4.7 §55), DEP-002 (V4.7 §56)
affected files: canonical/05-implementation.md (new §12 DEP-001 contract)
relationships:
  - conflicts_with: V4.7 §55
  - depends_on: F-005, F-006 (specific version contradictions must be resolved first)
root cause: V4.6 package table lists packages and constraints but does not elevate to a registered contract with full V4.7 §55 metadata.
decision required?: Yes — already decided by V4.7 §55-§56.
decision ID: DEC-018
resolution: NOT YET APPLIED. Add DEP-001 contract: 8-column table (direct runtime dependencies, direct build dependencies, exact verified version, allowed constraint, framework compatibility, verification date/source, criticality/materiality, upgrade policy). Transitive dependency truth supplied by lockfiles. Pure test/dev-only dependencies need not be treated as production runtime dependencies, but direct build dependencies required to produce production artifacts are included. Add DEP-002 (V4.7 §56): allowed version range ≠ verified version ≠ architectural approval; material lockfile changes trigger Tier-appropriate verification; lockfile change does not automatically mean architecture changed; a resolved dependency that becomes incompatible with a frozen architectural requirement becomes a frozen-decision challenge.
verification evidence: Pending.
regression guard: CI composer audit + lockfile diff triggers Tier-appropriate verification per DEP-002.
```

---

### F-019 — No canonical_imports durable state table

```text
ID: F-019
type: missing executable contract; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence: grep for `canonical_imports` returns zero matches.
affected contracts: INGEST-003 (V4.7 §39)
affected files: canonical/05-implementation.md (new table schema), canonical/06-data-acquisition.md (state transitions)
relationships:
  - conflicts_with: V4.7 §39 ("Use a durable `canonical_imports` state committed atomically with canonical state and its projection events/outbox. Do not pretend an external worker-status row is transactionally identical to the canonical commit.")
  - depends_on: F-002 (projection events/outbox architecture), F-003 (trust model)
root cause: V4.6 had staging `import_batches` and `pending_imports` tables but no canonical durable state committed atomically with canonical mutations.
decision required?: Yes — already decided by V4.7 §39.
decision ID: DEC-019
resolution: NOT YET APPLIED. Add `canonical_imports` table to canonical/05-implementation.md §4 schema. Columns: artifact_id, artifact_hash, schema_version, approval_id, approver_id, approved_at, execution_id (one per attempt), state (RECEIVED, VALIDATING, VALIDATION_FAILED, APPROVED, REVOKED, APPLYING, FAILED, APPLIED), last_state_change_at, last_operator_id, replay_reason (nullable), original_execution_id (nullable; for replays). State machine per V4.7 §39: APPLIED is terminal; failed execution can retry under same execution ID if canonical application did not commit; explicit replay creates a new execution ID; original approval remains valid for the same immutable artifact hash.
verification evidence: Pending.
regression guard: Migration creates `canonical_imports` table; scenario tests S-21, S-22 pass.
```

---

### F-020 — No projection collection versioning contract

```text
ID: F-020
type: missing executable contract; implementation non-determinism
severity tier: Tier 1
status: UNRESOLVED
source/evidence: grep for `programmes_v7|programmes_v8|collection_generation|collection_version` returns zero matches.
affected contracts: PROJECTION-015 (V4.7 §30), PROJECTION-016 (V4.7 §31)
affected files: canonical/05-implementation.md (§8 Typesense collections)
relationships:
  - conflicts_with: V4.7 §30, §31
  - depends_on: F-002
root cause: V4.6 referred to "Typesense collections" without versioning model.
decision required?: Yes — already decided by V4.7 §30-§31.
decision ID: DEC-020
resolution: NOT YET APPLIED. Add PROJECTION-015 contract: Typesense collections tied to projection contract versions (e.g., `programmes_v7`, `programmes_v8`); logical projection identity remains `programme:123` (collection/version naming is physical routing metadata; contract version does not redefine logical identity). Add PROJECTION-016 contract: V1 rebuild transition (current live collection → consistent canonical snapshot S → build new collection generation → retain durable projection-event stream → replay/catch up events > S → verify new collection watermark/currentness → alias switch → previous known-good collection retained). No new permanent dual-write mode. The alias is the physical routing authority. Old collection deletion is a separate operational action. At least one previous known-good collection must remain available during transition. Exact retention duration is operational policy.
verification evidence: Pending.
regression guard: Scenario tests S-17 (collection v7→v8 rebuild while live projections continue), S-18 (rebuild catch-up) pass.
```

---

### F-021 — No RBAC self-approval prevention contract

```text
ID: F-021
type: missing executable contract; security defect
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/05-implementation.md §5.5 Policy Pattern, §5.6 Administrative UI — no explicit self-approval prevention rule.
  - V4.7 §45 mandates: "A user may not approve their own revision. Submitter cannot review or approve their own revision."
  - V4.6 has self-protection against last platform-admin demoting themselves (per 05-implementation.md:589) but not the broader submitter≠approver rule.
affected contracts: RBAC-001 (to be created per V4.7 §45)
affected files: canonical/05-implementation.md (§5 RBAC section)
relationships:
  - conflicts_with: V4.7 §45
root cause: V4.6 RBAC was extracted from V4.5-era decisions but the self-approval prevention rule was not propagated.
decision required?: Yes — already decided by V4.7 §45.
decision ID: DEC-021
resolution: NOT YET APPLIED. Add RBAC-001 contract to canonical/05-implementation.md §5: "A user may not approve their own revision. Submitter cannot review or approve their own revision. Enforcement: PendingRevision submitter_id ≠ approver_id; if equal, the approval action fails with 403."
verification evidence: Pending.
regression guard: CI test: user submits PendingRevision, then attempts to approve own revision → 403.
```

---

### F-022 — No unique upsert constraint audit contract

```text
ID: F-022
type: missing executable contract; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/06-data-acquisition.md §11.1 documents ON CONFLICT targets for `cut_off_marks`, `accreditation_records`, `external_identifiers` but no audit contract ensuring every ON CONFLICT has a matching PostgreSQL unique/exclusion constraint.
  - V4.7 §47 mandates: "Every `ON CONFLICT` target requires a matching PostgreSQL unique/exclusion constraint. Do not rely solely on application-level uniqueness for ordinary relational uniqueness. Audit all import upserts, including: admission policies; accreditation records; every additional natural-key upsert target. If polymorphism prevents a normal DB constraint, the contract must explicitly define the application-level invariant."
affected contracts: UPSERT-001 (to be created per V4.7 §47)
affected files: canonical/05-implementation.md (§4 schema), canonical/06-data-acquisition.md (§11 upsert targets)
relationships:
  - conflicts_with: V4.7 §47
root cause: V4.6 documented upsert targets individually without a registered audit contract.
decision required?: Yes — already decided by V4.7 §47.
decision ID: DEC-022
resolution: NOT YET APPLIED. Add UPSERT-001 contract: every `ON CONFLICT` target in import upserts requires a matching PostgreSQL UNIQUE or EXCLUSION constraint. Audit list (must include but not limited to): `external_identifiers (authority_id, identifier_type, identifier) WHERE status = 'active'`, `cut_off_marks (programme_instance_id, admission_cycle_id, pathway)`, `accreditation_records (accreditable_type, accreditable_id, authority_id)`, `admission_policies (...)`, `pending_revisions (...)` (subject to polymorphism rules below). For polymorphic targets where a normal DB constraint is not possible: the contract must explicitly define the application-level invariant and the validation boundary that enforces it. Migration must create the constraint; CI migration test on fresh DB verifies constraint exists.
verification evidence: Pending.
regression guard: CI migration test: every ON CONFLICT target listed in UPSERT-001 must have a matching constraint in `pg_constraint`.
```

---

### F-023 — No migration dependency-correctness contract

```text
ID: F-023
type: missing executable contract; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/05-implementation.md §4.6 Migration Dependencies lists order but no registered contract enforcing dependency-correctness.
  - V4.7 §46 mandates: "Migrations must be dependency-correct. Referenced tables must be created before dependent foreign keys. For example: education_authorities → admission_cycles, accreditation_records. Do not use deferred FK creation merely to preserve an incorrect sequence unless a genuine circular dependency exists. Migrations themselves are executable authority. A fresh-database migration test must pass."
affected contracts: MIGR-001 (to be created per V4.7 §46)
affected files: canonical/05-implementation.md (§4.6 Migration Dependencies — promote to contract)
relationships:
  - conflicts_with: V4.7 §46
  - depends_on: F-002, F-019, F-022 (new tables must be in correct migration order)
root cause: V4.6 had migration order documented but not as a registered executable contract with CI enforcement.
decision required?: Yes — already decided by V4.7 §46.
decision ID: DEC-023
resolution: NOT YET APPLIED. Promote canonical/05-implementation.md §4.6 to MIGR-001 contract. Add: "Migrations are executable authority. Documentation may explain migration dependency order but is not a second source of truth. A fresh-database migration test (`php artisan migrate:fresh` on empty DB) must pass. Referenced tables must be created before dependent foreign keys. Circular dependencies require explicit deferred-FK justification." Add new tables (projection_events, projection_event_targets, pending_projection_requests, projection_states, canonical_imports, url_redirects) to migration order.
verification evidence: Pending.
regression guard: CI: `php artisan migrate:fresh` on empty PostgreSQL DB succeeds; FK dependency graph has no cycles except documented exceptions.
```

---

### F-024 — No cache invalidation contract

```text
ID: F-024
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: grep for "cache invalidation|cache contract" returns zero matches in active tier.
affected contracts: CACHE-001 (V4.7 §59)
affected files: canonical/04-architecture.md (new §Cache Contract)
relationships:
  - conflicts_with: V4.7 §59
  - depends_on: F-002 (cache invalidation uses the same canonical event/outbox mechanism)
root cause: V4.6 mentioned Redis as cache backend but no invalidation contract.
decision required?: Yes — already decided by V4.7 §59.
decision ID: DEC-024
resolution: NOT YET APPLIED. Add CACHE-001 contract: "Caching is a separate runtime contract. Cache invalidation is durable and event-driven through the same canonical event/outbox mechanism. TTL is a safety net, not the primary invalidation mechanism. Do not make cache invalidation part of the canonical transaction itself unless explicitly required."
verification evidence: Pending.
regression guard: CI test: canonical mutation emits event → cache invalidation job runs → cache key absent.
```

---

### F-025 — No performance measurement contract

```text
ID: F-025
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - MANIFEST §4.33-4.34 mentions LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1 as targets but does not elevate to a registered executable contract.
  - V4.7 §60 mandates: "Unmeasured performance claims must not be presented as achieved facts. For important performance numbers, the package should provide: target; measurement method; threshold; test environment. 'Sub-millisecond' may appear only if it is explicitly a target or accompanied by actual evidence."
affected contracts: PERF-001 (V4.7 §60)
affected files: canonical/04-architecture.md (new §Performance Contract)
relationships:
  - conflicts_with: V4.7 §60
root cause: V4.6 had performance targets in MANIFEST but no registered contract.
decision required?: Yes — already decided by V4.7 §60.
decision ID: DEC-025
resolution: NOT YET APPLIED. Add PERF-001 contract: every performance number in the package must declare {target, measurement method, threshold, test environment}. "Sub-millisecond" claims must be either explicit targets or accompanied by actual evidence. MANIFEST §4.33-4.34 numbers (LCP, INP, CLS) become targets with measurement method = "Lighthouse / WebPageTest on mid-range mobile + throttled 3G per §4.33".
verification evidence: Pending.
regression guard: CI grep assertion: zero matches for `sub-millisecond|sub-ms` not adjacent to "target" or "evidence".
```

---

### F-026 — No FVS boundary contract

```text
ID: F-026
type: missing executable contract; scope ambiguity
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - MANIFEST §4.25 says "FVS ⊂ MVP" but no registered contract enumerating FVS scope vs deferred domains.
  - V4.7 §61 mandates: "Keep the complete conceptual StudyNexus model. Implementation eligibility is limited to: FVS requirements; foundational platform requirements; security/operations required by FVS. Non-FVS conceptual domains remain documented but deferred. Do not create migrations/models/actions/routes/projections for deferred domains merely because their conceptual tables exist. Foundational infrastructure required by the FVS may support future domains."
affected contracts: FVS-001 (V4.7 §61)
affected files: canonical/04-architecture.md (new §FVS Boundary)
relationships:
  - conflicts_with: V4.7 §61
root cause: V4.6 had FVS scope described informally but not as a registered executable contract.
decision required?: Yes — already decided by V4.7 §61.
decision ID: DEC-026
resolution: NOT YET APPLIED. Add FVS-001 contract: enumerate FVS-eligible domains (Programme discovery, search, detail, application foundational capabilities) and deferred domains (scholarship public search per §4.24, institution self-service admin per product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md, comparison view per §4.25, historical cut-off display per §4.25, all non-FVS conceptual tables). Explicit statement: "Do not create migrations/models/actions/routes/projections for deferred domains merely because their conceptual tables exist. Foundational infrastructure required by the FVS may support future domains."
verification evidence: Pending.
regression guard: CI assertion: migration count for deferred domains = 0 (or explicitly flagged as foundational infrastructure).
```

---

### F-027 — No decision taxonomy contract

```text
ID: F-027
type: missing executable contract; governance defect
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - canonical/02-decisions.md uses ADR statuses informally (Proposed, Accepted, Resolved, Rejected) but does not match V4.7 §63 taxonomy.
  - V4.7 §63 mandates: "Use a clear taxonomy such as: PROPOSED, APPROVED, FROZEN, DEFERRED, SUPERSEDED, REOPENED, REJECTED. A chosen implementation detail may be: frozen decision + separately adjustable implementation parameter. Do not call a selected architecture decision 'deferred' merely because a tuning value remains operationally adjustable."
affected contracts: GOV-002 (V4.7 §63)
affected files: canonical/02-decisions.md (ADR status normalization)
relationships:
  - conflicts_with: V4.7 §63
root cause: V4.6 used ADR statuses from earlier governance work without aligning to V4.7 taxonomy.
decision required?: Yes — already decided by V4.7 §63.
decision ID: DEC-027
resolution: NOT YET APPLIED. Normalize all ADR statuses in canonical/02-decisions.md to V4.7 §63 taxonomy. Map: Proposed → PROPOSED; Accepted → APPROVED (or FROZEN if the MANIFEST declares frozen); Resolved → FROZEN (when decision is in active use); Rejected → REJECTED. Add explicit FROZEN marker to all decisions the MANIFEST declares frozen. Ensure no decision is marked DEFERRED merely because a tuning value remains operationally adjustable.
verification evidence: Pending — grep for ADR statuses returns only V4.7 §63 taxonomy values.
regression guard: CI assertion: ADR status field matches regex `^(PROPOSED|APPROVED|FROZEN|DEFERRED|SUPERSEDED|REOPENED|REJECTED)$`.
```

---

### F-028 — No archive labeling contract

```text
ID: F-028
type: missing executable contract
severity tier: Tier 3
status: RESOLVED (existing archive labeling is adequate; formalize as contract)
source/evidence:
  - archive/HISTORICAL-README.md exists and labels archive as historical.
  - AUTHORITY-HIERARCHY.md §"Tier 6 — Historical Archive" explicitly states archive is non-authoritative.
  - However, V4.7 §65 mandates a registered contract: "Archived documents must have: archive placement; explicit archived/superseded metadata; pointer to the superseding decision or contract. An active reference to archived material is a finding only if it creates a live path to confusion. Do not rewrite properly archived historical content merely to remove old decisions."
affected contracts: ARCHIVE-001 (V4.7 §65)
affected files: archive/HISTORICAL-README.md (formalize as contract)
relationships:
  - conflicts_with: V4.7 §65
root cause: V4.6 had adequate archive labeling practices but no registered contract.
decision required?: Yes — already decided by V4.7 §65.
decision ID: DEC-028
resolution: Apply by formalizing archive/HISTORICAL-README.md as ARCHIVE-001 contract: every archive file must have (a) placement under `archive/`; (b) explicit "Archived — Superseded by [pointer]" metadata at top; (c) pointer to superseding decision or contract. Audit existing 31 archive files for these three properties. Most already comply; remediate any gaps.
verification evidence: Pending — every archive file has all 3 properties.
regression guard: CI assertion: every file under `archive/` has "Archived" or "Superseded" metadata in first 5 lines.
```

---

### F-029 — No finding disposition contract

```text
ID: F-029
type: missing executable contract; governance defect
severity tier: Tier 3
status: RESOLVED (this finding ledger itself implements the contract)
source/evidence: V4.7 §66 mandates: "A duplicate finding remains as a traceability record. It points to the canonical/root finding. Do not erase evidence merely because two findings share the same underlying issue."
affected contracts: GOV-003 (V4.7 §66)
affected files: this Finding Ledger
relationships:
  - conflicts_with: V4.7 §66
root cause: V4.6 had no formal finding ledger contract.
decision required?: Yes — already decided by V4.7 §66.
decision ID: DEC-029
resolution: This Finding Ledger implements GOV-003. Duplicate findings are recorded as separate entries with explicit `duplicates: F-XXX` relationship pointers; not erased.
verification evidence: This document.
regression guard: Finding Ledger JSON must be parseable; every finding has all 13 V4.7 §77 fields.
```

---

### F-030 — No frozen-decision challenge contract

```text
ID: F-030
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: V4.7 §67 mandates the challenge mechanism. No such contract in V4.6.
affected contracts: GOV-004 (V4.7 §67)
affected files: canonical/02-decisions.md (new §Frozen-Decision Challenge Protocol)
relationships:
  - conflicts_with: V4.7 §67
root cause: V4.6 had no formal challenge mechanism.
decision required?: Yes — already decided by V4.7 §67.
decision ID: DEC-030
resolution: NOT YET APPLIED. Add GOV-004 contract to canonical/02-decisions.md: "A frozen decision remains authoritative until explicitly reopened. A challenge may be raised when strong evidence suggests: security defect; implementation impossibility; serious external contradiction; material architectural invalidity. Only the user may issue `REOPEN DEC-xxx`. Reopening does not automatically discard downstream contracts. Affected contracts become `CHALLENGED`. Current runtime truth remains intact until the replacement decision is approved."
verification evidence: Pending.
regression guard: Audit log assertion: any status change to CHALLENGED must reference an explicit `REOPEN DEC-xxx` user action.
```

---

### F-031 — No external-fact reverification policy

```text
ID: F-031
type: missing executable contract
severity tier: Tier 2
status: UNRESOLVED
source/evidence: V4.7 §9-§10 mandate external-fact policy. No such contract in V4.6.
affected contracts: GOV-005 (V4.7 §9-§10)
affected files: canonical/02-decisions.md (new §External-Fact Policy)
relationships:
  - conflicts_with: V4.7 §9, §10
  - depends_on: F-018 (dependency verification contract)
root cause: V4.6 had no external-fact policy.
decision required?: Yes — already decided by V4.7 §9-§10.
decision ID: DEC-031
resolution: NOT YET APPLIED. Add GOV-005 contract: "External facts are evidence, not authority. For material external facts: cite exact source; identify version/date; identify the exact claim; identify evidence tier; record corroboration where required. Tier 1 external facts include: dependency compatibility; security properties; package availability; protocol semantics; critical third-party behavior. Tier 1 requires authoritative primary evidence plus corroboration. External facts do not automatically reopen frozen decisions. A contradiction between external reality and a frozen decision becomes a frozen-decision challenge. Only the user may issue `REOPEN DEC-xxx`. Reverification may generate a challenge. It must never silently mutate the frozen contract."
verification evidence: Pending.
regression guard: External Evidence Register (deliverable #14) must be maintained.
```

---

### F-032 — No narrative duplication contract

```text
ID: F-032
type: missing executable contract
severity tier: Tier 3
status: RESOLVED (this Finding Ledger notes the contract)
source/evidence: V4.7 §64 mandates: "Narrative documents may explain a contract. They must not introduce independently actionable executable values. Examples are allowed only when clearly labeled non-authoritative. Contracts are the executable truth."
affected contracts: GOV-006 (V4.7 §64)
affected files: canonical/02-decisions.md (new §Narrative Duplication Policy)
relationships:
  - conflicts_with: V4.7 §64
root cause: V4.6 had implicit but not explicit narrative-duplication policy.
decision required?: Yes — already decided by V4.7 §64.
decision ID: DEC-032
resolution: Add GOV-006 contract: narrative docs (governance, product-experience) may explain contracts but must not introduce independently actionable executable values. Examples allowed only when clearly labeled non-authoritative. Contracts are the executable truth.
verification evidence: This ledger records the contract.
regression guard: Audit assertion: narrative documents do not contain executable values not present in registered contracts.
```

---

### F-033 — `pending_revisions` referential validation not explicit

```text
ID: F-033
type: missing executable contract; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/05-implementation.md documents `pending_revisions` table but does not enforce referential validation for polymorphic entity references.
  - V4.7 §44 mandates: "Polymorphic entity references are validated at the application/domain boundary. A conventional generic PostgreSQL FK is not assumed. Historical orphaned revisions may remain for audit history. Active pending revisions must not reference invalid/deleted targets. Pending revisions are immutable after submission. Use an explicit lifecycle with: draft/submitted; stale; conflict; approved; rejected; cancelled; superseded."
affected contracts: REV-001 (V4.7 §44)
affected files: canonical/05-implementation.md (§4 schema, §5 RBAC, §Pending Revisions section)
relationships:
  - conflicts_with: V4.7 §44
  - depends_on: F-021 (self-approval prevention)
root cause: V4.6 had pending_revisions but no registered contract for polymorphic validation, immutability, or lifecycle.
decision required?: Yes — already decided by V4.7 §44.
decision ID: DEC-033
resolution: NOT YET APPLIED. Add REV-001 contract: polymorphic entity references validated at application/domain boundary (not generic PostgreSQL FK). Historical orphaned revisions may remain for audit. Active pending revisions must not reference invalid/deleted targets. Pending revisions are immutable after submission. Lifecycle: draft, submitted, stale, conflict, approved, rejected, cancelled, superseded. A newer revision may supersede an older unresolved revision per existing governance rules. Do not invent a competing revision model if V4.6 already contains one; extract and reconcile it.
verification evidence: Pending.
regression guard: CI test: pending_revision submitter attempts to mutate after submission → 409 Conflict; pending_revision references deleted target → 422 Unprocessable Entity.
```

---

### F-034 — No source priority contract

```text
ID: F-034
type: missing executable contract
severity tier: Tier 1
status: UNRESOLVED
source/evidence: V4.7 §42 mandates source priority contract. V4.6 has `priority` column on `information_sources` (mentioned in canonical/05-implementation.md:1507) but no registered contract.
affected contracts: SRC-001 (V4.7 §42), SRC-002 (V4.7 §43)
affected files: canonical/05-implementation.md (§4 schema), canonical/06-data-acquisition.md (§source priority)
relationships:
  - conflicts_with: V4.7 §42, §43
root cause: V4.6 had the column but no contract.
decision required?: Yes — already decided by V4.7 §42-§43.
decision ID: DEC-034
resolution: NOT YET APPLIED. Add SRC-001 contract: source priority is governed by a dedicated data-governance capability. Priority resolves conflicts between same-scope assertions. Source priority does not override domain scope (instance-specific policy cannot be overridden by institution-wide policy merely because the institution source has greater source priority). Priority changes affect future resolution unless explicit re-reconciliation is performed. Add SRC-002 contract: canonical precedence `instance-specific policy > institution-level policy > no applicable policy`. No implicit fabricated default admission policy. Same-scope conflicts that cannot be deterministically resolved are blocking reconciliation errors. Source priority may resolve competing assertions at the same scope.
verification evidence: Pending.
regression guard: Scenario tests S-25 (same-scope source conflict), S-26 (instance vs institution policy conflict) pass.
```

---

### F-035 — Programme-level `ProgrammeStatus` not reconciled with V4.7 ACTIVE/SUSPENDED/DISCONTINUED/DRAFT-UNPUBLISHED matrix

```text
ID: F-035
type: executable-contract contradiction; lifecycle-state defect
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - V4.6 ProgrammeStatus enum: Prospective, Admitting, Suspended, Discontinued.
  - V4.7 §49 mandates lifecycle concepts: ACTIVE, SUSPENDED, DISCONTINUED (plus publication state).
  - V4.7 §50 matrix: ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED.
  - V4.6 Prospective + Admitting both map to V4.7 ACTIVE; V4.6 has no explicit DRAFT/UNPUBLISHED state (relies on is_published=false).
  - V4.7 §49 says: "Do not resurrect a Programme-level `ProgrammeStatus` as though it were canonical admission truth." (V4.7 §35).
affected contracts: LIFE-001 (V4.7 §49), SEO-001 (V4.7 §50)
affected files: canonical/03-domain.md, canonical/05-implementation.md (ProgrammeStatus enum), product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md:863-866 (ProgrammeStatus::Admitting/Prospective/Suspended/Discontinued → "Currently admitting"/"Not yet admitting"/"Admission suspended"/"Discontinued" mapping)
relationships:
  - conflicts_with: V4.7 §49, §50
  - depends_on: F-012 (CLOSED removal), F-013 (lifecycle matrix contract)
root cause: V4.6 ProgrammeStatus (Prospective, Admitting, Suspended, Discontinued) was canonical in V4.5/V4.6 but does not directly match V4.7 §50 matrix vocabulary.
decision required?: YES — requires a DECISION to either:
  (a) keep V4.6 ProgrammeStatus as-is and document the mapping to V4.7 §50 matrix (Prospective or Admitting + is_published=true → ACTIVE; is_published=false → DRAFT/UNPUBLISHED; Suspended → SUSPENDED; Discontinued → DISCONTINUED); OR
  (b) rename ProgrammeStatus to align with V4.7 §50 vocabulary (ACTIVE, SUSPENDED, DISCONTINUED) and use is_published for DRAFT/UNPUBLISHED.
decision ID: DEC-035 (REQUIRES USER APPROVAL — see Unresolved-Material-Issues Report)
resolution: NOT YET APPLIED — BLOCKED on user decision. Recommended option: (a) keep V4.6 ProgrammeStatus enum as-is (the V4.7 §49 phrase "existing relevant lifecycle concepts" suggests preservation is acceptable) and document the explicit mapping to V4.7 §50 matrix in the new SEO-001 contract section. The "Programme-level ProgrammeStatus must not be resurrected as canonical admission truth" rule (V4.7 §35) is already respected in V4.6 — admission truth is on ProgrammeInstance, not Programme.
verification evidence: Pending user decision.
regression guard: SEO-001 matrix contract must explicitly map V4.6 ProgrammeStatus + is_published to V4.7 §50 lifecycle rows.
```

---

### F-036 — `delivery_mode` and `tuition` removed from programmes table but product-experience still references Programme-level

```text
ID: F-036
type: stale executable-fact (residual V4.5-era references)
severity tier: Tier 3
status: RESOLVED (V4.6 ARBITRATION-FINAL pass; verify no residuals)
source/evidence:
  - MANIFEST §106-108 claims V4.6 ARBITRATION-FINAL corrected product-experience files for tuition/delivery_mode ownership.
  - Direct grep confirms `Programme.tuition` and `Programme.delivery_mode` references are gone from active tier (product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md, product-experience/FIRST-VERTICAL-SLICE-UX.md now reference ProgrammeInstance).
  - However, residual `cut_off_latest` (F-010) shows that not all Programme-level projection fields were removed.
affected contracts: TYPESENSE-001 (V4.7 §33)
affected files: product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md, product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, product-experience/FIRST-VERTICAL-SLICE-UI.md
relationships:
  - supersedes: V4.5-era Programme-level tuition/delivery_mode references
  - depends_on: F-010 (cut_off_latest removal is the remaining residual)
root cause: V4.6 ARBITRATION-FINAL pass was largely complete for tuition/delivery_mode but missed cut_off_latest.
decision required?: No — already resolved except for F-010.
decision ID: N/A (F-010 covers residual)
resolution: Verified resolved for tuition/delivery_mode. Cut_off_latest residual is F-010.
verification evidence: grep for `Programme\.tuition|Programme\.delivery_mode|programmes\.tuition|programmes\.delivery_mode` in active tier returns zero matches (confirmed).
regression guard: CI grep assertion: zero matches for `Programme\.tuition|Programme\.delivery_mode` in active-tier files.
```

---

### F-037 — No `admission_policies` unique constraint documented

```text
ID: F-037
type: missing executable contract; data-integrity failure
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - V4.7 §47 explicitly lists `admission policies` in the upsert audit list. V4.6 does not document the unique constraint for admission_policies upsert.
affected contracts: UPSERT-001 (V4.7 §47)
affected files: canonical/05-implementation.md (§4 schema — admission_policies table), canonical/06-data-acquisition.md (§11 upsert targets)
relationships:
  - conflicts_with: V4.7 §47
  - depends_on: F-022 (UPSERT-001 contract)
root cause: V4.6 documented admission_policies table but not its natural-key uniqueness contract.
decision required?: Yes — already decided by V4.7 §47.
decision ID: DEC-037
resolution: NOT YET APPLIED. Document the unique constraint for `admission_policies`: `(programme_instance_id, admission_cycle_id, pathway)` UNIQUE (matches cut_off_marks pattern; pathway is the canonical field name per V4.6 MANIFEST V4.6 changes section). If polymorphism prevents a normal DB constraint, explicitly define the application-level invariant.
verification evidence: Pending.
regression guard: CI migration test: constraint exists in `pg_constraint`.
```

---

### F-038 — Inconsistent RBAC role string documentation (residual)

```text
ID: F-038
type: stale executable-fact (residual)
severity tier: Tier 3
status: RESOLVED (V4.6 ARBITRATION-FINAL pass)
source/evidence:
  - MANIFEST §77-80 claims V4.6 propagated bare role strings (owner/admin/admissions/editor/viewer) across canonical/02-decisions.md, 04-architecture.md, 05-implementation.md §5.2/§5.5/§5.6/§6.
  - Grep confirms `institution-owner|institution-admin` returns zero matches in active-tier canonical files (only historical V4.2-REMEDIATION-REPORT.md and archive/ files mention them, which is acceptable).
affected contracts: RBAC-001 (V4.7 §45)
affected files: canonical/02-decisions.md, canonical/04-architecture.md, canonical/05-implementation.md
relationships:
  - supersedes: V4.5-era institution-* role strings
root cause: V4.5 used institution-* prefixed strings; V4.6 ARBITRATION-FINAL corrected to bare strings.
decision required?: No — already resolved.
decision ID: N/A
resolution: Verified resolved.
verification evidence: grep for `institution-owner|institution-admin|institution-admissions|institution-editor|institution-viewer` in canonical/ returns zero matches (confirmed).
regression guard: CI grep assertion: zero matches for `institution-owner|institution-admin` in canonical/ files.
```

---

### F-039 — No two-engineer implementation-determinism simulation contract

```text
ID: F-039
type: missing executable contract
severity tier: Tier 2
status: RESOLVED (this remediation produces the simulation as deliverable #16)
source/evidence: V4.7 §74 mandates the simulation. No such artifact in V4.6.
affected contracts: GOV-007 (V4.7 §74)
affected files: this remediation package — deliverable #16
relationships:
  - conflicts_with: V4.7 §74
root cause: V4.6 had no simulation artifact.
decision required?: Yes — already decided by V4.7 §74.
decision ID: DEC-039
resolution: This remediation produces the Two-Independent-Engineer Simulation Report as deliverable #16.
verification evidence: Deliverable #16.
regression guard: Future remediations must reproduce the simulation.
```

---

### F-040 — `archive/28-package-verification-audit.md` contains inline HTML comments INSIDE Composer package name strings

```text
ID: F-040
type: archive contamination (acceptable per V4.7 §2, but flagged for awareness)
severity tier: Tier 3
status: FALSE-POSITIVE (per V4.7 §2 — properly labeled archive)
source/evidence:
  - archive/28-package-verification-audit.md:94, 741, 745, 843, 888-895, 949, 967, 1000, 1115 — package names appear as `bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) -->`
  - This is a historical audit artifact where corrections were embedded as inline comments inside the package name string itself.
affected contracts: ARCHIVE-001 (V4.7 §65)
affected files: archive/28-package-verification-audit.md, archive/27-final-corrected-pre-implementation-blueprint.md, archive/26-pre-implementation-reconciliation.md
relationships:
  - duplicates: F-006 (filament-shield version contradiction in active tier is the live finding; archive contamination is the historical evidence)
root cause: Earlier audit passes used inline HTML comments to record corrections; this pattern leaked into package name strings.
decision required?: No — archive is non-authoritative per V4.7 §2.
decision ID: N/A
resolution: No remediation required. Archive files are properly labeled Tier 6 Historical. The inline-comment-within-string pattern is acceptable in archive context. Ensure this pattern does NOT propagate to active tier (verified: active tier uses clean `bezhansalleh/filament-shield` strings without inline comments).
verification evidence: grep for `<!--.*Corrected.*-->` in canonical/ returns zero matches (confirmed).
regression guard: CI grep assertion: zero matches for `<!--.*Corrected.*-->` in canonical/ files (archive exempt).
```

---

### F-041 — `spatie/laravel-permission ^6.x` and other dependencies not verified against Laravel 13 / PHP 8.5

```text
ID: F-041
type: external-fact verification defect
severity tier: Tier 2
status: UNRESOLVED
source/evidence:
  - README.md:36 declares `spatie/laravel-permission ^6.x` but no verification evidence recorded.
  - V4.7 §9-§10 mandate external-fact verification for Tier 1 dependencies.
  - V4.7 §55-§56 mandate DEP-001 contract with verification source.
affected contracts: DEP-001 (V4.7 §55)
affected files: README.md, canonical/05-implementation.md (§2 package table)
relationships:
  - conflicts_with: V4.7 §9, §55, §56
  - depends_on: F-018 (DEP-001 contract)
root cause: V4.6 declared versions without recording verification evidence.
decision required?: Yes — already decided by V4.7 §9-§10, §55-§56.
decision ID: DEC-041
resolution: NOT YET APPLIED. External Evidence Register (deliverable #14) must record verification for: `spatie/laravel-permission ^6.x` (verify Packagist + GitHub — latest stable compatible with Laravel 13 + PHP 8.5); `spatie/laravel-activitylog ^5.0`; `spatie/laravel-sitemap`; `spatie/laravel-medialibrary`; `spatie/laravel-tags`; `spatie/laravel-honeypot`; `spatie/laravel-backup`; `pxlrbt/filament-activity-log v3.1.1`; `typesense/typesense-php v4+`; `devloop1024/laravel-typesense`; `livewire/flux ^2.0`; `laravel/fortify ^1.0`; `bezhansalleh/filament-shield` (version TBD per F-006).
verification evidence: Pending — External Evidence Register must be populated.
regression guard: DEP-001 contract requires verification source for every row.
```

---

### F-042 — No Typesense outage UX contract for optional search-powered components

```text
ID: F-042
type: missing executable contract
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - V4.7 §13 mandates three outage sub-contracts: (a) primary public Typesense search → explicit unavailable/search-failure state; (b) optional search-powered components → canonical page remains available, failed optional discovery component fails closed or is omitted; (c) canonical browse/detail pages → continue using PostgreSQL.
  - V4.6 MANIFEST §4.30 says "basic facets remain functional via PostgreSQL query-builder" — this is the "silent switch to PostgreSQL" V4.7 §13 forbids.
  - V4.6 has no contract for optional search-powered components (e.g., "similar/related programmes" discovery) failing closed.
affected contracts: OUTAGE-001 (V4.7 §13)
affected files: canonical/04-architecture.md (new §Typesense Outage Contract), canonical/05-implementation.md (§8 search), product-experience/FIRST-VERTICAL-SLICE-UX.md (outage UX), MANIFEST.md (§4.30 rewrite)
relationships:
  - conflicts_with: V4.7 §13
  - depends_on: F-001 (PostgreSQL FTS fallback removal)
root cause: V4.6 §4.30 framed outage as "fallback to PostgreSQL query-builder" instead of "explicit unavailable state."
decision required?: Yes — already decided by V4.7 §13.
decision ID: DEC-042
resolution: NOT YET APPLIED. Add OUTAGE-001 contract per V4.7 §13:
  (a) Primary public Typesense search: Typesense unavailable → explicit unavailable/search-failure state; do not return zero results as a disguise; do not silently switch to PostgreSQL.
  (b) Optional search-powered components: canonical page remains available; failed optional discovery component fails closed or is omitted.
  (c) Canonical browse/detail pages: continue using PostgreSQL.
  Rewrite MANIFEST §4.30 from "basic facets remain functional via PostgreSQL query-builder" to "primary public search returns explicit unavailable/search-failure state per OUTAGE-001; canonical browse/detail pages (PostgreSQL) remain available; optional discovery components fail closed or are omitted."
verification evidence: Pending.
regression guard: Scenario tests S-35 (Typesense unavailable on primary search), S-36 (Typesense unavailable on optional related-programme component) pass.
```

---

### F-043 — No admission-open aggregate field semantics contract

```text
ID: F-043
type: missing executable contract
severity tier: Tier 1
status: UNRESOLVED
source/evidence:
  - canonical/05-implementation.md mentions `is_admission_open` as a Typesense field but no contract specifying its semantics per V4.7 §34.
  - V4.7 §34 mandates: "Instance-level `instances[].is_admission_open` is authoritative for contextual filtering. A top-level aggregate `is_admission_open` may exist only as a separately defined projection concept. If present, its meaning is: 'at least one publicly searchable eligible instance is currently admission-open.' It must never be interpreted as the status of an arbitrary matched instance."
affected contracts: TYPESENSE-001 (V4.7 §34)
affected files: canonical/05-implementation.md (§8.3/§8.4 search projection fields)
relationships:
  - conflicts_with: V4.7 §34
  - depends_on: F-007 (TYPESENSE-001 contract)
root cause: V4.6 had `is_admission_open` as a top-level field without explicit semantics.
decision required?: Yes — already decided by V4.7 §34.
decision ID: DEC-043
resolution: NOT YET APPLIED. Add TYPESENSE-001 §Admission Open Semantics subsection: `instances[].is_admission_open` is authoritative for contextual filtering. Top-level `is_admission_open` is a separately defined projection concept meaning "at least one publicly searchable eligible instance is currently admission-open"; must never be interpreted as the status of an arbitrary matched instance.
verification evidence: Pending.
regression guard: CI test: search query filters by `instances[].is_admission_open` (nested) — returns only matching instances, not arbitrary programme-level match.
```

---

### F-044 — No programme result status contract

```text
ID: F-044
type: missing executable contract
severity tier: Tier 1
status: UNRESOLVED
source/evidence: V4.7 §35 mandates the contract. V4.6 has informal "Open at [Campus]" display in product-experience but no canonical contract.
affected contracts: TYPESENSE-001 (V4.7 §35)
affected files: canonical/05-implementation.md (§8.4a ProgrammeInstance Context Semantics)
relationships:
  - conflicts_with: V4.7 §35
  - depends_on: F-007, F-043
root cause: V4.6 had informal display rules without canonical contract.
decision required?: Yes — already decided by V4.7 §35.
decision ID: DEC-044
resolution: NOT YET APPLIED. Add TYPESENSE-001 §Programme Result Status contract: admission status is contextual to the matching instance set. If search context narrows to a specific instance subset → result status reflects those matching instances. If all matching instances share one state → display that state. If multiple admission states remain → display a neutral state such as "Multiple admission states." Do not apply an arbitrary precedence rule. Do not resurrect a Programme-level `ProgrammeStatus` as though it were canonical admission truth.
verification evidence: Pending.
regression guard: Scenario test S-6 (search filter matching only one instance) verifies display reflects only the matching instance's admission state.
```

---

### F-045 — `external_identifiers` unique constraint documentation

```text
ID: F-045
type: stale executable-fact (V4.6 corrected but verify propagation)
severity tier: Tier 3
status: RESOLVED (V4.6 MANIFEST §189 confirms correction)
source/evidence:
  - canonical/05-implementation.md §8.0 documents `ON CONFLICT DO UPDATE` keyed on `external_identifiers (authority_id, identifier_type, identifier) WHERE status = 'active'` (INV-EI1).
  - canonical/06-data-acquisition.md §11 documents the same.
affected contracts: UPSERT-001 (V4.7 §47)
affected files: canonical/05-implementation.md, canonical/06-data-acquisition.md
relationships:
  - duplicates: F-022 (broader UPSERT-001 audit contract)
root cause: N/A — already resolved.
decision required?: No.
decision ID: N/A
resolution: Verified resolved.
verification evidence: grep for `external_identifiers.*authority_id.*identifier_type.*identifier.*status.*active` returns matches in canonical/05-implementation.md and canonical/06-data-acquisition.md.
regression guard: Same as F-022.
```

---

### F-046 — No Typesense nested filter same-element enforcement contract

```text
ID: F-046
type: missing executable contract (V4.6 has it informally; verify propagation)
severity tier: Tier 1
status: PARTIALLY-RESOLVED (V4.6 MANIFEST §71 claims remediation; verify)
source/evidence:
  - MANIFEST §71: "Typesense filter syntax corrected from the forbidden `instances.campus:=Abuja && instances.delivery_mode:=OnCampus` (which does NOT enforce same-element semantics) to the required grouped form `instances.{campus:=Abuja && delivery_mode:=OnCampus}` (which DOES enforce same-element semantics). The full explanation, the FORBIDDEN vs CORRECT forms, and a Level-A implementation contract (concrete `ProgrammeSearchQuery` class with raw `filter_by` via Scout `options()`) are now documented in §8.3.1."
  - V4.7 §32 mandates: "Same-element nested filtering is mandatory where the UI requires multiple conditions to apply to the same ProgrammeInstance. Do not independently filter nested properties in a way that can match different array elements."
  - Verification needed: read canonical/05-implementation.md §8.3.1 to confirm the contract is in place.
affected contracts: TYPESENSE-001 (V4.7 §32)
affected files: canonical/05-implementation.md (§8.3.1)
relationships:
  - conflicts_with: V4.7 §32
  - depends_on: F-007 (TYPESENSE-001 contract)
root cause: V4.5 had the wrong filter syntax; V4.6 claims remediation.
decision required?: No — already resolved per V4.6 MANIFEST.
decision ID: N/A
resolution: Verify V4.6 §8.3.1 remediation is in place; if so, mark RESOLVED. If not, remediate.
verification evidence: Pending — read §8.3.1.
regression guard: Scenario tests S-6 (search filter matching only one instance), S-7 (mixed instances), and Case A/B/C/D-I (per MANIFEST §16) pass.
```

---

### F-047 — `archive/19-domain-architecture.md` and others reference "PostgreSQL full-text search with tsvector columns" as fallback

```text
ID: F-047
type: archive contamination (acceptable per V4.7 §2)
severity tier: Tier 3
status: FALSE-POSITIVE (properly labeled archive)
source/evidence:
  - archive/19-domain-architecture.md:874, 2007, 2062
  - archive/20-domain-architecture-validation.md:661, 1158
  - archive/21-domain-architecture-frozen-baseline.md:232, 1047, 1289, 1397
  - archive/22-post-freeze-platform-architecture-review.md:542, 1326
  - archive/23-laravel-ecosystem-build-vs-buy-review.md:303, 1363
  - archive/26-pre-implementation-reconciliation.md:926
affected contracts: N/A (archive)
affected files: 6 archive files
relationships:
  - duplicates: F-001 (active-tier PostgreSQL FTS fallback is the live finding; archive is historical evidence)
root cause: Historical architecture decisions that pre-date V4.7.
decision required?: No — archive is non-authoritative per V4.7 §2.
decision ID: N/A
resolution: No remediation. Archive files are properly labeled Tier 6 Historical.
verification evidence: Files are in `archive/` directory; archive/HISTORICAL-README.md labels them as historical.
regression guard: Per ARCHIVE-001 contract.
```

---

## Cross-Finding Relationships (graph summary)

```
F-001 (PG FTS fallback) ──depends_on──> F-002 (projection architecture)
F-001 ──conflicts_with──> V4.7 §12, §13
F-002 ──depends_on──> F-001
F-002 ──conflicts_with──> V4.7 §14-§32, §58
F-003 (HMAC approval) ──depends_on──> F-004 (artifact atomicity)
F-003 ──conflicts_with──> V4.7 §40-§41
F-004 ──conflicts_with──> V4.7 §37
F-005 (Fortify version) ──duplicates──> F-006 (Shield version)
F-006 ──depends_on──> F-041 (external verification)
F-007 (TYPESENSE-001) ──depends_on──> F-002
F-008 (SERIAL-001) ──depends_on──> F-002
F-009 (QUEUE-001) ──depends_on──> F-002, F-008
F-010 (cut_off_latest) ──depends_on──> F-007
F-011 (awaiting approval) ──conflicts_with──> V4.7 §62
F-012 (CLOSED) ──depends_on──> F-013 (lifecycle matrix), F-035 (ProgrammeStatus)
F-013 ──depends_on──> F-012, F-014
F-014 ──depends_on──> F-013
F-015 ──depends_on──> F-014
F-017 ──depends_on──> F-013
F-018 (DEP-001) ──depends_on──> F-005, F-006, F-041
F-019 (canonical_imports) ──depends_on──> F-002, F-003
F-020 (collection versioning) ──depends_on──> F-002
F-021 (RBAC self-approval) ──conflicts_with──> V4.7 §45
F-022 (UPSERT-001) ──conflicts_with──> V4.7 §47
F-023 (MIGR-001) ──depends_on──> F-002, F-019, F-022
F-024 (CACHE-001) ──depends_on──> F-002
F-026 (FVS-001) ──conflicts_with──> V4.7 §61
F-027 (GOV-002) ──conflicts_with──> V4.7 §63
F-030 (GOV-004) ──conflicts_with──> V4.7 §67
F-031 (GOV-005) ──depends_on──> F-018
F-033 (REV-001) ──depends_on──> F-021
F-034 (SRC-001) ──conflicts_with──> V4.7 §42-§43
F-035 (ProgrammeStatus) ──depends_on──> F-012, F-013
F-037 (admission_policies constraint) ──depends_on──> F-022
F-041 (external verification) ──depends_on──> F-018
F-042 (OUTAGE-001) ──depends_on──> F-001
F-043 (admission-open semantics) ──depends_on──> F-007
F-044 (programme result status) ──depends_on──> F-007, F-043
F-046 (nested filter) ──depends_on──> F-007
```

## Findings Requiring User Decisions (Blocked)

| Finding | Decision Required | Recommended Option |
|---------|-------------------|-------------------|
| F-006 | filament-shield version verification | Verify on Packagist; likely `^3.0` for Filament v5 compatibility |
| F-009 | QUEUE-001 concrete values | User must approve retries count, backoff base, timeout seconds, exception cap |
| F-012 | InstitutionStatus::Closed replacement | Rename to `Discontinued` (parallel to ProgrammeStatus) |
| F-035 | ProgrammeStatus vs V4.7 §50 matrix vocabulary | Keep V4.6 enum; document mapping in SEO-001 |

All other findings have approved decisions from the V4.7 prompt and can be mechanically remediated.

---

## Verification Evidence Summary

| Verification Step | Status | Evidence |
|-------------------|--------|----------|
| Global search for "PostgreSQL FTS fallback" in active tier | DONE — 50+ matches found across 14 files | This ledger F-001 |
| Global search for "UpdateSearchIndex listener" in active tier | DONE — 3 matches found | This ledger F-002 |
| Global search for `projection_event*` | DONE — zero matches | This ledger F-002 |
| Global search for `HMAC.*shared secret` in active tier | DONE — 1 match in canonical/06-data-acquisition.md | This ledger F-003 |
| Global search for `cut_off_latest` in active tier | DONE — 8 matches in product-experience/ | This ledger F-010 |
| Global search for `awaiting human approval` in active tier | DONE — 4 matches in product-experience/ | This ledger F-011 |
| Global search for `CLOSED` in active tier | DONE — matches in GLOSSARY, DISCOVERY-CLOSURE, product-experience | This ledger F-012 |
| Global search for `Fortify.*\^13` in active tier | DONE — 1 match in canonical/04-architecture.md | This ledger F-005 |
| Global search for `filament-shield.*v3` vs `^5.0` | DONE — contradiction confirmed | This ledger F-006 |
| Inventory of 57 files | DONE — matches V4.7 §2 expectation | MANIFEST.md File Inventory table |

---

*End of Finding Ledger. All 47 findings recorded with V4.7 §77 record format. 22 Tier-1 findings unresolved → NO-GO verdict per V4.7 §11.*
