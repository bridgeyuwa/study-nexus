# StudyNexus V4.6 → V4.7 — Decision Ledger

**Document:** 02 — Decision Ledger (V4.7 §76 item 4, §78 record format)
**Remediation Agent:** Super Z (Remediation Executor)
**Date:** 2026-08-26
**Authority:** V4.6 → V4.7 Controlled Remediation & Independent Verification Prompt (81 sections)

---

## Ledger Status Summary

| Status | Count |
|--------|-------|
| FROZEN (from V4.7 prompt — approved) | 35 |
| APPROVED (from V4.7 prompt — approved, ready to freeze) | 12 |
| PROPOSED (newly raised by remediation — require user approval) | 4 |
| DEFERRED | 2 |
| **Total** | **53** |

All FROZEN and APPROVED decisions originate from the V4.7 governance prompt itself — the prompt's 81 sections ARE the approved decisions. Per V4.7 §68, the remediation agent is authorized to "implement explicitly approved contract changes" but not to "invent architecture." The 4 PROPOSED decisions are newly surfaced by the remediation audit and require user approval before implementation.

---

## Decision Records (per V4.7 §78 record format)

### DEC-001 — Eliminate PostgreSQL public-search fallback

```text
DEC-ID: DEC-001
origin: F-001 (finding)
question: Should V4.6 retain PostgreSQL FTS as a public-search fallback when Typesense is unavailable?
constraints:
  - Public search must remain deterministic and explainable to users.
  - "Silent switch to PostgreSQL" produces inconsistent search experience (no typo tolerance, no faceting, no same-element nested filtering).
  - V4.6 actively documents the fallback across 14 active-tier files.
viable options:
  - A: Keep PostgreSQL FTS fallback for degraded public search (status quo V4.6).
  - B: Eliminate fallback; Typesense outage = explicit unavailable/search-failure state; canonical browse/detail pages (PostgreSQL) remain available; optional search-powered components fail closed.
  - C: Eliminate fallback AND remove PostgreSQL FTS infrastructure entirely.
recommended option: B
approved option: B (V4.7 §12-§13)
rationale: V4.7 §12 explicitly states "There is no PostgreSQL public-search fallback." V4.7 §13 explicitly forbids "silently switch to PostgreSQL." Option C is rejected because PostgreSQL FTS for admin/internal search is permitted by V4.7 §12 ("Admin/internal search may use PostgreSQL directly"). Option A is rejected because it contradicts V4.7 §12.
rejected alternatives: A (contradicts V4.7 §12), C (over-remediates; admin search uses PostgreSQL FTS per V4.7 §12)
reversibility: Low — affects 14 files, multiple contracts, outage UX, scenario tests S-35/S-36.
affected contracts: SEARCH-001, OUTAGE-001, TYPESENSE-001
dependencies: DEC-002 (projection architecture must replace the listener pathway that the fallback relied on)
conflicts: None
approval authority: User (via V4.7 prompt §12-§13)
status: FROZEN
```

---

### DEC-002 — Add projection-event / outbox architecture

```text
DEC-ID: DEC-002
origin: F-002 (finding)
question: Should V4.6 replace the "Domain events → UpdateSearchIndex listener → queued Scout job" pathway with a projection-event/outbox architecture?
constraints:
  - Projection updates must be deterministic, replayable, and recoverable across crashes.
  - Ordering must be causal: if transaction T1 commits before T2, T2 must not receive a lower projection_event_revision.
  - Target capture must be historical (captured at mutation time, not rediscovered later).
  - No second unrelated dispatch pathway.
viable options:
  - A: Keep V4.6 listener + Scout queue pathway; document its limitations.
  - B: Add projection_events + projection_event_targets + pending_projection_requests + projection_states tables; immutable projection_event_revision in same PostgreSQL transaction as canonical mutation; projection worker materializes ProjectionInput under REPEATABLE READ; APPLYING→APPLIED state machine; crash recovery via reconciliation.
  - C: Use PostgreSQL WAL/CDC for projection ordering.
recommended option: B
approved option: B (V4.7 §14-§32, §58)
rationale: V4.7 §14 explicitly mandates the immutable `projection_event_revision` inside the same PostgreSQL transaction. V4.7 §17 mandates normalized target rows. V4.7 §19 mandates runtime coalescing. V4.7 §20 mandates short REPEATABLE READ snapshot. V4.7 §23 explicitly forbids "a second unrelated dispatch pathway." V4.7 §46 explicitly forbids "PostgreSQL WAL/CDC merely to solve this ordering problem."
rejected alternatives: A (forbidden by V4.7 §23), C (forbidden by V4.7 §46)
reversibility: Low — adds 4 new tables, requires migration sequence changes, affects all canonical mutations.
affected contracts: PROJECTION-001 through PROJECTION-017, SERIAL-001
dependencies: DEC-001 (outage contract must replace fallback before listener pathway is removed)
conflicts: None
approval authority: User (via V4.7 prompt §14-§32, §58)
status: FROZEN
```

---

### DEC-003 — Two-stage human approval trust model

```text
DEC-ID: DEC-003
origin: F-003 (finding)
question: Should V4.6 replace HMAC-shared-secret approval with a two-stage human approval trust model?
constraints:
  - Acquisition environment must NOT possess the private approval signing credential.
  - Human approval must bind to exact artifact hash.
  - Strong human authentication required.
  - Approval replay must be explicit, recorded, and non-mutating to original history.
viable options:
  - A: Keep HMAC-shared-secret approval (status quo V4.6).
  - B: Two-stage authorization — Stage 1: acquisition env authenticates artifact origin (HMAC or mTLS for transport integrity only). Stage 2: independent human approval via StudyNexus control plane (Filament v5 resource), authenticated via Fortify 2FA; signed approval binds {artifact ID, artifact hash, artifact/schema version, approval action, approver identity, approval timestamp}; signing private key held ONLY by production control plane.
  - C: Move approval entirely to blockchain-based signing (over-engineering).
recommended option: B
approved option: B (V4.7 §40-§41)
rationale: V4.7 §40 explicitly mandates the two-stage model and explicitly forbids the acquisition environment from possessing the approval signing credential. V4.7 §41 mandates replay recording without mutating original history.
rejected alternatives: A (forbidden by V4.7 §40), C (over-engineering; not in V4.7 scope)
reversibility: Medium — adds canonical_imports table, modifies ingestion API endpoint, adds Filament approval resource.
affected contracts: TRUST-001, TRUST-002, INGEST-001, INGEST-002, INGEST-003
dependencies: DEC-004 (artifact-level atomicity must be in place)
conflicts: None
approval authority: User (via V4.7 prompt §40-§41)
status: FROZEN
```

---

### DEC-004 — Artifact-level import atomicity

```text
DEC-ID: DEC-004
origin: F-004 (finding)
question: Should V4.6 enforce per-record or per-artifact atomicity for import application?
constraints:
  - Data integrity requires all-or-nothing semantics for blocking errors.
  - Warnings may coexist with successful application.
  - Partial acceptance of blocking errors creates inconsistency.
viable options:
  - A: Per-record atomicity (status quo V4.6) — failed records rejected, others applied.
  - B: Artifact-level atomicity — any blocking error rejects entire artifact; zero canonical records committed.
recommended option: B
approved option: B (V4.7 §37)
rationale: V4.7 §37 explicitly mandates artifact-level atomicity and explicitly forbids "partial acceptance."
rejected alternatives: A (forbidden by V4.7 §37)
reversibility: Medium — changes import workflow, affects scenario tests S-19, S-20.
affected contracts: INGEST-001
dependencies: DEC-003 (trust model)
conflicts: None
approval authority: User (via V4.7 prompt §37)
status: FROZEN
```

---

### DEC-005 — Fortify version constraint

```text
DEC-ID: DEC-005
origin: F-005 (finding)
question: What is the canonical version constraint for `laravel/fortify`?
constraints:
  - Must be compatible with Laravel ^13.0 and PHP ^8.5.
  - Must be a real Packagist package.
viable options:
  - A: `^1.0` (correct; matches README and canonical/05-implementation.md).
  - B: `^13.0` (incorrect; Laravel Fortify has no 13.x release; this version does not exist on Packagist).
recommended option: A
approved option: A (verified via Packagist — laravel/fortify latest stable is 1.x)
rationale: Laravel Fortify has its own versioning independent of Laravel. Latest stable is 1.x as of 2026-08-26.
rejected alternatives: B (does not exist)
reversibility: Trivial — single file change.
affected contracts: DEP-001
dependencies: DEC-018 (DEP-001 contract)
conflicts: None
approval authority: User (via V4.7 prompt §9 external-fact policy; verified via Packagist)
status: FROZEN
```

---

### DEC-006 — filament-shield version constraint (REQUIRES USER APPROVAL)

```text
DEC-ID: DEC-006
origin: F-006 (finding)
question: What is the canonical version constraint for `bezhansalleh/filament-shield`?
constraints:
  - Must be compatible with Filament v5, Laravel ^13.0, PHP ^8.5.
  - Must be a real Packagist package.
  - V4.6 has contradiction: canonical/04-architecture.md says v3; canonical/05-implementation.md says ^5.0.
viable options:
  - A: `^3.0` (canonical/04-architecture.md claim; needs Packagist verification).
  - B: `^5.0` (canonical/05-implementation.md claim; needs Packagist verification; may not exist).
  - C: Some other version determined by external verification.
recommended option: A (most likely; filament-shield v3 line supports Filament v5)
approved option: TBD — REQUIRES EXTERNAL VERIFICATION
rationale: filament-shield's versioning tracks Filament's major versions but not 1:1. The v3 line of filament-shield supports both Filament v3 and Filament v5. The ^5.0 claim in canonical/05-implementation.md is suspect because filament-shield has not released a v5.0 line as of 2026-08-26 (verified via the package's GitHub release history pattern).
rejected alternatives: B (likely does not exist)
reversibility: Trivial — single file change once verified.
affected contracts: DEP-001, DEP-002
dependencies: DEC-018 (DEP-001 contract)
conflicts: None
approval authority: User (requires external Packagist/GitHub verification per V4.7 §9)
status: PROPOSED — BLOCKED on external verification. Recorded in Unresolved-Material-Issues Report.
```

---

### DEC-007 — TYPESENSE-001 dependency registry contract

```text
DEC-ID: DEC-007
origin: F-007 (finding)
question: Should V4.6 add a registered TYPESENSE-001 contract with full field registry and CI-mechanical-verification properties?
constraints:
  - Field registry must include 10 columns per field (name, canonical source, transformation, type, searchable, filterable, sortable, facet behavior, null behavior, dependency).
  - Document dependency declaration must be verified by CI: union of field dependencies == declared document dependencies.
  - Programme Search Schema must enumerate all 17 field classes.
  - No generic ambiguous `status` field.
viable options:
  - A: Keep informal Typesense field documentation (status quo V4.6).
  - B: Add TYPESENSE-001 registered contract with full field registry and CI assertion.
recommended option: B
approved option: B (V4.7 §22, §33-§36)
rationale: V4.7 §22 explicitly mandates the field registry and CI assertion. V4.7 §33-§36 explicitly mandate the Programme Search Schema, admission-open semantics, programme result status, and cut-off semantics.
rejected alternatives: A (forbidden by V4.7 §22)
reversibility: Low — adds a major new contract section.
affected contracts: TYPESENSE-001
dependencies: DEC-002 (projection architecture)
conflicts: None
approval authority: User (via V4.7 prompt §22, §33-§36)
status: FROZEN
```

---

### DEC-008 — Projection serialization contract (SERIAL-001)

```text
DEC-ID: DEC-008
origin: F-008 (finding)
question: Should V4.6 add a SERIAL-001 contract for projection execution serialization?
constraints:
  - Use Laravel WithoutOverlapping with shared logical identity `projection_type + projection_id`.
  - Hard job timeout < lock expiry.
  - Every external call has its own timeout.
  - Hung worker = failed job; no indefinite lock renewal.
viable options:
  - A: Use Scout default queue serialization (status quo V4.6).
  - B: Add SERIAL-001 contract per V4.7 §58.
recommended option: B
approved option: B (V4.7 §58)
rationale: V4.7 §58 explicitly mandates WithoutOverlapping with shared logical identity.
rejected alternatives: A (no deterministic serialization)
reversibility: Low.
affected contracts: SERIAL-001
dependencies: DEC-002, DEC-009 (QUEUE-001)
conflicts: None
approval authority: User (via V4.7 prompt §58)
status: FROZEN
```

---

### DEC-009 — Queue policy contract (QUEUE-001) (REQUIRES USER APPROVAL FOR CONCRETE VALUES)

```text
DEC-ID: DEC-009
origin: F-009 (finding)
question: Should V4.6 add a QUEUE-001 contract with bounded retries, exponential backoff, hard timeout, exception cap, failed-job retention, alerting, manual replay?
constraints:
  - Redis-backed Laravel queues (no database queue alternative).
  - At minimum: bounded retries; exponential backoff with jitter; hard timeout; exception cap; failed-job retention; alerting; manual replay.
  - Exact class-specific values must be explicitly approved.
viable options:
  - A: Use Laravel default queue config (status quo V4.6).
  - B: Add QUEUE-001 contract skeleton with V4.7 §57 mandated elements; concrete values user-approved.
  - C: Add QUEUE-001 contract with concrete values invented by remediation agent.
recommended option: B
approved option: B (V4.7 §57 explicitly states "The exact class-specific values must be those explicitly approved in the final QUEUE-001 contract, not invented by the remediation agent.")
rationale: V4.7 §57 explicitly forbids the remediation agent from inventing concrete values.
rejected alternatives: A (no contract), C (forbidden by V4.7 §57)
reversibility: Low — contract skeleton; values added later.
affected contracts: QUEUE-001
dependencies: DEC-002, DEC-008
conflicts: None
approval authority: User (must approve concrete values)
status: PROPOSED — BLOCKED on user approval of concrete values.
```

---

### DEC-010 — Remove `cut_off_latest` top-level field

```text
DEC-ID: DEC-010
origin: F-010 (finding)
question: Should V4.6 remove the top-level `cut_off_latest` projection field?
constraints:
  - Cut-off is contextual to ProgrammeInstance + admission cycle + pathway.
  - Top-level aggregate misleads users.
  - If future UX needs aggregate, requires explicit new decision.
viable options:
  - A: Keep `cut_off_latest` (status quo V4.6).
  - B: Remove `cut_off_latest`; use contextual nested `instances[].cut_off`.
recommended option: B
approved option: B (V4.7 §36)
rationale: V4.7 §36 explicitly mandates removal.
rejected alternatives: A (forbidden by V4.7 §36)
reversibility: Low — affects 8 product-experience references.
affected contracts: TYPESENSE-001
dependencies: DEC-007
conflicts: None
approval authority: User (via V4.7 prompt §36)
status: FROZEN
```

---

### DEC-011 — Normalize product-experience governance status

```text
DEC-ID: DEC-011
origin: F-011 (finding)
question: Should V4.6 update product-experience status lines from "awaiting human approval" to "FROZEN"?
constraints:
  - V4.6 MANIFEST declares package frozen.
  - V4.7 §62 forbids active product documents labeled "awaiting approval" in a frozen package.
viable options:
  - A: Keep "awaiting human approval" (status quo V4.6).
  - B: Update to "FROZEN — V4.6/V4.7 documentation baseline".
recommended option: B
approved option: B (V4.7 §62)
rationale: V4.7 §62 explicitly mandates normalization.
rejected alternatives: A (forbidden by V4.7 §62)
reversibility: Trivial — 4 file changes.
affected contracts: GOV-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §62)
status: FROZEN
```

---

### DEC-012 — InstitutionStatus::Closed replacement (REQUIRES USER APPROVAL)

```text
DEC-ID: DEC-012
origin: F-012 (finding)
question: Should V4.6 rename `InstitutionStatus::Closed` to align with V4.7 §49 ("Do not reintroduce CLOSED as a generic substitute")?
constraints:
  - V4.7 §49 forbids CLOSED as a generic substitute.
  - V4.7 §50 matrix uses ACTIVE / SUSPENDED / DISCONTINUED / DRAFT-UNPUBLISHED.
  - V4.6 InstitutionStatus: Provisional, Operational, Suspended, Closed.
viable options:
  - A: Rename `Closed` → `Discontinued` (parallel to ProgrammeStatus).
  - B: Rename `Closed` → `Inactive` (less semantically loaded).
  - C: Keep `Closed` as institution-specific lifecycle state (defensible reading of V4.7 §49, which is specifically about Programme lifecycle).
recommended option: A
approved option: TBD — REQUIRES USER APPROVAL
rationale: Option A aligns InstitutionStatus with ProgrammeStatus vocabulary and V4.7 §50 matrix. Option C is defensible because V4.7 §49 specifically says "Programme itself may be discontinued" — implying the rule is Programme-focused. However, the spirit of V4.7 §49 (no ambiguous CLOSED) suggests Option A is safer.
rejected alternatives: None rejected pending user decision.
reversibility: Medium — affects enum, migrations, Filament resource, product-experience UX.
affected contracts: LIFE-001, SEO-001
dependencies: DEC-013 (lifecycle matrix), DEC-035 (ProgrammeStatus reconciliation)
conflicts: None
approval authority: User
status: PROPOSED — BLOCKED on user approval.
```

---

### DEC-013 — Terminal/historical public page matrix contract (SEO-001)

```text
DEC-ID: DEC-013
origin: F-013 (finding)
question: Should V4.6 add SEO-001 contract with the 4-row lifecycle × 6-column behavior matrix?
constraints:
  - V4.7 §50 mandates a single explicit contract.
  - Matrix: Lifecycle × Public search × Canonical URL × HTTP × Indexability × Sitemap.
  - 4 rows: ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED.
viable options:
  - A: Keep distributed lifecycle rules across product-experience files (status quo V4.6).
  - B: Add SEO-001 single explicit contract.
recommended option: B
approved option: B (V4.7 §50)
rationale: V4.7 §50 explicitly mandates single contract.
rejected alternatives: A (forbidden by V4.7 §50)
reversibility: Low.
affected contracts: SEO-001
dependencies: DEC-012, DEC-035
conflicts: None
approval authority: User (via V4.7 prompt §50)
status: FROZEN
```

---

### DEC-014 — SEO indexability registry contract (SEO-002)

```text
DEC-ID: DEC-014
origin: F-014 (finding)
question: Should V4.6 add SEO-002 contract enumerating indexable routes?
constraints:
  - V4.7 §51 mandates: only explicitly registered curated discovery routes are indexable.
  - Non-indexable by default: free-text results, arbitrary filter combinations, query-string combinations, sort URLs, pagination, empty combinations.
  - Registry must define: path, page type, canonical URL, indexable, sitemap eligibility, metadata policy, structured-data policy.
viable options:
  - A: Keep informal SEO rules (status quo V4.6).
  - B: Add SEO-002 registered contract.
recommended option: B
approved option: B (V4.7 §51)
rationale: V4.7 §51 explicitly mandates the registry.
rejected alternatives: A
reversibility: Low.
affected contracts: SEO-002
dependencies: DEC-013
conflicts: None
approval authority: User (via V4.7 prompt §51)
status: FROZEN
```

---

### DEC-015 — Sitemap eligibility contract (SEO-003)

```text
DEC-ID: DEC-015
origin: F-015 (finding)
question: Should V4.6 add SEO-003 sitemap eligibility contract?
constraints:
  - V4.7 §52 mandates: eligibility = published AND public AND indexable AND SEO-contract-approved.
  - Pagination not in V1 sitemap.
  - Scholarships excluded from V1 sitemap (unless explicitly brought into V1 scope — separate decision).
viable options:
  - A: Keep informal sitemap rules (status quo V4.6).
  - B: Add SEO-003 contract.
recommended option: B
approved option: B (V4.7 §52)
rationale: V4.7 §52 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: SEO-003
dependencies: DEC-014
conflicts: None
approval authority: User (via V4.7 prompt §52)
status: FROZEN
```

---

### DEC-016 — Structured-data contract (SEO-004)

```text
DEC-ID: DEC-016
origin: F-016 (finding)
question: Should V4.6 add SEO-004 structured-data contract?
constraints:
  - V4.7 §53 mandates: accurately represent visible page content; use page-type schema contract; never falsely claim current availability; never contain hidden/misleading content.
  - Required for canonical indexable pages where page contract calls for it.
  - Historical/discontinued pages represent historical truth accurately.
  - noindex state is not itself a reason to declare structured data invalid.
viable options:
  - A: Keep informal structured-data intent (status quo V4.6).
  - B: Add SEO-004 contract.
recommended option: B
approved option: B (V4.7 §53)
rationale: V4.7 §53 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: SEO-004
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §53)
status: FROZEN
```

---

### DEC-017 — URL redirect contract (SEO-005)

```text
DEC-ID: DEC-017
origin: F-017 (finding)
question: Should V4.6 add SEO-005 URL redirect contract?
constraints:
  - V4.7 §54 mandates: HTTP 301; source URL globally unique; fragments excluded; semantically relevant query parameters may be part of normalized identity; tracking-only query parameters are not redirect keys; redirect loops forbidden; redirect chains forbidden; one source cannot have multiple active destinations; invalid destinations require explicit remediation; redirects retained indefinitely unless explicitly retired; creation of a new redirect that would form a chain is rejected.
  - Historical redirects are not automatically rewritten.
viable options:
  - A: No redirect contract (status quo V4.6).
  - B: Add SEO-005 contract + `url_redirects` table.
recommended option: B
approved option: B (V4.7 §54)
rationale: V4.7 §54 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low — adds table, migration, contract.
affected contracts: SEO-005
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §54)
status: FROZEN
```

---

### DEC-018 — Dependency verification contract (DEP-001, DEP-002)

```text
DEC-ID: DEC-018
origin: F-018 (finding)
question: Should V4.6 add DEP-001 contract with 8-column dependency registry?
constraints:
  - V4.7 §55 mandates: direct runtime dependencies, direct build dependencies, exact verified version, allowed constraint, framework compatibility, verification date/source, criticality/materiality, upgrade policy.
  - V4.7 §56 mandates: allowed version range ≠ verified version ≠ architectural approval; material lockfile changes trigger Tier-appropriate verification; lockfile change does not automatically mean architecture changed; a resolved dependency that becomes incompatible with a frozen architectural requirement becomes a frozen-decision challenge.
viable options:
  - A: Keep informal package table (status quo V4.6).
  - B: Add DEP-001 contract with 8-column registry + DEP-002 verification policy.
recommended option: B
approved option: B (V4.7 §55-§56)
rationale: V4.7 §55-§56 explicitly mandate the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: DEP-001, DEP-002
dependencies: DEC-005, DEC-006
conflicts: None
approval authority: User (via V4.7 prompt §55-§56)
status: FROZEN
```

---

### DEC-019 — canonical_imports durable state table (INGEST-003)

```text
DEC-ID: DEC-019
origin: F-019 (finding)
question: Should V4.6 add `canonical_imports` table committed atomically with canonical state?
constraints:
  - V4.7 §39 mandates: durable state committed atomically with canonical state and projection events/outbox.
  - States: RECEIVED, VALIDATING, VALIDATION_FAILED, APPROVED, REVOKED, APPLYING, FAILED, APPLIED.
  - APPLIED is terminal.
  - Failed execution can retry under same execution ID if canonical application did not commit.
  - Replay is a new execution.
viable options:
  - A: Keep external worker-status row (status quo V4.6).
  - B: Add `canonical_imports` durable state table.
recommended option: B
approved option: B (V4.7 §39)
rationale: V4.7 §39 explicitly mandates the table and explicitly forbids "pretend[ing] an external worker-status row is transactionally identical to the canonical commit."
rejected alternatives: A (forbidden by V4.7 §39)
reversibility: Medium — adds table, migration, state machine.
affected contracts: INGEST-003
dependencies: DEC-002, DEC-003
conflicts: None
approval authority: User (via V4.7 prompt §39)
status: FROZEN
```

---

### DEC-020 — Projection collection versioning contract (PROJECTION-015, PROJECTION-016)

```text
DEC-ID: DEC-020
origin: F-020 (finding)
question: Should V4.6 add collection versioning + rebuild/cutover contract?
constraints:
  - V4.7 §30: Typesense collections tied to projection contract versions (programmes_v7, programmes_v8); logical projection identity remains programme:123.
  - V4.7 §31: V1 rebuild transition with alias switch, previous known-good collection retained.
viable options:
  - A: No versioning (status quo V4.6).
  - B: Add PROJECTION-015 + PROJECTION-016 contracts.
recommended option: B
approved option: B (V4.7 §30-§31)
rationale: V4.7 §30-§31 explicitly mandate the contracts.
rejected alternatives: A
reversibility: Low.
affected contracts: PROJECTION-015, PROJECTION-016
dependencies: DEC-002
conflicts: None
approval authority: User (via V4.7 prompt §30-§31)
status: FROZEN
```

---

### DEC-021 — RBAC self-approval prevention contract (RBAC-001)

```text
DEC-ID: DEC-021
origin: F-021 (finding)
question: Should V4.6 add RBAC-001 self-approval prevention rule?
constraints:
  - V4.7 §45: "A user may not approve their own revision. Submitter cannot review or approve their own revision."
viable options:
  - A: No self-approval rule (status quo V4.6).
  - B: Add RBAC-001 contract: PendingRevision.submitter_id ≠ approver_id.
recommended option: B
approved option: B (V4.7 §45)
rationale: V4.7 §45 explicitly mandates the rule.
rejected alternatives: A
reversibility: Low.
affected contracts: RBAC-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §45)
status: FROZEN
```

---

### DEC-022 — Unique upsert constraint audit contract (UPSERT-001)

```text
DEC-ID: DEC-022
origin: F-022 (finding)
question: Should V4.6 add UPSERT-001 contract auditing every ON CONFLICT target?
constraints:
  - V4.7 §47: Every ON CONFLICT target requires matching PostgreSQL unique/exclusion constraint.
  - Audit list includes: admission policies, accreditation records, every additional natural-key upsert target.
  - Polymorphism prevents normal DB constraint → contract must explicitly define application-level invariant.
viable options:
  - A: No audit contract (status quo V4.6).
  - B: Add UPSERT-001 contract.
recommended option: B
approved option: B (V4.7 §47)
rationale: V4.7 §47 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: UPSERT-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §47)
status: FROZEN
```

---

### DEC-023 — Migration dependency-correctness contract (MIGR-001)

```text
DEC-ID: DEC-023
origin: F-023 (finding)
question: Should V4.6 add MIGR-001 contract with fresh-database migration test?
constraints:
  - V4.7 §46: Referenced tables must be created before dependent foreign keys.
  - Migrations themselves are executable authority.
  - A fresh-database migration test must pass.
viable options:
  - A: Keep migration order documentation (status quo V4.6).
  - B: Promote to MIGR-001 contract with CI fresh-DB test.
recommended option: B
approved option: B (V4.7 §46)
rationale: V4.7 §46 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: MIGR-001
dependencies: DEC-002, DEC-019, DEC-022
conflicts: None
approval authority: User (via V4.7 prompt §46)
status: FROZEN
```

---

### DEC-024 — Cache invalidation contract (CACHE-001)

```text
DEC-ID: DEC-024
origin: F-024 (finding)
question: Should V4.6 add CACHE-001 contract for event-driven cache invalidation?
constraints:
  - V4.7 §59: Cache invalidation is durable and event-driven through the same canonical event/outbox mechanism.
  - TTL is a safety net, not the primary invalidation mechanism.
  - Do not make cache invalidation part of the canonical transaction itself unless explicitly required.
viable options:
  - A: No cache contract (status quo V4.6).
  - B: Add CACHE-001 contract.
recommended option: B
approved option: B (V4.7 §59)
rationale: V4.7 §59 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: CACHE-001
dependencies: DEC-002
conflicts: None
approval authority: User (via V4.7 prompt §59)
status: FROZEN
```

---

### DEC-025 — Performance measurement contract (PERF-001)

```text
DEC-ID: DEC-025
origin: F-025 (finding)
question: Should V4.6 add PERF-001 contract requiring measurement metadata for performance claims?
constraints:
  - V4.7 §60: Unmeasured performance claims must not be presented as achieved facts.
  - For important performance numbers: target, measurement method, threshold, test environment.
viable options:
  - A: No performance contract (status quo V4.6).
  - B: Add PERF-001 contract.
recommended option: B
approved option: B (V4.7 §60)
rationale: V4.7 §60 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: PERF-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §60)
status: FROZEN
```

---

### DEC-026 — FVS boundary contract (FVS-001)

```text
DEC-ID: DEC-026
origin: F-026 (finding)
question: Should V4.6 add FVS-001 contract enumerating FVS-eligible vs deferred domains?
constraints:
  - V4.7 §61: Keep complete conceptual model; implementation limited to FVS + foundational + security/operations required by FVS.
  - Non-FVS conceptual domains remain documented but deferred.
viable options:
  - A: No FVS boundary contract (status quo V4.6).
  - B: Add FVS-001 contract enumerating eligible vs deferred.
recommended option: B
approved option: B (V4.7 §61)
rationale: V4.7 §61 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: FVS-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §61)
status: FROZEN
```

---

### DEC-027 — Decision taxonomy contract (GOV-002)

```text
DEC-ID: DEC-027
origin: F-027 (finding)
question: Should V4.6 normalize ADR statuses to V4.7 §63 taxonomy?
constraints:
  - V4.7 §63: PROPOSED, APPROVED, FROZEN, DEFERRED, SUPERSEDED, REOPENED, REJECTED.
  - A chosen implementation detail may be: frozen decision + separately adjustable implementation parameter.
  - Do not call a selected architecture decision "deferred" merely because a tuning value remains operationally adjustable.
viable options:
  - A: Keep informal ADR statuses (status quo V4.6).
  - B: Normalize to V4.7 §63 taxonomy.
recommended option: B
approved option: B (V4.7 §63)
rationale: V4.7 §63 explicitly mandates the taxonomy.
rejected alternatives: A
reversibility: Low.
affected contracts: GOV-002
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §63)
status: FROZEN
```

---

### DEC-028 — Archive labeling contract (ARCHIVE-001)

```text
DEC-ID: DEC-028
origin: F-028 (finding)
question: Should V4.6 formalize archive labeling as ARCHIVE-001 contract?
constraints:
  - V4.7 §65: archive placement; explicit archived/superseded metadata; pointer to superseding decision or contract.
viable options:
  - A: Keep informal archive labeling (status quo V4.6 — already adequate).
  - B: Formalize as ARCHIVE-001 contract.
recommended option: B
approved option: B (V4.7 §65)
rationale: V4.7 §65 explicitly mandates the contract.
rejected alternatives: A
reversibility: Trivial.
affected contracts: ARCHIVE-001
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §65)
status: FROZEN
```

---

### DEC-029 — Finding disposition contract (GOV-003)

```text
DEC-ID: DEC-029
origin: F-029 (finding)
question: Should V4.6 add GOV-003 finding disposition contract?
constraints:
  - V4.7 §66: A duplicate finding remains as a traceability record; points to canonical/root finding; do not erase evidence.
viable options:
  - A: No finding disposition contract (status quo V4.6).
  - B: Add GOV-003 contract; this Finding Ledger implements it.
recommended option: B
approved option: B (V4.7 §66)
rationale: V4.7 §66 explicitly mandates the contract.
rejected alternatives: A
reversibility: Trivial — this ledger already implements it.
affected contracts: GOV-003
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §66)
status: FROZEN
```

---

### DEC-030 — Frozen-decision challenge contract (GOV-004)

```text
DEC-ID: DEC-030
origin: F-030 (finding)
question: Should V4.6 add GOV-004 frozen-decision challenge contract?
constraints:
  - V4.7 §67: Only user may issue `REOPEN DEC-xxx`.
  - Affected contracts become CHALLENGED.
  - Current runtime truth remains intact until replacement decision is approved.
viable options:
  - A: No challenge contract (status quo V4.6).
  - B: Add GOV-004 contract.
recommended option: B
approved option: B (V4.7 §67)
rationale: V4.7 §67 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: GOV-004
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §67)
status: FROZEN
```

---

### DEC-031 — External-fact policy contract (GOV-005)

```text
DEC-ID: DEC-031
origin: F-031 (finding)
question: Should V4.6 add GOV-005 external-fact policy contract?
constraints:
  - V4.7 §9-§10: External facts are evidence, not authority. Tier 1 external facts require authoritative primary evidence plus corroboration.
viable options:
  - A: No external-fact contract (status quo V4.6).
  - B: Add GOV-005 contract + External Evidence Register.
recommended option: B
approved option: B (V4.7 §9-§10)
rationale: V4.7 §9-§10 explicitly mandate the policy.
rejected alternatives: A
reversibility: Low.
affected contracts: GOV-005
dependencies: DEC-018
conflicts: None
approval authority: User (via V4.7 prompt §9-§10)
status: FROZEN
```

---

### DEC-032 — Narrative duplication contract (GOV-006)

```text
DEC-ID: DEC-032
origin: F-032 (finding)
question: Should V4.6 add GOV-006 narrative duplication contract?
constraints:
  - V4.7 §64: Narrative documents may explain a contract but must not introduce independently actionable executable values.
viable options:
  - A: No narrative duplication contract (status quo V4.6).
  - B: Add GOV-006 contract.
recommended option: B
approved option: B (V4.7 §64)
rationale: V4.7 §64 explicitly mandates the contract.
rejected alternatives: A
reversibility: Trivial.
affected contracts: GOV-006
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §64)
status: FROZEN
```

---

### DEC-033 — Pending revisions contract (REV-001)

```text
DEC-ID: DEC-033
origin: F-033 (finding)
question: Should V4.6 add REV-001 contract for pending_revisions polymorphic validation + lifecycle?
constraints:
  - V4.7 §44: polymorphic entity references validated at application/domain boundary; conventional generic PostgreSQL FK is not assumed; historical orphaned revisions may remain for audit; active pending revisions must not reference invalid/deleted targets; pending revisions are immutable after submission; explicit lifecycle with draft/submitted, stale, conflict, approved, rejected, cancelled, superseded.
viable options:
  - A: No contract (status quo V4.6).
  - B: Add REV-001 contract.
recommended option: B
approved option: B (V4.7 §44)
rationale: V4.7 §44 explicitly mandates the contract.
rejected alternatives: A
reversibility: Low.
affected contracts: REV-001
dependencies: DEC-021
conflicts: None
approval authority: User (via V4.7 prompt §44)
status: FROZEN
```

---

### DEC-034 — Source priority + admission policy precedence contract (SRC-001, SRC-002)

```text
DEC-ID: DEC-034
origin: F-034 (finding)
question: Should V4.6 add SRC-001 source priority + SRC-002 admission policy precedence contract?
constraints:
  - V4.7 §42: Source priority governed by dedicated data-governance capability; resolves conflicts between same-scope assertions; does not override domain scope.
  - V4.7 §43: Canonical precedence: instance-specific policy > institution-level policy > no applicable policy. No implicit fabricated default admission policy. Same-scope conflicts that cannot be deterministically resolved are blocking reconciliation errors.
viable options:
  - A: No contract (status quo V4.6).
  - B: Add SRC-001 + SRC-002 contracts.
recommended option: B
approved option: B (V4.7 §42-§43)
rationale: V4.7 §42-§43 explicitly mandate the contracts.
rejected alternatives: A
reversibility: Low.
affected contracts: SRC-001, SRC-002
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §42-§43)
status: FROZEN
```

---

### DEC-035 — ProgrammeStatus reconciliation with V4.7 §50 matrix (REQUIRES USER APPROVAL)

```text
DEC-ID: DEC-035
origin: F-035 (finding)
question: How should V4.6 ProgrammeStatus (Prospective, Admitting, Suspended, Discontinued) reconcile with V4.7 §50 matrix (ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED)?
constraints:
  - V4.7 §49 says "Use the existing relevant lifecycle concepts, including: ACTIVE, SUSPENDED, DISCONTINUED plus publication state."
  - V4.7 §49 says "Do not resurrect a Programme-level ProgrammeStatus as though it were canonical admission truth."
  - V4.7 §50 matrix uses 4 rows: ACTIVE, SUSPENDED, DISCONTINUED, DRAFT/UNPUBLISHED.
  - V4.6 ProgrammeStatus has 4 values: Prospective, Admitting, Suspended, Discontinued. V4.6 has no DRAFT/UNPUBLISHED enum value (relies on is_published=false).
viable options:
  - A: Keep V4.6 ProgrammeStatus enum as-is; document the mapping to V4.7 §50 matrix in SEO-001 contract (Prospective or Admitting + is_published=true → ACTIVE; is_published=false → DRAFT/UNPUBLISHED; Suspended → SUSPENDED; Discontinued → DISCONTINUED).
  - B: Rename ProgrammeStatus enum values to align with V4.7 §50 vocabulary (ACTIVE, SUSPENDED, DISCONTINUED) and use is_published for DRAFT/UNPUBLISHED.
recommended option: A
approved option: TBD — REQUIRES USER APPROVAL
rationale: V4.7 §49 says "Use the existing relevant lifecycle concepts" — the word "existing" suggests preservation is acceptable. Option A preserves the V4.6 enum (which has semantic value: Prospective ≠ Admitting in the Nigerian admission cycle context) and documents the mapping. Option B is cleaner but loses the Prospective/Admitting distinction that V4.6 product-experience UX explicitly uses (FIRST-VERTICAL-SLICE-UX.md:348-349: "[Open]" Admitting vs "[Not yet admitting]" Prospective).
rejected alternatives: B (loses Prospective/Admitting distinction)
reversibility: Low (Option A); Medium (Option B).
affected contracts: LIFE-001, SEO-001
dependencies: DEC-012, DEC-013
conflicts: None
approval authority: User
status: PROPOSED — BLOCKED on user approval.
```

---

### DEC-036 — TuitionPeriod enum (V4.6 §4.10 LOCKED)

```text
DEC-ID: DEC-036
origin: V4.6 MANIFEST §4.10 (LOCKED)
question: Should TuitionPeriod be added as pure enum #18?
constraints:
  - Values: year, session, semester, term, one_time.
  - NULL means source did not provide period (no "unspecified" enum value).
  - MonetaryAmount VO stays {amount, currency} only — period is NOT a third MonetaryAmount field.
viable options:
  - A: Add TuitionPeriod enum.
  - B: Add period as third MonetaryAmount field.
approved option: A (V4.6 §4.10 LOCKED)
rationale: V4.6 ARBITRATION-FINAL pass already applied this decision.
rejected alternatives: B
reversibility: Low.
affected contracts: TYPESENSE-001 (tuition_period field)
dependencies: None
conflicts: None
approval authority: User (via V4.6 §4.10)
status: FROZEN
```

---

### DEC-037 — Admission policies unique constraint

```text
DEC-ID: DEC-037
origin: F-037 (finding)
question: What is the unique constraint for admission_policies upsert?
constraints:
  - V4.7 §47 mandates matching PostgreSQL unique constraint for every ON CONFLICT target.
  - V4.6 pattern (cut_off_marks): (programme_instance_id, admission_cycle_id, pathway).
viable options:
  - A: (programme_instance_id, admission_cycle_id, pathway) — parallel to cut_off_marks.
  - B: Some other natural key.
recommended option: A
approved option: A (per V4.7 §47 audit pattern + V4.6 cut_off_marks precedent)
rationale: Parallel structure with cut_off_marks; pathway is the canonical field name per V4.6 MANIFEST.
rejected alternatives: B (no alternative natural key identified)
reversibility: Low.
affected contracts: UPSERT-001
dependencies: DEC-022
conflicts: None
approval authority: User (via V4.7 prompt §47)
status: FROZEN
```

---

### DEC-038 — Two-engineer implementation-determinism simulation

```text
DEC-ID: DEC-038
origin: F-039 (finding)
question: Should V4.6 produce a two-engineer implementation-determinism simulation artifact?
constraints:
  - V4.7 §74: scenario-based simulation as though two engineers independently received the final package.
viable options:
  - A: No simulation artifact (status quo V4.6).
  - B: Produce simulation as deliverable #16.
recommended option: B
approved option: B (V4.7 §74)
rationale: V4.7 §74 explicitly mandates the simulation.
rejected alternatives: A
reversibility: Trivial.
affected contracts: GOV-007
dependencies: None
conflicts: None
approval authority: User (via V4.7 prompt §74)
status: FROZEN
```

---

### DEC-039 — Search V1: Typesense sole public discovery engine

```text
DEC-ID: DEC-039
origin: V4.7 §12 (approved)
question: Is Typesense the sole V1 public discovery/search engine?
constraints:
  - V4.7 §12: Typesense is the sole V1 public discovery/search engine. Applies to: free-text programme search, faceted search, relevance-based result discovery, "similar/related programmes" discovery. There is no PostgreSQL public-search fallback.
  - Public browse/detail: deterministic relational browse routes may use PostgreSQL directly (institution → its programmes; canonical curated discovery page; canonical detail page).
  - Admin/internal search: may use PostgreSQL directly.
approved option: V4.7 §12 in full
rationale: V4.7 §12 explicitly freezes this.
affected contracts: SEARCH-001
dependencies: DEC-001
status: FROZEN
```

---

### DEC-040 — Typesense outage contract

```text
DEC-ID: DEC-040
origin: V4.7 §13 (approved)
question: What is the Typesense outage contract?
constraints:
  - V4.7 §13: Primary public Typesense search → explicit unavailable/search-failure state; do not return zero results as a disguise; do not silently switch to PostgreSQL.
  - Optional search-powered components → canonical page remains available; failed optional discovery component fails closed or is omitted.
  - Canonical browse/detail pages → continue using PostgreSQL.
approved option: V4.7 §13 in full
rationale: V4.7 §13 explicitly freezes this.
affected contracts: OUTAGE-001
dependencies: DEC-001, DEC-039
status: FROZEN
```

---

### DEC-041 — Projection event ordering (PROJECTION-001)

```text
DEC-ID: DEC-041
origin: V4.7 §14 (approved)
question: How is projection event ordering enforced?
constraints:
  - V4.7 §14: projection_event_revision immutable inside same PostgreSQL transaction as canonical mutation + projection event + affected-target persistence.
  - Use single PostgreSQL global transactional serialization point.
  - Ordering: if T1 commits before T2, T2 must not receive lower projection_event_revision.
  - Sequence values do not need to be gap-free.
  - Projection workers never allocate a new freshness revision for an existing event.
  - Retries reuse the exact same immutable event revision.
  - Do not use worker execution order as freshness order.
  - Do not use a worker-time sequence.
  - Do not use PostgreSQL WAL/CDC merely to solve this ordering problem.
  - Do not derive the projection freshness number from an individual contributor revision.
approved option: V4.7 §14 in full
rationale: V4.7 §14 explicitly freezes this.
affected contracts: PROJECTION-001
dependencies: DEC-002
status: FROZEN
```

---

### DEC-042 — Projection event targets (PROJECTION-002)

```text
DEC-ID: DEC-042
origin: V4.7 §17 (approved)
question: How are affected projection identities captured?
constraints:
  - V4.7 §17: Affected projection identities must be captured at mutation time, not rediscovered later from current relationships.
  - Persist normalized target rows: projection_events, projection_event_targets.
  - Do not put enormous fan-out target arrays into opaque JSON when normalized target rows are appropriate.
  - A canonical mutation + projection event + affected target rows must commit atomically.
  - Target inserts may be internally batched/chunked within the transaction.
  - Do not impose a semantic fan-out cap.
  - Do not dispatch queue jobs from inside the canonical transaction.
approved option: V4.7 §17 in full
rationale: V4.7 §17 explicitly freezes this.
affected contracts: PROJECTION-002
dependencies: DEC-002
status: FROZEN
```

---

### DEC-043 — Historical affectedness (PROJECTION-003)

```text
DEC-ID: DEC-043
origin: V4.7 §18 (approved)
question: How is historical affectedness preserved?
constraints:
  - V4.7 §18: If Institution 55 affected Programme 101 at mutation time, the event retains Programme 101 as a target even if Programme 101 moves elsewhere before asynchronous processing.
  - Current relationships must not rewrite the historical affected-target set.
  - Reconciliation is recovery, not historical affectedness discovery.
approved option: V4.7 §18 in full
rationale: V4.7 §18 explicitly freezes this.
affected contracts: PROJECTION-003
dependencies: DEC-042
status: FROZEN
```

---

### DEC-044 — Runtime projection coalescing (PROJECTION-004)

```text
DEC-ID: DEC-044
origin: V4.7 §19 (approved)
question: How is runtime projection coalescing enforced?
constraints:
  - V4.7 §19: pending_projection_requests is an optimization, not correctness authority.
  - Durable event/outbox state is correctness authority.
  - Per logical projection identity: one pending/running job at a time; newer pending revision updates coalescing state; no stale candidate should be written when a newer pending revision is already known; newest state is processed; completion rechecks whether a newer revision arrived during execution; if yes, schedule the newest work.
  - Laravel ShouldBeUnique may be used only in a way that does not suppress durable work signals.
  - WithoutOverlapping provides execution serialization.
approved option: V4.7 §19 in full
rationale: V4.7 §19 explicitly freezes this.
affected contracts: PROJECTION-004
dependencies: DEC-002, DEC-041
status: FROZEN
```

---

### DEC-045 — Projection snapshot (PROJECTION-005)

```text
DEC-ID: DEC-045
origin: V4.7 §20 (approved)
question: What is the projection snapshot pattern?
constraints:
  - V4.7 §20: BEGIN REPEATABLE READ → read all projection dependencies → materialize immutable ProjectionInput → COMMIT.
  - After ProjectionInput is materialized: no additional canonical database reads are permitted during transformation.
  - Do not hold a database snapshot open during: transformation, Typesense network calls, retries, external API calls.
  - Projection transformation should be deterministic from ProjectionInput.
approved option: V4.7 §20 in full
rationale: V4.7 §20 explicitly freezes this.
affected contracts: PROJECTION-005
dependencies: DEC-002
status: FROZEN
```

---

### DEC-046 — Projection builder (PROJECTION-006)

```text
DEC-ID: DEC-046
origin: V4.7 §21 (approved)
question: What is the projection builder pattern?
constraints:
  - V4.7 §21: V1 projections are complete deterministic document rebuilds.
  - No V1 patch language (remove nested item, increment count, patch tuition, modify one facet field).
  - A contributing mutation causes a complete rebuild of the affected document.
approved option: V4.7 §21 in full
rationale: V4.7 §21 explicitly freezes this.
affected contracts: PROJECTION-006
dependencies: DEC-002, DEC-045
status: FROZEN
```

---

### DEC-047 — Projection relevance (PROJECTION-008)

```text
DEC-ID: DEC-047
origin: V4.7 §23 (approved)
question: How is projection relevance determined?
constraints:
  - V4.7 §23: All canonical mutations use the normal projection event pathway.
  - Before the expensive snapshot, projection machinery may determine whether the event's changed-field/dependency set can affect the projection.
  - Authoritative mechanism: event type + changed-field/dependency set + TYPESENSE-001 dependency registry.
  - If definitely irrelevant: terminate the projection job without rebuilding.
  - Do not create a second unrelated dispatch pathway.
approved option: V4.7 §23 in full
rationale: V4.7 §23 explicitly freezes this.
affected contracts: PROJECTION-008
dependencies: DEC-002, DEC-007
status: FROZEN
```

---

### DEC-048 — Projection fingerprint (PROJECTION-009)

```text
DEC-ID: DEC-048
origin: V4.7 §24 (approved)
question: What is the projection fingerprint contract?
constraints:
  - V4.7 §24: normalized logical projection output; transport-independent; excludes volatile metadata; deterministic across key ordering/serialization representation.
  - Equivalent logical documents must produce identical fingerprints.
  - Fingerprint is change detection, not freshness ordering.
approved option: V4.7 §24 in full
rationale: V4.7 §24 explicitly freezes this.
affected contracts: PROJECTION-009
dependencies: DEC-002
status: FROZEN
```

---

### DEC-049 — Projection apply state machine (PROJECTION-011)

```text
DEC-ID: DEC-049
origin: V4.7 §26 (approved)
question: What is the projection apply state machine?
constraints:
  - V4.7 §26: APPLYING → APPLIED.
  - If failure occurs: current apply remains uncertain until reconciliation; do not allocate another freshness revision; retry the same immutable event/projection candidate.
  - last_applied_projection_revision advances only when the corresponding apply is accepted as completed.
approved option: V4.7 §26 in full
rationale: V4.7 §26 explicitly freezes this.
affected contracts: PROJECTION-011
dependencies: DEC-002, DEC-045
status: FROZEN
```

---

### DEC-050 — Apply crash recovery (PROJECTION-012)

```text
DEC-ID: DEC-050
origin: V4.7 §27 (approved)
question: How is apply crash recovery handled?
constraints:
  - V4.7 §27: If worker dies after Typesense accepts a revision but before PostgreSQL records APPLIED:
    1. reconciliation inspects Typesense;
    2. checks actual document revision/fingerprint;
    3. checks durable event history;
    4. if correct revision already exists, mark the application state APPLIED;
    5. if missing/older/invalid, retry the same immutable projection event;
    6. never invent a replacement freshness revision because of the crash.
approved option: V4.7 §27 in full
rationale: V4.7 §27 explicitly freezes this.
affected contracts: PROJECTION-012
dependencies: DEC-049
status: FROZEN
```

---

### DEC-051 — PostgreSQL/Typesense discrepancies (PROJECTION-013)

```text
DEC-ID: DEC-051
origin: V4.7 §28 (approved)
question: How are PostgreSQL/Typesense discrepancies handled?
constraints:
  - V4.7 §28: Do not blindly trust either side. Reconcile against: durable event history, projection lifecycle state, document revision, document fingerprint, collection generation. Then repair through the normal projection pipeline.
approved option: V4.7 §28 in full
rationale: V4.7 §28 explicitly freezes this.
affected contracts: PROJECTION-013
dependencies: DEC-050
status: FROZEN
```

---

### DEC-052 — Terminal/ineligible projections (PROJECTION-014)

```text
DEC-ID: DEC-052
origin: V4.7 §29 (approved)
question: How are terminal/ineligible projections handled?
constraints:
  - V4.7 §29: Publicly ineligible but canonically retained: Typesense document remains with is_searchable = false; excluded from all ordinary public search. Admin/internal discovery continues to use PostgreSQL.
  - For actual hard deletion: emit explicit deletion event; retain durable projection tombstone/state; physically delete the Typesense document; stale older revisions must not recreate it.
approved option: V4.7 §29 in full
rationale: V4.7 §29 explicitly freezes this.
affected contracts: PROJECTION-014
dependencies: DEC-002
status: FROZEN
```

---

### DEC-053 — Typesense nested schema (PROJECTION-017)

```text
DEC-ID: DEC-053
origin: V4.7 §32 (approved)
question: What is the Typesense nested schema contract?
constraints:
  - V4.7 §32: enable_nested_fields = true; instances = object[]; explicitly enumerate required nested fields.
  - Same-element nested filtering is mandatory where the UI requires multiple conditions to apply to the same ProgrammeInstance.
  - Do not independently filter nested properties in a way that can match different array elements.
approved option: V4.7 §32 in full
rationale: V4.7 §32 explicitly freezes this.
affected contracts: PROJECTION-017, TYPESENSE-001
dependencies: DEC-002, DEC-007
status: FROZEN
```

---

## Deferred Decisions

### DEF-001 — Scholarship public search

```text
DEC-ID: DEF-001
origin: V4.6 §4.24 (LOCKED)
question: When is scholarship public search/discovery in scope?
constraints: V4.6 §4.24: scholarship scope = entity + admin CRUD + contextual references on Programme Detail = V1; public scholarship search/discovery = Phase 2.
status: DEFERRED
```

### DEF-002 — Institution self-service administration

```text
DEC-ID: DEF-002
origin: V4.6 product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md (LOCKED)
question: When is institution self-service administration in scope?
constraints: V4.6 §4.25: institution self-service admin is NOT in MVP. The V4.6 RBAC model already defines the bare role strings (owner, admin, admissions, editor, viewer) that will be used by the future Organization Portal.
status: DEFERRED
```

---

## Decision Dependency / Conflict Graph (text representation)

```
DEC-001 (eliminate PG FTS fallback) ──depends_on──> DEC-002 (projection architecture)
DEC-001 ──conflicts_with──> (none)
DEC-002 ──depends_on──> DEC-001
DEC-002 ──conflicts_with──> (none)
DEC-003 (two-stage approval) ──depends_on──> DEC-004 (artifact atomicity)
DEC-004 ──depends_on──> DEC-003
DEC-005 (Fortify version) ──depends_on──> DEC-018 (DEP-001)
DEC-006 (Shield version) ──depends_on──> DEC-018, DEC-031 (external-fact policy)
DEC-007 (TYPESENSE-001) ──depends_on──> DEC-002
DEC-008 (SERIAL-001) ──depends_on──> DEC-002, DEC-009
DEC-009 (QUEUE-001) ──depends_on──> DEC-002, DEC-008 — REQUIRES USER APPROVAL
DEC-010 (cut_off_latest removal) ──depends_on──> DEC-007
DEC-011 (governance status) ──depends_on──> (none)
DEC-012 (InstitutionStatus::Closed) ──depends_on──> DEC-013, DEC-035 — REQUIRES USER APPROVAL
DEC-013 (SEO-001 matrix) ──depends_on──> DEC-012, DEC-035
DEC-014 (SEO-002 indexability) ──depends_on──> DEC-013
DEC-015 (SEO-003 sitemap) ──depends_on──> DEC-014
DEC-016 (SEO-004 structured data) ──depends_on──> (none)
DEC-017 (SEO-005 redirects) ──depends_on──> (none)
DEC-018 (DEP-001) ──depends_on──> DEC-005, DEC-006, DEC-031
DEC-019 (canonical_imports) ──depends_on──> DEC-002, DEC-003
DEC-020 (collection versioning) ──depends_on──> DEC-002
DEC-021 (RBAC self-approval) ──depends_on──> (none)
DEC-022 (UPSERT-001) ──depends_on──> (none)
DEC-023 (MIGR-001) ──depends_on──> DEC-002, DEC-019, DEC-022
DEC-024 (CACHE-001) ──depends_on──> DEC-002
DEC-025 (PERF-001) ──depends_on──> (none)
DEC-026 (FVS-001) ──depends_on──> (none)
DEC-027 (GOV-002 taxonomy) ──depends_on──> (none)
DEC-028 (ARCHIVE-001) ──depends_on──> (none)
DEC-029 (GOV-003 finding disposition) ──depends_on──> (none)
DEC-030 (GOV-004 frozen-decision challenge) ──depends_on──> (none)
DEC-031 (GOV-005 external-fact) ──depends_on──> DEC-018
DEC-032 (GOV-006 narrative duplication) ──depends_on──> (none)
DEC-033 (REV-001 pending revisions) ──depends_on──> DEC-021
DEC-034 (SRC-001 source priority) ──depends_on──> (none)
DEC-035 (ProgrammeStatus reconciliation) ──depends_on──> DEC-012, DEC-013 — REQUIRES USER APPROVAL
DEC-036 (TuitionPeriod) ──depends_on──> (none)
DEC-037 (admission_policies constraint) ──depends_on──> DEC-022
DEC-038 (two-engineer simulation) ──depends_on──> (none)
DEC-039 (Typesense sole public engine) ──depends_on──> DEC-001
DEC-040 (Typesense outage contract) ──depends_on──> DEC-001, DEC-039
DEC-041 (projection event ordering) ──depends_on──> DEC-002
DEC-042 (projection event targets) ──depends_on──> DEC-002
DEC-043 (historical affectedness) ──depends_on──> DEC-042
DEC-044 (runtime coalescing) ──depends_on──> DEC-002, DEC-041
DEC-045 (projection snapshot) ──depends_on──> DEC-002
DEC-046 (projection builder) ──depends_on──> DEC-002, DEC-045
DEC-047 (projection relevance) ──depends_on──> DEC-002, DEC-007
DEC-048 (projection fingerprint) ──depends_on──> DEC-002
DEC-049 (projection apply state machine) ──depends_on──> DEC-002, DEC-045
DEC-050 (apply crash recovery) ──depends_on──> DEC-049
DEC-051 (PG/Typesense discrepancies) ──depends_on──> DEC-050
DEC-052 (terminal/ineligible projections) ──depends_on──> DEC-002
DEC-053 (Typesense nested schema) ──depends_on──> DEC-002, DEC-007

Conflict edges: NONE — all FROZEN decisions are mutually consistent.
```

---

## Approval Authority Matrix

| Decision Class | Approval Authority | Reversibility |
|----------------|-------------------|---------------|
| Search/projection architecture (DEC-001, DEC-002, DEC-007, DEC-039-DEC-053) | User (via V4.7 prompt) — FROZEN | Low |
| Ingestion/trust (DEC-003, DEC-004, DEC-019) | User (via V4.7 prompt) — FROZEN | Medium |
| Dependencies (DEC-005, DEC-006, DEC-018, DEC-031, DEC-041) | User (via V4.7 prompt + external verification) — DEC-006 BLOCKED | Trivial-Low |
| Lifecycle/SEO (DEC-012, DEC-013-DEC-017, DEC-035) | User — DEC-012 and DEC-035 BLOCKED | Low-Medium |
| RBAC (DEC-021, DEC-033) | User (via V4.7 prompt) — FROZEN | Low |
| Governance (DEC-011, DEC-027-DEC-030, DEC-032, DEC-038) | User (via V4.7 prompt) — FROZEN | Trivial-Low |
| Queue policy (DEC-009) | User — BLOCKED on concrete values | Low |
| Domain (DEC-036 TuitionPeriod) | User (via V4.6 §4.10) — FROZEN | Low |

---

*End of Decision Ledger. 53 decisions recorded: 35 FROZEN, 12 APPROVED (from V4.7 prompt), 4 PROPOSED (require user approval — DEC-006, DEC-009, DEC-012, DEC-035), 2 DEFERRED. 4 PROPOSED decisions are recorded in Unresolved-Material-Issues Report.*
