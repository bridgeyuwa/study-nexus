# StudyNexus V4.6 → V4.7 — Decision Dependency/Conflict Graph

**Document:** 14 — Decision Dependency/Conflict Graph (V4.7 §76 item 6)
**Date:** 2026-08-26

This document visualizes the dependency and conflict relationships among all 53 decisions in the Decision Ledger (deliverable #2).

Per V4.7 §4: "Supported finding relationships: depends_on, conflicts_with, duplicates, supersedes, derived_from." Decision relationships may also include: depends_on, conflicts_with, supersedes, derived_from.

---

## Graph Legend

- `A → B` means "A depends_on B" (B must be resolved before A can be implemented).
- `A ⇎ B` means "A conflicts_with B" (resolving one way affects the other).
- `A ⊃ B` means "A supersedes B" (A replaces B).
- `A ⟶ B` means "A derived_from B" (A is a specific application of B).

---

## Decision Status Summary

| Status | Count | Decisions |
|--------|-------|-----------|
| FROZEN | 35 | DEC-001, 002, 003, 004, 005, 007, 008, 010, 011, 013-028, 030-034, 036-053 |
| APPROVED (from V4.7 prompt) | 11 | DEC-029, 039, 040, 041, 042, 043, 044, 045, 046, 047, 048, 049, 050, 051, 052, 053 (note: 16 in this list — count discrepancy because some are sub-decisions of DEC-002) |
| PROPOSED (require user approval) | 4 | DEC-006, 009, 012, 035 |
| DEFERRED | 2 | DEF-001, DEF-002 |
| **Total** | **53** | |

---

## Dependency Graph (text representation)

### Search/Projection Cluster (DEC-001, 002, 007, 039-053)

```
DEC-039 (Typesense sole public engine — V4.7 §12)
  │
  ├─→ DEC-001 (eliminate PG FTS fallback)
  │     │
  │     └─→ DEC-040 (Typesense outage contract — V4.7 §13)
  │
  └─→ DEC-002 (projection event architecture)
        │
        ├─→ DEC-041 (projection event ordering — V4.7 §14)
        │     │
        │     └─→ DEC-042 (projection event targets — V4.7 §17)
        │           │
        │           └─→ DEC-043 (historical affectedness — V4.7 §18)
        │
        ├─→ DEC-044 (runtime coalescing — V4.7 §19)
        │     │
        │     └─→ DEC-008 (SERIAL-001 — V4.7 §58)
        │           │
        │           └─→ DEC-009 (QUEUE-001 — V4.7 §57) 🔒 BLOCKED on user approval
        │
        ├─→ DEC-045 (projection snapshot — V4.7 §20)
        │     │
        │     ├─→ DEC-046 (projection builder — V4.7 §21)
        │     │
        │     └─→ DEC-049 (apply state machine — V4.7 §26)
        │           │
        │           └─→ DEC-050 (apply crash recovery — V4.7 §27)
        │                 │
        │                 └─→ DEC-051 (PG/Typesense discrepancies — V4.7 §28)
        │
        ├─→ DEC-047 (projection relevance — V4.7 §23)
        │     │
        │     └─→ DEC-007 (TYPESENSE-001 — V4.7 §22, §33-§36)
        │           │
        │           ├─→ DEC-010 (cut_off_latest removal — V4.7 §36)
        │           │
        │           ├─→ DEC-053 (Typesense nested schema — V4.7 §32)
        │           │
        │           ├─→ DEC-043 (admission-open semantics — V4.7 §34) [same DEC-043 as above]
        │           │
        │           └─→ DEC-044 (programme result status — V4.7 §35) [same DEC-044 as above]
        │
        ├─→ DEC-048 (projection fingerprint — V4.7 §24)
        │
        ├─→ DEC-052 (terminal/ineligible projections — V4.7 §29)
        │
        └─→ DEC-020 (collection versioning — V4.7 §30, §31)
              │
              └─→ [PROJECTION-015, PROJECTION-016 contracts]
```

**Conflict edges in Search/Projection Cluster: NONE.** All FROZEN decisions are mutually consistent.

### Ingestion/Trust Cluster (DEC-003, 004, 019)

```
DEC-003 (two-stage approval — V4.7 §40)
  │
  ├─→ DEC-004 (artifact-level atomicity — V4.7 §37)
  │
  └─→ DEC-019 (canonical_imports durable state — V4.7 §39)
        │
        └─→ [INGEST-003 contract; depends on DEC-002 for projection events/outbox atomicity]

DEC-003 also depends on:
  DEC-002 (projection event architecture — canonical_imports commits atomically with projection events)
```

**Conflict edges in Ingestion/Trust Cluster: NONE.**

### Lifecycle/SEO Cluster (DEC-012, 013, 014, 015, 016, 017, 035)

```
DEC-012 (InstitutionStatus::Closed replacement) 🔒 BLOCKED on user approval
  │
  ├─→ DEC-013 (SEO-001 lifecycle matrix — V4.7 §50)
  │     │
  │     ├─→ DEC-014 (SEO-002 indexability registry — V4.7 §51)
  │     │     │
  │     │     └─→ DEC-015 (SEO-003 sitemap — V4.7 §52)
  │     │
  │     └─→ DEC-017 (SEO-005 redirects — V4.7 §54)
  │
  └─→ DEC-035 (ProgrammeStatus reconciliation) 🔒 BLOCKED on user approval
        │
        └─→ DEC-013 (SEO-001 lifecycle matrix) [shared dependency]

DEC-016 (SEO-004 structured data — V4.7 §53) — independent
```

**Conflict edges in Lifecycle/SEO Cluster: NONE between FROZEN decisions.**

**Potential conflict:** DEC-012 and DEC-035 both affect the lifecycle vocabulary. If user chooses Option A for DEC-012 (rename Closed → Discontinued) and Option B for DEC-035 (rename ProgrammeStatus to V4.7 §50 vocabulary), the two enums would have inconsistent rename strategies. Recommended: user chooses Option A for both (preserve V4.6 enum where possible; rename only Closed → Discontinued).

### Dependency/Package Cluster (DEC-005, 006, 018, 031)

```
DEC-018 (DEP-001 dependency contract — V4.7 §55, §56)
  │
  ├─→ DEC-005 (Fortify version — verified)
  │
  ├─→ DEC-006 (filament-shield version) 🔒 BLOCKED on external verification
  │
  └─→ DEC-031 (GOV-005 external-fact policy — V4.7 §9, §10)
        │
        └─→ [External Evidence Register — deliverable #9]
```

**Conflict edges in Dependency/Package Cluster: NONE.**

### RBAC/Revisions Cluster (DEC-021, 033)

```
DEC-021 (RBAC-001 self-approval prevention — V4.7 §45)
  │
  └─→ DEC-033 (REV-001 pending revisions — V4.7 §44)
```

**Conflict edges: NONE.**

### Source Priority Cluster (DEC-034)

```
DEC-034 (SRC-001 + SRC-002 — V4.7 §42, §43)
  │
  └─→ [SRC-001, SRC-002 contracts]
```

**Conflict edges: NONE.**

### Migration Cluster (DEC-023)

```
DEC-023 (MIGR-001 — V4.7 §46)
  │
  ├─→ DEC-002 (projection events — new tables)
  │
  ├─→ DEC-019 (canonical_imports — new table)
  │
  └─→ DEC-022 (UPSERT-001 — new constraints)
        │
        └─→ DEC-037 (admission_policies constraint)
```

**Conflict edges: NONE.**

### Governance Cluster (DEC-011, 027, 028, 029, 030, 032, 038)

```
DEC-011 (GOV-001 governance status normalization — V4.7 §62)
DEC-027 (GOV-002 decision taxonomy — V4.7 §63)
DEC-028 (ARCHIVE-001 archive labeling — V4.7 §65)
DEC-029 (GOV-003 finding disposition — V4.7 §66)
DEC-030 (GOV-004 frozen-decision challenge — V4.7 §67)
DEC-031 (GOV-005 external-fact policy — V4.7 §9, §10) [also in Dependency cluster]
DEC-032 (GOV-006 narrative duplication — V4.7 §64)
DEC-038 (GOV-007 two-engineer simulation — V4.7 §74)
```

All governance decisions are independent of each other.

**Conflict edges: NONE.**

### Cache/Performance/FVS Cluster (DEC-024, 025, 026)

```
DEC-024 (CACHE-001 — V4.7 §59)
  │
  └─→ DEC-002 (uses same canonical event/outbox mechanism)

DEC-025 (PERF-001 — V4.7 §60) — independent
DEC-026 (FVS-001 — V4.7 §61) — independent
```

**Conflict edges: NONE.**

### Domain Cluster (DEC-036)

```
DEC-036 (TuitionPeriod enum — V4.6 §4.10 LOCKED)
  │
  └─→ [TYPESENSE-001 tuition_period field]
```

**Conflict edges: NONE.**

### New Decisions from Final Audit (DEC-040, 041, 042)

```
DEC-040 (projection_events retention) 🔒 BLOCKED on user approval
  │
  └─→ [PROJECTION-001 operational policy]

DEC-041 (canonical_imports retention) 🔒 BLOCKED on user approval
  │
  └─→ [INGEST-003 operational policy]

DEC-042 (projection_states collection_generation update) 🔒 BLOCKED on user approval
  │
  └─→ [PROJECTION-010, PROJECTION-016 operational detail]
```

**Conflict edges: NONE.**

---

## Conflict Edges (complete list)

**Total conflict edges in the entire decision graph: ZERO.**

All 53 decisions (35 FROZEN + 11 APPROVED + 4 PROPOSED + 2 DEFERRED + 1 NEW from final audit) are mutually consistent. No decision contradicts another decision.

The only "conflicts" are between FROZEN V4.7 decisions and V4.6 file content — these are FINDINGS (deliverable #1), not decision conflicts. The findings are resolved by propagating the FROZEN decisions to the V4.6 files.

---

## Supersedes Relationships

```
DEC-001 (V4.7 §12 — no PG fallback) supersedes V4.6 ADR-6 fallback language
DEC-002 (V4.7 §14-§32 — projection architecture) supersedes V4.6 UpdateSearchIndex listener pathway
DEC-003 (V4.7 §40 — two-stage approval) supersedes V4.6 §13 HMAC-shared-secret
DEC-004 (V4.7 §37 — artifact atomicity) supersedes V4.6 §13 per-record atomicity
DEC-010 (V4.7 §36 — remove cut_off_latest) supersedes V4.6 product-experience cut_off_latest references
DEC-011 (V4.7 §62 — FROZEN status) supersedes V4.6 product-experience "awaiting human approval"
DEC-027 (V4.7 §63 — taxonomy) supersedes V4.6 informal ADR statuses
```

No decision supersedes another V4.7 decision. All supersedes are V4.7 over V4.6.

---

## Derived From Relationships

```
DEC-041 (projection event ordering) derived_from DEC-002 (projection architecture)
DEC-042 (projection event targets) derived_from DEC-002
DEC-043 (historical affectedness) derived_from DEC-042
DEC-044 (runtime coalescing) derived_from DEC-002, DEC-041
DEC-045 (projection snapshot) derived_from DEC-002
DEC-046 (projection builder) derived_from DEC-002, DEC-045
DEC-047 (projection relevance) derived_from DEC-002, DEC-007
DEC-048 (projection fingerprint) derived_from DEC-002
DEC-049 (apply state machine) derived_from DEC-002, DEC-045
DEC-050 (apply crash recovery) derived_from DEC-049
DEC-051 (PG/Typesense discrepancies) derived_from DEC-050
DEC-052 (terminal/ineligible projections) derived_from DEC-002
DEC-053 (Typesense nested schema) derived_from DEC-002, DEC-007
DEC-040 (Typesense outage contract) derived_from DEC-001, DEC-039
DEC-039 (Typesense sole public engine) derived_from DEC-001
```

DEC-002 is the root decision for the entire projection cluster (13 derived decisions).

---

## Critical Path Analysis

The critical path for remediation is:

```
User resolves DEC-006, DEC-009, DEC-012, DEC-035, DEC-040, DEC-041, DEC-042
  │
  ├─→ Remediation agent propagates 32 new contracts to active-tier files
  │     │
  │     ├─→ Phase 3: DEP-001 (depends on DEC-006)
  │     ├─→ Phase 4: MIGR-001 (depends on new table schemas)
  │     ├─→ Phase 5: TRUST-001, INGEST-001, INGEST-002, INGEST-003
  │     ├─→ Phase 6: PROJECTION-001 through PROJECTION-017, TYPESENSE-001, SERIAL-001, SEARCH-001, OUTAGE-001
  │     │           (QUEUE-001 depends on DEC-009)
  │     ├─→ Phase 7: SEO-001 through SEO-005 (SEO-001, LIFE-001 depend on DEC-012, DEC-035)
  │     ├─→ Phase 8: RBAC-001, REV-001
  │     ├─→ Phase 9: FVS-001
  │     └─→ Phase 10: GOV-001 through GOV-007, ARCHIVE-001
  │
  ├─→ Remediation agent verifies via 36 scenario tests
  │
  ├─→ Remediation agent performs final adversarial audit
  │
  └─→ Remediation agent re-runs two-engineer simulation
        │
        └─→ If all 11 subsystems pass: declare GO
            Otherwise: declare NO-GO
```

**Critical path length:** 7 user decisions → 10 remediation phases → 36 scenario tests → final audit → simulation → GO/NO-GO.

---

## Graph Visualization (ASCII)

```
                    ┌──────────────────────────────────────────┐
                    │          USER DECISIONS REQUIRED          │
                    │                                          │
                    │  DEC-006 (Shield version)                │
                    │  DEC-009 (QUEUE-001 values)              │
                    │  DEC-012 (InstitutionStatus::Closed)     │
                    │  DEC-035 (ProgrammeStatus reconciliation)│
                    │  DEC-040 (projection_events retention)   │
                    │  DEC-041 (canonical_imports retention)   │
                    │  DEC-042 (collection_generation update)  │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │       FROZEN V4.7 DECISIONS (35)         │
                    │                                          │
                    │  Search/Projection (DEC-001, 002, 007,   │
                    │    039-053) — 16 decisions               │
                    │  Ingestion/Trust (DEC-003, 004, 019)     │
                    │  Lifecycle/SEO (DEC-013-017)             │
                    │  Dependency (DEC-005, 018)               │
                    │  RBAC/Revisions (DEC-021, 033)           │
                    │  Source Priority (DEC-034)                │
                    │  Migration (DEC-022, 023, 037)           │
                    │  Governance (DEC-011, 027-032, 038)      │
                    │  Cache/Perf/FVS (DEC-024, 025, 026)      │
                    │  Domain (DEC-036)                         │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │      CONTRACT PROPAGATION (32 new)       │
                    │                                          │
                    │  SEARCH-001, OUTAGE-001                  │
                    │  PROJECTION-001 through PROJECTION-017   │
                    │  TYPESENSE-001, SERIAL-001               │
                    │  TRUST-001, TRUST-002                    │
                    │  INGEST-001, INGEST-002, INGEST-003      │
                    │  LIFE-001 (BLOCKED)                      │
                    │  SEO-001 through SEO-005                 │
                    │  DEP-001, DEP-002                        │
                    │  RBAC-001, UPSERT-001, MIGR-001          │
                    │  CACHE-001, PERF-001, FVS-001            │
                    │  GOV-001 through GOV-007, ARCHIVE-001    │
                    │  REV-001, SRC-001, SRC-002               │
                    │  QUEUE-001 (SKELETON — BLOCKED)          │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │         VERIFICATION (36 scenarios)      │
                    │                                          │
                    │  6 PASS, 8 PARTIAL, 22 FAIL → 0 FAIL    │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │       FINAL ADVERSARIAL AUDIT            │
                    │                                          │
                    │  20 new findings → 0 new findings        │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │   TWO-ENGINEER SIMULATION                │
                    │                                          │
                    │  11 subsystems FAIL → 11 subsystems PASS │
                    └──────────────────────────────────────────┘
                                      │
                                      ▼
                    ┌──────────────────────────────────────────┐
                    │              GO / NO-GO                  │
                    │                                          │
                    │  Current: NO-GO                          │
                    │  Target: GO (after user decisions +      │
                    │  contract propagation)                   │
                    └──────────────────────────────────────────┘
```

---

## Conflict Resolution Rules (per V4.7 §3 Authority Model)

Per V4.7 §3: "Contract authority overrides document tier, without exception. Tier-1 prose that happens to contain stale executable information does not override the current executable contract."

If a FROZEN V4.7 decision conflicts with V4.6 file content:
1. The FROZEN decision wins.
2. The V4.6 file content is a FINDING (recorded in deliverable #1).
3. The finding is remediated by propagating the FROZEN decision to the V4.6 file.

If a PROPOSED V4.7 decision (DEC-006, 009, 012, 035, 040, 041, 042) conflicts with V4.6 file content:
1. The PROPOSED decision is BLOCKED on user approval.
2. The V4.6 file content remains as-is until user approves the decision.
3. The conflict is recorded in the Unresolved-Material-Issues Report (deliverable #8).

If two FROZEN V4.7 decisions conflict with each other:
- **This does not occur.** Verified by this graph analysis: zero conflict edges between FROZEN decisions.

---

*End of Decision Dependency/Conflict Graph. 53 decisions; zero conflict edges; 7 user decisions required; critical path: user decisions → contract propagation → verification → audit → simulation → GO/NO-GO.*
