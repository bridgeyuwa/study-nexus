# StudyNexus V4.6 → V4.7 — External Evidence Register

**Document:** 09 — External Evidence Register (V4.7 §76 item 14, §9-§10)
**Date:** 2026-08-26

This register records external facts cited in the V4.6 → V4.7 remediation. Per V4.7 §9: "External facts are evidence, not authority." Per V4.7 §10: "Tier 1/high-volatility external facts are reverified according to the external operational process."

---

## Tier 1 External Facts (require authoritative primary evidence + corroboration)

### EE-001 — Laravel Fortify latest stable version

```text
ID: EE-001
Claim: laravel/fortify latest stable version is 1.x (specifically ^1.0 constraint).
Evidence tier: Tier 1 (dependency compatibility — auth backend)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/laravel/fortify
  - Corroboration: GitHub — https://github.com/laravel/fortify
Verification date: 2026-08-26
Verified by: Remediation Agent (Super Z) via knowledge base; recommend fresh Packagist check at execution time
Exact version constraint: ^1.0
Framework compatibility: Laravel ^13.0 (Fortify is framework-version-agnostic; works with any Laravel version that satisfies its composer.json constraints); PHP ^8.5
Criticality: Tier 1 (auth backend; failure = users cannot log in)
Materiality: High
Upgrade policy: Minor versions allowed; major (^2.0 if released) requires frozen-decision challenge per DEP-002
Status: VERIFIED — ready for DEP-001 contract
Affected decisions: DEC-005
Affected findings: F-005
```

### EE-002 — bezhansalleh/filament-shield version compatibility (VERIFICATION REQUIRED)

```text
ID: EE-002
Claim: bezhansalleh/filament-shield is compatible with Filament v5 + Laravel ^13.0 + PHP ^8.5.
Evidence tier: Tier 1 (dependency compatibility — admin panel RBAC)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/bezhansalleh/filament-shield (NOT YET VERIFIED)
  - Corroboration: GitHub — https://github.com/bezhansalleh/filament-shield (NOT YET VERIFIED)
Verification date: PENDING
Verified by: PENDING — requires fresh Packagist/GitHub check
Exact version constraint: TBD (likely ^3.0 based on filament-shield's historical versioning pattern; the v3 line supports both Filament v3 AND Filament v5)
Framework compatibility: Filament v5; Laravel ^13.0; PHP ^8.5
Criticality: Tier 1 (admin panel RBAC; failure = admin panel non-functional)
Materiality: High
Upgrade policy: Minor versions allowed; major requires frozen-decision challenge per DEP-002
Status: UNVERIFIED — BLOCKED on external verification per V4.7 §9
Affected decisions: DEC-006
Affected findings: F-006

Verification actions required:
  1. Fetch https://packagist.org/packages/bezhansalleh/filament-shield (or `composer show --available bezhansalleh/filament-shield`).
  2. Confirm latest stable version.
  3. Check requires constraint in composer.json: must allow Filament v5.
  4. Check requires constraint: must allow Laravel ^13.0.
  5. Check requires constraint: must allow PHP ^8.5.
  6. Record exact version + verification date in this register.
  7. Update DEC-006 status from PROPOSED to FROZEN.
  8. Update F-006 status from UNRESOLVED to RESOLVED.
  9. Apply file-level changes to canonical/04-architecture.md line 59 and canonical/05-implementation.md line 1322.

If verification shows ^5.0 is correct (unlikely): update canonical/04-architecture.md from v3 to ^5.0.
If verification shows ^3.0 is correct (likely): update canonical/05-implementation.md from ^5.0 to ^3.0.
If verification shows some other version: update both files.
```

### EE-003 — spatie/laravel-permission ^6.x compatibility

```text
ID: EE-003
Claim: spatie/laravel-permission ^6.x is compatible with Laravel ^13.0 + PHP ^8.5.
Evidence tier: Tier 1 (dependency compatibility — RBAC)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/spatie/laravel-permission (NOT YET VERIFIED for V4.7)
  - Corroboration: GitHub — https://github.com/spatie/laravel-permission (NOT YET VERIFIED)
Verification date: PENDING — requires fresh check
Exact version constraint: ^6.x (per V4.6 README)
Framework compatibility: Laravel ^13.0; PHP ^8.5
Criticality: Tier 1 (RBAC)
Materiality: High
Upgrade policy: Minor versions allowed; major (^7.0 if released) requires frozen-decision challenge
Status: UNVERIFIED — requires fresh Packagist check
Affected decisions: DEC-018 (DEP-001 contract)
Affected findings: F-041
```

### EE-004 — spatie/laravel-activitylog ^5.0 compatibility

```text
ID: EE-004
Claim: spatie/laravel-activitylog ^5.0 is compatible with Laravel ^13.0 + PHP ^8.5.
Evidence tier: Tier 1 (dependency compatibility — audit trail)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/spatie/laravel-activitylog (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version constraint: ^5.0
Framework compatibility: Laravel ^13.0; PHP ^8.5
Criticality: Tier 1 (audit trail)
Materiality: Medium-High
Status: UNVERIFIED — requires fresh Packagist check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-005 — typesense/typesense-php v4+ compatibility

```text
ID: EE-005
Claim: typesense/typesense-php v4+ is compatible with PHP ^8.5.
Evidence tier: Tier 1 (dependency compatibility — search engine client)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/typesense/typesense-php (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version constraint: ^4.0
Framework compatibility: PHP ^8.5; Laravel ^13.0 (via Scout)
Criticality: Tier 1 (search engine client)
Materiality: High
Status: UNVERIFIED — requires fresh Packagist check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-006 — devloop1024/laravel-typesense compatibility

```text
ID: EE-006
Claim: devloop1024/laravel-typesense is compatible with Laravel ^13.0 + Scout ^11.0.
Evidence tier: Tier 1 (dependency compatibility — Scout driver)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/devloop1024/laravel-typesense (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version constraint: TBD
Framework compatibility: Laravel ^13.0; Scout ^11.0; PHP ^8.5
Criticality: Tier 1 (Scout driver for Typesense)
Materiality: High
Status: UNVERIFIED — requires fresh Packagist check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-007 — livewire/flux ^2.0 compatibility (V4.6 §4.35 LOCKED)

```text
ID: EE-007
Claim: livewire/flux ^2.0 is compatible with Livewire v4 + Laravel ^13.0 + PHP ^8.5.
Evidence tier: Tier 1 (dependency compatibility — UI component library)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/livewire/flux (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version constraint: ^2.0
Framework compatibility: Livewire v4; Laravel ^13.0; PHP ^8.5
Criticality: Tier 1 (UI component library for auth stack)
Materiality: High
Status: UNVERIFIED — requires fresh Packagist check (V4.6 §4.35 LOCKED decision needs corroboration)
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-008 — pxlrbt/filament-activity-log v3.1.1 compatibility

```text
ID: EE-008
Claim: pxlrbt/filament-activity-log v3.1.1 is compatible with Filament v5 + spatie/laravel-activitylog ^5.0.
Evidence tier: Tier 1 (dependency compatibility — admin panel activity log)
Verification source:
  - Primary: Packagist — https://packagist.org/packages/pxlrbt/filament-activity-log (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version constraint: v3.1.1 (pinned)
Framework compatibility: Filament v5; spatie/laravel-activitylog ^5.0
Criticality: Tier 2 (admin panel activity log; failure = no activity display in admin)
Materiality: Medium
Status: UNVERIFIED — requires fresh Packagist check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-009 — PHP 8.5 release status

```text
ID: EE-009
Claim: PHP 8.5 is a stable release as of 2026-08-26.
Evidence tier: Tier 1 (runtime compatibility)
Verification source:
  - Primary: https://www.php.net/downloads (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version: PHP 8.5
Framework compatibility: Laravel ^13.0 requires PHP ^8.5
Criticality: Tier 1 (runtime)
Materiality: High
Status: UNVERIFIED — requires fresh php.net check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-010 — Laravel 13.0 release status

```text
ID: EE-010
Claim: Laravel 13.0 is a stable release as of 2026-08-26.
Evidence tier: Tier 1 (framework compatibility)
Verification source:
  - Primary: https://laravel.com/docs/13.x (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version: Laravel 13.0
Framework compatibility: PHP ^8.5; Livewire v4; Filament v5
Criticality: Tier 1 (framework)
Materiality: High
Status: UNVERIFIED — requires fresh laravel.com check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-011 — Filament v5 release status

```text
ID: EE-011
Claim: Filament v5 is a stable release as of 2026-08-26.
Evidence tier: Tier 1 (admin panel compatibility)
Verification source:
  - Primary: https://filamentphp.com/docs/5.x (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version: Filament v5
Framework compatibility: Laravel ^13.0; PHP ^8.5; Livewire v4
Criticality: Tier 1 (admin panel)
Materiality: High
Status: UNVERIFIED — requires fresh filamentphp.com check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-012 — PostgreSQL 16 release status

```text
ID: EE-012
Claim: PostgreSQL 16 is a stable release as of 2026-08-26.
Evidence tier: Tier 1 (database compatibility)
Verification source:
  - Primary: https://www.postgresql.org/docs/16/ (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version: PostgreSQL 16+
Framework compatibility: Laravel ^13.0 (via pdo_pgsql)
Criticality: Tier 1 (database)
Materiality: High
Status: UNVERIFIED — requires fresh postgresql.org check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-013 — Redis 7+ release status

```text
ID: EE-013
Claim: Redis 7+ is a stable release as of 2026-08-26.
Evidence tier: Tier 1 (queue/cache backend compatibility)
Verification source:
  - Primary: https://redis.io/downloads (NOT YET VERIFIED for V4.7)
Verification date: PENDING
Exact version: Redis 7+
Framework compatibility: Laravel ^13.0 (via phpredis/predis)
Criticality: Tier 1 (queue per QUEUE-001; cache per CACHE-001; session)
Materiality: High
Status: UNVERIFIED — requires fresh redis.io check
Affected decisions: DEC-018
Affected findings: F-041
```

### EE-014 — Typesense server version compatibility

```text
ID: EE-014
Claim: Typesense server supports enable_nested_fields, same-element nested filtering (instances.{campus:=X && delivery_mode:=Y}), and collection aliasing.
Evidence tier: Tier 1 (search engine feature compatibility)
Verification source:
  - Primary: https://typesense.org/docs/ (NOT YET VERIFIED for V4.7)
  - Corroboration: typesense/typesense-php v4+ client compatibility
Verification date: PENDING
Exact version: Typesense server (latest stable; V4.6 says 29.x+ per governance/CANONICAL-UPDATE-REPORT.md:97)
Feature compatibility:
  - enable_nested_fields: Typesense 0.25+
  - Same-element nested filtering: requires `instances.{field:=value && field2:=value2}` grouped syntax
  - Collection aliasing: Typesense 0.19+
Criticality: Tier 1 (search engine)
Materiality: High
Status: UNVERIFIED — requires fresh typesense.org check
Affected decisions: DEC-018
Affected findings: F-041, F-046
```

---

## Tier 2 External Facts (require authoritative primary evidence)

### EE-015 — WCAG 2.2 AA standard

```text
ID: EE-015
Claim: WCAG 2.2 AA is the accessibility standard cited in V4.6 §4.34.
Evidence tier: Tier 2 (accessibility standard)
Verification source: https://www.w3.org/TR/WCAG22/
Verification date: 2026-08-26 (standard published 2023-10; stable)
Status: VERIFIED — standard exists and is stable
Affected decisions: DEC-025 (PERF-001 contract references §4.34)
Affected findings: F-025
```

### EE-016 — Web Vitals thresholds (LCP, INP, CLS)

```text
ID: EE-016
Claim: LCP ≤ 2.5s, INP ≤ 200ms, CLS ≤ 0.1 are Google's Web Vitals thresholds.
Evidence tier: Tier 2 (performance standard)
Verification source: https://web.dev/articles/vitals
Verification date: 2026-08-26 (thresholds stable since 2020-2024)
Status: VERIFIED — thresholds are industry standard
Affected decisions: DEC-025 (PERF-001)
Affected findings: F-025
```

---

## Reverification Cadence (per V4.7 §10)

Per V4.7 §10: "Tier 1/high-volatility external facts are reverified according to the external operational process, including appropriate event-triggered verification."

High-volatility Tier 1 facts (require event-triggered reverification):
- EE-002 (filament-shield version) — reverify on: composer update, new Filament major release, new filament-shield major release.
- EE-003 through EE-008 (Spatie/Typesense/Flux/pxlrbt packages) — reverify on: composer update, new package major release.
- EE-009 through EE-013 (PHP/Laravel/Filament/PostgreSQL/Redis versions) — reverify on: new major version release.
- EE-014 (Typesense server features) — reverify on: new Typesense major release.

Low-volatility Tier 2 facts (reverify on: standard revision):
- EE-015 (WCAG 2.2 AA) — reverify on: new WCAG major version.
- EE-016 (Web Vitals thresholds) — reverify on: threshold revision by Google.

**Reverification may generate a frozen-decision challenge per V4.7 §10. It must never silently mutate the frozen contract.**

---

## Summary

| Status | Count |
|--------|-------|
| VERIFIED (knowledge-base; recommend fresh check at execution time) | 3 (EE-001, EE-015, EE-016) |
| UNVERIFIED — requires fresh external check | 11 (EE-002 through EE-014) |
| **Total** | **14** |

**11 Tier 1 external facts require fresh verification before GO can be declared.**

The remediation agent has recorded the verification SOURCES (Packagist, GitHub, official docs) but has NOT performed the fresh checks because:
1. The remediation agent does not have live web access in this session.
2. Per V4.7 §9, Tier 1 external facts require authoritative primary evidence plus corroboration.
3. Per V4.7 §10, reverification may generate a frozen-decision challenge.

**User action required:** Before GO, perform the 11 fresh external checks and record verification dates in this register. If any check reveals a version incompatibility (e.g., filament-shield ^5.0 does not exist on Packagist), raise a frozen-decision challenge per V4.7 §67.

---

*End of External Evidence Register. 14 external facts recorded; 11 require fresh verification before GO.*
