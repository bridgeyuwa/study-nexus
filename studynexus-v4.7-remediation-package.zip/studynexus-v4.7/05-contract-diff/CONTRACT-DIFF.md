# StudyNexus V4.6 → V4.7 — Contract Diff

**Document:** 05 — Contract Diff (V4.7 §76 item 9)
**Date:** 2026-08-26

This document shows OLD (V4.6) vs NEW (V4.7) contract language for the most critical changes. Full per-file diffs are in the Change Manifest (deliverable #4).

---

## Diff 1: Public Search Engine Selection (SEARCH-001)

### OLD (V4.6 — canonical/02-decisions.md ADR-6, line 237)

> **Decision:** Typesense is the V1 search engine for full-text search, faceting, and typo-tolerant discovery. PostgreSQL FTS is maintained as a secondary search capability for admin search and as a fallback when Typesense is unavailable. Scout driver is Typesense for V1; `database` driver available for fallback. The domain is never coupled to the search engine — all indexing is triggered by domain events via the UpdateSearchIndex listener. Scout provides the abstraction layer for switching.

### NEW (V4.7 — SEARCH-001)

> **Decision:** Typesense is the sole V1 public discovery/search engine (per V4.7 §12). Applies to: free-text programme search; faceted search; relevance-based result discovery; "similar/related programmes" discovery. **There is no PostgreSQL public-search fallback.** PostgreSQL FTS infrastructure (tsvector + GIN indexes) is used for admin/internal search ONLY (per V4.7 §12). The `database` Scout driver is NOT used as a public-search fallback. Public browse/detail (deterministic relational routes: institution → its programmes; canonical curated discovery page; canonical detail page) may use PostgreSQL directly — these are not treated as search-engine operations merely because they produce lists. Admin/internal search may use PostgreSQL directly. Do not route internal search through Typesense merely for architectural symmetry.

### Delta Analysis

- Removed: "PostgreSQL FTS is maintained as a secondary search capability ... as a fallback when Typesense is unavailable"
- Removed: "`database` driver available for fallback"
- Added: "There is no PostgreSQL public-search fallback"
- Added: explicit admin/internal vs public search distinction
- Added: public browse/detail exception (PostgreSQL allowed for deterministic relational routes)

---

## Diff 2: Typesense Outage Contract (OUTAGE-001)

### OLD (V4.6 — MANIFEST §4.30)

> When Typesense is unavailable, basic facets remain functional via PostgreSQL query-builder; advanced/instance-scoped filters (Campus, Delivery Mode, Admission Status) are DISABLED; UI shows "Advanced filters temporarily unavailable." A legitimate zero-result search is NOT a degraded-state error.

### NEW (V4.7 — OUTAGE-001 per V4.7 §13)

> For primary public Typesense search: Typesense unavailable → explicit unavailable/search-failure state; **do not return zero results as a disguise**; **do not silently switch to PostgreSQL**.
> For optional search-powered components: canonical page remains available; failed optional discovery component fails closed or is omitted.
> For canonical browse/detail pages: continue using PostgreSQL.
> A legitimate zero-result search (Typesense available, no matches) is NOT a degraded-state error and is displayed normally.

### Delta Analysis

- Removed: "basic facets remain functional via PostgreSQL query-builder" — this IS the "silent switch to PostgreSQL" that V4.7 §13 forbids
- Added: explicit three-tier outage contract (primary search / optional components / canonical browse-detail)
- Added: "do not return zero results as a disguise"
- Added: "do not silently switch to PostgreSQL"

---

## Diff 3: Search Sync Pathway (PROJECTION-001)

### OLD (V4.6 — canonical/04-architecture.md line 757)

> | Search projection sync | Typesense sync via domain events → UpdateSearchIndex listener → queued Scout job; PostgreSQL FTS tsvector maintained for fallback |

### NEW (V4.7 — PROJECTION-001 per V4.7 §14)

> | Search projection sync | Projection event pathway (PROJECTION-001): canonical mutation + projection_event (with immutable `projection_event_revision`) + projection_event_targets commit atomically in one PostgreSQL transaction → projection worker materializes `ProjectionInput` under REPEATABLE READ (PROJECTION-005) → applies to Typesense via complete deterministic rebuild (PROJECTION-006) → records APPLIED in `projection_states` (PROJECTION-010, PROJECTION-011) → on crash, reconciliation inspects Typesense and retries the same immutable event (PROJECTION-012). PostgreSQL FTS tsvector maintained for admin/internal search only (SEARCH-001). |

### Delta Analysis

- Removed: "UpdateSearchIndex listener → queued Scout job" (the forbidden "second unrelated dispatch pathway" per V4.7 §23)
- Removed: "PostgreSQL FTS tsvector maintained for fallback"
- Added: full projection event architecture with 17 sub-contracts
- Added: immutable `projection_event_revision` in same transaction
- Added: REPEATABLE READ snapshot materialization
- Added: APPLYING → APPLIED state machine
- Added: crash recovery via reconciliation

---

## Diff 4: Import Approval Trust Model (TRUST-001)

### OLD (V4.6 — canonical/06-data-acquisition.md §13, line 593-609)

> **Request body:** The signed Approved Import Artifact JSON manifest:
> ```json
> { ..., "signature": "hmac-sha256-of-above-fields" }
> ```
> **Server-side processing:**
> 1. Verify HMAC signature using shared secret.
> 2. Verify Sanctum token scope.
> 3. Enqueue `ApprovedArtifactIngestionJob` on the `imports` queue.
> ...
> **Failure modes:**
> - Invalid signature → 401 Unauthorized; acquisition worker must re-sign.
> - Validation failure of individual records → records are rejected with structured error in the response; other records in the same artifact are still applied (atomicity is per-record, not per-artifact, unless a transaction is explicitly requested).

### NEW (V4.7 — TRUST-001 + INGEST-001 per V4.7 §37, §40)

> **Two-stage trust model (per TRUST-001):**
> - Stage 1 (acquisition env): HMAC or mTLS between acquisition worker and ingestion API for **transport integrity ONLY**. This is NOT the approval signature.
> - Stage 2 (production control plane): Independent human approval via Filament v5 resource (Fortify 2FA required). The signed approval binds {artifact ID, artifact hash, artifact/schema version, approval action, approver identity, approval timestamp}. **The signing private key is held ONLY by the production control plane.** The acquisition environment MUST NOT possess the private approval signing credential (per V4.7 §40).
>
> **Server-side processing:**
> 1. Verify transport HMAC signature (Stage 1 — transport integrity only).
> 2. Verify Sanctum token scope.
> 3. Look up matching approval record by `artifact_hash` in `canonical_imports` (state = APPROVED per INGEST-003). If no matching APPROVED record exists, reject with 403.
> 4. Verify approval signature using production control plane's public key.
> 5. Enqueue `ApprovedArtifactIngestionJob` on the `imports` queue.
> 6. Return 202 Accepted with the batch_id.
>
> **Failure modes:**
> - Invalid transport signature → 401 Unauthorized; acquisition worker must re-sign.
> - Invalid token → 403 Forbidden.
> - **No matching APPROVED record in canonical_imports → 403 Forbidden** (artifact not approved by human approver).
> - **Invalid approval signature → 403 Forbidden** (forged approval).
> - **Validation failure of any blocking record → entire artifact rejected (per INGEST-001); zero canonical records committed.** Warnings may coexist with successful application. Never turn blocking errors into partial acceptance.

### Delta Analysis

- Removed: "Verify HMAC signature using shared secret" as the sole approval mechanism
- Removed: "atomicity is per-record, not per-artifact" (forbidden by V4.7 §37)
- Added: two-stage trust model (transport vs approval)
- Added: human approval via Filament v5 + Fortify 2FA
- Added: approval signature binds to artifact hash
- Added: canonical_imports table lookup for APPROVED state
- Added: artifact-level atomicity (any blocking error → entire artifact rejected)

---

## Diff 5: Programme Search Schema — cut_off_latest removal (TYPESENSE-001)

### OLD (V4.6 — product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md line 1179)

> | `cut_off_latest` | CutOffMark (latest) | int32 | Sort + display |

### NEW (V4.7 — TYPESENSE-001 §Cut-off Semantics per V4.7 §36)

> **Removed:** top-level `cut_off_latest` field.
> **Replaced with:** contextual nested `instances[].cut_off` field. Cutoff must be associated with: applicable ProgrammeInstance; applicable admission cycle; applicable pathway/context; published/current validity according to the canonical cutoff contract.
> **Sort behavior:** sort applies within the matched instance subset per Programme Result Status contract (V4.7 §35). If multiple instances match, display "Multiple cutoffs — see details."
> **If future UX needs a top-level cutoff aggregate**, that requires an explicit new decision per V4.7 §36. Do not invent a misleading aggregate.

### Delta Analysis

- Removed: top-level `cut_off_latest` int32 sort+display field
- Added: contextual nested `instances[].cut_off`
- Added: explicit "no misleading aggregate" rule

---

## Diff 6: Programme Result Status — admission display (TYPESENSE-001)

### OLD (V4.6 — product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md lines 863-866)

> | `ProgrammeStatus::Admitting` + active cycle + policy exists | "Currently admitting" (green) |
> | `ProgrammeStatus::Prospective` | "Not yet admitting" (yellow) |
> | `ProgrammeStatus::Suspended` | "Admission suspended" (orange) |
> | `ProgrammeStatus::Discontinued` | "Discontinued" (red) |
>
> This derivation uses the existing `isAdmitting` query from canonical architecture.

### NEW (V4.7 — TYPESENSE-001 §Programme Result Status per V4.7 §35)

> Admission status is **contextual to the matching instance set**, NOT a Programme-level property.
>
> - If the search context narrows to a specific instance subset: result status reflects those matching instances.
> - If all matching instances share one state: display that state.
> - If multiple admission states remain: display a neutral state such as **"Multiple admission states."**
> - **Do not apply an arbitrary precedence rule.**
> - **Do not resurrect a Programme-level `ProgrammeStatus` as though it were canonical admission truth.**
>
> The V4.6 ProgrammeStatus enum (Prospective, Admitting, Suspended, Discontinued) is preserved per DEC-035 (pending user approval) but is mapped to V4.7 §50 lifecycle matrix in SEO-001:
> - Prospective or Admitting + is_published=true → ACTIVE
> - Suspended → SUSPENDED
> - Discontinued → DISCONTINUED
> - is_published=false → DRAFT/UNPUBLISHED

### Delta Analysis

- Removed: Programme-level admission status derivation as canonical truth
- Added: contextual-to-matching-instance-set semantics
- Added: "Multiple admission states" neutral display
- Added: explicit prohibition on Programme-level ProgrammeStatus as admission truth

---

## Diff 7: Fortify Version (DEP-001)

### OLD (V4.6 — canonical/04-architecture.md line 52)

> | Laravel Fortify | ^13.0 | Backend authentication service (login, 2FA, password reset, email verification) |

### NEW (V4.7 — DEP-001 per DEC-005)

> | Laravel Fortify | `laravel/fortify` | ^1.0 | Backend authentication service (login, 2FA, password reset, email verification) — paired with Livewire/Flux Pro for UI |
>
> DEP-001 contract row:
> - exact verified version: `^1.20` (assumed; verify on Packagist at install time)
> - allowed constraint: `^1.0`
> - framework compatibility: Laravel ^13.0 / PHP ^8.5
> - verification source: Packagist (laravel/fortify) + GitHub
> - criticality: Tier 1 (auth backend)
> - upgrade policy: minor versions allowed; major requires frozen-decision challenge

### Delta Analysis

- Removed: `^13.0` (does not exist on Packagist)
- Added: `^1.0` (correct; matches README and canonical/05-implementation.md)
- Added: full DEP-001 contract metadata

---

## Diff 8: filament-shield Version (DEP-001) — BLOCKED

### OLD (V4.6 — contradiction)

> canonical/04-architecture.md line 59: `bezhansalleh/filament-shield | v3`
> canonical/05-implementation.md line 1322: `bezhansalleh/filament-shield | ^5.0`

### NEW (V4.7 — DEP-001 per DEC-006; PENDING EXTERNAL VERIFICATION)

> | bezhansalleh/filament-shield | `bezhansalleh/filament-shield` | [TBD — likely ^3.0 pending Packagist verification] | Filament + Spatie Permission integration; auto-generates policies and permission-seeded resources |
>
> **STATUS: BLOCKED on external Packagist verification per V4.7 §9 external-fact policy.**
> - Verification required: latest stable version compatible with Filament v5 + Laravel ^13.0 + PHP ^8.5
> - Verification source: Packagist (bezhansalleh/filament-shield) + GitHub release history
> - Once verified, both canonical/04-architecture.md and canonical/05-implementation.md will be updated to the verified version.
> - DEP-001 contract row will be completed with verification date/source.

### Delta Analysis

- Conflict identified: v3 vs ^5.0
- Resolution: BLOCKED on external verification
- Recommended: `^3.0` (filament-shield v3 line supports Filament v5)

---

## Diff 9: Governance Status — Product Experience (GOV-001)

### OLD (V4.6 — 4 product-experience files line 4)

> **Status:** UX DESIGN — awaiting human approval
> **Status:** UX DISCOVERY — awaiting human approval
> **Status:** VISUAL UI DESIGN — awaiting human approval
> **Status:** DISCOVERY ONLY — awaiting human approval

### NEW (V4.7 — GOV-001 per V4.7 §62)

> **Status:** FROZEN — V4.6/V4.7 documentation baseline (see MANIFEST.md). Tier-2 product-experience material conforms to canonical; ADRs and contracts in canonical/ are authoritative.

### Delta Analysis

- Removed: "awaiting human approval" (contradicts V4.6 MANIFEST "FROZEN" declaration)
- Added: "FROZEN — V4.6/V4.7 documentation baseline"

---

## Diff 10: New Tables (PROJECTION-001, INGEST-003, SEO-005)

### OLD (V4.6)

No `projection_events`, `projection_event_targets`, `pending_projection_requests`, `projection_states`, `canonical_imports`, `url_redirects` tables exist.

### NEW (V4.7)

```sql
-- PROJECTION-001: Projection event ordering
CREATE TABLE projection_events (
    id BIGINT PRIMARY KEY,
    revision BIGINT UNIQUE NOT NULL,  -- immutable; allocated by global sequence
    projection_type VARCHAR(50) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    payload JSONB NOT NULL  -- event details (mutation type, changed fields, etc.)
);

-- PROJECTION-002: Normalized target rows
CREATE TABLE projection_event_targets (
    id BIGINT PRIMARY KEY,
    projection_event_id BIGINT NOT NULL REFERENCES projection_events(id),
    projection_type VARCHAR(50) NOT NULL,
    projection_id BIGINT NOT NULL,  -- logical projection identity (e.g., programme_id)
    UNIQUE (projection_event_id, projection_type, projection_id)
);

-- PROJECTION-004: Runtime coalescing (optimization, not correctness)
CREATE TABLE pending_projection_requests (
    id BIGINT PRIMARY KEY,
    projection_type VARCHAR(50) NOT NULL,
    projection_id BIGINT NOT NULL,
    pending_revision BIGINT NOT NULL,
    coalesced_at TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (projection_type, projection_id)  -- one pending/running job per identity
);

-- PROJECTION-010: Durable apply state
CREATE TABLE projection_states (
    projection_type VARCHAR(50) NOT NULL,
    projection_id BIGINT NOT NULL,
    last_applied_projection_revision BIGINT,
    lifecycle_state VARCHAR(20) NOT NULL DEFAULT 'APPLYING',  -- APPLYING | APPLIED
    terminal_revision BIGINT,
    projection_contract_version INT NOT NULL,
    collection_generation INT NOT NULL,
    last_applied_fingerprint VARCHAR(64),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (projection_type, projection_id)
);

-- INGEST-003: Canonical import state
CREATE TABLE canonical_imports (
    artifact_id UUID PRIMARY KEY,
    artifact_hash VARCHAR(64) NOT NULL UNIQUE,  -- sha256
    schema_version VARCHAR(20) NOT NULL,
    approval_id UUID NOT NULL,
    approver_id BIGINT NOT NULL,
    approved_at TIMESTAMP NOT NULL,
    execution_id UUID NOT NULL,  -- one per attempt
    state VARCHAR(20) NOT NULL,  -- RECEIVED | VALIDATING | VALIDATION_FAILED | APPROVED | REVOKED | APPLYING | FAILED | APPLIED
    last_state_change_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_operator_id BIGINT,
    replay_reason TEXT,
    original_execution_id UUID,  -- for replays; NULL for original
    UNIQUE (artifact_hash, execution_id)
);

-- SEO-005: URL redirects
CREATE TABLE url_redirects (
    id BIGINT PRIMARY KEY,
    source_url_normalized VARCHAR(2048) NOT NULL UNIQUE,  -- globally unique; fragments excluded
    destination_url VARCHAR(2048) NOT NULL,
    http_status SMALLINT NOT NULL DEFAULT 301,  -- V1: HTTP 301 only
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    retired_at TIMESTAMP  -- NULL = active; non-NULL = retired
);
```

### Delta Analysis

- Added: 6 new tables supporting the projection event architecture, canonical import state, and URL redirect contract.
- Migration order per MIGR-001: `projection_events` → `projection_event_targets` → `projection_states` → `pending_projection_requests`; `canonical_imports` (independent); `url_redirects` (independent).

---

## Diff 11: TYPESENSE-001 Field Registry (NEW)

### OLD (V4.6)

No formal field registry. Typesense collection fields documented informally across canonical/05-implementation.md §8.3, §8.4 and product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md.

### NEW (V4.7 — TYPESENSE-001 per V4.7 §22, §33)

```text
Field registry (10 columns per field):
  field name | canonical source | transformation | type | searchable | filterable | sortable | facet behavior | null behavior | dependency

Programme Search Schema (17 field classes per V4.7 §33):
  1. programme identity fields (id, public_id, slug)
  2. display name (name)
  3. sort name (name_sort)
  4. institution identity/name (institution_id, institution_name, institution_slug)
  5. institution state (institution_lifecycle)
  6. institution city (institution_city)
  7. ownership type (institution_ownership)
  8. discipline/discovery fields (discipline, discipline_slug)
  9. nested instances (instances[]) — per PROJECTION-017
  10. instance location/mode/year (instances[].campus, instances[].delivery_mode, instances[].academic_year)
  11. instance admission state (instances[].is_admission_open) — per V4.7 §34
  12. instance contextual cutoffs (instances[].cut_off) — per V4.7 §36 (replaces top-level cut_off_latest)
  13. admission-open semantics (top-level is_admission_open aggregate) — per V4.7 §34
  14. programme-count aggregate (only where explicitly used; e.g., on institution document)
  15. publication/searchability state (is_published, is_searchable) — per V4.7 §29
  16. tuition (tuition_min, tuition_max) — derived from published ProgrammeInstances per V4.6 §8.4
  17. award_level (enum facet)

There is NO generic ambiguous `status` field. Use explicit semantic fields.

CI assertion: union of field dependencies == declared document dependencies.
A projection field without a registered dependency is a Tier-1 finding.
An incorrectly declared dependency is a Tier-1 finding.
```

### Delta Analysis

- Added: formal 10-column field registry
- Added: 17 field classes enumerated
- Added: explicit "no generic status field" rule
- Added: CI-mechanical-verification properties

---

## Diff 12: RBAC Self-Approval Prevention (RBAC-001)

### OLD (V4.6 — canonical/05-implementation.md §5)

No self-approval prevention rule. V4.6 has self-protection against last platform-admin demoting themselves but not the broader submitter≠approver rule.

### NEW (V4.7 — RBAC-001 per V4.7 §45)

> **RBAC-001: Self-Approval Prevention**
>
> A user may not approve their own revision. Submitter cannot review or approve their own revision.
>
> **Enforcement:** `PendingRevision.submitter_id ≠ approver_id`; if equal, the approval action fails with 403 Forbidden.
>
> This rule applies to all pending revision types (programme, institution, scholarship, admission policy, cut-off mark, accreditation record).
>
> The V4.6 RBAC capability inventory is preserved (11 roles: 4 platform-global + 5 organization-scoped + 2 user-level). Roles are implementation groupings, not the authority model itself. Capability + scope matrix is the authority model.

### Delta Analysis

- Added: explicit submitter ≠ approver rule
- Added: 403 Forbidden enforcement
- Added: scope (all pending revision types)

---

*End of Contract Diff. 12 critical diffs documented. Full per-file diffs in Change Manifest (deliverable #4).*
