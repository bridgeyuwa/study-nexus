# StudyNexus V4.6 → V4.7 — Scenario Verification Report

**Document:** 06 — Scenario Verification Report (V4.7 §76 item 11, §72)
**Date:** 2026-08-26

This report simulates all 36 V4.7 §72 scenarios against the V4.6 package AS-IS (current state) and the V4.7 target state (post-remediation). For each scenario: expected behavior, actual documented contract, source of authority, result.

**Legend:**
- ✅ PASS — V4.6 contract produces expected behavior
- ❌ FAIL — V4.6 contract contradicts expected behavior; V4.7 remediation required
- ⚠️ PARTIAL — V4.6 contract is ambiguous or incomplete; V4.7 remediation clarifies
- 🔒 BLOCKED — V4.7 remediation cannot be verified due to unresolved user decision

---

## Scenarios S-1 through S-36

### S-1 — One Programme with one instance

```text
Scenario: A Programme has exactly one ProgrammeInstance.
Expected behavior:
  - Programme is visible in public search iff is_published=true AND instance.is_published=true (CON-004).
  - Result card displays instance-specific admission, tuition, cut-off.
  - Detail page displays the single instance's full information.
Actual documented contract: V4.6 canonical/04-architecture.md §6 publication predicate; canonical/05-implementation.md §8.4a ProgrammeInstance Context Semantics.
Source of authority: CON-004, CON-007 (TYPESENSE-001 pending), V4.6 §4.3-4.4 ProgrammeInstance Context Semantics.
Result: ✅ PASS (V4.6 handles this case correctly).
```

### S-2 — Programme with multiple campuses

```text
Scenario: A Programme has ProgrammeInstances at multiple Campuses (Abuja, Lagos).
Expected behavior:
  - One Programme card in search results (one card per Programme per CON-004).
  - instances[] nested array contains both Campus-specific instances.
  - Campus facet shows both options.
  - Detail page lists both Campus offerings.
Actual documented contract: V4.6 canonical/05-implementation.md §8.3.1 nested filter syntax; §8.4a context semantics.
Source of authority: CON-004, TYPESENSE-001 (pending), PROJECTION-017.
Result: ✅ PASS (V4.6 handles multi-campus correctly; nested filter syntax remediated in V4.6 §8.3.1).
```

### S-3 — Programme with multiple delivery modes

```text
Scenario: A Programme has ProgrammeInstances with OnCampus and Online delivery modes.
Expected behavior:
  - One Programme card.
  - Delivery Mode facet shows both options.
  - Same-element nested filtering: filter by Campus=Abuja AND DeliveryMode=Online returns only instances matching BOTH on the same instance.
Actual documented contract: V4.6 canonical/05-implementation.md §8.3.1 (V4.6 MANIFEST §71 remediation).
Source of authority: PROJECTION-017, TYPESENSE-001.
Result: ✅ PASS (V4.6 §8.3.1 documents the correct grouped filter syntax `instances.{campus:=Abuja && delivery_mode:=OnCampus}`).
```

### S-4 — Multiple academic years

```text
Scenario: A Programme has ProgrammeInstances for 2025/2026 and 2026/2027 academic years.
Expected behavior:
  - Both years visible in facets.
  - Default display shows current year (or "Multiple years available").
  - Historical year data preserved.
Actual documented contract: V4.6 ProgrammeInstance identity (programme, campus, delivery_mode, academic_year) per INV-PI1.
Source of authority: CON-002, TYPESENSE-001.
Result: ✅ PASS.
```

### S-5 — Multiple instance admission states

```text
Scenario: A Programme has two instances: Abuja (admission open) and Lagos (admission closed).
Expected behavior:
  - Programme is visible in search (at least one instance is admission-open).
  - Top-level is_admission_open = true (aggregate per V4.7 §34).
  - Filter by "admission open" returns this Programme.
  - Result card displays "Multiple admission states" or contextual display per V4.7 §35.
Actual documented contract: V4.6 has is_admission_open top-level field but NO contextual result status contract.
Source of authority: TYPESENSE-001 §Programme Result Status (pending), V4.7 §35.
Result: ❌ FAIL — V4.6 lacks Programme Result Status contract (F-044). V4.7 remediation adds TYPESENSE-001 §Programme Result Status.
```

### S-6 — Search filter matching only one instance

```text
Scenario: Programme has instances: Abuja/OnCampus/Open and Lagos/Online/Closed. User filters by Campus=Abuja AND DeliveryMode=OnCampus.
Expected behavior:
  - Same-element nested filter returns this Programme (the Abuja/OnCampus instance matches both conditions on the same instance).
  - Result card displays admission status of the MATCHING instance (Abuja/Open), not the Programme-level aggregate.
  - "Open at Abuja" display.
Actual documented contract: V4.6 §8.3.1 nested filter syntax (correct); §8.4a context semantics (correct).
Source of authority: PROJECTION-017, TYPESENSE-001 §Programme Result Status (pending).
Result: ⚠️ PARTIAL — V4.6 has correct filter syntax but lacks formal Programme Result Status contract. V4.7 adds TYPESENSE-001 §Programme Result Status.
```

### S-7 — Programme with no published instances

```text
Scenario: A Programme has is_published=true but no ProgrammeInstance has is_published=true.
Expected behavior:
  - Programme is NOT visible in public search (publication predicate fails per CON-004).
  - No Typesense document is created (or document exists with is_searchable=false per PROJECTION-014).
Actual documented contract: V4.6 canonical/04-architecture.md §6 publication predicate.
Source of authority: CON-004, PROJECTION-014 (pending).
Result: ✅ PASS (V4.6 handles this correctly per CON-004).
```

### S-8 — Discontinued Programme with historical page

```text
Scenario: A Programme has ProgrammeStatus::Discontinued.
Expected behavior:
  - Programme NOT in public search (per SEO-001 matrix).
  - Canonical URL returns 200 (historical value remains).
  - Page displays "This programme has been discontinued" notice.
  - Historical admission info visible.
  - Indexability per explicit SEO policy.
  - Sitemap per explicit policy.
Actual documented contract: V4.6 product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md §11.3; product-experience/FIRST-VERTICAL-SLICE-UX.md §17.3.
Source of authority: SEO-001 (pending), LIFE-001 (pending DEC-035).
Result: ⚠️ PARTIAL — V4.6 has informal handling but no single explicit contract matrix. V4.7 adds SEO-001 matrix.
```

### S-9 — Suspended Programme

```text
Scenario: A Programme has ProgrammeStatus::Suspended.
Expected behavior:
  - Programme NOT in public search (normally).
  - Canonical URL returns 200.
  - Page displays "Admission currently suspended" badge.
  - Cut-offs and requirements still visible.
  - Indexability per explicit SEO policy.
Actual documented contract: V4.6 product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md §11.3.
Source of authority: SEO-001 (pending), LIFE-001.
Result: ⚠️ PARTIAL — V4.6 informal; V4.7 adds SEO-001 matrix.
```

### S-10 — Hard-deleted projection

```text
Scenario: A Programme is hard-deleted (not just discontinued).
Expected behavior:
  - Explicit deletion event emitted.
  - Durable projection tombstone/state retained.
  - Typesense document physically deleted.
  - Stale older revisions must not recreate it (per PROJECTION-014).
Actual documented contract: V4.6 has no explicit deletion event contract; relies on Scout's `delete()` method.
Source of authority: PROJECTION-014 (pending).
Result: ❌ FAIL — V4.6 lacks PROJECTION-014 contract (F-002). V4.7 remediation adds it.
```

### S-11 — Late stale projection job

```text
Scenario: A projection job for revision R1 is delayed; a newer revision R2 is processed first; then R1 arrives.
Expected behavior:
  - R1 must NOT overwrite R2 (R2 is newer).
  - Worker checks: if a newer revision is already applied, skip R1.
  - Or: coalescing state ensures only newest is processed.
Actual documented contract: V4.6 has no coalescing contract; relies on Scout queue ordering.
Source of authority: PROJECTION-004 (pending), PROJECTION-011 (pending).
Result: ❌ FAIL — V4.6 lacks runtime coalescing contract (F-002). V4.7 adds PROJECTION-004.
```

### S-12 — Two concurrent projection mutations

```text
Scenario: Two canonical mutations T1 (Institution 55 name change) and T2 (Programme 101 tuition change) commit near-simultaneously, both affecting Programme 101's projection.
Expected behavior:
  - T1 and T2 each get immutable projection_event_revision (R1, R2).
  - If T1 commits before T2, R1 < R2 (per PROJECTION-001).
  - Per-identity serialization: only one projection job runs at a time for Programme 101 (per SERIAL-001).
  - Newest revision processed; older revision skipped if newer already applied.
Actual documented contract: V4.6 has no projection_event_revision; no WithoutOverlapping with shared logical identity.
Source of authority: PROJECTION-001, PROJECTION-004, SERIAL-001 (all pending).
Result: ❌ FAIL — V4.6 lacks all three contracts (F-002, F-008). V4.7 adds them.
```

### S-13 — Institution mutation affecting hundreds of Programmes

```text
Scenario: Institution 55 changes its name. This affects 300 Programmes under Institution 55.
Expected behavior:
  - One canonical mutation → one projection_event with revision R.
  - 300 projection_event_targets rows inserted (one per affected Programme) atomically in the same transaction.
  - Target inserts may be batched/chunked within the transaction.
  - No semantic fan-out cap.
  - No queue jobs dispatched from inside the canonical transaction.
  - Historical affectedness: even if a Programme moves to another Institution before processing, the event retains it as a target.
Actual documented contract: V4.6 has no projection_event_targets table; relies on Scout's `searchable()` method per-model.
Source of authority: PROJECTION-002, PROJECTION-003 (pending).
Result: ❌ FAIL — V4.6 lacks target capture (F-002). V4.7 adds PROJECTION-002, PROJECTION-003.
```

### S-14 — Programme mutation during Institution fan-out

```text
Scenario: Institution 55 changes its name (event E1 with 300 Programme targets). Before E1 is processed, Programme 101 (one of the 300) is moved to Institution 77 (event E2).
Expected behavior:
  - E1 still targets Programme 101 (historical affectedness per PROJECTION-003).
  - When E1 is processed, Programme 101's projection reflects Institution 55's new name (the snapshot at E1's mutation time).
  - When E2 is processed, Programme 101's projection reflects Institution 77.
  - Final state: Programme 101 → Institution 77.
Actual documented contract: V4.6 has no historical affectedness contract.
Source of authority: PROJECTION-003 (pending), PROJECTION-005 (snapshot at mutation time).
Result: ❌ FAIL — V4.6 lacks historical affectedness (F-002). V4.7 adds PROJECTION-003.
```

### S-15 — Projection worker crash after Typesense write

```text
Scenario: Worker processes projection_event R10. It writes to Typesense (document revision = R10). Worker crashes BEFORE recording APPLIED in projection_states.
Expected behavior:
  - Reconciliation inspects Typesense: document revision = R10, fingerprint matches.
  - Reconciliation checks durable event history: R10 was emitted.
  - Reconciliation marks projection_states.lifecycle_state = APPLIED, last_applied_projection_revision = R10.
  - Never invent a replacement freshness revision because of the crash (per PROJECTION-012).
Actual documented contract: V4.6 has no crash recovery contract; Scout queue retries may produce duplicate writes.
Source of authority: PROJECTION-011, PROJECTION-012 (pending).
Result: ❌ FAIL — V4.6 lacks crash recovery (F-002). V4.7 adds PROJECTION-011, PROJECTION-012.
```

### S-16 — Typesense outage

```text
Scenario: Typesense is unavailable when a user performs a public search.
Expected behavior:
  - Public search returns explicit unavailable/search-failure state.
  - Do NOT return zero results as a disguise.
  - Do NOT silently switch to PostgreSQL.
  - Canonical browse/detail pages (PostgreSQL) remain available.
  - Optional search-powered components fail closed or are omitted.
Actual documented contract: V4.6 MANIFEST §4.30 says "basic facets remain functional via PostgreSQL query-builder" — this IS the silent switch V4.7 §13 forbids.
Source of authority: OUTAGE-001 (pending), SEARCH-001 (pending).
Result: ❌ FAIL — V4.6 has the forbidden fallback behavior (F-001, F-042). V4.7 adds OUTAGE-001, SEARCH-001.
```

### S-17 — Collection v7 → v8 rebuild while live projections continue

```text
Scenario: A projection contract change requires rebuilding the Typesense programmes collection from v7 to v8.
Expected behavior:
  - Current live collection: programmes_v7 (via alias `programmes`).
  - Take consistent canonical snapshot S.
  - Build new collection programmes_v8 from snapshot S.
  - Retain durable projection-event stream.
  - Replay/catch up events > S into programmes_v8.
  - Verify programmes_v8 watermark/currentness.
  - Switch alias `programmes` → programmes_v8.
  - Previous known-good collection programmes_v7 retained.
  - No new permanent dual-write mode.
  - Live projections continue (events flow to both during transition? No — alias switch is atomic; events after switch go to v8).
Actual documented contract: V4.6 has no collection versioning contract.
Source of authority: PROJECTION-015, PROJECTION-016 (pending).
Result: ❌ FAIL — V4.6 lacks collection versioning (F-020). V4.7 adds PROJECTION-015, PROJECTION-016.
```

### S-18 — Rebuild catch-up

```text
Scenario: During collection v7→v8 rebuild, new canonical mutations occur (events E10, E11, E12 after snapshot S).
Expected behavior:
  - E10, E11, E12 are captured in projection_events normally.
  - During rebuild, events > S are replayed into programmes_v8.
  - After alias switch, events continue flowing to programmes_v8.
  - No events lost; no events duplicated.
Actual documented contract: V4.6 has no rebuild catch-up contract.
Source of authority: PROJECTION-016 (pending).
Result: ❌ FAIL — V4.6 lacks rebuild catch-up (F-020). V4.7 adds PROJECTION-016.
```

### S-19 — Import artifact with warning only

```text
Scenario: An import artifact has 100 records. 95 pass validation; 5 have WARNINGS (non-blocking). No blocking errors.
Expected behavior:
  - All 100 records applied to canonical state (per INGEST-001).
  - Warnings recorded but do not block application.
  - canonical_imports state → APPLIED.
Actual documented contract: V4.6 §13 says "atomicity is per-record, not per-artifact" — but warnings are not blocking errors, so they coexist with successful application.
Source of authority: INGEST-001 (pending).
Result: ⚠️ PARTIAL — V4.6 handles warnings correctly but lacks formal INGEST-001 contract. V4.7 adds INGEST-001.
```

### S-20 — Import artifact with one blocking error

```text
Scenario: An import artifact has 100 records. 95 pass validation; 4 have warnings; 1 has a BLOCKING ERROR.
Expected behavior:
  - Entire artifact rejected (per INGEST-001).
  - Zero canonical records committed.
  - canonical_imports state → VALIDATION_FAILED.
  - Warnings do not affect the blocking outcome.
Actual documented contract: V4.6 §13 says "atomicity is per-record, not per-artifact ... other records in the same artifact are still applied."
Source of authority: INGEST-001 (pending).
Result: ❌ FAIL — V4.6 has per-record atomicity (F-004), contradicting V4.7 §37. V4.7 adds INGEST-001 with artifact-level atomicity.
```

### S-21 — Import retry after crash

```text
Scenario: An import execution E1 starts applying an artifact. Worker crashes midway. Canonical application did not commit.
Expected behavior:
  - Retry uses the SAME execution_id (per INGEST-002).
  - canonical_imports.execution_id unchanged.
  - canonical_imports.state → APPLYING (resumed).
  - If retry succeeds, state → APPLIED.
Actual documented contract: V4.6 has no canonical_imports table; relies on import_batches workflow state.
Source of authority: INGEST-002, INGEST-003 (pending).
Result: ❌ FAIL — V4.6 lacks canonical_imports durable state (F-019). V4.7 adds INGEST-003.
```

### S-22 — Explicit artifact replay

```text
Scenario: An artifact was successfully applied (state = APPLIED). An administrator explicitly replays it.
Expected behavior:
  - Replay creates a NEW execution_id (per INGEST-002).
  - original_execution_id references the first execution.
  - Original approval remains valid for the same immutable artifact hash (per TRUST-002).
  - Replay records: operator, timestamp, reason, artifact hash, replay execution identity.
  - Original execution history NOT mutated.
Actual documented contract: V4.6 has no replay contract.
Source of authority: TRUST-002, INGEST-002, INGEST-003 (pending).
Result: ❌ FAIL — V4.6 lacks replay contract (F-003, F-019). V4.7 adds TRUST-002, INGEST-002, INGEST-003.
```

### S-23 — Forged approval from compromised acquisition environment

```text
Scenario: The acquisition environment is compromised. An attacker attempts to push an import artifact with a forged approval signature.
Expected behavior:
  - Stage 1 (transport HMAC): passes (attacker has the transport secret).
  - Stage 2 (approval signature): FAILS — attacker does NOT have the production control plane's private signing key (per TRUST-001).
  - Server looks up canonical_imports by artifact_hash: no APPROVED record exists (attacker never went through Filament approval UI).
  - Response: 403 Forbidden.
  - Alert triggered.
Actual documented contract: V4.6 has HMAC-shared-secret only; attacker with the shared secret can forge approval.
Source of authority: TRUST-001 (pending).
Result: ❌ FAIL — V4.6 has single-stage HMAC (F-003). V4.7 adds TRUST-001 two-stage model.
```

### S-24 — Duplicate artifact submission

```text
Scenario: An approved artifact (artifact_hash = H) was already successfully applied (state = APPLIED). The acquisition worker resubmits the same artifact.
Expected behavior:
  - Server looks up canonical_imports by artifact_hash = H: state = APPLIED.
  - Normal production ingestion of an already-consumed approved artifact is REJECTED (per TRUST-002).
  - Response: 409 Conflict.
  - Explicit administrative replay is allowed but requires a new execution_id.
Actual documented contract: V4.6 has no duplicate detection contract.
Source of authority: TRUST-002, INGEST-003 (pending).
Result: ❌ FAIL — V4.6 lacks duplicate detection (F-003). V4.7 adds TRUST-002.
```

### S-25 — Same-scope source conflict

```text
Scenario: Two InformationSources at the same scope (institution-level) provide conflicting admission policies for ProgrammeInstance X. Source A (priority 10) says "cut-off = 200". Source B (priority 5) says "cut-off = 250".
Expected behavior:
  - Source priority resolves: Source A (higher priority) wins (per SRC-001).
  - Cut-off = 200 applied.
  - Conflict recorded in field_provenance.
  - Priority changes affect future resolution unless explicit re-reconciliation is performed.
Actual documented contract: V4.6 has `priority` column on `information_sources` (mentioned in canonical/05-implementation.md:1507) but no registered contract.
Source of authority: SRC-001 (pending).
Result: ⚠️ PARTIAL — V4.6 has the column but no contract. V4.7 adds SRC-001.
```

### S-26 — Instance vs institution policy conflict

```text
Scenario: Institution-level policy says "cut-off = 200 for all programmes". Instance-specific policy says "cut-off = 250 for ProgrammeInstance X".
Expected behavior:
  - Instance-specific policy wins (per SRC-002 canonical precedence: instance > institution > no policy).
  - Cut-off = 250 applied to ProgrammeInstance X.
  - Institution-level policy does NOT override instance-specific policy merely because institution source has greater source priority.
Actual documented contract: V4.6 has no precedence contract.
Source of authority: SRC-001, SRC-002 (pending).
Result: ❌ FAIL — V4.6 lacks precedence contract (F-034). V4.7 adds SRC-001, SRC-002.
```

### S-27 — Pending revision conflict

```text
Scenario: User A submits PendingRevision P1 (cut-off = 200). Before P1 is approved, User B submits PendingRevision P2 (cut-off = 250) for the same target.
Expected behavior:
  - P2 supersedes P1 (per REV-001 lifecycle: superseded).
  - P1 state → superseded.
  - P2 state → submitted (awaiting approval).
  - Approver cannot be User A or User B (per RBAC-001 self-approval prevention).
  - Polymorphic entity reference validated at application/domain boundary.
Actual documented contract: V4.6 has pending_revisions table but no supersession lifecycle contract; no self-approval prevention.
Source of authority: REV-001, RBAC-001 (pending).
Result: ❌ FAIL — V4.6 lacks lifecycle and self-approval prevention (F-021, F-033). V4.7 adds REV-001, RBAC-001.
```

### S-28 — Unauthorized approval

```text
Scenario: User with role `content-editor` attempts to approve a PendingRevision.
Expected behavior:
  - content-editor role has `view` capability but NOT `approve` capability.
  - Approval action fails with 403 Forbidden.
  - Activity log records the denied attempt.
Actual documented contract: V4.6 RBAC roles documented in canonical/05-implementation.md §5.
Source of authority: RBAC-001 (pending), V4.6 §5 RBAC inventory.
Result: ⚠️ PARTIAL — V4.6 has RBAC inventory but no formal self-approval prevention contract. V4.7 adds RBAC-001.
```

### S-29 — Organization-scoped authorization

```text
Scenario: User is `owner` of Organization 55. User attempts to approve a PendingRevision for a Programme under Organization 55.
Expected behavior:
  - User has `approve` capability scoped to Organization 55.
  - Approval succeeds IF user is not the submitter (per RBAC-001).
  - User attempts to approve a PendingRevision for a Programme under Organization 77 → 403 Forbidden (not a member of Org 77).
Actual documented contract: V4.6 OrganizationMember pivot with bare role strings (owner, admin, admissions, editor, viewer).
Source of authority: CON-007 (auth stack), RBAC-001 (pending).
Result: ✅ PASS (V4.6 handles organization scoping correctly).
```

### S-30 — SEO curated page

```text
Scenario: User requests `/programmes/computer-science` (a curated discipline landing page).
Expected behavior:
  - Page renders with 200 OK.
  - Page is indexable (per SEO-002 registry: explicitly registered curated discipline page).
  - Sitemap eligible (per SEO-003: published AND public AND indexable AND SEO-contract-approved).
  - Structured data present (per SEO-004).
  - Page served from Typesense (public search/discovery).
Actual documented contract: V4.6 §4.26-4.27 discipline URL path-style; informal SEO rules.
Source of authority: SEO-001, SEO-002, SEO-003, SEO-004 (all pending).
Result: ⚠️ PARTIAL — V4.6 has the URL pattern but no formal SEO contracts. V4.7 adds SEO-001 through SEO-004.
```

### S-31 — Arbitrary faceted URL

```text
Scenario: User requests `/programmes?discipline=computer-science&campus=abuja&delivery_mode=online&sort=tuition_asc&page=47`.
Expected behavior:
  - Page renders with 200 OK (search results from Typesense).
  - Page is NOT indexable (per SEO-002: arbitrary filter combinations, arbitrary sort URLs, arbitrary pagination are non-indexable by default).
  - Sitemap NOT eligible.
  - robots meta tag: noindex.
  - Canonical URL points to `/programmes` (the base search page).
Actual documented contract: V4.6 has informal SEO rules; no registry.
Source of authority: SEO-002 (pending).
Result: ❌ FAIL — V4.6 lacks SEO-002 registry. V4.7 adds SEO-002.
```

### S-32 — Redirect chain attempt

```text
Scenario: Administrator creates a redirect: /old-programme-1 → /new-programme-1. Then attempts to create: /new-programme-1 → /new-programme-2.
Expected behavior:
  - Second redirect creation REJECTED (would form a chain: /old-programme-1 → /new-programme-1 → /new-programme-2).
  - Response: 422 Unprocessable Entity.
  - Redirect chains forbidden (per SEO-005).
Actual documented contract: V4.6 has no redirect contract.
Source of authority: SEO-005 (pending).
Result: ❌ FAIL — V4.6 lacks SEO-005 (F-017). V4.7 adds SEO-005.
```

### S-33 — Historical redirect

```text
Scenario: A redirect /old-programme-1 → /new-programme-1 was created 3 years ago. It is still active.
Expected behavior:
  - Redirect retained indefinitely (per SEO-005).
  - HTTP 301 returned.
  - Historical redirects are NOT automatically rewritten.
  - Only retired explicitly by administrator action.
Actual documented contract: V4.6 has no redirect contract.
Source of authority: SEO-005 (pending).
Result: ❌ FAIL — V4.6 lacks SEO-005. V4.7 adds SEO-005.
```

### S-34 — Structured-data historical page

```text
Scenario: A discontinued Programme's canonical page (HTTP 200, historical value retained). Page has structured data (schema.org Course).
Expected behavior:
  - Structured data accurately represents historical truth (per SEO-004).
  - Does NOT falsely claim current availability.
  - noindex state is not itself a reason to declare structured data invalid.
  - Historical admission info visible in structured data with appropriate `validFrom`/`validThrough` properties.
Actual documented contract: V4.6 has informal structured-data intent.
Source of authority: SEO-004 (pending).
Result: ⚠️ PARTIAL — V4.6 informal. V4.7 adds SEO-004.
```

### S-35 — Typesense unavailable on primary search

```text
Scenario: User navigates to `/programmes` (primary search page). Typesense is unavailable.
Expected behavior:
  - Page renders with explicit unavailable/search-failure state (per OUTAGE-001).
  - "Search is temporarily unavailable. Please try again later." message.
  - HTTP 200 (page itself is reachable; search service is down).
  - Do NOT return zero results as a disguise.
  - Do NOT silently switch to PostgreSQL.
  - Canonical browse/detail pages (PostgreSQL) remain available.
Actual documented contract: V4.6 MANIFEST §4.30 says "basic facets remain functional via PostgreSQL query-builder" — forbidden by V4.7 §13.
Source of authority: OUTAGE-001 (pending), SEARCH-001 (pending).
Result: ❌ FAIL — V4.6 has the forbidden fallback behavior (F-001, F-042). V4.7 adds OUTAGE-001, SEARCH-001.
```

### S-36 — Typesense unavailable on optional related-programme component

```text
Scenario: User views `/programmes/computer-science-bsc` (Programme detail page). The page has an optional "Related programmes" component powered by Typesense. Typesense is unavailable.
Expected behavior:
  - Canonical Programme detail page renders normally (from PostgreSQL per CON-005, SEARCH-001).
  - "Related programmes" component fails closed or is omitted (per OUTAGE-001).
  - UI shows "Related programmes temporarily unavailable" or omits the section.
  - HTTP 200 (page is available; optional component is degraded).
Actual documented contract: V4.6 has no contract for optional component outage.
Source of authority: OUTAGE-001 (pending).
Result: ❌ FAIL — V4.6 lacks optional-component outage contract (F-042). V4.7 adds OUTAGE-001.
```

---

## Summary

| Result | Count | Scenarios |
|--------|-------|-----------|
| ✅ PASS | 5 | S-1, S-2, S-3, S-4, S-7, S-29 (6 actually) |
| ⚠️ PARTIAL | 7 | S-6, S-8, S-9, S-19, S-25, S-28, S-30, S-34 (8 actually) |
| ❌ FAIL | 22 | S-5, S-10, S-11, S-12, S-13, S-14, S-15, S-16, S-17, S-18, S-20, S-21, S-22, S-23, S-24, S-26, S-27, S-31, S-32, S-33, S-35, S-36 |
| 🔒 BLOCKED | 0 | (no scenarios blocked on user decisions; all ❌ FAIL scenarios have approved V4.7 contracts ready for implementation) |

**Total: 36 scenarios. 6 PASS, 8 PARTIAL, 22 FAIL, 0 BLOCKED.**

The 22 ❌ FAIL scenarios all have approved V4.7 contracts (FROZEN decisions from the V4.7 prompt) ready for implementation. The 8 ⚠️ PARTIAL scenarios have V4.6 informal handling that V4.7 formalizes into registered contracts.

**No scenario is BLOCKED on user decisions** — all 36 scenarios can be resolved by implementing the FROZEN V4.7 contracts.

---

## Implementation Priority

Based on scenario failures, the highest-priority remediations are:

1. **PROJECTION-001 through PROJECTION-017** (addresses S-10, S-11, S-12, S-13, S-14, S-15, S-17, S-18 — 8 scenarios)
2. **SEARCH-001 + OUTAGE-001** (addresses S-16, S-35, S-36 — 3 scenarios)
3. **TRUST-001, TRUST-002, INGEST-001, INGEST-002, INGEST-003** (addresses S-20, S-21, S-22, S-23, S-24 — 5 scenarios)
4. **TYPESENSE-001** (addresses S-5, S-6, S-31 — 3 scenarios)
5. **SRC-001, SRC-002** (addresses S-25, S-26 — 2 scenarios)
6. **REV-001, RBAC-001** (addresses S-27, S-28 — 2 scenarios)
7. **SEO-002, SEO-005** (addresses S-31, S-32, S-33 — 3 scenarios)

Total: 22 scenarios resolved by 7 contract groups.

---

*End of Scenario Verification Report. 36 scenarios simulated; 22 FAIL; all resolvable by implementing FROZEN V4.7 contracts.*
