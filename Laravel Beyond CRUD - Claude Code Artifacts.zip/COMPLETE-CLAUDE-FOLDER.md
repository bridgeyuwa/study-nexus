# Complete .claude Folder — Laravel Beyond CRUD (2nd Edition)

All 23 artifacts in their final state. PHP 8.2 / Laravel 9 / Pest.

---

### root/README.md
```md
# .claude — Laravel Beyond CRUD Knowledge Base

Extracted from *Laravel Beyond CRUD* by Brent Roose (Spatie, 2020; 2nd edition revised 2022 by Freek Van der Herten). Code samples target **PHP 8.2 / Laravel 9**.

This folder contains the full architecture, patterns, rules, and skills from the book, organised for use as Claude project context.

> **Terminology note:** The 2nd edition uses "data objects" and "DTOs" interchangeably. Both refer to the same pattern of wrapping unstructured data in typed classes.

---

## Folder Map

```
.claude/
├── rules/                          ← Hard rules and decision guides
│   ├── architecture.md             ← Core principles (start here)
│   ├── naming-conventions.md       ← Suffixes, method names, folder names
│   ├── domain-vs-application.md    ← What belongs where
│   ├── anti-patterns.md            ← What NOT to do
│   └── decision-guide.md           ← Quick cheat sheet
│
├── context/                        ← Background knowledge and reference
│   ├── folder-structure.md         ← Full canonical project layout
│   ├── php-type-system.md          ← Type theory background
│   ├── managing-domains.md         ← Team guidance, identifying domains
│   ├── spatie-packages.md          ← All relevant Spatie packages
│   └── further-reading.md          ← Books, talks, articles from footnotes
│
├── skills/                         ← Deep how-to guides per pattern
│   ├── domain/
│   │   ├── dtos.md                 ← Data Objects / DTOs
│   │   ├── actions.md              ← Actions pattern
│   │   ├── models.md               ← Thin models, query builders, collections
│   │   ├── states.md               ← State pattern and transitions
│   │   └── enums.md                ← Enums vs states, native PHP 8.1 enums
│   ├── application/
│   │   ├── application-structure.md ← Feature modules, multiple apps
│   │   ├── view-models.md          ← View model pattern
│   │   ├── http-query-builders.md  ← URL param to SQL mapping
│   │   └── jobs.md                 ← Jobs as queue infrastructure only
│   └── testing/
│       ├── test-factories.md       ← Custom immutable test factories
│       └── testing-domain.md       ← How to test each pattern
│
└── commands/
    └── scaffolding.md              ← Templates and checklists for new classes
```

---

## Reading Order

If you're new to this architecture:

1. `rules/architecture.md` — understand the core principles
2. `context/folder-structure.md` — see the full picture
3. `rules/domain-vs-application.md` — know where everything goes
4. `skills/domain/dtos.md` → `actions.md` → `models.md` — the core triad
5. `skills/domain/states.md` → `enums.md` — model state management
6. `skills/application/` — the application layer patterns
7. `skills/testing/` — how to test it all
8. `rules/anti-patterns.md` — what to watch out for
9. `rules/decision-guide.md` — quick reference for daily use

---

## The One-Sentence Summary

> Group code by business concept (not technical type), separate domain logic from application infrastructure, make every business operation an explicit action class, and use strong typing throughout.

---

## Key Quotes

> "Has a client ever told you to 'work on the controllers now'? No — they ask you to work on invoicing, customer management or booking features."

> "It's not about writing the smallest number of characters or about the elegance of code. It's about making large codebases easier to navigate."

> "Actions allow the programmer to think in ways that are closer to the real world, instead of the code."

> "You have to take every opportunity you can to reduce cognitive load."

> "Don't be afraid to start using domains because you can always refactor them later."

```

---

### rules/architecture.md
```md
# Laravel Beyond CRUD — Architecture Rules

These are the non-negotiable principles for building larger-than-average Laravel applications.

---

## 1. Group Code by Business Concept, Not Technical Type

**WRONG:** Group all controllers together, all models together, all jobs together.

**RIGHT:** Group all invoice-related code together — its controllers, models, actions, data objects, states, jobs.

> "Has a client ever told you to 'work on the controllers now'? No — they ask you to work on invoicing, customer management or booking features."

Apply this in both the Domain layer and the Application layer. The same grouping principle governs both.

---

## 2. Separate Domain from Application

Every project has two distinct layers:

**Domain** — pure business logic. Has no knowledge of HTTP, requests, or framework infrastructure.
- Data Objects (DTOs)
- Actions
- Commands (domain commands, not Artisan)
- Models (data-oriented only)
- States & Transitions
- Enums
- Query Builders (Eloquent)
- Collections
- Events & Listeners
- Domain Exceptions
- Validation Rules

**Application** — consumes the domain and exposes it to users.
- Controllers
- Requests
- Middleware
- Resources (API)
- View Models
- HTTP Query Builders
- Jobs
- Commands (Artisan)

Applications do NOT talk to each other directly. They each consume the shared domain independently.

---

## 3. One Project, Multiple Applications

A single Laravel project may have several application surfaces:

```
app/Http/     — HTTP controllers, middleware, requests, resources, view models
app/Console/  — Artisan commands
```

Or, if extracting further:

```
src/App/Admin/     — HTTP admin panel
src/App/Api/       — REST API
src/App/Console/   — Artisan commands
```

Each is a standalone entry point into the domain. They share domain code but are otherwise isolated.

---

## 4. Namespace Root Structure

**Default approach (recommended for most projects):** Keep the Domain namespace inside `app/`:

```
app/
├── Domain/          ← All business logic, grouped by concept
├── Http/            ← Controllers, middleware, requests, etc.
├── Console/         ← Artisan commands
└── ...
```

No composer.json changes needed. This provides a good balance between domain-oriented structure and staying close to Laravel conventions.

**Extracted approach (optional, for larger projects):**

```json
{
  "autoload": {
    "psr-4": {
      "App\\": "src/App/",
      "Domain\\": "src/Domain/",
      "Support\\": "src/Support/"
    }
  }
}
```

`Support\` is the dumping ground for global helpers, base classes, and utilities that belong nowhere specific — things that could have been part of the framework itself.

---

## 5. Reduce Cognitive Load Above All Else

Every architectural decision should be evaluated against one primary question:

> Does this make the codebase easier to understand and navigate for a team working on it for years?

Metrics that indicate success:
- A new developer can work independently after a few hours of onboarding
- You know exactly where to go when a business requirement changes
- No magic, no hidden global state, no implicit coupling

---

## 6. Embrace the Framework, Don't Fight It

Use Laravel's extension points rather than introducing alien patterns:

- Use `newEloquentBuilder()` instead of repositories
- Use `newCollection()` for custom collection classes
- Use `$dispatchesEvents` for model event remapping
- Use `spatie/laravel-model-states` for the state pattern

---

## 7. Pragmatism Over Purity

These are guidelines, not laws. When two approaches have the same outcome but one is significantly simpler — choose simpler. Revisit the decision when complexity grows.

> "Don't think of this book as giving a fixed set of rules. Think of it as handing you a collection of ideas."

When starting a new project, you don't have to use domains from day one. Start with the standard Laravel structure, and refactor into domains when directories grow too large. Using a good IDE like PhpStorm, moving namespaces around can be done very fast.

```

---

### rules/naming-conventions.md
```md
# Naming Conventions

Consistent naming eliminates ambiguity in large codebases.

---

## Suffix All Domain Classes

Always suffix classes with their type. The name alone must never be ambiguous.

| Class | Wrong | Right |
|---|---|---|
| Action | `CreateInvoice` | `CreateInvoiceAction` |
| Data Object | `CustomerData` ✓ | (Data objects are already descriptive) |
| State | `Pending` | `PendingInvoiceState` |
| Transition | `PendingToPaid` | `PendingToPaidTransition` |
| Query Builder | `InvoiceQuery` | `InvoiceIndexQuery` |
| View Model | `InvoiceForm` | `InvoiceFormViewModel` |
| Event | `InvoiceSaving` | `InvoiceSavingEvent` |
| Subscriber | `Invoice` | `InvoiceSubscriber` |
| Factory (test) | `Invoice` | `InvoiceFactory` |
| Collection | `InvoiceLines` | `InvoiceLineCollection` |
| Job | `SendInvoiceMail` | `SendInvoiceMailJob` |

**Why:** `CreateInvoice` could be a controller, a command, a job, a request, or an action. Suffixes eliminate this collision entirely.

**Long names are fine.** IDE autocompletion handles them.

```php
// This is a real class name from a real project. It's fine.
CreateOrUpdateHabitantContractUnitPackageAction
```

---

## Action Method Name: `execute`

Do not use `__invoke` (causes PHP syntax issues when composing actions).
Do not use `handle` (Laravel hijacks it for method injection in jobs/commands).

Use `execute`:

```php
class CreateInvoiceAction
{
    public function execute(InvoiceData $invoiceData): Invoice
    {
        // ...
    }
}
```

---

## Factory Static Constructor: `new`

Test factories use `new()` as their static constructor, NOT `make()` or `create()`:

```php
InvoiceFactory::new()->create();
InvoiceFactory::new()->paid()->create();
```

**Why:** `make` and `create` imply the factory is producing a result. `new` is clearly just instantiation, leaving the intent to the chained methods.

---

## Application Modules Mirror Business Concepts

Within an application, group by feature/module — not by technical type:

```
Http/Invoices/
    Controllers/
    Filters/
    Middleware/
    Queries/
    Requests/
    Resources/
    ViewModels/
```

NOT:

```
Http/
    Controllers/   ← all mixed together
    Requests/      ← all mixed together
    ViewModels/    ← all mixed together
```

---

## Domain Folder Structure Per Business Concept

```
Domain/Invoices/
    Actions/
    Commands/
    Collections/
    DataTransferObjects/
    Events/
    Exceptions/
    Listeners/
    Models/
    QueryBuilders/
    Rules/
    States/
```

```

---

### rules/domain-vs-application.md
```md
# Domain vs Application — Placement Rules

Use these rules to decide where any given class belongs.

---

## Quick Decision Test

Ask: **"Does this class know about HTTP, requests, or user-facing infrastructure?"**

- Yes → Application layer
- No → Domain layer

---

## Domain Layer — What Belongs Here

The domain knows nothing about how it's consumed. It is framework-agnostic in spirit (even if it uses Eloquent).

| Class Type | Notes |
|---|---|
| **Actions** | Business operations. Take data objects as input, return domain objects. |
| **Data Objects (DTOs)** | Typed data containers. Map from external input at boundaries. |
| **Commands** | Domain commands (not Artisan commands). |
| **Models** | Data-oriented only. No business logic, no send/toPdf methods. |
| **States** | Encapsulate state-specific behaviour. Each state is a class. |
| **Transitions** | Handle state changes and their side effects. |
| **Enums** | Native PHP 8.1 enums for named value sets with no complex conditional flows. |
| **Query Builders** | Eloquent query builder extensions on models. |
| **Custom Collections** | Domain-specific collection methods. |
| **Events** | Specific model events remapped from generic Eloquent events. |
| **Listeners / Subscribers** | React to domain events. May call actions. |
| **Exceptions** | Domain-specific exceptions. |
| **Validation Rules** | Business validation rules. |

---

## Application Layer — What Belongs Here

| Class Type | Notes |
|---|---|
| **Controllers** | Receive HTTP input, call actions, return responses. Thin. |
| **Requests** | Laravel form requests with validation rules. (Or use `spatie/laravel-data` to replace them.) |
| **Middleware** | HTTP-level pre/post processing. |
| **Resources** | API output transformation (JSON). Map one-to-one on models. |
| **View Models** | Prepare data for views. Injected explicitly into controllers. |
| **HTTP Query Builders** | Map URL query params to Eloquent queries (spatie/laravel-query-builder). |
| **Jobs** | Queue management only. Delegate to actions for business logic. |
| **Commands** | Artisan commands. Delegate to actions. |
| **Data Object Factories** | (Alternative: construction logic on the data object itself or via `spatie/laravel-data`.) |

---

## The Boundary: Data Object Construction

The one judgment call: **where does the mapping from Request → data object live?**

**Option 1 — `spatie/laravel-data` (recommended):** Data object extends `Data`, inject directly in controller. Package handles validation and type casting.

```php
class CustomerController
{
    public function update(CustomerData $customerData)
    {
        // Already validated and constructed
    }
}
```

**Option 2 — Dedicated factory** in the application layer.

**Option 3 — Static constructor** on the data object itself (`CustomerData::fromRequest($request)`). Pragmatic but mixes layers.

---

## Jobs Are Application, Not Domain

Jobs manage queue infrastructure. They do NOT contain business logic.

```php
// RIGHT — job delegates to action
class SendInvoiceMailJob implements ShouldQueue
{
    public function __construct(
        public Invoice $invoice,
    ) {}

    public function handle(SendInvoiceMailAction $action): void
    {
        $action->execute($this->invoice);
    }
}

// WRONG — business logic in job
class SendInvoiceMailJob implements ShouldQueue
{
    public function handle(): void
    {
        Mail::to($this->invoice->client)->send(new InvoiceMail($this->invoice));
        $this->invoice->update(['mailed_at' => now()]);
    }
}
```

---

## Models Are Domain, But Keep Them Thin

Models live in the domain but must not handle business logic. They are data providers.

**Allowed in models:**
- Eloquent relations
- Casts
- Simple accessors (reading already-calculated values)
- `$dispatchesEvents` mapping
- `newEloquentBuilder()` override
- `newCollection()` override

**Not allowed in models:**
- Calculations (move to Actions)
- Sending mail / generating PDFs (move to Actions)
- Complex query scopes (move to QueryBuilder class)
- Collection manipulation chains (move to Collection class)
- Service location via `app()` (use DI instead)

```

---

### rules/anti-patterns.md
```md
# Anti-Patterns to Avoid

Everything *Laravel Beyond CRUD* explicitly warns against. Use this as a code review checklist.

---

## 1. Fat Models

**The pattern:** Putting business logic, calculations, and side effects directly in Eloquent models.

```php
// ANTI-PATTERN
class Invoice extends Model
{
    // Calculates on every read — performance problem
    public function getTotalPriceAttribute(): int
    {
        return $this->invoiceLines->reduce(
            fn(int $total, InvoiceLine $line) => $total + $line->total_price,
            0
        );
    }

    // Side effect in a model — belongs in an action
    public function send(): void
    {
        Mail::to($this->client)->send(new InvoiceMail($this));
        $this->update(['sent_at' => now()]);
    }

    // Service location — bad
    public function toPdf(): string
    {
        return app(PdfGenerator::class)->generate($this);
    }
}
```

**Fix:** Move calculations to actions. Store calculated values. Let models only read pre-computed data.

---

## 2. Business Logic in Controllers

**The pattern:** Controllers that grow to contain business rules, conditional logic, and multi-step operations.

```php
// ANTI-PATTERN
class InvoicesController
{
    public function store(InvoiceRequest $request)
    {
        $invoice = Invoice::create($request->validated());

        foreach ($request->lines as $line) {
            $price = $line['amount'] * $line['unit_price'];
            if ($line['vat_included']) {
                $price = $price * 1.21;
            }
            $invoice->lines()->create([...$line, 'total_price' => $price]);
        }

        $pdf = PDF::loadView('invoices.pdf', compact('invoice'));
        Storage::put("invoices/{$invoice->id}.pdf", $pdf->output());

        Mail::to($invoice->client)->send(new InvoiceMail($invoice, $pdf));

        return redirect()->route('invoices.index');
    }
}
```

**Fix:** Extract to `CreateInvoiceAction`. The controller becomes 2-3 lines.

---

## 3. Business Logic in Jobs

**The pattern:** Jobs that do actual work instead of delegating to actions.

```php
// ANTI-PATTERN
class SendInvoiceMailJob implements ShouldQueue
{
    public function handle(): void
    {
        $pdf = PDF::loadView('invoices.pdf', ['invoice' => $this->invoice]);
        Mail::to($this->invoice->client)
            ->cc($this->invoice->accountant)
            ->send(new InvoiceMail($this->invoice, $pdf));
        $this->invoice->update(['mailed_at' => now()]);
        InvoiceMailLog::create(['invoice_id' => $this->invoice->id]);
    }
}
```

**Fix:** Move all of this to `SendInvoiceMailAction`. The job becomes a one-liner delegating to the action.

---

## 4. View Composers for Complex Data

**The pattern:** Registering view composers globally to inject view data from hidden service providers.

```php
// ANTI-PATTERN — hidden, implicit, hard to track
class ViewComposerServiceProvider extends ServiceProvider
{
    public function boot()
    {
        View::composer('invoices.form', function ($view) {
            $view->with('categories', Category::allowedForUser(auth()->user())->get());
            $view->with('clients', Client::all());
        });
    }
}

// Controller reveals nothing about what the view receives
class InvoicesController
{
    public function create()
    {
        return view('invoices.form'); // what variables does this view have? mystery.
    }
}
```

**Fix:** Use an `InvoiceFormViewModel`. The controller explicitly constructs and passes it.

---

## 5. Grouping Application Code by Technical Type (Not Feature)

**The pattern:** All controllers together, all requests together, all view models together.

```
// ANTI-PATTERN — after a year this is unnavigable
App/Admin/
    Controllers/
        InvoicesController.php
        CustomersController.php
        PaymentsController.php
        ... 40 more files
    Requests/
        InvoiceRequest.php
        CustomerRequest.php
        ... 40 more files
    ViewModels/
        InvoiceViewModel.php
        CustomerViewModel.php
        ... 40 more files
```

**Fix:** Group by feature module. `App/Admin/Invoices/` contains all invoice-related app code.

---

## 6. Using Raw Arrays Instead of Data Objects

**The pattern:** Passing untyped arrays as data carriers between layers.

```php
// ANTI-PATTERN
function createInvoice(array $data): Invoice
{
    // What's in $data? No one knows without reading the caller.
    // $data['client_id']? $data['clientId']? $data['client']->id?
}

// Caller
createInvoice([
    'client_id' => $client->id,
    'lines' => $lines, // array of what?
    'due_at' => $date,
]);
```

**Fix:** Use a typed `InvoiceData` data object. All fields are known, typed, and IDE-visible.

---

## 7. Query Scopes on Models Instead of Query Builder Classes

**The pattern:** Adding query scopes directly to the model, making the model file grow.

```php
// ANTI-PATTERN — model accumulates all query logic
class Invoice extends Model
{
    public function scopeWhereOverdue($query) { ... }
    public function scopeWherePaid($query) { ... }
    public function scopeWhereForClient($query, $clientId) { ... }
    public function scopeWhereInDateRange($query, $from, $to) { ... }
    // ... 15 more scopes
}
```

**Fix:** Move to `InvoiceQueryBuilder extends Builder`, wire via `newEloquentBuilder()`.

---

## 8. Magic Strings for State/Type Values

**The pattern:** Hard-coding string values for states and types throughout the codebase.

```php
// ANTI-PATTERN
$invoice->update(['status' => 'paid']);
if ($invoice->status === 'pending') { ... }
Invoice::where('status', 'paid')->get();
```

**Fix:** Use native PHP 8.1 enums or state classes. Changes to the value name cascade correctly.

---

## 9. Mixing Application Code Into the Domain

**The pattern:** Domain classes that import and depend on HTTP request classes.

```php
// ANTI-PATTERN — domain class knows about HTTP
namespace Domain\Invoices\DataTransferObjects;

use Illuminate\Http\Request; // HTTP concern in the domain

class InvoiceData
{
    public static function fromRequest(Request $request): self
    {
        // The domain now depends on the application layer
    }
}
```

**Note:** The book acknowledges this as a pragmatic trade-off for the `fromRequest()` pattern when using typed request classes. Using `spatie/laravel-data` with controller injection avoids this issue entirely — the data object is constructed by the framework without the domain needing to know about HTTP.

---

## 10. Global State in Tests (Non-Immutable Factories)

**The pattern:** Mutable test factories where calling a configuration method on a factory changes it permanently.

```php
// ANTI-PATTERN — mutable factory
$factory = InvoiceFactory::new()->expiresAt('2023-01-01');
$invoiceA = $factory->paid()->create(); // mutates $factory
$invoiceB = $factory->create();         // also paid! unintended.
```

**Fix:** Every configuration method clones `$this` and returns the clone.

```

---

### rules/decision-guide.md
```md
# Quick Decision Guide

Use this cheat sheet when you're unsure where a class belongs or which pattern to use.

---

## Where Does This Class Go?

```
Is it business logic with no HTTP/queue knowledge?
├── YES → Domain layer
│   ├── Represents data only → DataTransferObjects/
│   ├── Performs a business operation → Actions/
│   ├── Is a domain command → Commands/
│   ├── Is an Eloquent model → Models/
│   ├── Encapsulates state behaviour → States/
│   ├── Categorises named values → use native PHP enum (or States/ if complex behaviour)
│   ├── Extends Eloquent Builder → QueryBuilders/
│   ├── Extends Eloquent Collection → Collections/
│   ├── Is a domain event → Events/
│   ├── Reacts to a domain event → Listeners/
│   ├── Is domain-level invalid input → Exceptions/
│   └── Validates business rules → Rules/
│
└── NO → Application layer
    ├── Handles HTTP requests → Controllers/
    ├── Validates HTTP input → Requests/
    ├── Filters HTTP middleware → Middleware/
    ├── Formats API output → Resources/
    ├── Prepares view data → ViewModels/
    ├── Maps URL params to SQL → Queries/
    ├── Manages queue pipeline → Jobs/
    └── Is an Artisan command → Console/Commands/

Is it globally shared, with no domain home?
└── Support/

Is it cross-cutting domain logic used by multiple domains?
└── Domain/Shared/
```

---

## Which Pattern Should I Use?

**I need to represent structured data from a request/API/form:**
→ **Data Object** (`DataTransferObjects/`). Use `spatie/laravel-data` for validation, casting, and form request replacement.

**I need to execute a business operation:**
→ **Action** (`Actions/`)

**My model has complex state-dependent behaviour:**
→ **State Pattern** (`States/`)

**My model has a simple set of fixed values with no complex behaviour:**
→ **Native PHP 8.1 Enum** (no package needed)

**I need to build complex Eloquent queries that are reused:**
→ **Custom Query Builder** (domain `QueryBuilders/`)

**I need to filter a collection in collection-pipeline style:**
→ **Custom Collection** (`Collections/`)

**I need to prepare data for a Blade view:**
→ **View Model** (`ViewModels/`)

**I need to filter/sort a list page from URL params:**
→ **HTTP Query Builder** (application `Queries/`)

**I need to run an action asynchronously:**
→ **Job** (delegates to action) or `->onQueue()->execute()` via `spatie/laravel-queueable-action`

---

## When to Use State vs. Enum

```
Does the value have different BEHAVIOUR per variant?
├── YES → State Pattern
│   └── Each variant = its own class with methods
└── NO → Native Enum
    └── Just categorisation, maybe one simple match expression

Will more variants with distinct behaviour be added over time?
├── YES → State Pattern (extensible by adding new classes)
└── NO → Enum is fine
```

---

## Action Method Naming

```
__invoke  → AVOID (PHP syntax issue when composing actions via properties)
handle    → AVOID (Laravel hijacks for method injection in jobs)
execute   → USE THIS
```

---

## Factory Configuration Methods

```
public function paid(): self
{
    $clone = clone $this;  // ← ALWAYS clone
    $clone->status = PaidInvoiceState::class;
    return $clone;         // ← return the clone, not $this
}
```

Never mutate `$this` in factory configuration methods. Always clone.

---

## Test Structure Template (Pest)

```php
it('describes the behaviour', function () {
    // SETUP — use factories, build state
    $data = SomeFactory::new()->withVariant()->create();
    $action = app(SomeAction::class);

    // EXECUTE — one meaningful operation
    $result = $action->execute($data);

    // ASSERT — verify observable outcomes
    expect($result->value)->toEqual($expected);
    $this->assertDatabaseHas('table', ['column' => 'value']);
});
```

---

## Data Object Construction (PHP 8+)

```
Plain PHP (simple cases):
→ Constructor property promotion + spread
→ new CustomerData(...$request->validated())

With type casting / validation:
→ Use spatie/laravel-data
→ Extend Spatie\LaravelData\Data
→ Inject data object directly in controller (replaces form request)

Legacy (PHP < 8):
→ Use spatie/data-transfer-object with DocBlocks
→ Array construction: new CustomerData([...])
```

---

## Common Mistakes Quick-Reference

| Symptom | Cause | Fix |
|---|---|---|
| Model file > 200 lines | Business logic in model | Extract to actions + query builders |
| Controller > 30 lines | Business logic in controller | Extract to actions |
| Job contains calculations | Business logic in job | Create an action, delegate |
| `$validated['key']` everywhere | No data objects | Create typed data object |
| `if ($status === 'pending')` chains | No state pattern | Create state classes |
| View data duplicated across controller methods | No view model | Create view model |
| IDE shows no autocompletion on factory result | Factory not typed | Add return type to `create()` |
| Two factories interfere with each other | Mutable factory | Use `clone $this` in config methods |
| Large `Domain/Shared/` folder | Wrong domain boundaries | Restructure domains |

```

---

### context/folder-structure.md
```md
# Project Folder Structure

The canonical folder layout for a domain-oriented Laravel project.

---

## Default Structure (Domain Inside `app/`)

For most projects, Spatie recommends keeping the Domain namespace inside the standard `app/` folder. This provides domain-oriented grouping while staying close to Laravel conventions.

```
app/
├── Domain/              ← All business logic, grouped by concept
│   ├── Invoices/
│   ├── Customers/
│   ├── Payments/
│   └── Shared/          ← Cross-cutting domain code (optional)
├── Http/                ← Controllers, middleware, requests, etc.
│   ├── Controllers/
│   ├── Middleware/
│   ├── Requests/
│   ├── Resources/
│   └── ViewModels/
├── Console/
│   └── Commands/
└── Support/             ← Global helpers, base classes
```

No `composer.json` changes are needed for this approach.

---

## Extracted Structure (Optional, for Larger Projects)

If you prefer to fully separate domain and application code into separate root namespaces:

```
src/
├── Domain/          ← All business logic, grouped by concept
├── App/             ← All application layers (HTTP, CLI, API, etc.)
└── Support/         ← Global helpers, base classes, utilities
```

This requires a `composer.json` autoload change:

```json
{
    "autoload": {
        "psr-4": {
            "App\\": "src/App/",
            "Domain\\": "src/Domain/",
            "Support\\": "src/Support/"
        }
    }
}
```

And a custom Application class:

```php
namespace App;

class Application extends \Illuminate\Foundation\Application
{
    protected $namespace = 'App\\';
}
```

```php
// bootstrap/app.php
use App\Application;

$app = (new Application(
    $_ENV['APP_BASE_PATH'] ?? dirname(__DIR__)
))->useAppPath('src/App');
```

---

## Domain Layer

One folder per business concept. Each concept has a consistent internal structure:

```
Domain/
├── Invoices/
│   ├── Actions/
│   │   ├── CreateInvoiceAction.php
│   │   ├── CreateInvoiceLineAction.php
│   │   ├── GeneratePdfAction.php
│   │   └── SendInvoiceMailAction.php
│   ├── Commands/
│   ├── Collections/
│   │   └── InvoiceLineCollection.php
│   ├── DataTransferObjects/
│   │   ├── InvoiceData.php
│   │   └── InvoiceLineData.php
│   ├── Events/
│   │   ├── InvoiceSavingEvent.php
│   │   └── InvoiceDeletingEvent.php
│   ├── Exceptions/
│   │   └── InvalidInvoiceStateException.php
│   ├── Listeners/
│   │   └── InvoiceSubscriber.php
│   ├── Models/
│   │   ├── Invoice.php
│   │   └── InvoiceLine.php
│   ├── QueryBuilders/
│   │   └── InvoiceQueryBuilder.php
│   ├── Rules/
│   │   └── ValidInvoiceNumberRule.php
│   └── States/
│       ├── InvoiceState.php            ← abstract
│       ├── PendingInvoiceState.php
│       ├── PaidInvoiceState.php
│       └── Transitions/
│           └── PendingToPaidTransition.php
│
├── Customers/
│   ├── Actions/
│   ├── DataTransferObjects/
│   ├── Models/
│   └── ...
│
├── Payments/
│   ├── Actions/
│   ├── DataTransferObjects/
│   ├── Models/
│   └── ...
│
└── Shared/                              ← Cross-cutting domain code
    ├── Models/
    │   └── Activity.php                 ← e.g. audit log used by all domains
    └── ...
```

### The `Domain/Shared/` Pattern

For code that doesn't belong to any single domain but is used across several. Example: an Activity model providing audit logging used by Invoices, Customers, and Payments.

**Keep `Shared/` small.** A large `Shared/` domain is a sign you need to restructure. Alternatively, you can put common code in `Support/` instead.

---

## Real-World Domain Examples

### Flare (exception tracker)

```
Domain/
├── Account/
├── Error/
├── Flare/
├── Notification/
├── Project/
├── Shared/
└── Subscription/
```

### Mailcoach (email marketing platform)

```
Domain/
├── Audience/
├── Automation/
├── Campaign/
├── Shared/
└── TransactionalMail/
```

Domain names reflect high-level business concepts, not technical categories.

---

## Application Layer (Feature Modules)

Within the HTTP application, group by feature module:

```
Http/
├── Invoices/                   ← Feature module
│   ├── Controllers/
│   │   ├── InvoicesController.php
│   │   ├── InvoiceStatusController.php
│   │   └── MissedInvoicesController.php
│   ├── Filters/
│   ├── Middleware/
│   ├── Queries/
│   │   ├── InvoiceIndexQuery.php
│   │   └── InvoiceCollectionIndexQuery.php
│   ├── Requests/
│   │   └── InvoiceRequest.php
│   ├── Resources/
│   │   ├── InvoiceResource.php
│   │   └── InvoiceLineResource.php
│   └── ViewModels/
│       ├── InvoiceIndexViewModel.php
│       └── InvoiceDraftViewModel.php
│
├── Customers/
│   └── ...
│
└── Settings/                   ← Module that touches multiple domains
    └── ...
```

---

## Support Namespace

For code that has no business-concept home — utilities, base classes, global helpers:

```
Support/
├── ValueObjects/
├── Http/
│   └── BaseRequest.php
└── Testing/
    └── Factory.php          ← Base factory class
```

---

## Tests Mirror the Domain Structure

```
tests/
├── Domain/
│   ├── Invoices/
│   │   ├── Actions/
│   │   │   └── CreateInvoiceActionTest.php
│   │   ├── Collections/
│   │   │   └── InvoiceLineCollectionTest.php
│   │   ├── QueryBuilders/
│   │   │   └── InvoiceQueryBuilderTest.php
│   │   └── States/
│   │       └── InvoiceStateTest.php
│   └── Customers/
│       └── ...
│
└── Factories/
    ├── InvoiceFactory.php
    ├── InvoiceDataFactory.php
    └── PaymentFactory.php
```

---

## Decision Guide: Where Does This Class Go?

1. Is it business logic with no HTTP knowledge? → `Domain/{Concept}/`
2. Does it handle HTTP input/output or queue infrastructure? → `Http/{Module}/` or `App/{Surface}/{Module}/`
3. Is it a global utility or base class? → `Support/`
4. Is it a test helper or factory? → `Tests/Factories/` or `Tests/`
5. Does it cross-cut multiple domains? → `Domain/Shared/` or `Support/`

```

---

### context/php-type-system.md
```md
# PHP Type System — Context & Theory

Understanding PHP's type system is foundational to understanding why data objects and strong typing matter in large codebases.

---

## Weak vs. Strong Types

**Weak (PHP):** Variables can change type after assignment. Type coercion happens silently.

```php
$a = 'test'; // string
$a = 1;      // now int — PHP allows this

function find(int $id): Model {}

$id = '1';
find($id); // '1' is coerced to 1 — no error
```

**Strong:** Once typed, a variable cannot change type. A whole class of bugs becomes impossible.

---

## Static vs. Dynamic Types

**Dynamic (PHP):** Type checks happen at runtime. A type error crashes the running program.

**Static:** Type checks happen before execution (at compile time). Errors are caught before the program runs.

PHP is dynamic. But tools like PHPStan, Phan, and Psalm apply static analysis to PHP — giving you the benefits of static typing without changing the language.

---

## The Guarantee of Strong + Static Types

> "It's mathematically provable that if a strongly typed program compiles, it's impossible for that program to have a range of bugs which would be able to exist in weakly typed languages."

This is why we use data objects. They are as close to strong typing as PHP allows. Combined with PHPStan/Psalm, they eliminate whole categories of runtime bugs.

---

## PHP's Type Improvements Over Time

| Version | What Changed |
|---|---|
| PHP 7.0 | Type declarations for parameters and return types |
| PHP 7.4 | Typed class properties |
| PHP 8.0 | Named arguments, union types, match expression, constructor property promotion |
| PHP 8.1 | Native enums, readonly properties, fibers |
| PHP 8.2 | Readonly classes, disjunctive normal form types |

**Impact on this architecture:**

- PHP 8.0: Constructor promotion → clean data object construction, `match` for enum methods
- PHP 8.1: Native enums → drop `spatie/enum`, readonly properties for data objects
- PHP 8.2: Readonly classes → entire data object classes can be readonly

---

## Strict Types Declaration

```php
declare(strict_types=1);
```

Prevents type coercion at function call sites:

```php
declare(strict_types=1);

function find(int $id): Model {}

find('1'); // TypeError — string not accepted
find(1);   // Fine
```

But strict types don't make variables immutable:

```php
function find(int $id): Model
{
    $id = '' . $id; // Now a string — PHP allows this inside the function
}
```

This is why typed class properties (data objects) are better than just strict_types — they enforce the type on the property itself throughout the object's life.

---

## Static Analysis Tools

Add these to your project:

| Tool | Package | Config |
|---|---|---|
| PHPStan | `phpstan/phpstan` | `phpstan.neon` |
| Larastan | `nunomaduro/larastan` | Laravel-aware PHPStan wrapper |
| Psalm | `vimeo/psalm` | `psalm.xml` |

These tools find type errors, null dereferences, and unreachable code before you run the application. In large teams, they pay for themselves immediately.

---

## The Practical Payoff

Without strong types:
- You must read source code or dump variables to know what data you're working with
- A colleague's code is a black box unless documented
- IDEs can't autocomplete or validate your code

With strong types (data objects + static analysis):
- Your IDE knows every property's type
- Passing the wrong data is caught before deployment
- New developers can read the code and understand the data shapes immediately

> "You have to take every opportunity you can to reduce cognitive load. You don't want developers having to start debugging their code every time they want to know what exactly is in a variable."

```

---

### context/managing-domains.md
```md
# Managing Domains — Philosophy & Team Guidance

How to start, evolve, and maintain domain-oriented Laravel projects over time.

---

## The Core Mindset Shift

Stop thinking like this:
> "I'm a programmer who writes code."

Start thinking like this:
> "I'm a translator between real-world problems and technical solutions."

Code is a means to an end. The primary goal is always to understand the business problem — the code is just how you express the solution.

---

## Identifying Domains

Domains come from the business, not from technical categories.

**Process:**
1. Talk to the client (face-to-face if possible)
2. Listen for the nouns and verbs they use naturally
3. Identify subsystems that have clear boundaries
4. Start coding — the right domains will emerge

**Common domain identification methods:**
- Event storming sessions with the client
- User story mapping
- Direct conversation — ask clients to describe their business processes
- Looking at what business reports they need

**The language test:** If the client says "work on invoicing this week" — that's a domain candidate.

---

## Practical Examples from Spatie

### Flare (exception tracker)

After creating a Flare account, you define a project with an API key. Errors from your application are sent to the project. Flare sends notifications on errors, and you can subscribe after a trial.

```
Domain/
├── Account/
├── Error/
├── Flare/
├── Notification/
├── Project/
├── Shared/
└── Subscription/
```

### Mailcoach (email marketing platform)

Build email lists, send campaigns, automate email flows, and send transactional mails. Has hosted and self-hosted versions sharing a common codebase.

```
Domain/
├── Audience/
├── Automation/
├── Campaign/
├── Shared/
└── TransactionalMail/
```

**Notice:** Domain names reflect high-level business concepts. Each domain has essentially the same internal structure as a Laravel app (Actions, Models, Events, etc.).

### The `Domain/Shared/` Pattern

For code that isn't easily identifiable to a single domain. In Flare, there's a custom Activity model providing an audit log used by all other domains. Most of the time, `Shared/` should be very small. A large `Shared/` domain is a sign that you need to restructure. Alternatively, put common code in `Support/` instead.

---

## Domains Will Change — That's Expected

Don't try to get the domain structure perfect upfront. It's impossible.

```
Year 1:  Domain/Invoices/
         → everything invoice-related

Year 2:  Domain/Invoices/     → invoice management
         Domain/Payments/     → payment processing (split out)
         Domain/Collections/  → collections/reminders (split out)
```

**This is healthy.** As your understanding of the business deepens, the domain structure becomes more accurate.

Why it's cheap to refactor:
- Domain code has minimal dependencies (by design)
- Moving files doesn't break application code (as long as namespaces update)
- Modern IDEs like PhpStorm handle refactoring well

**Rule: Don't be afraid to start. You can always refactor.**

When starting a project at Spatie, domains are often not used initially. It's only when certain directories grow too large that the refactoring to domains begins.

---

## Onboarding New Developers

Common concern: "Won't this architecture confuse new developers?"

**The real difficulty in large projects is not the architecture — it's the business knowledge.**

A new developer joining a project with 100 models and 300 actions cannot be expected to understand all the business rules instantly. That takes weeks. The architecture shouldn't be the bottleneck.

**Real experience from Spatie:**
> A new colleague joined as a backend developer to work on a project with a team of three existing developers. The architecture was new to him, even with prior Laravel experience. After a few hours of briefing and pair programming, he was able to work independently. It took weeks to fully understand the business, but the architecture helped him focus on the logic rather than getting lost in the codebase.

**Less magic = less confusion.** Every design decision in this architecture reduces hidden state and implicit behaviour. That makes it faster to learn, not harder.

---

## Teamwork Guidelines

1. **Agree on conventions as a team.** Write them down. This document is a starting point — adapt it.

2. **Revisit agreements.** Don't follow rules dogmatically. New experience should update agreements.

3. **Prioritise consistency over personal preference.** A codebase where 5 developers all have different styles is harder to maintain than one where everyone uses the "wrong" approach consistently.

4. **Document why, not just what.** When you make an architectural decision, write down the reason. Future developers (including yourself) need the context.

---

## Pragmatism vs. Strictness Scale

This architecture sits toward the pragmatic end:

```
Pragmatic ←————————————————→ Strict

Simple CRUD    This approach    Full DDD    Hexagonal
               (recommended)              Architecture
```

Adjust left or right based on:
- Team size and experience
- Project lifespan (2 months vs. 5 years)
- Business complexity
- Client budget and timeline

Not every project needs this. A blog or a simple CRUD admin doesn't benefit from domains and actions.

---

## Signs You Need This Architecture

- The project will last more than a year
- More than 2-3 developers will work on it
- The business logic is genuinely complex
- Controllers/models are already becoming hard to navigate
- You're finding bugs because logic is duplicated in multiple places

---

## Signs You've Over-Applied It

- You have domains with only 1-2 classes
- Every action is a single line delegating to another class
- You're writing more boilerplate than business logic
- The team feels like they're fighting the architecture

**Simplify when this happens.** The architecture serves the project, not the other way around.

---

## The Support Namespace

Everything that doesn't belong in a domain or application but needs to be shared:

```
Support/
├── Http/
│   └── BaseRequest.php
├── Testing/
│   └── Factory.php
├── ValueObjects/
│   └── Money.php
└── Helpers/
    └── DateHelper.php
```

Think of Support as "code that could have been in the framework or a package." If it has a clear home elsewhere, put it there. If not, it goes here.

```

---

### context/spatie-packages.md
```md
# Spatie Package Reference

All packages from the book that support this architecture.

---

## Core Architecture Packages

### spatie/laravel-data
**Docs:** https://spatie.be/docs/laravel-data

The primary data object package. Replaces `spatie/data-transfer-object` for new projects. Data objects can serve as form requests, API resources, and can generate TypeScript definitions.

```php
use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Rule;

class CustomerData extends Data
{
    public function __construct(
        public string $name,
        #[Rule('email')]
        public string $email,
        public Carbon $birth_date,
    ) {}
}

// As a form request replacement — inject directly in controller
class CustomerController
{
    public function update(CustomerData $customerData)
    {
        // Already validated and type-cast
    }
}

// As an API resource
return CustomerData::from($customer); // returns JSON-serializable data
```

**Key features:**
- Automatic type casting (string → Carbon, etc.)
- Validation via PHP attributes or dedicated methods
- Form request replacement (inject data object in controller)
- API resource replacement
- TypeScript definition generation
- Nested data objects and typed collections

---

### spatie/laravel-model-states
**GitHub:** https://github.com/spatie/laravel-model-states

State pattern for Eloquent models. Handles storing, loading, casting states, and managing allowed transitions.

```php
use Spatie\ModelStates\HasStates;

class Invoice extends Model
{
    use HasStates;

    protected $casts = [
        'status' => InvoiceState::class,
    ];
}

// Transition
$invoice->status->transitionTo(PaidInvoiceState::class);
```

---

### spatie/laravel-query-builder
**Docs:** https://spatie.be/docs/laravel-query-builder

Maps HTTP query parameters (`filter[]`, `sort`, `include`, `fields[]`) to Eloquent queries with an allow-list for safety.

```php
$invoices = QueryBuilder::for(Invoice::class)
    ->allowedFilters('number', 'client', AllowedFilter::exact('status'))
    ->allowedSorts('number', 'date', 'total_price')
    ->allowedIncludes('invoiceLines', 'client')
    ->paginate();
```

Use as a base class for dedicated query classes:

```php
class InvoiceIndexQuery extends QueryBuilder
{
    public function __construct(Request $request)
    {
        parent::__construct(Invoice::query()->with('invoicee'), $request);
        $this->allowedFilters('number')->allowedSorts('date');
    }
}
```

---

### spatie/laravel-view-models
**GitHub:** https://github.com/spatie/laravel-view-models

Base class for view models. Adds `Arrayable` (pass directly to view) and `Responsable` (return as JSON) implementations. Also auto-resolves public methods as view variables.

```php
use Spatie\ViewModels\ViewModel;

class PostFormViewModel extends ViewModel
{
    public function __construct(
        private User  $user,
        private ?Post $post = null,
    ) {}

    public function post(): Post
    {
        return $this->post ?? new Post();
    }

    public function categories(): Collection
    {
        return Category::allowedForUser($this->user)->get();
    }
}

// In controller
return view('blog.form', new PostFormViewModel($user, $post));
```

---

### spatie/laravel-queueable-action
**GitHub:** https://github.com/spatie/laravel-queueable-action

Dispatch any action as a queued job without writing a dedicated `*Job` class.

```php
use Spatie\LaravelQueueableAction\QueueableAction;

class SendInvoiceMailAction
{
    use QueueableAction;

    public function execute(Invoice $invoice): void
    {
        // business logic
    }
}

// Sync
$action->execute($invoice);

// Queued
$action->onQueue()->execute($invoice);
```

---

## Legacy Packages (Pre-PHP 8.1)

### spatie/data-transfer-object
**GitHub:** https://github.com/spatie/data-transfer-object

Legacy DTO base class. **Superseded by `spatie/laravel-data`** for all new projects.

### spatie/enum
**GitHub:** https://github.com/spatie/enum

Userland enum implementation. **Superseded by native PHP 8.1 enums.**

### spatie/laravel-enum
**GitHub:** https://github.com/spatie/laravel-enum

Laravel integration for `spatie/enum`. **Superseded by native PHP 8.1 enum casting.**

### myclabs/php-enum
Popular enum package with explicit constant definition. **Superseded by native PHP 8.1 enums.**

---

## External Reference Packages

### symfony/workflow
For complex state machines requiring many states, many transitions, and transition guards. More powerful than `spatie/laravel-model-states`.

---

## Quick Decision: Which Package for Which Need?

| Need | Package |
|---|---|
| Data objects / DTOs | `spatie/laravel-data` |
| State pattern on models | `spatie/laravel-model-states` |
| Type-safe enums | Native PHP 8.1 `enum` (no package needed) |
| Map URL params to queries | `spatie/laravel-query-builder` |
| View models | `spatie/laravel-view-models` |
| Queue actions without Job classes | `spatie/laravel-queueable-action` |
| Complex state machines | `symfony/workflow` |

```

---

### context/further-reading.md
```md
# Further Reading & References

All sources cited in *Laravel Beyond CRUD* (2nd edition) that influenced this architecture.

---

## Talks & Videos

**Gary Bernhardt — Type Systems**
https://www.destroyallsoftware.com/talks/ideology
Explores the philosophical divide between dynamic and static typing communities. Essential for understanding why we care about types.

**Alan Kay — His Vision of OOP**
https://www.youtube.com/watch?v=oKg1hTOQXoY
Kay (who coined "object-oriented") explains his original vision — which emphasises messaging and process over objects as data containers. Influenced the separation of actions from models in this architecture.

**Sandi Metz — Nothing Is Something**
https://www.youtube.com/watch?v=29MAL8pJImQ
Shows how to eliminate all `if` statements using OOP principles. Demonstrates the power of polymorphism (the foundation of the state pattern).

**Freek Van der Herten — Laravel Data at Laracon Online**
A practical demonstration of `spatie/laravel-data` and how it integrates with the data object pattern described in the book.

**Freek Van der Herten — Refactoring Mailcoach to Domains**
A practical video walkthrough of refactoring an existing Laravel codebase into the domain-oriented structure.

---

## Articles & Blog Posts

**Martin Fowler — Transaction Script**
https://martinfowler.com/eaaCatalog/transactionScript.html
Foundational pattern that actions are based on. A transaction script organises business logic as a single procedure per business transaction.

**Freek Van der Herten — Refactoring to Actions**
https://freek.dev/1371-refactoring-to-actions
How to take an existing Laravel application and migrate it toward the domain-oriented structure.

**Freek Van der Herten — Getting Started with Domain-Oriented Laravel**
https://freek.dev/1486-getting-started-with-domain-oriented-laravel
Another practical introduction from the team.

**Tighten — Class-Based Model Factories**
https://tighten.co/blog/tidy-up-your-tests-with-class-based-model-factories
Tighten independently arrived at a similar test factory approach. Good to compare the two implementations.

---

## GitHub Discussions

**Matthias Noback — Value Objects vs. DTOs**
https://github.com/spatie/data-transfer-object/issues/17
Important distinction: Value Objects have equality based on their values; DTOs are just data carriers. The book originally called DTOs "Value Objects" — this thread corrects that. In the 2nd edition, DTOs are often called "data objects."

---

## External Packages

**Symfony Workflow**
https://symfony.com/doc/current/workflow/workflow-and-state-machine.html
For complex state machines. An alternative to `spatie/laravel-model-states` when you need many states, complex transition guards, and transition logging.

---

## Spatie Open Source
https://spatie.be/open-source
All packages from the team behind this architecture. Many were built specifically to support this approach.

**Key packages:**
- `spatie/laravel-data` — https://spatie.be/docs/laravel-data
- `spatie/laravel-query-builder` — https://spatie.be/docs/laravel-query-builder
- `spatie/laravel-view-models` — https://github.com/spatie/laravel-view-models
- `spatie/laravel-model-states` — https://github.com/spatie/laravel-model-states
- `spatie/laravel-queueable-action` — https://github.com/spatie/laravel-queueable-action

```

---

### skills/domain/dtos.md
```md
# Data Objects (DTOs)

Data objects make data a first-class citizen of the codebase. They are the entry point for all external data entering the domain.

> **Terminology:** The book uses "data objects" and "DTOs" (data transfer objects) interchangeably. Both refer to the same pattern.

---

## Purpose

Wrap unstructured data (arrays, request payloads) in strongly typed, predictable objects. This:

- Eliminates "array of unknown stuff" problems
- Enables IDE autocompletion and static analysis
- Reduces cognitive load — you always know what data you're working with
- Catches type errors at analysis time, not runtime

---

## The Problem Data Objects Solve

```php
// BAD — what is in $validated? You don't know without digging.
function store(CustomerRequest $request, Customer $customer)
{
    $validated = $request->validated();
    $customer->name = $validated['name'];     // maybe?
    $customer->email = $validated['email'];   // maybe?
}

// GOOD — self-documenting, statically analysable
function store(CustomerRequest $request, Customer $customer)
{
    $data = CustomerData::fromRequest($request);
    $customer->name = $data->name;       // IDE knows this exists
    $customer->email = $data->email;     // IDE knows the type
    $customer->birth_date = $data->birth_date; // Carbon, guaranteed
}
```

---

## Plain PHP Data Object (PHP 8+)

The simplest approach — a plain class with constructor property promotion:

```php
class CustomerData
{
    public function __construct(
        public readonly string $name,
        public readonly string $email,
        public readonly Carbon $birth_date,
    ) {}
}
```

Construction from a request using the spread operator:

```php
class CustomerController
{
    public function update(UpdateCustomerRequest $request)
    {
        $customerData = new CustomerData(...$request->validated());

        // ... do something with customerData
    }
}
```

This works for simple cases where all properties are scalar types. It breaks down when you have object properties (like `Carbon $birth_date`) because the request returns a string, not a Carbon instance.

---

## Construction Approaches for Complex Data Objects

### Option A: Dedicated factory in the application layer (theoretically correct)

```php
class CustomerDataFactory
{
    public function fromRequest(CustomerRequest $request): CustomerData
    {
        return new CustomerData(
            name: $request->get('name'),
            email: $request->get('email'),
            birth_date: Carbon::make($request->get('birth_date')),
        );
    }
}
```

Keeps the domain clean. The factory lives in the application layer.

### Option B: Static constructor on the data object (pragmatic)

```php
$data = CustomerData::fromRequest($request);
```

Mixes application knowledge into the domain, but keeps construction logic close to the data class.

---

## Using spatie/laravel-data (Recommended)

At Spatie, the `spatie/laravel-data` package is the primary way to create and work with data objects in Laravel. It extends data objects with powerful capabilities.

```php
use Spatie\LaravelData\Data;

class CustomerData extends Data
{
    public function __construct(
        public string $name,
        public string $email,
        public Carbon $birth_date,
    ) {}
}
```

### Data Objects as Form Requests

With Laravel Data, data objects can **replace form requests** entirely. Inject the data object directly in the controller:

```php
class CustomerController
{
    public function update(CustomerData $customerData)
    {
        // $customerData is already validated and constructed
        // The controller method only runs if construction succeeds
    }
}
```

Laravel Data automatically handles type conversion (e.g., string → Carbon).

### Validation via Attributes

Add validation rules directly on properties:

```php
use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Rule;

class CustomerData extends Data
{
    public function __construct(
        public string $name,
        #[Rule('email')]
        public string $email,
        public Carbon $birth_date,
    ) {}
}
```

### Additional Capabilities

- **API Resources:** Data objects can serve as API resources (replacing `JsonResource`)
- **TypeScript generation:** Can be converted to TypeScript type definitions
- **Nesting:** Data objects can contain other data objects
- **Collections:** Typed collections of data objects

See the [Laravel Data documentation](https://spatie.be/docs/laravel-data) for the full API.

---

## What NOT to Put in Data Objects

- Business logic
- Calculations
- Database queries
- Side effects of any kind

Data objects are pure data containers. Their only job is structured representation of data.

---

## Testing Data Objects

Data objects with only typed properties need no tests — the type system IS the test.

Test ONLY if you have a `fromRequest()` or similar static constructor:

```php
it('will correctly map a request to booking data', function () {
    $unit = UnitFactory::new()->create();

    $dataObject = BookingData::fromStoreRequest(new BookingStoreRequest([
        'name'       => 'test',
        'unit_id'    => $unit->id,
        'date_start' => '2022-12-01',
        'date_end'   => '2022-12-05',
    ]));

    expect($dataObject)->toBeInstanceOf(BookingData::class);
});

it('will not work when unit id is missing', function () {
    BookingData::fromStoreRequest(new BookingStoreRequest([
        'name' => 'test',
        'date_start' => '2022-12-01',
        'date_end' => '2022-12-05',
    ]));
})->throws(ModelNotFoundException::class);
```

---

## Relevant Packages

- `spatie/laravel-data` — **Primary recommendation.** Data objects with validation, form request replacement, API resource capability, TypeScript generation.
- `spatie/data-transfer-object` — Legacy DTO package. Superseded by `spatie/laravel-data` for new projects.

```

---

### skills/domain/actions.md
```md
# Actions

Actions are the primary way to represent business operations in the domain. They are single-responsibility classes that take input, do something, and return output.

---

## Core Concept

Every user story becomes an action. Instead of spreading business logic across controllers, models, and jobs — it all lives in one place.

```
User story: "Admin creates an invoice"

Naive approach spreads this across:
  ├── InvoicesController (entry point)
  ├── Invoice model (business logic)  
  ├── GeneratePdfJob (async work)
  └── InvoiceCreatedListener (sends mail)

Action approach:
  └── CreateInvoiceAction (the whole story, start from here)
       ├── uses CreateInvoiceLineAction
       ├── uses GeneratePdfAction
       └── uses SendInvoiceMailAction
```

---

## Anatomy of an Action

```php
class CreateInvoiceAction
{
    public function __construct(
        private CreateInvoiceLineAction $createInvoiceLineAction,
        private GeneratePdfAction $generatePdfAction,
    ) {}

    // Context data injected via execute() — NOT the constructor
    public function execute(InvoiceData $invoiceData): Invoice
    {
        // business logic here
    }
}
```

**Key rules:**
- Lives in the domain
- No interfaces or abstractions required
- One public method: `execute()`
- Constructor = framework DI (services, other actions)
- `execute()` = runtime data (data objects, models)

---

## Why `execute` and Not `__invoke` or `handle`

**`__invoke` problem:** PHP won't let you call an invokable property directly.
```php
// This FAILS
$this->createInvoiceLineAction($lineData);

// You'd need this ugly workaround
($this->createInvoiceLineAction)($lineData);
```

**`handle` problem:** Laravel provides method injection on `handle` in jobs/commands. Actions must only get DI through the constructor — using `handle` breaks this guarantee.

**`execute` is the convention.** It's unambiguous and not hijacked by the framework.

---

## Composing Actions

Actions can depend on other actions. This is composition, not inheritance.

```php
class CreateInvoiceLineAction
{
    public function __construct(
        private VatCalculator $vatCalculator,
    ) {}

    public function execute(InvoiceLineData $data): InvoiceLine
    {
        $item = $data->item;

        if ($item->vatIncluded()) {
            [$priceIncVat, $priceExclVat] = $this->vatCalculator->vatIncluded(
                $item->getPrice(),
                $item->getVatPercentage()
            );
        } else {
            [$priceIncVat, $priceExclVat] = $this->vatCalculator->vatExcluded(
                $item->getPrice(),
                $item->getVatPercentage()
            );
        }

        return new InvoiceLine([
            'item_price'               => $item->getPrice(),
            'total_price'              => $data->item_amount * $priceIncVat,
            'total_price_excluding_vat' => $data->item_amount * $priceExclVat,
        ]);
    }
}
```

Composition chain example:
```
CreateInvoiceAction
  ├── CreateInvoiceLineAction
  │     └── VatCalculator
  ├── GeneratePdfAction
  └── SendInvoiceMailAction
```

**Warning:** Deep dependency chains make code hard to reason about. Keep composition shallow where possible.

---

## Reusability

Actions can be reused across multiple entry points:

```php
// Called from InvoicesController (HTTP)
$action->execute($invoiceData);

// Called from ArtisanCommand (CLI)
$action->execute($invoiceData);

// Called from another action (composition)
$this->createInvoiceAction->execute($invoiceData);

// Dispatched to queue via spatie/laravel-queueable-action
$action->onQueue()->execute($invoiceData);
```

---

## Abstracting Shared Action Behaviour

When multiple models need the same action shape:

```php
interface ToPdf
{
    public function toPdfData(): array;
}

class GeneratePdfAction
{
    public function execute(ToPdf $subject): string
    {
        // works for Invoice, Quote, Contract, etc.
    }
}

class Invoice implements ToPdf { ... }
class Quote implements ToPdf { ... }
```

---

## Actions vs. Commands/Handlers (DDD)

Actions are a simplified command bus. They combine "what" and "how" into one class.

| | Actions | Commands + Handlers |
|---|---|---|
| Separation | Combined | Separate classes |
| Flexibility | Less | More |
| Code volume | Less | More |
| Suitable for | Large-but-not-ginormous apps | Enterprise / high flexibility needs |

---

## Actions vs. Event-Driven Systems

Event-driven systems offer more decoupling but add indirectness. Actions are directly called — you always know what happens when you read the code.

For most Laravel projects, actions strike the right balance.

---

## Running Actions on the Queue

With `spatie/laravel-queueable-action`:

```php
// Instead of:
dispatch(new SendInvoiceMailJob($invoice));

// You write:
$this->sendInvoiceMailAction->onQueue()->execute($invoice);
```

The package creates a generic job class under the hood and dispatches it. No dedicated `*Job` class needed for simple action delegation.

---

## Benefits Summary

1. **Single source of truth** — one place to look when a business rule changes
2. **Reusable** — shared across controllers, jobs, commands, other actions
3. **Testable** — no HTTP, no facades, just instantiate and call `execute()`
4. **Reduces cognitive load** — business logic is no longer scattered

```

---

### skills/domain/models.md
```md
# Models

Models are the third core building block, alongside data objects and Actions. Their job is to represent and provide data from the database — nothing more.

---

## Core Principle: Models ≠ Business Logic

Models should NOT:
- Calculate derived values (e.g., `$invoice->total_price` computing a sum)
- Send mail
- Generate PDFs
- Perform complex operations

Models SHOULD:
- Define Eloquent relations
- Define casts
- Provide simple accessors for already-stored values
- Delegate to custom query builders
- Delegate to custom collection classes
- Map generic events to specific event classes

---

## What NOT to Do (Fat Model Anti-Pattern)

```php
// BAD — model doing calculation
class InvoiceLine extends Model
{
    public function getTotalPriceAttribute(): int
    {
        $vatCalculator = app(VatCalculator::class); // service location!
        $price = $this->item_amount * $this->item_price;

        if ($this->price_excluding_vat) {
            $price = $vatCalculator->totalPrice($price, $this->vat_percentage);
        }

        return $price;
    }
}
```

---

## What TO Do — Pre-Calculate via Actions

Calculate values in actions, store them, read them from the model:

```php
class CreateInvoiceLineAction
{
    public function __construct(
        private VatCalculator $vatCalculator,
    ) {}

    public function execute(InvoiceLineData $data): InvoiceLine
    {
        $totalPrice = $this->vatCalculator->calculate(...);

        return InvoiceLine::create([
            'total_price' => $totalPrice, // stored, not calculated on read
        ]);
    }
}

// Model just reads the stored value
$invoiceLine->total_price; // simple attribute access, no computation
```

**Advantages:**
- Performance: calculated once, not on every access
- Queryable: `->where('total_price', '>', 1000)` works
- No side effects on read

---

## Custom Query Builder Classes

Move query scopes to dedicated builder classes:

```php
namespace Domain\Invoices\QueryBuilders;

use Illuminate\Database\Eloquent\Builder;
use Domain\Invoices\States\Paid;

class InvoiceQueryBuilder extends Builder
{
    public function wherePaid(): self
    {
        return $this->whereState('status', Paid::class);
    }
}
```

Wire it up in the model:

```php
class Invoice extends Model
{
    public function newEloquentBuilder($query): InvoiceQueryBuilder
    {
        return new InvoiceQueryBuilder($query);
    }
}

// Usage — fully type-hinted, IDE-aware
Invoice::query()->wherePaid()->get();
```

---

## Custom Collection Classes

Move collection logic out of models and controllers:

```php
namespace Domain\Invoices\Collections;

use Illuminate\Database\Eloquent\Collection;
use Domain\Invoices\Models\InvoiceLine;

class InvoiceLineCollection extends Collection
{
    public function creditLines(): self
    {
        return $this->filter(fn(InvoiceLine $line) => $line->isCreditLine());
    }
}
```

Wire it up in the model:

```php
class InvoiceLine extends Model
{
    public function newCollection(array $models = []): InvoiceLineCollection
    {
        return new InvoiceLineCollection($models);
    }

    public function isCreditLine(): bool
    {
        return $this->price < 0.0;
    }
}
```

Usage:

```php
$invoice->invoiceLines->creditLines();
```

---

## Event-Driven Models

Instead of model observers, remap generic events to specific typed event classes:

```php
class Invoice extends Model
{
    protected $dispatchesEvents = [
        'saving'   => InvoiceSavingEvent::class,
        'deleting' => InvoiceDeletingEvent::class,
    ];
}
```

Specific event class:

```php
class InvoiceSavingEvent
{
    public function __construct(
        public Invoice $invoice,
    ) {}
}
```

Dedicated subscriber (NOT a model observer):

```php
class InvoiceSubscriber
{
    public function __construct(
        private CalculateTotalPriceAction $calculateTotalPriceAction,
    ) {}

    public function saving(InvoiceSavingEvent $event): void
    {
        $invoice = $event->invoice;
        $invoice->total_price = ($this->calculateTotalPriceAction)($invoice);
    }

    public function subscribe(Dispatcher $dispatcher): void
    {
        $dispatcher->listen(InvoiceSavingEvent::class, self::class . '@saving');
    }
}
```

Register in `EventServiceProvider`:

```php
protected $subscribe = [
    InvoiceSubscriber::class,
];
```

**Benefits over observers:**
- Subscribers can have injected dependencies
- Each event has a typed class (not magic strings)
- Testable in isolation — call the subscriber method directly

---

## Responding to the "Anemic Model" Concern

Martin Fowler's anemic domain model anti-pattern argues against models that are "empty bags of data."

The counter-argument: models are NOT empty bags. Via accessors and casts they provide a rich layer between raw database data and domain-ready objects. The business LOGIC moves to actions, but the business DATA and its presentation stays in models.

Alan Kay (who coined OOP) advocated for separating process and data. This architecture leans on that vision.

---

## Model Folder Location

```
Domain/Invoices/Models/
    Invoice.php
    InvoiceLine.php
```

```
Domain/Invoices/QueryBuilders/
    InvoiceQueryBuilder.php

Domain/Invoices/Collections/
    InvoiceLineCollection.php
```

```

---

### skills/domain/states.md
```md
# States & Transitions

The state pattern replaces brittle if/else chains with polymorphism. Each state is a first-class class.

---

## The Problem: Scattered Conditionals

You might start with a simple enum to represent state:

```php
enum InvoiceState: string
{
    case Pending = 'pending';
    case Paid = 'paid';

    public function color(): string
    {
        return match($this) {
            self::Pending => 'orange',
            self::Paid => 'green',
        };
    }
}
```

Used on a model:

```php
class Invoice extends Model
{
    public function getStateColour(): string
    {
        return $this->state->color();
    }
}
```

This works for simple cases. But using this approach, the enum (or the model) has to know what a specific state should do and how it works. As states and their behaviour grow, match expressions and conditionals multiply everywhere. This is fragile.

The state pattern turns this around: it treats "a state" as a first-class citizen. Every state is represented by a separate class, and each class acts upon a subject.

---

## The Solution: State Classes

### Step 1 — Abstract base state

```php
abstract class InvoiceState
{
    public function __construct(
        protected Invoice $invoice,
    ) {}

    abstract public function colour(): string;
    abstract public function mustBePaid(): bool;
}
```

### Step 2 — Concrete state classes

```php
class PendingInvoiceState extends InvoiceState
{
    public function colour(): string
    {
        return 'orange';
    }

    public function mustBePaid(): bool
    {
        if ($this->invoice->type != InvoiceType::Debit) {
            return false;
        }

        if ($this->invoice->total_price <= 0) {
            return false;
        }

        return true;
    }
}

class PaidInvoiceState extends InvoiceState
{
    public function colour(): string
    {
        return 'green';
    }

    public function mustBePaid(): bool
    {
        return false;
    }
}
```

### Step 3 — Wire to model

```php
class Invoice extends Model
{
    // state_class column stores the FQCN of the state
    public function getStateAttribute(): InvoiceState
    {
        return new $this->state_class($this);
    }

    // Delegate to state — model stays clean
    public function mustBePaid(): bool
    {
        return $this->state->mustBePaid();
    }

    public function colour(): string
    {
        return $this->state->colour();
    }
}
```

Usage:

```php
$invoice->colour();      // 'orange' or 'green' — no conditions in sight
$invoice->mustBePaid();  // true/false — handled by the state class
```

---

## States Without Transitions (Static Types)

Not all states transition. Some represent a fixed property. Apply the state pattern to eliminate conditionals even here:

```php
abstract class InvoiceType
{
    protected Invoice $invoice;
    abstract public function mustBePaid(): bool;
}

class DebitInvoiceType extends InvoiceType
{
    public function mustBePaid(): bool { return true; }
}

class CreditInvoiceType extends InvoiceType
{
    public function mustBePaid(): bool { return false; }
}
```

Now `PendingInvoiceState::mustBePaid` becomes:

```php
public function mustBePaid(): bool
{
    if ($this->invoice->total_price <= 0) {
        return false;
    }

    return $this->invoice->type->mustBePaid();
}
```

Reducing if/else statements allows code to be more linear, which is easier to reason about.

---

## Transitions

Transitions move a model from one state to another. They are separate classes with possible side effects.

```php
class PendingToPaidTransition
{
    public function __invoke(Invoice $invoice): Invoice
    {
        if (! $invoice->mustBePaid()) {
            throw new InvalidTransitionException(self::class, $invoice);
        }

        $invoice->status_class = PaidInvoiceState::class;
        $invoice->save();

        History::log($invoice, 'Pending to Paid');

        return $invoice;
    }
}
```

**States = read data / provide behaviour.**
**Transitions = write data / side effects.**

This separation keeps each class's responsibility clear.

---

## Testing States

Each state class is independently testable:

```php
test('the color of the pending state is orange', function () {
    $state = new PendingInvoiceState(
        InvoiceFactory::new()->create()
    );

    expect($state->colour())->toBe('orange');
});

test('a paid invoice does not need to be paid', function () {
    $state = new PaidInvoiceState(
        InvoiceFactory::new()->paid()->create()
    );

    expect($state->mustBePaid())->toBeFalse();
});
```

No HTTP, no complex setup — just instantiate the state and assert.

---

## Using spatie/laravel-model-states

Manual state management (storing/loading FQCN, mapping, transitions) gets tedious. Use the package:

```php
use Spatie\ModelStates\HasStates;

class Invoice extends Model
{
    use HasStates;

    protected $casts = [
        'status' => InvoiceState::class,
    ];
}
```

The package handles:
- Casting state strings to/from state class instances
- Defining allowed transitions
- Throwing on invalid transitions
- Transition history

---

## When to Use State vs. Enum

| Use State Pattern | Use Enum |
|---|---|
| Behaviour differs per value | Simple categorisation |
| Complex conditionals based on value | Few or no conditionals |
| Transitions between values needed | Value is fixed at creation |
| Pattern will grow over time | Small, stable set of values |

**Rule of thumb:** When you find yourself attaching more and more value-specific functionality to an enum, convert it to states.

---

## Package Reference

- `spatie/laravel-model-states` — state management for Eloquent models
- `symfony/workflow` — for complex state machines with many states/transitions

```

---

### skills/domain/enums.md
```md
# Enums

Enums categorise named values in a type-safe way. With PHP 8.1+, use **native enums**. Graduate to the State pattern when behaviour per value becomes complex.

---

## When to Use Enums vs. States

| Use Enum | Use State Pattern |
|---|---|
| Simple set of named values | Each value has unique behaviour |
| Few conditionals based on the value | Many conditionals, growing over time |
| Value rarely drives program flow | Value determines different code paths |
| Small, stable set | Complex, potentially expanding set |

If you keep adding methods to your enum that do `match($this) { X => ..., Y => ... }` — convert to states.

---

## Native PHP 8.1 Enums (Default Approach)

PHP 8.1+ has built-in enum support. This is the **primary and default** approach for all new code.

### Basic Enum

```php
enum InvoiceType: string
{
    case Credit = 'credit';
    case Debit  = 'debit';
}
```

### Usage

```php
// Type-safe — only InvoiceType instances accepted
public function setType(InvoiceType $type): void
{
    $this->type = $type;
}

$invoice->setType(InvoiceType::Credit);   // ✓
$invoice->setType('whatever');            // ✗ TypeError

// Construct from string
InvoiceType::from('credit');    // InvoiceType::Credit
InvoiceType::tryFrom('typo');   // null
```

### Enums With Simple Behaviour

Simple methods on native enums are acceptable:

```php
enum InvoiceState: string
{
    case Pending = 'pending';
    case Paid = 'paid';

    public function color(): string
    {
        return match($this) {
            self::Pending => 'orange',
            self::Paid => 'green',
        };
    }

    public function label(): string
    {
        return match($this) {
            self::Pending => 'Pending Payment',
            self::Paid => 'Paid',
        };
    }
}
```

This is fine. The moment `mustBePaid()`, `canTransitionTo()`, or complex business rules enter — switch to the State pattern.

### Eloquent Casting

Native enums can be cast directly on Eloquent models:

```php
class Invoice extends Model
{
    protected $casts = [
        'type'   => InvoiceType::class,
        'status' => InvoiceState::class,
    ];
}

// $invoice->type is now an InvoiceType enum instance
$invoice->type === InvoiceType::Credit; // true
```

---

## Enums or States?

The state pattern removes conditionals by providing a dedicated class for each value. Enums keep conditionals but centralise them in `match` expressions.

The state pattern's goal is to get rid of all those conditionals, and instead rely on polymorphism. Use the state pattern to get rid of conditional flows in your code, and enums for everything else.

**Pragmatic rule:** There is room for enums in the codebase. The state pattern has significant overhead (classes for each state, transition configuration, maintenance). Don't overcomplicate your code by always applying the state pattern.

If you need a collection of related values and there are few places where the application flow is determined by those values — use enums. If you find yourself attaching more and more value-related functionality — switch to states.

---

## Legacy: Userland Enum Packages

Before PHP 8.1, enums required userland packages. These are **no longer recommended** for new projects targeting PHP 8.1+.

- `spatie/enum` — enum values derived from DocBlocks. No longer needed.
- `spatie/laravel-enum` — Laravel integration for `spatie/enum`. No longer needed.
- `myclabs/php-enum` — popular alternative with explicit constants. No longer needed.

If maintaining a pre-8.1 codebase, these packages still work. For new code, always use native enums.

```

---

### skills/application/application-structure.md
```md
# Application Layer Structure

How to organise the application layer at scale. The same grouping-by-business-concept principle from the domain layer applies here too.

---

## What Is the Application Layer?

The application layer is the bridge between the outside world and the domain. It:

- Receives input (HTTP requests, CLI args, queue messages)
- Transforms input into domain-understood data (data objects)
- Calls domain actions
- Formats and returns output

All complex logic lives in the domain. Application code is mostly structural — "boring" glue code.

---

## Multiple Applications in One Project

Every Laravel project already has multiple applications by default:

| Application | Purpose |
|---|---|
| HTTP Admin | Back-office for internal users |
| HTTP API | REST/JSON for external clients or SPAs |
| Artisan Console | Developer operations |
| Third-party integrations | Webhooks, cron, event bridges |

Each is an isolated entry point. They share the domain but don't directly call each other.

---

## The Scaling Problem: Flat Technical Grouping

Laravel's default structure groups by technical type:

```
Http/
├── Controllers/   ← 50 files, all mixed
├── Requests/      ← 50 files, all mixed
├── Resources/     ← 50 files, all mixed
└── ViewModels/    ← 50 files, all mixed
```

After a year of development, each folder has 50+ files. Finding invoice-related code requires looking in 4+ directories simultaneously.

---

## The Solution: Feature Modules

Group by business concept WITHIN each application:

```
Http/
├── Invoices/
│   ├── Controllers/
│   ├── Filters/
│   ├── Middleware/
│   ├── Queries/
│   ├── Requests/
│   ├── Resources/
│   └── ViewModels/
├── Customers/
│   ├── Controllers/
│   ├── Requests/
│   ├── Resources/
│   └── ViewModels/
└── Settings/
    ├── Controllers/
    └── ViewModels/
```

Every invoice-related application class is in one folder. Open it and see everything you need.

---

## Modules ≠ Domains (1-to-1 is NOT required)

Application modules and domain groups can differ:

```
Domain/Invoices/          → invoice business logic
Domain/Payments/          → payment business logic

Http/Invoices/            → invoice UI (touches Domain/Invoices + Domain/Payments)
Http/Settings/            → settings UI (touches multiple domains)
```

A "Settings" module might touch 5 different domain groups. It's still one feature from the application perspective — keep it together.

---

## What Goes in Each Module Subfolder

| Folder | Contents |
|---|---|
| `Controllers/` | One controller per resource or action group |
| `Requests/` | Form request validation classes |
| `Middleware/` | Module-specific HTTP middleware |
| `Filters/` | Custom filter classes for query builders |
| `Queries/` | HTTP query builder classes |
| `Resources/` | API resource transformers |
| `ViewModels/` | View data preparation classes |
| `Jobs/` | Queue jobs specific to this module (if needed) |

---

## General-Purpose Application Code → Support

Classes that are shared across all modules in all applications:

- Base request class
- Authentication middleware
- Global exception handler
- Pagination helpers
- Response macros

These go in `Support/` (or `App/Http/` if you prefer staying closer to Laravel conventions):

```
Support/
├── Http/
│   ├── BaseRequest.php
│   └── Middleware/
│       └── AuthenticateMiddleware.php
└── Exceptions/
    └── Handler.php
```

---

## What Belongs in an Application Layer Class

### Controllers — Thin

```php
class InvoicesController
{
    public function store(
        InvoiceRequest $request,
        CreateInvoiceAction $action,
    ): RedirectResponse {
        $invoice = $action->execute(
            InvoiceData::fromRequest($request)
        );

        return redirect()->route('invoices.show', $invoice);
    }
}
```

Controllers should:
- Receive the request
- Call one action (or construct a view model)
- Return a response

They should NOT contain business logic, calculations, or conditional branching based on business rules.

### Jobs — Queue Management Only

```php
class ProcessInvoiceJob implements ShouldQueue
{
    public int $tries = 3;

    public function handle(CreateInvoiceAction $action): void
    {
        $action->execute($this->invoiceData);
    }
}
```

### Commands — Thin Wrappers

```php
class GenerateMonthlyInvoicesCommand extends Command
{
    protected $signature = 'invoices:generate-monthly';

    public function handle(GenerateMonthlyInvoicesAction $action): void
    {
        $action->execute(Carbon::now());
        $this->info('Done.');
    }
}
```

---

## Route Organisation

Mirror the module structure in routes:

```php
// routes/admin.php
Route::prefix('invoices')->name('invoices.')->group(function () {
    Route::get('/', [InvoicesController::class, 'index'])->name('index');
    Route::post('/', [InvoicesController::class, 'store'])->name('store');
    Route::get('/{invoice}', [InvoicesController::class, 'show'])->name('show');
    Route::patch('/{invoice}/status', [InvoiceStatusController::class, 'update'])->name('status.update');
});
```

---

## Testing Application Code

Application layer tests are integration/feature tests:

```php
it('allows an admin to create an invoice', function () {
    $user = UserFactory::new()->admin()->create();
    $client = ClientFactory::new()->create();

    $this->actingAs($user)
         ->post(route('invoices.store'), [
             'client_id' => $client->id,
             'due_at'    => now()->addDays(30)->toDateString(),
         ])
         ->assertRedirect();

    $this->assertDatabaseHas('invoices', ['client_id' => $client->id]);
});
```

Application tests verify routing, middleware, and request/response shape. They don't re-test business logic that's already covered by action tests.

```

---

### skills/application/view-models.md
```md
# View Models

View models prepare data for views. They replace ad-hoc data passing in controllers and eliminate duplication across create/edit/index controller methods.

---

## The Problem They Solve

```php
// BAD — duplicated across create and edit
public function create()
{
    return view('blog.form', [
        'categories' => Category::allowedForUser(current_user())->get(),
        'tags'       => Tag::all(),
    ]);
}

public function edit(Post $post)
{
    return view('blog.form', [
        'post'       => $post,
        'categories' => Category::allowedForUser(current_user())->get(),
        'tags'       => Tag::all(),
    ]);
}
```

When requirements change (e.g., filter categories by user), you update in multiple places. As forms grow, controllers grow.

**Worse alternatives:**
- Putting `allowedCategories()` on the Post model — duplication at model level
- Putting it on the User model — wrong responsibility, still scattered

---

## The View Model Pattern

```php
class PostFormViewModel
{
    public function __construct(
        private User $user,
        private ?Post $post = null,
    ) {}

    public function post(): Post
    {
        return $this->post ?? new Post();
    }

    public function categories(): Collection
    {
        return Category::allowedForUser($this->user)->get();
    }

    public function tags(): Collection
    {
        return Tag::orderBy('name')->get();
    }
}
```

Clean controllers:

```php
public function create()
{
    $viewModel = new PostFormViewModel(current_user());

    return view('blog.form', compact('viewModel'));
}

public function edit(Post $post)
{
    $viewModel = new PostFormViewModel(current_user(), $post);

    return view('blog.form', compact('viewModel'));
}
```

The controller now explicitly declares what the view will receive. No hidden state.

---

## Using the View Model in Blade

```blade
{{-- Explicit property access --}}
<input value="{{ $viewModel->post()->title }}" />
<input value="{{ $viewModel->post()->body }}" />

@foreach($viewModel->categories() as $category)
    <option value="{{ $category->id }}">{{ $category->name }}</option>
@endforeach
```

---

## Implementing Arrayable (Laravel Integration)

If the view model implements `Arrayable`, you can pass it directly to `view()`:

```php
use Illuminate\Contracts\Support\Arrayable;

class PostFormViewModel implements Arrayable
{
    public function toArray(): array
    {
        return [
            'post'       => $this->post(),
            'categories' => $this->categories(),
        ];
    }
}

// Controller
return view('blog.form', $viewModel); // Laravel unpacks Arrayable automatically
```

Blade can then use `$post` and `$categories` directly:

```blade
<input value="{{ $post->title }}" />

@foreach($categories as $category)
    <option>{{ $category->name }}</option>
@endforeach
```

---

## Implementing Responsable (AJAX / JSON)

If the view model implements `Responsable`, returning it from a controller sends it as JSON:

```php
use Illuminate\Contracts\Support\Responsable;

class PostFormViewModel implements Responsable
{
    public function toResponse($request): JsonResponse
    {
        return response()->json($this->toArray());
    }
}

// Controller — after saving via AJAX, return fresh view model data
public function update(Request $request, Post $post)
{
    // ... update logic

    return new PostFormViewModel(current_user(), $post);
}
```

---

## View Models + Resources

View models can use API resources internally:

```php
class PostViewModel
{
    public function values(): array
    {
        return PostResource::make($this->post ?? new Post())->resolve();
    }
}
```

**View models** provide whatever data a view needs (potentially from multiple models).
**Resources** map one-to-one onto a model for API output.
They are complementary, not competing.

---

## View Models vs. View Composers

| | View Models | View Composers |
|---|---|---|
| Wiring | Explicit — in controller | Implicit — global registration |
| Discovery | Read the controller, know the data | Must know where composers are registered |
| Dependencies | Injected explicitly | Hidden in global state |
| Reusability | Pass different args, reuse class | Tied to view name |
| Testability | Instantiate and test | Requires app boot |

View composers work fine in small apps. In large apps with multiple developers, global state is dangerous — use view models.

---

## Testing View Models

```php
it('provides allowed categories for the user', function () {
    $user = UserFactory::new()->create();
    Category::factory()->count(3)->create(['allowed_for' => $user->id]);
    Category::factory()->count(2)->create(); // not allowed for this user

    $viewModel = new PostFormViewModel($user);

    expect($viewModel->categories())->toHaveCount(3);
});
```

View models are plain PHP — no HTTP needed. Direct instantiation and assertion.

---

## Package Reference

- `spatie/laravel-view-models` — base class adding Arrayable + Responsable + automatic method-to-property resolution

```

---

### skills/application/http-query-builders.md
```md
# HTTP Query Builders

HTTP query builders map URL query parameters to Eloquent queries. They belong in the application layer and keep controllers thin.

---

## The Problem

Data tables need filtering, sorting, pagination, and search. Whether you're doing full-page refreshes, using something like Inertia.js, or AJAX — at scale, you'll always need to ask the server for an updated set of data based on given conditions. The naive approach:

```php
// BAD — inline in controller, duplicated across controllers
class InvoicesController
{
    public function index()
    {
        $invoices = QueryBuilder::for(Invoice::class)
            ->allowedFilters('number', 'client')
            ->allowedSorts('number', 'date')
            ->with(['invoicee', 'invoiceLines'])
            ->get();
    }
}
```

Problems:
- Duplicated when another controller needs the same query
- No static analysis on the base query
- Controllers get fat as queries grow complex

---

## The Solution: Dedicated Query Builder Classes

```php
namespace App\Admin\Invoices\Queries;

use Illuminate\Http\Request;
use Domain\Invoices\Models\Invoice;
use Spatie\QueryBuilder\QueryBuilder;

class InvoiceIndexQuery extends QueryBuilder
{
    public function __construct(Request $request)
    {
        $query = Invoice::query()
            ->with([
                'invoicee.contact',
                'invoiceLines.article',
            ]);

        parent::__construct($query, $request);

        $this
            ->allowedFilters('number', 'client')
            ->allowedSorts('number', 'date');
    }
}
```

---

## Injecting Into Controllers

Since `Request` is registered in the container, the query builder resolves via autowiring:

```php
class InvoicesController
{
    public function index(InvoiceIndexQuery $query)
    {
        $invoices = $query->paginate();

        return InvoiceResource::collection($invoices);
    }
}
```

The controller knows nothing about filtering/sorting logic. It just gets the query.

---

## Controller-Specific Modifications

The query builder is still fully Eloquent — you can modify it per-controller:

```php
class PaidInvoicesController
{
    public function index(InvoiceIndexQuery $invoiceQuery)
    {
        // Reuse all the shared config, add one constraint
        $invoices = $invoiceQuery
            ->whereStatus(InvoiceStatus::PAID())
            ->paginate();
    }
}
```

---

## Advanced: Complex Base Queries with Joins

Before passing to the parent constructor, set up any complex query:

```php
use Spatie\QueryBuilder\AllowedFilter;
use Support\QueryBuilder\FuzzyFilter;

class InvoiceIndexQuery extends QueryBuilder
{
    public function __construct(Request $request)
    {
        $query = Invoice::query()
            ->join('invoicees', 'invoicees.invoice_id', '=', 'invoices.id')
            ->join('contacts', 'invoicees.contact_id', '=', 'contacts.id');

        parent::__construct($query, $request);

        $this->allowedFilters([
            'number',
            AllowedFilter::custom('search', new FuzzyFilter(
                'contacts.name',
                'contacts.email',
            )),
        ]);
    }
}
```

---

## Injecting Into View Models

You can pass the query builder to a view model instead of resolving directly in the controller:

```php
class InvoicesController
{
    public function index(InvoiceIndexQuery $invoiceQuery)
    {
        $viewModel = new InvoiceIndexViewModel($invoiceQuery);
        return view('invoices.index', $viewModel);
    }
}

class InvoiceIndexViewModel
{
    public function __construct(private InvoiceIndexQuery $query) {}

    public function invoices(): LengthAwarePaginator
    {
        return $this->query->paginate(25);
    }

    public function totalCount(): int
    {
        return $this->query->count();
    }
}
```

---

## Where They Live

```
Http/Invoices/Queries/
    InvoiceIndexQuery.php
    InvoiceCollectionIndexQuery.php
```

Note: These are **HTTP** query builders (mapping URL params to SQL). This is distinct from **Eloquent** query builders (extending `Builder` in the domain layer).

---

## Naming Clarity

Two different "query builders" exist in this architecture:

| Type | Location | Purpose |
|---|---|---|
| **Eloquent Query Builder** | `Domain/*/QueryBuilders/` | Extends `Illuminate\Database\Eloquent\Builder`. Encapsulates reusable Eloquent scopes. |
| **HTTP Query Builder** | `Http/*/Queries/` | Extends `Spatie\QueryBuilder\QueryBuilder`. Maps HTTP params to SQL. |

---

## Package Reference

- `spatie/laravel-query-builder` — maps `filter[]`, `sort`, `include`, `fields` URL params to Eloquent queries with allowed-list safety

```

---

### skills/application/jobs.md
```md
# Jobs

Jobs belong in the application layer. They manage queue infrastructure — they do NOT contain business logic. Business logic lives in actions.

---

## Jobs Are Like Controllers (for Queues)

| | Controllers | Jobs |
|---|---|---|
| Receives input from | HTTP Request | Developer (serialized data) |
| Dispatched during | HTTP request | Queue worker |
| Supports middleware | Yes | Yes |
| Output | HTTP response | Database writes, mail, etc. |
| Contains business logic | No — delegates to actions | No — delegates to actions |

Just as controllers delegate to actions, jobs delegate to actions.

---

## Job Responsibility: Queue Infrastructure Only

Jobs configure:
- Whether they are queueable (`ShouldQueue`)
- Queue name and connection
- Retry attempts and backoff
- Timeouts
- Chaining with other jobs
- Unique constraints

They do NOT:
- Calculate prices
- Build complex data structures
- Make business decisions

---

## The Pattern: Job → Action

```php
class SendInvoiceMailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        public Invoice $invoice,
    ) {}

    // Laravel injects the action — NOT business logic in the job
    public function handle(SendInvoiceMailAction $sendInvoiceMailAction): void
    {
        $sendInvoiceMailAction->execute($this->invoice);
    }
}
```

Dispatch it:

```php
dispatch(new SendInvoiceMailJob($invoice));
```

---

## Simplified: Generic Action Jobs (spatie/laravel-queueable-action)

Writing a dedicated `*Job` class for every action is boilerplate. The package eliminates this:

```php
// Add the trait to your action
use Spatie\LaravelQueueableAction\QueueableAction;

class SendInvoiceMailAction
{
    use QueueableAction;

    public function execute(Invoice $invoice): void
    {
        // send the mail, track it, etc.
    }
}

// Instead of: dispatch(new SendInvoiceMailJob($invoice));
// Write:
$this->sendInvoiceMailAction->onQueue()->execute($invoice);
```

The package creates a generic job under the hood. IDE autocompletion on `execute()` still works.

---

## When You DO Need a Dedicated Job Class

Use a dedicated job class when the job itself has non-trivial infrastructure concerns:

```php
class ProcessInvoiceBatchJob implements ShouldQueue
{
    use Batchable;

    public int $tries = 3;
    public int $backoff = 60;
    public int $timeout = 300;

    public function __construct(
        private int $invoiceId,
        private string $batchId,
    ) {}

    public function handle(ProcessInvoiceAction $action): void
    {
        if ($this->batch()->cancelled()) {
            return;
        }

        $invoice = Invoice::findOrFail($this->invoiceId);
        $action->execute($invoice);
    }
}
```

Complex retry logic, batching, timeouts, unique jobs — these justify a dedicated class.

---

## Business Logic That Runs Async Still Lives in Actions

"Sending an invoice mail" is domain behaviour:
- Track which client received which mails
- Conditionally attach different PDFs based on client type
- Log the event

All of this lives in `SendInvoiceMailAction`, not in the job. The job just queues the action.

---

## Where Jobs Live

Jobs live in the application layer, not the domain — they know about queue infrastructure (a framework concern).

---

## Package Reference

- `spatie/laravel-queueable-action` — dispatch any action as a queued job without writing a dedicated job class

```

---

### skills/testing/test-factories.md
```md
# Test Factories

Custom test factory classes provide a type-safe, composable, immutable alternative for building test data. They work alongside Laravel 8+ model factories and extend the pattern to DTOs, events, and request objects.

---

## Laravel 8+ Factories

Laravel 8 introduced class-based model factories with much better static analysis support:

```php
$user = User::factory()->make();
$invoice = Invoice::factory()->create();
```

These built-in factories are excellent for models. However, they **only build models**. What about data objects, events, or request objects? That's where custom factories come in.

---

## The Custom Factory Pattern

A test factory is a plain PHP class. No base class required. No interfaces. Just patterns.

### Basic Structure

```php
class InvoiceDataFactory
{
    private static int $number = 0;

    public static function new(): self
    {
        return new self();
    }

    public function create(array $extra = []): InvoiceData
    {
        self::$number += 1;

        return InvoiceData::create(array_merge([
            'number' => 'I-' . self::$number,
            'status' => PendingInvoiceState::class,
        ], $extra));
    }
}
```

Usage:

```php
it('will test something', function () {
    $invoiceData = InvoiceDataFactory::new()->create();
});
```

**Why `new()` and not `make()`?** `make` and `create` imply result production. `new` is just construction — the intent is declared by the chained method.

---

## Making Factories Configurable

Add fluent configuration methods:

```php
class InvoiceFactory
{
    private ?string $status = null;
    private ?PaymentFactory $paymentFactory = null;
    private ?Carbon $expiresAt = null;

    public static function new(): self
    {
        return new self();
    }

    public function paid(PaymentFactory $paymentFactory = null): self
    {
        $clone = clone $this; // IMMUTABLE — always clone
        $clone->status = PaidInvoiceState::class;
        $clone->paymentFactory = $paymentFactory ?? PaymentFactory::new();
        return $clone;
    }

    public function expiresAt(string|Carbon $date): self
    {
        $clone = clone $this;
        $clone->expiresAt = Carbon::parse($date);
        return $clone;
    }

    public function create(array $extra = []): Invoice
    {
        $invoice = Invoice::create(array_merge([
            'status'     => $this->status ?? PendingInvoiceState::class,
            'expires_at' => $this->expiresAt ?? now()->addDays(30),
            'number'     => 'I-' . (++self::$number),
        ], $extra));

        if ($this->paymentFactory) {
            $this->paymentFactory->forInvoice($invoice)->create();
        }

        return $invoice;
    }
}
```

---

## Immutability — The Critical Rule

Every configuration method MUST clone `$this` and return the clone. Never mutate in place.

```php
// RIGHT — immutable
public function paid(): self
{
    $clone = clone $this;
    $clone->status = PaidInvoiceState::class;
    return $clone;
}

// WRONG — mutates original
public function paid(): self
{
    $this->status = PaidInvoiceState::class;
    return $this;
}
```

**Why immutability matters:**

```php
$factory = InvoiceFactory::new()->expiresAt('2023-01-01');

$invoiceA = $factory->paid()->create();   // paid, expires 2023-01-01
$invoiceB = $factory->create();           // pending, expires 2023-01-01 ✓

// Without immutability: $invoiceB would also be paid. Bug.
```

---

## Factories Within Factories

Pass child factories as arguments to control their configuration from outside:

```php
// Paid with a specific payment type
$invoice = InvoiceFactory::new()
    ->paid(PaymentFactory::new()->type(VisaPaymentType::class))
    ->create();

// Paid late (after expiry)
$invoice = InvoiceFactory::new()
    ->expiresAt('2023-01-01')
    ->paid(PaymentFactory::new()->paidAt('2022-05-20'))
    ->create();
```

### Comparison with Laravel 8+ Factories

The same scenario using Laravel's built-in factories:

```php
$invoice = Invoice::factory()
    ->has(
        Payment::factory()
            ->state(['paid_at' => '2022-05-20'])
    )
    ->state([
        'expires_at' => '2023-01-01',
        'state' => PaidInvoiceState::class,
    ])
    ->create();
```

Both approaches work. Laravel 8+ factories can also be extended with custom methods to achieve a similar API:

```php
$invoice = Invoice::factory()
    ->expiresAt('2023-01-01')
    ->paid(Payment::factory()->paidAt('2022-05-20'))
    ->create();
```

Custom factories are still valuable for DTOs, events, request objects, and any non-model test data.

---

## Factories for Data Objects

Factories aren't just for models. Use them for data objects in action tests:

```php
class InvoiceDataFactory
{
    private array $lineFactories = [];

    public static function new(): self
    {
        return new self();
    }

    public function addInvoiceLineDataFactory(InvoiceLineDataFactory $factory): self
    {
        $clone = clone $this;
        $clone->lineFactories[] = $factory;
        return $clone;
    }

    public function create(): InvoiceData
    {
        return new InvoiceData(
            lines: array_map(
                fn(InvoiceLineDataFactory $f) => $f->create(),
                $this->lineFactories
            )
        );
    }
}
```

---

## In Tests — The Setup/Execute/Assert Pattern

```php
it('can save an invoice', function () {
    // SETUP
    $invoiceData = InvoiceDataFactory::new()
        ->addInvoiceLineDataFactory(
            InvoiceLineDataFactory::new()
                ->withDescription('Line A')
                ->withItemAmount(1)
                ->withItemPrice(10_00)
        )
        ->addInvoiceLineDataFactory(
            InvoiceLineDataFactory::new()
                ->withDescription('Line B')
                ->withItemAmount(3)
                ->withItemPrice(33_00)
        )
        ->create();

    // EXECUTE
    $invoice = app(CreateInvoiceAction::class)->execute($invoiceData);

    // ASSERT
    $this->assertDatabaseHas($invoice->getTable(), ['id' => $invoice->id]);
    expect($invoice->number)->not()->toBeNull();
    expect($invoice->total_price)->toEqual(1 * 10_00 + 3 * 33_00);
    expect($invoice->invoiceLines)->toHaveCount(2);
});
```

---

## What NOT to Test with Factories

Factories build data for integration tests — tests of business logic that requires database state. For pure unit tests (e.g., a state class, a calculator) you don't need factories at all.

```

---

### skills/testing/testing-domain.md
```md
# Testing Domain Code

Domain code is tested with integration tests (require database) and unit tests (pure PHP). The factory pattern makes both practical.

---

## The Testing Philosophy

> "If all your actions are properly unit tested, you can be very confident that the bulk of functionality works as intended. Now it's only a matter of using these actions in ways that make sense for the end user."

Domain tests focus on **business rules**, not HTTP. No `$this->get()`, no fake routes, no response assertions.

The universal test pattern: **Setup → Execute → Assert**

---

## Testing Data Objects

Pure data objects with only typed properties need **no tests**. The type system is the test.

Only test data objects that have static constructors (`fromRequest()`, `fromArray()`, etc.):

```php
it('will correctly map a request to booking data', function () {
    $unit = UnitFactory::new()->create();

    $dataObject = BookingData::fromStoreRequest(new BookingStoreRequest([
        'name'       => 'test',
        'unit_id'    => $unit->id,
        'date_start' => '2022-12-01',
        'date_end'   => '2022-12-05',
    ]));

    expect($dataObject)->toBeInstanceOf(BookingData::class);
    // Type checks cover everything else — no need to assert individual fields
});

it('will not work when unit id is missing', function () {
    BookingData::fromStoreRequest(new BookingStoreRequest([
        'name' => 'test',
        'date_start' => '2022-12-01',
        'date_end' => '2022-12-05',
    ]));
})->throws(ModelNotFoundException::class);
```

---

## Testing Actions

Test two things:
1. The action does what it should (output, database state)
2. It correctly uses its composed sub-actions (implicitly, not by testing sub-action internals)

```php
it('can save an invoice', function () {
    // Setup
    $invoiceData = InvoiceDataFactory::new()
        ->addInvoiceLineDataFactory(
            InvoiceLineDataFactory::new()
                ->withDescription('Line A')
                ->withItemAmount(1)
                ->withItemPrice(10_00)
        )
        ->addInvoiceLineDataFactory(
            InvoiceLineDataFactory::new()
                ->withDescription('Line B')
                ->withItemAmount(3)
                ->withItemPrice(33_00)
        )
        ->create();

    // Execute
    $invoice = app(CreateInvoiceAction::class)->execute($invoiceData);

    // Assert
    $this->assertDatabaseHas($invoice->getTable(), ['id' => $invoice->id]);
    expect($invoice->number)->not()->toBeNull();

    $expectedTotalPrice = 1 * 10_00 + 3 * 33_00;
    expect($invoice->total_price)->toEqual($expectedTotalPrice);
    expect($invoice->invoiceLines)->toHaveCount(2);
});
```

**Rule:** Test `CreateInvoiceAction`'s behaviour at the invoice level. Trust that `CreateInvoiceLineAction` works — it has its own test.

---

## Mocking Action Dependencies

For IO-heavy sub-actions (PDF generation, email), mock them via the container:

```php
namespace Tests\Mocks\Actions;

use Domain\Pdf\Actions\GeneratePdfAction;

class MockGeneratePdfAction extends GeneratePdfAction
{
    public static function setup(): void
    {
        app()->singleton(
            GeneratePdfAction::class,
            fn() => new self(),
        );
    }

    public function execute(ToPdf $toPdf): void
    {
        // Do nothing — skip PDF generation in tests
    }
}
```

In your test setup:

```php
beforeEach(function () {
    MockGeneratePdfAction::setup();
});
```

Now `CreateInvoiceAction` will use the mock automatically (via constructor DI from the container).

---

## Testing States

Each state is independently testable — no HTTP, no factory needed:

```php
test('the color of the pending state is orange', function () {
    $invoice = InvoiceFactory::new()->create();
    $state = new PendingInvoiceState($invoice);

    expect($state->colour())->toBe('orange');
});

test('a paid invoice does not need payment', function () {
    $invoice = InvoiceFactory::new()->paid()->create();
    $state = new PaidInvoiceState($invoice);

    expect($state->mustBePaid())->toBeFalse();
});
```

---

## Testing Custom Collections

```php
test('onlyNegatives will only return negative lines', function () {
    $factory = InvoiceLineFactory::new();
    $negativeLine = $factory->withItemPrice(-1_00)->create();

    $collection = new InvoiceLineCollection([
        $negativeLine,
        $factory->withItemPrice(1_00)->create(),
    ]);

    expect($collection->onlyNegatives())->toHaveCount(1);
    expect($negativeLine->is($collection->onlyNegatives()->first()))->toBeTrue();
});
```

---

## Testing Custom Query Builders

```php
it('can filter on active units', function () {
    $factory = UnitFactory::new();
    $activeUnit   = $factory->active()->create();
    $inactiveUnit = $factory->inactive()->create();

    $countOfActiveUnit = Unit::query()
        ->whereActive()
        ->whereKey($activeUnit->id)
        ->count();
    expect($countOfActiveUnit)->toBe(1);

    $countOfInactiveUnit = Unit::query()
        ->whereActive()
        ->whereKey($inactiveUnit->id)
        ->count();
    expect($countOfInactiveUnit)->toBe(0);
});
```

---

## Testing Event Subscribers

Don't go through the model — call the subscriber method directly:

```php
test('saving calculates total price', function () {
    $subscriber = app(InvoiceSubscriber::class);
    $invoice = InvoiceFactory::new()->create();
    $event = new InvoiceSavingEvent($invoice);

    $subscriber->saving($event);

    // Objects are passed by reference — assert on the same invoice
    expect($invoice->total_price)->not()->toBeNull();
});
```

This avoids triggering the full Eloquent event system and tests the subscriber logic in isolation.

---

## What Each Pattern Needs Tested

| Pattern | What to Test | What NOT to Test |
|---|---|---|
| Data object (typed only) | Nothing | — |
| Data object (with `fromX()`) | Mapping correctness, exception cases | Individual field types |
| Action | Output, DB state, sub-action usage | Sub-action internals |
| State | Each method per state class | Model wiring (covered by integration) |
| Transition | State change occurs, side effects fire | State behaviour (test the states) |
| Collection | Custom methods return correct subsets | Base Collection behaviour |
| Query Builder | Custom scopes filter correctly | Eloquent internals |
| Subscriber | Listener method mutates the model correctly | Event registration |

```

---

### commands/scaffolding.md
```md
# Commands — Common Tasks

Quick reference for generating and scaffolding code in this architecture.

> Note: These templates are derived from the patterns in the book, not directly extracted text.

---

## /new-domain {DomainName}

Creates the full folder structure for a new domain concept.

**Creates:**
```
Domain/{DomainName}/
├── Actions/
├── Commands/
├── Collections/
├── DataTransferObjects/
├── Events/
├── Exceptions/
├── Listeners/
├── Models/
├── QueryBuilders/
├── Rules/
└── States/
```

**Also creates matching test folder:**
```
tests/Domain/{DomainName}/
├── Actions/
├── Collections/
├── QueryBuilders/
└── States/
```

---

## /new-action {Domain} {ActionName}

Scaffolds a new action class.

**Template:**
```php
<?php

declare(strict_types=1);

namespace Domain\{Domain}\Actions;

class {ActionName}Action
{
    public function __construct(
        // inject dependencies here
    ) {}

    public function execute(/* {ActionName}Data $data */): mixed
    {
        // business logic here
    }
}
```

**Test template (Pest):**
```php
<?php

use Domain\{Domain}\Actions\{ActionName}Action;

it('does something', function () {
    // Setup

    // Execute
    $result = app({ActionName}Action::class)->execute();

    // Assert
    expect($result)->not()->toBeNull();
});
```

---

## /new-dto {Domain} {DtoName}

Scaffolds a new Data Object.

**Plain PHP Template:**
```php
<?php

declare(strict_types=1);

namespace Domain\{Domain}\DataTransferObjects;

class {DtoName}Data
{
    public function __construct(
        public readonly string $exampleField,
        // add typed properties here
    ) {}
}
```

**Laravel Data Template (recommended):**
```php
<?php

declare(strict_types=1);

namespace Domain\{Domain}\DataTransferObjects;

use Spatie\LaravelData\Data;

class {DtoName}Data extends Data
{
    public function __construct(
        public string $exampleField,
        // add typed properties here
    ) {}
}
```

---

## /new-state {Domain} {ModelName} {States...}

Scaffolds state classes for a model.

**Creates:**
- `{ModelName}State.php` (abstract base)
- One class per state name provided

**Abstract template:**
```php
<?php

namespace Domain\{Domain}\States;

use Domain\{Domain}\Models\{ModelName};

abstract class {ModelName}State
{
    public function __construct(
        protected {ModelName} $model,
    ) {}

    // abstract public function someMethod(): type;
}
```

**Concrete template:**
```php
<?php

namespace Domain\{Domain}\States;

class {StateName}{ModelName}State extends {ModelName}State
{
    // implement abstract methods
}
```

---

## /new-factory {ModelName}

Scaffolds an immutable test factory.

**Template:**
```php
<?php

namespace Tests\Factories;

use Domain\{Domain}\Models\{ModelName};

class {ModelName}Factory
{
    private static int $count = 0;

    private function __construct(
        // private configuration state here
    ) {}

    public static function new(): self
    {
        return new self();
    }

    public function create(array $extra = []): {ModelName}
    {
        return {ModelName}::create(array_merge([
            // default attributes here
        ], $extra));
    }
    
    // Example configurable state:
    // public function withSomeState(): self
    // {
    //     $clone = clone $this;
    //     $clone->someState = true;
    //     return $clone;
    // }
}
```

---

## /new-viewmodel {App} {Module} {ViewModelName}

Scaffolds a view model in the application layer.

**Template:**
```php
<?php

namespace App\{App}\{Module}\ViewModels;

use Illuminate\Contracts\Support\Arrayable;

class {ViewModelName}ViewModel implements Arrayable
{
    public function __construct(
        // inject dependencies here
    ) {}

    public function toArray(): array
    {
        return [
            // expose data to the view
        ];
    }
}
```

---

## /new-query {App} {Module} {QueryName}

Scaffolds an HTTP query builder.

**Template:**
```php
<?php

namespace App\{App}\{Module}\Queries;

use Illuminate\Http\Request;
use Spatie\QueryBuilder\QueryBuilder;

class {QueryName}Query extends QueryBuilder
{
    public function __construct(Request $request)
    {
        $query = {Model}::query()
            ->with([]);

        parent::__construct($query, $request);

        $this
            ->allowedFilters([])
            ->allowedSorts([]);
    }
}
```

---

## Checklist: Adding a New Feature

When a new business requirement arrives:

- [ ] Identify which domain(s) it touches
- [ ] Create/update the data object for the input data
- [ ] Write the action(s) representing the operation
- [ ] Update/create model states if state changes are involved
- [ ] Create test factories for new models/data objects
- [ ] Write action tests (setup → execute → assert)
- [ ] Wire up in the application layer (controller/job/command)
- [ ] Add view model if the UI needs shaped data
- [ ] Add HTTP query builder if it's a list view with filters

```

---

