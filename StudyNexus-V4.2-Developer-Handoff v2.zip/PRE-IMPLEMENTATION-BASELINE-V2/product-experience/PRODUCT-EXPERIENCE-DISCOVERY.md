# StudyNexus — Product Experience & UI/UX Discovery Report

**Date:** 2026-08-10
**Status:** DISCOVERY ONLY — awaiting human approval
**Authoritative baseline:** 6 canonical documents (01–06)
**Constraint:** No canonical documents modified. No implementation code produced.

---

# 1. Executive Conclusion

StudyNexus's canonical business and domain documents define what the platform knows and why it exists. They do not define what the product actually looks like or how a real user accomplishes anything through it. This discovery fills that gap.

**The core product is a search-first, information-rich, SEO-driven education discovery platform.** Users arrive primarily through search (Google or on-site), navigate faceted results, and drill into detail pages for institutions, programmes, and scholarships. The product experience is fundamentally read-heavy: users consume verified, structured knowledge and make decisions. There is no application flow, no transactional workflow, and no user-generated content in the MVP.

**The minimum viable product should be built around a single vertical slice: Programme discovery → Programme detail → Institution detail → Admission information.** This exercises every critical architectural layer (PostgreSQL, Typesense, Eloquent, public rendering, SEO, admin data management, data acquisition) and delivers the highest-value user story: a secondary school student finding a programme, understanding its admission requirements, and seeing which institution offers it.

**Key findings:**

1. The domain model is well-aligned with the product experience but has gaps in publication/versioning that the UX exposes. Programmes need a clear published state. Cut-off marks and admission requirements need historical versioning. The domain model does not yet model "what the user sees" versus "what exists in the database" — it needs a publication/status layer that the product experience requires.

2. The architecture is sound for the product but the UX reveals that Typesense is not just a search add-on — it is the primary read path for the discovery experience. The public-facing programme/institution/scholarship list pages should render from Typesense projections, not Eloquent queries against PostgreSQL. PostgreSQL remains the canonical source; Typesense is the read-optimized serving layer for the discovery experience.

3. Examination/resource discovery (exam → subject → syllabus/resources) does NOT belong in the MVP. It is a separate product surface with distinct content requirements, distinct data acquisition challenges, and no direct overlap with the institution/programme/admission discovery flow. It belongs in Phase 2.

4. The existing domain has 11 entities but the product experience only directly surfaces 3 as primary user-facing pages: Institution, Programme, and Scholarship. Admission Policy, Eligibility Policy, Admission Cycle, Qualification, Accreditation Record, Education Authority, Scholarship Provider, and Information Source are supporting content that appears within or alongside the primary pages, or is exclusively admin-facing. This is healthy — not every entity needs a page.

---

# 2. Primary Users

From `01-business.md`, the four primary personas with their product-relevant characteristics:

| Persona | Priority | Core Need | Search Behaviour | Key Information |
|---------|:-------:|-----------|-----------------|----------------|
| **Secondary School Student / Graduate** | 1 | Discover tertiary programmes, understand admission requirements, compare options | Exploratory. Does not know exact programme names. Filters by location, subject interest, qualification, cost. | Cut-off marks, admission requirements, subject combinations, tuition, institution type |
| **Undergraduate Student** | 2 | Find postgraduate options, scholarships, transfer opportunities | More targeted. Knows their current qualification and field. | Postgraduate requirements, scholarship eligibility, transfer conditions |
| **Parent / Guardian** | 3 | Help child choose — same discovery need, different weightings | Proxy searcher. Prioritises cost, safety, accreditation, location. | Tuition, accreditation status, institution reputation, location |
| **Guidance Counsellor / Teacher** | 4 | Advise multiple students across different profiles | Professional searcher. Needs broad coverage, comparative tools. | Comprehensive comparison, eligibility assessment, reliable/verified data |

**Product implication:** All four personas share the same core interaction pattern: search → filter → evaluate → compare → decide. The variation is in which filters they use, which information they weight most heavily, and how many items they compare. The product does NOT need persona-specific interfaces — it needs a single powerful search/filter/compare experience that naturally serves all four through the richness of its facets and the completeness of its detail pages.

**Mobile priority:** Nigeria has heavy mobile internet usage. The secondary school student persona is overwhelmingly mobile. The product must be mobile-first, not mobile-responsive as an afterthought.

---

# 3. Primary User Journeys

After analysis against business workflows (WF1–WF7), SEO value, architectural significance, and MVP relevance, the primary journeys are:

## Journey 1: Programme Discovery (HIGHEST PRIORITY)

```
Home / Landing page
  ↓
Search input (programme-focused)
  ↓
Faceted results (filter by location, institution type, discipline, qualification, admission pathway, tuition range)
  ↓
Programme result card (institution name, programme name, qualification, duration, tuition, admission status)
  ↓
Programme detail page (full admission requirements, cut-off marks, subject combinations, fees, institution info)
  ↓
Institution detail page (accreditation, all programmes, facilities, contact)
```

**Why this is Journey 1:** This is the single highest-value user story. A SS3 student trying to answer "What can I study with my subject combination?" is StudyNexus's raison d'être. It exercises search, faceting, detail rendering, cross-entity navigation, SEO, and provenance display. It validates the entire stack end-to-end.

## Journey 2: Institution Discovery

```
Search / Browse (institution-focused)
  ↓
Institution results (filter by type, location, accreditation, ownership)
  ↓
Institution detail (profile, programmes, accreditation records, admission info, contact)
  ↓
Programme detail (from institution context)
```

**Why:** Users who know which institution they are interested in need to find it and explore its offerings. This is also the primary SEO surface — institution pages are the most stable, most linkable, and most Google-valuable content.

## Journey 3: Scholarship Discovery

```
Scholarship search / browse
  ↓
Scholarship results (filter by eligibility, coverage, deadline, provider)
  ↓
Scholarship detail (requirements, coverage amount, deadline, how to apply, eligible programmes/institutions)
```

**Why:** Scholarships are a high-impact, high-intent need. However, scholarship data is harder to acquire reliably and changes frequently. Scholarship discovery is important but secondary to programme/institution discovery in the MVP because the core value proposition (replacing fragmented discovery) is most acutely felt for programmes and admission requirements.

## Journey 4: Compare Programmes/Institutions

```
From search results or detail page
  ↓
Add to comparison (2–4 items)
  ↓
Comparison view (side-by-side on key dimensions: tuition, requirements, location, duration, accreditation)
```

**Why:** Comparison is a core business capability (WF3) and a key differentiator. It requires structured, standardised information — exactly what StudyNexus provides. However, comparison can be launched later than the basic search/detail flow because users can still make decisions by opening multiple tabs. Comparison adds significant value but is not a prerequisite for the product to be useful.

## Journey 5: Assess Eligibility (Future)

```
From programme detail page
  ↓
Enter own qualifications (subjects, grades, exam type)
  ↓
Eligibility result (meet / partially meet / do not meet requirements)
```

**Why:** This is WF4. It is high-value but requires reliable, machine-readable admission rules. Per OQ6-3, the method of eligibility assessment is deferred to product discovery. The data quality required (structured admission rules, not just text descriptions) may not be available at launch. This is Phase 2.

## Journey NOT in MVP: Examination/Resource Discovery

```
Exam → Subject → Syllabus/Resources
```

**Why excluded from MVP:** This is a separate content domain with distinct acquisition challenges (WAEC/NECO syllabi, past questions, study resources). It serves a different user need (exam preparation vs. opportunity discovery) and would require significant additional data acquisition, content licensing, and product design. It does not exercise the core discovery architecture in a way that the programme/institution journey does not already cover. Phase 2 at earliest.

---

# 4. Information Architecture

## 4.1 Primary Navigation

```
StudyNexus
├── Programmes        (primary — the core discovery surface)
├── Institutions      (primary — institution profiles and listings)
├── Scholarships      (primary — scholarship discovery)
└── Compare           (secondary — accessible from results/detail pages)
```

**No "Home" as a separate content section.** The home page IS the search entry point. Users arrive at StudyNexus to search. The home page should present the search experience immediately, with popular/suggested categories as discovery aids for users who do not know where to start.

## 4.2 Search Entry Points

1. **Global search bar** — present on every page. Autocomplete with programme, institution, and scholarship results. Typesense-powered.
2. **Home page search** — prominent, central, with category tabs (Programmes / Institutions / Scholarships) and popular filter suggestions.
3. **Category landing pages** — `/programmes`, `/institutions`, `/scholarships` — each presents a faceted search experience focused on that entity type.
4. **SEO landing pages** — pre-composed filter combinations that form stable, indexable URLs (e.g., `/programmes/in/lagos`, `/programmes/engineering`, `/institutions/universities`).

## 4.3 Content Relationships

```
Institution
├── Programmes[]           (has many — primary relationship)
├── AccreditationRecords[] (has many — shown in institution profile)
├── AdmissionCycles[]      (has many — shown with admission info)
└── Scholarships[]         (has many — scholarships offered by/at this institution)

Programme
├── Institution            (belongs to — always shown)
├── AdmissionPolicies[]    (has many — admission requirements)
├── AccreditationRecords[] (has many — programme-level accreditation)
└── Scholarships[]         (has many — scholarships applicable to this programme)

Scholarship
├── ScholarshipProvider    (belongs to — shown in detail)
├── eligible Institutions[] (many-to-many — where applicable)
└── eligible Programmes[]   (many-to-many — what it covers)
```

**Navigation is bidirectional.** From any programme, the user can navigate to its institution, its scholarships, and its admission information. From any institution, the user can navigate to any of its programmes. From any scholarship, the user can navigate to eligible institutions and programmes. This creates a dense but natural navigation graph that serves all personas.

## 4.4 Taxonomy / Browsing Structure

The primary browsing dimensions (not every dimension deserves a browse page):

| Browse Dimension | Entity | Indexable? | Rationale |
|-----------------|--------|:----------:|-----------|
| By state/location | Institution, Programme | Yes | Users commonly search by geography |
| By institution type (University, Polytechnic, CoE, IEI) | Institution | Yes | Major classification; stable |
| By discipline/category (Engineering, Medicine, Law, Arts…) | Programme | Yes | Primary discovery dimension for programmes |
| By qualification awarded (B.Sc, B.A, HND, ND, NCE) | Programme | Yes | Users know what qualification they want |
| By admission pathway (UTME, Direct Entry, IJMB, JUPEB) | Programme | Yes | Critical for non-UTME candidates |
| By ownership (Federal, State, Private) | Institution | Yes | Important filter for Nigerian students |
| By accreditation status | Institution, Programme | No | Not a browse entry point; filter only |

---

# 5. Core Views: Views

## 5.1 Home Page

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Search entry point; immediate value; convey trust and scope |
| **Target user** | All personas — especially first-time visitors |
| **Entry points** | Direct URL, Google search result |
| **Key information** | Search bar (prominent, central); category quick-links (Programmes, Institutions, Scholarships); popular searches or trending programmes; trust signals (number of institutions, programmes, verification status) |
| **Primary actions** | Search; navigate to category landing page |
| **SEO importance** | HIGH — the front door |
| **Required data** | Programme/institution/scholarship counts (cached); popular search terms; category metadata |

## 5.2 Programme Search Results

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Faceted programme discovery — the primary product surface |
| **Target user** | All personas — especially SS3 students and parents |
| **Entry points** | Home search; /programmes landing; programme nav link; SEO landing page |
| **Key information** | Facet sidebar (location, institution type, discipline, qualification, admission pathway, tuition range, ownership); result cards; result count; sort options |
| **Result card contains** | Programme name; institution name + type badge; qualification; duration; tuition range; admission status (open/closed); accreditation badge |
| **Primary actions** | Click to programme detail; add to comparison; refine filters |
| **Secondary actions** | Sort (relevance, tuition low→high, institution name A→Z); paginate; share URL |
| **SEO importance** | CRITICAL — the primary indexable surface |
| **Required data** | Typesense programme index with denormalized institution data |

## 5.3 Programme Detail Page

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Complete information about a specific programme at a specific institution |
| **Target user** | All personas evaluating a specific programme |
| **Entry points** | Search result click; institution programme list; direct URL; Google result |
| **Hero information** | Programme name; institution name + link; qualification; duration; study mode |
| **Key sections** | Admission Requirements (UTME subjects, O-level requirements, cut-off mark, direct entry requirements, alternative pathways); Tuition & Fees (per level, per session); Accreditation (status, accrediting body, date); Programme Description; Career Pathways |
| **Related content** | Other programmes at this institution; similar programmes at other institutions; applicable scholarships |
| **Primary actions** | Navigate to institution; view admission details; add to comparison; find scholarships |
| **Provenance display** | "Verified by StudyNexus" badge; last verified date; source attribution (e.g., "Admission requirements sourced from JAMB 2026 brochure") |
| **Historical information** | Previous cut-off marks (if changed); previous admission requirements (if superseded); effective dates shown |
| **SEO importance** | CRITICAL — highly indexable, stable URL, rich content |
| **URL pattern** | `/institutions/{institution-slug}/programmes/{programme-slug}` |
| **Required data** | Programme aggregate + Institution data + Admission Policies + Accreditation Records + Scholarships |

## 5.4 Institution Detail Page

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Complete profile of an educational institution |
| **Target user** | All personas — especially those exploring a specific institution |
| **Entry points** | Search result click; programme detail link; direct URL; Google result |
| **Hero information** | Institution name; type badge (University/Polytechnic/CoE/IEI); ownership (Federal/State/Private); location (city, state); logo |
| **Key sections** | Overview (year established, motto, website, contact); Accreditation Summary (overall status, latest NUC/NBTE/NCCE accreditation); Programmes (faceted list — filter by qualification, discipline); Admission Information (current cycle, general requirements, cut-off trends); Facilities & Campus |
| **Related content** | Similar institutions; scholarships at this institution |
| **Primary actions** | Browse programmes; view admission info; add to comparison |
| **SEO importance** | CRITICAL — most stable URL, high Google value |
| **URL pattern** | `/institutions/{institution-slug}` |

## 5.5 Scholarship Detail Page

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Complete information about a scholarship opportunity |
| **Target user** | All personas seeking financial support |
| **Entry points** | Scholarship search; programme detail link; institution detail link; direct URL |
| **Hero information** | Scholarship name; provider; coverage type (full/partial); amount; deadline |
| **Key sections** | Eligibility Requirements; Coverage Details; How to Apply; Eligible Programmes/Institutions; Timeline |
| **Provenance display** | Source; last verified date |
| **SEO importance** | HIGH — stable URLs, valuable content |
| **URL pattern** | `/scholarships/{scholarship-slug}` |

## 5.6 Comparison View

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Side-by-side comparison of 2–4 programmes or institutions |
| **Target user** | All personas making a decision between options |
| **Entry points** | "Compare" action from search results or detail pages |
| **Key information** | Aligned columns for each item; rows for every comparable dimension (tuition, location, duration, admission requirements, accreditation, etc.) |
| **Primary actions** | Remove item; add item; navigate to detail |
| **SEO importance** | LOW — user-state URL, not indexable |
| **Required data** | Programme/Institution detail data for selected items |

## Views NOT in MVP

| View | Reason |
|------|--------|
| Examination/Subject/Syllabus pages | Phase 2 — separate content domain |
| User profile / saved items | Requires user accounts (OQ4-1: no account required for core MVP) |
| Community / Q&A / Reviews | Stage 3 feature |
| Eligibility assessment tool | Requires structured admission rules; Phase 2 |
| Separate Admission Cycle page | Admission info is contextual within programme/institution |
| Separate Accreditation Record page | Accreditation is shown within institution/programme context |
| Education Authority page | Admin-facing only; not a public content page |

---

# 6. Search & Faceted Discovery Model

## 6.1 Global Search

- **Input:** Free-text search bar on every page. Typesense-powered with typo tolerance.
- **Autocomplete:** Yes. Show programme, institution, and scholarship suggestions as the user types. Grouped by type. Show the most relevant 3–5 suggestions per type.
- **Spelling tolerance:** Yes (Typesense built-in). Nigerian institution names are frequently misspelled.
- **Synonyms:** Yes. "Uni" → "University", "Poly" → "Polytechnic", "Scholarship" → "Award/Grant" (limited set, not a full synonym engine).
- **Search scopes:** All (default), Programmes, Institutions, Scholarships. The category tabs in navigation define the scope.

## 6.2 Programme Search

### Search input
- Free-text: searches programme name, discipline, related keywords
- Geosearch: by state (Nigeria has 36 states + FCT). Not a radius search — Nigerian education search is state-based.

### Result card
```
┌──────────────────────────────────────────────┐
│ University of Lagos                    [Uni] │
│ B.Sc. Computer Science              [B.Sc]  │
│ ├── 4 years · Full-time                     │
│ ├── ₦150,000/session (indigene)             │
│ ├── Cut-off: 200 (2025/2026)                │
│ ├── Accredited (NUC) ✓                      │
│ └── Admission: Open                         │
└──────────────────────────────────────────────┘
```

### Meaningful facets

| Facet | Type | Source | MVP? |
|-------|------|--------|:----:|
| State/Location | Multi-select | Institution.state | Yes |
| Institution Type | Multi-select | InstitutionType enum | Yes |
| Ownership | Multi-select | OwnershipType enum (Federal/State/Private) | Yes |
| Qualification Awarded | Multi-select | AwardLevel enum (B.Sc, B.A, HND, ND, NCE, M.Sc…) | Yes |
| Discipline/Category | Multi-select | Programme discipline classification | Yes |
| Admission Pathway | Multi-select | AdmissionPathway VO (UTME, Direct Entry, IJMB, JUPEB) | Yes |
| Tuition Range | Range slider | Programme.tuition | Yes |
| Accreditation Status | Multi-select | AccreditationRecord.status | Yes |
| Study Mode | Multi-select | DeliveryMode enum (Full-time, Part-time) | No — low discriminability in MVP |
| Duration | Range | Programme.duration | No — rarely used as primary filter |

**Do NOT blindly expose every field.** Facets must be useful discriminators. A facet that returns 98% one value and 2% another (e.g., "Country: Nigeria" in MVP) is useless and should be hidden.

### Filter behaviour
- **Multi-select within a facet:** OR semantics (selecting "Lagos" AND "Ogun" shows programmes in either state)
- **Cross-facet:** AND semantics (Lagos + University = universities in Lagos)
- **Filter persistence:** Filters persist in the URL as query parameters. User can share/bookmark filtered views.
- **URL representation:** `/programmes?state=lagos,kano&type=university&qualification=b.sc&discipline=engineering`
- **Clearing:** "Clear all" button; individual facet clear.
- **Sorting:** Relevance (default, Typesense), Tuition (low→high, high→low), Institution name (A→Z), Cut-off mark (low→high, high→low)
- **Pagination:** Traditional numbered pagination (not infinite scroll). SEO requires accessible, indexable page URLs.
- **Facet counts:** Yes — show count of matching results per facet value. Essential for users to understand the filter landscape.
- **Zero results:** Show helpful message with suggestions: "No programmes match all your filters. Try removing [filter name] or searching for [similar query]."

### Search URLs and SEO

| URL Pattern | Indexable? | Type |
|-------------|:----------:|------|
| `/programmes` | Yes | Category landing page |
| `/programmes/in/{state}` | Yes | SEO landing page (e.g., "Programmes in Lagos") |
| `/programmes/{discipline}` | Yes | SEO landing page (e.g., "Engineering Programmes") |
| `/programmes/in/{state}/{discipline}` | Yes | SEO landing page (combo) |
| `/institutions` | Yes | Category landing page |
| `/institutions/{type}` | Yes | SEO landing page (e.g., "Universities") |
| `/institutions/in/{state}` | Yes | SEO landing page |
| `/scholarships` | Yes | Category landing page |
| `/programmes?state=lagos&qualification=b.sc` | No | User-state search URL (arbitrary filter combo) |
| `/institutions/{slug}` | Yes | Entity detail page |
<canonical> |
| `/institutions/{slug}/programmes/{slug}` | Yes | Entity detail page (canonical) |

**Key principle:** Only a limited set of pre-composed filter combinations become indexable landing pages. Arbitrary user filter combinations are noindex, canonical to their nearest landing page. This# 7. Detail-Page Information Hierarchy

## 7.1 Programme Detail

```
┌─ HERO ─────────────────────────────────────────────────┐
│ B.Sc. Computer Science                                  │
│ University of Lagos · Akoka, Lagos · Federal University │
│ 4 years · Full-time · Accredited (NUC) ✓              │
│ Last verified: 2026-07-15                              │
└─────────────────────────────────────────────────────────┘

┌─ ADMISSION REQUIREMENTS (primary section) ─────────────┐
│ UTME Subject Combination:                              │
│   English (compulsory), Maths, Physics, Chemistry      │
│ O-Level Requirements:                                  │
│   5 credits including English, Maths, Physics          │
│ Cut-off Mark: 200 (2025/2026 session)                  │
│   Previous: 180 (2024/2025) · 175 (2023/2024)         │
│ Direct Entry Requirements:                             │
│   2 A-level passes in Maths and Physics                │
│ Alternative Pathways: IJMB, JUPEB                      │
│ Source: JAMB 2026 Brochure, verified 2026-07-15       │
└─────────────────────────────────────────────────────────┘

┌─ TUITION & FEES ───────────────────────────────────────┐
│ Indigene:  ₦150,000 / session                          │
│ Non-Indigene: ₦250,000 / session                       │
│ Acceptance fee: ₦30,000                                │
│ Source: Institution website, verified 2026-06-20      │
└─────────────────────────────────────────────────────────┘

┌─ ACCREDITATION ────────────────────────────────────────┐
│ NUC: Full Accreditation (granted 2023, expires 2028)   │
└─────────────────────────────────────────────────────────┘

┌─ RELATED ──────────────────────────────────────────────┐
│ Other programmes at University of Lagos (browse)       │
│ Similar programmes at other institutions               │
│ Scholarships applicable to this programme              │
└─────────────────────────────────────────────────────────┘
```

**Historical information treatment:** Cut-off marks are shown with previous values and their effective sessions. This is not "showing the audit trail" — it is showing the user contextually relevant history. "The cut-off was 180 last year and 175 the year before" is genuinely useful for a student estimating their chances. The previous values are secondary information — collapsed by default, expandable.

**Superseded admission requirements:** If requirements changed (e.g., subject combination was modified), show the current requirements prominently and the previous version as "Requirements for 2024/2025 session" in a collapsible section. The user should see the current canonical information first and historical context only when they seek it.

## 7.2 Institution Detail

```
┌─ HERO ─────────────────────────────────────────────────┐
│ University of Lagos                                    │
│ Federal University · Est. 1962 · Akoka, Lagos          │
│ Type: University · Ownership: Federal                  │
│ Accredited (NUC) ✓ · 85 programmes                    │
└─────────────────────────────────────────────────────────┘

┌─ PROGRAMMES (primary section, faceted) ────────────────┐
│ [All (85)] [Undergraduate (72)] [Postgraduate (13)]   │
│ Filter by: Discipline, Qualification, Admission Status │
│ ┌─ Programme list (searchable, filterable) ──────┐    │
│ │ B.Sc. Computer Science · 4 yrs · ₦150,000     │    │
│ │ B.Sc. Electrical Engineering · 5 yrs · ₦150,000│    │
│ │ …                                              │    │
│ └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘

┌─ ADMISSION INFORMATION ────────────────────────────────┐
│ Current Admission Cycle: 2026/2027                     │
│ General UTME Requirements: …                           │
│ Application Period: …                                  │
└─────────────────────────────────────────────────────────┘

┌─ ACCREDITATION ────────────────────────────────────────┐
│ NUC: Full Accreditation (2023–2028)                    │
│ Programme-level accreditations (summary)               │
└─────────────────────────────────────────────────────────┘

┌─ ABOUT ────────────────────────────────────────────────┐
│ Website: unilag.edu.ng                                 │
│ Contact: …                                             │
│ Address: Akoka, Yaba, Lagos                           │
└─────────────────────────────────────────────────────────┘
```

## 7.3 Scholarship Detail

```
┌─ HERO ─────────────────────────────────────────────────┐
│ Shell Nigeria University Scholarship                   │
│ Shell Petroleum · Full Scholarship                     │
│ Deadline: 2026-09-30                                   │
└─────────────────────────────────────────────────────────┘

┌─ ELIGIBILITY ──────────────────────────────────────────┐
│ Must be a Nigerian citizen                             │
│ Must be enrolled in a Nigerian university              │
│ Minimum CGPA: 3.5                                      │
│ Eligible fields: Engineering, Geosciences, IT          │
└─────────────────────────────────────────────────────────┘

┌─ COVERAGE ─────────────────────────────────────────────┐
│ Full tuition + Accommodation + Stipend                 │
│ Duration: Throughout programme                         │
└─────────────────────────────────────────────────────────┘

┌─ ELIGIBLE INSTITUTIONS & PROGRAMMES ───────────────────┐
│ (Linked institution/programme pages)                   │
└─────────────────────────────────────────────────────────┘
```

## 7.4 Provenance & Verification Display

Users need to trust the information. The display must be informative without exposing internal machinery:

- **Verified information:** "Verified by StudyNexus" badge with last-verified date. Green check icon. This is the default state for information that has been cross-referenced against an official source.
- **Official information:** "Sourced from [JAMB / NUC / Institution website]" attribution. This tells the user where the information came from without showing the acquisition process.
- **Unverified information:** "Awaiting verification" notice. Amber icon. This information has been acquired but not yet cross-referenced.
- **Historical information:** "As of [date]" label. This indicates when the information was confirmed accurate. Not "scraped on" — the user does not need to know the scraping date.
- **Superseded information:** Collapsed section labelled "Previous [cut-off / requirements / tuition]" with effective date range. The user can see it if they want historical context.

**Never expose:** Scraping details, adapter class names, import batch IDs, raw source data, crawl timestamps, match confidence scores. These are internal machinery.

---

# 8. Product States

| State | Where | Importance | Treatment |
|-------|-------|:----------:|-----------|
| **Loading** | Search results, detail pages | High | Skeleton placeholders. Programme/institution cards should show structure before data fills in. |
| **Empty / No results** | Search results | High | Helpful message with suggestions: remove filters, broaden search, browse categories. |
| **Partial / Incomplete data** | Detail pages | Medium | Show what is available. Mark missing sections with "Information not yet available" rather than hiding them. This is common — many institution websites are incomplete. |
| **Unverified data** | Detail pages | Medium | Show the information with an "Awaiting verification" notice. Better to show unverified information with a warning than to hide it entirely. |
| **Recently updated** | Detail pages | Low | "Updated [X days ago]" timestamp. Useful for trust but not critical. |
| **Admission cycle closed** | Programme detail | Medium | "Admission for 2026/2027 cycle is closed." Show requirements for reference; link to next cycle when available. |
| **Coming soon** | Scholarship detail | Low | "Opening soon" for scholarships with future application dates. |

**States NOT needed for MVP:**

| State | Why excluded |
|-------|-------------|
| User logged in / logged out | No user accounts in MVP (OQ4-1) |
| Archived / Deprecated entity | If an entity is archived, it should not appear in public search. Admin-only concern. |
| Error (server) | Generic error page; no special product state needed |

---

# 9. Mobile & Responsive Behaviour

**Principle: Mobile-first.** Nigeria's internet usage is predominantly mobile. Design for the small screen first.

| Element | Mobile | Desktop |
|---------|--------|---------|
| **Search bar** | Full-width, prominent. Sticky on scroll. | Prominent in header. |
| **Facets/Filters** | Bottom sheet or full-screen overlay. "Filter" button with active count badge. No sidebar — screen too narrow. | Left sidebar, always visible. Facet values collapsible. |
| **Result cards** | Full-width stacked cards. Key info: programme name, institution, qualification, tuition. | 2–3 column grid or list view. More information visible per card. |
| **Detail pages** | Single column. Sections stacked vertically. Tab navigation for major sections on programme/institution pages. | Multi-column layout where appropriate. Sidebar with quick facts. |
| **Comparison** | Horizontal scroll with 2 items maximum. Consider vertically-aligned comparison on very small screens. | Side-by-side columns (2–4 items). |
| **Navigation** | Hamburger menu. Bottom tab bar for primary categories (Programmes, Institutions, Scholarships). | Top nav bar with primary categories. |
| **Pagination** | "Load more" button or numbered pages. | Numbered pagination with page links. |

---

# 10. SEO Experience Requirements

## Indexable pages

| Page Type | URL Pattern | Count (est.) | Indexable |
|-----------|-------------|:------------:|:---------:|
| Home | `/` | 1 | Yes |
| Programme landing | `/programmes` | 1 | Yes |
| Institution landing | `/institutions` | 1 | Yes |
| Scholarship landing | `/scholarships` | 1 | Yes |
| Programme by state | `/programmes/in/{state}` | 37 | Yes |
| Programme by discipline | `/programmes/{discipline}` | ~30 | Yes |
| Institution by type | `/institutions/{type}` | 4 | Yes |
| Institution by state | `/institutions/in/{state}` | 37 | Yes |
| Institution detail | `/institutions/{slug}` | ~500 | Yes |
| Programme detail | `/institutions/{slug}/programmes/{slug}` | ~10,000 | Yes |
| Scholarship detail | `/scholarships/{slug}` | ~200 | Yes |

**Estimated indexable surface: ~11,000 pages.** This is significant but manageable. Each page has unique, structured content with distinct titles, meta descriptions, and JSON-LD structured data.

## Non-indexable pages

| Page Type | Reason |
|-----------|--------|
| Search with arbitrary filters | Canonical URL is the nearest landing page; noindex |
| Comparison view | User-state URL; noindex |
| Admin panel | Behind auth; noindex |
| Paginated beyond page 1 | noindex, follow (to discover detail pages) |

## JSON-LD structured data

- Institution pages: `CollegeOrUniversity` schema
- Programme pages: `EducationalOccupationalProgram` schema
- Scholarship pages: `EducationalOccupationalCredential` or custom scholarship schema

## Sitemap

- Partitioned sitemaps: `sitemap-institutions.xml`, `sitemap-programmes.xml`, `sitemap-scholarships.xml`, `sitemap-landing.xml`
- Generated after each data import batch that adds/updates entities

---

# 11. Administrative Workflows

The admin panel (Filament v5) supports the product. The key workflows are:

| Workflow | Actors | Description |
|----------|--------|-------------|
| **Review imported data** | content-admin, content-editor | Review pending imports; resolve duplicates and conflicts; approve or reject records |
| **Manage institutions** | content-admin, content-editor | Create/edit institution profiles; update contact info, facilities, descriptions; manage accreditation records |
| **Manage programmes** | content-admin, content-editor | Create/edit programme details; update admission requirements, tuition, cut-off marks; manage admission policies |
| **Manage scholarships** | content-admin, content-editor | Create/edit scholarships; update eligibility, deadlines, coverage |
| **Publish/unpublish** | content-admin | Control what appears on the public site. Entities can exist in the database without being published. |
| **Verify information** | platform-moderator, content-admin | Mark information sources as verified; review community corrections |
| **View provenance/history** | content-admin, content-editor | See where data came from; view change history; compare current vs. previous values |
| **Manage information sources** | platform-admin, content-admin | Register/edit/disable sources; configure adapters; trigger manual imports |
| **RBAC management** | platform-admin | Manage platform roles; invite institution admins; manage OrganizationMember memberships |

**Institution self-service (institution-owner, institution-admin, etc.) is NOT in the MVP.** Per A2-3, institution management features come post-MVP. In the MVP, all institution data is managed by the StudyNexus content team through the admin panel.

---

# 12. Domain-Model / UX Reconciliation

This section examines whether the current domain model naturally supports the discovered product experience.

## Gaps found

### GAP-1: No Publication/Status Model on Entities

**Problem:** The domain model has status enums (InstitutionStatus, ProgrammeStatus, ScholarshipStatus) but these model domain lifecycle states (Active, Suspended, Closed, etc.), not publication states. The product experience requires a clear distinction between:

- Data that exists in the database (acquired, possibly verified)
- Data that is published and visible on the public site
- Data that is unpublished (awaiting review, draft, or intentionally hidden)

**Current state:** An institution can be "Active" in the domain but there is no concept of "published to the public site." The product needs: `is_published` boolean or `publication_status` enum on Programme, Institution, and Scholarship.

**Severity:** HIGH — without this, the public site would show every entity in the database regardless of completeness or verification status.

**Recommendation:** Add a `publication_status` column (Draft, Published, Unpublished, Archived) to institutions, programmes, and scholarships. This is a product requirement, not a domain change. It does not affect domain invariants.

### GAP-2: No Historical Versioning for Key Data Points

**Problem:** The product experience shows cut-off marks and admission requirements with historical values (e.g., "Cut-off: 200 (2025/2026) — Previous: 180 (2024/2025)"). The domain model has provenance on entities (who acquired the data, when) but does not model historical values of specific attributes.

**Current state:** If a cut-off mark changes from 150 to 200, the old value is overwritten. The provenance trait tracks when data was acquired and from where, but does not retain the previous value for display.

**Severity:** MEDIUM — the product can launch without historical cut-off displays, but this is a significant user need (students use previous cut-offs to estimate their chances). Pragmatic approach: store previous values in a simple `attribute_history` JSON column or a lightweight `data_versions` table. Not event sourcing — just relational history.

**Recommendation:** Add a `data_versions` polymorphic table that stores previous values of designated attributes when they change. Not every attribute needs history — only user-facing, decision-relevant attributes (cut-off marks, tuition, admission requirements).

### GAP-3: Programme Discipline/Category Classification

**Problem:** The product experience requires a "Discipline" facet for programme search (Engineering, Medicine, Law, Arts, etc.). The domain model does not have an explicit discipline/category classification for programmes. Programmes have a name ("Computer Science") and a qualification (B.Sc.), but no structured category.

**Current state:** Tags (via Spatie tags) could serve this, but there is no canonical discipline taxonomy defined.

**Severity:** HIGH — without discipline classification, programme search cannot provide the most important browse dimension. Users do not search for "B.Sc." — they search for "Engineering" or "Medicine."

**Recommendation:** Define a canonical discipline taxonomy (Engineering, Medicine/Health Sciences, Law, Business/Admin, Arts/Humanities, Education, Sciences, Agriculture, Environmental, Social Sciences, etc.) and classify programmes. This can be a simple string column or enum on Programme, or a structured taxonomy table. Spatie tags are an alternative but lack the hierarchy and controlled vocabulary needed for faceted search.

### GAP-4: Tuition as a Searchable Range

**Problem:** The product needs a tuition range filter (e.g., "Under ₦200,000/session"). The domain model stores MonetaryAmount as a VO, but tuition varies by indigene status, level, and programme. There is no single "tuition" value to facet on.

**Current state:** Tuition is stored as structured data (potentially multiple amounts for different categories). Typesense needs a single numeric value for range filtering.

**Severity:** MEDIUM — workaround is to store a `tuition_min` and `tuition_max` denormalized on the programme for search, even if the detailed tuition breakdown is more complex.

**Recommendation:** Denormalize tuition range (min/max) into the Typesense programme document for faceted search. The detail page shows the full breakdown. This is a read-model concern, not a domain change.

### GAP-5: No "Admission Open/Closed" State

**Problem:** Programme result cards show "Admission: Open" or "Admission: Closed." The domain model has AdmissionCycle with phases, but there is no simple derived state that answers "is admission currently open for this programme?"

**Current state:** Deriving this requires joining Programme → ProgrammeInstance → AdmissionPolicy → AdmissionCycle and checking if there is an active cycle with an open phase. This is possible but complex for a result card.

**Severity:** MEDIUM — workaround is to denormalize an `admission_open` boolean onto the programme Typesense document, updated when admission cycle phases change.

**Recommendation:** Compute `admission_open` as a denormalized field on the Typesense programme document. Recompute when admission cycle data changes. This is a read-model optimisation.

## Alignment confirmed

| Aspect | Status | Detail |
|--------|--------|--------|
| Institution → Programme relationship | ✓ Aligned | Naturally supports institution profile with programme list |
| Programme → ProgrammeInstance → AdmissionPolicy relationship | ✓ Aligned | Admission info displays correctly on programme detail |
| Scholarship → Programme/Institution linkage | ✓ Aligned | Scholarships can link to eligible programmes and institutions |
| Provenance model | ✓ Aligned | Supports the "Verified by StudyNexus" and source attribution display |
| Typesense as read projection | ✓ Aligned | Architecture already defines Typesense as the search layer |
| Entity counts (11 entities) | ✓ Aligned | Only 3 need user-facing pages; the rest are supporting or admin-only |

---

# 13. Architecture / UX Reconciliation

## Confirmed adequate

| Architectural concern | Status | Detail |
|----------------------|--------|--------|
| PostgreSQL + Eloquent as canonical source | ✓ | Supports all entity queries for detail pages |
| Typesense for search/faceting | ✓ | The right tool for faceted, typo-tolerant, ranked search |
| Filament v5 for admin | ✓ | Supports all administrative workflows identified |
| Livewire v4 for public UI | ✓ | Supports interactive search, faceting, comparison without a JS SPA |
| SEO page rendering | ✓ | Laravel + Blade renders server-side HTML; Typesense serves search API |
| Queue jobs for search indexing | ✓ | After data import, search index updates are queued |
| Caching | ✓ | Programme/institution detail pages can be HTTP-cached; search results cached with short TTL |

## Gaps found

### ARCH-GAP-1: Typesense is the Primary Read Path for Discovery

**Problem:** The current architecture treats Typesense as "the search add-on." The product experience reveals that Typesense is actually the primary read path for the entire discovery surface. Programme search results, institution search results, faceted browsing, and even programme/institution list pages within institution detail should all serve from Typesense, not from Eloquent queries against PostgreSQL.

**Current state:** The architecture defines Typesense for search but does not explicitly establish it as the serving layer for list/browse pages.

**Severity:** MEDIUM — the architecture supports this; it just needs to be made explicit. Programme search results are already Typesense-served. The question is whether the programme list on an institution detail page also comes from Typesense (filtered by institution) or from Eloquent.

**Recommendation:** Establish the principle: all list/browse/search surfaces serve from Typesense. Only individual entity detail pages query PostgreSQL directly (for the full entity graph). This means the Typesense programme document must be rich enough to render result cards and list items without a PostgreSQL round-trip.

### ARCH-GAP-2: No Public HTTP Cache Strategy Defined

**Problem:** The product experience is read-heavy and the content changes infrequently (daily at most, for most entities). HTTP caching can dramatically reduce server load and improve response times. The architecture mentions Redis for caching but does not define a public page cache strategy.

**Severity:** LOW — performance optimisation, not a functional gap.

**Recommendation:** Define HTTP cache headers for public pages: detail pages cache for 1–4 hours; landing pages cache for 4–24 hours; search results cache for 5–15 minutes. Purge on data update via cache tags.

### ARCH-GAP-3: Data Acquisition Boundary Clarification

**Problem:** The user's instructions clarify that scraper mechanics belong outside the StudyNexus core. The canonical `06-data-acquisition.md` defines the pipeline inside StudyNexus. This needs reconciliation.

**Current state:** The data acquisition pipeline is designed as an internal subsystem with adapters, staging, and verification inside StudyNexus.

**Recommendation:** The boundary is about code ownership and deployment, not about data flow. The external data acquisition system (scraper, crawler, adapter) can be a separate codebase/deployment that writes clean, normalised data to a shared staging area (or API endpoint). StudyNexus's responsibility starts at the staging layer: verifying, matching, and applying imported data to the canonical store. The provenance, history, and publication state remain inside StudyNexus. This is a deployment boundary, not a domain boundary. The canonical `06-data-acquisition.md` pipeline design remains valid — it just may execute in a separate service for operational reasons.

---

# 14. MVP vs Later Phases

## MVP — First Vertical Slice

**The programme discovery vertical:**

| Component | Includes |
|-----------|----------|
| **Public pages** | Home (search entry), Programme search/results, Programme detail, Institution detail, Scholarship detail (basic) |
| **Search** | Programme search with facets (state, type, ownership, qualification, discipline, admission pathway, tuition range). Institution search (basic). Global search with autocomplete. |
| **Detail pages** | Programme detail with admission requirements, cut-off marks, tuition, accreditation. Institution detail with programme list, accreditation summary, contact. |
| **Provenance** | Verification badges, source attribution, last-verified dates |
| **Admin** | Institution/Programme CRUD, publication status, data import review, information source management |
| **Data acquisition** | JAMB brochure import, NUC accreditation import, institution website crawl (initial set) |
| **SEO** | Indexable landing pages, entity detail pages, sitemaps, JSON-LD |
| **Architecture** | PostgreSQL, Eloquent, Typesense, Livewire v4, Filament v5, Redis cache |

**What the MVP validates end-to-end:**
1. Data can be acquired from external sources and imported into the canonical store
2. Imported data can be verified, de-duplicated, and published
3. Published data is indexed in Typesense with correct denormalization
4. Public search serves faceted results from Typesense
5. Detail pages render from PostgreSQL with full entity graph
6. SEO pages are indexable with correct structured data
7. Admin workflows support the content lifecycle

## Phase 2

| Feature | Rationale |
|---------|-----------|
| Comparison view | High value but not required for the product to be useful |
| Scholarship search with full faceting | Scholarship data quality may not be sufficient at launch |
| Historical cut-off display | Requires data versioning (GAP-2) |
| Eligibility assessment (WF4) | Requires structured admission rules |
| Institution-scoped admin | Institution self-management (post-MVP per A2-3) |
| User accounts | No accounts needed for core MVP (OQ4-1) |
| Saved searches / favourites | Requires user accounts |
| Community corrections (OQ4-2) | Requires user accounts and moderation |

## Later

| Feature | Rationale |
|---------|-----------|
| Examination/resource discovery | Separate content domain |
| Notifications | Stage 2 capability |
| Postgraduate-focused features | Lower priority persona need |
| Career pathways integration | Future capability |
| Public API | Stage 4 capability |
| Multi-country support | Post-Nigeria expansion |

---

# 15. Open Product Questions

| # | Question | Context | Impact |
|---|----------|---------|--------|
| PQ-1 | Should the home page default to programme search or show all three categories equally? | The home page design depends on whether programmes are the primary entry point or one of three equal entry points | Affects home page layout, navigation emphasis, default search scope |
| PQ-2 | What is the canonical discipline taxonomy for Nigerian programmes? | GAP-3 requires a structured discipline classification. There is no universally standard taxonomy for Nigerian tertiary programmes. | Affects faceted search, SEO landing pages, programme classification |
| PQ-3 | Should institution detail pages show programmes as a Typesense-served list or an Eloquent-served list? | ARCH-GAP-1: the programme list within an institution detail page could be served from either system | Affects architecture, performance, search index design |
| PQ-4 | How should tuition be presented when it varies by indigene status, level, and session? | Nigerian universities commonly charge different tuition for indigenes vs. non-indigenes of the institution's state. The search facet needs a single value; the detail page needs the full breakdown. | Affects search index denormalization, detail page design |
| PQ-5 | Should scholarship detail pages exist in the MVP or should scholarships only appear as related content on programme/institution pages? | Scholarship data is harder to acquire and may be incomplete at launch | Affects scope, data acquisition priority |
| PQ-6 | What is the minimum data completeness threshold for publishing an entity? | GAP-1: when is an institution or programme "complete enough" to show on the public site? | Affects publication workflow, content strategy |
| PQ-7 | Should the comparison feature support cross-type comparison (programme vs. institution) or only same-type? | Comparison across types (comparing a programme to its institution) is not meaningful. Comparison should probably be type-locked. | Affects comparison view design |

---

# 16. Decisions That Need Your Approval

## Decision 1: MVP Vertical Slice

```
Decision:   What is the first vertical slice to implement?
Options:
  A) Programme discovery → detail → institution → admission (recommended)
  B) Institution discovery → detail → programmes → admission
  C) All three discovery surfaces simultaneously (programme, institution, scholarship)
Recommendation: A
Why:   Programme discovery exercises the full stack, delivers the highest-value user story,
       and is the most SEO-valuable surface. Institution discovery follows naturally.
       Scholarship discovery can be deferred if data quality is insufficient.
Impact: Determines implementation order, data acquisition priorities, and what constitutes
        "launched" for the MVP.
```

## Decision 2: Discipline Taxonomy

```
Decision:   How should programmes be classified by discipline for faceted search?
Options:
  A) Hardcoded enum (Discipline enum with ~15 values: Engineering, Medicine, Law,
     Business, Sciences, Arts, Education, Agriculture, Environmental, Social Sciences,
     ICT, Architecture, Pharmacy, Veterinary, Theology)
  B) Database table with admin-managed taxonomy (discipline_categories table with
     id, name, slug, parent_id for hierarchy)
  C) Spatie tags (free-form tagging by content editors)
Recommendation: B
Why:   A discipline taxonomy needs hierarchy (Engineering → Civil Engineering) for
       drill-down, but the values change slowly enough that a database table is better
       than an enum (which requires code deployment to add values). Tags lack the
       controlled vocabulary and hierarchy needed for faceted search.
Impact: Affects programme model, search index, SEO landing pages, admin UI.
```

## Decision 3: Publication Status Model

```
Decision:   Should entities have an explicit publication status?
Options:
 & A) publication_status enum (Draft, Published, Unpublished, Archived) on
     Institution, Programme, Scholarship
  B) is_published boolean on each entity
  C) No publication status — show all "Active" entities on the public site
Recommendation: A
Why:   The product needs more than binary published/unpublished. "Draft" (never published),
       "Published" (visible), "Unpublished" (was published, now hidden), and "Archived"
       (permanently removed from public) are distinct states. This is a product concern,
       not a domain concern — it does not affect domain invariants.
Impact: Affects public queries, admin workflow, search indexing.
```

## Decision 4: Data Versioning Approach

```
Decision:   How should historical values (cut-offs, tuition, requirements) be stored?
Options:
  A) data_versions polymorphic table (versionable_type, versionable_id, attribute,
     old_value, new_value, effective_from, effective_to, source)
  B) JSON attribute_history column on each entity
  C) No versioning in MVP — only current values
Recommendation: C for MVP, A for Phase 2
Why:   Historical cut-off marks are valuable but not essential for launch. The product
       is useful with current values only. Adding versioning adds complexity to the
       data model, import pipeline, and detail page rendering. Defer to Phase 2 when
       the basic product is validated.
Impact: Affects data model, import pipeline, detail page, search index.
```

## Decision 5: Scholarship Pages in MVP

```
Decision:   Should scholarship detail pages be part of the MVP?
Options:
  A) Full scholarship search + detail pages in MVP
  B) Scholarships appear only as related content on programme/institution pages (no
     dedicated search or detail page)
  C) Basic scholarship landing page + detail pages, but without full faceted search
Recommendation: C
Why:   Scholarships are high-value content that attracts users and SEO. A basic page
       is low effort. Full faceted search can wait until the data volume and quality
       justify it. Even a simple list of scholarships with deadline and eligibility
       summary is better than no scholarship presence.
Impact: Affects data acquisition priority, search index scope, SEO surface.
```

## Decision 6: External Data Acquisition Deployment Boundary

```
Decision:   Should the scraper/crawler/adapter layer be inside/ part of the StudyNexus
            codebase or a separate service?
Options:
  A) Internal to StudyNexus (current design in 06-data-acquisition.md)
  B) Separate service/codebase that writes to StudyNexus's staging tables via API
  C) Separate service that writes to a shared staging database
Recommendation: A for MVP, B for production maturity
Why:   For the MVP, keeping everything in one codebase simplifies deployment and
       debugging. The scrapers are the only way to get data — they need to work
       reliably. Splitting into a separate service adds operational complexity
       (separate deployment, monitoring, error handling) before the pipeline is
       proven. Once stable, the acquisition layer can be extracted.
Impact: Affects deployment architecture, codebase structure, operational complexity.
```

---

# 17. Challenged Decisions

| Decision / Pattern | Verdict | Rationale |
|-------------------|---------|-----------|
| Strict Laravel Beyond CRUD forcing every concept into a class | **NEEDS REVISITING** | The product experience is search-heavy and read-optimised. Not every attribute needs a Value Object class. Not every query needs an Action. The discipline taxonomy, the publication status, the search denormalization — these are pragmatic product concerns, not domain purity concerns. Use Laravel Beyond CRUD where it genuinely protects business rules (aggregate methods, invariants). Use plain Eloquent, query scopes, and direct Typesense calls where the product experience requires it. |
| 11 entities as the canonical model | **CONFIRMED** | The UX confirms that 11 entities is correct. Only 3 need user-facing pages. The supporting entities (AdmissionPolicy, EligibilityPolicy, AdmissionCycle, Qualification, AccreditationRecord, EducationAuthority, ScholarshipProvider, InformationSource) naturally serve as content within primary pages or as admin-only concepts. |
| Admission Pathway as Value Object | **CONFIRMED** | The UX confirms this. Admission pathways appear as facet values in search (UTME, Direct Entry, IJMB, JUPEB) — they are discriminators, not entities. No user ever navigates to an "Admission Pathway detail page." |
| Typesense for search | **CONFIRMED** | The product experience is fundamentally search-first. Typesense's typo tolerance, faceting, and ranking are essential. Eloquent faceted search would be both slow and complex. |
| No user accounts in MVP | **STILL VALID BUT NEEDS UX DETAIL** | The product works without accounts for search/compare. However, the comparison feature (adding items to compare) requires session state. Without accounts, comparison must be cookie/session-based. This limits comparison to a single device/session. This is acceptable for MVP but needs to be made explicit. |
| Laravel monolith / modular monolith | **CONFIRMED** | The product experience does not require microservices. A monolith with clear domain boundaries is appropriate. |
| Examination/resource discovery in MVP | **CONTRADICTED BY PRODUCT REQUIREMENT** | The product requirement analysis shows this is a separate content domain that does not exercise the core architecture and has distinct data challenges. It is correctly excluded from MVP. |

---

# 18. Recommended Next Step

**Upon your approval of the decisions above:**

1. **Create a single canonical `07-product-experience.md`** document that captures the approved product experience decisions (primary journeys, information architecture, core views, search model, detail page hierarchy, MVP scope). This document becomes part of the canonical documentation set alongside 01–06.

2. **Update the 6 existing canonical documents** where the product experience requires changes:
   - `03-domain.md`: Add discipline classification to Programme; add publication_status to entities
   - `04-architecture.md`: Make explicit that Typesense is the primary read path for discovery surfaces
   - `05-implementation.md`: Add the publication status columns, discipline taxonomy table, and search denormalization strategy
   - `06-data-acquisition.md`: Clarify the deployment boundary decision

3. **Do NOT start implementation yet.** The next step after documentation update is to define the implementation plan (phase breakdown, sprint planning, technical proof-of-concept order).

---

*Product Experience Discovery complete. Awaiting human approval before any canonical documents are modified or implementation begins.*
