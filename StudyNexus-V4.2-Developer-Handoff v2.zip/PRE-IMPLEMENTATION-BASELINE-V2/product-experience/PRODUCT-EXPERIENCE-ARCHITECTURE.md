# StudyNexus — Product Experience Architecture

**Date:** 2026-08-10
**Status:** UX DISCOVERY — awaiting human approval
**Authoritative baseline:** 6 canonical documents (01–06) + PRODUCT-EXPERIENCE-DISCOVERY.md + PRODUCT-DISCOVERY-CHALLENGE.md + DISCOVERY-CLOSURE.md
**Constraint:** No canonical documents modified. No implementation code produced. No UI designs created.

---

# 1. Product Experience Map

StudyNexus is a search-first, information-rich, trust-grounded education discovery platform. The product does not execute transactions or process applications. Every experience exists to move a user from **question** to **informed decision**.

## 1.1 Top-Level Experience Domains

```text
┌─────────────────────────────────────────────────────────┐
│                    StudyNexus Product                    │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  DISCOVERY   │  │  EVALUATION  │  │   TRUST &    │  │
│  │              │  │              │  │  PROVENANCE  │  │
│  │ Search       │  │ Compare      │  │              │  │
│  │ Browse       │  │ Inspect      │  │ Source       │  │
│  │ Filter       │  │ Understand   │  │ Freshness    │  │
│  │ Navigate     │  │ Decide       │  │ Verification │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
│         │                  │                  │          │
│         └──────────────────┴──────────────────┘          │
│                           │                              │
│                    INFORMED DECISION                     │
└─────────────────────────────────────────────────────────┘
```

## 1.2 Experience Flow Model

```text
User has a question about education
        ↓
Entry point (Google, direct, referral)
        ↓
Discovery (search / browse / filter)
        ↓
Identify candidate opportunities
        ↓
Evaluate (detail page → understand specifics)
        ↓
Cross-reference (related programme, institution, admission, scholarship)
        ↓
Compare (side-by-side where needed)
        ↓
Assess trust (source, freshness, verification)
        ↓
Informed decision or continue exploring
```

This is not a linear funnel. Users enter at any point, loop back, branch, and exit when their question is answered. The product must support:

- **Direct entry** (SEO → detail page → explore related)
- **Exploratory entry** (homepage → browse → filter → evaluate)
- **Targeted entry** (search → results → evaluate)
- **Cross-domain jumps** (programme → institution → other programmes at that institution)

---

# 2. User Types

## 2.1 Primary Users (MVP)

### Prospective Student (SS3 / Secondary School Graduate)

| Dimension | Description |
|-----------|-------------|
| **Primary goal** | Find programmes they qualify for, understand admission requirements, identify institutions to consider |
| **Key tasks** | Search programmes by discipline/interest; check cut-off marks against their scores; find currently admitting programmes; understand tuition costs; discover institutions near a location |
| **Information needs** | Programme name, discipline, award level, admission status, cut-off marks, tuition, institution name/type/location, admission requirements |
| **Decisions** | Which programmes to consider; which institutions to research further; whether their scores meet cut-offs; whether tuition is affordable |
| **Frustrations** | Fragmented information across JAMB, institution sites, blogs; outdated cut-off marks; uncertain admission status; can't compare side-by-side |
| **Likely entry** | Google search ("computer science cut off mark UNILAG 2026"); discipline-based discovery; location-based browse |
| **Mobile behavior** | Primary device. Low data tolerance. Needs fast answers. Will scroll long pages but won't navigate deep hierarchies |

### Undergraduate Student

| Dimension | Description |
|-----------|-------------|
| **Primary goal** | Find scholarships, transfer/postgraduate opportunities, or verify current programme information |
| **Key tasks** | Search scholarships by eligibility; explore postgraduate programmes; check information about their current institution |
| **Information needs** | Scholarship eligibility criteria, deadlines, coverage; postgraduate programme requirements; current institution accreditation status |
| **Decisions** | Whether to apply for a scholarship; whether to consider transfer/postgraduate; whether current information is reliable |
| **Frustrations** | Scholarship information is scattered and deadlines are missed; postgraduate options are hard to discover |
| **Likely entry** | Scholarship search; institution detail (their own); programme detail (advanced search) |
| **Mobile behavior** | Mixed mobile/desktop. More patient with complex information. Will bookmark and return |

### Parent / Guardian

| Dimension | Description |
|-----------|-------------|
| **Primary goal** | Help their child choose wisely — safety, cost, and quality matter more than for the student |
| **Key tasks** | Compare institutions by cost and location; verify accreditation; understand admission timelines; find affordable options |
| **Information needs** | Tuition comparison, institution type/ownership, accreditation status, location, admission deadlines |
| **Decisions** | Which institutions are affordable and reputable; whether accreditation is current; admission timeline alignment |
| **Frustrations** | Cannot easily compare costs across institutions; unsure which information is trustworthy; institutional websites are unhelpful |
| **Likely entry** | Google search; referral from child/teacher; cost-focused comparison |
| **Mobile behavior** | Mixed. More likely to share links. More likely to spend longer evaluating |

### Guidance Counsellor / Teacher

| Dimension | Description |
|-----------|-------------|
| **Primary goal** | Provide accurate, current information to multiple students with different interests and qualifications |
| **Key tasks** | Look up programmes across disciplines; verify admission information; find options for students with specific score ranges |
| **Information needs** | Broad coverage across disciplines; current admission status; cut-off mark ranges; institution accreditation |
| **Decisions** | Which programmes to recommend to specific students; whether information is current enough to rely on |
| **Frustrations** | Information goes stale quickly; hard to keep track of admission cycle changes; need to re-verify every year |
| **Likely entry** | Direct search; discipline browse; programme comparison |
| **Mobile behavior** | Likely desktop at school. Mobile for quick lookups. Will print or share results |

## 2.2 Administrative Users (MVP)

| User Type | Primary Goal | Key Tasks |
|-----------|-------------|-----------|
| **Content Admin** | Ensure data quality and completeness | Review imported data; publish/unpublish entities; correct errors; manage reference data |
| **Content Editor** | Maintain and enrich content | Edit programme/institution descriptions; add missing information; manage content |
| **Platform Admin** | System integrity | Full access; manage users; configure system; inspect provenance; resolve conflicts |

## 2.3 Future Users (Post-MVP)

| User Type | Relevance |
|-----------|-----------|
| **Institution Representative** | Post-MVP: manage their institution's data. Currently, content admins handle this |
| **Scholarship Provider** | Post-MVP: publish and manage scholarships. Currently, content admins handle this |
| **Education Agency** | Strategic data partner, not a UI user in MVP |

---

# 3. User Goals

## 3.1 Goal Hierarchy

```text
GOAL: Make an informed education decision
  │
  ├── GOAL: Discover what options exist
  │     ├── Find programmes in a discipline I care about
  │     ├── Find institutions near me
  │     ├── Find programmes I qualify for
  │     └── Discover options I didn't know about
  │
  ├── GOAL: Evaluate specific options
  │     ├── Understand admission requirements
  │     ├── Check if I meet cut-off marks
  │     ├── Understand tuition costs
  │     ├── Verify accreditation
  │     └── Assess information reliability
  │
  ├── GOAL: Compare options
  │     ├── Compare programmes across institutions
  │     ├── Compare institutions by key criteria
  │     └── Compare costs
  │
  └── GOAL: Take next action
        ├── Apply to institution (external — not in StudyNexus)
        ├── Seek more information (visit institution site)
        └── Save/remember for later (post-MVP)
```

## 3.2 Goal Priority for MVP

| Priority | Goal | Personas | MVP? |
|:--------:|------|----------|:----:|
| P0 | Find programmes in a discipline | All primary | ✓ |
| P0 | Understand admission requirements and cut-offs | Prospective student, parent | ✓ |
| P0 | Determine if admission is currently open | Prospective student, parent | ✓ |
| P0 | Find which institution offers a programme | All primary | ✓ |
| P0 | Understand tuition costs | Parent, prospective student | ✓ |
| P1 | Compare programmes/institutions | All primary | ✓ (lightweight) |
| P1 | Verify accreditation and trust | Parent, counsellor | ✓ |
| P1 | Find institutions by location | All primary | ✓ |
| P1 | Discover scholarships | Undergraduate, prospective | ✓ (limited) |
| P2 | Compare side-by-side | Parent, counsellor | Post-MVP enhancement |
| P2 | Save/follow/shortlist | All primary | Post-MVP (Stage 2) |
| P2 | Get notifications | All primary | Post-MVP (Stage 2) |

---

# 4. Decision Models

## 4.1 Programme Discovery Decision Model

```text
"I want to study [discipline/field]."
        ↓
QUESTION: "What programmes exist in this field?"
        ↓
INFORMATION NEEDED:
  - Programme names and award levels
  - Which institutions offer them
  - Whether admission is currently open
  - Discipline classification
        ↓
DECISION: "Which programmes should I evaluate further?"
        ↓
ACTION: Navigate to programme detail
```

**Entry points:** Homepage search; Google search for discipline; discipline landing page; programme listing with discipline filter.

**Critical UX factor:** The user often does not know the exact programme name. They know their interest ("I like computers") or their qualification path ("I wrote JAMB for engineering"). The discovery experience must bridge from vague intent to specific programmes.

## 4.2 Programme Evaluation Decision Model

```text
"This programme looks interesting."
        ↓
QUESTION: "Can I get admitted? What does it require?"
        ↓
INFORMATION NEEDED:
  - Admission requirements (subjects, qualifications)
  - Cut-off marks (current and recent historical)
  - Current admission status (admitting / suspended / not yet)
  - Admission cycle timing
  - Tuition cost
  - Programme duration and delivery mode
        ↓
DECISION: "Do I meet the requirements? Should I consider this?"
        ↓
ACTION: Evaluate the institution / compare with alternatives / check scholarships
```

**Critical UX factor:** Cut-off marks are the single most requested piece of information. A programme page without cut-off information fails the user's primary question. Historical cut-offs are important because current-year cut-offs may not yet be available.

## 4.3 Institution Evaluation Decision Model

```text
"This programme is at this institution."
        ↓
QUESTION: "Is this institution reputable? What else do they offer?"
        ↓
INFORMATION NEEDED:
  - Institution type and ownership
  - Accreditation status (current)
  - Location
  - Other programmes offered (especially admitting ones)
  - Tuition for this and related programmes
        ↓
DECISION: "Is this institution worth considering? Should I look at alternatives?"
        ↓
ACTION: Browse other programmes at this institution / compare institutions
```

**Critical UX factor:** The institution page answers "can I trust this place?" and "what are my alternatives here?" It is reached primarily from a programme page, not independently.

## 4.4 Scholarship Discovery Decision Model

```text
"I need financial support for my education."
        ↓
QUESTION: "What scholarships are available for my situation?"
        ↓
INFORMATION NEEDED:
  - Scholarship name and provider
  - Eligibility criteria
  - Coverage (full/partial/tuition-only)
  - Application deadline and status
  - Target programmes/institutions
        ↓
DECISION: "Should I apply? Am I eligible?"
        ↓
ACTION: Visit provider site to apply (external)
```

**MVP scope:** Scholarship information appears as contextual data on programme/institution pages. Dedicated scholarship search and discovery is Phase 2. The MVP shows scholarships related to the programme or institution the user is viewing, not a standalone scholarship search experience.

## 4.5 Admission Evaluation Decision Model

```text
"I have my exam scores. Can I get in?"
        ↓
QUESTION: "Is my score high enough? What are the requirements?"
        ↓
INFORMATION NEEDED:
  - Cut-off marks for this programme (current and historical)
  - Subject requirements
  - Qualification requirements (JAMB, WAEC, post-UTME)
  - Admission pathway (UTME, direct entry, etc.)
  - Whether admission is currently open
        ↓
DECISION: "Should I apply? Do I need a different pathway?"
        ↓
ACTION: Apply (external) / explore alternative pathways
```

**Critical UX factor:** This is where StudyNexus delivers its most distinct value. No existing source presents cut-off marks, admission requirements, and admission status together in a verified, structured format. The admission evaluation experience must be the strongest part of the product.

## 4.6 Location-Based Discovery Decision Model

```text
"I want to study in [city/state]."
        ↓
QUESTION: "What institutions and programmes are available there?"
        ↓
INFORMATION NEEDED:
  - Institutions in the location
  - Programmes at those institutions
  - Institution types and admission status
        ↓
DECISION: "Which institutions in this area should I consider?"
        ↓
ACTION: Evaluate specific institutions/programmes
```

**Critical UX factor:** Location is a filter, not a separate experience. Nigerian students often consider institutions in specific states (home state, nearby states). The location filter should support state-level and city-level filtering.

---

# 5. Core Journeys

## 5.1 Journey 1: Discipline-First Discovery (Primary Journey)

```text
Homepage
  → Types in "Computer Science" or selects "Engineering" discipline
  → Faceted programme results (filtered by discipline)
  → Applies filters: award level, location, admission status
  → Selects a programme
  → Programme detail: requirements, cut-off, tuition, admission status
  → Scrolls to institution section
  → Institution detail: accreditation, other programmes, location
  → May return to results to evaluate another programme
```

**This is the most common journey.** Users know their field of interest before they know specific programme names. The discipline filter is the primary organizing principle.

**Backend exercised:** Typesense (search + faceting), PostgreSQL (detail pages), Discipline reference table, Programme-Institution relationship, ProgrammeInstance (admission boundary), CutOffMark history (scoped to ProgrammeInstance), AdmissionPolicy (owned by ProgrammeInstance).

## 5.2 Journey 2: Institution-First Discovery

```text
Homepage
  → Searches for "University of Lagos" or filters by institution type/location
  → Institution detail page
  → Browses programmes at this institution
  → Selects a programme
  → Programme detail
```

**This journey is for users who already have an institution in mind** (often from family, teachers, or reputation). They want to see what the institution offers.

**Backend exercised:** Typesense (institution search), PostgreSQL (institution detail + programme list), Eloquent eager loading.

## 5.3 Journey 3: SEO Direct Entry

```text
Google search "UNILAG computer science cut off mark 2026"
  → Lands on programme detail page
  → Sees cut-off, admission status, requirements
  → Navigates to institution or related programmes
  → May search for alternatives
```

**This is the highest-value entry point** because it captures users with specific, high-intent queries. The programme detail page must be self-sufficient — it must answer the user's question without requiring navigation elsewhere.

**Backend exercised:** PostgreSQL (detail page), SEO (canonical URL, structured data, breadcrumbs).

## 5.4 Journey 4: Admission Status Check

```text
User wants to know if a specific programme is admitting
  → Searches or navigates to programme
  → Sees admission status badge and cycle information
  → If admitting: reviews requirements and cut-offs
  → If not admitting: sees when next cycle opens (if known) or related alternatives
```

**Backend exercised:** Admission cycle state, ProgrammeStatus enum, derived `isAdmitting` query, ProgrammeInstance (admission owner), AdmissionPolicy (polymorphic on ProgrammeInstance).

## 5.5 Journey 5: Scholarship Contextual Discovery

```text
User is on programme detail page
  → Sees "Related scholarships" section
  → Reviews scholarship name, coverage, deadline
  → If interested, navigates to scholarship detail
```

**MVP scope:** Scholarships appear as contextual information on programme and institution pages. Dedicated scholarship search is Phase 2.

**Backend exercised:** Scholarship entity, Programme-Scholarship targeting relationship, ScholarshipStatus lifecycle.

---

# 6. Cross-Domain Experiences

## 6.1 Programme + Institution + Admission

This is the core cross-domain experience. A programme cannot be meaningfully evaluated without understanding which institution offers it and what admission requirements apply.

```text
Programme detail page
  ├── Institution summary (name, type, location, accreditation)
  ├── Admission information (requirements, cut-offs, status, cycle)
  └── Related scholarships (if any target this programme)
```

**Product implication:** Programme detail must eager-load institution, programme instances, and each instance's admission policies and cut-off marks. The data flow is Programme → ProgrammeInstance → AdmissionPolicy / CutOffMark (not Programme → AdmissionPolicy / CutOffMark directly). This is already the canonical architecture (PostgreSQL/Eloquent serves detail pages with full entity graph). No new domain relationships needed.

## 6.2 Programme + Discipline + Location

Users discover programmes through discipline (the primary facet) and then narrow by location. This is a filter composition, not a new domain relationship.

```text
Discipline: "Engineering"
  + Location: "Lagos"
  → Programmes in Engineering discipline at institutions in Lagos
```

**Product implication:** Discipline is a FK on Programme. Location is on Institution. Typesense must project both discipline (from Programme) and location (from Institution) as facets on the programme search document. This is already the canonical design (denormalized parent attributes on child documents).

## 6.3 Institution + Programme + Admission Cycle

When viewing an institution, users need to see which programmes are currently admitting. This requires knowing both the programme's status and the current admission cycle state.

```text
Institution detail
  ├── Programme listing
  │     └── Per programme: admission status badge
  └── Active admission cycles
```

**Product implication:** The derived `isAdmitting` query already exists in canonical architecture. Typesense projects `is_admission_open` on programme documents. No new domain logic needed.

## 6.4 Programme + Scholarship

Scholarships target programmes and/or institutions. On a programme detail page, showing related scholarships is a query, not a domain relationship change.

**Product implication:** Scholarship targeting uses a pivot table (`scholarship_programme`, `scholarship_institution`). Querying scholarships for a programme is an Eloquent query, not a new domain concept. This is already canonical.

## 6.5 Exam + Programme + Admission (Future)

Examination bodies (JAMB, WAEC) define qualifications used in admission requirements. The connection is through Qualification references in Admission Rules, not through a direct Exam-to-Programme relationship.

**Product implication:** This is already modeled. AdmissionRule VO contains QualificationThreshold VO, which references Qualification entities. No new relationships needed. Dedicated exam/resource pages are future scope.

---

# 7. Product-Wide Discovery Model

## 7.1 Recommendation: Contextual Hybrid Search

StudyNexus should NOT implement a single universal search bar that searches everything simultaneously. Education discovery has fundamentally different modes:

| Mode | When | Behavior |
|------|------|----------|
| **Programme search** | User's primary intent is to find a programme | Typesense `programmes` collection; discipline, institution, location, award level facets |
| **Institution search** | User's primary intent is to find an institution | Typesense `institutions` collection; type, location, ownership facets |
| **Global search (autocomplete)** | User types in the homepage search box | Searches programmes AND institutions; returns top results from each; user clicks to enter the appropriate context |
| **Scholarship search** | Phase 2 | Typesense `scholarships` collection; eligibility, coverage, deadline facets |

## 7.2 Homepage Search Experience

The homepage search box is the primary entry point for targeted queries. It should:

1. **Accept any text** — programme names, institution names, discipline names, abbreviations, common misspellings
2. **Autocomplete with categories** — show matching programmes and matching institutions in separate groups
3. **On submit** — if the query clearly matches one type, go to that filtered results page; if ambiguous, show programme results (the primary experience) with an option to switch to institutions

## 7.3 Structured Discovery

Alongside search, the homepage provides structured entry points:

- **Discipline browse** — "Explore by field of study" → grid/list of disciplines → programme results
- **Institution type browse** — "Universities" / "Polytechnics" / "Colleges of Education" → institution results
- **Location browse** — "Explore by state" → institution results filtered by state

These serve users who do not have a specific query but want to explore.

**UX hypothesis:** Most first-time users will enter via search (SEO or on-site), not via structured browse. Structured browse serves returning users and explorers.

---

# 8. Information Architecture

## 8.1 Primary Navigation

```text
StudyNexus
 ├── Programmes        ← Primary discovery path
 ├── Institutions      ← Secondary discovery path
 └── [Scholarships]    ← Phase 2
```

The navigation reflects the two primary discovery paths. Everything else is reached through cross-links, search, or SEO entry.

## 8.2 Discovery Paths

```text
Home
 ├── Search (any query → programme results by default)
 ├── Browse by Discipline → /programmes?discipline={slug}
 ├── Browse by Institution Type → /institutions?type={type}
 └── Browse by Location → /institutions?state={state}

Programmes
 ├── Faceted search/listing → /programmes
 ├── Discipline landing → /programmes?discipline={slug}
 └── Programme detail → /institutions/{inst}/programmes/{prog}

Institutions
 ├── Faceted search/listing → /institutions
 └── Institution detail → /institutions/{inst}
```

## 8.3 Detail Experiences

```text
Programme Detail (/institutions/{inst}/programmes/{prog})
 ├── What is this programme? (name, discipline, award level, duration, delivery mode)
 ├── Can I get admitted? (status, requirements, cut-offs, cycle)
 ├── How much does it cost? (tuition)
 ├── Which institution offers it? (institution summary with link)
 ├── Are there scholarships? (related scholarships)
 └── What else might interest me? (related programmes at same institution, same discipline at other institutions)

Institution Detail (/institutions/{inst})
 ├── What is this institution? (name, type, ownership, location)
 ├── Is it accredited? (accreditation records)
 ├── What programmes does it offer? (programme listing with admission status)
 ├── Which programmes are currently admitting? (filtered programme list)
 └── Are there scholarships? (related scholarships)
```

## 8.4 Cross-Links

```text
Programme ←→ Institution (always bidirectional)
Programme ←→ Discipline (programme to discipline landing page)
Programme ←→ Related Programmes (same discipline, same institution, or same award level)
Institution ←→ Programmes (always bidirectional)
Programme ←→ Scholarships (programme page shows related scholarships)
Institution ←→ Scholarships (institution page shows related scholarships)
```

## 8.5 SEO Entry Points

```text
/programmes?discipline=computer-science     ← Discipline landing page
/institutions/university-of-lagas           ← Institution detail
/institutions/unilag/programmes/cs-bsc      ← Programme detail (highest value)
/institutions?state=lagos                   ← Location-filtered institutions
/institutions?type=university               ← Type-filtered institutions
```

---

# 9. Search UX

## 9.1 Programme Search

### Search Entry

A prominent search box on the homepage and the `/programmes` page. Placeholder text: "Search programmes — e.g., Computer Science, Medicine, Engineering"

### Query Types Supported

| Query Type | Example | Handling |
|-----------|---------|----------|
| Programme name | "Computer Science" | Typesense full-text search with typo tolerance |
| Institution name | "UNILAG" | Typesense search across institution_name field on programme documents |
| Discipline | "Engineering" | Discipline facet selection or text match |
| Abbreviation | "CS", "MBA" | Typesense typo tolerance + abbreviation handling |
| Misspelling | "compter sciense" | Typesense typo tolerance (configured per collection) |
| Location | "Lagos" | Filter by institution state/city |
| Award level | "BSc", "HND" | Award level facet |

### Result Card Data

Each result card in programme search shows:

```text
┌─────────────────────────────────────────────┐
│ Computer Science (BSc)              [Admitting] │
│ University of Lagos · University · Lagos     │
│ Duration: 4 years · Mode: On-Campus          │
│ Cut-off: 200 (2025) · Tuition: ₦150,000/yr  │
└─────────────────────────────────────────────┘
```

This is a **UX hypothesis**: the specific fields shown on the result card. The principle is: show enough to evaluate, not so much that the card is cluttered. Cut-off and tuition are shown because they are the two most decision-relevant data points.

## 9.2 Institution Search

### Result Card Data

```text
┌─────────────────────────────────────────────┐
│ University of Lagos                 [Operational] │
│ University · Public · Lagos, Lagos State     │
│ Programmes: 87 · Accredited: NUC (Full)     │
└─────────────────────────────────────────────┘
```

## 9.3 Autocomplete

The homepage search provides autocomplete that returns grouped results:

```text
Programmes
  Computer Science (BSc) — University of Lagos
  Computer Engineering (BSc) — University of Ibadan

Institutions
  University of Lagos
  Lagos State University
```

This is served by Typesense's multi-search capability across the `programmes` and `institutions` collections.

---

# 10. Faceted Search Experience

## 10.1 Programme Facets

| Facet | User question | Decision it supports | Priority |
| ----- | ------------- | -------------------- | -------- |
| **Discipline** | "What field?" | Primary organizing principle | P0 |
| **Award level** | "What qualification?" | Undergraduate vs postgraduate vs diploma | P0 |
| **Institution type** | "University or polytechnic?" | Institution category preference | P0 |
| **Location (state)** | "Where?" | Geographic preference | P0 |
| **Admission status** | "Can I apply now?" | Immediacy of opportunity | P1 |
| **Ownership type** | "Public or private?" | Cost/quality preference | P1 |
| **Delivery mode** | "On-campus or online?" | Learning mode preference | P2 |
| **Tuition range** | "Can I afford it?" | Budget constraint | P2 |

**Discipline, award level, institution type, and location** are the four essential facets. They address the four most common filtering questions. Admission status is important but derived (not stored directly — computed from programme status + admission cycle state), so its facet behavior needs special handling in Typesense (pre-computed `is_admission_open` boolean).

## 10.2 Institution Facets

| Facet | User question | Decision it supports | Priority |
| ----- | ------------- | -------------------- | -------- |
| **Institution type** | "University, polytechnic, college?" | Category preference | P0 |
| **Location (state)** | "Where?" | Geographic preference | P0 |
| **Ownership type** | "Public or private?" | Cost/quality preference | P1 |

Institution facets are simpler because institutions are coarser entities.

## 10.3 Facet Interaction Behavior

### Desktop

- Left sidebar with all facets always visible
- Facet values show counts (from Typesense facet counts)
- Selecting a facet value immediately updates results (Livewire, no full reload)
- Active filters shown as chips above results
- "Clear all" to reset

### Mobile

- Filter button triggers a bottom sheet/drawer
- Facets in the drawer are accordion-style (collapsed by default)
- "Apply filters" button at bottom of drawer
- Active filter chips shown above results (horizontal scroll)
- Result count updates in real-time as filters are selected

### Zero Results

- Show "No programmes match your filters"
- Suggest removing the most restrictive filter
- Show alternative searches with relaxed filters
- Never show an empty page with no guidance

### Sorting

| Sort Option | Use Case |
|------------|----------|
| Relevance (default) | Text search active — Typesense relevance |
| Programme name A-Z | Browsing without search query |
| Cut-off mark (low to high) | Finding programmes with accessible cut-offs |
| Cut-off mark (high to low) | Finding competitive programmes |
| Tuition (low to high) | Budget-constrained users |

---

# 11. Programme Detail Experience

## 11.1 Information Hierarchy

The programme detail page is organized around the user's primary question: **"Can I get admitted to this programme?"**

### Above the Fold (Critical)

```text
Programme Name                    [Admitting] badge
Award Level · Duration · Delivery Mode
Institution Name (link) · Type · Location
```

### Primary Section: Admission Information

Admission is owned by **ProgrammeInstance**, not Programme directly. A Programme may have multiple instances (e.g., On-campus vs Online) each with distinct admission requirements and cut-off marks. The data flow is Programme → ProgrammeInstance → AdmissionPolicy / CutOffMark.

```text
Admission (per ProgrammeInstance)
  ├── Instance: On-campus
  ├── Status: Currently admitting
  ├── Cut-off mark: 200 (2025/2026 cycle)
  │     └── Previous: 190 (2024/2025) · 185 (2023/2024)
  ├── Requirements:
  │     ├── JAMB: English, Mathematics, Physics, Chemistry
  │     ├── Post-UTME: Required
  │     └── Minimum subjects: 5 O-level credits including English, Maths
  └── Admission cycle: 2026/2027 — Registration open until 2026-05-15
```

### Secondary Sections

```text
Programme Information
  ├── Description (if available)
  ├── Discipline: Engineering
  └── Delivery mode: On-campus

Tuition
  ├── Tuition: ₦150,000 per year
  └── Source: Institution website · Updated: 2026-03-15

Institution
  ├── University of Lagos (link to institution page)
  ├── Type: Federal University
  ├── Location: Akoka, Lagos
  └── Accreditation: NUC — Full (valid until 2028)

Related Scholarships (if any)
  ├── PTDF Scholarship — Full coverage · Deadline: 2026-04-30
  └── MTN Foundation — Partial · Deadline: 2026-05-15

Related Programmes
  ├── At this institution: Computer Engineering, Electrical Engineering
  └── Same discipline elsewhere: Computer Science at UNIBEN, OAU
```

### Provenance Footer

```text
Last updated: 2026-07-20
Primary source: JAMB Official Brochure 2026
Report incorrect information → [link]
```

## 11.2 Incomplete Data Handling

When a programme has missing information:

| Missing Field | Behavior |
|---------------|----------|
| Cut-off mark | Show "Cut-off mark not available" with last known historical value if exists |
| Tuition | Show "Tuition information not available" — do NOT show ₦0 |
| Requirements | Show "Admission requirements not yet published" |
| Description | Omit section entirely — no "No description" placeholder |
| Accreditation | Show "Accreditation status not verified" |

**Publication rule:** A programme can be published even with incomplete data, because a programme name + institution + discipline + award level provides value even without cut-offs or tuition. The user can see that information is missing and decide to seek it elsewhere.

## 11.3 Discontinued / Suspended Programme

- **Discontinued:** Page renders with a clear notice "This programme has been discontinued and is no longer offered." Historical information (previous cut-offs, previous requirements) remains visible. The page is not indexed in search but remains accessible via direct URL (for SEO/history).
- **Suspended admission:** Page renders normally with a badge "Admission currently suspended" instead of "Admitting". Cut-offs and requirements remain visible. The programme still appears in search results (it still exists, just not admitting).

---

# 12. Institution Detail Experience

## 12.1 Information Hierarchy

Users reach the institution page primarily from a programme page. Their questions are: "What is this place?" and "What else do they offer?"

### Above the Fold

```text
Institution Name                        [Operational] badge
Type · Ownership · Location
```

### Primary Section: Accreditation

```text
Accreditation
  ├── NUC: Full accreditation (valid until 2028)
  └── Source: NUC accreditation list · Verified: 2026-01-10
```

### Programme Listing

```text
Programmes (87)
  Filter by: [All] [Admitting] [Award Level ▼] [Discipline ▼]

  Computer Science (BSc)           [Admitting]   Cut-off: 200
  Computer Engineering (BSc)       [Admitting]   Cut-off: 195
  Medicine (MBBS)                  [Admitting]   Cut-off: 280
  ...
```

The programme list within an institution is served from Eloquent (scoped to one institution with eager loading), not Typesense. This is canonical architecture.

### Secondary Sections

```text
Institution Information
  ├── Year established
  ├── Website (external link)
  └── Contact information

Related Scholarships (if any)

Location
  └── Full address · State · LGA (if available)
```

## 12.2 Closed / Suspended Institution

- **Closed:** Page renders with notice "This institution has been closed." Historical programme and accreditation information remains visible. Not indexed in search. Accessible via direct URL.
- **Suspended:** Page renders with badge "Operations currently suspended." Programme listing still visible but all programmes show "Admission suspended." Appears in search with the suspended badge.

---

# 13. Admission Information Experience

## 13.1 Priority Order

| Priority | Information | Visibility |
|:--------:|------------|------------|
| 1 | Current admission status (admitting / suspended / not yet open) | Above fold, as badge |
| 2 | Current cut-off mark | Above fold, in admission section |
| 3 | Admission requirements (subjects, qualifications) | Admission section, primary |
| 4 | Historical cut-off marks | Expandable, under current cut-off |
| 5 | Admission cycle dates | Admission section, secondary |
| 6 | Admission pathway (UTME, Direct Entry, etc.) | Within requirements |

## 13.2 Cut-Off Mark Display

```text
Cut-off mark
  2025/2026: 200    ← Current (highlighted)
  2024/2025: 190    ← Historical
  2023/2024: 185    ← Historical
```

Historical cut-offs are **always shown** when available because:

1. Current-year cut-offs may not be published yet
2. Historical cut-offs indicate trend and competitiveness
3. Students use historical cut-offs as targets for exam preparation

**Backend implication:** `cut_off_marks` table (programme_instance_id, admission_cycle_id, pathway, value, source_id). One row per ProgrammeInstance per admission cycle per pathway. Already canonical per DISCOVERY-CLOSURE.md T-03.

## 13.3 Admission Status Derivation

Admission status is **derived**, not stored directly. The displayed status comes from:

| Condition | Display |
|-----------|---------|
| `ProgrammeStatus::Admitting` + active cycle + policy exists | "Currently admitting" (green) |
| `ProgrammeStatus::Prospective` | "Not yet admitting" (yellow) |
| `ProgrammeStatus::Suspended` | "Admission suspended" (orange) |
| `ProgrammeStatus::Discontinued` | "Discontinued" (red) |
| No active admission cycle | "Admission cycle not announced" |

This derivation uses the existing `isAdmitting` query from canonical architecture.

## 13.4 Incomplete Admission Information

| Missing | Display |
|---------|---------|
| No cut-off for current year | Show most recent historical + "Current year cut-off not yet published" |
| No cut-off marks at all | "Cut-off information not available" |
| No admission policy | "Admission requirements not yet published" |
| No admission cycle | "Admission cycle information not available" |

---

# 14. Trust & Provenance Experience

## 14.1 Trust Communication Principles

StudyNexus does NOT implement a trust score or trust badge system. Trust is communicated through **transparency**: showing where information came from and when it was last verified.

## 14.2 Provenance Display

| Element | Where Shown | Format |
|---------|------------|--------|
| Source attribution | Every data section footer | "Source: JAMB Official Brochure · Acquired: 2026-01-15" |
| Last verified date | Programme/Institution page footer | "Last verified: 2026-03-20" |
| Verification status | Not shown to public | Internal only — affects whether data is published |
| Data freshness indicator | Stale data warning | "This information was last updated 6 months ago — verify with the institution" |

## 14.3 Freshness Categories

| Freshness | Threshold | UX Response |
|-----------|-----------|-------------|
| Fresh | Updated within 90 days | No indicator needed |
| Aging | Updated 90–180 days ago | Small "Last updated X months ago" note |
| Stale | Updated 180+ days ago | Prominent "Information may be outdated — verify with institution" warning |

**UX hypothesis:** Showing a staleness warning is sufficient for trust communication. Users who care about freshness will see the warning and verify. Users who don't care won't be distracted.

**Backend implication:** The `provenance.last_verified_at` timestamp already exists on every entity (via HasProvenance trait on content models, and provenance JSON on domain entities). Computing freshness is a presentation concern, not a domain change.

## 14.4 Conflicting Information

When two sources disagree, the canonical architecture resolves this through the verification engine (official sources win; conflicts flagged for admin review). The public experience never shows conflicting data — it shows the **resolved** canonical value. The provenance metadata indicates the authoritative source.

If a user reports conflicting information, it enters the information-quality workflow (business capability #10) and does not modify canonical data directly.

---

# 15. Lifecycle & Publication Experience

## 15.1 Domain Lifecycle → Public UX Mapping

| Domain State | Search Inclusion | Detail Page | Badge | Historical Info |
|-------------|:---------------:|:-----------:|:-----:|:--------------:|
| **Programme: Admitting** | ✓ | Full | "Admitting" (green) | ✓ |
| **Programme: Prospective** | ✓ | Full | "Not yet admitting" (yellow) | ✓ |
| **Programme: Suspended** | ✓ | Full | "Admission suspended" (orange) | ✓ |
| **Programme: Discontinued** | ✗ | Notice + historical | "Discontinued" (red) | ✓ (visible) |
| **Institution: Operational** | ✓ | Full | "Operational" (green) | ✓ |
| **Institution: Provisional** | ✓ | Full | "Provisional" (yellow) | ✓ |
| **Institution: Suspended** | ✓ | Limited | "Suspended" (orange) | ✓ |
| **Institution: Closed** | ✗ | Notice + historical | "Closed" (red) | ✓ (visible) |

## 15.2 Publication Logic

Publication (`is_published`) is orthogonal to lifecycle. An entity must be **both** published AND in a publicly-displayable lifecycle state to appear in public search.

```text
is_published = true
AND status NOT IN (Discontinued, Closed)
AND status NOT IN (ScholarshipStatus::Withdrawn, ScholarshipStatus::Expired)
    → Publicly visible
```

Unpublished entities are never publicly visible, regardless of lifecycle state. This is canonical architecture.

## 15.3 Discontinued/Closed Pages

Discontinued programmes and closed institutions are removed from search but their detail pages remain accessible at their canonical URLs. This is important for:

- **SEO:** 404s on previously-indexed pages damage site authority. A notice page preserves the URL.
- **Historical reference:** Users who bookmarked or shared the link still get value.
- **Trust:** Showing that a programme was discontinued is more honest than making it disappear.

> **Cross-reference:** The canonical architecture (04-architecture.md §5.5) now separates **search visibility** (excludes Discontinued/Closed from the Typesense index) from **URL accessibility** (detail pages remain accessible at canonical URLs). This product-experience specification is consistent with and derives from that canonical visibility model.

---

# 16. Incomplete-Data Experience

## 16.1 Completeness Tiers

| Tier | Minimum Fields | Publication Allowed? | Search Indexing? |
|------|---------------|:--------------------:|:----------------:|
| **Full** | name, institution, discipline, award level, cut-off, tuition, requirements | ✓ | ✓ (full result card) |
| **Partial** | name, institution, discipline, award level | ✓ | ✓ (simpler result card) |
| **Minimal** | name, institution | ✓ | ✓ (minimal result card) |
| **Stub** | name only | ✗ | ✗ |

A programme with just a name and institution is already useful — it tells a user that the programme exists. StudyNexus should not withhold partial information; it should present what it has and clearly indicate what is missing.

## 16.2 Result Card Variants

```text
Full card:
  Programme · Award · Institution · Location · Cut-off · Tuition · Status

Partial card (no cut-off/tuition):
  Programme · Award · Institution · Location · Status
  "Cut-off and tuition information not available"

Minimal card (no discipline/award):
  Programme · Institution · Location
  "Limited information available"
```

## 16.3 Detail Page Missing Sections

Missing sections are **omitted**, not shown as empty placeholders. The user never sees a blank section or a "No data" label where information could exist. If a field is missing, the section either:

1. Shows "Information not available" with a source/freshness note (for critical fields like cut-off)
2. Is omitted entirely (for non-critical fields like description)

---

# 17. SEO-Entry Experience

## 17.1 Direct Entry Scenarios

| Entry URL | User Intent | What They See |
|-----------|-------------|---------------|
| `/institutions/unilag/programmes/cs-bsc` | "UNILAG CS cut off" | Full programme detail with admission info — question answered immediately |
| `/institutions/unilag` | "University of Lagos" | Institution overview with programme listing — can browse |
| `/programmes?discipline=computer-science` | "Computer science programmes" | Faceted results pre-filtered by discipline — can filter further |
| `/institutions?state=lagos` | "Universities in Lagos" | Institution results filtered by state — can browse |

## 17.2 Continuing from SEO Entry

After landing on a detail page, the user must be able to:

1. **Go back to search** — "Search" link in navigation
2. **See related options** — "Related programmes" section provides alternatives
3. **Navigate up** — Breadcrumbs: Home > Institutions > UNILAG > Computer Science
4. **Navigate across** — Link to institution page, link to discipline page

## 17.3 Breadcrumb Structure

```text
Programme detail:
  Home > Programmes > Computer Science > Computer Science (UNILAG)

Institution detail:
  Home > Institutions > University of Lagos
```

Breadcrumbs are rendered server-side for SEO (Schema.org BreadcrumbList JSON-LD).

## 17.4 Internal Linking Strategy

Every detail page links to:

- Its parent entity (programme → institution)
- Its discipline landing page (programme → `/programmes?discipline={slug}`)
- Related programmes (same discipline at other institutions, same institution other programmes)

This creates a dense internal link graph that distributes SEO authority and provides discovery paths for users.

---

# 18. Mobile Experience

## 18.1 Mobile-First Principles

Nigeria is a mobile-heavy market. Data costs are significant. The mobile experience is NOT a resized desktop — it has its own interaction model.

1. **Progressive disclosure** — Show the most important information first; let users expand for details
2. **Minimal data loading** — Server-render the initial view; lazy-load secondary sections
3. **Touch-friendly filters** — Bottom sheet with large tap targets, not a sidebar
4. **Sticky search** — Search bar remains accessible as user scrolls
5. **Vertical scrolling** — All information flows vertically; no horizontal scrolling

## 18.2 Mobile Journey: Programme Discovery

```text
Homepage
  → Search bar prominent at top
  → Types query → autocomplete dropdown
  → Submits → results page
  → Results: vertical card list (one card per row)
  → "Filter" button at top → bottom sheet with facets
  → Selects filters → "Show results" → sheet closes, results update
  → Taps programme card → programme detail page
  → Scrolls through admission info (primary section first)
  → Taps institution → institution detail
  → Back button → returns to results (preserved state)
```

## 18.3 Mobile Interaction Model

| Element | Desktop | Mobile |
|---------|---------|--------|
| Search | Top bar, always visible | Top bar, always visible |
| Facets | Left sidebar | Bottom sheet triggered by "Filter" button |
| Result cards | Grid (2–3 columns) | Single column |
| Active filters | Chips above results | Horizontal scrollable chips above results |
| Programme detail | Sections in two columns | Stacked vertically |
| Programme listing in institution | Table | Card list |
| Cut-off history | Inline | Expandable accordion |
| Navigation | Top nav bar | Bottom nav bar (Programmes, Institutions) or hamburger |

## 18.4 Tap Complexity

| Action | Taps |
|--------|:----:|
| Search → First result | 2 (type + tap result) |
| Open filters | 1 (tap filter button) |
| Apply single filter | 3 (open sheet → select → apply) |
| Clear all filters | 2 (open sheet → clear all) |
| Navigate to institution from programme | 1 (tap institution name) |
| Return to search results | 1 (back button) |

Maximum 3 taps for any primary action. This is acceptable for mobile.

---

# 19. Critical Edge Cases

| Edge Case | UX Response | Priority |
|-----------|-------------|:--------:|
| **No search results** | "No programmes found. Try removing filters or searching differently." + suggest popular disciplines | P0 |
| **Too many results (1000+)** | Show top results + suggest adding filters. Never show unbounded lists | P0 |
| **Missing cut-off mark** | Show "Cut-off not available" + historical values if exist | P0 |
| **Missing tuition** | Show "Tuition not available" — never show ₦0 | P0 |
| **Discontinued programme via SEO** | Show page with "Discontinued" notice + historical info | P0 |
| **Suspended institution** | Show page with "Suspended" badge + limited info | P1 |
| **Stale data (6+ months)** | Show "Information may be outdated" warning | P1 |
| **Programme at multiple institutions** | Each institution has its own programme page — not combined | P1 |
| **Invalid/obsolete URL** | 301 redirect if slug changed; 404 if entity deleted | P1 |
| **Mobile filter interaction** | Bottom sheet with apply/clear; never inline dropdowns on mobile | P1 |
| **Unpublished programme via direct URL** | 404 for public; accessible in admin | P1 |
| **Conflicting sources** | Show resolved canonical value; provenance shows authoritative source | P2 |

---

# 20. UX → Backend Traceability

| # | UX Requirement | User Need | Product Capability | Domain Implication | Data Implication | Search/Projection Implication | Backend Impact |
|---|---------------|-----------|-------------------|-------------------|-----------------|---------------------------|---------------|
| 1 | Filter programmes by discipline | "I want to study Engineering" | Discover Educational Opportunities | Programme has `discipline_id` FK | `disciplines` reference table + `discipline_id` on `programmes` | `discipline` facet on programme collection | Canonical (T-04) |
| 2 | Show cut-off marks with history | "What was the cut-off last year?" | Present Educational Knowledge | `cut_off_marks` table (per programme instance per cycle + pathway) | `cut_off_marks` (programme_instance_id, admission_cycle_id, pathway, value, source_id) | `cut_off` sort field; historical not in search (detail page only) | Canonical (T-03) |
| 3 | Show admission status badge | "Can I apply now?" | Discover Educational Opportunities | Derived from ProgrammeStatus + AdmissionCycle + AdmissionPolicy | No new data — derived query | `is_admission_open` boolean facet on programme collection | Already canonical |
| 4 | Filter by location | "Where is this institution?" | Discover Educational Opportunities | Location VO on Institution | Already canonical | `institution_state`, `institution_city` fields on programme document | Already canonical (denormalized parent attrs) |
| 5 | Filter by institution type | "I want a university, not a polytechnic" | Discover Educational Opportunities | InstitutionType enum on Institution | Already canonical | `institution_type` facet on programme and institution collections | Already canonical |
| 6 | Filter by award level | "I want a BSc programme" | Discover Educational Opportunities | AwardLevel enum on Programme | Already canonical | `award_level` facet on programme collection | Already canonical |
| 7 | Filter by ownership type | "Public or private?" | Evaluate Educational Opportunities | OwnershipType enum on Institution | Already canonical | `ownership_type` facet | Already canonical |
| 8 | Show tuition on result card | "Can I afford it?" | Evaluate Educational Opportunities | MonetaryAmount VO on Programme | Already canonical | `tuition_min`, `tuition_max` sort/facet fields | Already canonical |
| 9 | Show programme-institution relationship | "Which institution offers this?" | Present Educational Knowledge | Programme belongs to Institution | Already canonical | `institution_name`, `institution_type`, `institution_slug` on programme document | Already canonical |
| 10 | Show related scholarships | "Can I get financial help?" | Discover Educational Opportunities | Scholarship targets Programme (pivot) | Already canonical | Not in search — queried on detail page | Already canonical |
| 11 | Show accreditation status | "Is this institution accredited?" | Verify Educational Information | AccreditationRecord child entity | Already canonical | `accreditation_status` on institution document | Already canonical |
| 12 | Publication visibility | Admin controls what's public | Present Educational Knowledge | `is_published` + `published_at` | Already canonical (T-01) | Only published entities indexed in public collection | Canonical (T-01) |
| 13 | Show data freshness | "Is this information current?" | Verify Educational Information | Provenance metadata | Already canonical | Not projected — computed on detail page render | Low (presentation only) |
| 14 | Programme comparison (lightweight) | "How do these compare?" | Compare Educational Opportunities | No new domain concept | No new data | Result cards already comparable | None (presentation) |
| 15 | Discipline landing page | SEO entry for discipline queries | Present Educational Knowledge | Discipline reference table | Already canonical (T-04) | Discipline slug for URL | Low (route + query) |

---

# 21. Backend Impact Register

| ID | UX Finding | Backend Impact | Severity | MVP? | Canonical Change Required? |
|----|-----------|----------------|:--------:|:----:|:-------------------------:|
| B-01 | Programme filtering by discipline requires `discipline_id` FK | Schema: `disciplines` table + `discipline_id` on `programmes` | HIGH | ✓ | ✓ (already approved T-04) |
| B-02 | Cut-off mark history requires dedicated table | Schema: `cut_off_marks` table | HIGH | ✓ | ✓ (already approved T-03) |
| B-03 | Admission status badge requires derived query | Query: `isAdmitting` derived from status + cycle + policy | MEDIUM | ✓ | No (already canonical) |
| B-04 | Admission status as search facet requires pre-computed boolean | Typesense: `is_admission_open` boolean on programme document | MEDIUM | ✓ | No (already canonical as search projection) |
| B-05 | Staleness/freshness indicator requires `last_verified_at` access | Presentation: computed from provenance metadata | LOW | ✓ | No (already canonical) |
| B-06 | Programme comparison requires no domain change | Presentation: result cards already comparable; side-by-side is a UI concern | LOW | Partial | No |
| B-07 | Scholarship discovery on programme page requires pivot query | Query: `scholarship_programme` pivot already canonical | LOW | ✓ | No |
| B-08 | Discipline landing page requires discipline-by-slug route | Route + query: `disciplines` table + slug field | LOW | ✓ | No (T-04 covers) |
| B-09 | Historical cut-off display on detail page requires multi-row query | Query: `cut_off_marks` ordered by cycle descending | MEDIUM | ✓ | No (T-03 covers) |
| B-10 | Programme discontinued page remains accessible | Route: detail page renders for discontinued; search excludes | LOW | ✓ | No (canonical lifecycle) |
| B-11 | SEO canonical URLs for programme pages | Route: `/institutions/{inst-slug}/programmes/{prog-slug}` | MEDIUM | ✓ | No (already canonical) |
| B-12 | Autocomplete across programmes and institutions | Typesense: multi-search across two collections | MEDIUM | ✓ | No (Typesense supports) |
| B-13 | Mobile filter sheet requires Livewire component | Component: filter component with URL query string binding | LOW | ✓ | No (Livewire supports) |
| B-14 | Result card requires tuition and cut-off in search document | Typesense: `tuition_min`, `tuition_max`, `cut_off_latest` on programme document | MEDIUM | ✓ | No (already canonical as projection) |

**No BLOCKERs identified.** All HIGH-severity items are already approved canonical changes (T-03, T-04). The current domain model adequately supports the required UX.

---

# 22. Search Projection Requirements

## 22.1 Programme Search Document

| Field | Source | Type | Purpose |
|-------|--------|------|---------|
| `id` | Programme UUID | string | Document ID |
| `name` | Programme.name | string | Full-text search |
| `slug` | Programme.slug | string | URL construction |
| `award_level` | Programme.award_level | string (enum value) | Facet |
| `discipline` | Discipline.name | string | Facet + full-text |
| `discipline_slug` | Discipline.slug | string | URL construction |
| `institution_name` | Institution.name | string | Full-text search |
| `institution_slug` | Institution.slug | string | URL construction |
| `institution_type` | Institution.type | string (enum value) | Facet |
| `institution_state` | Institution.location.region | string | Facet |
| `institution_city` | Institution.location.city | string | Facet |
| `ownership_type` | Institution.ownership_type | string (enum value) | Facet |
| `delivery_mode` | Programme.delivery_mode | string (enum value) | Facet |
| `tuition_min` | Programme.tuition (computed) | int32 | Sort + range filter |
| `tuition_max` | Programme.tuition (computed) | int32 | Sort + range filter |
| `cut_off_latest` | CutOffMark (latest) | int32 | Sort + display |
| `is_admission_open` | Derived (status + cycle + policy) | bool | Facet + filter |
| `is_published` | Programme.is_published | bool | Filter (exclude unpublished from public) |
| `status` | Programme.status | string | Filter (exclude Discontinued from public) |
| `sort_name` | Programme.name (normalized) | string | Alphabetical sort |
| `programme_count_at_institution` | Computed | int32 | Display |

## 22.2 Institution Search Document

| Field | Source | Type | Purpose |
|-------|--------|------|---------|
| `id` | Institution UUID | string | Document ID |
| `name` | Institution.name | string | Full-text search |
| `slug` | Institution.slug | string | URL construction |
| `type` | Institution.type | string (enum value) | Facet |
| `ownership_type` | Institution.ownership_type | string (enum value) | Facet |
| `state` | Institution.location.region | string | Facet |
| `city` | Institution.location.city | string | Facet |
| `is_published` | Institution.is_published | bool | Filter |
| `status` | Institution.status | string | Filter |
| `programme_count` | Computed | int32 | Display |
| `accreditation_status` | Latest AccreditationRecord | string | Display |
| `sort_name` | Institution.name (normalized) | string | Alphabetical sort |

## 22.3 Canonical vs Projection Separation

**Canonical (PostgreSQL):** Normalized, integrity-protected, domain-rule-enforced.
**Projection (Typesense):** Denormalized, pre-computed, optimized for search/facet/sort.

Projections contain:
- Direct attributes from the aggregate
- Parent attributes for filtering (institution attrs on programme documents)
- Computed/derived attributes (is_admission_open, programme_count, cut_off_latest)
- Sort attributes (sort_name)

Projections do NOT contain:
- Full admission policy rules (too complex, detail-page only)
- Full accreditation record history (detail-page only)
- Historical cut-off marks (detail-page only)
- Provenance metadata (detail-page only)

---

# 23. Detail Page Data Requirements

## 23.1 Programme Detail Page

**Data source:** PostgreSQL/Eloquent (full entity graph)

```text
Programme
  ├── eager-load: institution (name, type, ownership, location, slug, accreditation)
  ├── eager-load: discipline (name, slug)
  ├── eager-load: programmeInstances (each instance owns its own admission data)
  │     ├── eager-load: admissionPolicies (where status = Published, ordered by cycle desc)
  │     └── eager-load: cutOffMarks (ordered by cycle desc, limit 3)
  ├── eager-load: accreditationRecords (latest per authority)
  └── lazy-load: scholarships (where targeting this programme, status in (Open, Announced))
```

**Derived information:**
- `isAdmitting` (from status + cycle + policy on ProgrammeInstance)
- `currentCutOff` (latest cut_off_mark value per ProgrammeInstance)
- `historicalCutOffs` (previous cut_off_mark values per ProgrammeInstance)

**Provenance:** `provenance` JSON on Programme entity (source, acquired_at, last_verified_at, trust_level)

**Incomplete handling:** Sections with missing data are omitted or show "Information not available" per Section 16.

## 23.2 Institution Detail Page

**Data source:** PostgreSQL/Eloquent (full entity graph)

```text
Institution
  ├── eager-load: accreditationRecords (latest per authority)
  ├── eager-load: programmes (scoped to this institution, with status + discipline)
  └── lazy-load: scholarships (where targeting this institution, status in (Open, Announced))
```

**Derived information:**
- `programmeCount` (count of published, non-discontinued programmes)
- `admittingProgrammeCount` (count of programmes where isAdmitting)
- `currentAccreditation` (latest AccreditationRecord per authority)

**Programme list within institution:** Served from Eloquent, NOT Typesense. Scoped to one institution with eager loading. Livewire component for filtering/sorting within the list.

---

# 24. UX Hypotheses

| ID | Hypothesis | Evidence | Confidence | Backend Implication | How to Validate |
|----|-----------|----------|:----------:|---------------------|-----------------|
| H-01 | Discipline is the primary organizing principle for programme discovery | Business docs identify "Explore by discipline" as WF1; PED identifies discipline as first facet | HIGH | `discipline_id` FK already approved | Analytics: track most-used facet on programme search |
| H-02 | Cut-off marks are the single most requested information on programme pages | Domain analysis: QualificationThreshold VO is core to AdmissionRule; PED identifies cut-off as primary user question | HIGH | `cut_off_marks` table already approved | Analytics: track which section users spend most time on; search query analysis |
| H-03 | Users arrive primarily via Google searches for specific programme+institution queries | SEO-driven platform; Nigerian education search behavior | HIGH | Programme URL must be institution-scoped for SEO | Analytics: track entry points and referrers |
| H-04 | Result cards should show cut-off and tuition as decision-relevant data | No direct evidence; inferred from decision model | MEDIUM | Requires tuition + cut-off in Typesense document | A/B test result card variants; user interviews |
| H-05 | Most users will not use comparison features in MVP | Comparison is P2; users make 2–3 comparisons, not 10 | MEDIUM | No domain change needed | Analytics: track comparison usage if implemented |
| H-06 | Bottom sheet is the best mobile filter pattern | Standard mobile UX pattern; works well for faceted search | MEDIUM | None (UI pattern) | Usability testing |
| H-07 | Showing staleness warnings is sufficient for trust communication | Inferred from trust problem dimension; no evidence of need for elaborate trust system | LOW | None (presentation only) | User research: do users understand and act on staleness warnings? |
| H-08 | Partial programme data should be published (not withheld until complete) | StudyNexus values discoverability; a programme name + institution provides value | MEDIUM | Publication rules allow partial data | Analytics: track engagement with partial-data pages vs full-data pages |
| H-09 | Scholarship discovery in MVP should be contextual (on programme/institution pages) not standalone search | DISCOVERY-CLOSURE T-08: scholarship scope is domain capability + admin + inline in first slice | HIGH | No new search collection needed for MVP | User feedback on MVP; search query analysis |
| H-10 | Users expect to see historical cut-off marks | Inferred: students use past cut-offs as targets; JAMB brochure includes past cut-offs | MEDIUM | `cut_off_marks` table already supports this | User research |

---

# 25. Unknowns Requiring Real Research

## 25.1 Known (Supported by Evidence)

- StudyNexus must be search-first (canonical business decision)
- Programme discovery is the primary user journey (business priority)
- Cut-off marks are critical information (domain analysis)
- Mobile is the primary device (Nigerian market)
- SEO is the primary acquisition channel (architecture decision)
- Publication and lifecycle are orthogonal (canonical decision)

## 25.2 Inferred (Reasonable Interpretation)

- Discipline is the primary facet (inferred from workflows and decision model)
- Users arrive with specific queries more often than exploratory browsing (inferred from SEO-first architecture)
- Historical cut-offs are valuable (inferred from JAMB behavior)
- Partial data should be published (inferred from discoverability goal)
- Bottom sheet is best mobile filter pattern (inferred from mobile UX conventions)
- Staleness warnings are sufficient trust communication (inferred from trust problem dimension)

## 25.3 Unknown (Requires Real Research)

| Unknown | Why It Matters | How to Resolve |
|---------|---------------|----------------|
| Do users actually understand "Admitting" vs "Prospective" status? | If not, the badge wording may cause confusion | Usability testing with 5–8 Nigerian students |
| Which fields matter most on the result card? | Card design affects click-through and satisfaction | A/B testing with different card layouts |
| Do users want side-by-side comparison in MVP? | Significant UX and backend effort if yes | User interviews during beta |
| Is location filtering by state sufficient, or do users need city/LGA? | Affects location facet granularity | Analytics on filter usage; user interviews |
| Do users trust staleness warnings, or do they ignore them? | Affects trust communication strategy | Usability testing |
| What is the actual mobile data cost tolerance? | Affects how much data to load initially | Nigerian market research / field testing |
| Do guidance counsellors need export/print features? | Affects MVP scope | Interview 3–5 guidance counsellors |
| What programme-related information do parents prioritize vs students? | May affect information hierarchy on detail pages | Interview parents and students separately |

---

# 26. First Vertical Slice

## 26.1 Recommended Slice: Programme Discovery

```text
Home (search + discipline browse)
 ↓
Programme search (Typesense-powered)
 ↓
Faceted programme results (discipline, award level, institution type, location, admission status)
 ↓
Programme detail (PostgreSQL-served: admission info, cut-offs, tuition, institution)
 ↓
Institution detail (PostgreSQL-served: accreditation, programme listing)
 ↓
Admission information (within programme detail: requirements, cut-offs, status, cycle)
```

## 26.2 Why This Slice?

1. **It addresses the primary user goal:** A student finding a programme and understanding whether they can get admitted. This is the highest-value user story.
2. **It exercises every critical architectural layer:**
   - PostgreSQL (detail pages)
   - Typesense (search, faceting, autocomplete)
   - Eloquent (entity graph, eager loading)
   - Domain model (Programme, ProgrammeInstance, Institution, AdmissionPolicy, CutOffMark, Discipline)
   - Publication model (is_published filtering)
   - SEO (canonical URLs, structured data, breadcrumbs)
   - Livewire (interactive filters, URL query string binding)
3. **It validates the core UX hypotheses:** H-01 (discipline-first), H-02 (cut-off importance), H-03 (SEO entry), H-04 (result card content)
4. **It produces visible, testable output:** Every screen is a user-facing page, not internal infrastructure.
5. **It is the smallest slice that delivers meaningful value:** Removing any component breaks the core decision model.

## 26.3 What User Problem Does It Prove?

A secondary school student in Nigeria can, for the first time, type "Computer Science" into a search engine or StudyNexus search, see verified programmes with admission status and cut-off marks, understand the requirements, and know which institution offers the programme — all from a single trusted source.

## 26.4 Which Backend Capabilities Does It Exercise?

| Capability | Exercised By |
|-----------|-------------|
| Domain model | Programme, ProgrammeInstance, Institution, AdmissionPolicy, CutOffMark, Discipline, AdmissionCycle |
| PostgreSQL | Detail page entity graphs, cut_off_marks table |
| Typesense | Programme search, faceting, autocomplete, sort |
| Publication model | is_published filtering on public queries |
| SEO | Canonical URLs, JSON-LD, breadcrumbs, sitemap entries |
| Livewire | Interactive filter component, URL binding |
| Reference data | Disciplines table, seed data |
| Admin (minimal) | Programme/Institution CRUD via Filament for data entry |

## 26.5 Which UX Assumptions Does It Validate?

- Discipline is the primary facet (H-01)
- Cut-off marks are the most important information (H-02)
- SEO entry is the highest-value entry point (H-03)
- Result card content drives evaluation (H-04)
- Partial data can be published (H-08)
- Scholarship context is sufficient for MVP (H-09)
- Historical cut-offs are valuable (H-10)

## 26.6 Which Future Capabilities Remain Outside It?

| Capability | When |
|-----------|------|
| Scholarship standalone search | Phase 2 |
| Side-by-side comparison | Phase 2 (enhancement) |
| Save/follow/shortlist | Stage 2 |
| User accounts | Stage 2 |
| Notifications | Stage 2 |
| Institution self-service | Stage 3 |
| Examination/resource pages | Phase 2+ |
| Content (articles, guides) | Phase 2 |
| Community Q&A | Phase 2+ |
| Personalization | Stage 2 |

---

# 27. UX Depth Levels

| Capability | Depth Level | Rationale |
|-----------|:-----------:|-----------|
| Programme discovery (search + facets + results) | **Level 4** | First vertical slice — needs detailed interaction design |
| Programme detail | **Level 4** | First vertical slice — needs detailed information architecture |
| Institution detail | **Level 4** | First vertical slice — reached from programme |
| Admission information | **Level 4** | First vertical slice — core value proposition |
| Homepage (search entry) | **Level 3** | Interaction model affects implementation (autocomplete, search submission) |
| Search autocomplete | **Level 3** | Implementation detail (Typesense multi-search) |
| Trust/provenance display | **Level 2** | Journey understood; visual design deferred |
| Incomplete-data handling | **Level 2** | Behavior specified; interaction details deferred |
| Lifecycle display | **Level 2** | Behavior specified per domain; interaction deferred |
| Scholarship contextual display | **Level 2** | Journey understood; not in first slice |
| Mobile interaction model | **Level 3** | Affects component implementation |
| SEO entry experience | **Level 2** | URL/rendering strategy defined; visual deferred |
| Institution search | **Level 3** | Simpler than programme search; reuses patterns |
| Admin (data management) | **Level 1** | Filament provides defaults; custom later |
| Scholarship search | **Level 1** | Phase 2 |
| Content (articles, guides) | **Level 1** | Phase 2 |
| Examination/resource pages | **Level 1** | Phase 2+ |
| Comparison | **Level 1** | Phase 2 enhancement |
| Personalization | **Level 1** | Stage 2 |

---

# 27.5 UI Design System & Theming Architecture

StudyNexus uses an **OKLCH color space, CSS custom property-driven theming layer** that ensures perceptual uniformity across all shades, enables instant brand color switching without refactoring any component, and mandates dark mode support from V1. This architecture applies to the entire TALL stack (Tailwind CSS, Alpine.js, Livewire, Laravel) and the Filament v5 admin panel, ensuring the public site and admin panel share a unified, easily swappable brand identity.

## 27.5.1 Color Space — OKLCH (Mandatory)

**All colors in StudyNexus MUST be defined in OKLCH, not HEX or HSL.** OKLCH provides perceptual uniformity — a fixed lightness step produces an equally noticeable brightness change across all hues — and enables clean, mathematically uniform shade generation. HEX and HSL are prohibited for brand and semantic color definitions because they produce inconsistent perceived lightness across hues (e.g., HSL lightness 50% looks different for blue vs. yellow).

OKLCH channel format: `oklch(L C H)` where L = perceptual lightness [0–1], C = chroma [0–0.4], H = hue angle [0–360]. For CSS custom properties, the channels are stored space-separated so Tailwind can compose the function: `--color-primary-600: 0.55 0.18 230;` → `oklch(0.55 0.18 230)`.

## 27.5.2 Color Hierarchy & Palette — Sky/Cyan/Teal/Emerald

The StudyNexus palette is deliberately constrained. Following the Refactoring UI principle "Limit your choices," only three brand colors exist: primary (Sky/Cyan), secondary (Teal), and accent (Emerald). This constraint eliminates indecision and enforces visual consistency. All shades (50–950) are generated algorithmically from the OKLCH anchor value, ensuring perceptually uniform steps.

**Primary palette — Sky/Cyan (primary actions, active states, links, CTAs):** A blueish hue that conveys trust and professionalism, appropriate for an education discovery platform. The 600-weight anchor is `oklch(0.55 0.15 230)` (sky blue). Used for: primary buttons, active navigation, link text, focus rings, selected states, loading indicators.

**Secondary/Accent palette — Teal/Emerald (highlights, secondary links, success-adjacent feedback):** A cooler green hue that complements the primary without competing. The 600-weight anchor is `oklch(0.52 0.12 170)` (teal). Used for: secondary buttons, highlighted badges, secondary link hover states, callout borders, achievement indicators.

**Semantic colors — Danger, Warning, Success:** These are fixed-palette colors for system feedback. They are not brand-switchable. Danger: `oklch(0.55 0.22 25)` (red). Warning: `oklch(0.75 0.15 85)` (amber). Success: `oklch(0.62 0.18 155)` (green). These OKLCH values are chosen for maximum perceptual distinguishability from the brand palette.

**Discarded colors:** No Navy, no Gold, no Nigeria Green. These were rejected because (1) they expand the palette beyond the "Limit your choices" constraint, (2) Navy has poor perceptual uniformity in HSL (it compresses lightness steps), and (3) Gold/Yellow has the worst perceptual uniformity of any hue in HSL. The Sky/Cyan/Teal/Emerald family provides sufficient range with uniform lightness behavior.

## 27.5.3 Tailwind Configuration — OKLCH Semantic Palette Mapping

Tailwind's `primary`, `secondary`, and `accent` color palettes are mapped to OKLCH CSS custom properties. All shades (50–950) for each semantic color reference the corresponding CSS variable with alpha-value support:

```javascript
// tailwind.config.js
export default {
  theme: {
    extend: {
      colors: {
        primary:   'oklch(var(--color-primary) / <alpha-value>)',
        secondary: 'oklch(var(--color-secondary) / <alpha-value>)',
        accent:    'oklch(var(--color-accent) / <alpha-value>)',
        success:   'oklch(var(--color-success) / <alpha-value>)',
        warning:   'oklch(var(--color-warning) / <alpha-value>)',
        danger:    'oklch(var(--color-danger) / <alpha-value>)',
      },
    },
  },
  darkMode: 'class',  // .dark class on <html> toggles dark palette
}
```

The `<alpha-value>` modifier enables Tailwind's opacity modifiers (e.g., `bg-primary-600/50`) without requiring separate CSS variable definitions for each opacity level. The `darkMode: 'class'` configuration means Tailwind generates dark variants prefixed with `.dark`, which are activated by toggling the `dark` class on the `<html>` element.

## 27.5.4 CSS Root Variables — OKLCH Brand Token Definitions

Brand colors are defined once in the main `resources/css/app.css` `:root` block as space-separated OKLCH channel values (L, C, H). Tailwind composes the `oklch()` function at build time. A `.dark` selector block overrides the same variables for dark mode:

```css
:root {
  /* Primary — Sky/Cyan (hue 230): primary actions, active states, CTAs, links */
  --color-primary-50:  0.97 0.02 230;
  --color-primary-100: 0.93 0.04 230;
  --color-primary-200: 0.85 0.07 230;
  --color-primary-300: 0.75 0.10 230;
  --color-primary-400: 0.65 0.13 230;
  --color-primary-500: 0.60 0.15 230;
  --color-primary-600: 0.55 0.15 230;   /* anchor — Sky Blue */
  --color-primary-700: 0.48 0.14 230;
  --color-primary-800: 0.40 0.12 230;
  --color-primary-900: 0.33 0.10 230;
  --color-primary-950: 0.25 0.08 230;

  /* Secondary/Accent — Teal (hue 170): highlights, secondary links, badges */
  --color-secondary-50:  0.97 0.02 170;
  --color-secondary-100: 0.93 0.04 170;
  --color-secondary-200: 0.85 0.07 170;
  --color-secondary-300: 0.75 0.09 170;
  --color-secondary-400: 0.65 0.11 170;
  --color-secondary-500: 0.58 0.12 170;
  --color-secondary-600: 0.52 0.12 170;   /* anchor — Teal */
  --color-secondary-700: 0.45 0.11 170;
  --color-secondary-800: 0.38 0.09 170;
  --color-secondary-900: 0.31 0.07 170;
  --color-secondary-950: 0.24 0.05 170;

  /* Accent — Emerald (hue 160): achievement, success-adjacent, callout borders */
  --color-accent-600: 0.62 0.18 160;

  /* Semantic — Danger (red, hue 25), Warning (amber, hue 85), Success (green, hue 155) */
  --color-danger-600:  0.55 0.22 25;
  --color-warning-600: 0.75 0.15 85;
  --color-success-600: 0.62 0.18 155;
}

.dark {
  /* Primary — Sky/Cyan: lightened + desaturated for dark backgrounds */
  --color-primary-50:  0.25 0.08 230;
  --color-primary-100: 0.33 0.10 230;
  --color-primary-200: 0.40 0.12 230;
  --color-primary-300: 0.48 0.14 230;
  --color-primary-400: 0.55 0.15 230;
  --color-primary-500: 0.60 0.15 230;
  --color-primary-600: 0.65 0.13 230;   /* dark mode anchor — lighter sky */
  --color-primary-700: 0.75 0.10 230;
  --color-primary-800: 0.85 0.07 230;
  --color-primary-900: 0.93 0.04 230;
  --color-primary-950: 0.97 0.02 230;

  /* Secondary/Accent — Teal: lightened for dark backgrounds */
  --color-secondary-50:  0.24 0.05 170;
  --color-secondary-100: 0.31 0.07 170;
  --color-secondary-200: 0.38 0.09 170;
  --color-secondary-300: 0.45 0.11 170;
  --color-secondary-400: 0.52 0.12 170;
  --color-secondary-500: 0.58 0.12 170;
  --color-secondary-600: 0.65 0.11 170;   /* dark mode anchor */
  --color-secondary-700: 0.75 0.09 170;
  --color-secondary-800: 0.85 0.07 170;
  --color-secondary-900: 0.93 0.04 170;
  --color-secondary-950: 0.97 0.02 170;

  /* Accent — Emerald (dark mode) */
  --color-accent-600: 0.70 0.15 160;

  /* Semantic — adjusted for dark backgrounds */
  --color-danger-600:  0.65 0.20 25;
  --color-warning-600: 0.80 0.13 85;
  --color-success-600: 0.70 0.15 155;
}
```

**Brand switching** is achieved by replacing the `:root` and `.dark` variable values (or loading alternate CSS files). No Blade component, Livewire component, or Filament resource requires modification — they all reference the semantic classes. **Dark mode** is toggled by adding/removing the `dark` class on the `<html>` element (Alpine.js: `x-data="{ dark: localStorage.getItem('theme') === 'dark' }" x-bind:class="{ dark }" x-effect="localStorage.setItem('theme', dark ? 'dark' : 'light')"`).

## 27.5.5 Filament v5 Theme Alignment

The Filament v5 admin panel is configured to consume the same OKLCH CSS custom properties. Filament's theme panel configuration (`Panel::brandName()`, `Panel::brandLogo()`) and custom CSS are wired to the shared variables:

```php
// app/Providers/Filament/AdminPanelProvider.php
->brandName('StudyNexus')
->brandLogo(asset('images/logo.svg'))
->viteTheme('resources/css/filament/admin.css')  // imports shared :root and .dark variables
```

The Filament admin CSS file (`resources/css/filament/admin.css`) imports the shared `:root` and `.dark` variable definitions from the public site CSS and applies them to Filament's theme hooks. This ensures that a brand color change and dark mode toggle propagate to both the public site and the admin panel simultaneously. The admin panel follows the user's system preference or manual toggle — it does not force a specific theme.

## 27.5.6 Refactoring UI — Mandatory Design Rules

The following rules are derived from *Refactoring UI* (Adam Wathan & Steve Schoger) and are **mandatory for all StudyNexus UI implementation**. These rules constrain the design system to prevent common visual quality regressions.

**Rule 1 — Hierarchy: Emphasize by De-emphasizing.** Visual hierarchy is created not by making important elements bigger, but by making less important elements smaller and softer. Use font weight (medium vs. regular) and color (soft grey `oklch(0.55 0 0)` for secondary text) to differentiate hierarchy levels. **Never use grey text on a colored background** — grey-on-color destroys readability. Instead, use a hand-picked lower-contrast OKLCH color derived from the background hue (e.g., on a `bg-primary-600` surface, use `text-primary-200` not `text-grey-300`).

**Rule 2 — Limit Your Choices: Constrained Scales.** Do not use arbitrary spacing, sizing, or type values. All values must come from a defined scale:

| Scale Type | Values | Rationale |
|---|---|---|
| Spacing | 4px, 8px, 12px, 16px, 24px, 32px, 48px, 64px | 4px base; powers of 2 with 12px for tight-but-not-touching |
| Sizing (components) | 24px, 32px, 40px, 48px, 64px | Touch targets: minimum 40px for mobile (WCAG) |
| Type scale | 12px, 14px, 16px, 18px, 20px, 24px, 30px, 36px, 48px | Major second (1.125) ratio with 16px base |
| Border radius | 4px, 8px, 12px, 16px, full | Rounded but not bubbly |
| Font weight | 400 (regular), 500 (medium), 600 (semibold), 700 (bold) | Four weights only |

Arbitrary Tailwind values (e.g., `mt-[13px]`, `text-[17px]`, `p-[6px]`) are **forbidden** in Blade components. If a value is not on the scale, use the nearest scale value.

**Rule 3 — Depth: Elevation via Box Shadows.** Use box shadows to convey elevation, emulating a light source from above-left. Define a strict 5-level elevation system. Borders are NOT elevation — they are containment (see Rule 4):

| Level | Shadow | Use Case |
|---|---|---|
| 0 | none | Flat elements (cards in a grid with no overlap) |
| 1 | `0 1px 2px oklch(0 0 0 / 0.05)` | Subtle lift (cards, list items) |
| 2 | `0 2px 4px oklch(0 0 0 / 0.08)` | Default elevation (dropdowns, popovers) |
| 3 | `0 4px 8px oklch(0 0 0 / 0.12)` | Prominent elevation (modals, dialogs) |
| 4 | `0 8px 16px oklch(0 0 0 / 0.16)` | Maximum elevation (toast notifications over modals) |

Shadow colors use OKLCH `oklch(0 0 0)` (perceptual black) with alpha — not HEX `#000`. In dark mode, shadow opacity is reduced by ~50% because dark surfaces absorb less light.

**Rule 4 — Borders: Use Fewer Borders.** Rely on background color contrast and box shadows to separate elements, not borders. Borders add visual noise. Specific guidance:
- Card separation: Use `shadow-1` (elevation) or `bg-white` on a `bg-grey-50` surface — no border.
- Section separation: Use increased spacing (24px+ gap) or a subtle background shift — no border.
- Input fields: Use a bottom border only (not a full border-box), or a background change on focus.
- Tables: Use row background alternation (`bg-grey-50` / `bg-white`) — no horizontal row borders. Use a bottom border on the header row only.
- When a border is necessary: Use `border-grey-200` (light mode) or `border-grey-700` (dark mode) at 1px — never 2px+.

**Rule 5 — Consistent Component Language.** The same interaction pattern must always use the same visual treatment. Primary buttons are always `bg-primary-600 text-white`. Secondary buttons are always `bg-secondary-600 text-white`. Destructive buttons are always `bg-danger-600 text-white`. Ghost buttons are always `text-primary-600 hover:bg-primary-50`. No exceptions, no one-off styling.

## 27.5.7 Component Rule — No Hardcoded Colors

**All Blade components, Livewire components, and Filament resource views must use semantic Tailwind classes that reference the OKLCH CSS variable palette. Hardcoded Tailwind color classes are forbidden.**

| Forbidden | Required |
|-----------|----------|
| `bg-blue-600` | `bg-primary-600` |
| `text-red-500` | `text-danger-500` |
| `border-green-300` | `border-success-300` |
| `bg-indigo-100` | `bg-secondary-100` |
| `text-yellow-700` | `text-warning-700` |
| `bg-teal-500` | `bg-secondary-500` |
| `text-cyan-600` | `text-primary-600` |

This rule is enforced by:
1. **Tailwind config safelist**: Only semantic color names (`primary`, `secondary`, `accent`, `success`, `warning`, `danger`) are generated. Direct Tailwind color scales (`blue`, `red`, `green`, `sky`, `cyan`, `teal`, `emerald`, etc.) are excluded from the safelist so they produce no output CSS — using them is a build error.
2. **Code review checklist**: Every PR is checked for hardcoded color classes in Blade, Livewire, and Filament views.
3. **ESLint/Stylelint rule** (optional future): A custom rule flags any `bg-{color}-`, `text-{color}-`, `border-{color}-` where `{color}` is not in the semantic set.

**Rationale:** Without this rule, a brand color change requires finding and replacing hundreds of hardcoded class references across every component — a refactor that risks regressions and takes days. With CSS variables, the change is a single `:root` edit that propagates instantly. The OKLCH color space ensures that shade substitution preserves perceptual uniformity, so a brand switch cannot accidentally produce a shade that is too dark or too light.

---

# 28. Product Experience Architecture (Conceptual Model)

## 28.1 Users → Goals → Journeys → Capabilities → Information → Decisions → Actions

```text
PROSPECTIVE STUDENT
  ├── Goal: Find programmes I qualify for
  │     ├── Journey: Discipline-first discovery
  │     │     ├── Capability: Search + Filter
  │     │     │     ├── Information: Programme name, discipline, award level, admission status
  │     │     │     ├── Decision: Which programmes to evaluate
  │     │     │     └── Action: Navigate to programme detail
  │     │     └── ...
  │     └── Journey: Programme evaluation
  │           ├── Capability: Present Educational Knowledge
  │           │     ├── Information: Requirements, cut-offs, tuition, institution
  │           │     ├── Decision: Do I qualify? Should I consider this?
  │           │     └── Action: Evaluate institution / compare / explore alternatives
  │           └── ...
  ├── Goal: Understand admission requirements
  │     └── (covered by Programme evaluation journey)
  └── Goal: Find affordable options
        ├── Journey: Tuition-filtered discovery
        │     ├── Capability: Search + Filter (tuition range)
        │     ├── Decision: Which programmes can I afford?
        │     └── Action: Evaluate affordable programmes
        └── ...

PARENT / GUARDIAN
  ├── Goal: Verify institution quality
  │     ├── Journey: Institution evaluation
  │     │     ├── Capability: Present Educational Knowledge + Verify
  │     │     ├── Information: Accreditation, ownership, location
  │     │     ├── Decision: Is this institution trustworthy?
  │     │     └── Action: Recommend to child / continue searching
  │     └── ...
  └── Goal: Compare costs
        ├── Journey: Cost comparison
        │     ├── Capability: Compare Educational Opportunities
        │     ├── Decision: Which is most affordable for equivalent quality?
        │     └── Action: Shortlist affordable options
        └── ...
```

## 28.2 Product Experience → Domain → Data → Search → Public Experience

```text
PRODUCT EXPERIENCE
  "I want to find Computer Science programmes in Lagos"
        ↓
DOMAIN
  Programme (name, discipline_id, institution_id, status, award_level)
  Institution (name, type, location)
  Discipline (name, slug)
        ↓
CANONICAL DATA (PostgreSQL)
  programmes table → discipline_id FK → disciplines table
  programmes table → institution_id FK → institutions table
  institutions table → location JSON (country, region, city)
        ↓
SEARCH PROJECTION (Typesense)
  programme document:
    name, discipline, discipline_slug, award_level,
    institution_name, institution_type, institution_state,
    is_admission_open, tuition_min, tuition_max, cut_off_latest
        ↓
PUBLIC EXPERIENCE
  Faceted search page:
    Results filtered by discipline=Computer Science, state=Lagos
    Each result card shows name, institution, cut-off, tuition, status
    Click → programme detail page (PostgreSQL-served)
```

---

# 29. Summary of Findings

## 29.1 Product-Wide Experience Model

StudyNexus is a search-first, trust-grounded education discovery platform. The product experience is organized around three interconnected experience domains: **Discovery** (search, browse, filter), **Evaluation** (inspect, understand, compare), and **Trust** (source, freshness, verification). Users move fluidly between these domains; the product does not impose a linear funnel.

## 29.2 Primary Users and Goals

**Primary user:** Prospective student (SS3/graduate). **Primary goal:** Find programmes they qualify for and understand admission requirements. **Secondary users:** Parents (cost/quality verification), undergraduate students (scholarships/postgraduate), guidance counsellors (multi-student advisory).

## 29.3 Major Journeys

1. **Discipline-first discovery** (primary): Search/browse → filter → evaluate → decide
2. **Institution-first discovery**: Search institution → browse programmes → evaluate
3. **SEO direct entry**: Land on detail page → question answered → explore related
4. **Admission status check**: Search programme → see status + requirements + cut-offs
5. **Scholarship contextual discovery**: View programme → see related scholarships

## 29.4 Backend Gaps Discovered

**No BLOCKERs.** All HIGH-severity backend requirements are already approved canonical changes:
- T-03: `cut_off_marks` table (cut-off history)
- T-04: `disciplines` reference table + `discipline_id` FK

The current domain model adequately supports the required UX. No canonical modifications are needed beyond the already-approved 12 changes from DISCOVERY-CLOSURE.md.

## 29.5 Backend Implications

14 backend impact items identified (B-01 through B-14). All are MEDIUM or LOW severity. The two HIGH items (discipline FK, cut-off marks) are already approved. The architecture is well-aligned with the UX requirements.

## 29.6 First Vertical Slice Recommendation

**Programme discovery** (Home → Search → Faceted Results → Programme Detail → Institution Detail → Admission Info) is confirmed as the correct first vertical slice. It addresses the primary user goal, exercises every critical architectural layer, and is the smallest slice that delivers meaningful value.

## 29.7 Decisions Requiring Approval

1. **Scholarship scope in MVP**: Contextual (inline on programme/institution pages) vs standalone search — recommended contextual, already aligned with DISCOVERY-CLOSURE T-08
2. **Incomplete-data publication**: Allow publishing programmes with partial data vs require minimum completeness — recommended allow partial (name + institution is sufficient)
3. **Discontinued/Closed page handling**: Keep pages accessible with notice vs 404 — recommended keep accessible for SEO and trust
4. **Staleness warning thresholds**: 90 days (aging) / 180 days (stale) — these are configurable; confirm or adjust
5. **Programme result card content**: Show cut-off and tuition on cards vs minimal cards — recommended show key decision data

## 29.8 Unknowns Requiring Real User Research

Eight unknowns identified (Section 25.3). The most critical for MVP:
- Whether users understand "Admitting" vs "Prospective" status wording
- Which fields matter most on result cards
- Whether location filtering by state is sufficient

These can be resolved through usability testing with 5–8 Nigerian students before or during early implementation.

---

*This document is a working UX discovery artifact. It is not a canonical architecture document. UX hypotheses are not approved product decisions. No canonical documents were modified.*
