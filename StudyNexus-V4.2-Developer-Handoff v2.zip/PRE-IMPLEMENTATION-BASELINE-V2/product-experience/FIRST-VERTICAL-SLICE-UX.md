# StudyNexus — First Vertical Slice UX Specification

**Date:** 2026-08-10
**Status:** UX DESIGN — awaiting human approval
**Phase:** UX specification (not discovery, not visual design, not implementation)

**Note:** Typesense is the V1 search engine. PostgreSQL FTS is available as fallback for admin search and degraded mode. All search functionality in V1 is served by Typesense; PostgreSQL FTS + pg_trgm + GIN indexes provide the fallback search capability.
**Baseline:** 6 canonical documents + PRODUCT-EXPERIENCE-ARCHITECTURE.md + DISCOVERY-CLOSURE.md
**Constraint:** No canonical documents modified. No code written. No visual design (colors, typography, branding).

---

# 1. Slice Objective

Enable a Nigerian secondary school student to type a field of interest into StudyNexus, discover programmes in that field, understand admission requirements and cut-off marks, and evaluate the offering institution — all from a single trusted source, on a mobile phone, arriving via Google or directly.

---

# 2. Target User

**Prospective student** (SS3 or recent graduate). They have exam scores or are preparing for exams. They know their field of interest but may not know exact programme names. They need to answer: *"Can I get admitted to this programme at this institution?"*

Secondary users in this slice: parents helping their child; guidance counsellors looking up information for students.

---

# 3. User Problem

Nigerian students cannot find verified, structured, current admission information in one place. Cut-off marks are scattered across JAMB brochures (PDFs), institution websites (often outdated), blogs (unverified), and WhatsApp groups (anecdotal). Admission status is uncertain. Tuition information requires visiting each institution separately. A student with a JAMB score of 210 who wants to study Computer Science cannot currently determine, without hours of manual research, which accredited institutions offer the programme, what their cut-off marks are, and whether admission is currently open.

---

# 4. Success Criteria

1. A student can search "Computer Science" and see relevant programmes within 3 seconds
2. Each result card shows enough information to decide whether to open it (institution, admission status, cut-off, tuition)
3. Programme detail page answers the admission question: requirements, cut-off (current + historical), status, tuition
4. Institution detail page answers the trust question: accreditation, location, other programmes
5. The entire journey works on a 3G mobile connection with < 2 MB data per page
6. SEO entry on a programme page answers the user's question without requiring navigation elsewhere
7. Incomplete data is communicated honestly, not hidden or faked

---

# 5. Entry Points

| Entry Point | URL | User Intent |
|-------------|-----|-------------|
| Homepage | `/` | General exploration or search |
| Programme search | `/programmes` | Search/filter programmes |
| Programme detail (SEO) | `/institutions/{inst}/programmes/{prog}` | Specific programme query |
| Institution detail (SEO) | `/institutions/{inst}` | Specific institution query |
| Discipline landing (SEO) | `/programmes?discipline={slug}` | Browse programmes in a discipline |

---

# 6. User Flows

## Flow 1 — Targeted Search (most common)

```text
Homepage
  → Types "Computer Science" in search box
  → Autocomplete shows matching programmes and institutions
  → Presses Enter or clicks "Search"
  → Programme results page with discipline filter pre-applied
  → Scans result cards
  → Taps a result card
  → Programme detail page
  → Reviews admission section (status, cut-off, requirements)
  → May tap institution link → Institution detail
  → May tap back → Returns to results (state preserved)
```

## Flow 2 — Discipline Browse

```text
Homepage
  → Scrolls to "Explore by field of study"
  → Taps "Engineering"
  → Programme results page with discipline=Engineering filter active
  → Applies additional filters (location, award level)
  → Taps a result card
  → Programme detail page
```

## Flow 3 — SEO Direct Entry

```text
Google search: "UNILAG computer science cut off mark 2026"
  → Lands on /institutions/unilag/programmes/computer-science-bsc
  → Sees programme name, admission status, cut-off mark immediately
  → Question answered. May explore further:
    → Taps institution → Institution detail
    → Taps "Related programmes" → Other CS or UNILAG programmes
    → Taps "Search" → Programme search
```

## Flow 4 — Institution-First

```text
Homepage
  → Types "University of Lagos" in search
  → Autocomplete shows institution match
  → Taps institution in autocomplete → Institution detail
  → Browses programme listing
  → Taps a programme → Programme detail
```

---

# 7. Screen / Experience Inventory

| # | Screen | URL | Primary Data Source |
|---|--------|-----|---------------------|
| 1 | Homepage | `/` | Static + Typesense (autocomplete) |
| 2 | Programme Search/Results | `/programmes` | Typesense (search + facets + results) |
| 3 | Programme Detail | `/institutions/{inst}/programmes/{prog}` | PostgreSQL/Eloquent |
| 4 | Institution Detail | `/institutions/{inst}` | PostgreSQL/Eloquent |

Four screens. No more. The discipline landing page is the programme search screen with a pre-applied filter.

---

# 8. Information Hierarchy (Product-Wide)

```text
Level 1 — Discovery (what exists?)
  Programme search → Result cards → Programme detail

Level 2 — Evaluation (can I get in?)
  Admission status → Cut-off marks → Requirements → Tuition

Level 3 — Trust (is this reliable?)
  Accreditation → Source → Freshness

Level 4 — Context (what else?)
  Institution detail → Related programmes → Related scholarships
```

---

# 9. Search Interaction

## 9.1 Homepage Search Box

**Goal:** Get the user from a question to relevant results in one action.

**Behavior:**

| State | What Happens |
|-------|-------------|
| **Empty** | Search box with placeholder: "Search programmes and institutions" |
| **Typing (≥ 2 characters)** | Autocomplete dropdown appears after 300ms debounce |
| **Autocomplete results** | Two groups: "Programmes" (max 5) and "Institutions" (max 3). Each shows name + key detail |
| **Enter / Search click** | Navigate to `/programmes?q={query}` |
| **Autocomplete item tap** | Navigate directly to that entity's detail page |

**Autocomplete programme item:**
```text
Computer Science (BSc) — University of Lagos
```

**Autocomplete institution item:**
```text
University of Lagos — Federal University, Lagos
```

**Data source:** Typesense multi-search across `programmes` and `institutions` collections. Server-side Livewire component queries Typesense on each keystroke (debounced). Results rendered as HTML, not client-side JS.

## 9.2 Programme Search Page Search

The `/programmes` page has its own search box that behaves identically to the homepage search box but is scoped to programmes. This search box sits above the filters and results.

**Query behavior:**

| Action | Behavior |
|--------|----------|
| Type + Enter | Full-text search via Typesense; filters preserved; results update |
| Clear query | Remove text search; filters preserved; results show all matching filters |
| Empty query + no filters | Show all published programmes (default sort: relevance/name) |

## 9.3 Browse vs Search

**Search** = user types text. Typesense performs full-text matching with typo tolerance.
**Browse** = user selects filters without typing. Typesense returns all documents matching facet constraints.
**Filter** = user narrows an existing search/browse result set.
**Sort** = user changes result ordering.

These are distinct interactions on the same results surface. The search box handles text queries. The facet sidebar/sheet handles filtering. The sort dropdown handles ordering.

---

# 10. Facet Interaction

## 10.1 Programme Facets (Ordered by Priority)

| # | Facet | User Question | Multi-Select? | Mobile Behavior |
|---|-------|--------------|:------------:|-----------------|
| 1 | **Discipline** | "What field?" | Single-select | Accordion in filter sheet; scrollable list |
| 2 | **Award Level** | "What qualification?" | Multi-select | Accordion; checkboxes |
| 3 | **Institution Type** | "University or polytechnic?" | Multi-select | Accordion; checkboxes |
| 4 | **State** | "Where?" | Single-select | Accordion; scrollable list (36 states + FCT) |
| 5 | **Admission Status** | "Can I apply now?" | Single-select (binary: Open / All) | Toggle: "Currently admitting only" |
| 6 | **Ownership Type** | "Public or private?" | Multi-select | Accordion; checkboxes |
| 7 | **Delivery Mode** | "On-campus or online?" | Multi-select | Accordion; checkboxes |

**Tuition range** is a sort option, not a facet (range sliders add complexity and are unreliable on mobile). **Cut-off range** is similarly a sort option.

## 10.2 Desktop Facet Behavior

```text
┌──────────────────┐  ┌─────────────────────────────────────────────┐
│ DISCIPLINE        │  │ [Result cards...]                           │
│  ● Engineering    │  │                                             │
│  ○ Sciences       │  │                                             │
│  ○ Arts           │  │                                             │
│  ○ Medicine       │  │                                             │
│                   │  │                                             │
│ AWARD LEVEL       │  │                                             │
│  ☑ BSc           │  │                                             │
│  ☐ MSc           │  │                                             │
│  ☐ HND           │  │                                             │
│                   │  │                                             │
│ INSTITUTION TYPE  │  │                                             │
│  ☑ University     │  │                                             │
│  ☐ Polytechnic    │  │                                             │
│                   │  │                                             │
│ STATE             │  │                                             │
│  ● Lagos          │  │                                             │
│  ○ Oyo            │  │                                             │
│                   │  │                                             │
│ ADMISSION         │  │                                             │
│  [Currently       │  │                                             │
│   admitting only] │  │                                             │
└──────────────────┘  └─────────────────────────────────────────────┘
```

- Left sidebar: always visible, facets in priority order
- Each facet shows value counts from Typesense (e.g., "Engineering (142)")
- Selecting a value: immediate results update (Livewire, no full page reload)
- Active filters: chips above results area, horizontally scrollable
- "Clear all" link next to active filter chips
- Discipline is single-select (selecting a new discipline deselects the previous)
- State is single-select
- Award Level, Institution Type, Ownership, Delivery Mode are multi-select (checkboxes)
- Admission Status is a toggle: "Currently admitting only" (on/off). When on, adds `is_admission_open=true` filter

## 10.3 Mobile Facet Behavior

```text
┌─────────────────────────────────┐
│  142 programmes   [Filter] [Sort]│
│                                  │
│  Active: Engineering × | Lagos × │
│                                  │
│  [Result cards...]               │
└─────────────────────────────────┘
```

- **Filter button** (top right): opens a bottom sheet
- Bottom sheet contains all facets in accordion sections (collapsed by default)
- User expands a section, makes selections, taps "Show results" at bottom
- Sheet closes; results update
- **Active filters**: chips above results (horizontal scroll); each chip has × to remove
- **"Currently admitting only"**: toggle switch at top of filter sheet, always visible (not inside an accordion)
- **State selection**: on mobile, a searchable list (36 states + FCT is too many to scroll comfortably on small screens)

## 10.4 Zero-Result Behavior

```text
┌─────────────────────────────────────┐
│  No programmes match your filters    │
│                                      │
│  Try:                                │
│  • Removing the State filter         │
│  • Changing Discipline               │
│  • Turning off "Currently admitting"  │
│                                      │
│  [Clear all filters]                 │
└─────────────────────────────────────┘
```

The suggestion removes the most restrictive filter first (the last one applied). Never show an empty page with no guidance.

## 10.5 Result Count Behavior

- After each filter change, the result count updates immediately (Typesense returns facet counts with every response)
- Show "X programmes" above the results
- On mobile, this count is visible in the sticky header bar

---

# 11. Result-Card Specification

## 11.1 Programme Result Card

Each card must answer: *"Is this result worth opening?"*

```text
┌─────────────────────────────────────────────────┐
│ Computer Science                         [Open]  │
│ BSc · 4 years · On-campus                        │
│ University of Lagos · Federal · Lagos            │
│ Cut-off: 200 (2025)  ·  Tuition: ₦150,000/yr    │
└─────────────────────────────────────────────────┘
```

| Field | Always Shown? | Rationale |
|-------|:------------:|-----------|
| **Programme name** | ✓ | Primary identifier. Without it, the card is meaningless |
| **Admission status badge** | ✓ | The most decision-relevant boolean: "Can I apply?" |
| **Award level** | ✓ | Distinguishes BSc from HND from MSc — fundamentally different programmes |
| **Duration** | If available | Helpful for evaluation, not critical for initial scan |
| **Delivery mode** | If not OnCampus | Only shown if unusual (Online, Hybrid) — OnCampus is default assumption |
| **Institution name** | ✓ | A programme means nothing without knowing who offers it |
| **Institution type** | ✓ | University vs Polytechnic is a primary decision filter |
| **Location (state)** | ✓ | Geographic preference is a primary filter criterion |
| **Cut-off (latest)** | If available | The single most decision-relevant number. Absence is noted |
| **Tuition (annual)** | If available | Second most decision-relevant number. Absence is noted |

### Card Variants by Data Completeness

**Full card** (all data available):
```text
Computer Science                               [Open]
BSc · 4 years
University of Lagos · Federal University · Lagos
Cut-off: 200  ·  Tuition: ₦150,000/yr
```

**Partial card** (no cut-off, no tuition):
```text
Computer Science                               [Open]
BSc · 4 years
University of Lagos · Federal University · Lagos
Cut-off not available  ·  Tuition not available
```

**Minimal card** (name + institution only):
```text
Computer Science                               [Open]
University of Lagos · Lagos
Limited information available
```

**Status badge variants:**
- `[Open]` — green — ProgrammeStatus::Admitting
- `[Not yet admitting]` — amber — ProgrammeStatus::Prospective
- `[Suspended]` — orange — ProgrammeStatus::Suspended
- (Discontinued programmes do not appear in search results)

---

# 12. Sorting and Result Ranking

| Sort Option | Label | When Default | Behavior |
|------------|-------|:-----------:|----------|
| **Relevance** | "Most relevant" | Text search active | Typesense text_relevance score (typo-tolerance, field weights) |
| **Name A–Z** | "Name A–Z" | No text query, no filters | Alphabetical by programme name |
| **Cut-off (low→high)** | "Cut-off: Low to high" | Never default | Sort by `cut_off_latest` ascending; nulls last |
| **Cut-off (high→low)** | "Cut-off: High to low" | Never default | Sort by `cut_off_latest` descending; nulls last |
| **Tuition (low→high)** | "Tuition: Low to high" | Never default | Sort by `tuition_min` ascending; nulls last |
| **Tuition (high→low)** | "Tuition: High to low" | Never default | Sort by `tuition_min` descending; nulls last |

**Default:** Relevance when text search is active; Name A–Z when browsing without search text.

**Sort UI:** Dropdown above results. On mobile, "Sort" button next to "Filter" button, opens a bottom sheet with sort options.

Ranking is **implicit** (Typesense relevance). The user never sees a rank number or score. Explicit ranking signals (popularity, click-through) are post-MVP.

---

# 13. Programme Detail Specification

## 13.1 Page Purpose

Answer the student's primary question: **"Can I get admitted to this programme, and what does it require?"**

## 13.2 URL Structure

`/institutions/{institution-slug}/programmes/{programme-slug}`

The URL is institution-scoped because the same programme name exists at multiple institutions. This is canonical architecture.

## 13.3 Information Hierarchy

### Above the Fold

```text
Computer Science (BSc)                        [Open]
University of Lagos · Federal University
Lagos, Lagos State
4 years · On-campus
```

**What the user sees immediately:** Programme identity, admission status, and institution. This answers "What is this?" and "Can I apply?" in the first viewport.

### Section 1: Admission (Primary — answers "Can I get in?")

This is the most important section on the page. It is shown immediately after the header, before any other information. **Admission is owned by ProgrammeInstance**, not Programme directly. A Programme may have multiple instances (e.g., On-campus vs Online), each with its own AdmissionPolicy and cut-off marks. The programme detail page shows all published ProgrammeInstances, each with its own admission information. Different instances may have different admission requirements.

```text
── Admission (On-campus) ────────────────────────

  Status: Currently admitting

  Cut-off mark
    2025/2026: 200                    ← Current (prominent)
    2024/2025: 190                    ← Historical (indented, smaller)
    2023/2024: 185                    ← Historical

  Requirements
    JAMB subjects: English, Mathematics, Physics, Chemistry
    Post-UTME: Required
    O-level: 5 credits including English, Mathematics

  Admission cycle
    2026/2027 cycle: Registration open
    Deadline: 15 May 2026
```

If the Programme has multiple instances (e.g., On-campus and Online), each instance is shown with its own admission section, as they may have different cut-off marks and requirements.

**Historical cut-off display:**
- Current cycle cut-off is **prominent** (larger text, distinct styling)
- Previous cycle cut-offs are **indented and smaller** (2–3 most recent)
- On mobile, historical cut-offs are in an expandable accordion if more than 2 exist
- Clear visual distinction: "2025/2026: **200**" vs "2024/2025: 190"
- Never ambiguous which is current and which is historical

**Missing cut-off behavior:**
```text
  Cut-off mark
    2025/2026: Not yet published       ← Clear about current status
    2024/2025: 190                     ← Historical still shown
    2023/2024: 185
```

### Section 2: Tuition (answers "Can I afford it?")

```text
── Tuition ────────────────────────────────────

  ₦150,000 per year
  Source: Institution website · Updated: Mar 2026
```

**Missing tuition:**
```text
── Tuition ────────────────────────────────────

  Tuition information not available
  Check with the institution for current fees
```

### Section 3: Institution (answers "Who offers this?")

```text
── Institution ────────────────────────────────

  University of Lagos                     → View institution
  Federal University · Public
  Akoka, Lagos, Lagos State
  Accreditation: NUC — Full (valid until 2028)
```

This section is a summary with a link to the full institution detail page. It answers the immediate trust question (accreditation) without requiring navigation.

### Section 4: Programme Information (contextual)

```text
── About this programme ───────────────────────

  Discipline: Engineering
  Award level: Bachelor of Science (BSc)
  Duration: 4 years
  Delivery mode: On-campus
  [Description text if available]
```

This section is omitted entirely if no description exists. Discipline and award level are already shown in the header, but repeating them here with additional context (full description) provides a natural reading flow.

### Section 5: Related Scholarships (if any exist)

```text
── Scholarships ───────────────────────────────

  PTDF Overseas Scholarship
  Full coverage · Deadline: 30 Apr 2026
                                        → View scholarship

  MTN Foundation Scholarship
  Partial coverage · Deadline: 15 May 2026
                                        → View scholarship
```

This section is **only shown if related scholarships exist**. Scholarship discovery is contextual in MVP (DISCOVERY-CLOSURE T-08). If no scholarships target this programme, the section is omitted entirely — no "No scholarships available" placeholder.

### Section 6: Related Programmes (exploration)

```text
── Related programmes ─────────────────────────

  At University of Lagos:
    Computer Engineering (BSc)           [Open]
    Electrical Engineering (BSc)         [Open]

  Computer Science at other institutions:
    Computer Science (BSc) — UNIBEN      [Open]
    Computer Science (BSc) — OAU         [Open]
```

Shows up to 3 programmes in each group. These are Eloquent queries (same institution, same discipline at other institutions), not Typesense. They provide exploration paths without requiring the user to return to search.

### Provenance Footer (always present)

```text
Last updated: 20 Jul 2026
Source: JAMB Official Brochure 2026 · Institution website
[Report incorrect information]                    ← Link to report workflow
```

## 13.4 Page States

| State | What User Sees |
|-------|---------------|
| **Complete data** | Full page with all sections |
| **Partial data** (no cut-off/tuition) | Admission section shows "Not yet published" / "Not available"; other sections render normally |
| **Minimal data** (name + institution only) | Header renders; sections show "Information not available" or are omitted; provenance footer notes limited data |
| **Discontinued** | Full header with `[Discontinued]` badge (red); notice: "This programme has been discontinued and is no longer offered."; historical admission info visible; "Related programmes" section emphasizes alternatives |
| **Suspended admission** | Full page with `[Suspended]` badge (orange); admission section shows "Admission currently suspended"; cut-offs and requirements still visible |
| **Unpublished** | 404 for public visitors (page does not exist); accessible in admin panel |
| **Invalid URL** | 404 page with "Programme not found" + link to search |

---

# 14. Institution Detail Specification

## 14.1 Page Purpose

Answer: **"Is this institution trustworthy, and what do they offer?"** The user arrives here primarily from a programme detail page. They already have a programme in mind; they want to understand the institution.

## 14.2 URL Structure

`/institutions/{institution-slug}`

## 14.3 Information Hierarchy

### Above the Fold

```text
University of Lagos                          [Operational]
Federal University · Public
Akoka, Lagos, Lagos State
```

### Section 1: Accreditation (answers "Is this place legitimate?")

```text
── Accreditation ──────────────────────────────

  NUC: Full accreditation
  Valid until: 2028
  Source: NUC accreditation list · Verified: Jan 2026
```

**Missing accreditation:**
```text
── Accreditation ──────────────────────────────

  Accreditation information not yet verified
```

### Section 2: Programmes (answers "What do they;:offer?")

This is the primary content of the institution page.

```text
── Programmes (87) ────────────────────────────

  [All]  [Admitting]                Filter: [Discipline ▼]

  Computer Science (BSc)           [Open]   Cut-off: 200
  Computer Engineering (BSc)       [Open]   Cut-off: 195
  Medicine (MBBS)                  [Open]   Cut-off: 280
  Law (LLB)                        [Open]   Cut-off: 250
  Accounting (BSc)                 [Open]   Cut-off: 180
  ... (paginated, 20 per page)
```

**Sub-filters within the programme list:**
- Tab: "All" / "Admitting" — quick filter to show only currently admitting programmes
- Dropdown: Discipline — filter programmes by discipline (disciplines present at this institution)

**Data source:** Eloquent (scoped to this institution, eager-loaded). NOT Typesense. This is canonical architecture.

**Each programme row shows:** name, award level, admission status badge, latest cut-off (if available). Tapping navigates to programme detail.

### Section 3: Institution Information (contextual)

```text
── About ──────────────────────────────────────

  [Description if available]
  Year established: 1962
  Website: unilag.edu.ng                ← External link
```

### Section 4: Related Scholarships (if any)

```text
── Scholarships ───────────────────────────────

  PTDF Overseas Scholarship
  Full coverage · Open · Deadline: 30 Apr 2026
```

Only shown if scholarships target this institution. Omitted entirely otherwise.

### Provenance6Footer

```text
Last updated: 20 Jul 2026
Source: NUC accreditation list · Institution website
[Report incorrect information]
```

## 14.4 Page States

| State | What User Sees |
|-------|---------------|
| **Operational** | Full page |
| **Provisional** | Full page with `[Provisional]` badge (amber) |
| **Suspended** | Full page with `[Suspended]` badge (orange); all programmes show "Admission suspended" |
| **Closed** | Header with `[Closed]` badge (red); notice: "This institution has been closed."; historical programme and accreditation info visible; no admission status badges |
| **Unpublished** | 404 for public; accessible in admin |

---

# 15. Admission Information Specification

## 15.1 Design Principle

Admission information is the **core value** of StudyNexus. It must be:
- **Immediately visible** — not hidden behind tabs or expandable sections
- **Clearly current** — the user must know which cycle's data they are viewing
- **Historical-aware** — previous cut-offs are shown because they inform expectations
- **Honest about gaps** — missing information is explicitly stated, not hidden

## 15.2 Information Priority

| Priority | Information | Rationale |
|:--------:|------------|-----------|
| 1 | Admission status (Open/Not yet/Suspended) | Binary decision gate: proceed or don't |
| 2 | Current cut-off mark | The number the student compares against their score |
| 3 | Historical cut-off marks (2–3 most recent) | Informs expectations when current not yet available; indicates competitiveness trend |
| 4 | Subject requirements (JAMB, O-level) | Determines if the student has the right subjects |
| 5 | Admission cycle deadline | Time pressure: when does the window close? |
| 6 | Admission pathway (UTME, Direct Entry, etc.) | Alternative routes if student doesn't meet primary requirements |
| 7 | Post-UTME requirement | Whether additional examination is needed |

## 15.3 Historical Cut-Off Display Rules

1. **Current cycle** cut-off is always displayed most prominently (larger font weight, top position)
2. **Previous cycles** are shown immediately below, indented, in smaller text
3. **Maximum 3 historical cut-offs** shown by default (current + 2 previous). If more exist, an expandable "Show earlier years" link reveals them.
4. Each cut-off is labeled with its **cycle** (e.g., "2025/2026") — never displayed without a cycle label
5. When current-year cut-off is not available, the most recent historical cut-off is shown with note: "Current year cut-off not yet published. Last known: 190 (2024/2025)"
6. Cut-offs for different admission pathways (UTME vs Direct Entry) are shown separately if they differ

**Example — Multiple pathways:**
```text
  Cut-off mark
    UTME:
      2025/2026: 200
      2024/2025: 190
    Direct Entry:
      2025/2026: 180
```

## 15.4 Missing Admission Information

| Missing | Display | Impact |
|---------|---------|--------|
| Current cut-off | "Cut-off not yet published for this cycle" + show historical if available | Medium — user can use historical as estimate |
| All cut-offs | "Cut-off information not available" | High — user must seek information elsewhere |
| Admission policy | "Admission requirements not yet published" | High — user cannot evaluate eligibility |
| Admission cycle | "Admission cycle information not available" | Medium — user cannot determine timing |
| Post-UTME info | Omit — do not show "Post-UTME: Unknown" | Low — assumption is post-UTME may be required |

---

# 16. Trust and Data-Quality Behavior

## 16.1 Design Principle

**Transparency without noise.** Show enough provenance for a user to assess reliability, but don't make the interface feel like a data-quality dashboard.

## 16.2 Source Attribution

Shown in the provenance footer of every detail page. Format:

```text
Source: JAMB Official Brochure 2026 · Institution website
```

The source attribution names the most authoritative source. If multiple sources contributed, the two most relevant are shown (e.g., "JAMB brochure" for cut-offs, "Institution website" for tuition).

## 16.3 Freshness Indicator

| Time Since Update | UX Response |
|-------------------|-------------|
| < 90 days | No indicator (information is fresh) |
| 90–180 days | "Last updated X months ago" in footer (subtle) |
| > 180 days | "⚠ Information may be outdated — verify with the institution" (prominent, at top of page) |

Freshness is computed from `provenance.last_verified_at` (domain entity) or `updated_at` (content entity). This is a presentation computation, not a domain change.

## 16.4 Missing Information

Missing critical fields (cut-off, tuition, requirements) are explicitly stated: "Information not available." The user is never left wondering whether the field is missing or just not loaded.

Missing non-critical fields (description, year established) are simply omitted — the section doesn't appear.

## 16.5 Conflicting Information

StudyNexus shows the **resolved canonical value** (per the verification engine in 06-data-acquisition.md: official sources win; conflicts flagged for admin). The public never sees conflicting values side by side. If the user suspects inaccuracy, the "Report incorrect information" link allows them to flag it.

---

# 17. Publication and Lifecycle Behavior

## 17.1 Domain Lifecycle → Public UX

| Domain State | In Search? | Detail Page | Badge | Historical Info |
|-------------|:----------:|:-----------:|:-----:|:--------------:|
| Programme: **Admitting** | ✓ | Full | `[Open]` green | ✓ |
| Programme: **Prospective** | ✓ | Full | `[Not yet admitting]` amber | ✓ |
| Programme: **Suspended** | ✓ | Full | `[Suspended]` orange | ✓ |
| Programme: **Discontinued** | ✗ | Notice + historical | `[Discontinued]` red | ✓ visible |
| Institution: **Operational** | ✓ | Full | `[Operational]` green | ✓ |
| Institution: **Provisional** | ✓ | Full | `[Provisional]` amber | ✓ |
| Institution: **Suspended** | ✓ | Limited | `[Suspended]` orange | ✓ |
| Institution: **Closed** | ✗ | Notice + historical | `[Closed]` red | ✓ visible |

## 17.2 Publication Gate

An entity must be **both** `is_published = true` AND in a publicly-displayable lifecycle state to appear in public search and on public detail pages.

```text
Public visibility = is_published AND status NOT IN (Discontinued, Closed, Withdrawn, Expired)
```

Unpublished entities: 404 on public URL. Accessible in Filament admin.

## 17.3 Discontinued/Closed Page Behavior

- Detail page remains at canonical URL (not 404)
- Clear notice at top: "This programme has been discontinued" / "This institution has been closed"
- Historical information (previous cut-offs, accreditation records, programme list) remains visible
- Not indexed in sitemap; `noindex` meta tag
- Internal links from other pages to discontinued/closed entities are removed or replaced
- 301 redirects via `url_redirects` table if slug changes

---

# 18. Incomplete-Data Behavior

## 18.1 Publication Threshold

A programme can be published if it has at minimum: **name + institution**. Even without discipline, cut-off, or tuition, the programme's existence is valuable information.

## 18.2 Detail Page Behavior

| Missing Section | Behavior |
|----------------|----------|
| Cut-off mark | Show "Cut-off not yet published" + historical values if available |
| All cut-offs | Show "Cut-off information not available" |
| Tuition | Show "Tuition information not available" |
| Admission requirements | Show "Admission requirements not yet published" |
| Description | Omit "About" section entirely |
| Accreditation | Show "Accreditation not yet verified" |
| Duration / Delivery mode | Omit from header (reduces to programme name + institution + badge) |

## 18.3 Result Card Behavior

Missing fields on the result card are handled per Section 11 (card variants). The card degrades gracefully:
- Full → Partial → Minimal
- Each variant is visually coherent; no empty gaps or "—" placeholders

---

# 19. Loading / Empty / Error States

## 19.1 Programme Search

| State | What User Sees |
|-------|---------------|
| **Initial (no query, no filters)** | All published programmes, default sort (Name A–Z) |
| **Typing** | Existing results remain; autocomplete dropdown appears |
| **Loading** | Skeleton result cards (3–5 gray rectangles) |
| **Results** | Result cards + count + active filters |
| **No results** | "No programmes match" + suggestions + "Clear all filters" |
| **Search failed** | "Search is temporarily unavailable. Please try again." + fallback: show cached results if available, else show browse options |
| **Too many results** | Show first 20 + pagination; suggest adding filters |

## 19.2 Programme Detail

| State | What User Sees |
|-------|---------------|
| **Loading** | Skeleton page (header + 3 section placeholders) |
| **Complete** | Full page per Section 13 |
| **Partially complete** | Available sections render; missing sections show "not available" or are omitted |
| **Discontinued** | Notice + historical info per Section 17 |
| **Invalid URL** | 404: "Programme not found" + link to programme search |
| **Server error** | "Something went wrong. Please try again." + link to homepage |

## 19.3 Institution Detail

| State | What User Sees |
|-------|---------------|
| **Loading** | Skeleton page |
| **Complete** | Full page per Section 14 |
| **Partially complete** | Available sections; missing accreditation shows "not verified" |
| **Closed** | Notice + historical info per Section 17 |
| **Invalid URL** | 404: "Institution not found" + link to institution search |

---

# 20. SEO-Entry Behavior

## 20.1 Breadcrumbs

**Programme detail:**
```text
Home  >  Programmes  >  Engineering  >  Computer Science (UNILAG)
  /      /programmes   ?discipline=    /institutions/unilag/programmes/cs-bsc
                      engineering
```

**Institution detail:**
```text
Home  >  Institutions  >  University of Lagos
  /      /institutions   /institutions/unilag
```

Breadcrumbs are rendered server-side as HTML with Schema.org `BreadcrumbList` JSON-LD. Each breadcrumb is a clickable link.

## 20.2 Continuing from SEO Entry

A user landing on a programme detail page from Google can:

1. **Answer their question** — admission info is above the fold
2. **Explore the institution** — tap institution name in header or Institution section
3. **Find alternatives** — "Related programmes" section at bottom
4. **Search further** — "Search" in navigation → programme search page
5. **Browse the discipline** — tap discipline link → `/programmes?discipline=engineering`

## 20.3 Internal Linking

Every programme detail page links to:
- Its institution (bidirectional)
- Its discipline landing page
- Related programmes at same institution (up to 3)
- Related programmes in same discipline at other institutions (up to 3)
- Related scholarships (if any)

Every institution detail page links to:
- All its programmes (via programme listing)
- Related scholarships (if any)

This creates a dense internal link graph for both SEO and user discovery.

---

# 21. Mobile Behavior

## 21.1 Navigation

```text
┌───────────────────────────────────┐
│  StudyNexus         [Search icon] │
├───────────────────────────────────┤
│  [Programmes]  [Institutions]     │
└───────────────────────────────────┘
```

- Top bar: brand name + search icon (taps to expand search box)
- Tab bar below: "Programmes" / "Institutions" — primary navigation
- On detail pages, back button returns to previous page (results state preserved via Livewire)

## 21.2 Search

- Search box expands from search icon (full width)
- Autocomplete dropdown below search box
- On submit, navigates to `/*programmes?q={query}`
- Keyboard: "Search" button on mobile keyboard (not "Go")

## 21.3 Filters

- "Filter" button next to result count → bottom sheet
- Bottom sheet: accordion sections for each facet
- "Currently admitting only" toggle at top of sheet (always visible)
- "Show results" button at bottom of sheet
- Sheet closes on selection + apply, or on backdrop tap (without applying)
- Active filter chips above results (horizontal scroll, × to remove)

## 21.4 Result Cards

- Single column, full width
- Each card is a tappable area (no separate "View" button needed — entire card is clickable)
- Tap target: minimum 44px height
- Information density: programme name (bold), institution + location (regular), cut-off + tuition (smaller)

## 21.5 Programme Detail

- All sections stack vertically
- Admission section is NOT collapsible — always expanded (it's the primary reason for the page)
- Historical cut-offs: expandable accordion if > 2 historical values
- Tuition section: compact
- Institution summary: compact with → link
- Related programmes: horizontal scrollable cards (not vertical list)

## 21.6 Institution Detail

- Programme list: vertical card list (same style as search results, but without search/facets)
- "All" / "Admitting" tabs are horizontal toggle buttons
- Discipline dropdown: native mobile select

## 21.7 Data Considerations

- Initial page load: server-rendered HTML (no JS required for first paint)
- Livewire provides interactivity (filter updates, pagination) without full reloads
- Target: < 2 MB per page on 3G
- Images: institution logos only (small); no hero images in MVP
- Skeleton loading states for perceived performance

---

# 22. Accessibility Requirements (UX-Level)

| Area | Requirement |
|------|-------------|
| **Keyboard navigation** | All interactive elements reachable via Tab; search, filters, result cards, detail sections all keyboard-operable |
| **Focus behavior** | After filter application, focus moves to result count. After search, focus moves to first result. After opening autocomplete, focus trapped in dropdown |
| **Semantic hierarchy** | `<h1>` = programme/institution name. `<h2>` = section headings (Admission, Tuition, Institution, etc.). `<h3>` = sub-sections |
| **Form labels** | Search box has `<label>` (visually hidden, screen-reader visible). Filter controls have associated labels |
| **Filter controls** | Checkboxes use native `<input type="checkbox">` with labels. Toggle switch has `role="switch"` with `aria-checked` |
| **Status communication** | Loading states use `aria-busy="true"`. Result count changes announced via `aria-live="polite"`. Filter application announced |
| **Expandable content** | Historical cut-offs accordion uses `aria-expanded`. "Show more" has `aria-controls` pointing to expanded content |
| **Error communication** | Error messages associated with search via `aria-describedby`. No results message in `aria-live` region |
| **Touch targets** | Minimum 44×44px for all interactive elements. Filter checkboxes have adequate spacing. Result cards have adequate padding |
| **Contrast** | Status badges (green/amber/orange/red) must meet 4.5:1 contrast against background. Text on cards must meet 4.5:1 |
| **Color independence** | Status badges use both color AND text label ("Open", "Suspended"). Not color alone |

---

# 23. User Flow Diagrams

## Flow 1 — Targeted Search

```text
Homepage
  │
  ├─ Types query
  │    │
  │    ├─ Sees autocomplete
  │    │    ├─ Taps programme → Programme Detail
  │    │    ├─ Taps institution → Institution Detail
  │    │    └─ Continues typing
  │    │
  │    └─ Presses Enter
  │         │
  │         └─ Programme Results
  │              │
  │              ├─ Scans cards
  │              ├─ Applies filter (e.g., State = Lagos)
  │              ├─ Changes sort
  │              │
  │              └─ Taps card → Programme Detail
  │                   │
  │                   ├─ Reads admission section
  │                   ├─ Checks cut-off
  │                   ├─ Taps institution → Institution Detail
  │                   │    ├─ Views accreditation
  │                   │    ├─ Browses programme list
  │                   │    └─ Taps programme → Programme Detail
  │                   │
  │                   ├─ Taps related programme → Programme Detail
  │                   └─ Back → Results (state preserved)
```

## Flow 2 — Discipline Browse

```text
Homepage
  │
  └─ Taps discipline (e.g., "Engineering")
       │
       └─ Programme Results (discipline=Engineering)
            │
            ├─ Scans cards
            ├─ Adds location filter
            ├─ Turns on "Currently admitting only"
            │
            └─ Taps card → Programme Detail
```

## Flow 3 — SEO Programme Entry

```text
Google → /institutions/unilag/programmes/cs-bsc
  │
  ├─ Sees programme name + admission status (above fold)
  ├─ Reads admission section (cut-off, requirements)
  ├─ Question answered ✓
  │
  ├─ (Optional) Taps breadcrumbs → Discipline results
  ├─ (Optional) Taps institution → Institution Detail
  ├─ (Optional) Taps related programme → Programme Detail
  └─ (Optional) Taps "Search" → Programme Search
```

## Flow 4 — Institution-First

```text
Homepage
  │
  └─ Types "University of Lagos"
       │
       ├─ Autocomplete shows institution
       │    └─ Taps → Institution Detail
       │
       └─ Presses Enter → Programme Results (q="University of Lagos")
            └─ Scans results at this institution
```

---

# 24. UX → Backend Contract

| # | UX Requirement | Required Information/Behavior | Existing Backend Support | Search Support | Gap? | Severity |
|---|---------------|------------------------------|------------------------|----------------|:----:|:--------:|
| 1 | Programme search with text query | Typesense full-text search on programmes collection | ✓ `programmes` collection | ✓ | No | — |
| 2 | Autocomplete (programmes + institutions) | Typesense multi-search across two collections | ✓ Both collections exist | ✓ multi-search | No | — |
| 3 | Discipline facet | `discipline` + `discipline_slug` on programme search document | ✓ (T-04 approved) | ✓ facet field | No | — |
| 4 | Award level facet | `award_level` on programme search document | ✓ AwardLevel enum | ✓ facet field | No | — |
| 5 | Institution type facet | `institution_type` denormalized on programme document | ✓ denormalized | ✓ facet field | No | — |
| 6 | Location facet (state) | `institution_state` on programme document | ✓ Location VO | ✓ facet field | No | — |
| 7 | Admission status filter | `is_admission_open` boolean on programme document | ✓ derived query | ✓ boolean facet | No | — |
| 8 | Ownership type facet | `ownership_type` on programme document | ✓ OwnershipType enum | ✓ facet field | No | — |
| 9 | Delivery mode facet | `delivery_mode` on programme document | ✓ DeliveryMode enum | ✓ facet field | No | — |
| 10 | Tuition sort | `tuition_min`/`tuition_max` on programme document | ✓ MonetaryAmount VO | ✓ sort field | No | — |
| 11 | Cut-off sort | `cut_off_latest` on programme document | ✓ (T-03 approved) | ✓ sort field | No | — |
| 12 | Programme detail with admission info | Eloquent: Programme → ProgrammeInstance → AdmissionPolicy / CutOffMark | ✓ entity graph | N/A (detail page) | No | — |
| 13 | Historical cut-off marks | `cut_off_marks` table (multi-row per programme instance) | ✓ (T-03 approved) | N/A | No | — |
| 14 | Cut-off by pathway (UTME vs Direct Entry) | `cut_off_marks.pathway` column | ✓ (T-03 approved) | N/A | No | — |
| 15 | Institution detail with programme list | Eloquent: Institution → Programmes (scoped) | ✓ eager loading | N/A | No | — |
| 16 | Accreditation display | AccreditationRecord child entity | ✓ canonical | N/A | No | — |
| 17 | Related scholarships (contextual) | Scholarship → Programme pivot query | ✓ `scholarship_programme` | N/A | No | — |
| 18 | Related programmes (same institution) | Eloquent: Programme where institution_id = X | ✓ | N/A | No | — |
| 19 | Related programmes (same discipline, other institutions) | Eloquent: Programme where discipline_id = X, institution_id ≠ Y | ✓ (T-04 provides discipline_id) | N/A | No | — |
| 20 | Publication filtering | `is_published` boolean on public queries | ✓ (T-01 approved) | ✓ filter | No | — |
| 21 | Lifecycle filtering (exclude Discontinued/Closed from public) | Status enum check | ✓ canonical | ✓ filter | No | — |
| 22 | Provenance/freshness display | `provenance` JSON + `updated_at` | ✓ canonical | N/A | No | — |
| 23 | SEO canonical URLs | Institution-scoped programme URLs | ✓ canonical | N/A | No | — |
| 24 | Breadcrumbs | Route model binding + slug | ✓ Laravel routing | N/A | No | — |
| 25 | Structured data (JSON-LD) | Schema.org types per model | ✓ canonical | N/A | No | — |
| 26 | Livewire filter component with URL binding | Livewire `#[Url]` attribute | ✓ Livewire v4 | N/A | No | — |
| 27 | Discipline landing page | `/programmes?discipline={slug}` route + query | ✓ (T-04 + T-11) | ✓ | No | — |
| 28 | "Report incorrect information" link | Information quality workflow (business capability #10) | ✓ canonical | N/A | No | — |

**No gaps identified.** All 28 UX requirements are supported by existing canonical architecture or already-approved changes (T-01 through T-04, T-11). The backend is well-aligned with the UX specification.

---

# 25. Backend Gaps

| # | Potential Gap | Assessment | Resolution |
|---|--------------|------------|------------|
| 1 | Discipline seed values | Not a schema gap — values are data, not structure | Populate during first data import |
| 2 | Programme comparison | UX-only concern — no domain change needed | Result cards are inherently comparable; side-by-side is Phase 2 |
| 3 | User shortlisting/favorites | Post-MVP (Stage 2) | Requires user accounts + `favourites` table |
| 4 | Eligibility evaluation ("Do I qualify?") | Post-MVP — requires score input + rule evaluation engine | Domain model supports it (AdmissionRule VO), but no public UX in MVP |
| 5 | Programme count on institution result cards | Search projection — already canonical (`programme_count`) | Computed in `toSearchableArray()` |

**No BLOCKERs. No canonical changes required.** The existing architecture supports every UX requirement in this slice.

---

# 26. Open UX Questions

These are NOT blockers for implementation. They are questions where the UX specification makes a reasonable choice but user research could change it.

| # | Question | Current Decision | What Could Change It |
|---|----------|-----------------|---------------------|
| 1 | Should "Currently admitting only" be default-on or default-off? | Default-off (show all programmes, let user filter) | If most users only want admitting programmes, default-on reduces friction |
| 2 | How many historical cut-offs to show by default? | Current + 2 previous; expandable for more | If users routinely need 5+ years, increase default |
| 3 | Should the result card show tuition as annual or total? | Annual (matches how institutions publish) | If students think in total cost, show total with "per year" note |
| 4 | Should the discipline browse show a grid or list? | Grid on desktop, list on mobile | A/B test engagement |
| 5 | Should programme detail show all admission pathways or just the primary? | Show all pathways with separate cut-offs | If confusing, collapse to primary with "Other pathways" expandable |
| 6 | Should related scholarships show on programme cards in search results? | No — only on detail page (keeps cards simple) | If scholarship availability is a strong decision signal, add to cards |
| 7 | Should stale-data warnings appear inline or in a banner? | Inline at top of page (below header) | If too intrusive, move to footer or make dismissible |

---

# 27. Summary

This specification defines **four screens** (Homepage, Programme Search/Results, Programme Detail, Institution Detail) that together enable the complete first vertical slice: a student discovers programmes, evaluates admission eligibility, and assesses the offering institution.

The UX is organized around **decision-making, not data display**. Every element answers a user question. The admission section on the programme detail page — the most important element in the entire product — is positioned first, never collapsed, and shows current and historical cut-offs with clear cycle labels.

The backend contract confirms **zero gaps**: all 28 UX requirements map to existing canonical architecture or already-approved changes. No canonical modifications are needed.

This specification stops at **interaction and information architecture**. Visual design (colors, typography, spacing, component styling) belongs to the next phase.

---

*This document is a UX specification, not a canonical architecture document. No canonical documents were modified. No code was written.*
