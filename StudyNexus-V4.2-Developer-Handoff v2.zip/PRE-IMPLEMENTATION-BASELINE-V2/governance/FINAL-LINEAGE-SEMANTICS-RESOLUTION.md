# StudyNexus — Final Lineage Semantics Resolution

**Document Type:** Targeted Semantic Resolution — Final Pass Before Canonical Amendment
**Date:** 2026-08-17
**Status:** SEMANTICS RESOLVED
**Constraint:** No canonical documents modified. No migrations written. No application code. No reconciliation executed.
**Scope:** Editorial provenance, InformationSource/EducationAuthority semantics, ExternalIdentifier source semantics, model minimization, domain/implementation separation, final schema

---

# 1. Executive Verdict

## GO FOR CANONICAL AMENDMENT

All seven issues are resolved. The lineage model is semantically coherent, minimally sufficient, and correctly separates domain decisions from implementation details. No foundational decisions (BD-1, BD-3, BD-5, ND-5, ND-4) are reopened. No new abstractions are introduced. One unnecessary abstraction (authority_id NOT NULL on InformationSource) is relaxed to nullable, reflecting actual domain semantics.

### Resolutions Summary

| Issue | Resolution |
|-------|-----------|
| 1. Editorial provenance | **Option A**: source_id NULLable on field_provenance; NULL = editorial assertion; ON DELETE RESTRICT |
| 2. InformationSource/Authority | **authority_id NULLable** on InformationSource; not every source belongs to an education authority |
| 3. ExternalIdentifier source | **source_id NULLable** on external_identifiers; NULL = editorial entry; ON DELETE RESTRICT |
| 4. Model minimization | **All 7 concepts retained** — none exist merely from review abstraction accumulation |
| 5. Domain vs implementation | **4 canonical decisions, 2 architecture decisions, 2 DB constraints, 3 implementation conventions** |
| 6. Final schema | **7 entity schemas** with essential fields, relationships, and invariants |
| 7. Open decisions | **ZERO unresolved foundational decisions** remain |

---

# 2. Editorial Provenance Decision

## The Question

> What is an editorial assertion in StudyNexus's provenance model?

## Domain Reasoning

field_provenance records: *"This specific field of this specific entity is supported by this source, which provided this observed value."*

For external sources: the source is an InformationSource — a specific publication or data endpoint. The provenance record says *"InformationSource X says field = Y."*

For editorial assertions: the source is a StudyNexus admin making a judgment call. The provenance record says *"StudyNexus admin asserts field = Y (no external source)."*

These are **fundamentally different types of provenance**. An editorial assertion is not an observation from an external source. It is a canonical decision made by a human operator. Trying to represent an admin as an InformationSource is a **type error** — an admin is a decision-maker, not a data source.

## Four-Way Evaluation

### Option A: source_id NULLable, NULL = editorial

| Criterion | Assessment |
|-----------|-----------|
| **Semantic accuracy** | **CORRECT.** NULL accurately represents "no external source." An editorial assertion, by definition, does not come from an external InformationSource. This is not "unknown" — it is a positive statement that the provenance is editorial. |
| **Provenance clarity** | **CLEAR.** With ON DELETE RESTRICT, source_id NULL means exactly one thing: editorial assertion. No other code path produces NULL. Source deprecation doesn't NULL the FK — it changes the source's status. Source deletion is blocked. |
| **InformationSource meaning** | **PRESERVED.** InformationSource remains "a retrievable external publication/document." No artificial entities dilute this definition. |
| **Referential integrity** | **STRONG.** ON DELETE RESTRICT prevents source deletion when provenance records exist. No ON DELETE SET NULL that could corrupt the NULL signal. |
| **Source deprecation** | **CORRECT.** Deprecated sources remain referenced by provenance records (source_id still points to them). The source's status changes to Deprecated; the FK remains valid. This is the intended behavior — deprecated sources are still sources. |
| **Source deletion** | **BLOCKED.** ON DELETE RESTRICT prevents deletion of any InformationSource that has dependent provenance. An admin must first supersede or remove all provenance records before deleting a source. This is correct — deleting a source with active provenance would destroy audit. |
| **Auditability** | **EXCELLENT.** Activity log records WHO made the editorial assertion (causer_id), WHEN (timestamp), and WHY (description). field_provenance records WHAT value was asserted. Together they provide complete audit. |
| **Admin UX** | **NATURAL.** When an admin edits a field, the UI shows "No source (editorial)" for the provenance. This is clear and expected. No fake "Editorial Override" entry in source dropdowns. |
| **Querying** | **ACCEPTABLE.** `WHERE source_id IS NULL` finds all editorial overrides. LEFT JOIN to information_sources with COALESCE for display. Standard SQL pattern, not a defect. |
| **Laravel/Eloquent** | **SIMPLE.** `source_id` is a nullable `belongsTo`. Accessor: `$provenance->source?->name ?? 'Editorial'`. One null-safe operator. |
| **Artificial entities** | **NONE.** No synthetic records. InformationSource table contains only real external sources. |
| **NULL ambiguity** | **NONE with ON DELETE RESTRICT.** There is exactly one reason source_id is NULL: editorial assertion. Source deletion cannot produce NULL because it's blocked. |
| **Risk of collapsing source and assertion** | **NONE.** The model explicitly distinguishes: source_id IS NOT NULL → external source observation; source_id IS NULL → editorial assertion. Two different provenance types, one column, unambiguous. |

### Option B: source_id NOT NULL + synthetic Editorial InformationSource

| Criterion | Assessment |
|-----------|-----------|
| **Semantic accuracy** | **INCORRECT.** An editorial assertion is NOT a source observation. Creating a fake InformationSource that says "Editorial Override" misrepresents the domain. An admin is not a publication. |
| **InformationSource meaning** | **CORRUPTED.** InformationSource now includes both real external sources AND a synthetic record that isn't a source. INV-IS3 ("every source has a retrievable reference") is violated — the editorial source has no retrievable reference. |
| **Artificial entities** | **YES.** One synthetic record that doesn't represent any domain fact. It exists solely to make a FK constraint non-nullable. |
| **Risk of collapsing source and assertion** | **HIGH.** The editorial source is treated identically to real sources in queries, reports, and the admin UI. Developers will filter it out everywhere, creating a perpetual `WHERE id != editorial_source_id` tax. |
| **Source deprecation** | **PROBLEMATIC.** Can the editorial source be deprecated? No — provenance records depend on it. Can it be deleted? No — ON DELETE RESTRICT blocks it. It becomes a permanent, undeletable, undeprecatable sentinel. |

### Option C: source_id NULLable + provenance_type NOT NULL

| Criterion | Assessment |
|-----------|-----------|
| **Semantic accuracy** | **MOST EXPLICIT.** provenance_type makes the distinction between source observation and editorial completely unambiguous, even without looking at source_id. |
| **NULL ambiguity** | **ZERO.** provenance_type = 'editorial' ↔ source_id IS NULL is an explicit invariant. |
| **Cost** | **One additional column + one additional invariant.** More complex inserts. More columns to maintain. |
| **MVP justification** | **MARGINAL.** For MVP, there are only two provenance types: source observation and editorial. The provenance_type column adds explicitness but the same information is derivable from `source_id IS NULL`. If "derived" provenance is added later, the column becomes justified — but that's a future concern, not an MVP requirement. |

### Option D: Separate editorial_provenance table

This would split provenance into two tables: field_provenance (with source_id NOT NULL) and editorial_provenance (with admin_id NOT NULL, no source_id).

**Rejected.** This doubles the query surface, doubles the model complexity, and creates a union-query pattern everywhere provenance is displayed. The two tables have identical structures except for the source reference. This is over-engineering for MVP.

## Decision: Option A

**field_provenance.source_id: BIGINT NULL**

- NULL means editorial assertion — a positive domain fact, not missing information
- FK constraint: ON DELETE RESTRICT — source deletion blocked when provenance exists
- The meaning of NULL is unambiguous: editorial assertion is the ONLY code path that sets source_id to NULL
- Activity log records WHO made the assertion (causer_id); field_provenance records WHAT was asserted
- No synthetic entities. No additional columns for MVP. No dilution of InformationSource semantics.

**If "derived" provenance is needed in future** (e.g., tuition = JAMB value + inflation adjustment), add a `provenance_type` column then. It is an additive, non-breaking change. For MVP, two types (source observation, editorial) are sufficient and unambiguous.

---

# 3. InformationSource / EducationAuthority Decision

## EducationAuthority — Precise Definition

**EducationAuthority is: An organization that holds official power over some aspect of the education system.**

It is characterized by what it DOES, not what it publishes:

| AuthorityType | Definition | Examples |
|---------------|-----------|----------|
| Admissions | Administers centralized admission processes | JAMB, UCAS, KUCCPS |
| Accreditation | Grants or revokes institutional/programme accreditation | NUC, NBTE, NCCE, ABET |
| Regulatory | Sets and enforces education policy and standards | FME, State MOE, GTEC |
| Examination | Administers standardized examinations | WAEC, NECO, NABTEB |
| Funding | Provides education funding/scholarships at systemic level | PTDF, TETFund, UBEC |

**EducationAuthority is NOT:**
- A publisher (publishing is incidental to its authority)
- An institution (institutions are subjects OF authority, not authorities themselves)
- Any organization that happens to have education data

## InformationSource — Precise Definition

**InformationSource is: A specific, retrievable publication, document, or data endpoint from which StudyNexus acquires information.**

Key attributes from the canonical domain model:
- It has a **retrievable reference** (INV-IS3) — a URL, file path, or access method
- It has a **verification lifecycle** (Registered → Verified ↔ Unreliable → Deprecated)
- It has an **InformationCategory** (Official, Unofficial, Historical, Scraped)
- It is consumed by a **specific adapter** that knows how to fetch and normalize its data

## Twelve Examples Analyzed

| # | Example | What is the InformationSource? | EducationAuthority? | authority_id |
|---|---------|-------------------------------|---------------------|:------------:|
| 1 | JAMB 2026 Brochure | Specific PDF document published by JAMB for the 2026 admission cycle | JAMB (Admissions) | NOT NULL |
| 2 | JAMB official website | Web endpoint at jamb.gov.ng | JAMB (Admissions) | NOT NULL |
| 3 | NUC 2025 Accreditation Directory | Specific publication listing accredited institutions/programmes | NUC (Accreditation) | NOT NULL |
| 4 | NBTE institution directory | Publication listing NBTE-accredited institutions | NBTE (Accreditation) | NOT NULL |
| 5 | UNILAG official website | Web endpoint at unilag.edu.ng | **NULL** — UNILAG is an institution, not an education authority | NULL |
| 6 | UNILAG admission portal | Web endpoint for admissions.unilag.edu.ng | **NULL** — same reasoning | NULL |
| 7 | UNILAG CS handbook PDF | Specific departmental document | **NULL** — same reasoning | NULL |
| 8 | University press release | Specific document | **NULL** — not published by an authority | NULL |
| 9 | FME education circular | Specific government circular document | FME (Regulatory) | NOT NULL |
| 10 | Scholarship provider webpage | Web endpoint at provider site | **Depends** — PTDF is Funding authority; Shell/MTN are not | NULL or NOT NULL |
| 11 | User-submitted correction | Community contribution record | **NULL** — no authority | NULL |
| 12 | StudyNexus editorial assertion | **NOT an InformationSource** — editorial provenance is represented by source_id = NULL on field_provenance | N/A | N/A |

## Key Insight

**Not every InformationSource belongs to an EducationAuthority.** Institution websites (examples 5-8) are published by institutions, which are domain entities but NOT education authorities. Community contributions (example 11) have no authority. Some scholarship providers (Shell, MTN) are corporations, not education authorities.

Forcing authority_id NOT NULL would require either:
- Creating fake "authority" records for every institution (UNILAG is not an authority)
- Refusing to track institution websites as InformationSources (losing provenance)
- Creating an "Other" authority category that means nothing

All three are worse than nullable authority_id.

## Decision: authority_id NULLable on InformationSource

**information_sources.authority_id: BIGINT NULL**

- NOT NULL when the source is published by an education authority (JAMB brochure, NUC directory, FME circular)
- NULL when the source is not published by an authority (institution website, community contribution, corporate scholarship page)
- The relationship represents a real domain fact: "this source is published under the authority of this education body"
- When NULL, the source's trust level is determined by its InformationCategory (Official, Unofficial, Historical, Scraped) and verification status, not by an authority relationship

**Trust cascade for authority-less sources:** When an institution is closed/deprecated, its website source's data is flagged via the Institution aggregate's lifecycle events, not via an authority cascade. The two cascade paths are:
1. Authority deprecation → all sources from that authority are flagged → all provenance from those sources is recalculated
2. Source deprecation → all provenance from that source is recalculated

Institution website deprecation follows path 2 directly (admin deprecates the source), not path 1.

---

# 4. ExternalIdentifier Source Semantics

## Case Analysis

| Case | Scenario | source_id | authority_id | Reasoning |
|------|----------|:---------:|:------------:|-----------|
| A | JAMB assigns code 123, observed in JAMB brochure | NOT NULL → JAMB brochure | NOT NULL → JAMB | Observed from a source; assigned by an authority |
| B | Admin enters confirmed JAMB code from phone/email exchange | NULL | NOT NULL → JAMB | Editorial entry: the identifier is assigned by JAMB (authority_id is real) but not observed from any InformationSource |
| C | StudyNexus derives an internal identifier | **Not in external_identifiers** | N/A | Internal identifiers (slugs, internal codes) are NOT external identifiers. They belong on the entity itself, not in this table. |
| D | Identifier imported from a source later deprecated | NOT NULL → (now-deprecated source) | NOT NULL → JAMB | Source is deprecated but still exists; FK remains valid. The identifier WAS observed from that source. |

## Decision: source_id NULLable on ExternalIdentifier

**external_identifiers.source_id: BIGINT NULL**

- NOT NULL when the identifier was observed from an InformationSource (Cases A, D)
- NULL when the identifier was editorially entered (Case B)
- ON DELETE RESTRICT — source deletion blocked when identifiers reference it
- authority_id remains NOT NULL — every external identifier belongs to an authority's namespace (even editorially entered ones: if you're entering a JAMB code, you know it's JAMB's namespace)

**Case C exclusion:** StudyNexus-derived identifiers (slugs, internal codes) are NOT stored in external_identifiers. They remain as entity columns. external_identifiers exists specifically for codes assigned by EXTERNAL authorities.

---

# 5. Minimal Lineage Model

## Concept Audit

| Concept | What Fact? | Who Creates? | Who Reads? | Who Owns? | Lifecycle | Why Not Another Concept? | Classification |
|---------|-----------|--------------|------------|-----------|-----------|------------------------|----------------|
| **EducationAuthority** | An org with official power over an aspect of education | Platform admin (seed) | Trust cascade, provenance display, identifier namespace, admin UI | Platform (reference) | Active → Deprecated (terminal) | Distinct domain concept; cannot be merged with InformationSource | Canonical domain (reference) |
| **InformationSource** | A specific retrievable publication/endpoint for data acquisition | Admin or import pipeline | Provenance, import pipeline, admin UI | Platform (reference) | Registered → Verified ↔ Unreliable → Deprecated | Distinct from authority; has own lifecycle and verification | Canonical domain + acquisition infra |
| **ExternalIdentifier** | A code assigned by an authority to identify an entity externally | Import pipeline or admin | Search (Typesense), duplicate detection, admin UI, public pages | Referenced entity | Active → Retired/Superseded | BD-5 rejected source-specific columns; no alternative | Canonical domain (identification) |
| **ImportBatch** | One import operation from one source at one time | Import pipeline | Admin UI (monitoring), audit | Import pipeline (staging) | Pending → ... → Completed/Failed | Needed for batch tracking, idempotency, error logging | Acquisition infrastructure (staging) |
| **PendingImport** | One record in an import batch, before canonical application | Import pipeline | Verification engine, admin UI (conflict resolution) | Import pipeline (staging) | Pending → Verified/Rejected/Conflict → Applied | Needed for verification workflow; cannot merge with batch | Acquisition infrastructure (staging) |
| **FieldProvenance** | A specific field supported by a specific source (or editorially asserted) | Import pipeline or admin | Admin UI (conflict, provenance), trust computation | Referenced entity | Active → Superseded (chain) | Entity JSONB insufficient for multi-source fields | Provenance infrastructure |
| **Provenance JSONB** | Entity-level trust summary for efficient display/search | Import pipeline or admin (recalc) | Search (Typesense), admin UI, public pages | Canonical entity | Overwritten on recalc | Could compute on demand, but expensive for search projection | Provenance infrastructure (denormalized) |

**Result: All 7 concepts retained. None exists merely from review abstraction accumulation.** Each represents a distinct domain or infrastructure fact that cannot be represented by another concept without information loss or operational impairment.

---

# 6. Domain vs Implementation Classification

| Item | Classification | Rationale |
|------|---------------|-----------|
| **source_id nullability** (field_provenance) | **A. Canonical domain decision** | Whether editorial provenance has an external source is a domain semantics question. The answer defines what editorial provenance IS. |
| **authority_id nullability** (InformationSource) | **A. Canonical domain decision** | Whether every source belongs to an authority is a domain semantics question. The answer defines what InformationSource IS relative to EducationAuthority. |
| **current_phase invariant** (INV-C2b/c/d) | **A. Canonical domain decision** | The relationship between current_phase and PhaseSequence is domain logic. The invariant defines valid aggregate states. |
| **stable phase IDs** | **B. Architecture decision** | How the PhaseSequence VO represents phases internally (stable ID vs mutable name) is an architecture choice about the VO's internal structure, not a domain concept. |
| **partial unique indexes** | **C. Database implementation constraint** | PostgreSQL-specific index strategy for enforcing "at most one active identifier." The domain invariant is "uniqueness"; the partial index is how PostgreSQL implements it. |
| **CHECK constraints** | **C. Database implementation constraint** | Enforcing domain invariants (status ∈ enum, confidence ∈ [0,100]) at the DB level for defense-in-depth. The invariants are domain; the CHECK constraints are implementation. |
| **lockForUpdate** | **D. Application implementation convention** | The concurrency mechanism for advancePhase(). The domain requirement is "atomic phase transition"; lockForUpdate is how Laravel implements it. |
| **morphMap** | **D. Application implementation convention** | Laravel convention for polymorphic type aliases. The domain concept is polymorphic identity; morphMap is the Laravel implementation. |
| **field_name whitelist** | **D. Application implementation convention** | Which fields get provenance is domain knowledge (the 80/20 strategy), but the whitelist mechanism (constant class, config file) is implementation. |
| **migration order** | **D. Application implementation convention** | The sequence in which migrations run. The domain dependencies are real; the specific migration file ordering is implementation. |

**Key principle: Canonical domain documents (01-06) should contain only Category A decisions. Architecture decisions (B) belong in ADR documents. Implementation details (C, D) belong in implementation documentation, not canonical.**

---

# 7. Final Conceptual Schema

## EducationAuthority

**Purpose:** An organization with official power over an aspect of the education system (admissions, accreditation, examination, regulation, funding).

| Field | Type | Purpose |
|-------|------|---------|
| id | BIGINT PK | Identity |
| name | VARCHAR | Display name (e.g., "Joint Admissions and Matriculation Board") |
| short_name | VARCHAR | Abbreviation (e.g., "JAMB") |
| type | AuthorityType enum | {Admissions, Accreditation, Examination, Regulatory, Funding} |
| jurisdiction | AuthorityJurisdiction VO | Scope definition (country, institution types, etc.) |
| status | LifecycleStatus | {Active, Deprecated} |

**Essential relationships:**
- has many InformationSources (where authority_id = this)
- has many ExternalIdentifiers (namespace owner)
- has many AdmissionCycles (cycle owner)
- has many AccreditationRecords (accreditation grantor)

**Essential invariants:**
- Deprecated is terminal — no reactivation
- short_name is unique within type

---

## InformationSource

**Purpose:** A specific, retrievable publication, document, or data endpoint from which StudyNexus acquires information.

| Field | Type | Purpose |
|-------|------|---------|
| id | BIGINT PK | Identity |
| name | VARCHAR | Descriptive name (e.g., "JAMB 2026 Unified Tertiary Matriculation Brochure") |
| authority_id | BIGINT NULL FK → education_authorities | The authority that published this source, if applicable |
| type | SourceType enum | {OfficialRegistry, InstitutionWebsite, AccreditationBody, GovernmentOpenData, ScholarshipProvider, CommunityContribution, DataPartner} |
| category | InformationCategory enum | {Official, Unofficial, Historical, Scraped} |
| reference | VARCHAR | Retrivable URL/path/access method (INV-IS3) |
| adapter_class | VARCHAR | Fully qualified adapter class name |
| verification_status | SourceReliability enum | {Registered, Verified, Unreliable, Deprecated} |

**Essential relationships:**
- belongsTo EducationAuthority (nullable) — the authority that published this source
- has many ImportBatches
- has many FieldProvenance records
- has many ExternalIdentifier records

**Essential invariants:**
- INV-IS1: Cannot be simultaneously Verified and Unreliable
- INV-IS2: Deprecated is terminal
- INV-IS3: Every registered source has a retrievable reference
- When authority_id IS NOT NULL, the source is published by that authority
- When authority_id IS NULL, the source is not published by any education authority (institution website, community contribution, etc.)

---

## ExternalIdentifier

**Purpose:** A code assigned by a specific authority to identify a canonical entity in an external reference system. Bridges external reference systems to StudyNexus canonical identity.

| Field | Type | Purpose |
|-------|------|---------|
| id | BIGINT PK | Identity |
| entity_type | VARCHAR | Morph alias ('institution', 'programme') |
| entity_id | BIGINT | FK to canonical entity (polymorphic) |
| authority_id | BIGINT NOT NULL FK → education_authorities | Who ASSIGNED this identifier |
| identifier_type | VARCHAR | Type of code ('institution_code', 'programme_code', 'accreditation_number') |
| identifier | VARCHAR | The actual external code value |
| status | VARCHAR enum | {active, retired, superseded} |
| valid_from | TIMESTAMP | When this identifier became valid |
| valid_until | TIMESTAMP NULL | When this identifier ceased to be valid |
| source_id | BIGINT NULL FK → information_sources | Where StudyNexus OBSERVED this identifier |
| replaced_by_id | BIGINT NULL FK → external_identifiers | The identifier that replaced this one |
| retirement_reason | VARCHAR NULL | {merger, reassignment, authority_retired, source_error, entity_closed} |

**Essential relationships:**
- morphTo identifiable (Institution/Programme)
- belongsTo EducationAuthority (NOT NULL — every identifier belongs to an authority's namespace)
- belongsTo InformationSource (nullable — NULL when editorially entered)
- belongsTo ExternalIdentifier (nullable, self-referential via replaced_by_id)

**Essential invariants:**
- INV-EI1: For a given (authority, type, identifier), at most ONE entity may have an active identifier
- INV-EI2: For a given (entity, authority, type), at most ONE identifier may be active
- INV-EI3: A retired identifier may be reassigned to a different entity
- INV-EI4: Historical identifiers are preserved indefinitely
- status ∈ {active, retired, superseded} (CHECK constraint)
- valid_until IS NULL OR valid_until > valid_from (CHECK constraint)
- authority_id represents ASSIGNING authority; source_id represents OBSERVING source — they MAY differ

---

## ImportBatch

**Purpose:** One import operation from one InformationSource at one point in time. Staging-level record.

| Field | Type | Purpose |
|-------|------|---------|
| id | UUID PK | Identity (staging boundary exception per BD-1) |
| source_id | BIGINT NOT NULL FK → information_sources | The source for this import |
| status | enum | {pending, parsing, parsed, verifying, verified, applying, completed, failed} |
| total_records | INT | Records found in source |
| verified_records | INT | Records passing verification |
| rejected_records | INT | Records failing verification |
| conflict_records | INT | Records conflicting with existing data |
| applied_records | INT | Records successfully applied |
| started_at | TIMESTAMP | When processing began |
| completed_at | TIMESTAMP NULL | When processing completed |
| error_log | JSONB NULL | Structured error details |
| metadata | JSONB | Source-specific metadata |

**Essential relationships:**
- belongsTo InformationSource (NOT NULL — every batch comes from a source)
- has many PendingImports

**Essential invariants:**
- Status progresses linearly through the pipeline
- completed_at is NULL until status reaches completed/failed

---

## PendingImport

**Purpose:** One record in an import batch, before it's applied to the canonical store. Staging-level record.

| Field | Type | Purpose |
|-------|------|---------|
| id | UUID PK | Identity (staging boundary exception per BD-1) |
| batch_id | UUID NOT NULL FK → import_batches | Parent batch |
| entity_type | VARCHAR | Target domain entity |
| raw_data | JSONB | Raw data from source |
| normalized_data | JSONB | Normalized, source-agnostic DTO |
| verification_status | enum | {pending, verified, rejected, conflict, duplicate} |
| verification_notes | JSONB NULL | Structured verification results |
| matching_entity_id | BIGINT NULL | If matched to existing entity (polymorphic) |
| match_confidence | DECIMAL NULL | Fuzzy match score (0.0-1.0) |
| applied_at | TIMESTAMP NULL | When record was applied |

**Essential relationships:**
- belongsTo ImportBatch (NOT NULL)
- Polymorphic reference to canonical entity via (entity_type, matching_entity_id)

**Essential invariants:**
- Staging is ephemeral — may be purged after batch completion
- match_confidence ∈ [0.0, 1.0] when not null

---

## FieldProvenance

**Purpose:** Records that a specific field of a specific canonical entity is supported by a specific source (or editorially asserted), with the value that source provided. Sparse — only for Category A (always) and Category B (on conflict) fields.

| Field | Type | Purpose |
|-------|------|---------|
| id | BIGINT PK | Identity |
| entity_type | VARCHAR | Morph alias |
| entity_id | BIGINT | FK to canonical entity (polymorphic) |
| field_name | VARCHAR | Which field (whitelisted: 7 Cat A + 6 Cat B) |
| source_id | BIGINT NULL FK → information_sources | The source; NULL = editorial assertion |
| observed_value | TEXT NULL | What the source said / admin asserted |
| confidence | SMALLINT NULL | Trust weight (0-100); NULL for retroactive records |
| verification_status | VARCHAR enum | {unverified, verified, disputed, superseded, stale} |
| observed_at | TIMESTAMP | When the source made this observation (approximation for retroactive) |
| superseded_at | TIMESTAMP NULL | When this provenance was superseded |
| superseded_by_id | BIGINT NULL FK → field_provenance | The provenance that replaced this one |
| retroactive | BOOLEAN DEFAULT FALSE | Whether this record was reconstructed after the fact |

**Essential relationships:**
- morphTo entity (Institution/Programme/etc.)
- belongsTo InformationSource (nullable — NULL for editorial)
- belongsTo FieldProvenance (nullable, self-referential via superseded_by_id)

**Essential invariants:**
- One active provenance per (entity, field, source) — enforced by partial unique index WHERE superseded_at IS NULL
- source_id IS NULL ↔ editorial assertion (no other code path produces NULL)
- field_name ∈ Category A ∪ Category B (application-level whitelist)
- verification_status ∈ {unverified, verified, disputed, superseded, stale}
- confidence ∈ [0, 100] when not null
- Supersession chain is acyclic
- Entity field values are the canonical source of truth; observed_value is audit/display only

---

## AdmissionCycle — PhaseSequence / current_phase

**Purpose:** current_phase is the authoritative domain state of where an admission cycle is in its progression. It is NOT derived from timestamps — phase transitions are business actions.

| Field | Type | Purpose |
|-------|------|---------|
| phase_sequence | JSONB NOT NULL | PhaseSequence VO: ordered phases with stable IDs, labels, and dates |
| current_phase | VARCHAR(50) NULL | The stable ID of the current phase; NULL = cycle not started |

**PhaseSequence JSONB structure:**
```json
{
  "phases": [
    { "id": "registration", "label": "Registration Period", "start_date": "2026-01-15", "end_date": "2026-03-31" },
    { "id": "application", "label": "Application Window", "start_date": "2026-04-01", "end_date": "2026-06-30" },
    { "id": "screening", "label": "Screening/Post-UTME", "start_date": "2026-07-01", "end_date": "2026-08-31" },
    { "id": "admission", "label": "Admission Lists", "start_date": "2026-09-01", "end_date": "2026-10-31" }
  ]
}
```

**Essential invariants:**
- INV-C2b: current_phase ∈ {phase.id for each phase in phase_sequence} ∪ {NULL}
- INV-C2c: current_phase = NULL ↔ cycle status = Upcoming (not yet activated)
- INV-C2d: cycle status = Active → current_phase ≠ NULL
- INV-C2f: Phase transitions follow defined sequence order (no backwards, no skipping)
- INV-C2g: After activate(), phase IDs and ordering are immutable; only labels and dates may change
- current_phase references the stable `id` field, not the mutable `label`

**Concurrency:** advancePhase() must use `DB::transaction()` + `lockForUpdate()` to prevent race conditions. Domain events dispatched after transaction commit via `DB::afterCommit()`.

---

# 8. Closed Decisions

| ID | Decision | Resolution | Confidence |
|----|----------|-----------|:----------:|
| BD-1 | Primary key strategy | Uniform bigint auto-increment for ALL canonical/domain tables; UUID only for staging boundary | CLOSED |
| BD-3 | PhaseSequence storage | JSONB PhaseSequence VO + current_phase as authoritative domain state; stable IDs for phase reference; immutable IDs after activate() | CLOSED |
| BD-5 | External identifiers | Generic external_identifiers table with partial unique indexes on active identifiers; authority_id NOT NULL; source_id nullable | CLOSED |
| ND-5 | InformationSource scope | Independent aggregate root; NO institution_id; authority_id nullable (not every source belongs to an authority) | CLOSED |
| ND-4 | Provenance model | Hybrid: entity-level JSONB + field_provenance (80/20); NO primary_source_id; source_id nullable (NULL = editorial) | CLOSED |
| DL-1 | External identifier uniqueness | Partial unique indexes WHERE status = 'active'; retirement via status + valid_until | CLOSED |
| DL-2 | field_provenance schema | observed_value TEXT; verification_status enum; derive active from superseded_at IS NULL (remove is_active) | CLOSED |
| DL-3 | field_provenance triggers | Category A (always), B (on conflict), C (never) | CLOSED |
| DL-4 | InformationSource/import hierarchy | EducationAuthority (1) > InformationSource (many) > ImportBatch (many) > PendingImport (many) | CLOSED |
| DL-5 | Provenance retention | Historical identifiers preserved indefinitely; staging ephemeral after batch completion | CLOSED |
| EP-1 | Editorial provenance semantics | source_id NULL on field_provenance = editorial assertion; no synthetic source; ON DELETE RESTRICT | CLOSED |
| IS-1 | authority_id on InformationSource | NULLable; not every source belongs to an education authority | CLOSED |
| EI-1 | source_id on ExternalIdentifier | NULLable; NULL = editorial entry; authority_id NOT NULL (every identifier belongs to a namespace) | CLOSED |
| PH-1 | current_phase reference mechanism | Stable ID (not name); immutable after activate() | CLOSED |
| CC-1 | Concurrency for advancePhase() | Pessimistic locking (lockForUpdate) + transaction-aware event dispatch | CLOSED |

---

# 9. Remaining Decisions

## NONE

All foundational decisions concerning PKs, InformationSource semantics, external identifier semantics, provenance semantics, and AdmissionCycle phase persistence are now closed.

## Implementation Conventions (no architectural approval required)

| Convention | Detail |
|-----------|--------|
| Partial unique indexes | PostgreSQL implementation of uniqueness invariants |
| CHECK constraints | status, verification_status, confidence, temporal ranges — defense-in-depth |
| morphMap values | Laravel convention for polymorphic type aliases |
| field_name whitelist | Application-level constant: 13 valid field names (7 Cat A + 6 Cat B) |
| Migration order | 15-step corrected sequence (external_identifiers created before jamb_code data migration) |
| lockForUpdate pattern | Applied in AdvanceAdmissionPhase Action |
| is_active removal | Derive from superseded_at IS NULL; add Laravel accessor + scope |
| CHECK constraint timing | Add in initial migration — zero architectural impact |

---

# 10. Exact Canonical Amendments Required

| # | Document | Amendment | Category |
|---|----------|-----------|----------|
| 1 | 05-implementation.md | Change disciplines.id from UUID to BIGINT | Domain |
| 2 | 05-implementation.md | Change cut_off_marks.id and all FKs from UUID to BIGINT | Domain |
| 3 | 05-implementation.md | Add current_phase + phase_sequence JSONB to admission_cycles; remove hardcoded timestamp columns | Domain |
| 4 | 05-implementation.md | Remove institution_id from information_sources | Domain |
| 5 | 05-implementation.md | Add authority_id BIGINT NULL FK to information_sources | Domain |
| 6 | 05-implementation.md | Add external_identifiers table (schema per §7) | Domain |
| 7 | 05-implementation.md | Add field_provenance table (schema per §7) | Domain |
| 8 | 05-implementation.md | Add education_authorities table before information_sources | Domain |
| 9 | 06-data-acquisition.md | Amend principle 5: "Provenance recorded per 80/20 model (Cat A always, Cat B on conflict, Cat C never)" | Domain |
| 10 | 03-domain.md | Remove UUID PKs from disciplines and cut_off_marks | Domain |
| 11 | 03-domain.md | Align verification_status enum: {unverified, verified, disputed, superseded, stale} | Domain |
| 12 | 02-decisions.md | Remove primary_source_id implication; align with ND-4 rejection | Domain |
| 13 | ADR-DL1 | Resolve source_id NOT NULL vs NULL: NULL = editorial assertion; ON DELETE RESTRICT | Domain |
| 14 | ADR-DL1 | Remove is_active from field_provenance; derive from superseded_at IS NULL | Architecture |
| 15 | ADR-DL1 | Add replaced_by_id and retirement_reason to external_identifiers | Domain |
| 16 | ADR-DL1 | Specify stable-ID pattern for PhaseSequence phases; immutable after activate() | Architecture |
| 17 | ADR-DL1 | Remove false concurrency claim; specify lockForUpdate + DB::afterCommit() | Architecture |
| 18 | ADR-DL1 | Add CHECK constraints for status, verification_status, confidence, temporal ranges | Implementation |
| 19 | ADR-DL1 | Make confidence nullable; add retroactive flag to field_provenance | Domain |
| 20 | ADR-DL1 | State field_provenance is NOT a complete observation log (80/20 selective model) | Domain |
| 21 | ADR-DL1 | Change information_sources.authority_id to NULLable; document when NULL | Domain |
| 22 | ADR-DL1 | Make external_identifiers.source_id NULLable; NULL = editorial entry | Domain |
| 23 | ADR-DL1 | Document: authority_id = ASSIGNING authority; source_id = OBSERVING source; they MAY differ | Domain |

---

*HARD STOP: No canonical documents modified. No baseline modified. No migrations. No code. No reconciliation execution. This document provides the semantic resolution necessary for canonical amendment and subsequent migration implementation.*
