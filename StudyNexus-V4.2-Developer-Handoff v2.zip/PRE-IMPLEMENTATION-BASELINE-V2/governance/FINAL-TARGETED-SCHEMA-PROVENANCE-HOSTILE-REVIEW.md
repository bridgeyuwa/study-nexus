# StudyNexus — Final Targeted Schema + Provenance Hostile Review

**Document Type:** Pre-Migration Freeze Gate — Second Hostile Pass
**Date:** 2026-08-17
**Status:** HOSTILE REVIEW COMPLETE
**Constraint:** No canonical documents modified. No migrations written. No application code. No silent resolution.
**Previous Verdict Under Attack:** GO FOR CANONICAL AMENDMENT — 0 blockers (from Final Pre-Migration Architecture Audit)
**Scope:** field_provenance, external_identifiers, InformationSource, current_phase, concurrency, migration order, BIGINT safety, identifier history, source_id nullability, information loss, invariant enforcement, cross-document consistency

---

# 1. Executive Verdict

## VERDICT: GO FOR CANONICAL AMENDMENT THEN MIGRATION

The previous audit's claim of "GO FOR CANONICAL AMENDMENT — 0 blockers" is **partly falsified**. This hostile review finds:

- **1 BLOCKER** — Migration ordering defect (jamb_code data migration targets a table that does not yet exist)
- **9 HIGH findings** — Schema defects that must be resolved before migration
- **8 MEDIUM findings** — Design divergences requiring canonical amendment
- **5 LOW findings** — Application-level concerns

The architecture is **directionally sound** — no fundamental redesign is required. But the previous audit missed a migration-ordering blocker, a concurrency falsehood, a dangerous source_id NULL overload, and an is_active redundancy. These are not theoretical; they will cause runtime failures or data corruption if implemented as documented.

### Finding Summary

| Severity | Count | Breakdown |
|----------|-------|-----------|
| BLOCKER | 1 | Migration ordering: data migration before target table exists |
| HIGH | 9 | Concurrency falsehood, source_id NULL overload, is_active redundancy, current_phase name coupling, identifier history gaps, ADR-DL1 internal contradiction, UUID FK type mismatches, migration ordering gaps, field_provenance EAV risk |
| MEDIUM | 8 | Retroactive provenance, status/validity coupling, provenance scope contradiction, field_name whitelist, verification_status enum gaps, valid_until/valid_to naming, PhaseSequence mutability, BIGINT upgrade safety |
| LOW | 5 | Event noise on multi-advance, metadata JSONB uncommitted, morph FK gap, domain event provenance, Typesense projection limits |

### Unresolved Design Decisions

| ID | Decision | Status |
|----|----------|--------|
| D-1 | field_provenance: is_active column or derive from superseded_at? | **Recommendation: Remove is_active** |
| D-2 | source_id: NULL for editorial or synthetic Editorial source? | **Recommendation: Synthetic source, NOT NULL** |
| D-3 | current_phase: name-based or stable-ID reference? | **Recommendation: Stable ID with immutable phase identifiers** |
| D-4 | external_identifiers: add replaced_by_id + retirement_reason? | **Recommendation: Yes, additive non-breaking** |
| D-5 | field_provenance confidence: NOT NULL DEFAULT 100 or nullable? | **Recommendation: Nullable (retroactive records cannot have meaningful confidence)** |
| D-6 | Concurrency: optimistic or pessimistic locking for advancePhase()? | **Recommendation: Pessimistic (lockForUpdate) — low contention domain** |

---

# 2. Previous Audit Findings Revalidated

| # | Finding | Previous Verdict | Revalidated? | Reason |
|---|---------|-----------------|:------------:|--------|
| F1 | cut_off_marks UUID PK/FK | HIGH | ✅ | Confirmed: UUID→BIGINT required per BD-1 |
| F2 | disciplines.id UUID | HIGH | ✅ | Confirmed: must become BIGINT |
| F3 | pending_imports.matching_entity_id UUID | MEDIUM | ✅ | Confirmed: must become BIGINT (polymorphic FK to canonical entities) |
| F4 | InformationSource missing authority_id | HIGH | ✅ | Confirmed: authority_id BIGINT NOT NULL FK required |
| F5 | institution_id on information_sources | HIGH | ✅ | Confirmed: must be removed per ND-5 |
| F6 | verification_status boolean→enum | HIGH | ✅ | Confirmed: 5-value enum is correct |
| F7 | value_hash→observed_value | HIGH | ✅ | Confirmed: TEXT is correct for admin UI conflict display |
| F8 | is_primary removed | MEDIUM | ✅ | Confirmed: redundant per uniqueness constraint |
| F9 | "No fundamental information loss" | ACCEPTABLE | ❌ **OVERTURNED** | Overconfident. 3 dangerous losses + 2 compliance gaps exist. Corrected to "no fatal loss" |
| F10 | Concurrency handled by aggregate boundary | LOW | ❌ **OVERTURNED** | FALSE. PostgreSQL MVCC + Eloquent provide no implicit locking. Race condition exists. Upgraded to HIGH |
| F11 | is_active denormalization safe | LOW | ❌ **OVERTURNED** | Consistency risk with no DB enforcement. Direct SQL corrupts invariant. Upgraded to HIGH, recommend removal |
| F12 | source_id NULL for editorial | MEDIUM | ❌ **OVERTURNED** | NULL overload + ON DELETE SET NULL creates data corruption vector. Upgraded to HIGH, recommend synthetic source |
| F13 | Migration ordering correct | ACCEPTABLE | ❌ **OVERTURNED** | BLOCKER: jamb_code migration targets external_identifiers before it exists |
| F14 | current_phase name-based reference | LOW | ❌ **OVERTURNED** | Fragile coupling with no referential integrity. Phase rename orphans current_phase. Upgraded to HIGH |

---

# 3. Field Provenance Hostile Review

## 3A. EAV Risk Analysis

**Finding: field_provenance is NOT canonical EAV, but it is EAV-adjacent with dangerous gravitational pull.**

The architectural distinction from EAV is real but requires active enforcement to maintain:

- **Why it is NOT EAV:** The canonical entity columns (e.g., `institutions.tuition BIGINT`) remain the typed, queryable, indexed source of truth. `field_provenance` is a subordinate meta-table that records *where values came from*, not *what the values are*. In true EAV, the entity table has no columns — all data lives in the EAV table. StudyNexus's entity tables have full columnar schemas.
- **The gravitational pull:** `field_provenance` retains EAV's `(attribute, value)` axes via `field_name VARCHAR(255)` and `observed_value TEXT`. Without explicit guardrails, developers can and will read `observed_value` as a substitute for entity columns, especially for conflict display in admin UIs.

**Specific EAV risks identified:**

| Risk | Current Protection | Verdict |
|------|-------------------|---------|
| Canonical business logic reads observed_value | None — no prohibition documented | **HIGH** — must be prohibited by convention and code review |
| field_name accepts arbitrary strings | None — VARCHAR(255) accepts anything | **HIGH** — needs application-level whitelist of 13 valid field names (7 Cat A + 6 Cat B) |
| TEXT creates semantic ambiguity | Accepted as tradeoff | **MEDIUM** — acceptable with type discipline |
| Second source of truth emergence | None | **HIGH** — must document that entity columns are authoritative |

**Typed-value problem:** For Value Objects (MonetaryAmount, Duration, Location, EligibilityRule), `observed_value TEXT` stores JSON. This creates problems:
- **Key ordering instability** — JSON `{"amount":150000,"currency":"NGN"}` vs `{"currency":"NGN","amount":150000}` are semantically identical but textually different, breaking equality comparison
- **Display unsuitability** — raw JSON is not human-readable in admin UIs
- **Schema evolution fragility** — if MonetaryAmount representation changes (e.g., adds `period` field), old `observed_value` records become unparseable without migration

**Recommendation:** Accept `observed_value TEXT` for MVP but add:
1. Application-level `field_name` whitelist (config/constant, not DB CHECK — the field list is domain knowledge)
2. Explicit architectural rule: *field_provenance.observed_value is NEVER read as a canonical value by domain logic. It is for audit display and conflict resolution only.*
3. Document that canonical field representation changes require a one-time migration of affected `observed_value` records

## 3B. Semantic Definition

**Definition: Selective Source Attribution Provenance — Option 2 hybrid.**

field_provenance is **NOT** a complete historical observation log. It is:

- For Category A fields: always-present source attribution for the current value
- For Category B fields: source attribution only when a conflict exists between sources
- For Category C fields: never present — no provenance at all

This contradicts 06-data-acquisition.md principle 5: *"Provenance is recorded for every data point."* That principle is **overridden by the 80/20 model**. The canonical document must be amended to reflect the actual design.

**ADR-DL1 communicates this unclearly.** The 80/20 strategy is described but the document does not explicitly state that the system is NOT a complete observation log. An amendment is required to state this unambiguously.

## 3C. Retroactive Provenance Problem

**Verdict: Conditionally acceptable with three mandatory changes.**

When a Category B field has a single source (no provenance created) and later a second source creates a conflict, the system retroactively creates provenance for the first source. The retroactive record **fabricates or loses**:

| Attribute | Available? | Impact |
|-----------|:----------:|--------|
| observed_at | ❌ Lost | Original observation time unknown; must use entity `updated_at` as approximation |
| import_batch | ❌ Lost | Original import context destroyed with staging purge |
| confidence | ❌ Fabricated | DEFAULT 100 is false certainty; must be nullable for retroactive records |
| source metadata | ❌ Lost | Original source URL, fetch context, parser version unknown |
| exact original observation | ⚠️ Partial | Current entity value is available, but intermediate edits may have occurred |
| acquisition context | ❌ Lost | Adapter class, normalization path, verification results unknown |

**Required changes:**

1. **`confidence SMALLINT NULL`** (change from NOT NULL DEFAULT 100) — retroactive records set confidence = NULL, indicating unknown
2. **Add `retroactive BOOLEAN NOT NULL DEFAULT FALSE`** — flags records reconstructed after the fact, so admin UIs display appropriate disclaimers
3. **Document `observed_at` approximation** — retroactive provenance records use `entity.updated_at` as `observed_at`, which is an approximation; display with disclaimer

These are **additive, non-breaking** schema changes. No migration penalty.

## 3D. Canonical vs Observed Value Boundary

**The critical architectural rule that must be enforced:**

> Entity column values are the canonical source of truth. `field_provenance.observed_value` is an audit/display field ONLY. Domain logic MUST NOT read `observed_value` as a substitute for entity fields.

This rule must be documented in ADR-DL1 and enforced by code review. There is no practical DB-level enforcement — but the rule must be explicit, not implicit.

---

# 4. External Identifier Hostile Review

## 4A. Status vs Validity Semantics

**Finding: DESIGN DEFECT — overlapping lifecycle concepts with zero coupling invariants.**

The schema has two independently mutable columns (`status` and `valid_until`) that both express lifecycle state, with **no enforced relationship between them**.

### Adversarial State Results

| # | State | Severity | Failure Mode |
|---|-------|----------|-------------|
| 1 | `active` + `valid_until` in past | HIGH | Stale entity receives import matches — data corruption |
| 2 | `retired` + `valid_until=NULL` | HIGH | Audit trail broken; no retirement date |
| 3 | `superseded` + `valid_until` in future | MEDIUM | Overlap ambiguity |
| 4 | `active` + `valid_from` in future | MEDIUM | Premature uniqueness lock |
| 5 | Retired → reused (same authority) | PASS | Works when coupling maintained — fragile |
| 6 | Identifier reassigned A→B | MEDIUM | Partial-update breaks coupling |
| 7 | Institution merge | HIGH | Setting `valid_until` without `status` deadlocks merge |
| 8 | Institution split | MEDIUM | Manual operations are where coupling invariants break |

### Missing Invariants

| Invariant | Enforcement | Purpose |
|-----------|-------------|---------|
| INV-EI5: `status='active' → valid_until IS NULL` | CHECK constraint | Active identifier has no end date |
| INV-EI6: `status ≠ 'active' → valid_until IS NOT NULL` | CHECK constraint | Retired/superseded must have end date |
| INV-EI7: `valid_until IS NULL OR valid_until > valid_from` | CHECK constraint | Temporal sanity |
| INV-EI8: `status='superseded'` requires replacement active identifier | Application logic | Prevent orphaned supersession |

**Recommendation:** Add CHECK constraints for INV-EI5, INV-EI6, INV-EI7. These are additive, non-breaking, and eliminate adversarial states 1-3 at the schema level.

## 4B. Authority Namespace

**Finding: The authority_id on external_identifiers and the source_id→authority_id represent DIFFERENT concepts.**

- `authority_id` = ASSIGNING authority (who assigned this identifier?)
- `source_id→authority_id` = OBSERVING authority (where did we see this identifier?)

**The invariant `external_identifiers.authority_id == information_sources.authority_id` must NOT be enforced.** Cross-authority observation is legitimate and common (e.g., NUC codes observed from JAMB brochures). Forcing equality would destroy provenance for the majority of imported identifiers.

## 4C. Historical Reassignment and Merge/Split

**Finding: The schema STORES historical identifiers but cannot INTERPRET them.**

Five distinct business events produce the same structural state (one retired row + one active row):

1. **Merger** — A merged into B; code transferred
2. **Reassignment** — JAMB deliberately moved code from A to B
3. **Authority retirement** — JAMB retired code from A, later assigned to B
4. **Source error** — Incorrect code in import, later corrected
5. **Entity closure** — A closed, B is new entity with same code

These are **causally distinct** but **structurally indistinguishable** in the current schema.

**Missing columns identified:**

| Column | Type | Purpose |
|--------|------|---------|
| `replaced_by_id` | BIGINT nullable FK → external_identifiers.id | Links retired identifier to its replacement |
| `retirement_reason` | VARCHAR(50) nullable | Discriminator: `merger`, `reassignment`, `authority_retired`, `source_error`, `entity_closed` |

**Recommendation:** Add both columns. They are **additive, non-breaking**. No migration penalty. The `replaced_by_id` enables reassignment chain queries; `retirement_reason` enables causal interpretation of historical events.

## 4D. Uniqueness

**The partial unique index `WHERE status = 'active'` is correct and sufficient** for ensuring at most one active identifier per (authority, type, identifier) and per (entity, authority, type). No change needed.

---

# 5. InformationSource Hostile Review

## Authority Relationship

**The EducationAuthority → InformationSource → ImportBatch → PendingImport hierarchy is correct.**

Key findings:

1. **authority_id NOT NULL on information_sources** is required (confirmed by F5 fix) — every source is published by an authority
2. **Cross-authority observation is valid** — see §4B above
3. **InformationSource as independent aggregate root** (ND-5) is correct — JAMB brochures cover multiple institutions

## Source/Authority Consistency

The invariant that **should NOT hold** (authority_id on external_identifiers == source→authority_id) is addressed in §4B. The invariant that **should hold** is:

- Every InformationSource has a valid authority_id (FK enforced)
- Every ImportBatch references a valid source (FK enforced)
- When an InformationSource is deprecated, its import batches should be flagged but not cascade-deleted (application-level concern)

No schema changes required for InformationSource beyond the already-identified authority_id addition.

---

# 6. AdmissionCycle / current_phase Hostile Review

## NULL Semantics

**NULL for current_phase means: cycle has not started (status = Upcoming).**

This is the correct domain interpretation but it is **unstated in the schema**. There is no CHECK constraint correlating `current_phase` NULLability with `status`. Required invariants:

| ID | Invariant | Severity |
|----|-----------|----------|
| INV-C2c | `current_phase = NULL ⟺ status = 'Upcoming'` | HIGH |
| INV-C2d | `status = 'Active' → current_phase ≠ NULL` | HIGH |
| INV-C2e | `status ∈ {'Closed','Archived'} → current_phase = last(phase_sequence)` | MEDIUM |
| INV-C2g | `phase_sequence.phase_ids` are immutable after `activate()` | HIGH |

## Name-Based Reference — DESIGN DEFECT

**`current_phase VARCHAR(50)` references a phase in `phase_sequence JSONB` by string name match. This is a dangling reference with no referential integrity.**

Failure modes:

| Operation | Result | Recovery |
|-----------|--------|----------|
| Rename phase in phase_sequence | current_phase orphaned, cycle frozen | **None defined** |
| Delete phase from phase_sequence | current_phase orphaned, close() blocked | **None defined** |
| Typo in phase name | Silent mismatch | Manual DB fix |
| Reorder phases before current position | nextAfter() returns wrong phase | Semantic corruption |

**Recommendation: Stable-Identifier Pattern**

Restructure PhaseSequence JSONB to use stable immutable IDs:

```json
{
  "phases": [
    { "id": "registration", "label": "Registration", "start": "...", "end": "..." },
    { "id": "application", "label": "Application", "start": "...", "end": "..." }
  ]
}
```

- `id`: stable, immutable after `activate()` — referenced by `current_phase`
- `label`: freely renamable display name — does not orphan `current_phase`
- **INV-C2g**: After `activate()`, phase IDs and ordering are frozen; only dates and labels may change

## Phase Transitions and Mutability

- **Backwards movement**: Correctly forbidden. No `retreatPhase()` operation.
- **Skipping**: Achieved via multi-advance (each intermediate phase entered briefly). Creates event noise but is acceptable for MVP.
- **Phase reordering after activation**: Must be prevented by INV-C2g.
- **Archive/close current_phase value**: Must be explicitly specified (set to last phase in sequence, not NULL).

## Concurrency

**The previous audit's claim that "aggregate boundary / PostgreSQL" provides concurrency protection is FALSE.**

PostgreSQL MVCC allows multiple concurrent reads of the same row. Laravel Eloquent has **no built-in optimistic locking**. The `update()` method checks affected rows only against the PK WHERE clause, not a version column.

**Race condition scenario:**
1. Admin A and B both load cycle at phase "applications_open"
2. Both call `advancePhase()` → both validate against "applications_open" (stale data)
3. Both UPDATE succeeds (WHERE id = 42, 1 row affected)
4. Both dispatch `PhaseAdvanced` event → **duplicate side effects** (duplicate notifications, double search reindex)

**Required fix: Pessimistic locking in AdvanceAdmissionPhase Action**

```php
class AdvanceAdmissionPhase
{
    public function execute(AdmissionCycle $cycle): void
    {
        DB::transaction(function () use ($cycle) {
            $locked = AdmissionCycle::lockForUpdate()->findOrFail($cycle->id);
            $locked->advancePhase();  // validates against FRESH data
            $locked->save();
        });
        // Dispatch event AFTER commit (transaction-aware)
        event(new AdmissionCyclePhaseAdvanced(...));
    }
}
```

**Severity: HIGH** — The false claim of concurrency protection is worse than no claim; it prevents implementation of actual protection.

---

# 7. Migration Dependency and Ordering Audit

## BLOCKER: Data Migration Before Target Table Exists

The previous audit proposes this sequence:

| Step | Table | Action |
|------|-------|--------|
| 4 | institutions | "remove jamb_code, **migrate data to external_identifiers**" |
| 5 | programmes | "remove jamb_code, **migrate data to external_identifiers**" |
| 8 | external_identifiers | "**CREATE TABLE**" |

Steps 4 and 5 issue `INSERT INTO external_identifiers ...` but external_identifiers does not exist until Step 8. **This is a guaranteed runtime failure** with error: `relation "external_identifiers" does not exist`.

**Severity: BLOCKER** — must be corrected before any migration is written.

## Additional Ordering Defects

| # | Finding | Severity |
|---|---------|----------|
| 7.2 | 05-implementation.md places information_sources BEFORE education_authorities despite FK dependency | HIGH |
| 7.3 | import_batches creation step missing from executable migration list | HIGH |
| 7.4 | FK creation timing not specified in migration steps | MEDIUM |

## Corrected Safe Migration Sequence

```
Phase 1: Reference Data (zero FK dependencies)
  Step  1: education_authorities    → CREATE TABLE + seed (JAMB, NUC, WAEC, NBTE, NCCE)

Phase 2: Provenance-Origin Tables (FK → Phase 1 only)
  Step  2: information_sources      → CREATE TABLE WITH authority_id FK → education_authorities
                                     + seed synthetic "Editorial Override" source (id = 1)

Phase 3: Reference Data (continued)
  Step  3: disciplines              → CREATE TABLE with BIGINT PK + seed

Phase 4: Domain Aggregate Roots (FK → Phases 1-3)
  Step  4: institutions             → CREATE TABLE WITHOUT jamb_code
  Step  5: programmes               → CREATE TABLE WITHOUT jamb_code
                                     + institution_id FK → institutions
                                     + discipline_id BIGINT FK → disciplines
  Step  6: admission_cycles         → CREATE TABLE WITH phase_sequence JSONB + current_phase
                                     + institution_id FK → institutions
  Step  7: cut_off_marks            → CREATE TABLE with BIGINT PK + BIGINT FKs

Phase 5: Supporting Infrastructure (FK → Phases 1-4)
  Step  8: external_identifiers     → CREATE TABLE + indexes + constraints
                                     + authority_id FK → education_authorities
                                     + source_id BIGINT NOT NULL FK → information_sources
  Step  9: field_provenance         → CREATE TABLE + indexes + constraints
                                     + source_id BIGINT NOT NULL FK → information_sources

Phase 6: Data Migration (all targets now exist)
  Step 10: MIGRATE jamb_code        → INSERT INTO external_identifiers from institutions.jamb_code
  Step 11: MIGRATE jamb_code        → INSERT INTO external_identifiers from programmes.jamb_code
  Step 12: DROP jamb_code           → ALTER TABLE institutions DROP COLUMN jamb_code
  Step 13: DROP jamb_code           → ALTER TABLE programmes DROP COLUMN jamb_code

Phase 7: Staging Infrastructure
  Step 14: import_batches           → CREATE TABLE (UUID PK — staging boundary)
  Step 15: pending_imports          → CREATE TABLE (UUID PK — staging boundary)
```

**Verification:** Every FK target exists before the FK is created. Every data-migration target exists before the INSERT. Zero forward references. Zero circular dependencies.

---

# 8. Information-Loss Audit

**The previous audit's claim of "No fundamental information loss" is OVERTURNED.** The correct phrasing is:

> **"No fatal information loss. Three dangerous losses exist: (1) unmapped source fields discarded during normalization, (2) fuzzy-match evidence below the 0.50 threshold, and (3) human review reasoning not persisted. Two compliance-audit gaps exist: rejected records destroyed with staging, and intermediate verification reasoning lost on staging purge. All dangerous losses and compliance gaps have identified mitigations. All remaining losses are acceptable for MVP by design."**

### Complete Loss Classification

| # | Loss Point | Classification | Recoverable? |
|---|-----------|----------------|:------------:|
| 1 | Raw HTTP/PDF bytes before adapter parsing | Acceptable MVP | Irrecoverable |
| 2 | Source document structure/format | Acceptable MVP | Irrecoverable |
| 3 | Adapter-specific metadata (partial in import_batches.metadata) | Acceptable MVP | Partial |
| 4 | Unmapped source fields (raw_data vs normalized_data) | **Dangerous** | Irrecoverable |
| 5 | Fuzzy match candidates below threshold 0.50 | **Dangerous** | Irrecoverable |
| 6 | Verification notes/intermediate reasoning | **Compliance/audit** | Irrecoverable after staging purge |
| 7 | Human review reasoning (why, not just what) | **Dangerous** | Irrecoverable |
| 8 | Rejected records (staging ephemerality) | **Compliance/audit** | If staging purged: irrecoverable |
| 9 | Category B non-conflict fields — source attribution | Acceptable MVP | Partial |
| 10 | Category C fields — zero provenance | Acceptable MVP | Partial (activity log) |
| 11 | Retroactive provenance observation timing | Acceptable MVP | Irrecoverable |
| 12 | Staging data after successful import | Acceptable MVP (by design) | Irrecoverable |
| 13 | Import batch metadata aggregation | Acceptable MVP | Partial |
| 14 | Entity-level provenance JSONB recalculation | Acceptable MVP | Recoverable (activity log) |
| 15 | External identifier source attribution when NULL | Acceptable MVP | Partial (activity log) |
| 16 | Domain event payloads (ephemeral) | Acceptable MVP | Irrecoverable |
| 17 | Typesense projection — no field-level provenance | Acceptable MVP | Recoverable (re-query canonical) |

### Required Mitigations for Dangerous Losses

| Loss | Mitigation | Cost |
|------|-----------|------|
| #4 Unmapped source fields | Document intentionally discarded fields per adapter; consider raw_data archive table | Low — documentation effort |
| #5 Fuzzy match below threshold | Log all comparisons to durable `match_audit_log` table | Low — one additional table |
| #7 Human review reasoning | Add mandatory `reason` field to admin review UI; persist in activity log `properties` | Low — UI + persistence |

---

# 9. Database/Application/Domain Invariant Matrix

| # | Invariant | DB | APP | DOM | PROSE | Current State | Required Change |
|---|-----------|:--:|:---:|:---:|:-----:|---------------|----------------|
| 1 | External identifier uniqueness (active) | ✅ | — | — | — | Strong | None |
| 2 | External identifier per-entity uniqueness | ✅ | — | — | — | Strong | None |
| 3 | Authority namespace (FK) | ✅ | — | — | — | Strong | None |
| 4 | Provenance lifecycle supersede chain | ✅ | ✅ | — | — | Partial | Add CHECK for supersede atomicity |
| 5 | is_active = superseded_at IS NULL | — | ✅ | ✅ | — | **Weak** | Add CHECK constraint OR remove is_active |
| 6 | Supersession chain acyclicity | — | ✅ | — | — | Weak | Acceptable (requires deliberate bypass) |
| 7 | Category A/B/C classification | — | ✅ | — | — | Weak | Acceptable (code discipline) |
| 8 | current_phase ∈ PhaseSequence | — | ✅ | ✅ | — | **Weak** | Add stable-ID pattern + freeze after activate |
| 9 | Phase transition ordering | — | ✅ | ✅ | — | Moderate | Add lockForUpdate for concurrency |
| 10 | Editorial provenance (source_id NULL) | — | ✅ | — | — | **Prose convention** | Replace NULL with synthetic editorial source |
| 11 | Source/authority consistency | — | ✅ | — | — | Weak | Document that cross-authority is valid |
| 12 | Identifier lifecycle transitions | — | ✅ | — | ✅ | **Prose** | Add status transition guard |
| 13 | Canonical vs provenance value boundary | — | ✅ | — | — | Weak | Document architectural rule |
| 14 | Morph entity integrity | — | — | — | ✅ | **Known gap** | Standard Laravel polymorphic tradeoff |
| 15 | verification_status enum validity | — | — | — | ✅ | **Prose** | Add CHECK constraint |
| 16 | confidence range [0,100] | — | ✅ | — | — | Weak | Add CHECK constraint |
| 17 | valid_until > valid_from | — | — | — | ✅ | **Prose** | Add CHECK constraint |
| 18 | status ∈ {active, retired, superseded} | — | — | — | ✅ | **Prose** | Add CHECK constraint |

### Trivially Addable DB CHECK Constraints

These four constraints have **zero architectural impact** and should be in the initial migration:

```sql
-- field_provenance
ALTER TABLE field_provenance ADD CONSTRAINT fp_confidence_check
  CHECK (confidence >= 0 AND confidence <= 100);
ALTER TABLE field_provenance ADD CONSTRAINT fp_verification_check
  CHECK (verification_status IN ('unverified','verified','disputed','superseded','stale'));

-- external_identifiers
ALTER TABLE external_identifiers ADD CONSTRAINT ei_status_check
  CHECK (status IN ('active','retired','superseded'));
ALTER TABLE external_identifiers ADD CONSTRAINT ei_temporal_check
  CHECK (valid_until IS NULL OR valid_until > valid_from);
```

---

# 10. Canonical Contradiction Matrix

| ID | Term | Document A | Claim in A | Document B | Claim in B | Severity |
|----|------|-----------|-----------|-----------|-----------|----------|
| C1 | disciplines.id | 05-implementation | Implied UUID (programmes.discipline_id UUID FK) | ADR-DL1/BD-1 | Uniform bigint | HIGH |
| C2 | cut_off_marks.id + FKs | 03-domain | UUID PK + UUID FKs | ADR-DL1/BD-1 | All bigint | HIGH |
| C3 | pending_imports.matching_entity_id | 06-data-acquisition | UUID | BD-1 | BIGINT (canonical entities) | HIGH |
| C4 | institution_id on information_sources | 05-implementation | FK present | ND-5 | Must be removed | HIGH |
| C5 | current_phase on admission_cycles | 05-implementation | Not present (time-derived) | BD-3 | JSONB + current_phase as authoritative state | HIGH |
| C6 | phase_sequence column | 05-implementation | Not present | BD-3 | JSONB NOT NULL | HIGH |
| C7 | external_identifiers table | All canonical | Not defined | BD-5 | Required from day one | HIGH |
| C8 | field_provenance table | All canonical | Not defined | ND-4 | Required from day one | HIGH |
| C9 | Provenance scope | 06-data-acquisition | "Every data point" | ND-4 80/20 | Category C gets no provenance | HIGH |
| C10 | authority_id on information_sources | 05-implementation | Not present | F5 fix | BIGINT NOT NULL FK required | HIGH |
| C11 | source_id nullability | ADR-DL1 schema | BIGINT NOT NULL | ADR-DL1 prose | NULL for editorial | HIGH |
| C12 | observed_value vs value_hash | ADR-DL1 | observed_value TEXT | Second-Order | value_hash VARCHAR(64) | HIGH |
| C13 | verification_status design | ADR-DL1 | 5-value enum | Second-Order | boolean is_verified | HIGH |
| C14 | Active indicator mechanism | ADR-DL1 | status column | Second-Order | valid_to IS NULL | HIGH |
| C15 | is_active on field_provenance | ADR-DL1 | Present (denormalized) | Second-Order | Not present | MEDIUM |
| C16 | is_primary on external_identifiers | ADR-DL1 | Removed | Second-Order | Present | MEDIUM |
| C17 | valid_until vs valid_to naming | ADR-DL1 | valid_until | Second-Order | valid_to | MEDIUM |
| C18 | primary_source_id | 02-decisions | Implied single source_id | ND-4 | Rejected — no primary_source_id | MEDIUM |
| C19 | verification_status enum values | 05-implementation | Unspecified | Second-Order | {unverified,verified,unreliable,deprecated} | MEDIUM |
| C20 | admission_cycles.institution_id | 05-implementation | FK → institutions | Second-Order | Should be education_authority_id | HIGH |

**Total: 20 contradictions (13 HIGH, 7 MEDIUM)**

All contradictions result from canonical documents being frozen before the data lineage architecture was resolved. They are expected and are the reason canonical amendment is required.

---

# 11. Decisions That Are Actually Closed

These decisions have been validated under hostile review and survive. No further architectural debate is required:

| ID | Decision | Resolution | Confidence |
|----|----------|-----------|:----------:|
| BD-1 | Primary key strategy | Uniform bigint auto-increment for ALL canonical/domain tables. UUID only for staging boundary (import_batches, pending_imports). | HIGH |
| BD-3 | PhaseSequence storage | JSONB PhaseSequence VO + current_phase as authoritative domain state. NOT time-derived. | HIGH |
| BD-5 | External identifiers | Generic external_identifiers table from day one. Partial unique indexes on active identifiers. | HIGH |
| ND-5 | InformationSource scope | Independent aggregate root, NO institution_id. Covers multiple institutions. | HIGH |
| ND-4 | Provenance model | Hybrid: entity-level JSONB + field_provenance (80/20). NO primary_source_id. | HIGH |
| D-verified | value_hash → observed_value | TEXT is correct for admin UI conflict display. Hashes prevent display. | HIGH |
| D-verified | boolean → verification_status enum | 5-value enum needed to express disputed/stale/superseded. | HIGH |
| D-verified | is_primary removal | Redundant per uniqueness constraint. | HIGH |
| D-verified | Cross-authority observation | authority_id on external_identifiers ≠ source→authority_id is valid. | HIGH |

---

# 12. Decisions Still Open

| ID | Question | Options | Recommendation | Migration Blocking? |
|----|----------|---------|---------------|:-------------------:|
| D-1 | Should is_active be removed from field_provenance? | A: Keep (current) / B: Remove, derive from superseded_at / C: Generated column | **B: Remove** — eliminates consistency risk at zero performance cost | No (additive change) |
| D-2 | How to represent editorial provenance? | A: NULL source_id / B: Synthetic Editorial source / C: Separate assertion_type | **B: Synthetic source** — eliminates NULL ambiguity, preserves FK integrity | Yes (schema change before migration) |
| D-3 | Should current_phase use stable IDs instead of names? | A: Name-based (current) / B: Stable ID with mutable labels | **B: Stable ID** — prevents orphaning on rename | Yes (VO design before implementation) |
| D-4 | Should external_identifiers have replaced_by_id + retirement_reason? | A: No (current) / B: Yes | **B: Yes** — enables reassignment chain and causal interpretation | No (additive columns) |
| D-5 | Should field_provenance.confidence be nullable? | A: NOT NULL DEFAULT 100 / B: Nullable | **B: Nullable** — retroactive records cannot have meaningful confidence | No (additive change) |
| D-6 | Concurrency mechanism for advancePhase()? | A: None (current claim) / B: Pessimistic lock / C: Optimistic lock | **B: Pessimistic lockForUpdate** — low contention, simple, explicit | No (implementation pattern) |

---

# 13. Required Canonical Amendments

These amendments are genuinely necessary. No cosmetic amendments are included.

| # | Document | Amendment | Severity |
|---|----------|-----------|----------|
| 1 | 05-implementation.md | Change disciplines.id from UUID to BIGINT GENERATED ALWAYS AS IDENTITY | HIGH |
| 2 | 05-implementation.md | Change cut_off_marks.id and all FKs from UUID to BIGINT | HIGH |
| 3 | 05-implementation.md | Add current_phase VARCHAR(50) and phase_sequence JSONB NOT NULL to admission_cycles; remove opens_at/closes_at/results_at | HIGH |
| 4 | 05-implementation.md | Remove institution_id from information_sources | HIGH |
| 5 | 05-implementation.md | Add authority_id BIGINT NOT NULL FK to information_sources | HIGH |
| 6 | 05-implementation.md | Add external_identifiers table (full schema per ADR-DL1) | HIGH |
| 7 | 05-implementation.md | Add field_provenance table (full schema per ADR-DL1) | HIGH |
| 8 | 05-implementation.md | Add education_authorities table before information_sources | HIGH |
| 9 | 06-data-acquisition.md | Amend principle 5: "Provenance is recorded for Category A and B fields per the 80/20 model" | HIGH |
| 10 | 03-domain.md | Remove UUID PKs from disciplines and cut_off_marks | HIGH |
| 11 | 03-domain.md | Align verification_status enum with ADR-DL1 5-value enum | MEDIUM |
| 12 | 02-decisions.md | Remove primary_source_id implication; align with ND-4 rejection | MEDIUM |
| 13 | ADR-DL1 | Resolve source_id NOT NULL vs NULL contradiction: adopt NOT NULL + synthetic editorial source | HIGH |
| 14 | ADR-DL1 | Remove is_active from field_provenance; derive from superseded_at IS NULL | HIGH |
| 15 | ADR-DL1 | Add replaced_by_id and retirement_reason to external_identifiers | MEDIUM |
| 16 | ADR-DL1 | Specify stable-ID pattern for PhaseSequence phases | HIGH |
| 17 | ADR-DL1 | Remove false concurrency claim; specify lockForUpdate pattern | HIGH |
| 18 | ADR-DL1 | Add CHECK constraints for status, verification_status, confidence, temporal ranges | MEDIUM |
| 19 | ADR-DL1 | Make confidence nullable; add retroactive flag | MEDIUM |
| 20 | ADR-DL1 | State explicitly that field_provenance is NOT a complete observation log | MEDIUM |

---

# 14. Final Freeze Recommendation

## GO FOR CANONICAL AMENDMENT THEN MIGRATION

### Why not GO FOR MIGRATION?

One BLOCKER exists: the migration ordering defect where jamb_code data migration targets external_identifiers before that table is created. This is a genuine sequencing error that will cause a runtime migration failure. It must be corrected in the canonical migration order before any migration file is written.

Additionally, 9 HIGH findings require resolution:
- The concurrency falsehood (advancePhase race condition) must be corrected — the canonical documents must not claim protection that Laravel/PostgreSQL do not provide
- The source_id NULL overload creates a data corruption vector via ON DELETE SET NULL
- The is_active redundancy creates an unenforced invariant that direct SQL can violate
- The current_phase name coupling creates orphaned references on phase rename
- The identifier history gaps (replaced_by_id, retirement_reason) prevent interpretation of historical events
- The ADR-DL1 internal contradiction on source_id nullability must be resolved
- The UUID FK type mismatches in cut_off_marks make the schema non-creatable as documented
- The missing import_batches step in migration sequence

### Why not HOLD?

No finding requires an architectural redesign. All HIGH findings have clear, bounded resolutions:
- Concurrency: Add lockForUpdate (1 Action class change)
- source_id NULL: Add synthetic editorial source + change to NOT NULL (1 seed record + schema change)
- is_active: Remove column, use accessor (1 column drop + 1 scope)
- current_phase: Stable-ID pattern in PhaseSequence VO (VO redesign, no schema change)
- Identifier history: Add 2 nullable columns (additive, non-breaking)
- UUID mismatches: Already decided by BD-1; canonical amendment applies the decision
- Migration order: Reorder steps (procedural, no design change)

### Why not NO-GO?

The foundational architecture is sound:
- BD-1 (bigint PKs) is correct
- BD-3 (JSONB PhaseSequence + current_phase) is directionally correct; the stable-ID fix is a refinement
- BD-5 (generic external_identifiers) is correct
- ND-5 (InformationSource as independent aggregate) is correct
- ND-4 (hybrid provenance 80/20) is correct; the EAV boundary is maintainable with documented rules
- The domain model (5 aggregate roots, 3 child entities, 3 supporting entities) is coherent
- The data acquisition pipeline architecture is sound
- Laravel Beyond CRUD architecture is appropriate

### Conditions for MIGRATION

After canonical amendment, migration implementation may begin when:

1. ✅ Migration ordering corrected (15-step sequence in §7)
2. ✅ is_active removed from field_provenance
3. ✅ source_id changed to NOT NULL with synthetic editorial source
4. ✅ PhaseSequence stable-ID pattern documented in ADR-DL1
5. ✅ Concurrency pattern (lockForUpdate) specified for advancePhase()
6. ✅ replaced_by_id and retirement_reason added to external_identifiers
7. ✅ CHECK constraints added for status, verification_status, confidence, temporal ranges
8. ✅ All 20 canonical contradictions resolved
9. ✅ field_provenance "NOT a complete observation log" stated explicitly
10. ✅ "No fundamental information loss" claim replaced with corrected wording

### Compact Finding Table

| ID | Finding | Severity | Migration Blocking? | Required Action |
|----|---------|----------|:-------------------:|----------------|
| B1 | jamb_code migration targets external_identifiers before table exists | BLOCKER | **YES** | Reorder migration: create external_identifiers at Step 8, migrate data at Steps 10-11 |
| H1 | advancePhase() race condition — no concurrency protection | HIGH | No | Specify lockForUpdate in Action; remove false claims |
| H2 | source_id NULL overloads semantics; ON DELETE SET NULL corrupts data | HIGH | Yes | Replace with synthetic editorial source, make NOT NULL |
| H3 | is_active + superseded_at duplicated state, no DB enforcement | HIGH | No | Remove is_active, derive from superseded_at IS NULL |
| H4 | current_phase name-based reference orphaned by phase rename | HIGH | Yes | Adopt stable-ID pattern with immutable phase IDs |
| H5 | external_identifiers cannot distinguish merger/reassignment/source error | HIGH | No | Add replaced_by_id + retirement_reason |
| H6 | ADR-DL1 internal contradiction: source_id NOT NULL vs NULL | HIGH | Yes | Resolve in favor of NOT NULL + synthetic editorial source |
| H7 | cut_off_marks UUID FKs → BIGINT PKs: type mismatch, schema not creatable | HIGH | Yes | Change all UUID FKs to BIGINT per BD-1 |
| H8 | programmes.discipline_id UUID FK not tracked as migration step | HIGH | Yes | Add explicit migration step |
| H9 | import_batches missing from migration sequence | HIGH | No | Add Step 14 |
| M1 | Retroactive provenance fabricates confidence and observed_at | MEDIUM | No | Make confidence nullable; add retroactive flag |
| M2 | status/valid_until coupling has zero invariants | MEDIUM | No | Add CHECK constraints INV-EI5/EI6/EI7 |
| M3 | 06-data-acquisition.md "every data point" vs Category C exclusion | MEDIUM | Yes | Amend canonical document |
| M4 | field_name has no whitelist — accepts arbitrary strings | MEDIUM | No | Application-level whitelist of 13 valid fields |
| M5 | verification_status enum values differ across documents | MEDIUM | Yes | Align in canonical amendment |
| M6 | valid_until vs valid_to naming inconsistency | MEDIUM | Yes | Standardize to valid_until in canonical |
| M7 | PhaseSequence mutable after activate() — phase rename/delete corrupts state | MEDIUM | Yes | Add INV-C2g: phase IDs immutable after activate |
| M8 | BIGINT migration approach has 3 unaddressed upgrade failure modes | MEDIUM | No | Document: (a) retain UUID until verification, (b) concurrent-write trigger, (c) pg_dump snapshot |
| L1 | Multi-advance creates synthetic domain events | LOW | No | Acceptable for MVP; consider advanceMultiplePhases() later |
| L2 | metadata JSONB uncommitted as retirement_reason carrier | LOW | No | Add explicit column instead |
| L3 | Polymorphic FK gap on entity_type/entity_id | LOW | No | Standard Laravel tradeoff |
| L4 | Domain events carry no provenance | LOW | No | Acceptable — events are fire-and-forget |
| L5 | Typesense projection lacks field-level provenance | LOW | No | By design — search is a read model |

---

*This hostile review is a FREEZE GATE. No migrations, Eloquent models, Actions, Filament resources, or production code shall be written until the canonical amendments in §13 are applied and the conditions in §14 are satisfied.*
