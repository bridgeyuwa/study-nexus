# Second-Order Architectural Review

**Project:** StudyNexus  
**Document Type:** Second-Order Architectural Validation  
**Review Scope:** BD-1, BD-3, BD-5, ND-4, ND-5  
**Date:** 2026-03-04  
**Status:** CONDITIONAL GO  

---

## Table of Contents

1. [Executive Verdict](#1-executive-verdict)
2. [Decision Audit](#2-decision-audit)
3. [Primary Key Architecture](#3-primary-key-architecture)
4. [Admission Phase Architecture](#4-admission-phase-architecture)
5. [Data Lineage Architecture](#5-data-lineage-architecture)
6. [InformationSource](#6-informationsource)
7. [ExternalIdentifier](#7-externalidentifier)
8. [Provenance](#8-provenance)
9. [Observation vs Canonical Assertion](#9-observation-vs-canonical-assertion)
10. [Reconciliation](#10-reconciliation)
11. [Publication](#11-publication)
12. [Acquisition Boundary](#12-acquisition-boundary)
13. [Entity Merge/Split Implications](#13-entity-mergesplit-implications)
14. [Failure Scenarios](#14-failure-scenarios)
15. [Schema Sketch](#15-schema-sketch)
16. [Index and Constraint Strategy](#16-index-and-constraint-strategy)
17. [Laravel/Eloquent Implications](#17-laraveleloquent-implications)
18. [Typesense Implications](#18-typesense-implications)
19. [Canonical Document Amendments](#19-canonical-document-amendments)
20. [ADR-DL1](#20-adr-dl1)
21. [Final Human Decisions](#21-final-human-decisions)

---

## 1. Executive Verdict

**VERDICT: CONDITIONAL GO**

Three of five decisions are genuinely resolved. Two remain partially unresolved. The provenance model (ND-4) requires more specificity before migrations, but the directional architecture is sound enough to proceed with schema creation if three specific conditions are met.

**What is actually resolved:**

- BD-1: Uniform bigint for all domain PKs — RESOLVED
- BD-3: JSONB PhaseSequence + current_phase — RESOLVED
- ND-5: InformationSource without institution_id — RESOLVED

**What remains partially unresolved:**

- BD-5/External identifiers: Design is resolved but exact constraint strategy needs confirmation
- ND-4/Provenance: Direction is correct but field_provenance trigger conditions and retention policy need specification

**What must happen before migrations:**

1. Three bugs in 05-implementation.md must be corrected (cut_off_marks FK type mismatch, missing current_phase, incorrect institution_id on information_sources)
2. ADR-DL1 must be written and approved
3. field_provenance trigger conditions must be specified (even if the table is created empty)
4. External identifier uniqueness constraints must be confirmed

---

## 2. Decision Audit

| Decision | Previous (First Review) | Revised (This Review) | Verdict | Confidence | Reason |
|----------|------------------------|----------------------|---------|------------|--------|
| BD-1 | Uniform bigint for all domain PKs | UNIFORM BIGINT — confirmed | APPROVE | HIGH | No domain invariant requires UUID. Single-writer PostgreSQL. Explicit seeded IDs for reference data. FK type mismatch in cut_off_marks must be fixed. |
| BD-3 | JSONB + current_phase | JSONB + current_phase — confirmed, current_phase is AUTHORITATIVE STATE not projection | APPROVE | HIGH | advancePhase() is a domain operation that emits a domain event. current_phase is set by the operation, not derived from time. This makes it authoritative state within the aggregate boundary. |
| BD-5 | Generic external_identifiers from day one | Generic external_identifiers — confirmed, with specific uniqueness constraints | APPROVE | HIGH | P5-compliant, provenance-aligned, zero migration cost for new authorities. Polymorphic design is standard Laravel. |
| ND-5 | InformationSource without institution_id | NO institution_id — confirmed | APPROVE | HIGH | A source IS a provenance origin. Entity-to-source relationships are through provenance. The JAMB brochure example proves institution_id is incorrect. |
| ND-4 | Hybrid provenance (entity JSONB + field_provenance, no primary_source_id) | Entity-level JSONB + field_provenance table from day one + no primary_source_id — confirmed, but trigger conditions need specification | CONDITIONAL APPROVE | MEDIUM-HIGH | Direction is correct. The 80/20 model is sound: most entities need only entity-level provenance only; multi-source entities need field_provenance. Trigger conditions and retention policy must be specified before migration. |

---

## 3. Primary Key Architecture

### Analysis

StudyNexus's architecture is:

- Laravel 13 monolith with single-writer PostgreSQL (ADR-2)
- External acquisition pipelines that import through the application's domain API
- Import/staging boundary: adapters → staging → verification → canonical store
- Business identifiers (JAMB code, NUC code, slug, name) used for matching, not PKs
- Public URLs use slugs, not PKs
- Typesense document IDs are strings (bigint cast to string works fine)
- No distributed writes, no multi-primary replication, no cross-service PK collision risk

### Comparison

**bigint auto-increment (RECOMMENDED):**

- 8 bytes, sequential inserts, optimal B-tree behavior
- Laravel default — zero configuration, zero custom traits
- `$model->id` is int — standard everywhere
- Explicit seeded IDs for reference data achieve cross-environment stability
- FK type homogeneity — every FK is bigint, no cognitive tax
- Storage savings: ~50% vs UUID for PK+FK columns across 56+ tables
- Public URLs use slugs — PK never exposed in URLs
- Sequential IDs reveal creation order, but this is not a security concern for an education platform (not a financial or auth system)
- Compatible with all Spatie packages, Filament, Scout out of the box

**UUID:**

- 16 bytes, random inserts cause B-tree fragmentation (UUIDv4)
- Requires custom trait on every model, non-default migration pattern
- `$model->id` is string — deviations throughout codebase
- Justified for distributed writes — StudyNexus has none
- Global uniqueness — useful for multi-service, not applicable here
- Cross-environment seeding "automatic" — but explicit seeded bigint IDs are simpler
- FK type homogeneity — also homogeneous if used everywhere, but 2x storage

**UUIDv7:**

- Time-ordered, reduces B-tree fragmentation vs UUIDv4
- Still 16 bytes, still requires custom trait
- RFC 9562 standardized
- Better than UUIDv4 but still worse than bigint for StudyNexus

**ULID:**

- Similar to UUIDv7, 128 bits, time-ordered
- 26-character string representation
- Less Laravel ecosystem support
- No compelling advantage over bigint for this use case

**Mixed strategies:**

- Cognitive tax of remembering which tables use which type
- FK type mismatches at boundaries
- The exact bug found in cut_off_marks (UUID FKs referencing bigint PKs) demonstrates the concrete harm

### Is there ANY legitimate reason for disciplines to retain UUIDs?

No. The only argument was "cross-environment seeding stability," which explicit seeded bigint IDs achieve with less complexity. Other reference data (education_authorities, countries) also need stable IDs and will use explicit seeded bigint. No special case for disciplines is justified.

### Decision

**Uniform bigint auto-increment for ALL domain and reference tables.**

UUID ONLY for import/staging infrastructure tables (import_batches, pending_imports) which are outside the canonical domain boundary and may receive concurrent writes from parallel import jobs.

### Rationale

1. Single-writer PostgreSQL eliminates the primary justification for UUID (globally unique IDs for distributed writes)
2. Laravel convention alignment — zero deviation from defaults
3. FK type homogeneity — eliminates the class of bugs exemplified by cut_off_marks
4. Storage and performance — measurable benefit at StudyNexus scale
5. Explicit seeded IDs solve cross-environment stability for reference data
6. Public URLs use slugs — PK type is irrelevant to URL identity

### Rejected Alternatives

- **UUID/UUIDv7/ULID:** Over-engineered for single-writer PostgreSQL monolith
- **Mixed (bigint + UUID for some):** Creates FK type heterogeneity, cognitive tax, bug class

### Consequences

- All domain FKs are bigint — homogeneous
- Import/staging tables use UUID — acceptable boundary exception
- `$model->id` is int everywhere in domain — standard Laravel
- Developers never need to ask "which FK type is this?"
- Typesense doc IDs are string-casted bigint ("12345") — functionally equivalent to UUID strings

### Canonical-Document Changes Required

- 05-implementation.md: Change `disciplines.id` from UUID to bigint
- 05-implementation.md: Change all `cut_off_marks` FKs from UUID to bigint
- 05-implementation.md: Ensure all domain table PKs are explicitly typed as bigint
- 06-data-acquisition.md: Change `pending_imports.matching_entity_id` from UUID to bigint

---

## 4. Admission Phase Architecture

### Analysis

The domain model defines:

- PhaseSequence as a Value Object within AdmissionCycle
- `advancePhase()` as a domain method with INV-C2 (no backwards, no skipping)
- `AdmissionCyclePhaseAdvanced` domain event with payload (cycleId, previousPhase, currentPhase)

The implementation doc has:

- No PhaseSequence column at all
- Three hardcoded timestamps (opens_at, closes_at, results_at)
- No `current_phase` column

This is a gap, not a design preference.

### Challenge: Is current_phase domain state or derived?

**current_phase is AUTHORITATIVE DOMAIN STATE, not a projection.**

Reasoning:

1. `advancePhase()` is a domain operation — it transitions the cycle to the next phase. This is a deliberate business action, not a time-based derivation.
2. The domain event `AdmissionCyclePhaseAdvanced` records the transition as a business fact. Facts are authoritative.
3. Phase transitions may NOT be purely time-derived: an admin may manually advance a phase early, a phase may be paused, or dates may have gaps.
4. If current_phase were derived from timestamps, then editing timestamps could retroactively change the "current phase" — this violates the event semantics.
5. The state machine (Upcoming → Active → Closed → Archived, with sequential phase advances within Active) treats phase as STATE, not DERIVATION.

### What happens when:

1. **Dates are edited:** PhaseSequence JSONB is updated. current_phase remains unchanged (it was set by advancePhase(), not computed from dates). The admin may need to call advancePhase() or resetPhase() to align.
2. **Timezone changes:** PhaseSequence stores dates in UTC. current_phase is a string name, timezone-irrelevant.
3. **A phase is skipped:** INV-C2 forbids skipping. advancePhase() enforces sequential progression. If a phase needs to be "fast-forwarded," multiple advancePhase() calls are required.
4. **Phases overlap:** PhaseSequence VO validates non-overlapping time windows as part of its invariant.
5. **A cycle is paused:** This would require a new domain operation (pause()/resume()), which is a future extension. current_phase would remain at its current value during pause.
6. **An administrator manually changes phase:** This IS advancePhase() — the admin triggers the domain operation, which sets current_phase.

### Is current_phase a projection/cache or authoritative state?

AUTHORITATIVE STATE. It is set by the domain operation `advancePhase()` and persisted as a column. It is the source of truth for "what phase is this cycle in?"

### Consistency Mechanism

Within the AdmissionCycle aggregate boundary:

- `advancePhase()` atomically: validates (next phase must be next in sequence), updates PhaseSequence JSONB (to record the transition), and sets current_phase
- All updates occur in a single database transaction
- The aggregate boundary guarantees consistency

### Is denormalization worth it for the query workload?

Yes. Queries that benefit:

- `WHERE current_phase = 'examination'` — trivial with a column, requires JSONB containment query otherwise
- `SELECT current_phase, COUNT(*) GROUP BY current_phase` — trivial for dashboards
- Notification triggers: Eloquent model observer detects current_phase change
- Typesense: current_phase as top-level facet field

### Does current_phase violate Value Object semantics?

No. PhaseSequence remains a Value Object (immutable, equality by value, no identity). current_phase is a separate attribute of the AdmissionCycle entity. The VO defines the structure and sequence; the entity records the current position.

### Decision

**JSONB PhaseSequence Value Object + `current_phase` string column on admission_cycles.**

- PhaseSequence JSONB: stores the full phase definition (ordered phases with names and time windows)
- current_phase: authoritative state maintained by `advancePhase()`
- `advancePhase()` atomically validates and updates both
- PhaseSequence is the VO; current_phase is the entity's state

### Rejected Alternatives

- **JSONB only:** Cannot efficiently query, filter, or trigger notifications on phase
- **Normalized child table:** Over-normalizes a Value Object, breaks VO semantics, adds unnecessary table
- **Generated expression:** Cannot derive authoritative state from JSONB when phase transitions are operations, not time-derivations

---

## 5. Data Lineage Architecture

### Conceptual Model

```
SOURCE → EXTERNAL IDENTIFIER → OBSERVATION → RECONCILIATION → CANONICAL ASSERTION → PUBLICATION
```

But NOT every box requires a database table.

### SOURCE — InformationSource

- **Needs identity:** Yes — it's an aggregate root
- **Needs lifecycle:** Yes — register, verify, mark unreliable, deprecate
- **Needs historical retention:** Yes — source verification status changes are business facts
- **Needs direct querying:** Yes — admin manages sources, import pipeline references them
- **Needs FK integrity:** Yes — provenance references sources
- **Part of canonical domain:** Yes — it's aggregate root #5
- **NOT staging/import infrastructure:** Correct
- **NOT merely metadata:** It has invariants and business operations

**Table required: `information_sources` (in canonical DB)**

### EXTERNAL IDENTIFIER

- **Needs identity:** Yes — each identifier has its own provenance (who assigned it, when, source)
- **Needs lifecycle:** Partially — identifiers can be retired (valid_to set), new ones assigned
- **Needs historical retention:** Yes — retired identifiers must be retained for audit and merge scenarios
- **Needs direct querying:** Yes — "find institution with JAMB code X" is a core query for import matching
- **Needs FK integrity:** Yes — references information_sources, education_authorities, and morphable entity
- **Part of canonical domain:** Yes — identifiers are first-class provenance assertions
- **NOT staging/import infrastructure:** Correct

**Table required: `external_identifiers` (in canonical DB)**

### OBSERVATION

- **Needs identity:** Yes, temporarily — during import
- **Needs lifecycle:** Yes, but ephemeral — created during import, consumed during application
- **Needs historical retention:** Debatable — for MVP, activity log is sufficient
- **Needs direct querying:** Yes, during import — but this is staging, not canonical
- **Needs FK integrity:** Within staging boundary, not across boundary
- **Part of canonical domain:** NO — observations are pre-canonical
- **Staging/import infrastructure:** YES

**Table: `pending_imports` (in staging/infrastructure, NOT canonical)**

### RECONCILIATION

- **Needs identity:** Partially — reconciliation decisions are business facts, but for MVP they're captured in activity log
- **Needs lifecycle:** No separate lifecycle — reconciliation is a process, not an entity
- **Needs historical retention:** Yes — "why was JAMB's name chosen over NUC's?" needs an audit trail
- **Needs direct querying:** Partially — admin may want to review past reconciliation decisions
- **Needs FK integrity:** Yes, if modeled as a table
- **Part of canonical domain:** Debatable — for MVP, activity log + field_provenance capture the outcome

**Table: NOT REQUIRED FOR MVP. Activity log + field_provenance capture the essential data. A `reconciliation_decisions` table can be added in Stage 3 when reconciliation becomes more complex.**

### CANONICAL ASSERTION

- The domain entities themselves (institutions, programmes, scholarships, etc.)
- Provenance metadata on each entity (HasProvenance JSONB + field_provenance where needed)
- Publication status (is_published, published_at)

**Tables: Existing domain entity tables + field_provenance (new)**

### PUBLICATION

- Already modeled: `is_published` boolean + `published_at` timestamp on domain entities
- Publication is orthogonal to domain lifecycle (already canonical)
- Provenance interacts with publication: unpublished entities may have unverified provenance

**No new table required. Existing model is sufficient.**

### Complete Data Model

```
── SOURCE LAYER ───

education_authorities (existing, supporting entity)
  id          bigint PK
  name        string
  short_name  string
  slug        string (unique)
  type        enum
  country     string (ISO 3166-1)
  jurisdiction jsonb
  ... (standard columns)

information_sources (existing aggregate root, MODIFIED — remove institution_id)
  id                    bigint PK
  name                  string
  type                  enum (official_registry, institution_website, accreditation_body, ...)
  url                   string nullable
  contact_name          string nullable
  contact_email         string nullable
  verification_status   enum (unverified, verified, unreliable, deprecated)
  information_category  enum (official, unofficial, historical, scraped)
  verified_at           timestamp nullable
  verified_by           bigint FK nullable → users
  notes                 text nullable
  metadata              jsonb nullable
  created_at, updated_at

  Index: type, verification_status, information_category
  Index: (type, verification_status)

── IDENTIFICATION LAYER ───

external_identifiers (NEW TABLE)
  id                  bigint PK
  identifiable_type   string (morph: 'institution', 'programme', 'scholarship')
  identifiable_id     bigint (morph ID)
  authority_id        bigint FK nullable → education_authorities
  identifier_type     string (enum: 'registration_code', 'examination_code', 'accreditation_code', 'institutional_code', 'website_url', 'other')
  value               string
  is_primary          boolean default false
  valid_from          date nullable
  valid_to            date nullable
  source_id           bigint FK nullable → information_sources
  acquired_at         timestamp
  notes               text nullable
  created_at, updated_at

  Unique: (identifiable_type, identifiable_id, authority_id, identifier_type) WHERE valid_to IS NULL
    — one active identifier per entity per authority per type
  Partial unique index: (authority_id, identifier_type, value) WHERE valid_to IS NULL
    — one active entity per (authority, type, value) — prevents two institutions with same JAMB code
  Index: morphs index on (identifiable_type, identifiable_id)
  Index: (identifier_type, value) — cross-entity identifier lookup
  Index: authority_id
  Index: (identifiable_type, identifiable_id, is_primary) WHERE is_primary = true AND valid_to IS NULL
    — quick lookup of primary identifier

── CANONICAL LAYER ───

institutions, programmes, scholarships, admission_cycles, etc.
  id          bigint PK
  ... (entity fields)
  provenance  jsonb (HasProvenance trait — entity-level)
  is_published boolean default false
  published_at timestamp nullable
  created_at, updated_at

── PROVENANCE LAYER ───

field_provenance (NEW TABLE)
  id             bigint PK
  entity_type    string (morph type)
  entity_id      bigint (morph ID)
  field_name     string
  source_id      bigint FK → information_sources
  value_hash     string (SHA-256 hash of the field value at time of recording)
  acquired_at    timestamp
  is_verified    boolean default false
  superseded_by  bigint FK nullable → field_provenance (self-referencing — the record that replaced this one)
  superseded_at  timestamp nullable
  created_at, updated_at

  Index: morphs index on (entity_type, entity_id)
  Index: (entity_type, entity_id, field_name) — find provenance for a specific field
  Index: source_id
  Index: (source_id, is_verified) — find unverified data from a specific source
  Index: (entity_type, entity_id, field_name) WHERE superseded_at IS NULL
    — current (non-superseded) provenance per field

── STAGING LAYER (existing, outside canonical boundary) ───

import_batches, pending_imports (existing)
  — These remain in the import/staging infrastructure
  — pending_imports.matching_entity_id changes from UUID to bigint
```

---

## 6. InformationSource

### Semantic Definition

An InformationSource record represents a **provenance origin** — an identifiable origin point that can be attributed as the source of a piece of information in the canonical store.

It represents:

- **Not merely an organization:** "JAMB" is an organization; "JAMB 2024 UTME Brochure" is a source
- **Not merely a URL:** A URL can change; a source has identity beyond its current URL
- **Not merely a document:** "University of Lagos website" is a source that spans many documents
- **A retrievable reference:** Every source must have a retrievable reference (INV-IS3)
- **A trust classification:** Every source has a verification status and information category

An InformationSource record represents **the smallest unit of attribution** — the thing we cite when we say "this data came from X."

### Concrete Examples

| Source | InformationSource.name | type | url | Covers |
|-------|----------------------|------|-----|--------|
| JAMB brochure | "JAMB 2026 Unified Tertiary Matriculation Brochure" | official_registry | https://jamb.gov.ng/brochure.pdf | ALL institutions |
| JAMB website | "JAMB Official Website" | official_registry | https://jamb.gov.ng | ALL institutions |
| NUC list | "NUC Accreditation List 2026" | accreditation_body | https://nuc.edu.ng/accreditation | MANY institutions |
| NBTE directory | "NBTE Approved Programmes Directory" | accreditation_body | https://nbte.gov.ng/directory | MANY institutions |
| Institution website | "University of Lagos Official Website" | institution_website | https://unilag.edu.ng | ONE institution |
| Institution portal | "UNILAG Admission Portal" | institution_website | https://admission.unilag.edu.ng | ONE institution |
| PDF report | "OAU 2026 Post-UTME Results PDF" | document | (file reference) | ONE institution |
| Community report | "User correction #1234" | community_contribution | null | ONE entity |

### Why NO institution_id

1. **"What IS this source?"** is a different question from **"what does this source provide information about?"**
2. For JAMB/NUC sources, the answer to "what entities?" is "many/all" — institution_id cannot represent this
3. For institution websites, the answer is "this institution" — but provenance on the entity already captures this
4. institution_id on InformationSource conflates source identity with entity association
5. The data acquisition pipeline's import_batches already correctly model the source-to-many-entities relationship

### Schema

```
information_sources
  id                    bigint PK
  name                  string (required)
  type                  enum: official_registry, institution_website, accreditation_body, government_open_data, scholarship_provider, community_contribution, data_partner, document, news, archived
  url                   string nullable
  contact_name          string nullable (for community contributions)
  contact_email         string nullable
  verification_status   enum: unverified, verified, unreliable, deprecated
  information_category  enum: official, unofficial, historical, scraped
  verified_at           timestamp nullable
  verified_by           bigint FK nullable → users
  notes                 text nullable
  metadata              jsonb nullable
  created_at            timestamp
  updated_at            timestamp

  Index: type
  Index: verification_status
  Index: information_category
  Index: (type, verification_status)
```

---

## 7. ExternalIdentifier

### Semantic Definition

An ExternalIdentifier represents a **source assertion about an entity's identity** in an external system. "JAMB says this institution's registration code is 12345" is not just a string — it's a factual claim from a specific authority, with provenance.

### Schema

```
external_identifiers
  id                  bigint PK
  identifiable_type   string (morph: 'institution', 'programme', 'scholarship')
  identifiable_id     bigint (morph ID)
  authority_id        bigint FK nullable → education_authorities
  identifier_type     string enum: registration_code, examination_code, accreditation_code, institutional_code, website_url, other
  value               string (required)
  is_primary          boolean default false
  valid_from          date nullable
  valid_to            date nullable
  source_id           bigint FK nullable → information_sources
  acquired_at         timestamp
  notes               text nullable
  created_at, updated_at
```

### Constraints

1. **One active identifier per entity per authority per type:** `UNIQUE (identifiable_type, identifiable_id, authority_id, identifier_type) WHERE valid_to IS NULL`
   - An institution has at most one active JAMB registration code

2. **One active entity per (authority, type, value) globally (among active):** `UNIQUE (authority_id, identifier_type, value) WHERE valid_to IS NULL`
   - No two institutions can have the same active JAMB code
   - Implemented as partial unique index

3. **Morph index for eager loading:** `INDEX (identifiable_type, identifiable_id)`

4. **Cross-entity lookup:** `INDEX (identifier_type, value)` — find entities by external code

### Lifecycle

- **Created:** When data is imported or an admin adds an identifier
- **Retired:** Set valid_to when an identifier is no longer current (e.g., after institution merge)
- **Replaced:** Create new identifier with new value, retire old identifier
- **Deleted:** Hard delete only for data entry errors; normally retire

### Key Questions Answered

| Question | Answer |
|----------|--------|
| Can two institutions have the same JAMB code? | NO — partial unique index prevents this |
| Can the same institution have two JAMB codes over time? | YES — retired identifier (valid_to set) + new identifier (valid_to NULL) |
| Can two sources assign the same identifier? | The uniqueness is on authority_id, not source_id. Two sources from the same authority should agree. If they disagree, it's a data quality issue flagged in provenance. |
| Can one source assign the same identifier to two entities? | NO — partial unique index prevents this |
| What happens when an identifier is reassigned? | Old identifier retired (valid_to set), new identifier created. Both retained for audit. |

### Polymorphism Justification

Polymorphism is appropriate because:

1. External identifiers have identical structure regardless of entity type
2. Query across entity types is useful ("find any entity with external code X")
3. Laravel's morphable pattern is standard and well-supported
4. The alternative (separate tables per entity type) duplicates schema and cannot query across types

---

## 8. Provenance

### The Problem

An institution has:

- name ← NUC
- address ← institution website
- type ← NUC
- jamb_code ← JAMB
- programme_count ← internally derived

Entity-level provenance (a single JSONB on the entity) CANNOT represent this field-level source diversity. It can only say "this entity was last updated from source X." It cannot say "the name came from NUC, the address came from the institution website."

If JAMB and NUC disagree about an institution's name:

- **Where are both observations stored?** In pending_imports during import. After application to canonical store, the losing observation is lost unless preserved in field_provenance.
- **Where is the winning value stored?** On the institution entity (name = "University of Lagos").
- **Why was it selected?** Recorded in field_provenance (which source won) and activity log (who approved).
- **Who approved it?** Activity log (spatie/laravel-activitylog).
- **Can we reconstruct the decision?** field_provenance records both observations (the superseded one and the current one). Activity log records the approval action.
- **Can we determine which source currently supports the value?** field_provenance WHERE superseded_at IS NULL.
- **Can we display "verified by NUC"?** field_provenance with source_id → information_sources, is_verified = true.
- **Can we invalidate all information originating from a deprecated source?** field_provenance WHERE source_id = deprecated_source_id.
- **Can we re-run reconciliation later?** We have the current canonical values and their provenance. We lack the original observations (they're in staging, which may be purged). For full re-run capability, we'd need persistent observations — but this is Stage 3 scope.

### The Minimum Viable Provenance Model

**Layer 1: Entity-level provenance (HasProvenance JSONB — on every domain entity)**

```json
{
  "source_type": "official",
  "source_url": "https://jamb.gov.ng/brochure.pdf",
  "acquired_at": "2024-06-15T10:30:00Z",
  "last_verified_at": "2024-06-15T10:30:00Z",
  "trust_level": "official",
  "verification_status": "verified",
  "import_batch_id": 42
}
```

Purpose: Quick reference for "overall provenance" — who last updated this entity, when, from what source. Used for staleness detection and basic trust display. Populated automatically by import pipeline.

**Layer 2: Field-level provenance (field_provenance table — sparsely populated)**

Purpose: Per-field source attribution for multi-source entities. Records which source provided the canonical value for each field.

**Populated ONLY when:**

- A field has a different source than the entity's overall source
- A conflict is detected between sources
- A field is manually edited by an admin
- A field's provenance changes during a partial update

**NOT populated when:**

- The entire entity comes from a single import batch (one source for all fields)
- No conflicts exist

### Why NO primary_source_id FK on entities

primary_source_id is a MISLEADING abstraction. For an institution where name comes from NUC, tuition from the institution, and admission dates from JAMB, there IS no "primary" source. Picking one is arbitrary and creates a false abstraction. If the UI shows "Source: JAMB" for an institution, but the tuition field came from the institution's website, the user is misinformed.

### Schema: field_provenance

```
field_provenance
  id             bigint PK
  entity_type    string (morph type)
  entity_id      bigint (morph ID)
  field_name     string
  source_id      bigint FK → information_sources
  value_hash     string (SHA-256 hash)
  acquired_at    timestamp
  is_verified    boolean default false
  superseded_by  bigint FK nullable → field_provenance
  superseded_at  timestamp nullable
  created_at, updated_at

  Index: morphs index on (entity_type, entity_id)
  Index: (entity_type, entity_id, field_name) WHERE superseded_at IS NULL
  Index: source_id
  Index: (source_id, is_verified)
```

**value_hash:** SHA-256 hash of the field value at the time of recording. This allows detecting if the canonical value has diverged from the provenance record without storing the value redundantly. If the hash doesn't match the current field's hash, the provenance is stale.

**superseded_by:** Self-referencing FK. When a new field_provenance record supersedes an old one, the old record's superseded_by is set to the new record's id. This creates a chain: record N → superseded_by → record N+1 → superseded_by → null (current).

### Trigger Conditions (SPECIFIED)

| Trigger | Action |
|---------|--------|
| Import batch applies entity data from source A, entity previously had data from source B, and field F differs | Create field_provenance for field F from source A (is_verified = false). Set old provenance for field F (if exists) as superseded. |
| Import batch applies entity data, and field F has no prior provenance but entity's overall source differs | Create field_provenance for field F from the import source. |
| Admin manually edits field F | Create field_provenance for field F from source "admin override" (a special InformationSource record). Set old provenance as superseded. |
| Source is deprecated | Mark all field_provenance records from that source with a trust signal update (not deletion). Entity-level provenance trust_level should also be re-evaluated. |

### Retention Policy (SPECIFIED)

- **Retention:** field_provenance records are retained indefinitely (they are audit data)
- **Purging:** Only as part of GDPR data deletion for a specific entity
- **Growth estimate:** Most entities have 0 field_provenance records. Multi-source entities have ~5-10 records per field conflict. For 10,000 institutions, expect ~50,000-100,000 field_provenance records in steady state. Manageable.

### Why this is the minimum viable model

1. Entity-level JSONB handles 80% of cases (single-source entities) — zero overhead for the common case
2. field_provenance handles the 20% of cases that matter — multi-source entities and conflicts
3. No misleading primary_source_id — provenance is field-level or entity-level, never "primary"
4. Auditability — superseded_by chain provides full provenance history per field
5. Trust display — field_provenance enables per-field trust signals ("name: NUC verified ✓, tuition: institution-provided ○")
6. Source deprecation — field_provenance enables cascading trust updates when a source is deprecated
7. Stage 3 ready — the infrastructure supports external contributions without redesign

---

## 9. Observation vs Canonical Assertion

### Does StudyNexus need to explicitly model this distinction?

**Yes, but the boundary is already implicitly modeled correctly.**

The distinction exists at the staging → canonical boundary:

- `pending_imports` = OBSERVATIONS (source says X)
- Domain entities = CANONICAL ASSERTIONS (StudyNexus accepts X)
- `field_provenance` = the bridge (which observation won, which source supports the canonical value)

### Do we need a persistent `observations` table in the canonical DB?

**No.**

Observations are staging data. They live in `pending_imports` during import. Once verified and applied, the observation is consumed and the canonical assertion is created. Retaining all observations permanently would:

- Create massive storage growth (every import produces observations for every entity)
- Contradict the staging → canonical boundary principle
- Conflate pre-canonical data with canonical data

The provenance system (HasProvenance + field_provenance) captures the ESSENTIAL outcome: which source won, what value was accepted, when, and by whom. This is sufficient for MVP.

### Do we need a `reconciliation_decisions` table?

**Not for MVP.** The reconciliation process is:

1. Import creates pending_imports (observations)
2. Verification engine detects conflicts (cross-source consistency check)
3. Admin resolves conflicts via Filament UI (manual merge/reject/approve)
4. Resolution is logged in activity log (who, what, when)
5. field_provenance records the outcome (which source supports each field)

For Stage 3 (external contributions), a `reconciliation_decisions` table would enable:

- Automated reconciliation rules (auto-accept from verified sources, flag for review from unverified)
- Re-running reconciliation with different rules
- Reporting on reconciliation patterns

This can be added as an additive, non-breaking change.

### Decision

No persistent `observations` table. No `reconciliation_decisions` table for MVP. The staging pipeline + field_provenance + activity log provide sufficient audit trail.

---

## 10. Reconciliation

### Where reconciliation decisions live

Reconciliation decisions are captured in TWO places:

1. **Activity log** (spatie/laravel-activitylog): Records the human action — "Admin Jane resolved conflict on Institution #42 name: chose NUC value 'University of Lagos' over JAMB value 'UNILAG'." This answers: who, what, when.

2. **field_provenance**: Records the data outcome — Institution #42, field "name", source_id = NUC, is_verified = true. The superseded record (JAMB value) is linked via superseded_by. This answers: which source won, what value was accepted.

### How reconciliation affects canonical data

When a conflict is resolved:

1. The winning value is written to the canonical entity field
2. field_provenance is updated (new record for winning source, old record superseded)
3. Entity-level provenance is updated (last_updated_source, acquired_at)
4. Domain event is dispatched (if the entity's domain method is called)
5. Activity log records the decision

### Reconciliation Rules (MVP)

| Scenario | Rule | Automated? |
|----------|------|:----------:|
| Official source says X, unofficial says Y | Official wins | Yes (auto) |
| Two official sources disagree | Flag for admin review | No (manual) |
| New data contradicts verified existing data | Flag for admin review | No (manual) |
| New data extends (adds fields) existing data | Merge (new fields added) | Yes (auto) |
| New data updates existing field with same source | Update (newer-wins) | Yes (auto) |

---

## 11. Publication

### How provenance interacts with publication status

Publication and provenance are ORTHOGONAL concerns:

- An entity can be published with unverified provenance (data imported but not yet verified)
- An entity can be unpublished with verified provenance (data verified but admin hasn't published yet)
- Publication does not imply verification; verification does not imply publication

**Display logic:**

- Published + verified provenance → Normal display with trust signals
- Published + unverified provenance → Display with "unverified" indicator
- Published + stale provenance → Display with staleness warning
- Unpublished → Not visible on public site regardless of provenance

**Trust signals on public pages:**

- Field-level: "Source: NUC accreditation list · Verified ✓" (from field_provenance WHERE superseded_at IS NULL)
- Entity-level: "Last verified: 2026-01-15" (from provenance JSONB)
- Staleness: Computed from last_verified_at threshold

---

## 12. Acquisition Boundary

### Clear separation

| Concept | Lives In | Rationale | Ephemeral? |
|---------|----------|-----------|:----------:|
| Raw source data | Adapter output | Consumed during normalization | Yes |
| Normalized DTOs | Adapter output → pending_imports.normalized_data | Consumed during verification | Yes |
| Import batches | import_batches (staging) | Tracking metadata, persists for audit | No (audit) |
| Pending imports | pending_imports (staging) | Individual import records | Yes (after application) |
| External identifiers | external_identifiers (canonical) | First-class domain concept | No |
| Provenance metadata | HasProvenance JSONB + field_provenance (canonical) | Must survive batch deletion | No |
| Approval decisions | Activity log | Audit trail | No (audit) |
| Source registry | information_sources (canonical) | Aggregate root | No |

### Principle: Acquisition/staging data does NOT leak into canonical domain model

- Domain entities have NO awareness of import batches or pending imports
- Domain Actions (ImportInstitutionData) orchestrate the boundary crossing
- The only "leak" is provenance metadata (import_batch_id in HasProvenance JSONB), which is a lightweight reference for audit, not a domain dependency

---

## 13. Entity Merge/Split Implications

### Merge: Two institutions merge into one

**External identifiers:**

- Both institutions' identifiers are retained
- Identifiers from the absorbed institution are retired (valid_to set to merge date)
- New identifiers for the merged institution are created if needed (e.g., new JAMB code)
- The partial unique index (authority_id, identifier_type, value) ensures no active duplicates

**Provenance:**

- field_provenance records from both original institutions are updated to point to the surviving entity
- Entity-level provenance is updated to reflect the merge (source = "admin merge")
- The InstitutionMerger domain service coordinates this

**Domain events:**

- `InstitutionsMerged` event carries initiatingId, targetId
- Listeners update search index, reassign programmes, flag scholarships

### Split: One institution splits into two

**External identifiers:**

- Existing identifiers remain on the original institution
- New identifiers are created for the new institution
- This is rare and requires manual admin work

**Provenance:**

- field_provenance records stay with their original entity
- New entity gets fresh provenance from the split operation

**Domain implication:**

- Split is not a current domain operation — it would need to be added as a future Action
- The data model supports it (identifiers and provenance are entity-scoped)

---

## 14. Failure Scenarios

| # | Scenario | How Architecture Handles It |
|---|----------|---------------------------|
| 1 | Polymorphic FK orphans after entity deletion | external_identifiers with identifiable_type + identifiable_id referencing a deleted entity become orphans. Mitigation: Use ON DELETE CASCADE on the morph relationship, or add a cleanup job. Recommended: ON DELETE CASCADE for external_identifiers when the parent entity is hard-deleted. Domain model uses status-based lifecycle (close/deprecate), not hard delete — so orphans should be rare. |
| 2 | Source versioning: JAMB 2025 vs JAMB 2026 brochure | Each year's brochure is a SEPARATE InformationSource record. Name distinguishes them ("JAMB 2025 Brochure" vs "JAMB 2026 Brochure"). Provenance on each entity records which brochure its data came from. No versioning conflict — sources are distinct records. |
| 3 | Identifier reassignment after institution merge | Old identifiers are retired (valid_to set to merge date). New identifiers are created for the merged institution. Partial unique index on (authority_id, identifier_type, value) WHERE valid_to IS NULL ensures only active identifiers are uniqueness-constrained. |
| 4 | Source deprecation cascade | When an InformationSource is deprecated: entity-level provenance trust_level is re-evaluated; field_provenance records from the deprecated source are flagged (is_verified set to false or a new flag); search index is updated to reflect reduced trust; admin is notified to review affected entities. |
| 5 | Duplicate source records | Two admins create similar InformationSource records. Mitigation: unique constraint on (name, type) or a canonical source registry with dedup workflow. For MVP, admin discipline and activity log auditing prevent this. Stage 3 adds automated deduplication. |
| 6 | Stale provenance | An entity's provenance says "last verified 2024-01-01" but the source has been updated since. Mitigation: StaleDataDetectionJob (already in 06-data-acquisition.md) flags entities not updated within threshold. The provenance.last_verified_at timestamp enables staleness computation. |
| 7 | Conflicting values (JAMB vs NUC on institution name) | field_provenance records both observations. The canonical entity stores the winning value. The superseded_by chain preserves the conflict history. Admin can review and reverse decisions. |
| 8 | Historical reconstruction ("what was the name in 2023?") | field_provenance superseded_by chain provides partial reconstruction (who superseded whom, when). For full time-travel, event sourcing would be needed — but this contradicts ADR-2. For MVP, field_provenance + activity log provide sufficient audit trail. |
| 9 | Auditability ("who changed tuition and why?") | spatie/laravel-activitylog records all model changes with causer, properties, and description. field_provenance records which source supports the current value. Together, they answer who, what, when, and from which source. |
| 10 | Query performance on field_provenance | Estimated 50,000-100,000 rows in steady state. Indexes on (entity_type, entity_id, field_name) and source_id provide efficient access. Growth is bounded by conflict frequency, not entity count. Manageable. |
| 11 | Admin UX for external identifiers | Filament RelationManager on Institution resource for external_identifiers. Standard pattern — no custom development needed beyond the relation definition. |
| 12 | Typesense sync with provenance changes | Provenance does NOT belong in Typesense search projections. Provenance is detail-page data, not search/facet data. When provenance changes, no Typesense update is needed (unless is_published or status changes, which already trigger search index updates). |
| 13 | International expansion (KUCCPS codes from Kenya) | Generic external_identifiers handles this naturally: new EducationAuthority record for KUCCPS, new external_identifier records linking Kenyan institutions to KUCCPS codes. No schema change. P5-compliant. |
| 14 | Source-specific assumptions in schema | The design has ZERO Nigeria-specific columns (no jamb_code, nuc_code). All source-specific codes are in external_identifiers with authority_id. P5-compliant. |
| 15 | Schema migration for field_provenance addition | Adding field_provenance is a non-breaking migration (new table, no modifications to existing tables). Can be done at any point. Creating it from day one avoids the migration entirely. |
| 16 | Data deletion (GDPR/NDPR) | Entity deletion cascades to external_identifiers (ON DELETE CASCADE on morph relationship). field_provenance records are deleted with the entity (ON DELETE CASCADE on morph relationship). HasProvenance JSONB is on the entity — deleted with the entity. Activity log entries may need to be retained per legal requirements. |
| 17 | Entity merges | InstitutionMerger domain service handles reassignment of external_identifiers, field_provenance, and programmes. Both source entities' provenance is preserved on the surviving entity. |
| 18 | Entity splits | Rare; requires admin manual work. Data model supports it (identifiers and provenance are entity-scoped). No domain operation exists for split — future Action. |
| 19 | Canonical identity changes (PK change) | PKs are bigint auto-increment and NEVER change. If a canonical identity change is needed, it would be handled by a domain operation that creates a new entity and retires the old one — not by PK mutation. |
| 20 | Concurrent import jobs creating duplicate external_identifiers | The partial unique index on (authority_id, identifier_type, value) WHERE valid_to IS NULL prevents duplicates at the database level. Concurrent imports that try to insert the same identifier will fail with a constraint violation. The import pipeline should handle this gracefully (upsert or skip). |

---

## 15. Schema Sketch

### Domain Tables (existing, with modifications noted)

```sql
-- MODIFIED: Remove institution_id
CREATE TABLE information_sources (
  id                    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name                  VARCHAR(255) NOT NULL,
  type                  VARCHAR(50) NOT NULL,
  url                   VARCHAR(2048),
  contact_name          VARCHAR(255),
  contact_email         VARCHAR(255),
  verification_status   VARCHAR(50) NOT NULL DEFAULT 'unverified',
  information_category  VARCHAR(50) NOT NULL,
  verified_at           TIMESTAMP,
  verified_by           BIGINT REFERENCES users(id),
  notes                 TEXT,
  metadata              JSONB,
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW()
);

-- MODIFIED: Add current_phase, add PhaseSequence JSONB, change FK to education_authority_id
CREATE TABLE admission_cycles (
  id                    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  education_authority_id BIGINT NOT NULL REFERENCES education_authorities(id),
  name                  VARCHAR(255) NOT NULL,
  academic_year         VARCHAR(20) NOT NULL,
  admission_pathway     VARCHAR(50) NOT NULL,
  phase_sequence        JSONB NOT NULL,
  current_phase         VARCHAR(50),
  status                VARCHAR(50) NOT NULL,
  provenance            JSONB,
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW()
);

-- MODIFIED: All PKs are bigint, all FKs are bigint
CREATE TABLE institutions (
  id                    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name                  VARCHAR(255) NOT NULL,
  slug                  VARCHAR(255) NOT NULL,
  type                  VARCHAR(50) NOT NULL,
  country               VARCHAR(2) NOT NULL,
  state_province        VARCHAR(100),
  city                  VARCHAR(100),
  address               JSONB,
  contact_info          JSONB,
  coordinates           JSONB,
  website               VARCHAR(2048),
  founded_year          INTEGER,
  description           TEXT,
  ownership_type        VARCHAR(50),
  status                VARCHAR(50) NOT NULL DEFAULT 'provisional',
  is_published          BOOLEAN NOT NULL DEFAULT FALSE,
  published_at          TIMESTAMP,
  provenance            JSONB,
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW(),
  UNIQUE (slug, country)
);

-- MODIFIED: discipline_id is bigint FK, not UUID FK
-- (other institution, programme, scholarship tables similarly modified for bigint PKs/FKs)

-- MODIFIED: All FK types are bigint
CREATE TABLE cut_off_marks (
  id                    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  programme_id          BIGINT NOT NULL REFERENCES programmes(id) ON DELETE CASCADE,
  admission_cycle_id    BIGINT NOT NULL REFERENCES admission_cycles(id) ON DELETE CASCADE,
  pathway               VARCHAR(50) NOT NULL,
  value                 INTEGER NOT NULL,
  source_id             BIGINT REFERENCES information_sources(id) ON DELETE SET NULL,
  provenance            JSONB,
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW(),
  UNIQUE (programme_id, admission_cycle_id, pathway)
);

-- MODIFIED: bigint PK, not UUID PK
CREATE TABLE disciplines (
  id                    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name                  VARCHAR(100) NOT NULL,
  slug                  VARCHAR(100) NOT NULL UNIQUE,
  description           TEXT,
  sort_order            INTEGER,
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW()
);
```

### New Tables

```sql
CREATE TABLE external_identifiers (
  id                  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  identifiable_type   VARCHAR(255) NOT NULL,
  identifiable_id     BIGINT NOT NULL,
  authority_id        BIGINT REFERENCES education_authorities(id),
  identifier_type     VARCHAR(50) NOT NULL,
  value               VARCHAR(255) NOT NULL,
  is_primary          BOOLEAN NOT NULL DEFAULT FALSE,
  valid_from          DATE,
  valid_to            DATE,
  source_id           BIGINT REFERENCES information_sources(id),
  acquired_at         TIMESTAMP NOT NULL,
  notes               TEXT,
  created_at          TIMESTAMP DEFAULT NOW(),
  updated_at          TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX ext_ident_entity_unique
  ON external_identifiers (identifiable_type, identifiable_id, authority_id, identifier_type)
  WHERE valid_to IS NULL;

CREATE UNIQUE INDEX ext_ident_value_unique
  ON external_identifiers (authority_id, identifier_type, value)
  WHERE valid_to IS NULL;

CREATE INDEX ext_ident_morph
  ON external_identifiers (identifiable_type, identifiable_id);

CREATE INDEX ext_ident_lookup
  ON external_identifiers (identifier_type, value);

CREATE TABLE field_provenance (
  id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entity_type    VARCHAR(255) NOT NULL,
  entity_id      BIGINT NOT NULL,
  field_name     VARCHAR(255) NOT NULL,
  source_id      BIGINT NOT NULL REFERENCES information_sources(id),
  value_hash     VARCHAR(64) NOT NULL,
  acquired_at    TIMESTAMP NOT NULL,
  is_verified    BOOLEAN NOT NULL DEFAULT FALSE,
  superseded_by  BIGINT REFERENCES field_provenance(id),
  superseded_at  TIMESTAMP,
  created_at     TIMESTAMP DEFAULT NOW(),
  updated_at     TIMESTAMP DEFAULT NOW()
);

CREATE INDEX fp_morph
  ON field_provenance (entity_type, entity_id);

CREATE INDEX fp_field_current
  ON field_provenance (entity_type, entity_id, field_name)
  WHERE superseded_at IS NULL;

CREATE INDEX fp_source
  ON field_provenance (source_id);

CREATE INDEX fp_unverified
  ON field_provenance (source_id, is_verified);
```

---

## 16. Index and Constraint Strategy

### external_identifiers

| Index/Constraint | Type | Purpose |
|-----------------|------|---------|
| PK on id | Primary key | Standard |
| ext_ident_entity_unique | Partial UNIQUE | One active identifier per entity per authority per type |
| ext_ident_value_unique | Partial UNIQUE | One active entity per (authority, type, value) — prevents duplicate JAMB codes |
| ext_ident_morph | B-tree | Eloquent morphable relationship loading |
| ext_ident_lookup | B-tree | Find entity by external code value |
| FK on authority_id | Foreign key | Referential integrity to education_authorities |
| FK on source_id | Foreign key (nullable) | Referential integrity to information_sources |

### field_provenance

| Index/Constraint | Type | Purpose |
|-----------------|------|---------|
| PK on id | Primary key | Standard |
| fp_morph | B-tree | Eloquent morphable relationship loading |
| fp_field_current | Partial B-tree | Find current (non-superseded) provenance per field |
| fp_source | B-tree | Find all provenance from a specific source (for deprecation cascade) |
| fp_unverified | B-tree | Find unverified provenance from a specific source |
| FK on source_id | Foreign key | Referential integrity to information_sources |
| FK on superseded_by | Foreign key (nullable, self-referencing) | Provenance chain integrity |

### admission_cycles

| Index/Constraint | Type | Purpose |
|-----------------|------|---------|
| Index on education_authority_id | B-tree | Find cycles for an authority |
| Index on current_phase | B-tree | Filter cycles by phase |
| Index on status | B-tree | Filter by lifecycle status |
| GIN index on phase_sequence | GIN | JSONB containment queries (if needed) |

---

## 17. Laravel/Eloquent Implications

### Models

**InformationSource (modified):**

```php
class InformationSource extends Model
{
    // REMOVED: belongsTo Institution
    // ADDED: hasMany ExternalIdentifier (through provenance, not direct)

    protected $casts = [
        'metadata' => 'array',
        'verification_status' => SourceReliability::class,
        'information_category' => InformationCategory::class,
    ];
}
```

**ExternalIdentifier (new):**

```php
class ExternalIdentifier extends Model
{
    public function identifiable(): MorphTo
    {
        return $this->morphTo();
    }

    public function authority(): BelongsTo
    {
        return $this->belongsTo(EducationAuthority::class);
    }

    public function source(): BelongsTo
    {
        return $this->belongsTo(InformationSource::class);
    }

    protected $casts = [
        'identifier_type' => IdentifierType::class,
        'acquired_at' => 'datetime',
        'valid_from' => 'date',
        'valid_to' => 'date',
    ];
}
```

**Institution (modified):**

```php
class Institution extends Model
{
    // REMOVED: jamb_code, nuc_code columns
    // ADDED: morphMany ExternalIdentifier

    public function externalIdentifiers(): MorphMany
    {
        return $this->morphMany(ExternalIdentifier::class, 'identifiable');
    }

    // Convenience accessor for primary JAMB code
    public function getJambCodeAttribute(): ?string
    {
        return $this->externalIdentifiers()
            ->where('identifier_type', 'registration_code')
            ->whereHas('authority', fn($q) => $q->where('short_name', 'JAMB'))
            ->where('is_primary', true)
            ->whereNull('valid_to')
            ->first()?->value;
    }
}
```

**AdmissionCycle (modified):**

```php
class AdmissionCycle extends Model
{
    // ADDED: phase_sequence JSONB cast
    // ADDED: current_phase column

    protected $casts = [
        'phase_sequence' => PhaseSequence::class, // Custom cast
    ];

    public function advancePhase(): void
    {
        $nextPhase = $this->phase_sequence->nextAfter($this->current_phase);
        // INV-C2 enforcement
        throw_unless($nextPhase, new InvalidPhaseTransition());

        $previousPhase = $this->current_phase;
        $this->current_phase = $nextPhase->name;
        $this->save();

        event(new AdmissionCyclePhaseAdvanced($this->id, $previousPhase, $this->current_phase));
    }
}
```

**FieldProvenance (new):**

```php
class FieldProvenance extends Model
{
    public function source(): BelongsTo
    {
        return $this->belongsTo(InformationSource::class);
    }

    public function superseder(): BelongsTo
    {
        return $this->belongsTo(FieldProvenance::class, 'superseded_by');
    }

    protected $casts = [
        'acquired_at' => 'datetime',
        'superseded_at' => 'datetime',
    ];
}
```

### Actions

**RegisterExternalIdentifier (new):**

- Validates: entity exists, authority exists, identifier not duplicate
- Creates external_identifier record
- Records provenance (source_id, acquired_at)
- Dispatches event for activity log

**RecordFieldProvenance (new):**

- Creates or updates field_provenance record
- Handles supersession chain (sets superseded_by on old record)
- Called by import pipeline and admin override actions

### Domain Events

- **ExternalIdentifierCreated:** entity, authority, identifier_type, value, source
- **ExternalIdentifierRetired:** entity, authority, identifier_type, value, retired_at
- **FieldProvenanceUpdated:** entity, field, old_source, new_source, updated_by

### Value Objects

- **PhaseSequence:** Immutable PHP object with JSON cast. Methods: nextAfter(currentPhase), phases(), currentPhaseDates(), validate()
- **IdentifierType:** PHP Backed Enum with values: registration_code, examination_code, accreditation_code, institutional_code, website_url, other

---

## 18. Typesense Implications

### What provenance/state belongs in search projections

| Field | In Typesense? | Rationale |
|-------|:------------:|-----------|
| is_published | YES | Filter: exclude unpublished from public search |
| status | YES | Filter: exclude discontinued/closed from public search |
| current_phase | YES (on admission_cycles collection) | Facet: "all cycles in Examination phase" |
| is_admission_open | YES (on programmes collection) | Facet: "currently admitting" |
| provenance.last_verified_at | NO | Detail page data, not search concern |
| provenance.source_type | NO | Detail page data |
| external_identifier values | NO | Used for import matching, not public search |
| field_provenance | NO | Detail page data, not search concern |

### When provenance changes, does Typesense need updating?

Only if the provenance change affects publication status or lifecycle status. If an entity's provenance becomes "deprecated" or "unverified" but is_published and status remain the same, no Typesense update is needed. The public page will show the trust signal on next render.

If is_published or status changes (e.g., admin unpublishes an entity after deprecating its source), Typesense IS updated via the existing domain event → UpdateSearchIndex pipeline.

---

## 19. Canonical Document Amendments

### 03-domain.md

1. **Section 8 — InformationSource entity:** Remove `institution_id` from the implicit schema. Clarify that entity-to-source associations are through provenance (HasProvenance trait on entities), not through a FK on InformationSource. The aggregate root's invariants (INV-IS1 through INV-IS3) remain unchanged.

2. **Section 8 — Institution entity:** Add note that `registrationIdentifier` in `establish()` maps to an ExternalIdentifier record creation. Remove any reference to source-specific identifier columns (jamb_code, nuc_code).

3. **Section 8 — AdmissionCycle entity:** Add `current_phase` as a denormalized authoritative state attribute maintained by `advancePhase()`. Clarify that PhaseSequence JSONB defines the sequence structure and current_phase records the current position as authoritative domain state (not a projection).

4. **Section 12 — Disciplines:** Change `id` from UUID to bigint. Add note that explicit seeded IDs are used for cross-environment stability.

5. **Section 13 — CutOffMark:** Change `id` from UUID to bigint. Change all FK columns from UUID to bigint.

6. **New section — ExternalIdentifier:** Add as a first-class domain concept (not an entity — it has identity and provenance but no invariants beyond uniqueness). Described as a "provenance assertion" — a claim from an authority about an entity's identity in an external system.

7. **New section — Field Provenance:** Add as a provenance infrastructure concept. Sparsely populated. Trigger conditions documented.

### 04-architecture.md

1. **P5 compliance note:** Add explicit statement that no schema column may encode a Nigeria-specific regulatory body name (no jamb_code, nuc_code). All external identifiers use the generic external_identifiers table.

2. **Data lineage architecture reference:** Add reference to ADR-DL1 (once written).

### 05-implementation.md

1. **information_sources table:** Remove `institution_id` FK. Add columns: type (enum), information_category (enum), metadata (jsonb).

2. **admission_cycles table:** Remove `institution_id` FK. Add `education_authority_id` FK. Add `phase_sequence` JSONB column. Add `current_phase` VARCHAR(50) column. Remove `opens_at`, `closes_at`, `results_at` (superseded by PhaseSequence).

3. **disciplines table:** Change `id` from UUID to bigint.

4. **cut_off_marks table:** Change `id` from UUID to bigint. Change all FK columns from UUID to bigint.

5. **New table: external_identifiers:** Add full table definition with constraints and indexes.

6. **New table: field_provenance:** Add full table definition with constraints and indexes.

7. **institutions table:** Remove `jamb_code`, `nuc_code` columns (if they were planned). Add `provenance` JSONB column (HasProvenance trait).

8. **All domain tables:** Ensure `provenance` JSONB column is present.

### 06-data-acquisition.md

1. **pending_imports table:** Change `matching_entity_id` from UUID to bigint.

2. **import_batches table:** Change `id` from UUID to bigint (or retain UUID for staging — this is a boundary exception). Recommend retaining UUID for staging tables since they're outside the canonical domain boundary.

3. **Provenance model section:** Update to reflect hybrid provenance (entity-level JSONB + field_provenance). Remove any reference to primary_source_id. Document the HasProvenance trait structure and field_provenance trigger conditions.

4. **Verification engine section:** Add note that conflicts detected by the cross-source consistency check create field_provenance records in the canonical store (not just staging flags).

---

## 20. ADR-DL1

### Title

**ADR-DL1: Data Lineage Architecture for Multi-Source Entity Provenance**

### Status

Proposed

### Context

StudyNexus aggregates educational information from multiple external sources (JAMB, NUC, NBTE, NCCE, institution websites, scholarship providers, community contributions). Each source provides different data fields for the same entities. The canonical store must:

- Attribute each data point to its source
- Detect and resolve conflicts between sources
- Support trust signals per field
- Handle source deprecation cascades
- Maintain audit trail for reconciliation decisions
- Prepare for Stage 3 transition (external contributions)

The current canonical documents model provenance as entity-level JSONB on each entity, which cannot represent field-level source attribution. The InformationSource entity has an institution_id FK that conflates source identity with entity association. External identifiers are not modeled as first-class objects. These three concerns are aspects of one architectural concept: DATA LINEAGE.

### Problem

How should StudyNexus model the complete information flow from external sources through reconciliation to canonical assertions to publication, while preserving sufficient provenance for trust, audit, and future extensibility?

### Decision

**StudyNexus adopts a hybrid data lineage architecture with four persistent layers:**

1. **Source Layer:** InformationSource (aggregate root, no entity associations) + EducationAuthority (supporting entity)
2. **Identification Layer:** ExternalIdentifier (first-class provenance assertion linking entities to authority-assigned identifiers)
3. **Canonical Layer:** Domain entities with entity-level provenance JSONB (HasProvenance trait)
4. **Provenance Layer:** field_provenance table (sparsely populated, for multi-source entities)

**Staging/observation data (import_batches, pending_imports) remains outside the canonical boundary and is ephemeral.**

### Architecture

```
EXTERNAL SOURCES
  → Adapters (fetch, normalize, validate)
  → Staging (import_batches, pending_imports)
  → Verification Engine (duplicate detection, cross-source consistency, schema validation)
  → Application (Actions → domain methods → canonical store)
  → Provenance Recording (HasProvenance JSONB + field_provenance)
  → Domain Events (AdmissionCyclePhaseAdvanced, ExternalIdentifierCreated, etc.)
  → Search Index (Typesense projection)
```

### Data Model

1. **information_sources:** Aggregate root with NO institution_id. Entity-to-source associations are through provenance on entities, not FK on InformationSource.

2. **external_identifiers:** Generic polymorphic table. First-class provenance assertions linking entities to authority-assigned identifiers. Supports validity periods, retirement, and per-identifier provenance.

3. **HasProvenance trait:** JSONB on every domain entity. Contains: source_type, source_url, acquired_at, last_verified_at, trust_level, verification_status, import_batch_id. Populated automatically by import pipeline.

4. **field_provenance:** Polymorphic table. Records per-field source attribution. Sparsely populated — only for multi-source entities and conflicts. Supports supersession chain for provenance history.

### Invariants

- **INV-DL1:** Every canonical entity has entity-level provenance (HasProvenance JSONB is non-null after first import)
- **INV-DL2:** No schema column encodes a Nigeria-specific regulatory body name (P5 compliance)
- **INV-DL3:** External identifier values are unique per (authority, type) among active identifiers
- **INV-DL4:** field_provenance records are never deleted (audit retention)
- **INV-DL5:** When a source is deprecated, all field_provenance from that source is flagged within 24 hours (eventual consistency)

### Lifecycle

- **Source lifecycle:** register → verify ↔ mark unreliable → deprecate (terminal). Same as existing 03-domain.md.
- **Identifier lifecycle:** create → [retire (set valid_to)] → [replace (create new, retire old)]. Identifiers are never hard-deleted (audit retention).
- **Provenance lifecycle:** create → [supersede (set superseded_by when new record supersedes)]. Provenance records are never deleted (audit retention).
- **Reconciliation:** observe conflict → flag in field_provenance → admin resolves → update canonical → activity log records decision.

### Alternatives Considered

1. **Full observation model:** Persistent `observations` table in canonical DB. Rejected — massive storage growth, conflates pre-canonical data with canonical data, contradicts staging → canonical boundary.

2. **Normalized provenance table (per-field):** One row per (entity, field, source) even for single-source entities. Rejected — 10x+ row count, unnecessary joins for the 80% single-source case.

3. **primary_source_id FK on entities:** Single FK pointing to "primary" source. Rejected — misleading for multi-source entities, creates false abstraction.

4. **Entity-level JSONB only (no field_provenance):** Provenance is entity-level only. Rejected — cannot represent field-level source attribution, cannot support per-field trust signals, cannot detect which fields are affected by source deprecation.

5. **Data lineage platform (event sourcing for data):** Every field change is an event. Rejected — contradicts ADR-2 (Active Record with Domain Methods), massive complexity, premature for MVP.

### Consequences

1. Every entity has entity-level provenance — zero overhead for single-source entities (JSONB always present)
2. Field-level provenance is available when needed — sparsely populated, no overhead for single-source entities
3. No misleading primary_source_id — provenance is field-level or entity-level, never "primary"
4. External identifiers are P5-compliant — no Nigeria-specific columns
5. InformationSource correctly represents "what IS the source" — entity associations through provenance
6. Audit trail is sufficient for MVP — field_provenance + activity log
7. Stage 3 ready — infrastructure supports external contributions
8. Storage cost: field_provenance is ~50,000-100,000 rows in steady state — manageable

### Migration Implications

- New tables: external_identifiers, field_provenance
- Modified tables: information_sources (remove institution_id), admission_cycles (add phase_sequence, current_phase, change FK), disciplines (change PK type), cut_off_marks (change PK and FK types)
- All domain tables: Add provenance JSONB column if not present
- No data migration required for external_identifiers or field_provenance (empty tables at creation)
- Existing data with jamb_code/nuc_code would need migration script to populate external_identifiers — but these columns don't exist yet in production (pre-implementation), so no migration needed

### Deferred Decisions

- **reconciliation_decisions table:** Deferred to Stage 3 when reconciliation becomes more complex. MVP uses activity log + field_provenance.
- **persistent observations:** Deferred indefinitely. Staging data + field_provenance provide sufficient audit trail.
- **field-level provenance for content models:** Content models (Article, Guide, etc.) have their own provenance via HasProvenance trait. field_provenance for content is not needed in MVP.
- **automated reconciliation rules:** Deferred to Stage 3. MVP reconciliation is manual (admin review).

---

## 21. Final Human Decisions

### APPROVE NOW

**1. BD-1: Uniform bigint PKs for ALL domain tables.**

Sufficiently analyzed. No domain invariant requires UUID. Single-writer PostgreSQL is confirmed. FK type heterogeneity has no offsetting benefit. The cut_off_marks type mismatch bug must be fixed. Explicit seeded IDs solve reference data stability.

**2. BD-3: JSONB PhaseSequence + current_phase (authoritative state).**

The gap in the implementation doc is confirmed. JSONB preserves VO integrity. current_phase is authoritative domain state (set by advancePhase(), not derived). The hybrid approach is the correct design.

**3. ND-5: InformationSource without institution_id.**

The JAMB brochure example definitively proves institution_id is incorrect. A source IS a provenance origin. Entity-to-source relationships are through provenance. The aggregate root's invariants are all about source verification, not entity association.

**4. External identifiers as generic polymorphic table.**

P5 compliance requires no Nigeria-specific columns. The provenance model aligns with first-class identifier objects. The generic table requires zero schema changes for new authorities.

**5. No primary_source_id FK on any entity.**

primary_source_id is a misleading abstraction for multi-source entities. Entity-level JSONB + field_provenance provide correct provenance.

**6. field_provenance table created from day one.**

The infrastructure is needed for the minority of multi-source entities. Sparse population means zero overhead for the common case. Trigger conditions are specified. Retention policy is specified.

### DISCUSS

**1. External identifier uniqueness constraints.**

The proposed partial unique indexes enforce: (a) one active identifier per entity per authority per type, and (b) one active entity per (authority, type, value). Index (b) prevents two institutions from having the same JAMB code. Is this correct? Should we allow temporary overlaps during data quality remediation? Should the constraint be in the application layer instead of the database?

**2. field_provenance trigger conditions.**

The proposed triggers are: (a) field has different source than entity's overall source, (b) conflict detected, (c) admin manual edit, (d) provenance changes during partial update. Are these the complete set? Should import batch application ALWAYS create field_provenance for every field (not just conflicting fields)? This would increase row count but provide complete provenance coverage.

**3. source_id on external_identifiers.**

Should external identifiers reference an InformationSource (the specific document/batch that provided the identifier) or an EducationAuthority (the authority that assigned the identifier)? Currently both are referenced (authority_id for the authority, source_id for the provenance). Is this correct?

**4. current_phase and time-based automatic transition.**

Should admission cycle phase transitions be purely manual (admin calls advancePhase()) or should there be a scheduled job that automatically advances phases based on dates in PhaseSequence? The domain model defines advancePhase() as a domain operation, but in practice, admission cycles in Nigeria follow predictable date-based schedules.

### DEFER

**1. Reconciliation decisions table.**

Deferred to Stage 3. MVP uses activity log + field_provenance for audit trail. A reconciliation_decisions table can be added as an additive, non-breaking change when reconciliation becomes more complex.

**2. Persistent observations in canonical DB.**

Deferred indefinitely. The staging pipeline + field_provenance provide sufficient audit trail. If full observation replay is needed, it can be added as a new table without modifying existing schema.

**3. Field-level provenance for content models.**

Deferred. Content models have their own provenance via HasProvenance trait. field_provenance for content is not needed in MVP.

**4. Automated reconciliation rules.**

Deferred to Stage 3. MVP reconciliation is manual (admin review). Automated rules (e.g., "official source always wins") can be added as configuration.

**5. Admission cycle pause/resume.**

Deferred. The domain model's advancePhase() supports sequential phase progression. Pause/resume would require new domain operations (pause(), resume()) and is a non-breaking additive change.

---

*End of Second-Order Architectural Review*
