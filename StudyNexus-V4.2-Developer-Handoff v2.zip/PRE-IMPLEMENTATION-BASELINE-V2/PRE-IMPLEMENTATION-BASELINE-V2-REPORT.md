# StudyNexus — Pre-Implementation Baseline v2 Report

**Date:** 2026-08-17
**Version:** 2.0
**Status:** FROZEN
**Supersedes:** PRE-IMPLEMENTATION-BASELINE v1 (2026-08-08)

---

## 1. Baseline Creation Summary

This baseline was created after completing the canonical amendment phase that applied all decisions from the FINAL-LINEAGE-SEMANTICS-RESOLUTION and the FINAL APPROVED DECISION SET.

### Process

1. **Targeted source-reference check** — Verified that the differing ON DELETE behaviors for source_id across three tables (field_provenance → RESTRICT, external_identifiers → RESTRICT, cut_off_marks → SET NULL) are intentional and semantically justified. Documented the distinction in 03-domain.md and 05-implementation.md.

2. **Baseline assembly** — Copied all amended canonical documents, product experience documents, governance/ADR records, and historical archive into the v2 directory structure.

3. **SHA-256 verification** — Computed and recorded hashes for all files in MANIFEST.md.

4. **ZIP creation** — Created `StudyNexus-Pre-Implementation-Baseline-v2.zip` for portable distribution.

---

## 2. Files Included

### Canonical (6 files) — AUTHORITATIVE

| File | Purpose |
|------|---------|
| `01-business.md` | Business vision, users, capabilities, workflows, glossary |
| `02-decisions.md` | All decisions, ADRs (ADR-1 through ADR-23), open questions, change protocol |
| `03-domain.md` | Domain model: entities, VOs, enums, events, actions, invariants, relationships, provenance, external identifiers |
| `04-architecture.md` | Architecture: principles, layers, search, RBAC, provenance architecture, concurrency |
| `05-implementation.md` | Implementation blueprint: stack, migrations, schemas, ON DELETE, CHECK constraints, indexes, Filament, factories |
| `06-data-acquisition.md` | Data acquisition: source taxonomy, staging schema, adapter pattern, provenance model |

### Product Experience (4 files)

| File | Purpose |
|------|---------|
| `PRODUCT-EXPERIENCE-DISCOVERY.md` | Product experience discovery outcomes |
| `PRODUCT-EXPERIENCE-ARCHITECTURE.md` | Product experience architecture |
| `FIRST-VERTICAL-SLICE-UX.md` | First vertical slice UX design |
| `FIRST-VERTICAL-SLICE-UI.md` | First vertical slice UI specification |

### Governance (10 files)

| File | Purpose |
|------|---------|
| `DISCOVERY-CLOSURE.md` | Business discovery closure record |
| `CANONICAL-UPDATE-REPORT.md` | v1 canonical update report |
| `FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` | Final semantic resolution (7 issues resolved) |
| `FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` | Second hostile review (1 blocker, 9 HIGH) |
| `FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` | Adversarial review of foundational decisions |
| `ADVERSARIAL-DECISION-REVIEW.md` | Full adversarial decision review |
| `FOUNDATIONAL-DECISIONS-BRIEF.md` | Foundational decisions brief |
| `SECOND-ORDER-ARCHITECTURE-REVIEW.md` | Second-order architecture review |
| `CANONICAL-AMENDMENT-REPORT.md` | Amendment report (what changed from v1) |
| `CANONICAL-CONSISTENCY-AUDIT.md` | Post-amendment consistency audit (0 contradictions) |

### Archive (31 files) — HISTORICAL, NON-AUTHORITATIVE

Discovery documents, early domain models, platform reviews, and reconciliation records from the pre-v1 process. Preserved for historical traceability but NOT current specifications.

---

## 3. Canonical Counts (Verified)

| Concept | Count | Breakdown |
|---------|-------|-----------|
| Domain Entities | 11 | 5 aggregate roots + 3 child entities + 3 supporting entities |
| Infrastructure Entities | 2 | ExternalIdentifier, FieldProvenance |
| Staging Entities | 2 | ImportBatch, PendingImport (UUID PKs, ephemeral) |
| Value Objects | 28 | 12 non-enum immutable PHP objects + 16 PHP Backed Enums |
| Enums | 16 | 3 behavioural + 13 pure |
| Domain Events | 29 | Plain PHP classes |
| Actions | 20 | Application-layer orchestration |
| RBAC Roles | 11 | 4 platform-global + 5 institution-scoped + 2 user-level |
| Database Tables | 58 | Across 10 layers |
| Category A Provenance Fields | 5 | name, type, status, accreditation_status, cut_off_mark |
| Category B Provenance Fields | 6 | founded_year, location, website, admission_requirements, application_deadline, amount |
| Total Provenance-Whitelisted Fields | 11 | Category A (5) + Category B (6) |

### Aggregate Roots (5)
1. Educational Institution
2. Programme
3. Scholarship
4. Admission Cycle
5. Information Source

### Infrastructure Entities (2)
1. ExternalIdentifier
2. FieldProvenance

---

## 4. Key Architectural Decisions Reflected

| Decision ID | Decision | ADR |
|-------------|----------|-----|
| BD-1 | Uniform BIGINT auto-increment PKs for all canonical tables | ADR-19 |
| BD-3 | PhaseSequence JSONB VO + stable phase IDs + current_phase | ADR-20 |
| BD-5 | Generic external_identifiers model (no per-entity code columns) | ADR-21 |
| ND-5 | InformationSource as independent aggregate root (no institution_id) | ADR-22 |
| ND-4 | Hybrid provenance: entity JSONB + field_provenance 80/20 | ADR-23 |

---

## 5. Source-Reference Check Result

**The differing ON DELETE behavior for source_id is INTENTIONAL and SEMANTICALLY JUSTIFIED.**

| Table | source_id ON DELETE | Relationship | Rationale |
|-------|---------------------|-------------|-----------|
| `field_provenance` | RESTRICT | Source IS the reason for the record | Provenance records exist to attribute values to sources; deleting source destroys audit chain |
| `external_identifiers` | RESTRICT | Source validates the identifier | Identifier was observed from source; losing source prevents verification |
| `cut_off_marks` | SET NULL | Source is attribution metadata | cut_off_marks is a query model; the integer value remains valid without source attribution |

Documented in: 03-domain.md §13, 05-implementation.md §4.7

---

## 6. Verification Results

| Check | Result |
|-------|--------|
| All canonical files present | ✅ 6 of 6 |
| All canonical files readable plain text | ✅ |
| No ZIP/binary embedded in Markdown | ✅ |
| v1 baseline files unmodified | ✅ (working copies amended in-place; v1 ZIP untouched) |
| v1 ZIP unmodified | ✅ |
| No duplicate canonical files | ✅ |
| Archive files marked historical | ✅ (HISTORICAL-README.md in archive/) |
| SHA-256 hashes match | ✅ (see MANIFEST.md) |
| Category A = 5 | ✅ |
| Category B = 6 | ✅ |
| Category A + B = 11 | ✅ |
| All 16 enums aligned | ✅ |
| 0 stale references | ✅ |
| 0 contradictions | ✅ |
| Migration-ready | ✅ |

---

## 7. Portability Assessment

A competent LLM receiving ONLY `StudyNexus-Pre-Implementation-Baseline-v2.zip` can:

| Capability | Status | Notes |
|------------|--------|-------|
| Understand the product | ✅ | 01-business.md + product-experience/ |
| Understand the domain | ✅ | 03-domain.md (entities, VOs, enums, invariants, relationships) |
| Understand the architecture | ✅ | 04-architecture.md (layers, search, RBAC, provenance, concurrency) |
| Understand the acquisition boundary | ✅ | 06-data-acquisition.md (staging, adapters, provenance) |
| Understand the provenance model | ✅ | 03-domain.md §15, 02-decisions.md ADR-23, 05-implementation.md §3.5 |
| Understand PK/FK strategy | ✅ | 02-decisions.md ADR-19, 05-implementation.md §4.3 |
| Understand InformationSource/Authority | ✅ | 03-domain.md §8, ADR-22, authority_id NULL semantics documented |
| Understand external identifiers | ✅ | 03-domain.md §14, ADR-21, full schema + indexes |
| Understand AdmissionCycle phases | ✅ | 03-domain.md §5, ADR-20, stable phase IDs documented |
| Understand implementation constraints | ✅ | 05-implementation.md (stack, packages, ordering, constraints) |
| Begin migration design | ✅ | All schema decisions resolved; ON DELETE, CHECK, indexes specified |

### Remaining Ambiguity

**None that blocks migration design.** The following items are application-level conventions that a developer will decide during implementation (they are NOT architectural decisions):

1. **Exact Eloquent cast class names** for PhaseSequence, AdmissionRule, etc. — the VO types are documented; the PHP class names are implementation conventions.
2. **Filament form schema details** — field ordering, validation rules, section grouping are UI decisions, not architecture.
3. **Factory default values** — test data generation is implementation, not architecture.
4. **Exact morphMap registration location** — documented as convention; the aliases are specified.

---

*Pre-Implementation Baseline v2 Report — 2026-08-17 — FROZEN*
