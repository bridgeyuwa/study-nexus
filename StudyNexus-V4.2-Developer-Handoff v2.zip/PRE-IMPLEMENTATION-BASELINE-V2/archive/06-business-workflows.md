# StudyNexus — Business Workflows

Workflows describe how users achieve business goals by exercising business capabilities. They are derived from approved business discovery, not invented independently. Variations within a workflow remain within the same workflow unless they introduce fundamentally different business goals. Workflows may be executed in any order; there is no mandatory sequence.

---

## Workflow Classification

| Category | Workflows | Status |
|----------|-----------|--------|
| **Canonical** | WF1: Explore Educational Opportunities, WF2: Evaluate Educational Opportunities, WF3: Compare Educational Opportunities, WF4: Assess Eligibility, WF5: Assess Information Reliability, WF6: Make an Educational Decision | Confirmed across all 4 primary personas (Secondary School Student and Graduate, Undergraduate Student, Parent or Guardian, Guidance Counsellor or Teacher) |
| **Persona-Specific** | WF7: Understand Current Educational Journey | Confirmed for Undergraduate Student; applicability to other enrolled personas is an open question (OQ7-2) |
| **Potential Future** | *(None identified yet)* | To be evaluated as remaining personas are discovered |

The 6 canonical workflows represent the recurring business goals exercised by all primary personas. Their emergence across multiple personas indicates they are properties of the domain rather than of individual users. Persona-specific workflows address business goals unique to a particular persona's relationship with the domain.

---

## Canonical Business Workflows

### WF1: Explore Educational Opportunities

**Business Goal:** Understand what educational opportunities exist based on interests, qualifications, or aspirations.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Exploring tertiary institutions, programmes, scholarships, alternative admission pathways. |
| Undergraduate Student | Exploring postgraduate programmes, transfer options, scholarships, internships. |
| Parent or Guardian | Exploring opportunities on behalf of their child — same goal, acting as proxy decision-maker. |
| Guidance Counsellor or Teacher | Exploring opportunities on behalf of students — same goal, multi-student advisory context, may execute proactively to maintain professional awareness. |

**Trigger:** User wants to know what educational options are available — a broad intent, not a specific target.

**Preconditions:** User has some educational context (interests, current qualifications, or aspirations) but may not know exact names or identifiers of matching opportunities.

**Success Outcome:** User is aware of relevant educational opportunities they did not previously know about, and can identify at least one opportunity worth further evaluation.

**High-Level Business Steps:**

1. Express interests, qualifications, or aspirations (may be broad or vague).
2. Discover educational opportunities that match or relate.
3. Review discovered opportunities at a high level.
4. Identify opportunities worth further evaluation.

**Business Capabilities Exercised:** Discover Educational Opportunities, Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF1-1: Exploration must support users who do not know exact names or identifiers (structured exploration principle, A3-6).
- BR-WF1-2: Exploration results must be presented in a way that allows high-level assessment without requiring full evaluation.

**Persona-Specific Business Rules:**

- *(None identified — rules are consistent across personas)*

**Candidate Business Concepts:** Structured Exploration (established in Topic 3, not candidate).

**Open Questions:**

- What parameters guide structured exploration per persona? (Deferred to Product Discovery)

---

### WF2: Evaluate Educational Opportunities

**Business Goal:** Gather sufficient information about an educational opportunity to make an informed decision.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Evaluating institutions, programmes, scholarship terms, admission prospects. |
| Undergraduate Student | Evaluating postgraduate institutions, scholarship conditions, transfer requirements. |
| Parent or Guardian | Evaluating opportunities on behalf of their child — may weight different information priorities (e.g., cost, safety). |
| Guidance Counsellor or Teacher | Evaluating opportunities on behalf of students — multi-student advisory, may need to evaluate across multiple student profiles. |

**Trigger:** User has identified one or more opportunities of interest (from Explore or from prior knowledge).

**Preconditions:** User has identified at least one educational opportunity to evaluate.

**Success Outcome:** User has sufficient information about the opportunity to compare it, assess eligibility, assess reliability, or make a decision.

**High-Level Business Steps:**

1. Select an educational opportunity to evaluate.
2. Review available information about the opportunity.
3. Identify information gaps — information the user needs but is not available or not sufficient.
4. Assess whether available information is sufficient for the user's decision needs.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF2-1: What constitutes "sufficient" information is user-dependent and context-dependent (OQ6-1).
- BR-WF2-2: The specific information types required (e.g., tuition, accreditation, scholarships, career pathways) belong to business rules and future domain discovery, not the workflow definition.

**Persona-Specific Business Rules:**

- *(None identified — the variation is in information priorities, which is a Product Discovery concern, not a business rule difference)*

**Candidate Business Concepts:** *(None — relies on established concepts)*

**Open Questions:**

- OQ6-1: What constitutes "sufficient" information for an evaluation or decision?
- What specific information types are required for evaluating different categories of educational opportunity? (Deferred to Domain Discovery)

---

### WF3: Compare Educational Opportunities

**Business Goal:** Objectively compare multiple opportunities using standardized information before making a decision.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Comparing institutions, programmes, scholarship packages. |
| Undergraduate Student | Comparing postgraduate programmes, scholarship packages, transfer destinations. |
| Parent or Guardian | Comparing opportunities on behalf of their child — may prioritize cost and quality dimensions. |
| Guidance Counsellor or Teacher | Comparing opportunities on behalf of students — same goal, may compare across multiple student contexts. |

**Trigger:** User has evaluated or is evaluating multiple opportunities and wants to compare them.

**Preconditions:** User has identified two or more educational opportunities to compare.

**Success Outcome:** User can see opportunities compared on standardized criteria relevant to their decision, and can identify meaningful differences and trade-offs.

**High-Level Business Steps:**

1. Select educational opportunities to compare.
2. Review available comparison criteria relevant to the decision.
3. Compare opportunities across selected criteria.
4. Identify meaningful differences and trade-offs.

**Business Capabilities Exercised:** Compare Educational Opportunities, Present Educational Knowledge.

**Business Rules:**

- BR-WF3-1: Comparison uses standardized information (A3-4, Standardized Information concept).
- BR-WF3-2: The user reviews available comparison criteria; the workflow does not assume the user defines the comparison model.
- BR-WF3-3: Available comparison criteria are determined by what standardized information exists for the selected opportunities.

**Persona-Specific Business Rules:**

- *(None identified — which criteria are most relevant per persona is a Product Discovery concern)*

**Candidate Business Concepts:** Comparison Dimension.

**Open Questions:**

- OQ6-2: What are the standard comparison dimensions?
- Who determines available comparison criteria and how? (Deferred to Product Discovery)

---

### WF4: Assess Eligibility

**Business Goal:** Determine whether the user's qualifications satisfy the published admission requirements.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Assessing eligibility for tertiary admission (UTME, Direct Entry, IJMB, JUPEB pathways). |
| Undergraduate Student | Assessing eligibility for postgraduate admission, scholarship qualification, transfer requirements. |
| Parent or Guardian | Assessing eligibility on behalf of their child, using the child's qualifications. |
| Guidance Counsellor or Teacher | Assessing eligibility on behalf of students, using each student's qualifications. |

**Trigger:** User wants to know if they qualify for a specific educational opportunity.

**Preconditions:** User has identified an educational opportunity and has (or can provide) their qualifications.

**Success Outcome:** User understands the degree to which their qualifications meet the published admission requirements.

**High-Level Business Steps:**

1. Identify the educational opportunity and its published admission requirements.
2. Review or provide own qualifications.
3. Assess the match between qualifications and requirements.
4. Understand the result — which requirements are met, partially met, or unmet.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF4-1: Assessment is based on published admission requirements as recorded by StudyNexus.
- BR-WF4-2: The method of eligibility assessment (performed by StudyNexus, self-assisted by user, or presented for manual review) is an open question deferred to Product Discovery.

**Persona-Specific Business Rules:**

- *(None identified — the assessment method is the same open question for all personas)*

**Candidate Business Concepts:** Eligibility Status.

**Open Questions:**

- OQ6-3: Does StudyNexus perform eligibility assessment for the user, present requirements for self-assessment, or both? (Deferred to Product Discovery)
- What qualification types must be supported for eligibility assessment? (Deferred to Domain Discovery)

---

### WF5: Assess Information Reliability

**Business Goal:** Determine whether educational information is trustworthy, current, and supported by authoritative sources.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Assessing reliability of admission information, cut-off marks, scholarship details. |
| Undergraduate Student | Assessing reliability of postgraduate information, scholarship details, institutional claims. |
| Parent or Guardian | Assessing reliability of information on behalf of their child — may have lower trust threshold for decisions affecting others. |
| Guidance Counsellor or Teacher | Assessing reliability of information before advising students — professional obligation to verify before recommending. |

**Trigger:** User encounters information and needs to assess its reliability before relying on it for a decision.

**Preconditions:** User is viewing educational information and has doubt or need for confidence about its accuracy or currency.

**Success Outcome:** User can make a judgment about whether to trust the information based on available trust signals.

**High-Level Business Steps:**

1. Encounter educational information of interest.
2. Review available trust signals for the information.
3. Form a judgment about the reliability of the information.

**Business Capabilities Exercised:** Verify Educational Information, Present Educational Knowledge, Preserve Information Provenance.

**Business Rules:**

- BR-WF5-1: Trust signals are implementation-neutral. They may include provenance, verification status, publication dates, official sources, editorial review, or other mechanisms.
- BR-WF5-2: The specific trust signals presented are a Product Discovery decision.

**Persona-Specific Business Rules:**

- *(None identified — trust signal presentation is the same open question for all personas)*

**Candidate Business Concepts:** Trust Signal.

**Open Questions:**

- OQ6-4: What trust signals should be presented to users? (Deferred to Product Discovery)
- OQ6-8: How do trust signals differ across Information Categories (Official, Verified, Historical, Community-Contributed)? (Deferred to Product Discovery)

---

### WF6: Make an Educational Decision

**Business Goal:** Reach a decision about whether and how to proceed with an educational opportunity.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Deciding whether to apply to an institution/programme, pursue a scholarship. |
| Undergraduate Student | Deciding whether to pursue postgraduate study, accept a scholarship, transfer. |
| Parent or Guardian | Deciding on behalf of or with their child — shared decision-making context. |
| Guidance Counsellor or Teacher | Supporting a student's decision — the counsellor advises, the student decides. Same workflow goal. |

**Trigger:** User has gathered, compared, and verified sufficient information to decide.

**Preconditions:** User has evaluated one or more educational opportunities and assessed relevant eligibility and reliability.

**Success Outcome:** User reaches a decision — whether to pursue, defer, or reject the opportunity.

**High-Level Business Steps:**

1. Consolidate information gathered about the opportunity or opportunities.
2. Weigh the relevant factors.
3. Reach a decision about the opportunity.

**Business Capabilities Exercised:** Present Educational Knowledge.

**Business Rules:**

- BR-WF6-1: The workflow ends with the user deciding. Whether the user applies, researches further, postpones, or rejects the opportunity is outside the scope of this workflow.
- BR-WF6-2: StudyNexus supports informed decision-making but does not perform applications in the MVP (A6-4).
- BR-WF6-3: This workflow is reusable for scholarships, programmes, institutions, and future educational opportunities.

**Persona-Specific Business Rules:**

- *(None identified — the decision scope is the same for all personas)*

**Candidate Business Concepts:** Educational Decision.

**Open Questions:**

- OQ6-5: Does StudyNexus provide decision support beyond presenting consolidated information? (Related to OQ4-3)
- What constitutes "sufficient confidence" to decide? (Related to OQ6-1)

---

## Persona-Specific Workflows

### WF7: Understand Current Educational Journey

**Business Goal:** Understand information relevant to the educational opportunity the user is already pursuing in order to make informed decisions throughout that journey.

**Which Personas Use This Workflow:**

| Persona | Status |
|---------|--------|
| Undergraduate Student | Confirmed — managing an existing educational commitment (programme, institution, academic progress). |
| Secondary School Student and Graduate | Not applicable — not yet enrolled in tertiary education. |
| Parent or Guardian | Not confirmed — a parent may need to understand their child's current programme, but this is an open question. |
| Guidance Counsellor or Teacher | Not confirmed — a counsellor may need to understand a student's current programme to advise effectively, but this is an open question. |

**Trigger:** User needs clarity about their current programme, institution, or academic situation — not to evaluate a new opportunity, but to manage an existing commitment.

**Preconditions:** User is currently enrolled in an educational programme.

**Success Outcome:** User has accurate, current understanding of information relevant to their ongoing educational journey, sufficient to make informed decisions.

**High-Level Business Steps:**

1. Identify the aspect of the current educational journey requiring clarity.
2. Access current, accurate information about that aspect.
3. Understand the implications for ongoing decisions.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge, Maintain Educational Knowledge (ensures information is current).

**Business Rules:**

- BR-WF7-1: This workflow is distinct from evaluation workflows because the user is not considering whether to pursue the opportunity — they are managing an existing educational commitment.
- BR-WF7-2: The workflow is defined by its business goal, not by the specific information it may present. Examples of relevant information (programme requirements, academic regulations, curriculum, graduation requirements, accreditation changes, tuition and fee updates, available scholarships, transfer opportunities, progression opportunities, postgraduate pathways) are examples only and do not become part of the workflow definition.
- BR-WF7-3: The specific information types relevant to this workflow belong to business rules and future domain discovery (consistent with BR-WF2-2).

**Persona-Specific Business Rules:**

- *(None identified for Undergraduate Student beyond the general rules above)*

**Candidate Business Concepts:** Current Educational Journey.

**Open Questions:**

- OQ7-1: What specific information types are most critical for an undergraduate managing their current journey? (Deferred to Domain Discovery)
- OQ7-2: Does this workflow apply only to Undergraduate Students, or also to other enrolled students (e.g., postgraduate)? (Active — to be evaluated as more personas are discovered)
- Does a Parent or Guardian need this workflow to understand their child's current programme? (Active — to be evaluated during remaining persona discovery)

---

## Workflow Relationships

These workflows are not executed in a mandatory sequence. Users may enter any workflow at any point based on their current need. However, typical patterns emerge:

- **Exploration → Evaluation → Comparison → Decision** is a common but not required pattern.
- **Assess Eligibility** and **Assess Information Reliability** may occur at any point after an opportunity is identified.
- **Make an Educational Decision** typically follows some combination of the other workflows but does not require all of them.
- **Understand Current Educational Journey** is independent — it does not require or feed into the other workflows, though information gained may inform them.

---

## Candidate Business Concepts — All Workflows

| Concept | Introduced In | Recurs Across Personas | Promotion Status |
|---------|--------------|----------------------|-----------------|
| Comparison Dimension | WF3 (Topic 6) | Yes — via canonical workflows across all 4 primary personas | Eligible for promotion (OQ7-3) |
| Eligibility Status | WF4 (Topic 6) | Yes — via canonical workflows across all 4 primary personas | Eligible for promotion (OQ7-3) |
| Trust Signal | WF5 (Topic 6) | Yes — via canonical workflows across all 4 primary personas | Eligible for promotion (OQ7-3) |
| Educational Decision | WF6 (Topic 6) | Yes — via canonical workflows across all 4 primary personas | Eligible for promotion (OQ7-3) |
| Current Educational Journey | WF7 (Topic 7) | No — currently Undergraduate Student only | Not yet eligible |

Per A6-10, promotion to canonical requires explicit approval. The first four concepts now recur across all four primary personas via the canonical workflows.

---

## Persona Workflow Summary

| Workflow | SS Student/Grad | Undergrad | Parent/Guardian | Guidance Counsellor/Teacher |
|----------|:---:|:---:|:---:|:---:|
| WF1: Explore Educational Opportunities | ✓ | ✓ | ✓ | ✓ |
| WF2: Evaluate Educational Opportunities | ✓ | ✓ | ✓ | ✓ |
| WF3: Compare Educational Opportunities | ✓ | ✓ | ✓ | ✓ |
| WF4: Assess Eligibility | ✓ | ✓ | ✓ | ✓ |
| WF5: Assess Information Reliability | ✓ | ✓ | ✓ | ✓ |
| WF6: Make an Educational Decision | ✓ | ✓ | ✓ | ✓ |
| WF7: Understand Current Educational Journey | — | ✓ | ? | ? |

**Total canonical workflows:** 6 (exercised by all 4 primary personas)
**Total persona-specific workflows:** 1 (Undergraduate Student)
**Total workflows:** 7
