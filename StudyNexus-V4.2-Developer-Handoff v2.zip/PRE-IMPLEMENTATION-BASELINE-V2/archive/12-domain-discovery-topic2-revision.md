# StudyNexus — Domain Discovery: Topic 2 Revision
# Aggregate Boundaries (Laravel Beyond CRUD Review)

**Date:** 2026-08-07
**Status:** Awaiting Approval
**Scope:** Aggregate boundary decisions only (DD2-1, DD2-2, DD2-3 revised; DD2-4 through DD2-8 new)
**Unchanged:** Relationship analysis, lifecycles, temporal behaviour, identity rules, cardinality, domain interactions — accepted as-is from original Topic 2

---

## Guiding Philosophy

This revision applies the pragmatic DDD philosophy of Laravel Beyond CRUD (Brent Roose & Freek Van der Herten):

1. **Aggregate roots exist to protect business invariants and consistency boundaries** — not because an entity has identity, not because it is independently searchable, not because it has a lifecycle.
2. **Having identity does not make something an aggregate root.** Many things have identity but belong within another aggregate's consistency boundary.
3. **Being independently searchable does not make something an aggregate root.** Discoverability is a product concern, not a domain concern. Read models and projections serve search; aggregates protect consistency.
4. **Anemic aggregates are a warning sign.** An aggregate root with no meaningful business behavior is likely misclassified.
5. **Every aggregate root must answer**: What invariants does it protect? What business operations does it perform? What consistency boundary does it define?
6. **Practical over theoretical.** The model must serve the business domain. Patterns that add complexity without protecting real invariants should be simplified.

---

## DD2-1 (Revised): Aggregate Root Classifications

### Evaluation Criteria

For each entity, we evaluate against five questions:

| # | Question | Implication if No |
|---|----------|-------------------|
| 1 | Does it protect business invariants? | Not an aggregate root — no consistency boundary to define |
| 2 | Does it have an independent lifecycle? | May be a child entity — lifecycle driven by parent |
| 3 | Can the business manipulate it independently? | May be a child or supporting entity — no autonomous business operations |
| 4 | Would domain experts treat it as a standalone business concept? | May be a child or supporting entity — always qualified by context |
| 5 | Does it define its own consistency boundary? | Not an aggregate root — consistency is within another boundary |

### Evaluation Matrix

| Entity | Protects Invariants? | Independent Lifecycle? | Independently Manipulable? | Standalone to Domain Experts? | Own Consistency Boundary? | Classification |
|--------|:---:|:---:|:---:|:---:|:---:|---------------|
| Educational Institution | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Aggregate Root** |
| Programme | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Aggregate Root** |
| Scholarship | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Aggregate Root** |
| Admission Cycle | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Aggregate Root** |
| Information Source | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Aggregate Root** |
| Admission Policy | No | Partially | No | No | No | **Child Entity** |
| Eligibility Policy | No | Partially | No | No | No | **Child Entity** |
| Accreditation Record | No | Partially | No | No | No | **Child Entity** |
| Qualification | No | Minimal | No | Partially | No | **Supporting Entity** |
| Scholarship Provider | No | Minimal | No | Partially | No | **Supporting Entity** |
| Government Education Agency | No | Minimal | No | Partially | No | **Supporting Entity** |

---

### Aggregate Root Justifications

#### Educational Institution — Aggregate Root

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **Yes.** An Institution maintains the invariant that its type determines which agency can accredit it (INV-3). It ensures institutional-level admission policies are one-per-cycle. It governs which programmes it offers. |
| Independent lifecycle? | **Yes.** Established → Operational → Suspended → Closed. Each transition is a significant business event in the Nigerian education landscape. |
| Independently manipulable? | **Yes.** Domain operations: establish institution, suspend operations, close permanently, merge with another, rename. These are meaningful business actions, not CRUD. |
| Standalone to domain experts? | **Yes.** "University of Lagos" is discussed as a standalone entity. Domain experts reason about institutions independently. |
| Own consistency boundary? | **Yes.** The institution's type, name, operational status, institutional policies, and institutional accreditation must be internally consistent. Changing an institution's type has cascading effects on accreditation and programmes. |

**Business responsibilities**: Establish institution, manage programmes, publish institutional admission policies, record institutional accreditation events, suspend/close/merge/rename.

---

#### Programme — Aggregate Root

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **Yes.** A Programme maintains the invariant that only one admission policy is active per admission cycle. It ensures its admission status is the conjunction of its lifecycle state and the cycle state. It governs its own admission policies and programme-level accreditation. |
| Independent lifecycle? | **Yes.** Introduced → Admitting → Suspended → Discontinued. Each transition is a business event affecting the admission landscape. |
| Independently manipulable? | **Yes.** Domain operations: introduce programme, publish admission requirements for a cycle, suspend admission, resume admission, discontinue. These are significant business actions. |
| Standalone to domain experts? | **Yes.** "Computer Science at University of Lagos" is discussed as a standalone entity. This is the primary unit of admission — domain experts reason about admission at the programme level, not the institution level. |
| Own consistency boundary? | **Yes.** A programme's admission policies, accreditation records, and lifecycle state must be internally consistent. Publishing a new admission policy for a cycle must supersede the previous one — this consistency belongs to the Programme, not to any external coordinator. |

**Why not a child entity of Institution?** A university may offer 50-100+ programmes. Embedding all programmes within the Institution aggregate would create an unbounded aggregate that cannot enforce meaningful consistency. More importantly, the Programme has its own invariants (one active policy per cycle, admission status derivation) that the Institution does not protect. The Institution ensures programmes belong to it; the Programme ensures its own admission consistency.

**Business responsibilities**: Introduce programme, publish admission requirements per cycle, determine admission status for a cycle, suspend/resume admission, discontinue, record programme-level accreditation, derive current accreditation status.

---

#### Scholarship — Aggregate Root

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **Yes.** A Scholarship maintains the invariant that only one eligibility policy is active per period. It ensures applications can only be opened when in the correct lifecycle state. It governs its applicability to programmes and institutions. |
| Independent lifecycle? | **Yes.** Announced → Open → Closed → Expired. Each transition is a business event. |
| Independently manipulable? | **Yes.** Domain operations: announce scholarship, open applications, close applications, publish eligibility criteria, withdraw, target programmes/institutions. |
| Standalone to domain experts? | **Yes.** "Shell Undergraduate Scholarship" is discussed as a standalone opportunity. |
| Own consistency boundary? | **Yes.** The scholarship's eligibility policy, application period, and lifecycle state must be internally consistent. You cannot open applications without a published eligibility policy. You cannot close applications that were never opened. |

**Business responsibilities**: Announce scholarship, publish eligibility criteria, open/close applications, withdraw, target programmes/institutions, determine applicability.

---

#### Admission Cycle — Aggregate Root

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **Yes.** An Admission Cycle maintains the invariant that phase transitions follow a defined sequence. You cannot go from "closed" back to "registration open". The cycle protects the temporal integrity of the admission process. |
| Independent lifecycle? | **Yes.** Upcoming → Registration Open → Examination Period → Results Released → Admission Period → Closed → Archived. |
| Independently manipulable? | **Yes.** Domain operations: announce cycle, open registration, begin examinations, release results, open admission period, close cycle. These are significant business actions (JAMB announces the UTME cycle; institutions announce their admission periods). |
| Standalone to domain experts? | **Yes.** "2024/2025 UTME Cycle" is a standalone concept. The admission cycle is the temporal backbone of the entire system. |
| Own consistency boundary? | **Yes.** The cycle's phases must follow the correct sequence. The cycle's dates must be temporally consistent (registration opens before examinations, etc.). |

**Business responsibilities**: Announce cycle, open registration, begin examinations, release results, open admission period, close cycle, archive, determine current phase.

---

#### Information Source — Aggregate Root

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **Yes.** An Information Source protects the invariant that a source cannot be simultaneously verified and unreliable. Its reliability status affects trust signals for all information derived from it — this is a cascading consistency concern. |
| Independent lifecycle? | **Yes.** Discovered → Verified → Unreliable → Deprecated. |
| Independently manipulable? | **Yes.** Domain operations: register source, verify reliability, mark unreliable, deprecate. Verifying a source is a meaningful business decision (part of the Verify capability, A5-1). |
| Standalone to domain experts? | **Yes.** "JAMB official website" is a distinct, discussable concept. Source reliability is a first-class concern (WF5). |
| Own consistency boundary? | **Yes.** A source's verification status must be internally consistent. Marking a source unreliable affects trust for all entities that reference it — this cascading effect requires the source to be its own consistency boundary. |

**Business responsibilities**: Register source, verify reliability, mark unreliable, deprecate, assess current reliability status.

---

### Child Entity Justifications

#### Admission Policy — Child Entity of Programme or Institution

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **No.** What invariants does an Admission Policy protect independently? Its rules must be internally consistent (e.g., you cannot simultaneously require 5 and 2 O'level credits), but this is validation, not a business invariant. The real invariants — one active policy per cycle, policies apply to correct cycles — belong to the Programme/Institution. |
| Independent lifecycle? | **Partially.** It has states (draft → published → active → superseded → retired), but these transitions are driven by the parent entity and the admission cycle. A programme publishes its requirements for a cycle. The policy does not decide to publish itself. |
| Independently manipulable? | **No.** You do not "manage admission policies" as a standalone business operation. You "publish admission requirements for a programme for a cycle." The operation is always: `programme.publishAdmissionPolicy(cycle, rules)`. |
| Standalone to domain experts? | **No.** Domain experts talk about "the admission requirements for Computer Science at UNILAG for 2024/2025" — always qualified by programme and cycle. No one discusses "Admission Policy #1234" in isolation. |
| Own consistency boundary? | **No.** The consistency between policies (one active per cycle, correct supersession sequence) is protected by the Programme aggregate. The policy's internal consistency (valid rules) is validation, not a transactional invariant. |

**Why was it previously an aggregate root?** The original Topic 2 classified Admission Policy as an aggregate root based on two arguments: (1) it has its own lifecycle, and (2) embedding it within Programme would make the Programme aggregate too large. Both arguments are rejected under pragmatic DDD:

1. **Lifecycle ≠ aggregate root.** A child entity can have lifecycle states. What matters is who drives the transitions. Admission Policy's transitions are driven by its parent — the programme publishes, the cycle activation makes it active, a new policy supersedes it. The policy doesn't act autonomously.

2. **Aggregate size is managed by loading strategy, not by fracturing the model.** The Programme aggregate does not need to load all historical policies for every operation. It loads what is needed for the current business operation. When publishing a new policy, the Programme needs the current/previous policy for the same cycle. When a user views admission requirements, a read model serves the current policy. The aggregate boundary defines consistency, not loading scope.

**Owner**: Programme (for programme-level policies) or Institution (for institutional-level policies). The parent protects the invariant of one active policy per cycle.

---

#### Eligibility Policy — Child Entity of Scholarship

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **No.** Same analysis as Admission Policy. The real invariant — one active eligibility policy per period — belongs to the Scholarship. |
| Independent lifecycle? | **Partially.** Same pattern as Admission Policy — lifecycle driven by parent. |
| Independently manipulable? | **No.** The business operation is `scholarship.publishEligibilityPolicy(period, rules)`, not standalone policy management. |
| Standalone to domain experts? | **No.** "The eligibility criteria for Shell Scholarship 2024" — always qualified by scholarship and period. |
| Own consistency boundary? | **No.** Consistency is within the Scholarship boundary. |

**Owner**: Scholarship. The Scholarship protects the invariant of one active eligibility policy per period, and the invariant that applications cannot open without a published policy.

---

#### Accreditation Record — Child Entity of Programme or Institution

| Criterion | Assessment |
|-----------|-----------|
| Protects invariants? | **No.** An Accreditation Record is a recorded fact — "NUC granted full accreditation to Computer Science at UNILAG on 2023-06-01". Facts do not protect invariants; they are data. The invariants around accreditation — only the correct agency can accredit (INV-3), accreditation status affects admission — belong to the Programme/Institution. |
| Independent lifecycle? | **Partially.** It has states (granted → renewed → suspended → revoked → expired), but these transitions are driven by external events (the agency's actions). StudyNexus records these events; it does not perform them. In the MVP, StudyNexus acquires accreditation information from sources (A2-11) — it does not manage accreditation. |
| Independently manipulable? | **No.** The business operation is `programme.recordAccreditation(agency, status, period)` — recording a fact, not managing an entity. Only the granting agency changes accreditation status, and StudyNexus records this change, it does not initiate it. |
| Standalone to domain experts? | **No.** "The accreditation of Computer Science at UNILAG" — always qualified by entity and agency. No one discusses "Accreditation Record #5678" in isolation. |
| Own consistency boundary? | **No.** The consistency between records (current status derives from most recent record, correct agency for institution type) is protected by the Programme/Institution. |

**Why was it previously an aggregate root?** The original Topic 2 classified Accreditation Record as an aggregate root because it is "a fact about the relationship between an Agency and an Institution/Programme" and was deemed "not owned by either." Under pragmatic DDD, this reasoning is inverted: precisely because it is a recorded fact (not an entity with autonomous behavior), it belongs within the aggregate that uses it. The Programme/Institution derives its current accreditation status from its records — this derivation is a Programme/Institution concern, not an independent concern.

**Dual reference concern**: An Accreditation Record references both the accredited entity and the granting agency. This was previously cited as evidence that it cannot belong to either. But in StudyNexus's domain, the Programme is the primary context — users check a programme's accreditation, not an agency's list of accredited programmes. The Agency is referenced within the record but is not the consistency boundary.

**Owner**: Programme (for programme-level accreditation) or Institution (for institutional-level accreditation). The parent protects the invariant that accreditation is from the correct agency for its type (INV-3), and derives its current accreditation status from its records.

---

### Supporting Entity Justifications

#### Qualification — Supporting Entity

Qualification is reference data in the Nigerian education domain. It has identity (needed for references from Admission/Eligibility Policies) but:

- **No invariants to protect.** A qualification is a stable classification (WAEC SSCE, JAMB UTME, NCE, ND, HND). There are no business rules that require a Qualification aggregate to enforce consistency.
- **No business operations.** StudyNexus records qualifications; it does not manage them. Qualifications are defined by examining bodies external to StudyNexus.
- **No consistency boundary.** No operation on a Qualification requires transactional consistency with other entities.
- **Domain experts treat it as a classification system**, not a manipulable business concept. "WAEC SSCE" is a label used in admission rules, not an entity with behavior.

Qualification is referenced by Admission Rules and Eligibility Rules (value objects within policies). It may be referenced by Government Education Agency (the body that defines/awards it). These are reference relationships, not consistency relationships.

---

#### Scholarship Provider — Supporting Entity

Scholarship Provider is reference data in StudyNexus's MVP domain. It has identity (referenced by Scholarships) but:

- **No invariants to protect in MVP.** A provider is an organization that offers scholarships. In the MVP (Stage 1), StudyNexus acquires scholarship information from public sources (A2-11, A4-3). It does not manage providers.
- **No business operations in MVP.** Provider management (create, update, verify) is explicitly excluded from MVP (A4-3: "scholarship provider self-service" is excluded). In Stage 3, if providers become active participants, this classification may be re-evaluated.
- **No consistency boundary.** A provider's name or status changing does not require transactional consistency with its scholarships. Scholarship records reference the provider; they do not depend on it for consistency.

**Future consideration**: In Stage 3 (Education Ecosystem), Scholarship Providers may become aggregate roots with business operations (publish scholarships, manage eligibility criteria, verify applicant information). This is a legitimate evolution of the model as the business context changes.

---

#### Government Education Agency — Supporting Entity

Government Education Agency is reference data. It has identity (referenced by Accreditation Records and Qualifications) but:

- **No invariants to protect.** Agencies are defined by legislation. Their properties (name, abbreviation, jurisdiction) are externally determined. StudyNexus does not manage agencies.
- **No business operations.** Agency restructuring is an external event that StudyNexus records, not a business operation it performs.
- **No consistency boundary.** No operation on a Government Education Agency requires transactional consistency with other entities.
- **Domain experts treat agencies as part of the regulatory landscape**, not as entities with autonomous behavior in StudyNexus's domain.

Agencies are referenced for two purposes: (1) as the granting authority in Accreditation Records, and (2) as the examining/awarding body for Qualifications. Both are reference relationships.

---

## DD2-2 (Revised): Ownership vs Aggregate Membership

### Revised Principle

In the original Topic 2, composition implied independent aggregate roots with mandatory references. Under pragmatic DDD, **composition implies aggregate membership** — if an entity cannot exist without its parent and its consistency is protected by the parent, it is a child entity within the parent's aggregate.

| Relationship | Original Classification | Revised Classification | Rationale |
|-------------|----------------------|---------------------|-----------|
| Institution → Programme | Composition (separate aggregate roots) | **Composition (Programme is aggregate root with mandatory parent)** | Programme is an aggregate root because it has its own invariants (one active policy per cycle, admission status derivation) that the Institution does not protect. Programme's aggregate is independently consistent. |
| Programme → Admission Policy | Composition (separate aggregate roots) | **Composition (Admission Policy is child entity of Programme)** | Admission Policy has no independent invariants. The Programme protects the one-active-per-cycle invariant. The policy's lifecycle is driven by the Programme. |
| Institution → Admission Policy | Composition (separate aggregate roots) | **Composition (Admission Policy is child entity of Institution)** | Same rationale — institutional-level policies are children of the Institution. |
| Scholarship → Eligibility Policy | Composition (separate aggregate roots) | **Composition (Eligibility Policy is child entity of Scholarship)** | Eligibility Policy has no independent invariants. The Scholarship protects the one-active-per-period invariant. |
| Programme → Accreditation Record | Association (separate aggregate roots) | **Composition (Accreditation Record is child entity of Programme)** | Accreditation records exist within the Programme's context. The Programme derives its current status from them and protects the agency-type invariant (INV-3). |
| Institution → Accreditation Record | Association (separate aggregate roots) | **Composition (Accreditation Record is child entity of Institution)** | Same rationale for institutional-level accreditation. |
| Provider → Scholarship | Aggregation (separate aggregate roots) | **Association (Scholarship references Provider as supporting entity)** | No change in effect — Scholarship is an aggregate root, Provider is a supporting entity. The reference is an association. |
| Agency → Accreditation Record | Association (separate aggregate roots) | **Association (Accreditation Record references Agency as supporting entity)** | The Agency is referenced within the record but does not own the record. The record belongs to the Programme/Institution aggregate. |

### Key Change: Ownership Now Implies Aggregate Membership

The most significant revision: **composition relationships now imply aggregate membership**, not just mandatory references between independent aggregates.

- **Admission Policy** is structurally within the Programme/Institution aggregate. The Programme/Institution creates, publishes, and supersedes policies.
- **Eligibility Policy** is structurally within the Scholarship aggregate. The Scholarship publishes and supersedes its eligibility criteria.
- **Accreditation Record** is structurally within the Programme/Institution aggregate. The Programme/Institution records accreditation events and derives current status.

**Programme remains an aggregate root** despite being compositionally owned by Institution. This is the exception where ownership does not imply aggregate membership, because:
1. The Institution aggregate would be unbounded (50-100+ programmes per university)
2. The Programme has its own invariants that the Institution does not protect
3. Programme is the primary unit of admission — domain experts reason about it independently
4. Programme has significant business behavior (publish admission policies, determine admission status, manage accreditation)

This is consistent with Laravel Beyond CRUD: aggregate boundaries follow business behavior and invariant protection, not blindly following ownership hierarchies.

---

## DD2-3 (Revised): Child Entity Analysis

### Admission Policy as Child Entity

| Property | Detail |
|----------|--------|
| **Owner** | Programme (programme-level) or Institution (institutional-level) |
| **Why independent consistency is unnecessary** | The only invariants around admission policies (one active per cycle, correct supersession sequence) are Programme/Institution concerns. The policy's internal consistency (valid rules) is validation, not a transactional invariant. |
| **Which aggregate protects its invariants** | The Programme/Institution aggregate. When a Programme publishes a new admission policy for a cycle, the Programme: (1) validates the rules, (2) ensures no other active policy exists for the same cycle, (3) supersedes the previous policy, (4) updates the policy's lifecycle state. All of these must be consistent within a single Programme operation. |
| **Identity** | Scoped to parent + cycle. "Computer Science at UNILAG admission requirements for 2024/2025". Has identity within the parent aggregate to distinguish policies across cycles. |
| **Lifecycle** | Draft → Published → Active → Superseded → Retired. Transitions driven by parent operations. |

### Eligibility Policy as Child Entity

| Property | Detail |
|----------|--------|
| **Owner** | Scholarship |
| **Why independent consistency is unnecessary** | The invariant (one active per period) is a Scholarship concern. Publishing eligibility criteria is a Scholarship operation. |
| **Which aggregate protects its invariants** | The Scholarship aggregate. When a Scholarship publishes eligibility criteria, the Scholarship: (1) validates the rules, (2) ensures no other active policy for the same period, (3) supersedes the previous policy. |
| **Identity** | Scoped to Scholarship + period. Has identity within the Scholarship aggregate to distinguish policies across periods. |
| **Lifecycle** | Draft → Published → Active → Superseded → Retired. Same pattern as Admission Policy. |

### Accreditation Record as Child Entity

| Property | Detail |
|----------|--------|
| **Owner** | Programme (programme-level) or Institution (institutional-level) |
| **Why independent consistency is unnecessary** | An Accreditation Record is a recorded fact, not an autonomous entity. The invariants around accreditation (correct agency for institution type, current status derivation) are Programme/Institution concerns. |
| **Which aggregate protects its invariants** | The Programme/Institution aggregate. When recording an accreditation event, the Programme: (1) validates that the agency is correct for its institution type (INV-3), (2) adds the record to its history, (3) updates its derived current accreditation status. |
| **Identity** | Scoped to parent + agency + effective date. Has identity within the parent aggregate to distinguish records across time. |
| **Lifecycle** | Granted → Interim → Partial → Renewed → Suspended → Revoked → Expired. Transitions are recorded (not performed) by StudyNexus. |

---

## DD2-4 (New): Value Object Discovery

### Value Objects Within Policies

| Value Object | Belongs To | Defined By | Why Value Object |
|-------------|-----------|-----------|-----------------|
| **Admission Rule** | Admission Policy | Qualification + threshold + subject combination (e.g., "requires WAEC SSCE with 5 credits including Mathematics and English") | Defined entirely by its attributes. Two rules with the same qualification, threshold, and subjects are the same rule. No identity needed. Rules are compared by value when evaluating eligibility. |
| **Eligibility Rule** | Eligibility Policy | Qualification + threshold + condition (e.g., "must be studying Engineering", "CGPA ≥ 3.5") | Same rationale as Admission Rule. Defined by attributes, not identity. |
| **Subject Combination** | Admission Rule | Set of required subjects (e.g., "Mathematics, Physics, Chemistry" for Engineering programmes) | Defined by its contents. Two combinations with the same subjects are the same combination. Order may or may not matter (domain question). |
| **Qualification Threshold** | Admission/Eligibility Rule | Qualification reference + minimum value + comparator (e.g., "JAMB UTME ≥ 200", "WAEC SSCE credits ≥ 5") | Defined by its attributes. The threshold is the rule's constraint on a qualification. No identity — two thresholds with the same qualification, value, and comparator are the same. |
| **Cut-off Mark** | Admission Policy (or derived) | Score value + qualification context (e.g., "200 for JAMB UTME", "250 for post-UTME") | A specialized form of Qualification Threshold used specifically for minimum admission scores. In Nigerian domain, "cut-off mark" is a distinct and well-understood concept (defined in glossary). Defined by value, not identity. |

### Enum-like Value Objects (Domain Classifications)

| Value Object | Possible Values | Why Value Object |
|-------------|----------------|-----------------|
| **Institution Type** | University, Polytechnic, College of Education, Innovation Enterprise Institution | Finite, stable classification. Determines which agency can accredit (INV-3). Defined by value — two institutions of the same type are interchangeable for regulatory purposes. |
| **Award Level** | B.Sc., B.A., B.Eng., M.Sc., Ph.D., ND, HND, NCE, etc. | Finite classification of programme awards. Determines admission pathways (Direct Entry for ND/HND/NCE holders). |
| **Accreditation Status** | Granted, Interim, Partial, Renewed, Suspended, Revoked, Expired | Finite lifecycle classification for Accreditation Records. Each status has different trust implications. |
| **Policy Status** | Draft, Published, Active, Superseded, Retired | Finite lifecycle classification for Admission/Eligibility Policies. |
| **Programme Status** | Introduced, Admitting, Suspended, Discontinued | Finite lifecycle classification for Programmes. |
| **Scholarship Status** | Announced, Open, Closed, Expired, Withdrawn | Finite lifecycle classification for Scholarships. |
| **Institution Status** | Established, Operational, Suspended, Closed | Finite lifecycle classification for Institutions. |
| **Admission Cycle Phase** | Upcoming, Registration Open, Examination Period, Results Released, Admission Period, Closed, Archived | Finite lifecycle classification for Admission Cycles. |
| **Information Category** | Official, Verified, Historical, Community-Contributed | Per A3-7 — business concept, defined as value object. |
| **Source Reliability** | Discovered, Verified, Unreliable, Deprecated | Finite lifecycle classification for Information Sources. |

### Composite Value Objects

| Value Object | Composition | Why Value Object |
|-------------|------------|-----------------|
| **Validity Period** | Start date + end date | A date range that defines when something is effective. Defined by its boundaries. Two periods with the same dates are the same period. Used by Accreditation Records, Admission Policies, and Eligibility Policies. |
| **Trust Signal** | Provenance reference + verification status + last verified date + source reliability + information category | Composed of multiple attributes that together form a trust assessment. Per A6-8, trust signals are implementation-neutral — they are a value computed from multiple sources, not a persisted entity. Two pieces of information with the same provenance, verification, and currency have the same trust signal. |

### Value Objects Rejected

| Proposed | Why Rejected |
|----------|-------------|
| **Minimum Score** | Too granular — subsumed by Qualification Threshold. A minimum score is one attribute of a threshold, not a standalone domain concept. |
| **Institution Name** | While names change over time, an institution's name is tracked as a historical fact (name changes are business events). This is more complex than a simple value object — it requires temporal tracking. Model as a collection of name records, not a single value object. |

---

## DD2-5 (New): Aggregate Responsibilities

### Educational Institution

| Business Operation | Description | Invariants Protected |
|-------------------|-------------|---------------------|
| `establish(name, type, regulatoryBody)` | Record a new institution in the knowledge base | Type must be valid; regulatory body must match type (INV-3) |
| `addProgramme(programme)` | Introduce a new programme offered by this institution | Programme must reference this institution; programme award level must be valid for institution type |
| `removeProgramme(programme)` | Discontinue a programme | Programme must belong to this institution |
| `publishAdmissionPolicy(cycle, rules)` | Publish institutional-level admission requirements for a cycle | Only one active institutional policy per cycle; supersede previous policy if exists |
| `recordAccreditation(agency, status, period)` | Record an institutional-level accreditation event | Agency must be correct for this institution's type (INV-3) |
| `suspend(reason)` | Suspend institutional operations | Must be operational |
| `close()` | Permanently close | Must be operational or suspended |
| `mergeWith(institution)` | Merge with another institution | Both must be operational; merged institution transitions to merged state |
| `rename(newName, effectiveDate)` | Change official name | Name must differ from current; effective date must be valid |
| `currentAccreditationStatus()` | Derive current accreditation from records | Derived from most recent Accreditation Record |
| `activeAdmissionPolicy(cycle)` | Get current institutional admission policy for a cycle | Returns the active policy for the given cycle |

**Not CRUD**: These are meaningful business operations. `publishAdmissionPolicy` is not "create/update admission policy" — it is the business act of publishing admission requirements for a specific cycle, with invariant enforcement (one active per cycle, correct supersession).

---

### Programme

| Business Operation | Description | Invariants Protected |
|-------------------|-------------|---------------------|
| `introduce(institution, name, awardLevel)` | Record a new programme at an institution | Institution must exist; award level must be valid for institution type |
| `publishAdmissionPolicy(cycle, rules)` | Publish admission requirements for a cycle | Only one active policy per cycle; supersede previous policy; cycle must be valid |
| `suspendAdmission(reason)` | Suspend admission | Must be in admitting state; cannot admit while suspended |
| `resumeAdmission()` | Resume admission | Must be in suspended state |
| `discontinue()` | Permanently discontinue | Must not be already discontinued |
| `recordAccreditation(agency, status, period)` | Record a programme-level accreditation event | Agency must be correct for institution type (INV-3) |
| `isAdmitting(cycle)` | Determine if admitting in a given cycle | Result = (lifecycle state is Admitting) ∧ (cycle phase is Admission Period) |
| `currentAdmissionPolicy(cycle)` | Get active admission policy for a cycle | Returns the active policy; fails if none exists for cycle |
| `currentAccreditationStatus()` | Derive current accreditation from records | Derived from most recent Accreditation Record |

**Not CRUD**: `publishAdmissionPolicy` is the core business operation of a programme — it is how admission requirements enter the domain. `isAdmitting` is a derived business query, not a stored flag. `recordAccreditation` is a domain event recording, not a create operation.

---

### Scholarship

| Business Operation | Description | Invariants Protected |
|-------------------|-------------|---------------------|
| `announce(provider, name, period)` | Announce a new scholarship | Provider must exist; period must be valid |
| `publishEligibilityPolicy(period, rules)` | Publish eligibility criteria | Only one active policy per period; supersede previous; cannot publish without at least one rule |
| `openApplications()` | Open for applications | Must be in "announced" state; must have a published eligibility policy |
| `closeApplications()` | Close applications | Must be in "open" state |
| `withdraw()` | Withdraw the scholarship | Must be announced or open |
| `targetProgrammes(programmes)` | Set programme targets | Programmes must exist |
| `targetInstitutions(institutions)` | Set institution targets | Institutions must exist |
| `isApplicableTo(programme)` | Check if scholarship applies to a programme | Derived from targeting rules |
| `currentEligibilityPolicy()` | Get active eligibility policy | Returns the active policy |

**Not CRUD**: `openApplications` enforces the invariant that applications cannot open without a published eligibility policy. This is a real business rule — you cannot accept applications if you haven't defined who is eligible.

---

### Admission Cycle

| Business Operation | Description | Invariants Protected |
|-------------------|-------------|---------------------|
| `announce(period)` | Announce a new admission cycle | Period must be valid; no overlapping cycle for the same scope |
| `openRegistration()` | Begin registration | Must be in "upcoming" state |
| `beginExaminations()` | Examination period begins | Must be in "registration open" state |
| `releaseResults()` | Results are available | Must be in "examination period" state |
| `openAdmission()` | Admission period begins | Must be in "results released" state |
| `close()` | Cycle ends | Must be in "admission period" state |
| `archive()` | Archive the cycle | Must be in "closed" state |
| `isAdmissionOpen()` | Check if currently in admission period | Derived from current phase |

**Not CRUD**: Every transition enforces phase sequence invariants. You cannot skip phases or go backwards. This is the core temporal integrity of the admission process.

---

### Information Source

| Business Operation | Description | Invariants Protected |
|-------------------|-------------|---------------------|
| `register(name, reference, type)` | Register a new information source | Reference must be non-empty; type must be valid |
| `verify()` | Confirm source reliability | Must be in "discovered" or "unreliable" state; cannot be simultaneously verified and unreliable |
| `markUnreliable(reason)` | Mark as unreliable | Must be in "verified" state |
| `deprecate()` | Mark as no longer accessible | Can deprecate from any state |
| `isReliable()` | Check reliability status | Derived from current state |

**Not CRUD**: `verify` and `markUnreliable` are significant business decisions with cascading trust implications. Marking a source unreliable affects the trust signals of every piece of information derived from it.

---

## DD2-6 (New): Aggregate Invariants

### Educational Institution

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-I1 | An Institution has a valid type (University, Polytechnic, College of Education, IEI). | `establish()` |
| INV-I2 | An Institution can only be accredited by the agency appropriate to its type (NUC for universities, NBTE for polytechnics/IEIs, NCCE for colleges of education). | `recordAccreditation()` |
| INV-I3 | Only one active institutional Admission Policy per Admission Cycle. | `publishAdmissionPolicy()` |
| INV-I4 | An Institution always has a current official name. | `establish()`, `rename()` |
| INV-I5 | A closed institution cannot perform business operations. | `close()` |

### Programme

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-P1 | A Programme belongs to exactly one Institution. | `introduce()` |
| INV-P2 | Only one active Admission Policy per Admission Cycle. | `publishAdmissionPolicy()` |
| INV-P3 | A Programme's admission status = (lifecycle state is Admitting) ∧ (cycle is in Admission Period). | `isAdmitting()` |
| INV-P4 | A Programme's award level is valid for its Institution's type. | `introduce()` |
| INV-P5 | A Programme's accreditation can only be from the agency appropriate to its Institution type. | `recordAccreditation()` |
| INV-P6 | A discontinued programme cannot perform business operations. | `discontinue()` |

### Scholarship

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-S1 | A Scholarship has exactly one Provider. | `announce()` |
| INV-S2 | Only one active Eligibility Policy per period. | `publishEligibilityPolicy()` |
| INV-S3 | Applications can only be opened when the Scholarship is in "announced" state. | `openApplications()` |
| INV-S4 | Applications can only be closed when the Scholarship is in "open" state. | `closeApplications()` |
| INV-S5 | Applications cannot be opened without a published Eligibility Policy. | `openApplications()` |

### Admission Cycle

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-C1 | A cycle has defined start and end dates. | `announce()` |
| INV-C2 | Phase transitions follow the defined sequence (no backwards, no skipping). | All transition operations |
| INV-C3 | A cycle is time-bounded. | `announce()` |

### Information Source

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-IS1 | A source cannot be simultaneously verified and unreliable. | `verify()`, `markUnreliable()` |
| INV-IS2 | A deprecated source cannot be verified. | `verify()` |
| INV-IS3 | Every registered source has a retrievable reference. | `register()` |

---

## DD2-7 (New): Business Consistency Boundaries

### Operations and Their Consistency Boundaries

| Business Operation | Consistency Must Include | Protected By Aggregate |
|-------------------|------------------------|---------------------|
| **Publish admission requirements for a programme for a cycle** | The programme, the new policy, the previous policy (if any) for the same cycle | **Programme** — ensures one active per cycle, correct supersession |
| **Publish institutional admission requirements for a cycle** | The institution, the new policy, the previous policy (if any) | **Educational Institution** — ensures one active per cycle |
| **Publish eligibility criteria for a scholarship** | The scholarship, the new policy, the previous policy (if any) | **Scholarship** — ensures one active per period, application state consistency |
| **Open scholarship applications** | The scholarship, its eligibility policy, its lifecycle state | **Scholarship** — ensures policy is published, state is correct |
| **Suspend a programme** | The programme, its lifecycle state | **Programme** — ensures valid state transition |
| **Discontinue a programme** | The programme, its lifecycle state | **Programme** — ensures valid state transition |
| **Record accreditation event** | The programme/institution, the new record, the agency reference | **Programme/Institution** — ensures agency is correct for type (INV-3), derives new current status |
| **Advance admission cycle phase** | The cycle, its current phase | **Admission Cycle** — ensures correct sequence |
| **Verify an information source** | The source, its current reliability status | **Information Source** — ensures state consistency |
| **Rename an institution** | The institution, its name history | **Educational Institution** — records name change as business event |
| **Add a programme to an institution** | The institution, the new programme | **Educational Institution** — ensures programme references this institution; **Programme** (separate aggregate) — ensures it references the institution |

### Cross-Aggregate Operations

Some business operations involve multiple aggregates but do not require cross-aggregate transactional consistency:

| Operation | Aggregates Involved | Consistency Approach |
|-----------|-------------------|---------------------|
| **Programme participates in admission cycle** | Programme + Admission Cycle | Each aggregate is independently consistent. The Programme records which cycles it participates in. The Cycle records which programmes are involved. Eventual consistency is acceptable — a programme appearing in a cycle's list while the cycle doesn't list the programme is a data inconsistency, not a business invariant violation. |
| **Scholarship targets programmes** | Scholarship + Programme | The Scholarship maintains its targeting rules. The Programme does not need to know about every scholarship that targets it (it can be queried). Eventual consistency is acceptable. |
| **Recording provenance** | Any entity + Information Source | The entity records which source its information came from. The Source doesn't need to know which entities reference it. This is a reference, not a consistency boundary. |

---

## DD2-8 (New): Laravel Beyond CRUD Alignment Review

### Evaluation Against Pragmatic DDD Principles

| Principle | Assessment | Evidence |
|-----------|-----------|---------|
| **Protect business invariants** | ✅ Aligned | Every aggregate root protects specific, named invariants (INV-I1 through INV-IS3). Child entities do not have independent invariants — their consistency is protected by their parent aggregate. Supporting entities have no invariants to protect. |
| **Avoid anemic models** | ✅ Aligned | Every aggregate root has meaningful business operations (not CRUD). `publishAdmissionPolicy` is not "create policy" — it is the business act of publishing requirements with invariant enforcement. `openApplications` enforces preconditions (published policy, correct state). `isAdmitting` is a derived query, not a stored flag. |
| **Avoid unnecessary aggregate roots** | ✅ Aligned (revised) | Original Topic 2 had 11 aggregate roots. Revision reduces to 5. Admission Policy, Eligibility Policy, and Accreditation Record became child entities because they have no independent invariants. Qualification, Scholarship Provider, and Government Education Agency became supporting entities because they are reference data with no business behavior. |
| **Use explicit business language** | ✅ Aligned | Operations use domain language: `publishAdmissionPolicy`, `openApplications`, `recordAccreditation`, `isAdmitting`. No technical language (no `create`, `update`, `save`, `setStatus`). |
| **Avoid artificial abstractions** | ✅ Aligned | No "Educational Opportunity", "Policy", or "Educational Offering" abstraction. Value objects are introduced only where the domain naturally requires them (Admission Rule, Subject Combination, Cut-off Mark — all are terms used in Nigerian education). |
| **Remain practical for the business domain** | ✅ Aligned | The model reflects how the Nigerian education system actually works: programmes publish admission requirements per cycle, JAMB manages admission cycle phases, NUC/NBTE/NCCE grant accreditation by institution type. The model is not theoretical — it mirrors observable domain behavior. |

### Anti-Patterns Avoided

| Anti-Pattern | How Avoided |
|-------------|------------|
| **CRUD disguised as DDD** | All aggregate operations are business operations with invariant enforcement, not create/read/update/delete wrappers. |
| **Aggregate root per entity** | Original model had this problem (11 aggregate roots). Revision reduces to 5, with clear justification for each reduction. |
| **Anemic child entities** | Child entities (Admission Policy, Eligibility Policy, Accreditation Record) have lifecycle states but their transitions are driven by parent operations. They are not anemic — they contain rules (value objects) and have identity — but their consistency is not independently protected. |
| **Giant aggregates** | Programme remains a separate aggregate from Institution to avoid an unbounded aggregate. Historical policies are accessible without loading the entire aggregate. |
| **Reference data as aggregate roots** | Qualification, Scholarship Provider, and Government Education Agency are supporting entities, not aggregate roots. They have identity for referencing but no business behavior. |

### Pragmatic Considerations

| Concern | Approach |
|---------|---------|
| **Loading historical child entities** | A Programme with 20 years of admission policies should not load all policies for every operation. The aggregate boundary defines consistency, not loading scope. Business operations that need historical policies (trend comparison) can load them without violating consistency — they are read-only historical data. |
| **Dual-parented Admission Policy** | An Admission Policy can belong to either a Programme or an Institution. This is a modelling reality, not an implementation problem. The invariant is clear: exactly one parent. Whether this is modelled as two collections (programme policies + institutional policies) or one with a parent type discriminator is a Product Discovery decision. |
| **Scholarship Provider as future aggregate root** | In Stage 3, if providers become active participants, they may be promoted to aggregate root with business operations (publish scholarships, manage eligibility). This is a legitimate model evolution — the current classification is correct for MVP. |
| **Government Education Agency and accreditation** | In the current model, the Agency is a supporting entity referenced within Accreditation Records. If future discovery reveals that Agencies have business operations in StudyNexus's domain (e.g., publishing accreditation guidelines, managing accreditation schedules), they may be promoted to aggregate root. |

---

## Revised Aggregate Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                     AGGREGATE ROOTS (5)                              │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │ Educational Institution                                 │         │
│  │   ├── [child] Admission Policies (institutional-level)  │         │
│  │   ├── [child] Accreditation Records (institutional)     │         │
│  │   └── [ref]  Programmes (separate aggregates)          │         │
│  └─────────────────────────────────────────────────────────┘         │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │ Programme                                               │         │
│  │   ├── [child] Admission Policies (programme-level)      │         │
│  │   ├── [child] Accreditation Records (programme-level)   │         │
│  │   ├── [ref]  Institution (parent aggregate)             │         │
│  │   └── [ref]  Admission Cycles                          │         │
│  └─────────────────────────────────────────────────────────┘         │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │ Scholarship                                             │         │
│  │   ├── [child] Eligibility Policies                      │         │
│  │   ├── [ref]  Scholarship Provider (supporting entity)   │         │
│  │   ├── [ref]  Programmes (targets)                       │         │
│  │   └── [ref]  Institutions (targets)                     │         │
│  └─────────────────────────────────────────────────────────┘         │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │ Admission Cycle                                         │         │
│  │   ├── [ref]  Institutions (participants)                │         │
│  │   └── [ref]  Programmes (participants)                  │         │
│  └─────────────────────────────────────────────────────────┘         │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │ Information Source                                      │         │
│  │   └── (no children — referenced by all entities for     │         │
│  │        provenance)                                      │         │
│  └─────────────────────────────────────────────────────────┘         │
│                                                                       │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│                   SUPPORTING ENTITIES (3)                            │
│                                                                       │
│  Qualification          — referenced by Admission/Eligibility Rules   │
│  Scholarship Provider   — referenced by Scholarships                  │
│  Government Education Agency — referenced by Accreditation Records    │
│                              and Qualifications                       │
│                                                                       │
│  Supporting entities have identity (for referencing) but no           │
│  aggregate root, no business operations, and no invariants to        │
│  protect in StudyNexus's MVP domain.                                 │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Summary of Changes from Original Topic 2

### Aggregate Root Changes

| Entity | Original | Revised | Reason for Change |
|--------|---------|---------|-------------------|
| Educational Institution | Aggregate Root | **Aggregate Root** (unchanged) | — |
| Programme | Aggregate Root | **Aggregate Root** (unchanged) | — |
| Scholarship | Aggregate Root | **Aggregate Root** (unchanged) | — |
| Admission Cycle | Aggregate Root | **Aggregate Root** (unchanged) | — |
| Information Source | Aggregate Root | **Aggregate Root** (unchanged) | — |
| **Admission Policy** | Aggregate Root | **Child Entity** | No independent invariants. Lifecycle driven by parent. One-active-per-cycle is a Programme/Institution invariant. |
| **Eligibility Policy** | Aggregate Root | **Child Entity** | No independent invariants. Lifecycle driven by parent. One-active-per-period is a Scholarship invariant. |
| **Accreditation Record** | Aggregate Root | **Child Entity** | No independent invariants. It is a recorded fact. Agency-type invariant (INV-3) belongs to Programme/Institution. |
| **Qualification** | Aggregate Root | **Supporting Entity** | Reference data. No invariants to protect. No business operations. Defined by external bodies. |
| **Scholarship Provider** | Aggregate Root | **Supporting Entity** | Reference data in MVP. No invariants to protect. No business operations. May become aggregate root in Stage 3. |
| **Government Education Agency** | Aggregate Root | **Supporting Entity** | Reference data. No invariants to protect. No business operations. Defined by legislation. |

### Ownership Model Changes

| Relationship | Original | Revised | Reason |
|-------------|---------|---------|--------|
| Programme → Admission Policy | Composition (separate aggregates with mandatory reference) | **Composition (child entity within Programme aggregate)** | Ownership now implies aggregate membership for entities without independent consistency boundaries |
| Scholarship → Eligibility Policy | Composition (separate aggregates with mandatory reference) | **Composition (child entity within Scholarship aggregate)** | Same rationale |
| Institution/Programme → Accreditation Record | Association (separate aggregates) | **Composition (child entity within Institution/Programme aggregate)** | Accreditation records exist within the entity's context; the entity derives its status from them |

### Conceptual Shift

| Dimension | Original Topic 2 | Revision |
|-----------|-----------------|---------|
| **Aggregate count** | 11 aggregate roots | 5 aggregate roots + 3 child entity types + 3 supporting entities |
| **Driving principle** | Evans DDD: identity + independent access → aggregate root | Pragmatic DDD: invariant protection + business behavior → aggregate root |
| **Composition treatment** | Mandatory references between independent aggregates | Child entities within parent aggregate (except Programme, which remains a separate aggregate for size and invariant reasons) |
| **Reference data** | All entities are aggregate roots | Supporting entities with identity but no business behavior |
| **Discoverability** | Treated as domain concern → justifies aggregate roots | Treated as product concern → served by read models, not aggregate boundaries |
| **Value objects** | Not explored | 5 policy-level VOs + 10 enum VOs + 2 composite VOs introduced |

---

## Final Recommendation

The revised model is a significant improvement over the original Topic 2 aggregate boundary decisions. The reduction from 11 to 5 aggregate roots aligns with Laravel Beyond CRUD's philosophy: aggregate roots exist to protect business invariants and define consistency boundaries, not merely because entities have identity or are independently searchable.

**The five aggregate roots** — Educational Institution, Programme, Scholarship, Admission Cycle, Information Source — each have:
- Named invariants they protect
- Meaningful business operations (not CRUD)
- Independent consistency boundaries
- Recognition by domain experts as standalone business concepts

**The three child entity types** — Admission Policy, Eligibility Policy, Accreditation Record — each have:
- Identity within their parent aggregate
- Lifecycle states (transitions driven by parent)
- Internal structure (rules, status values)
- But no independent invariants or business operations

**The three supporting entities** — Qualification, Scholarship Provider, Government Education Agency — each have:
- Identity for referencing
- Stable, externally-defined properties
- But no invariants to protect and no business behavior in StudyNexus's MVP domain

**The value objects** — Admission Rule, Eligibility Rule, Subject Combination, Qualification Threshold, Cut-off Mark, and various enums — enrich the domain model with concepts that are defined by their attributes, not by identity. These are the vocabulary of admission and eligibility policies.

**The most impactful change**: Admission Policy, Eligibility Policy, and Accreditation Record moving from aggregate roots to child entities. This is the correct modelling decision because their consistency belongs to their parent aggregate. The Programme ensures one active admission policy per cycle. The Scholarship ensures applications cannot open without a published eligibility policy. The Programme/Institution ensures accreditation is from the correct agency for its type. These are parent invariants, not child invariants.

**No changes are required to the accepted sections** of original Topic 2 (lifecycles, temporal behaviour, identity rules, cardinality, domain interactions). The revised aggregate boundaries are compatible with all accepted analysis — they simply provide a more precise and pragmatic classification of entities within those relationships.

---

**Approval Required**: This revision requires explicit approval of:
- Revised aggregate root classifications (5 aggregate roots)
- Child entity classifications (Admission Policy, Eligibility Policy, Accreditation Record)
- Supporting entity classifications (Qualification, Scholarship Provider, Government Education Agency)
- Value object candidates
- Revised ownership model (composition implies aggregate membership)
- Aggregate responsibilities, invariants, and consistency boundaries
- Laravel Beyond CRUD alignment assessment
