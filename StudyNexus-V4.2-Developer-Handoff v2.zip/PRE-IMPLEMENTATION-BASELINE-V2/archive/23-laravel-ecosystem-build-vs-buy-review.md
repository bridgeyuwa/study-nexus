# StudyNexus Laravel Ecosystem & Build-vs-Buy Review

> **⚠️ Reconciliation Note (2026-08-08):** C5 Resolution: RBAC references in this document use `super-admin` as a role name and `role_id` FK in OrganizationMember code samples. The canonical names are: `platform-admin` (not `super-admin`), and `organization_members.role` is a **string** column (not a FK to Spatie roles). These corrections are per Document 26 (file 26, Change R2 + Rec 8). Original references preserved for provenance; apply corrections during implementation.


**Document ID:** 22
**Date:** 2026-08-08
**Status:** Architecture Review
**Prerequisite:** Frozen Baseline (20), Post-Freeze Review (21)
**Author:** StudyNexus Architecture Team
**Classification:** Critical — Infrastructure & Dependency Decision Record

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architectural Principle](#2-architectural-principle)
3. [Laravel Beyond CRUD Compatibility](#3-laravel-beyond-crud-compatibility)
4. [Spatie Ecosystem Review](#4-spatie-ecosystem-review)
5. [Non-Spatie Laravel Ecosystem Review](#5-non-spatie-laravel-ecosystem-review)
6. [RBAC Review](#6-rbac-review)
7. [Multi-Admin Institution Model](#7-multi-admin-institution-model)
8. [User Engagement Architecture](#8-user-engagement-architecture)
9. [Comparison Architecture](#9-comparison-architecture)
10. [Community Architecture](#10-community-architecture)
11. [Notification Architecture](#11-notification-architecture)
12. [Social Sharing Architecture](#12-social-sharing-architecture)
13. [Typesense Architecture](#13-typesense-architecture)
14. [SEO Architecture](#14-seo-architecture)
15. [TALL Architecture](#15-tall-architecture)
16. [Filament Architecture](#16-filament-architecture)
17. [Study Abroad/Global Extensibility Review](#17-study-abroadglobal-extensibility-review)
18. [Build-vs-Buy Matrix](#18-build-vs-buy-matrix)
19. [Package Quality Matrix](#19-package-quality-matrix)
20. [Adopt-Now Package List](#20-adopt-now-package-list)
21. [Evaluate-Later Package List](#21-evaluate-later-package-list)
22. [Rejected Package List](#22-rejected-package-list)
23. [Custom Implementation Justification List](#23-custom-implementation-justification-list)
24. [Dependency Risk Analysis](#24-dependency-risk-analysis)
25. [Security Considerations](#25-security-considerations)
26. [Performance Considerations](#26-performance-considerations)
27. [Upgrade/Maintenance Considerations](#27-upgrademaintenance-considerations)
28. [Architecture Impact Analysis](#28-architecture-impact-analysis)
29. [New ADRs Required](#29-new-adrs-required)
30. [Frozen-Domain Impact Test](#30-frozen-domain-impact-test)
31. [Implementation Sequencing](#31-implementation-sequencing)
32. [Final Architectural Verdict](#32-final-architectural-verdict)

---

## 1. Executive Summary

This document presents the comprehensive Laravel ecosystem evaluation and build-vs-buy analysis for StudyNexus, a global education opportunity discovery platform. It serves as the definitive dependency selection record, superseding and deepening the Spatie-specific evaluation from Document 21 (Post-Freeze Platform Architecture Review).

The core tension in this review is **dependency discipline vs. operational pragmatism**. Every package added to `composer.json` is a maintenance contract, an upgrade constraint, and a potential coupling point with the frozen domain model. Conversely, every line of custom code we write instead of adopting a well-maintained package is a testing burden, a security surface, and a long-term maintenance cost that falls entirely on our team.

**Key outcomes of this review:**

- **17 packages classified ADOPT NOW** — required for production launch or immediate operational needs (backup, webhooks, data export, bulk import, social auth, push notifications)
- **9 packages classified ADOPT WHEN NEEDED** — justified for specific feature horizons but not blocking launch (tags, response cache, translation loader, markdown, etc.)
- **8 packages classified EVALUATE LATER** — potentially useful but no current use case or insufficient information (honeypot, rate-limits, CSP, cookie consent, OpenTelemetry, onboard, Passport, Livewire tables)
- **11 packages classified REJECT** — actively harmful, superseded, or fundamentally incompatible with our architecture (event-sourcing, model-states, newsletter, fractal, valuestore, view-models, feeds, geocoder, menu, Ray, WireUI)
- **4 packages classified CUSTOM IMPLEMENTATION JUSTIFIED** — where no package matches our specific requirement and the custom code is bounded and testable (OrganizationMember pivot, Community system, Search projection sync, SEO faceted URL strategy)
- **6 adversarial challenges resolved** — deep evaluation of previously superficial decisions, with explicit rationale for each resolution
- **4 new ADRs identified** — decisions that require formal Architecture Decision Records before implementation begins

The most significant revision from Document 21 is the **elevation of `spatie/laravel-backup` from ADOPT LATER to ADOPT NOW**. Production deployment without automated database and file backups is negligent, not pragmatic. Similarly, `spatie/laravel-webhook-client` is elevated from unmentioned to ADOPT NOW because Information Source integrations — the mechanism by which StudyNexus ingests educational data from external authorities — are architecturally foundational, not future nice-to-haves.

The most significant rejection is `spatie/laravel-model-states`. Despite the valid argument that explicit transition rules would prevent invalid state transitions (e.g., Institution `Suspended` → `Closed`), the Laravel Beyond CRUD pattern already enforces transitions through domain methods with guard clauses. Adding a package to make explicit what is already enforced in code would be dependency inflation. The guard clause approach is more idiomatic for LBC, keeps transition logic in the domain layer where it belongs, and avoids coupling state machine logic to an external package's API surface.

---

## 2. Architectural Principle

Every package adoption decision in this review is governed by the following principles, listed in strict priority order:

| Priority | Principle | Rationale |
|----------|-----------|-----------|
| 1 | **Frozen Domain Sovereignty** | No package may require changes to the frozen domain model (5 aggregates, 20 actions, 28 value objects, 29 events) without evidence from production usage. |
| 2 | **LBC Layer Integrity** | Packages must respect Domain → Application → Infrastructure → Presentation layering. A package that tempts us to put logic in the wrong layer is rejected. |
| 3 | **Dependency Minimization** | Each package is a maintenance contract. We prefer writing 50 lines of well-tested custom code over adding a package that saves those 50 lines but constrains upgrades for years. |
| 4 | **Upgrade Path Preservation** | Packages must have a credible Laravel upgrade path. A package abandoned between Laravel 10 and 11 is a migration blocker. |
| 5 | **Operational Necessity** | Packages that solve real, immediate operational problems (backups, imports, compliance) are prioritized over packages that solve hypothetical problems. |
| 6 | **Spatie Preference, Not Bias** | Spatie packages are evaluated first because of their exceptional maintenance record and Laravel-first philosophy, but they are not automatically adopted. Quality and fit determine adoption, not brand. |
| 7 | **TALL Stack Coherence** | Packages must work with Livewire, Alpine.js, and Flux. Packages that assume SPA patterns or conflict with server-rendered component lifecycles are rejected. |
| 8 | **PostgreSQL as Truth** | No package may introduce an alternative source of truth. Typesense is a projection; Redis is a cache/queue; PostgreSQL is the only source of truth. |

**The 12-Point Package Evaluation Criteria:**

Every package is scored against these criteria before classification:

1. **Active Maintenance** — Commits in last 6 months? Issue resolution cadence?
2. **Laravel Version Compatibility** — Supports current + next Laravel version?
3. **Test Coverage** — >80% coverage? CI pipeline visible?
4. **Documentation Quality** — Comprehensive docs? Migration guides?
5. **Community Adoption** — >500 GitHub stars? Used in production by known projects?
6. **Dependency Footprint** — How many transitive dependencies does it add?
7. **Layer Compatibility** — Which LBC layers does it touch? Does it respect boundaries?
8. **Domain Model Impact** — Does it require domain model changes? Does it couple to aggregates?
9. **Custom Code Equivalent** — How many lines would we write to replace it? Is that code complex enough to justify a dependency?
10. **Upgrade Risk** — Has it broken across Laravel minor versions? How many breaking changes in last 3 majors?
11. **Security Surface** — Does it process user input? Handle auth? Expose endpoints?
12. **Operational Urgency** — Do we need this for launch? For Nigeria rollout? For Africa expansion?

---

## 3. Laravel Beyond CRUD Compatibility

Laravel Beyond CRUD (LBC) is the architectural pattern StudyNexus follows. It is **pragmatic DDD** — not classical Evans DDD with bounded contexts and context mapping, but a domain-driven organization of code that respects the reality of Laravel's framework conventions. The key constraint is layering:

```
Domain/
  ├── Models/          (Eloquent models as aggregate roots + value objects)
  ├── Events/          (Domain events)
  └── Exceptions/      (Domain exceptions)

Application/
  ├── Actions/         (Use case entry points — one class per operation)
  ├── Queries/         (Read-side optimization — one class per query)
  ├── DTOs/            (Data transfer objects via spatie/laravel-data)
  └── Listeners/       (Event listeners for side effects)

Infrastructure/
  ├── Persistence/     (Eloquent scopes, custom query builders)
  ├── Search/          (Typesense/Scout configuration)
  └── Integrations/    (Third-party API clients)

Presentation/
  ├── Livewire/        (Livewire components)
  ├── Blade/           (Blade components & views)
  └── Filament/        (Admin panel resources)
```

**Package Compatibility Rules Derived from LBC:**

| Rule | Constraint | Example Violation |
|------|-----------|-------------------|
| R1 | Packages must not place business logic in Eloquent model scopes that belong in Application Actions | A search package that defines `Model::searchable()` with ranking logic |
| R2 | Packages must not emit domain events from infrastructure layer | A webhook package that fires `WebhookReceived` as a domain event |
| R3 | Packages must not require repository pattern | Any package that expects `UserRepositoryInterface` instead of Eloquent |
| R4 | Packages must not conflict with Livewire's component lifecycle | A package that depends on client-side routing or SPA navigation |
| R5 | Packages must not introduce CQRS or event sourcing patterns | Event-sourcing packages force architecture changes |
| R6 | Value objects must remain PHP classes/enums, not package-provided abstractions | A VO package that replaces PHP enums with its own type system |

**Adversarial Challenge:** Some Spatie packages blur the Domain/Application boundary. For example, `spatie/laravel-model-status` adds a `HasStatuses` trait to Eloquent models, which puts status tracking logic directly on the aggregate root. In LBC, status transitions are Application Actions that delegate to domain methods. We rejected `model-status` in Document 21 for this reason, and reaffirm that rejection here. The same logic applies to `model-states` — its `HasStates` trait on the model is an LBC layer violation, regardless of how useful explicit transitions would be.

---

## 4. Spatie Ecosystem Review

Spatie is the most prolific Laravel package maintainer, with 60+ packages. We evaluate all Spatie packages with potential relevance to StudyNexus, classified by their relationship to our architecture.

### 4.1 Core Infrastructure Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-permission | v6 | 12k+ | **ADOPT NOW** | Decided in doc 21. RBAC foundation. |
| laravel-backup | v9 | 5k+ | **ADOPT NOW** | Elevated from ADOPT LATER. Production without backups is negligent. |
| laravel-activitylog | v4 | 5k+ | **ADOPT NOW** | Decided in doc 21. Audit trail is regulatory requirement. |
| laravel-medialibrary | v11 | 5k+ | **ADOPT NOW** | Decided in doc 21. Institution logos, programme brochures. |
| laravel-data | v4 | 2k+ | **ADOPT NOW** | Decided in doc 21. DTOs, API resources, form objects. |
| laravel-sluggable | v3 | 2k+ | **ADOPT NOW** | Decided in doc 21. URL generation for all aggregate roots. |
| laravel-query-builder | v3 | 4k+ | **ADOPT NOW** | Decided in doc 21. API filtering, sorting, inclusion. |

### 4.2 Webhook & Integration Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-webhook-client | v3 | 1k+ | **ADOPT NOW** | Information Source integrations require webhook ingestion. Foundational. |
| laravel-webhook-server | v3 | 800+ | **ADOPT WHEN NEEDED** | Outbound webhooks needed when we push updates to partner platforms. |

### 4.3 Compliance & Data Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-personal-data-export | v1 | 600+ | **ADOPT NOW** | GDPR Article 20 + Nigerian NDPR. Legal requirement for global platform. |
| laravel-cookie-consent | v3 | 1k+ | **EVALUATE LATER** | Needed for EU users but not for Nigeria MVP. |

### 4.4 Content & Taxonomy Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-tags | v4 | 2k+ | **ADOPT WHEN NEEDED** | Community content needs user-generated tags. Programme tags could complement enum disciplines. Not needed at launch. |
| laravel-markdown | v2 | 500+ | **ADOPT WHEN NEEDED** | Community posts need Markdown rendering. Not needed until community feature. |

### 4.5 Performance & Caching Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-responsecache | v7 | 2k+ | **ADOPT WHEN NEEDED** | Public listing pages are read-heavy. Compatible with Livewire (POST requests bypass). Needs careful invalidation strategy for facet counts. |
| laravel-tags | — | — | (see above) | — |

### 4.6 Internationalization Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-translation-loader | v4 | 1k+ | **ADOPT WHEN NEEDED** | Database-backed translations for admin-side management without deployments. Critical for Africa expansion (French, Portuguese, Arabic). Not needed for Nigeria English MVP. |

### 4.7 SEO & Meta Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-sitemap | v6 | 1k+ | **ADOPT WHEN NEEDED** | Decided in doc 21. Sitemap generation for search engines. |
| schema-org | v3 | 300+ | **ADOPT WHEN NEEDED** | Decided in doc 21. Structured data for rich snippets. |

### 4.8 Monitoring & Debugging Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-schedule-monitor | v3 | 600+ | **EVALUATE LATER** | Doc 21 decision. Useful when cron monitoring needed beyond Laravel's built-in. |
| laravel-health | v1 | 500+ | **EVALUATE LATER** | Availability checks. Complementary to Laravel Pulse (performance). Not competing. |
| laravel-ray | v1 | 500+ | **EVALUATE LATER** | Development-only debugging. Never a production dependency. |

### 4.9 Utility Packages

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-settings | v3 | 1k+ | **ADOPT WHEN NEEDED** | Decided in doc 21. Application-level settings. |
| browsershot | v4 | 2k+ | **ADOPT WHEN NEEDED** | PDF generation for programme comparison exports, scholarship detail PDFs. |
| eloquent-sortable | v1 | 300+ | **ADOPT WHEN NEEDED** | Display ordering for programme listings, FAQ ordering. Simple but useful. |
| laravel-honeypot | v2 | 500+ | **EVALUATE LATER** | Anti-spam for public forms. Livewire has some built-in protection. |
| laravel-rate-limits | v2 | 300+ | **EVALUATE LATER** | Laravel has built-in rate limiting. Only needed if we exceed its capabilities. |
| laravel-csp | v2 | 500+ | **EVALUATE LATER** | Security hardening. Important for production but not launch-blocking. |
| laravel-welcome-notification | v1 | 200+ | **ADOPT WHEN NEEDED** | Onboarding email. Small but useful. Could be 10 lines of custom code though. |

### 4.10 Rejected Spatie Packages

| Package | Classification | Rejection Rationale |
|---------|----------------|---------------------|
| laravel-event-sourcing | **REJECT** | Over-engineering. Contradicts frozen baseline. Forces CQRS architecture. |
| laravel-comments | **REJECT** | Commercial/paid license. Also, our community architecture is custom (SO+Reddit hybrid, not simple comments). |
| laravel-view-models | **REJECT** | Superseded by laravel-data which provides validated DTOs, rendering, and API resource conversion. |
| laravel-feeds | **REJECT** | RSS/Atom feeds have near-zero relevance for an education discovery platform targeting African students. |
| laravel-geocoder | **REJECT** | Premature. Location search is handled by Typesense geo filter. Geocoding can be added later if needed. |
| laravel-menu | **REJECT** | Superseded by Blade components and Livewire navigation. Menu builders are a server-side pattern that doesn't fit TALL. |
| laravel-model-states | **REJECT** | PHP enums + guard clauses in domain methods are simpler, more idiomatic for LBC, and avoid trait-on-model pattern. |
| laravel-newsletter | **REJECT** | Mailchimp-only. Use Laravel Notifications + queue for multi-provider newsletter capability. |
| laravel-fractal | **REJECT** | Superseded by laravel-data. |
| valuestore | **REJECT** | Superseded by laravel-settings. |
| laravel-ray | **REJECT** (as dependency) | Development-only tool. Useful locally, never in composer.json production dependencies. |

---

## 5. Non-Spatie Laravel Ecosystem Review

Beyond Spatie, several non-Spatie packages are critical for StudyNexus. Each is evaluated with the same 12-point criteria.

### 5.1 Bulk Data Import

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| maatwebsite/excel | v3 | 12k+ | **ADOPT NOW** | Core operational need. Bulk import of institutions, programmes, qualifications, scholarships from CSV/Excel files. Supports validation, chunked processing, and queued imports. `spatie/simple-excel` is insufficient for complex imports with multi-sheet validation. |

**Adversarial deep-dive on maatwebsite/excel vs spatie/simple-excel:**

`spatie/simple-excel` is a lightweight wrapper around box/spout. It reads and writes Excel/CSV files efficiently but provides no validation framework, no chunked import with rollback, and no queued import support. For StudyNexus, importing 5,000 programmes from an accreditation body's Excel file requires:

- Per-row validation against domain rules (e.g., "programme name must not be empty," "qualification level must be a valid enum value")
- Multi-sheet support (institutions on Sheet 1, programmes on Sheet 2, link by institution code)
- Import job queuing (large imports should not block HTTP requests)
- Progress tracking (admin user needs to see import progress in Filament)
- Error reporting (row 437 has invalid qualification level — show this to the admin)

Maatwebsite/excel provides all of these via the `WithValidation`, `WithChunkReading`, `WithMultipleSheets`, and `ShouldQueue` interfaces. Simple-excel provides none. The custom code equivalent to replicate this in simple-excel would be ~1,500 lines of import infrastructure. This is not dependency inflation — this is justified adoption.

### 5.2 Push Notifications

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel-notification-channels/webpush | v1 | 1k+ | **ADOPT NOW** | Browser push notifications for admission deadline alerts, scholarship expiry warnings, and status change notifications. Critical engagement channel for students who may not check email regularly. |

**Implementation consideration:** Web Push requires a VAPID key pair and a service worker. The Laravel package handles the server-side (payload encryption, subscription management). The client-side service worker registration is a small Alpine.js component. This is a notification channel, not a notification framework — it integrates with Laravel's native notification system, respecting our architecture decision from Document 21.

### 5.3 Social Authentication

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel/socialite | v5 | 5k+ | **ADOPT NOW** | Social login via Google and Microsoft is expected by students and institution admins respectively. Reduces registration friction significantly. |

**Adversarial challenge:** Do we really need Socialite at launch? Yes. Student registration friction is a known conversion killer. Google OAuth is table stakes for consumer-facing platforms in 2026. Microsoft OAuth is critical for institution admins who use institutional Microsoft accounts. The integration is minimal (Socialite extends Laravel's auth), and the dependency footprint is low (guzzlehttp/oauth2-client).

### 5.4 Admin Panel Integration

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| filament/filament | v5 | 18k+ | **ADOPT NOW** (already decided) | Admin panel framework. |
| bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhan-salam (typo) --> | v3 | 1k+ | **ADOPT NOW** | Directly integrates Spatie Permission with Filament. Generates permission-seeded resources, policy scaffolding, and role-based widget visibility. Saves ~500 lines of repetitive authorization boilerplate in Filament resources. |

### 5.5 Health Monitoring

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel/pulse | v1 | 2k+ | **ADOPT NOW** | First-party Laravel package. Performance monitoring: slow queries, slow endpoints, job failures, exception tracking. Lightweight, Livewire dashboard, zero config for basic usage. |
| spatie/laravel-health | v1 | 500+ | **EVALUATE LATER** | Availability checks (database reachable, Redis connected, Typesense index healthy, storage writable). Complementary to Pulse, not competing. Evaluate when we need uptime monitoring beyond basic Laravel health check endpoint. |

**Key insight:** Pulse and Health are complementary. Pulse answers "how fast?" and "what broke?" Health answers "is it alive?" and "are dependencies reachable?" We adopt Pulse now because it's first-party and zero-config. Health later because our infrastructure (Kubernetes/Docker health checks) may provide sufficient liveness probes.

### 5.6 Queue Monitoring

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel/horizon | v5 | 4k+ | **ADOPT WHEN NEEDED** | Queue monitoring dashboard. Requires Redis. Adopt when we switch from database queues to Redis queues for production. |

### 5.7 Authentication Advanced

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| laravel/passport | v12 | 3k+ | **EVALUATE LATER** | OAuth2 server. Only needed if we provide third-party API access. Not needed for first-party web + mobile app. |
| laravel/sanctum | v4 | 2k+ | **ADOPT NOW** (Laravel built-in) | API token authentication for mobile app. Already included with Laravel. |
| laravel/passkeys | — | — | **EVALUATE LATER** | WebAuthn/Passkeys. Modern auth trend but low priority. Evaluate when browser support is universal and users expect it. |

### 5.8 Search & Indexing

| Package | Version | Stars | Classification | Rationale |
|---------|---------|-------|----------------|-----------|
| typesense/typesense-php | v4 | 200+ | **ADOPT NOW** (already decided) | Typesense PHP client. |
| laravel/scout | v10 | 1k+ | **ADOPT NOW** (Laravel built-in) | Search abstraction. Already included with Laravel. |

### 5.9 Rejected Non-Spatie Packages

| Package | Classification | Rejection Rationale |
|---------|----------------|---------------------|
| wireui/wireui | **REJECT** | Unnecessary when using Flux. Flux is the official Livewire component library. WireUI duplicates functionality with different API. |
| rappasoft/laravel-livewire-tables | **EVALUATE LATER→LIKELY REJECT** | Filament has its own table system. Public-facing tables use Livewire + Query classes. This package targets admin tables, which Filament already handles. |

---

## 6. RBAC Review

**Previous Decision (Doc 21):** Spatie Permission + custom OrganizationMember pivot (BookStack-inspired).

**Adversarial Challenge 1:** Is the OrganizationMember pivot actually necessary, or can we model multi-tenancy entirely within Spatie Permission?

**Resolution:** The OrganizationMember pivot is necessary because Spatie Permission models **global** roles and permissions. A user who is `institution-admin` at University of Lagos should not automatically be `institution-admin` at University of Ibadan. Spatie Permission does not natively support scoped/tenant-bound roles. The OrganizationMember pivot provides:

- Organization-scoped role assignment (user X has role Y **within** organization Z)
- Organization membership management (join, leave, invite)
- Organization-level permission inheritance (institution-admin can manage programmes **for their institution only**)

```php
// OrganizationMember pivot — the glue between User, Organization, and Role
class OrganizationMember extends Pivot
{
    protected $table = 'organization_members';

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function organization(): BelongsTo { return $this->belongsTo(Organization::class); }
    public function role(): BelongsTo { return $this->belongsTo(Role::class); }

    // Scope: Does this user have this permission within this organization?
    public function hasPermissionInOrganization(
        User $user,
        string $permission,
        Organization $organization
    ): bool {
        return $this->newQuery()
            ->where('user_id', $user->id)
            ->where('organization_id', $organization->id)
            ->whereHas('role.permissions', fn($q) => $q->where('name', $permission))
            ->exists();
    }
}
```

**Adversarial Challenge 2:** Does Filament Shield eliminate the need for the OrganizationMember pivot?

**Resolution:** No. Filament Shield handles Filament admin panel authorization only. It generates policies and permissions for Filament resources. It does not handle the multi-tenancy problem (scoped authorization). Shield and OrganizationMember solve different problems. Shield = "who can access this Filament resource?" OrganizationMember = "which organizations does this user belong to, and with what role?"

**RBAC Architecture Summary:**

| Layer | Mechanism | Package |
|-------|-----------|---------|
| Global roles (super-admin, platform-moderator) | Spatie Permission | laravel-permission |
| Organization-scoped roles (institution-admin, institution-editor) | OrganizationMember pivot | Custom |
| Filament resource authorization | Filament Shield | filament-shield |
| API token authorization | Sanctum | laravel/sanctum |
| Policy authorization | Laravel Policies | Built-in |

---

## 7. Multi-Admin Institution Model

An educational institution on StudyNexus may have multiple administrators with different permission levels. This is not a simple "one owner" model — it's a collaborative model where:

- **Institution Owner** — full control, can invite/remove other admins, manage all programmes
- **Institution Admin** — can manage programmes, scholarships, admission cycles, but cannot remove the owner or change institution settings
- **Institution Editor** — can edit programme details and scholarship information, but cannot publish/unpublish
- **Institution Viewer** — read-only access to institution dashboard and analytics

**Implementation via OrganizationMember:**

```php
// Assigning a user as editor within an institution
OrganizationMember::create([
    'user_id' => $user->id,
    'organization_id' => $institution->organization->id,
    'role_id' => Role::where('name', 'institution-editor')->first()->id,
]);

// Checking permission in an Application Action
class UpdateProgrammeAction
{
    public function execute(User $user, Institution $institution, Programme $programme, ProgrammeData $data): Programme
    {
        // Guard: User must have 'programme.update' permission within this institution
        if (!$user->hasPermissionInOrganization('programme.update', $institution->organization)) {
            throw new AuthorizationException('You do not have permission to update programmes for this institution.');
        }

        // Guard: Programme must belong to this institution
        if ($programme->institution_id !== $institution->id) {
            throw new AuthorizationException('This programme does not belong to the specified institution.');
        }

        // Domain delegation
        return $programme->updateFromData($data);
    }
}
```

**This is NOT modeled as a domain entity.** OrganizationMember is an Application-layer concept. The domain model knows nothing about "who can update a programme" — that's an authorization concern, not a domain concern. This preserves frozen domain sovereignty.

---

## 8. User Engagement Architecture

**Previous Decision (Doc 21):** Save/Follow/Like as application-layer Eloquent relationships (no UserInteraction entity).

**Adversarial Challenge:** Should user engagement data live in PostgreSQL or be projected to Typesense for "users who followed X also followed Y" recommendations?

**Resolution:** The raw engagement data (saves, follows, likes) must live in PostgreSQL as the source of truth. Typesense is a search projection, not a recommendation engine. Simple collaborative filtering can be done via SQL (e.g., "users who saved this programme also saved..."), and if we need more sophisticated recommendations later, that's a separate bounded context with its own data pipeline.

**Schema Design (Application layer, not Domain layer):**

```php
// These are Application-layer Eloquent models, NOT domain entities
class UserSave extends Model
{
    protected $table = 'user_saves';
    // user_id, saveable_type, saveable_id, collection_name, created_at
    // Polymorphic: user can save programmes, scholarships, institutions
}

class UserFollow extends Model
{
    protected $table = 'user_follows';
    // user_id, followable_type, followable_id, created_at
    // Polymorphic: user can follow institutions, scholarship providers
}

class UserLike extends Model
{
    protected $table = 'user_likes';
    // user_id, likeable_type, likeable_id, created_at
    // Polymorphic: user can like community posts, reviews
}
```

**Key decision:** These are polymorphic relationships, not a single `UserInteraction` table. The reasoning is:

1. **Query efficiency** — Saves, follows, and likes have different access patterns. Saves are queried by collection. Follows drive notification subscriptions. Likes drive ranking.
2. **Column divergence** — Saves have `collection_name`. Follows have notification preferences. Likes are simpler. A unified table would be sparse and confusing.
3. **Independent indexing** — Each table can be indexed independently in Typesense/Scout if needed.

**No package needed.** Laravel's polymorphic relationships handle this natively. Adding a package like `spatie/laravel-activitylog` for engagement tracking would be wrong — activity log is for audit trail, not for user interaction data.

---

## 9. Comparison Architecture

**Previous Decision (Doc 21):** Product/presentation capability via Livewire + Query classes.

**Deepening:** Programme comparison is a key feature for students deciding between multiple programmes. The architecture is:

1. **Selection** — User adds programmes to a comparison "basket" (stored in session or database depending on auth status)
2. **Query** — `CompareProgrammesQuery` fetches all selected programmes with their attributes
3. **Presentation** — Livewire component renders a side-by-side comparison table with aligned attributes

```php
// Application/Queries/CompareProgrammesQuery.php
class CompareProgrammesQuery
{
    public function fetch(array $programmeIds): Collection
    {
        return Programme::with(['institution', 'disciplines', 'qualification', 'admissionCycles'])
            ->whereIn('id', $programmeIds)
            ->get()
            ->map(fn ($p) => ProgrammeComparisonData::fromModel($p));
    }
}

// Presentation/Livewire/CompareProgrammes.php
class CompareProgrammes extends Component
{
    public array $selectedProgrammeIds = [];

    public function render()
    {
        $programmes = app(CompareProgrammesQuery::class)->fetch($this->selectedProgrammeIds);
        return view('livewire.compare-programmes', compact('programmes'));
    }
}
```

**No package needed.** Comparison is a presentation concern. The data comes from PostgreSQL (source of truth), the query is an Application-layer Query class, and the rendering is a Livewire component. There is no `spatie/laravel-compare` package, and we wouldn't use one if it existed — comparison logic is too domain-specific to generalize.

---

## 10. Community Architecture

**This is the most architecturally sensitive new feature not covered in Document 21.**

StudyNexus needs a community component where students can:
- Ask questions about programmes, institutions, scholarships (Stack Overflow style)
- Share experiences and reviews (Reddit style)
- Answer each other's questions (peer support)
- Upvote/downvote content (quality signal)

**Critical Constraint:** The community must NOT pollute the frozen domain model. The domain model is about educational institutions, programmes, scholarships, admission cycles, and information sources. Community content is a separate concern.

**Architecture Decision:** The community is a **separate module within the same Laravel application**, not a separate bounded context (which would imply separate databases, context mapping, and anti-corruption layers — classical DDD overhead we explicitly avoid in LBC).

```
app/
  ├── Domain/                    # FROZEN — do not touch
  ├── Application/               # Existing application layer
  ├── Community/                  # NEW MODULE
  │   ├── Domain/                # Community domain (Posts, Questions, Answers, Comments, Votes)
  │   ├── Application/           # Community actions, queries, policies
  │   ├── Infrastructure/        # Community persistence, markdown rendering
  │   └── Presentation/          # Community Livewire components, Blade views
  ├── Infrastructure/            # Existing infrastructure layer
  └── Presentation/              # Existing presentation layer
```

**Why a separate module and not just more models in Domain/?**

1. **Frozen domain sovereignty** — The core domain model is frozen. Adding community entities would violate the freeze.
2. **Separate evolution** — Community features will evolve rapidly (gamification, moderation tools, reputation systems) while the core domain is stable. Separate modules allow different change velocities.
3. **Separate authorization** — Community moderators are not institution admins. Community has its own role/permission model.
4. **Separate data model** — Community content (Markdown text, votes, reputation scores) has fundamentally different data patterns from core domain data (structured attributes, enums, value objects).

**Community Domain Entities (NOT part of the frozen baseline):**

| Entity | Description | Key Relationships |
|--------|-------------|-------------------|
| Question | A student's question about an education topic | Belongs to User, has many Answers, polymorphic Tags |
| Answer | A response to a Question | Belongs to User and Question, has Votes |
| Post | A discussion post (Reddit-style) | Belongs to User, belongs to PostChannel, has Comments |
| Comment | A reply to a Post | Belongs to User and Post, supports nesting |
| Vote | Upvote/downvote on Questions, Answers, Posts | Polymorphic, belongs to User |

**Tag Architecture Decision:** Community tags use `spatie/laravel-tags` (adopted when community feature begins). Programme discipline tags remain PHP enums. These are different tag systems serving different purposes — discipline tags are curated and stable, community tags are user-generated and dynamic.

**Custom Implementation Justified:** No existing Laravel package provides a Stack Overflow + Reddit hybrid community. `spatie/laravel-comments` is too simple (flat comments only, no voting, no questions/answers separation) and requires a paid license. We build this ourselves.

---

## 11. Notification Architecture

**Previous Decision (Doc 21):** Laravel native notifications (no custom framework).

**Deepening with Web Push:**

Laravel's notification system supports multiple channels via a single `Notification` class. StudyNexus uses:

| Channel | Package | Use Case |
|---------|---------|----------|
| Database | Built-in | In-app notification bell icon |
| Mail | Built-in | Email notifications for critical events |
| WebPush | laravel-notification-channels/webpush | Browser push for deadline alerts |
| SMS (future) | Custom via Africa's Talking / Twilio | SMS for Nigerian students (high mobile usage) |

```php
// A single notification class can route to multiple channels
class ScholarshipDeadlineApproaching extends Notification
{
    public function via($notifiable): array
    {
        return ['database', 'mail', WebPushChannel::class];
    }

    public function toWebPush($notifiable): WebPushMessage
    {
        return (new WebPushMessage)
            ->title('Scholarship Deadline Reminder')
            ->body("The {$this->scholarship->name} deadline is in 7 days.")
            ->action('View Scholarship', route('scholarships.show', $this->scholarship))
            ->vibrate([100, 50, 100]);
    }
}
```

**Adversarial Challenge on Newsletter:** Document 21 classified `spatie/laravel-newsletter` as "evaluate when needed." But this package is Mailchimp-only via its `drewm/mailchimp-api` dependency. For StudyNexus expanding across Africa:

- **Mailchimp** has poor deliverability to African email providers and limited local compliance
- **SendGrid** (Twilio) has better global infrastructure
- **Postmark** has excellent deliverability but limited automation
- **Custom via Laravel Notifications** — Send a `NewsletterEdition` notification to all subscribed users via queue, using whatever mail provider we configure

**Resolution:** REJECT `spatie/laravel-newsletter`. Implement newsletter as a queued Laravel Notification sent to a subscriber list. This gives us provider independence (swap Mailchimp for SendGrid for Postmark by changing `.env`), queue-based sending (don't block HTTP requests with 10,000 email sends), and native Laravel integration.

```php
// Application/Actions/SendNewsletterAction.php
class SendNewsletterAction
{
    public function execute(NewsletterEdition $edition): void
    {
        $subscribers = User::where('newsletter_subscribed', true)->lazyById();

        foreach ($subscribers as $subscriber) {
            $subscriber->notify(new NewsletterEditionNotification($edition));
        }
    }
}
```

---

## 12. Social Sharing Architecture

**Previous Decision (Doc 21):** Client-side + Blade meta (no server-side tracking).

**Deepening:** Social sharing for education opportunities is primarily about **discovery amplification**, not analytics. A student shares a scholarship on WhatsApp (the dominant platform in Nigeria), and their contacts discover StudyNexus through that share.

**Implementation:**

1. **Open Graph meta tags** — Blade component renders OG tags for programme, scholarship, and institution detail pages
2. **Share buttons** — Alpine.js component with Web Share API (falls back to traditional share links)
3. **UTM parameters** — Share links include `utm_source=whatsapp&utm_medium=share&utm_campaign=scholarship-{id}` for basic attribution in analytics
4. **No server-side share tracking** — We do NOT track "user X shared programme Y on platform Z." This would require logging every share event, adding database writes to a read path, and creating privacy concerns. If we need share attribution later, UTM parameters in analytics are sufficient.

```blade
{{-- Presentation/Blade/Components/OpenGraphMeta.php --}}
@props(['title', 'description', 'image', 'url'])

<meta property="og:title" content="{{ $title }}" />
<meta property="og:description" content="{{ $description }}" />
<meta property="og:image" content="{{ $image }}" />
<meta property="og:url" content="{{ $url }}" />
<meta property="og:type" content="website" />
<meta name="twitter:card" content="summary_large_image" />
```

**No package needed.** Open Graph rendering is ~10 lines of Blade. Share buttons are ~30 lines of Alpine.js. Adding a package for this would be dependency inflation.

---

## 13. Typesense Architecture

**Previous Decision (Doc 21):** Typesense is a search/discovery projection. PostgreSQL is the source of truth.

**Deepening the synchronization architecture:**

The critical architectural constraint is that Typesense must never be treated as authoritative. If Typesense and PostgreSQL disagree, PostgreSQL wins. This means:

1. **Writes always go to PostgreSQL first** — via Application Actions
2. **Domain events trigger Scout synchronization** — via Laravel's event system
3. **Typesense is eventually consistent** — there is a small window between PostgreSQL write and Typesense index update
4. **Reconciliation job runs daily** — compares PostgreSQL counts with Typesense counts and re-indexes discrepancies

```php
// Domain event fires after programme is created/updated
class ProgrammeCreated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public Programme $programme) {}
}

// Scout listener synchronizes to Typesense
// (This is automatic via Laravel Scout's Searchable trait)
class Programme extends Model implements Searchable
{
    public function toSearchableArray(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'discipline' => $this->discipline->value,
            'institution_name' => $this->institution->name,
            'country' => $this->institution->country,
            'tuition_fee' => $this->tuition_fee?->amount,
            'qualification_level' => $this->qualification->level->value,
            // ... projected fields only
        ];
    }

    public function searchableAs(): string
    {
        return 'programmes'; // Typesense collection name
    }
}
```

**Custom Implementation Justified:** The wiring between domain events → Scout → Typesense is custom because:

1. Scout's default synchronization is model-level (`save()` triggers sync). We need aggregate-level synchronization (creating a Programme may also need to re-index the parent Institution).
2. Our search schema includes computed fields (e.g., "is scholarship available") that require application-layer logic, not just model attribute mapping.
3. Reconciliation logic (detecting drift between PostgreSQL and Typesense) is application-specific.

---

## 14. SEO Architecture

**Previous Decision (Doc 21):** Server-rendered + controlled indexation + curated landing pages.

**Deepening with faceted URL strategy:**

StudyNexus has faceted search pages (e.g., `/programmes?discipline=engineering&country=nigeria&level=undergraduate`). These present an SEO challenge:

1. **Facet combinations create near-infinite URLs** — Google could crawl millions of facet permutations
2. **Most facet combinations have thin content** — 2 programmes matching an obscure facet combination is not a good search result
3. **Some facet combinations ARE valuable landing pages** — `/programmes/engineering/nigeria` (high search volume) should be indexed

**Strategy:**

| Facet combination type | URL pattern | SEO directive |
|------------------------|-------------|---------------|
| Single discipline + country | `/programmes/{discipline}/{country}` | Index, canonical, curated meta |
| Single discipline | `/programmes/{discipline}` | Index, canonical |
| Single country | `/programmes/country/{country}` | Index, canonical |
| Multi-facet (complex) | `/programmes?discipline=...&country=...&level=...` | Noindex, follow |
| Search with query | `/search?q=...` | Noindex, nofollow |

**Implementation:**

1. `spatie/laravel-sitemap` generates sitemap for indexable URLs only (curated landing pages + entity detail pages)
2. `spatie/schema-org` generates structured data for rich snippets (Programme, EducationalOrganization, Scholarship)
3. Custom middleware adds `X-Robots-Tag` header based on URL pattern
4. Curated landing page content is stored in database (not hardcoded), manageable by content team via Filament

**Custom Implementation Justified:** The faceted URL strategy is application-specific. No SEO package handles the nuanced "index these facet combinations but not those" logic. The middleware is ~50 lines of code.

---

## 15. TALL Architecture

The TALL stack (Tall = Tailwind CSS + Alpine.js + Laravel + Livewire) is the presentation foundation. This section reviews the stack's package needs and compatibility.

### 15.1 Stack Components

| Component | Version | Status | Notes |
|-----------|---------|--------|-------|
| Laravel | 11.x | ADOPT NOW | Framework |
| Livewire | 3.x | ADOPT NOW | Server-rendered components |
| Flux | 2.x | ADOPT NOW | Official Livewire component library (replaces need for WireUI) |
| Alpine.js | 3.x | ADOPT NOW | Client-side interactivity (dropdowns, modals, transitions) |
| Tailwind CSS | 4.x | ADOPT NOW | Utility-first CSS |

### 15.2 Livewire-Specific Considerations

- **File uploads** — Livewire's `WithFileUploads` trait handles file uploads natively. No additional package needed for institution logo or document uploads. Files are stored via Laravel's filesystem (S3 in production) and registered with `spatie/laravel-medialibrary` for conversions (thumbnails, optimized formats).
- **Pagination** — Livewire's `WithPagination` trait handles cursor and offset pagination natively. No additional package needed.
- **Form validation** — `spatie/laravel-data` provides form objects with validation rules. Livewire 3's `#[Validate]` attribute is used for simple component-level validation.
- **Real-time** — Livewire's `#[On]` attribute and `$listeners` handle real-time updates within the server-rendered paradigm. No WebSocket package needed for Livewire features (Livewire uses its own polling/push mechanism).

### 15.3 Alpine.js Patterns

```javascript
// Share button with Web Share API fallback
x-data="{
    share() {
        if (navigator.share) {
            navigator.share({ title: this.title, url: this.url });
        } else {
            // Fallback: copy link to clipboard
            navigator.clipboard.writeText(this.url);
            this.copied = true;
        }
    }
}"
```

Alpine.js handles lightweight client-side interactions that don't need server round-trips: dropdown menus, mobile navigation toggles, copy-to-clipboard, share buttons, and UI state transitions. These are 10-30 line components, not applications.

---

## 16. Filament Architecture

FilamentPHP is used **exclusively for the admin panel**. It is NOT used for the public-facing application. This boundary is strict and must remain so.

### 16.1 Filament Resources

Each aggregate root gets a Filament resource for admin CRUD:

| Aggregate Root | Filament Resource | Key Features |
|----------------|-------------------|-------------|
| Educational Institution | InstitutionResource | Logo upload, multi-admin management, programme count |
| Programme | ProgrammeResource | Rich text description, discipline multi-select, qualification selector |
| Scholarship | ScholarshipResource | Amount/currency, deadline picker, eligibility criteria |
| Admission Cycle | AdmissionCycleResource | Date range, associated programmes, status workflow |
| Information Source | InformationSourceResource | Webhook URL, sync schedule, last sync status |

### 16.2 Filament Shield Integration

```php
// Filament Shield generates permissions and policies automatically
// After running: php artisan shield:generate --all  <!-- v5 Shield: generates policies for all resources -->

class ProgrammeResource extends \Filament\Resources\Resource  <!-- v5: Shield generates policies automatically -->
{
    public static function canCreate(): bool
    {
        return auth()->user()->can('create_programme');
    }

    // Shield auto-generates these policies based on Spatie Permission
    // create_programme, view_programme, update_programme, delete_programme
    // For organization-scoped access, we override with custom logic:
    public static function canEdit(Model $record): bool
    {
        $user = auth()->user();
        if ($user->hasRole('super-admin')) return true;

        return $user->hasPermissionInOrganization(
            'programme.update',
            $record->institution->organization
        );
    }
}
```

### 16.3 Filament Plugins

| Plugin | Classification | Rationale |
|--------|----------------|-----------|
| filament-shield | **ADOPT NOW** | Integrates Spatie Permission with Filament resources |
| filament-activitylog | **ADOPT NOW** | Integrates Spatie ActivityLog with Filament (audit trail in admin) |
| filament-media-manager | **EVALUATE LATER** | If we need advanced media management beyond MediaLibrary's built-in |

---

## 17. Study Abroad/Global Extensibility Review

StudyNexus launches in Nigeria, expands to Africa, then goes global. Each expansion stage introduces new architectural requirements.

### 17.1 Nigeria → Africa

| Requirement | Package/Implementation | Timeline |
|-------------|------------------------|----------|
| Multi-currency display | Custom value object (Money VO already in frozen baseline) | Launch |
| French language support | `spatie/laravel-translation-loader` for database-backed translations | Africa expansion |
| Portuguese language support | Same as above (Lusophone Africa: Angola, Mozambique, Cape Verde) | Africa expansion |
| Arabic language support | Same as above (North Africa: Egypt, Morocco, Tunisia) | Africa expansion |
| Regional accreditation bodies | Information Source webhooks per region | Africa expansion |
| Mobile-first (feature phones) | Progressive Web App + SMS notifications | Africa expansion |

### 17.2 Africa → Global

| Requirement | Package/Implementation | Timeline |
|-------------|------------------------|----------|
| GDPR compliance | `spatie/laravel-personal-data-export` (already ADOPT NOW) | Global |
| Cookie consent | `spatie/laravel-cookie-consent` | Global |
| CSP headers | `spatie/laravel-csp` | Global |
| Distributed tracing | `spatie/laravel-open-telemetry` | Global (when scale warrants) |
| OAuth2 API for partners | `laravel/passport` | Global (if partners need API access) |
| Study abroad specific fields | Domain model extension (NOT now — frozen) | Global |

### 17.3 Domain Model Extensibility

The frozen domain model must accommodate global expansion **without breaking changes**. The key mechanism is **value objects** and **optional attributes**:

- `Currency` value object already supports multi-currency
- `Language` value object supports programme language of instruction
- `Country` value object supports any country (not just Nigeria)
- New attributes (e.g., `study_abroad_specific_visa_info`) are added as **optional columns** or **JSON attributes** that don't break existing code

**We do NOT add "StudyAbroadProgramme" as a new aggregate root.** A programme is a programme, whether in Nigeria or the UK. The attributes differ, but the aggregate root is the same. This is the LBC approach — same model, different data.

---

## 18. Build-vs-Buy Matrix

For every capability StudyNexus needs, we evaluate whether to adopt a package ("buy"), build custom code, or defer. The matrix uses these symbols:

- **🟢 ADOPT** — Use a package
- **🟡 BUILD** — Write custom code
- **🔴 DEFER** — Not needed now
- **⚪ REJECT** — Not needed ever

| Capability | Decision | Package/Code | Rationale | Custom Code Equivalent |
|-----------|----------|--------------|-----------|----------------------|
| RBAC | 🟢 ADOPT | spatie/laravel-permission | De facto standard, excellent maintenance | 2,000+ lines |
| Scoped authorization | 🟡 BUILD | OrganizationMember pivot | No package provides this | 300 lines |
| DTOs & validation | 🟢 ADOPT | spatie/laravel-data | Comprehensive, type-safe, reduces boilerplate | 1,000+ lines |
| Media management | 🟢 ADOPT | spatie/laravel-medialibrary | Image conversions, responsive images, S3 | 3,000+ lines |
| Audit logging | 🟢 ADOPT | spatie/laravel-activitylog | Regulatory requirement, well-maintained | 500 lines |
| URL slugs | 🟢 ADOPT | spatie/laravel-sluggable | Simple, reliable, well-tested | 200 lines |
| API filtering | 🟢 ADOPT | spatie/laravel-query-builder | Complex filtering/sorting/inclusion | 1,500+ lines |
| Backups | 🟢 ADOPT | spatie/laravel-backup | Production non-negotiable | 400 lines |
| Webhook ingestion | 🟢 ADOPT | spatie/laravel-webhook-client | Signature verification, retry logic | 800 lines |
| Data export (GDPR) | 🟢 ADOPT | spatie/laravel-personal-data-export | Legal requirement | 500 lines |
| Bulk import | 🟢 ADOPT | maatwebsite/excel | Complex validation, chunking, queuing | 1,500+ lines |
| Push notifications | 🟢 ADOPT | laravel-notification-channels/webpush | Browser push for deadline alerts | 600 lines |
| Social login | 🟢 ADOPT | laravel/socialite | Google + Microsoft OAuth | 1,000+ lines |
| Admin panel | 🟢 ADOPT | filament/filament | Full admin framework | 10,000+ lines |
| Admin authorization | 🟢 ADOPT | filament-shield | Permission-resource integration | 500 lines |
| Performance monitoring | 🟢 ADOPT | laravel/pulse | First-party, zero-config | 2,000+ lines |
| Sitemap | 🟢 ADOPT | spatie/laravel-sitemap | Standard sitemap generation | 300 lines |
| Settings | 🟢 ADOPT | spatie/laravel-settings | App-level settings without .env | 400 lines |
| Search projection sync | 🟡 BUILD | Custom Scout + Typesense wiring | Domain-specific projection logic | 200 lines |
| SEO faceted URLs | 🟡 BUILD | Custom middleware + Blade | Application-specific logic | 50 lines |
| Community system | 🟡 BUILD | Custom module | No SO+Reddit hybrid package exists | 5,000+ lines |
| User engagement | 🟡 BUILD | Eloquent polymorphic | Simple relationships, no package needed | 100 lines |
| Comparison | 🟡 BUILD | Livewire + Query class | Presentation-only concern | 200 lines |
| Social sharing | 🟡 BUILD | Blade + Alpine.js | Simple meta + client-side | 40 lines |
| State machines | 🟡 BUILD | PHP enums + guard clauses | LBC-idiomatic, no package needed | 50 lines per aggregate |
| Tags (community) | 🔴 DEFER | spatie/laravel-tags | Needed when community launches | — |
| Markdown (community) | 🔴 DEFER | spatie/laravel-markdown | Needed when community launches | — |
| Response cache | 🔴 DEFER | spatie/laravel-responsecache | Evaluate when traffic warrants | — |
| Translation loader | 🔴 DEFER | spatie/laravel-translation-loader | Needed for Africa expansion | — |
| Browsershot (PDF) | 🔴 DEFER | spatie/browsershot | Needed for PDF exports | — |
| Queue monitoring | 🔴 DEFER | laravel/horizon | Needed when Redis adopted | — |
| Webhook outbound | 🔴 DEFER | spatie/laravel-webhook-server | Needed for partner integrations | — |
| Event sourcing | ⚪ REJECT | — | Over-engineering, contradicts frozen baseline | — |
| Newsletter (Mailchimp) | ⚪ REJECT | — | Provider-locked; use Laravel Notifications | — |
| Model states | ⚪ REJECT | — | Enums + guard clauses are simpler for LBC | — |
| WireUI | ⚪ REJECT | — | Superseded by Flux | — |
| Livewire tables | ⚪ REJECT | — | Filament handles admin; public uses custom | — |
| Fractal | ⚪ REJECT | — | Superseded by laravel-data | — |
| View models | ⚪ REJECT | — | Superseded by laravel-data | — |
| Value store | ⚪ REJECT | — | Superseded by laravel-settings | — |

---

## 19. Package Quality Matrix

Every ADOPT NOW package is scored against the 12-point evaluation criteria. Score: 1 (poor) to 5 (excellent).

| Package | Maintenance | Compatibility | Tests | Docs | Community | Deps | Layer | Domain | Custom Equiv | Upgrade Risk | Security | Urgency | **Total** |
|---------|------------|--------------|-------|------|-----------|------|-------|--------|-------------|-------------|----------|---------|----------|
| laravel-permission | 5 | 5 | 5 | 5 | 5 | 4 | 5 | 5 | 5 | 4 | 4 | 5 | **57** |
| laravel-backup | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 4 | 4 | 3 | 5 | **56** |
| laravel-data | 5 | 5 | 4 | 5 | 4 | 4 | 5 | 5 | 5 | 4 | 4 | 5 | **55** |
| laravel-medialibrary | 5 | 5 | 5 | 5 | 5 | 3 | 4 | 4 | 5 | 4 | 3 | 4 | **52** |
| laravel-activitylog | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 4 | 4 | 3 | 4 | **51** |
| laravel-sluggable | 5 | 5 | 5 | 4 | 4 | 5 | 5 | 5 | 3 | 4 | 5 | 4 | **50** |
| laravel-query-builder | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 4 | 4 | 3 | 4 | **51** |
| laravel-webhook-client | 5 | 5 | 4 | 4 | 4 | 4 | 5 | 5 | 4 | 4 | 3 | 5 | **52** |
| laravel-personal-data-export | 4 | 4 | 4 | 4 | 3 | 5 | 5 | 5 | 3 | 3 | 3 | 5 | **48** |
| maatwebsite/excel | 5 | 5 | 5 | 5 | 5 | 3 | 4 | 5 | 5 | 3 | 3 | 5 | **53** |
| webpush | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 4 | 3 | 3 | 4 | **48** |
| socialite | 5 | 5 | 5 | 5 | 5 | 4 | 5 | 5 | 4 | 4 | 3 | 4 | **54** |
| filament-shield | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 4 | 3 | 3 | 4 | **48** |
| laravel/pulse | 5 | 5 | 5 | 5 | 4 | 4 | 5 | 5 | 4 | 5 | 3 | 4 | **55** |
| laravel-sitemap | 5 | 5 | 5 | 4 | 4 | 5 | 5 | 5 | 3 | 4 | 5 | 3 | **49** |
| laravel-settings | 5 | 5 | 5 | 4 | 4 | 5 | 5 | 5 | 3 | 4 | 5 | 3 | **49** |

**Minimum quality threshold:** 40/60. All ADOPT NOW packages exceed this. Packages scoring below 40 are evaluated more carefully or rejected.

**Quality observations:**

- **Spatie packages** consistently score highest due to exceptional maintenance and documentation
- **maatwebsite/excel** scores high despite a heavier dependency footprint because its custom code equivalent is massive and its feature set is irreplaceable
- **webpush** scores lower on upgrade risk because the Web Push protocol is stable but browser implementation varies
- **laravel-personal-data-export** is a smaller/younger package (lower community score) but solves a legal requirement that we cannot defer

---

## 20. Adopt-Now Package List

These 17 packages are required for production launch or immediate operational needs. They are installed before the first deployment.

| # | Package | Version | Purpose | LBC Layer |
|---|---------|---------|---------|-----------|
| 1 | `spatie/laravel-permission` | ^6.0 | RBAC | Application (Authorization) |
| 2 | `spatie/laravel-data` | ^4.0 | DTOs, form objects, API resources | Application (DTOs) |
| 3 | `spatie/laravel-medialibrary` | ^11.0 | File/image management | Infrastructure (Persistence) |
| 4 | `spatie/laravel-activitylog` | ^4.0 | Audit trail | Infrastructure (Logging) |
| 5 | `spatie/laravel-sluggable` | ^3.0 | URL slug generation | Application (Utilities) |
| 6 | `spatie/laravel-query-builder` | ^3.0 | API filtering/sorting | Application (Queries) |
| 7 | `spatie/laravel-backup` | ^9.0 | Database + file backups | Infrastructure (Operations) |
| 8 | `spatie/laravel-webhook-client` | ^3.0 | Webhook ingestion for integrations | Infrastructure (Integrations) |
| 9 | `spatie/laravel-personal-data-export` | ^1.0 | GDPR/NDPR data export | Infrastructure (Compliance) |
| 10 | `maatwebsite/excel` | ^3.1 | Bulk data import | Infrastructure (Import) |
| 11 | `laravel-notification-channels/webpush` | ^1.0 | Browser push notifications | Infrastructure (Notifications) |
| 12 | `laravel/socialite` | ^5.0 | Social login (Google, Microsoft) | Infrastructure (Auth) |
| 13 | `laravel/sanctum` | ^4.0 | API token auth (mobile) | Infrastructure (Auth) |
| 14 | `laravel/pulse` | ^1.0 | Performance monitoring | Infrastructure (Monitoring) |
| 15 | `filament/filament` | ^3.0 | Admin panel | Presentation (Admin) |
| 16 | `bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) -->` | ^3.0 | Filament + Permission integration | Presentation (Admin) |
| 17 | `pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard -->` | ^3.0 | Activity log in admin panel | Presentation (Admin) |

**Installation command:**

```bash
composer require \
  spatie/laravel-permission \
  spatie/laravel-data \
  spatie/laravel-medialibrary \
  spatie/laravel-activitylog \
  spatie/laravel-sluggable \
  spatie/laravel-query-builder \
  spatie/laravel-backup \
  spatie/laravel-webhook-client \
  spatie/laravel-personal-data-export \
  maatwebsite/excel \
  laravel-notification-channels/webpush \
  laravel/socialite \
  laravel/sanctum \
  laravel/pulse \
  filament/filament:"^5.0" \
  bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) --> \
  pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard -->
```

---

## 21. Evaluate-Later Package List

These packages are potentially useful but have no current use case or need further evaluation before adoption.

| # | Package | Purpose | Trigger for Adoption | Blocker |
|---|---------|---------|---------------------|---------|
| 1 | `spatie/laravel-schedule-monitor` | Cron job monitoring | When we have >5 scheduled jobs | Laravel's built-in scheduling may suffice |
| 2 | `spatie/laravel-health` | Availability checks | When we need health checks beyond Kubernetes probes | May be redundant with infrastructure monitoring |
| 3 | `spatie/laravel-honeypot` | Anti-spam for forms | When we see form spam in production | Livewire has built-in CSRF; honeypot adds layer |
| 4 | `spatie/laravel-rate-limits  <!-- ⚠️ INVALID/DOES NOT EXIST: use Laravel RateLimiter facade or spatie/laravel-rate-limited-job-middleware -->` | API rate limiting | When we need per-user rate limits beyond Laravel's throttle | Laravel's `RateLimiter` facade may suffice |
| 5 | `spatie/laravel-csp` | Content Security Policy | When we deploy to production with EU users | Important for security but not launch-blocking |
| 6 | `spatie/laravel-cookie-consent` | GDPR cookie consent | When we serve EU users | Not needed for Nigeria MVP |
| 7 | `spatie/laravel-open-telemetry` | Distributed tracing | When we have >5 services or microservices | Premature for monolith; contradicts no-microservices rule |
| 8 | `spatie/laravel-onboard` | Onboarding step tracking | When we implement guided onboarding | Can be implemented with 50 lines of custom code |
| 9 | `laravel/passport` | OAuth2 server | When third-party partners need API access | Sanctum suffices for first-party mobile app |
| 10 | `rappasoft/laravel-livewire-tables` | Public-facing tables | When Filament tables don't fit public UI | Likely REJECT — custom Livewire tables are simple |
| 11 | `laravel/passkeys` | WebAuthn/Passkeys auth | When browser support is universal | Low priority, evaluate in 12 months |

---

## 22. Rejected Package List

These packages are explicitly rejected with rationale. This list prevents re-evaluation unless new evidence emerges.

| # | Package | Rejection Rationale | Alternative |
|---|---------|---------------------|-------------|
| 1 | `spatie/laravel-event-sourcing` | Over-engineering. Forces CQRS/ES architecture. Contradicts frozen baseline and LBC pattern. | Domain events (already in baseline) + event listeners |
| 2 | `spatie/laravel-comments` | Commercial/paid license. Too simple for SO+Reddit hybrid community. | Custom community module |
| 3 | `spatie/laravel-view-models` | Superseded by laravel-data which provides validated DTOs, type-safe form objects, and API resource conversion. | laravel-data |
| 4 | `spatie/laravel-feeds` | RSS/Atom feeds have near-zero relevance for education discovery targeting African students. | Not needed |
| 5 | `spatie/laravel-geocoder` | Premature. Location search via Typesense geo filter. Geocoding not needed at launch. | Typesense geo filter |
| 6 | `spatie/laravel-menu` | Superseded by Blade components + Livewire navigation. Menu builders are server-side patterns that don't fit TALL. | Blade components |
| 7 | `spatie/laravel-model-states` | PHP enums + guard clauses in domain methods are simpler, more idiomatic for LBC, and avoid trait-on-model pattern. Transition rules should be explicit in domain methods, not delegated to a package. | PHP enums + guard clauses |
| 8 | `spatie/laravel-newsletter` | Mailchimp-only via drewm/mailchimp-api dependency. Provider lock-in. Use Laravel Notifications + queue for provider-independent newsletter. | Laravel Notifications + queue |
| 9 | `spatie/laravel-fractal` | Superseded by laravel-data. Fractal was for API transformers; laravel-data provides this + validation + types. | laravel-data |
| 10 | `spatie/valuestore` | Superseded by laravel-settings. Same functionality, better API, more active maintenance. | laravel-settings |
| 11 | `wireui/wireui` | Unnecessary when using Flux. Flux is the official Livewire component library. Two component libraries = confusion. | Flux |
| 12 | `spatie/laravel-ray` | Development-only debugging tool. Useful locally (`ray()` calls), but must never be a production dependency. | Dev dependency only |

---

## 23. Custom Implementation Justification List

These capabilities require custom code because no package matches the specific requirement, or the custom code is bounded enough that a dependency is unjustified.

| # | Capability | Lines Est. | Justification | LBC Layer | Test Strategy |
|---|-----------|-----------|---------------|-----------|---------------|
| 1 | OrganizationMember pivot | 300 | Scoped authorization — Spatie Permission provides global roles but not tenant-scoped roles. No Laravel package provides this pattern. BookStack's approach is the reference implementation. | Application (Authorization) | Unit tests for `hasPermissionInOrganization()`, feature tests for multi-tenant access |
| 2 | Community system | 5,000+ | No Laravel package provides a Stack Overflow + Reddit hybrid. Spatie Comments is too simple and paid. We need questions, answers, posts, comments, votes, reputation — this is a full sub-application. | Separate Community module | Feature tests for each entity type, integration tests for voting/reputation |
| 3 | Search projection sync | 200 | Domain events → Scout → Typesense wiring is custom because Scout's default sync is model-level, not aggregate-level. We need to trigger re-indexing of related entities (e.g., programme change → re-index parent institution). | Infrastructure (Search) | Integration tests with Typesense, reconciliation job tests |
| 4 | SEO faceted URL strategy | 50 | The "index these facet combos but not those" logic is application-specific. No SEO package handles this nuance. | Presentation (Middleware) | HTTP tests verifying X-Robots-Tag headers per URL pattern |

**Total custom code estimate: ~5,550 lines**

This is significant but justified. The community system alone accounts for ~5,000 lines and would require a similar amount of custom code regardless of which packages we adopt, because no package matches our hybrid architecture. The other three items are bounded, well-tested, and would not benefit from any existing package.

---

## 24. Dependency Risk Analysis

Every dependency introduces risk. This section analyzes the risk profile of our adopted packages.

### 24.1 Risk Categories

| Risk | Description | Mitigation |
|------|-------------|------------|
| **Abandonment** | Package maintainer stops updating | Prefer Spatie (track record), avoid single-maintainer packages |
| **Breaking changes** | Package major version requires code changes | Pin versions, read upgrade guides before Laravel upgrades |
| **Security vulnerability** | Package has CVE | Monitor `composer audit`, subscribe to security advisories |
| **Coupling** | Package pervades codebase, hard to replace | Isolate package interactions behind application-layer interfaces |
| **Dependency conflict** | Two packages require conflicting transitive deps | Use `composer why` to resolve, prefer packages with minimal deps |
| **Performance** | Package adds overhead to critical path | Benchmark before adoption, profile in production |

### 24.2 Per-Package Risk Assessment

| Package | Abandonment Risk | Breaking Change Risk | Security Risk | Coupling Risk | Overall Risk |
|---------|-----------------|---------------------|---------------|---------------|-------------|
| laravel-permission | Very Low | Low | Low | **Medium** (pervasive — every policy uses it) | **Low** |
| laravel-data | Very Low | Medium (v3→v4 had breaking changes) | Low | **Medium** (all DTOs use it) | **Medium** |
| laravel-medialibrary | Very Low | Low | Low | Low | **Low** |
| laravel-activitylog | Very Low | Very Low | Low | Low | **Low** |
| laravel-sluggable | Very Low | Very Low | Low | Low | **Low** |
| laravel-query-builder | Very Low | Very Low | Low | Low | **Low** |
| laravel-backup | Very Low | Very Low | Low | Low | **Low** |
| laravel-webhook-client | Very Low | Low | **Medium** (processes external input) | Low | **Medium** |
| laravel-personal-data-export | Low | Medium (v1, less mature) | Low | Low | **Medium** |
| maatwebsite/excel | Very Low | Medium (v2→v3 was significant) | **Medium** (processes uploaded files) | **Medium** (import infrastructure) | **Medium** |
| webpush | Low | Low | Low | Low | **Low** |
| socialite | Very Low | Low | Low | Low | **Low** |
| filament | Very Low | **High** (v2→v3 was major rewrite) | Low | **High** (admin panel is deeply coupled) | **High** |
| filament-shield | Low | **High** (follows Filament major versions) | Low | **Medium** | **High** |
| laravel/pulse | Very Low | Low (first-party) | Low | Low | **Low** |

### 24.3 Highest Risk: Filament

Filament is our highest-risk dependency because:

1. **Major version rewrites** — Filament v2→v3 required significant migration effort. v3→v4 may do the same.
2. **Deep coupling** — Every admin resource, widget, and page is a Filament class. Replacing Filament would be a full admin rewrite.
3. **Ecosystem lock-in** — Filament plugins (Shield, ActivityLog) only work with Filament.

**Mitigation:**

- Keep Filament resources thin — business logic stays in Application Actions, not in Filament resource methods
- Admin panel is isolated — public application uses zero Filament code
- Budget 2-3 days for each Filament major version upgrade
- Monitor Filament's release cadence and upgrade proactively (don't fall 2 versions behind)

### 24.4 Coupling Isolation Strategy

For packages with **Medium** or **High** coupling risk, we isolate them behind application-layer interfaces:

```php
// Instead of directly calling MediaLibrary everywhere:
// Bad: $model->addMedia($file)->toMediaCollection('logos');

// Good: Application Action that wraps MediaLibrary
class AddInstitutionLogoAction
{
    public function execute(Institution $institution, UploadedFile $file): Media
    {
        return $institution->addMedia($file)
            ->usingName($institution->slug . '-logo')
            ->toMediaCollection('logos');
    }
}
```

This way, if we ever replace MediaLibrary (unlikely, but defensive), we change one Action class, not 50 call sites.

---

## 25. Security Considerations

### 25.1 Packages That Process External Input

| Package | Input Source | Attack Vector | Mitigation |
|---------|-------------|---------------|------------|
| laravel-webhook-client | HTTP POST from external services | Signature spoofing, replay attacks, payload injection | Webhook signature verification (built-in), rate limiting on webhook endpoints, payload schema validation |
| maatwebsite/excel | Uploaded Excel/CSV files | Malicious macros, zip bombs, formula injection | Disable macro evaluation, enforce file size limits, validate cell data against domain rules before persistence |
| laravel-personal-data-export | User request | Data leakage (export includes another user's data) | Scope export strictly to requesting user's data, audit export events |
| laravel/socialite | OAuth redirect | CSRF, open redirect, token theft | Socialite handles CSRF state parameter, validate redirect URIs |

### 25.2 Authentication Security

| Mechanism | Package | Consideration |
|-----------|---------|---------------|
| Password auth | Laravel Fortify | Bcrypt/Argon2, rate-limited login, password confirmation for sensitive actions |
| Social auth | Socialite | Validate OAuth state, restrict provider domains for institutional Microsoft |
| API tokens | Sanctum | Token abilities (scope), token expiration, revocation |
| Session security | Laravel | Secure cookies, SameSite=Lax, HTTPS-only in production, session fixation protection |
| Web Push | webpush | VAPID keys authenticate push subscription, no user-identifying data in push payloads |

### 25.3 Data Privacy

| Regulation | Applies When | Package | Requirement |
|------------|-------------|---------|-------------|
| Nigerian NDPR | Now (Nigeria launch) | laravel-personal-data-export | Data export on request, data deletion on account deletion |
| GDPR | Global expansion | laravel-personal-data-export + laravel-cookie-consent | Right to access, right to erasure, right to portability, lawful basis for processing |
| Kenyan DPA | Africa expansion | Same packages | Similar to GDPR, data localization requirements |

### 25.4 Webhook Security Deep-Dive

The `spatie/laravel-webhook-client` package provides critical security features for webhook ingestion:

```php
// config/webhook-client.php
return [
    'configs' => [
        [
            'name' => 'information-source-webhooks',
            'signing_secret' => env('WEBHOOK_SECRET'),
            'signature_header_name' => 'X-Webhook-Signature',
            'signature_validator' => \Spatie\WebhookClient\SignatureValidator\DefaultSignatureValidator::class,
            'webhook_profile' => \Spatie\WebhookClient\WebhookProfile\ProcessEverythingWebhookProfile::class,
            'webhook_model' => \Spatie\WebhookClient\Models\WebhookCall::class,
            'process_webhook_job' => \App\Infrastructure\Integrations\ProcessInformationSourceWebhookJob::class,
        ],
    ],
];
```

The signature validator ensures that webhook payloads are genuinely from the Information Source, not from an attacker. The `ProcessInformationSourceWebhookJob` is queued, so webhook processing doesn't block the HTTP response (and can be retried on failure).

---

## 26. Performance Considerations

### 26.1 Package Performance Impact

| Package | Impact | Detail | Mitigation |
|---------|--------|--------|------------|
| laravel-permission | **Low** | Database query on `hasPermissionTo()`. Cached via Laravel's cache when `cache.enabled = true` in config. | Enable permission caching, clear cache on role/permission changes |
| laravel-data | **Low** | DTO creation is PHP object construction. No database queries. | None needed |
| laravel-medialibrary | **Medium** | Media retrieval adds queries. Image conversion is CPU-intensive. | Queue media conversions, use responsive images with lazy loading |
| laravel-activitylog | **Medium** | Every logged action is a database write. | Queue activity log writes, use `lazy` logging mode, batch inserts |
| laravel-query-builder | **Low** | Adds WHERE clauses to existing queries. | Index filtered/sorted columns in PostgreSQL |
| laravel-backup | **Medium** | Backup job is I/O and CPU intensive. | Run during off-peak hours, use incremental backups |
| laravel-webhook-client | **Low** | Webhook processing is queued. | Ensure adequate queue workers |
| maatwebsite/excel | **High** | Excel import of thousands of rows is memory and CPU intensive. | Use `WithChunkReading` (process in chunks), `ShouldQueue` (queue imports), limit memory via `ini_set` |
| webpush | **Low** | Push notification dispatch is queued. | Ensure adequate queue workers |
| laravel/pulse | **Low** | Pulse aggregates are computed periodically, not on every request. | Configure aggregation interval, exclude high-traffic routes from tracking |
| filament | **Medium** | Admin panel loads its own assets. Each resource page has queries. | Lazy-load Filament panels, optimize Eager Loading in resources |

### 26.2 Caching Strategy

| Cache Type | Store | Package | Usage |
|------------|-------|---------|-------|
| Permission cache | Redis/App | laravel-permission | Cached role/permission checks |
| Configuration cache | File | Laravel | `config:cache` in production |
| Route cache | File | Laravel | `route:cache` in production |
| View cache | File | Laravel | `view:cache` in production |
| Response cache | Redis | spatie/laravel-responsecache (DEFER) | Public listing pages, when traffic warrants |
| Typesense index | Typesense | Custom | Search projection, not cache |
| Query cache | Redis | Application-level | Expensive aggregation queries (programme counts by discipline) |

### 26.3 Database Indexing Strategy

Key indexes for adopted packages:

```sql
-- Spatie Permission
CREATE INDEX idx_model_has_roles_model ON model_has_roles (model_type, model_id);
CREATE INDEX idx_model_has_permissions_model ON model_has_permissions (model_type, model_id);

-- Spatie ActivityLog
CREATE INDEX idx_activity_log_subject ON activity_log (subject_type, subject_id);
CREATE INDEX idx_activity_log_causer ON activity_log (causer_type, causer_id);
CREATE INDEX idx_activity_log_created ON activity_log (created_at);

-- OrganizationMember (custom)
CREATE INDEX idx_org_members_user_org ON organization_members (user_id, organization_id);
CREATE INDEX idx_org_members_org_role ON organization_members (organization_id, role_id);

-- User engagement (custom)
CREATE INDEX idx_user_saves_user ON user_saves (user_id, saveable_type, saveable_id);
CREATE INDEX idx_user_follows_user ON user_follows (user_id, followable_type, followable_id);

-- Webhook calls
CREATE INDEX idx_webhook_calls_processed ON webhook_calls (processed_at);
```

---

## 27. Upgrade/Maintenance Considerations

### 27.1 Laravel Version Upgrade Path

| Laravel Version | Expected Release | Key Concerns | Package Compatibility Risk |
|----------------|-----------------|--------------|--------------------------|
| 11.x (current) | 2024-03 | Current version | All ADOPT NOW packages compatible |
| 12.x | 2025-03 | PHP 8.3+ requirement, Carbon 3 | Spatie packages typically support within 1 month |
| 13.x | 2026-03 | Unknown changes | Spatie has 2-year upgrade track record |

### 27.2 Per-Package Upgrade Strategy

| Package | Upgrade Approach | Rollback Strategy |
|---------|-----------------|-------------------|
| All Spatie packages | Follow Spatie's upgrade guides (typically minimal breaking changes) | Git branch, test before merge |
| maatwebsite/excel | Major versions require migration (v2→v3 was significant) | Pin to current major, test upgrade in staging |
| filament | Major versions are significant rewrites (budget 2-3 days) | Keep admin resources thin to minimize migration surface |
| webpush | Protocol is stable, package changes are minimal | Standard version pinning |
| socialite | Provider drivers are stable, core changes rare | Standard version pinning |

### 27.3 Maintenance Cadence

| Activity | Frequency | Owner |
|----------|-----------|-------|
| `composer update` (minor/patch) | Weekly | CI automated |
| Security audit (`composer audit`) | Daily | CI automated |
| Package upgrade review | Monthly | Tech lead |
| Laravel major version upgrade | Annually | Architecture team |
| Dependency removal review | Quarterly | Architecture team |

### 27.4 Dead Dependency Detection

A package that was adopted but is no longer used is worse than no package — it's a maintenance burden with zero benefit. We run a quarterly check:

```bash
# Find packages that might be unused
composer outdated --direct

# Check if a package's classes are referenced in code
# Example: is laravel-sluggable still used?
rg "HasSlug|Sluggable|spatie/laravel-sluggable" app/ --type php
```

If a package is no longer referenced, it's a candidate for removal. This prevents dependency rot.

---

## 28. Architecture Impact Analysis

This section maps each adopted package to the architectural elements it affects.

### 28.1 Impact on LBC Layers

| Package | Domain | Application | Infrastructure | Presentation |
|---------|--------|-------------|----------------|-------------|
| laravel-permission | — | ✅ (policies, authorization) | — | — |
| laravel-data | — | ✅ (DTOs, form objects) | — | — |
| laravel-medialibrary | — | — | ✅ (file storage, image processing) | — |
| laravel-activitylog | — | — | ✅ (database writes) | — |
| laravel-sluggable | — | ✅ (slug generation) | — | — |
| laravel-query-builder | — | ✅ (query construction) | — | — |
| laravel-backup | — | — | ✅ (backup operations) | — |
| laravel-webhook-client | — | — | ✅ (webhook processing) | — |
| laravel-personal-data-export | — | — | ✅ (data export) | — |
| maatwebsite/excel | — | ✅ (import actions) | ✅ (file parsing, queuing) | — |
| webpush | — | ✅ (notification classes) | ✅ (push delivery) | — |
| socialite | — | ✅ (auth actions) | ✅ (OAuth flow) | ✅ (redirect views) |
| filament | — | — | — | ✅ (admin panel) |
| filament-shield | — | ✅ (authorization) | — | ✅ (admin panel) |
| laravel/pulse | — | — | ✅ (monitoring) | ✅ (dashboard) |

**Key observation:** No ADOPT NOW package touches the Domain layer. This is correct — the domain model is frozen and package-independent. All package integration happens in Application, Infrastructure, or Presentation layers.

### 28.2 Impact on Aggregate Roots

| Aggregate Root | Packages That Interact | Interaction Type |
|----------------|----------------------|------------------|
| Educational Institution | medialibrary, sluggable, activitylog, query-builder, permission (via OrganizationMember) | Read/write, audit, auth |
| Programme | sluggable, activitylog, query-builder, excel (import) | Read/write, audit, import |
| Scholarship | sluggable, activitylog, query-builder | Read/write, audit |
| Admission Cycle | activitylog, query-builder | Read/write, audit |
| Information Source | webhook-client, activitylog | Webhook ingestion, audit |

**No package changes the domain behavior of any aggregate root.** Packages interact with aggregates through Application Actions, never by modifying domain methods. This preserves the frozen baseline.

### 28.3 Impact on Domain Events

| Domain Event | Packages That Listen | Listener Location |
|-------------|---------------------|-------------------|
| ProgrammeCreated | activitylog, Scout (Typesense sync) | Application/Listeners |
| ProgrammeUpdated | activitylog, Scout (Typesense sync) | Application/Listeners |
| InstitutionVerified | activitylog, notification (WebPush) | Application/Listeners |
| ScholarshipDeadlineApproaching | notification (WebPush, mail, database) | Application/Listeners |
| InformationSourceSynced | webhook-client (status update) | Infrastructure/Listeners |

**No package introduces new domain events.** Packages react to existing events or are triggered by Application Actions.

---

## 29. New ADRs Required

Four architectural decisions from this review require formal Architecture Decision Records before implementation begins.

### ADR-022-1: Webhook Architecture for Information Source Integration

**Status:** Proposed
**Context:** Information Sources (accreditation bodies, education authorities, data partners) will push data to StudyNexus via webhooks. We need to define the webhook ingestion architecture, including signature verification, payload validation, retry strategy, and error handling.
**Decision:** Use `spatie/laravel-webhook-client` for signature verification and payload storage, with custom `ProcessInformationSourceWebhookJob` for domain-specific processing.
**Consequences:** Webhook processing is asynchronous (queued), idempotent (duplicate webhooks are safe), and observable (all webhook calls stored in database for debugging).

### ADR-022-2: Community Module Architecture

**Status:** Proposed
**Context:** The community feature (questions, answers, posts, votes) must not pollute the frozen domain model. It must be a separate module with its own domain, application, infrastructure, and presentation layers.
**Decision:** Community is a separate module (`app/Community/`) within the same Laravel application, with its own domain entities, database tables, and Livewire components. It does not share database tables with the core domain.
**Consequences:** Community can evolve independently. Community entities are not part of the frozen baseline. Community uses its own authorization model (community moderators). Community tags use `spatie/laravel-tags` (deferred until community development begins).

### ADR-022-3: Newsletter Architecture (Rejecting Spatie Newsletter)

**Status:** Proposed
**Context:** StudyNexus needs to send newsletter emails to subscribers. `spatie/laravel-newsletter` is Mailchimp-only. We need provider independence for global expansion.
**Decision:** Implement newsletter as queued Laravel Notifications sent to subscriber lists, using Laravel's mail system (configurable provider via MAIL_MAILER env).
**Consequences:** Provider-independent (swap Mailchimp/SendGrid/Postmark via .env). Queue-based (no HTTP blocking). Native Laravel integration. No vendor lock-in.

### ADR-022-4: State Machine Explicitness (Rejecting Model-States)

**Status:** Proposed
**Context:** Aggregate root state transitions (e.g., Institution: Draft → Verified → Suspended → Closed) are currently enforced by domain methods with guard clauses. `spatie/laravel-model-states` would make transitions explicit.
**Decision:** Reject `spatie/laravel-model-states`. Continue with PHP enums + guard clauses in domain methods. Add explicit transition test coverage to ensure invalid transitions are prevented.
**Consequences:** No package dependency for state management. Transition rules live in domain layer (correct LBC placement). Requires comprehensive transition tests (one test per valid transition, one test per invalid transition).

---

## 30. Frozen-Domain Impact Test

This is the most critical test in the entire review. **No adopted package may require changes to the frozen domain model.** If any package does, it must be rejected or the integration must be redesigned.

### 30.1 Domain Model Reference

The frozen baseline (Document 20) contains:

- **5 Aggregate Roots:** Educational Institution, Programme, Scholarship, Admission Cycle, Information Source
- **20 Application Actions:** CreateInstitution, VerifyInstitution, SuspendInstitution, CloseInstitution, CreateProgramme, UpdateProgramme, PublishProgramme, ArchiveProgramme, CreateScholarship, UpdateScholarship, ActivateScholarship, DeactivateScholarship, OpenAdmissionCycle, CloseAdmissionCycle, AddProgrammeToCycle, RemoveProgrammeFromCycle, RegisterInformationSource, SyncInformationSource, ValidateSyncResult, ResolveSyncConflict
- **28 Value Objects:** Currency, Money, Country, Language, AccreditationStatus, ProgrammeStatus, ScholarshipStatus, CycleStatus, SyncStatus, InstitutionType, OwnershipType, QualificationLevel, Discipline, Duration, ContactInfo, Address, GeographicCoordinates, Website, SocialMediaLinks, TuitionFeeRange, AdmissionRequirement, EligibilityCriteria, ApplicationDeadline, ScholarshipAmount, CycleDateRange, InformationSourceType, SyncFrequency, DataFormat
- **29 Domain Events:** InstitutionCreated, InstitutionVerified, InstitutionSuspended, InstitutionReactivated, InstitutionClosed, ProgrammeCreated, ProgrammeUpdated, ProgrammePublished, ProgrammeArchived, ScholarshipCreated, ScholarshipUpdated, ScholarshipActivated, ScholarshipDeactivated, ScholarshipDeadlineApproaching, AdmissionCycleOpened, AdmissionCycleClosing, AdmissionCycleClosed, ProgrammeAddedToCycle, ProgrammeRemovedFromCycle, InformationSourceRegistered, InformationSourceSyncStarted, InformationSourceSyncCompleted, InformationSourceSyncFailed, SyncConflictDetected, SyncConflictResolved, InstitutionDataUpdated, ProgrammeDataUpdated, ScholarshipDataUpdated

### 30.2 Per-Package Impact Test Results

| Package | Requires New Aggregates? | Requires New Actions? | Requires New VOs? | Requires New Events? | **VERDICT** |
|---------|------------------------|---------------------|-------------------|---------------------|-------------|
| laravel-permission | No | No | No | No | ✅ PASS |
| laravel-data | No | No | No | No | ✅ PASS |
| laravel-medialibrary | No | No | No | No | ✅ PASS |
| laravel-activitylog | No | No | No | No | ✅ PASS |
| laravel-sluggable | No | No | No | No | ✅ PASS |
| laravel-query-builder | No | No | No | No | ✅ PASS |
| laravel-backup | No | No | No | No | ✅ PASS |
| laravel-webhook-client | No | No | No | No | ✅ PASS |
| laravel-personal-data-export | No | No | No | No | ✅ PASS |
| maatwebsite/excel | No | No | No | No | ✅ PASS |
| webpush | No | No | No | No | ✅ PASS |
| socialite | No | No | No | No | ✅ PASS |
| filament | No | No | No | No | ✅ PASS |
| filament-shield | No | No | No | No | ✅ PASS |
| laravel/pulse | No | No | No | No | ✅ PASS |

**All packages PASS the frozen-domain impact test.** No adopted package requires changes to the frozen domain model. This is expected and correct — all packages operate in Application, Infrastructure, or Presentation layers, never in Domain.

### 30.3 Future Freeze Extension Scenarios

When the domain model is unfrozen for evidence-driven extension (e.g., adding Study Abroad attributes for global expansion), the following packages would be evaluated for domain-level impact:

| Scenario | Domain Extension | Package Risk |
|----------|-----------------|-------------|
| Add "visa_requirement" to Programme | New Value Object: VisaRequirement | No package impact — it's a new VO |
| Add "exchange_rate" to Institution | New Value Object: ExchangeRate | No package impact — it's a new VO |
| Add "programme_comparison" aggregate | New Aggregate Root: Comparison | No package impact — comparison is custom code |
| Add "user_review" to Programme | New Aggregate Root: Review (in Community module) | No package impact — reviews are in separate module |

---

## 31. Implementation Sequencing

Package adoption must be sequenced to avoid integration conflicts and ensure each package is fully configured and tested before the next is introduced.

### Phase 1: Foundation (Week 1-2)

These packages have no dependencies on each other and form the base layer:

```
1. spatie/laravel-permission     → RBAC foundation
2. spatie/laravel-data           → DTOs for all subsequent Actions
3. spatie/laravel-activitylog    → Audit trail from day one
4. spatie/laravel-sluggable      → URL generation for all aggregates
5. laravel/sanctum               → API auth for mobile
```

**Configuration priority:**
- Run `php artisan vendor:publish` for all config files
- Set up database migrations and run them
- Write base tests for each package's integration

### Phase 2: Core Operations (Week 3-4)

These packages support core business operations:

```
6. spatie/laravel-medialibrary   → File uploads, image processing
7. spatie/laravel-query-builder  → API filtering
8. spatie/laravel-backup         → Production backup (configure before first deploy)
9. maatwebsite/excel             → Bulk import infrastructure
10. laravel/socialite            → Social login
```

**Key milestone:** After Phase 2, the application can import data, serve API requests, and has automated backups. This is the minimum viable infrastructure for staging deployment.

### Phase 3: Integration & Monitoring (Week 5-6)

These packages connect StudyNexus to external systems:

```
11. spatie/laravel-webhook-client   → Information Source webhooks
12. spatie/laravel-personal-data-export → GDPR/NDPR compliance
13. laravel-notification-channels/webpush → Push notifications
14. laravel/pulse                   → Performance monitoring
```

**Key milestone:** After Phase 3, the application can receive data from Information Sources, comply with data export requests, send push notifications, and monitor performance. This is the minimum viable infrastructure for production deployment.

### Phase 4: Admin Panel (Week 7-8)

These packages build the Filament admin panel:

```
15. filament/filament              → Admin framework
16. bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) -->    → Permission integration
17. pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard --> → Audit trail in admin
```

**Key milestone:** After Phase 4, the admin panel is fully functional with RBAC, audit trail, and all CRUD resources. This is the minimum viable infrastructure for admin user access.

### Phase 5: Deferred Packages (Post-Launch)

These packages are adopted when their trigger conditions are met:

```
18. spatie/laravel-sitemap          → When SEO strategy is finalized
19. spatie/laravel-settings         → When admin-configurable settings are needed
20. spatie/laravel-tags             → When community feature begins
21. spatie/laravel-markdown         → When community feature begins
22. spatie/laravel-responsecache    → When public traffic justifies caching
23. spatie/laravel-translation-loader → When Africa expansion begins (French, Portuguese, Arabic)
24. spatie/browsershot              → When PDF export is requested
25. spatie/eloquent-sortable        → When display ordering is needed
26. laravel/horizon                 → When Redis is adopted for queues
27. spatie/laravel-webhook-server   → When partner integrations need outbound webhooks
```

### Phase 6: Custom Implementations (Parallel with Phases 1-4)

These custom implementations are built alongside package adoption:

```
A. OrganizationMember pivot        → Phase 1 (needed for RBAC)
B. Search projection sync          → Phase 3 (needed for Typesense)
C. SEO faceted URL strategy        → Phase 5 (needed for SEO)
D. Community system                → Post-launch (separate module)
```

---

## 32. Final Architectural Verdict

### 32.1 Verdict Summary

This review affirms the architectural decisions from Document 21 while introducing critical elevations, rejections, and new evaluations based on deeper adversarial analysis.

**Elevations from Document 21:**

| Package | Doc 21 Classification | This Review Classification | Rationale for Elevation |
|---------|----------------------|---------------------------|----------------------|
| laravel-backup | ADOPT LATER | **ADOPT NOW** | Production without automated backups is negligent. This is not a "later" concern. |
| laravel-webhook-client | Not evaluated | **ADOPT NOW** | Information Source integrations are architecturally foundational, not future nice-to-haves. |
| laravel-personal-data-export | Not evaluated | **ADOPT NOW** | GDPR/NDPR compliance is a legal requirement, not a feature request. |
| maatwebsite/excel | Not evaluated | **ADOPT NOW** | Bulk import is a core operational need — the team cannot manually enter thousands of programmes. |
| webpush | Not evaluated | **ADOPT NOW** | Push notifications for deadline alerts are a key engagement channel for students. |
| socialite | Not evaluated | **ADOPT NOW** | Social login reduces registration friction — a known conversion requirement. |
| laravel/pulse | Not evaluated | **ADOPT NOW** | First-party, zero-config performance monitoring. No reason to defer. |

**Affirmed Rejections from Document 21:**

| Package | Rejection | This Review | Rationale |
|---------|-----------|-------------|-----------|
| laravel-model-states | DO NOT USE | **REJECT** | PHP enums + guard clauses are LBC-idiomatic. Adding a package for explicit transitions is dependency inflation when guard clauses already enforce the same rules. The key argument for model-states (preventing invalid transitions like Suspended→Closed) is better solved by comprehensive transition tests, not a package dependency. |
| laravel-newsletter | EVALUATE WHEN NEEDED | **REJECT** | Mailchimp-only is provider lock-in. Laravel Notifications + queue provides provider independence. |
| laravel-fractal | DO NOT USE | **REJECT** | Superseded by laravel-data. |
| valuestore | DO NOT USE | **REJECT** | Superseded by laravel-settings. |

**New Rejections:**

| Package | Rejection Rationale |
|---------|---------------------|
| laravel-event-sourcing | Over-engineering that contradicts frozen baseline and LBC architecture. |
| laravel-comments | Paid license + too simple for SO+Reddit hybrid. |
| laravel-view-models | Superseded by laravel-data. |
| laravel-feeds | Near-zero relevance for education discovery. |
| laravel-geocoder | Premature; Typesense geo filter handles location. |
| laravel-menu | Superseded by Blade components. |
| wireui/wireui | Unnecessary when using Flux. |

### 32.2 Dependency Graph Summary

```
StudyNexus Dependency Graph (ADOPT NOW only)
═══════════════════════════════════════════

├── Authentication & Authorization
│   ├── spatie/laravel-permission (RBAC)
│   ├── laravel/sanctum (API tokens)
│   ├── laravel/socialite (social login)
│   └── [Custom] OrganizationMember pivot
│
├── Data & Validation
│   ├── spatie/laravel-data (DTOs)
│   ├── spatie/laravel-query-builder (API filtering)
│   └── spatie/laravel-sluggable (URLs)
│
├── Media & Files
│   └── spatie/laravel-medialibrary (uploads, conversions)
│
├── Audit & Compliance
│   ├── spatie/laravel-activitylog (audit trail)
│   └── spatie/laravel-personal-data-export (GDPR/NDPR)
│
├── Integrations
│   ├── spatie/laravel-webhook-client (inbound webhooks)
│   └── maatwebsite/excel (bulk import)
│
├── Notifications
│   └── laravel-notification-channels/webpush (browser push)
│
├── Operations
│   ├── spatie/laravel-backup (backups)
│   └── laravel/pulse (performance monitoring)
│
└── Admin Panel
    ├── filament/filament (admin framework)
    ├── bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) --> (permission integration)
    └── pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard --> (audit in admin)

Total ADOPT NOW packages: 17
Total deferred packages: 9
Total rejected packages: 11
Total custom implementations: 4
```

### 32.3 Architectural Constraints Preserved

| Constraint | Status | Evidence |
|-----------|--------|----------|
| Frozen domain model untouched | ✅ PRESERVED | All 17 ADOPT NOW packages pass frozen-domain impact test (Section 30) |
| LBC layer integrity | ✅ PRESERVED | No package introduces logic in Domain layer; all operate in Application/Infrastructure/Presentation |
| No SPA/microservices/CQRS/ES | ✅ PRESERVED | Event-sourcing rejected; Livewire is server-rendered; monolith architecture maintained |
| PostgreSQL as source of truth | ✅ PRESERVED | No package introduces alternative truth source; Typesense remains projection |
| TALL stack coherence | ✅ PRESERVED | All packages compatible with Livewire/Alpine/Flux/Tailwind; WireUI rejected |
| Minimal dependency graph | ✅ PRESERVED | 17 packages for a platform of this scope is disciplined; each justified by >40/60 quality score |

### 32.4 The Adversarial Verdict

The most important outcome of this review is not the list of packages — it is the **discipline** demonstrated in rejecting packages that would add convenience at the cost of coupling.

**We reject `spatie/laravel-model-states`** even though explicit state transitions would be clearer, because PHP enums + guard clauses + comprehensive transition tests achieve the same guarantee without a package dependency that would place a trait on our aggregate roots.

**We reject `spatie/laravel-newsletter`** even though it would save us from writing a newsletter action, because its Mailchimp lock-in would constrain our provider choices as we expand across Africa and globally.

**We reject `spatie/laravel-event-sourcing`** even though it would provide perfect audit trails, because it forces an architectural paradigm (CQRS + ES) that contradicts our frozen baseline and LBC pattern.

**We adopt `spatie/laravel-backup` NOW** even though Document 21 said "later," because deploying to production without automated backups is not pragmatism — it's negligence.

**We adopt `spatie/laravel-webhook-client` NOW** even though Document 21 didn't evaluate it, because Information Source integrations are how StudyNexus ingests the data that makes it valuable. Without webhooks, we're manually importing data forever.

**The simplest architecture that can realistically grow** into a global education discovery platform — without fundamental rewrites, without domain model pollution, without vendor lock-in, and without over-engineering — is the one described in this document.

---

## Appendix A: Full Package Classification Table

| Package | Classification | Quality Score | Custom Code Equivalent | LBC Layer |
|---------|----------------|--------------|-----------------------|-----------|
| spatie/laravel-permission | ADOPT NOW | 57/60 | 2,000+ lines | Application |
| spatie/laravel-data | ADOPT NOW | 55/60 | 1,000+ lines | Application |
| spatie/laravel-medialibrary | ADOPT NOW | 52/60 | 3,000+ lines | Infrastructure |
| spatie/laravel-activitylog | ADOPT NOW | 51/60 | 500 lines | Infrastructure |
| spatie/laravel-sluggable | ADOPT NOW | 50/60 | 200 lines | Application |
| spatie/laravel-query-builder | ADOPT NOW | 51/60 | 1,500+ lines | Application |
| spatie/laravel-backup | ADOPT NOW | 56/60 | 400 lines | Infrastructure |
| spatie/laravel-webhook-client | ADOPT NOW | 52/60 | 800 lines | Infrastructure |
| spatie/laravel-personal-data-export | ADOPT NOW | 48/60 | 500 lines | Infrastructure |
| maatwebsite/excel | ADOPT NOW | 53/60 | 1,500+ lines | Infrastructure |
| laravel-notification-channels/webpush | ADOPT NOW | 48/60 | 600 lines | Infrastructure |
| laravel/socialite | ADOPT NOW | 54/60 | 1,000+ lines | Infrastructure |
| laravel/sanctum | ADOPT NOW | N/A (built-in) | — | Infrastructure |
| laravel/pulse | ADOPT NOW | 55/60 | 2,000+ lines | Infrastructure |
| filament/filament | ADOPT NOW | N/A (framework) | 10,000+ lines | Presentation |
| bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) --> | ADOPT NOW | 48/60 | 500 lines | Presentation |
| pxlrbt/filament-activity-log | ADOPT NOW | N/A (plugin) | 200 lines | Presentation |
| spatie/laravel-sitemap | ADOPT WHEN NEEDED | 49/60 | 300 lines | Infrastructure |
| spatie/laravel-settings | ADOPT WHEN NEEDED | 49/60 | 400 lines | Infrastructure |
| spatie/laravel-tags | ADOPT WHEN NEEDED | ~48/60 | 600 lines | Application |
| spatie/laravel-markdown | ADOPT WHEN NEEDED | ~45/60 | 300 lines | Infrastructure |
| spatie/laravel-responsecache | ADOPT WHEN NEEDED | ~48/60 | 500 lines | Infrastructure |
| spatie/laravel-translation-loader | ADOPT WHEN NEEDED | ~47/60 | 400 lines | Infrastructure |
| spatie/browsershot | ADOPT WHEN NEEDED | ~47/60 | 800 lines | Infrastructure |
| spatie/eloquent-sortable | ADOPT WHEN NEEDED | ~44/60 | 100 lines | Application |
| spatie/laravel-welcome-notification | ADOPT WHEN NEEDED | ~42/60 | 30 lines | Application |
| laravel/horizon | ADOPT WHEN NEEDED | ~50/60 | 1,000+ lines | Infrastructure |
| spatie/laravel-webhook-server | ADOPT WHEN NEEDED | ~48/60 | 400 lines | Infrastructure |
| spatie/laravel-schedule-monitor | EVALUATE LATER | ~46/60 | 200 lines | Infrastructure |
| spatie/laravel-health | EVALUATE LATER | ~44/60 | 300 lines | Infrastructure |
| spatie/laravel-honeypot | EVALUATE LATER | ~44/60 | 100 lines | Infrastructure |
| spatie/laravel-rate-limits  <!-- ⚠️ INVALID/DOES NOT EXIST: use Laravel RateLimiter facade or spatie/laravel-rate-limited-job-middleware --> | EVALUATE LATER | ~42/60 | 150 lines | Infrastructure |
| spatie/laravel-csp | EVALUATE LATER | ~44/60 | 200 lines | Infrastructure |
| spatie/laravel-cookie-consent | EVALUATE LATER | ~42/60 | 100 lines | Presentation |
| spatie/laravel-open-telemetry | EVALUATE LATER | ~38/60 | 2,000+ lines | Infrastructure |
| spatie/laravel-onboard | EVALUATE LATER | ~40/60 | 50 lines | Application |
| laravel/passport | EVALUATE LATER | ~46/60 | 3,000+ lines | Infrastructure |
| rappasoft/laravel-livewire-tables | EVALUATE LATER | ~40/60 | 500 lines | Presentation |
| laravel/passkeys | EVALUATE LATER | ~35/60 | 800 lines | Infrastructure |
| spatie/laravel-event-sourcing | REJECT | — | — | — |
| spatie/laravel-comments | REJECT | — | — | — |
| spatie/laravel-view-models | REJECT | — | — | — |
| spatie/laravel-feeds | REJECT | — | — | — |
| spatie/laravel-geocoder | REJECT | — | — | — |
| spatie/laravel-menu | REJECT | — | — | — |
| spatie/laravel-model-states | REJECT | — | — | — |
| spatie/laravel-newsletter | REJECT | — | — | — |
| spatie/laravel-fractal | REJECT | — | — | — |
| spatie/valuestore | REJECT | — | — | — |
| wireui/wireui | REJECT | — | — | — |
| spatie/laravel-ray | REJECT (as dep) | — | — | — |

---

## Appendix B: State Machine Transition Test Specification

Since we rejected `spatie/laravel-model-states`, we must ensure that domain methods with guard clauses comprehensively prevent invalid transitions. This appendix specifies the required test coverage.

### Institution State Transitions

```
Valid transitions:
  Draft ──→ Verified
  Draft ──→ Closed
  Verified ──→ Suspended
  Verified ──→ Closed
  Suspended ──→ Verified  (reactivate)
  Closed ──→ (terminal state)

Invalid transitions (MUST be prevented by guard clauses + tested):
  Draft ──→ Suspended     ✗ (must be verified first)
  Suspended ──→ Closed    ✗ (must be reactivated first)
  Closed ──→ Draft        ✗ (terminal state)
  Closed ──→ Verified     ✗ (terminal state)
  Closed ──→ Suspended    ✗ (terminal state)
```

### Programme State Transitions

```
Valid transitions:
  Draft ──→ Published
  Draft ──→ Archived
  Published ──→ Draft      (unpublish)
  Published ──→ Archived
  Archived ──→ Draft      (restore)

Invalid transitions:
  Draft ──→ (no direct invalid transitions from Draft)
  Published ──→ Published  ✗ (no-op, but should be idempotent)
  Archived ──→ Published  ✗ (must restore to Draft first)
```

### Scholarship State Transitions

```
Valid transitions:
  Draft ──→ Active
  Draft ──→ Closed
  Active ──→ Inactive     (deactivate)
  Active ──→ Closed
  Inactive ──→ Active     (reactivate)
  Inactive ──→ Closed
  Closed ──→ (terminal state)

Invalid transitions:
  Draft ──→ Inactive      ✗ (must activate first)
  Inactive ──→ Closed     ✗ (must reactivate first... actually this may be valid)
  Closed ──→ Active       ✗ (terminal state)
```

### Test Template

```php
// tests/Domain/Institution/InstitutionStateTransitionsTest.php
class InstitutionStateTransitionsTest extends TestCase
{
    #[Test]
    public function draft_can_be_verified(): void
    {
        $institution = Institution::factory()->draft()->create();
        $institution->verify();
        $this->assertEquals(AccreditationStatus::Verified, $institution->accreditation_status);
    }

    #[Test]
    public function draft_cannot_be_suspended(): void
    {
        $this->expectException(InvalidStateTransitionException::class);
        $institution = Institution::factory()->draft()->create();
        $institution->suspend();
    }

    #[Test]
    public function suspended_cannot_be_closed(): void
    {
        $this->expectException(InvalidStateTransitionException::class);
        $institution = Institution::factory()->suspended()->create();
        $institution->close();
    }

    #[Test]
    public function closed_is_terminal_state(): void
    {
        $this->expectException(InvalidStateTransitionException::class);
        $institution = Institution::factory()->closed()->create();
        $institution->verify(); // or suspend(), or any transition
    }
}
```

This test suite provides the **explicit transition guarantee** that `spatie/laravel-model-states` would have provided, but without the package dependency. If a developer accidentally adds an invalid transition to a domain method, the test suite catches it immediately.

---

## Appendix C: Web Push Implementation Specification

### Server-Side

```php
// 1. VAPID keys (generate once, store in .env)
// php artisan webpush:vapid

// 2. User model modification
class User extends Authenticatable
{
    use HasPushSubscriptions; // From webpush package
}

// 3. Notification class
class ScholarshipDeadlineApproaching extends Notification
{
    public function __construct(public Scholarship $scholarship) {}

    public function via($notifiable): array
    {
        // Only send WebPush if user has subscriptions
        $channels = ['database', 'mail'];
        if ($notifiable->pushSubscriptions()->exists()) {
            $channels[] = WebPushChannel::class;
        }
        return $channels;
    }

    public function toWebPush($notifiable): WebPushMessage
    {
        return (new WebPushMessage)
            ->title('Scholarship Deadline Reminder')
            ->icon(asset('images/studynexus-icon.png'))
            ->body("{$this->scholarship->name} at {$this->scholarship->institution->name} closes in 7 days.")
            ->action('View Details', route('scholarships.show', $this->scholarship))
            ->action('Dismiss', 'dismiss')
            ->data(['scholarship_id' => $this->scholarship->id])
            ->vibrate([100, 50, 100]);
    }
}
```

### Client-Side (Alpine.js + Livewire)

```html
{{-- resources/views/livewire/push-notification-subscription.blade.php --}}
<div x-data="pushSubscription()" x-init="init()">
    <template x-if="!isSubscribed && isSupported">
        <button @click="subscribe"
                class="btn btn-primary">
            Enable Push Notifications
        </button>
    </template>
    <template x-if="isSubscribed">
        <span class="text-sm text-green-600">✓ Push notifications enabled</span>
    </template>
</div>

<script>
function pushSubscription() {
    return {
        isSupported: 'PushManager' in window,
        isSubscribed: false,

        async init() {
            if (!this.isSupported) return;
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            this.isSubscribed = !!subscription;
        },

        async subscribe() {
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: '{{ config("webpush.vapid.public_key") }}'
            });

            // Send subscription to server via Livewire
            @this.sendSubscriptionToServer(JSON.stringify(subscription));
            this.isSubscribed = true;
        }
    }
}
</script>
```

---

## Appendix D: Bulk Import Architecture Specification

### Import Flow

```
Admin uploads Excel file
       │
       ▼
Filament Upload Action
       │
       ▼
Maatwebsite Import Job (queued)
       │
       ├── Sheet 1: Institutions → Validate → Create/Update via Application Actions
       ├── Sheet 2: Programmes → Validate → Create/Update via Application Actions
       └── Sheet 3: Scholarships → Validate → Create/Update via Application Actions
       │
       ▼
Import Result (success count, failure count, error details)
       │
       ▼
Filament Notification (success/failure with details)
```

### Import Class Example

```php
// Infrastructure/Import/ProgrammeImport.php
class ProgrammeImport implements WithHeadingRow, WithValidation, WithChunkReading, ShouldQueue
{
    use Importable;

    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            try {
                app(CreateProgrammeAction::class)->execute(
                    institution: Institution::where('code', $row['institution_code'])->firstOrFail(),
                    data: ProgrammeData::fromImportRow($row),
                );
            } catch (Exception $e) {
                $this->failures[] = [
                    'row' => $row,
                    'error' => $e->getMessage(),
                ];
            }
        }
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'institution_code' => ['required', 'exists:institutions,code'],
            'discipline' => ['required', 'in:' . implode(',', Discipline::values())],
            'qualification_level' => ['required', 'in:' . implode(',', QualificationLevel::values())],
            'duration_months' => ['required', 'integer', 'min:1', 'max:120'],
            'tuition_fee' => ['nullable', 'numeric', 'min:0'],
            'currency' => ['required_with:tuition_fee', 'in:NGN,USD,GBP,EUR'],
        ];
    }

    public function chunkSize(): int
    {
        return 500; // Process 500 rows at a time
    }
}
```

**Critical architectural note:** The import delegates to `CreateProgrammeAction`, not directly to Eloquent. This ensures that imported data goes through the same Application-layer validation and domain logic as manually entered data. The import is just a different input channel — the business rules are identical.

---

**END OF DOCUMENT**

Document 22 — StudyNexus Laravel Ecosystem & Build-vs-Buy Review
Version: 1.0
Date: 2026-08-08
Status: Architecture Review — Final
Next: Implementation Sequencing (Phase 1 begins)
