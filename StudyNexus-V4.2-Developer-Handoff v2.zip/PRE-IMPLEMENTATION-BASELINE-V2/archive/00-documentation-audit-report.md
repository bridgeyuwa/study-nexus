# StudyNexus Documentation Cleanup — Audit & Pruning Proposal

**Date:** 2026-08-08
**Status:** AUDIT ONLY — No files modified
**Documents analyzed:** 32
**Author:** Super Z (automated audit agent)

---

## A. Executive Summary

| Metric | Value |
|--------|-------|
| Total documents | 32 |
| Genuinely necessary (authoritative) | 12 |
| Redundant or superseded | 14 |
| Should be consolidated | 4 |
| Should be archived | 16 |
| Dangerous ambiguities | 3 (Admission Pathway classification, file numbering errors, RBAC multi-source) |

**Key findings:**

1. The 32 documents form a well-structured discovery pipeline, but the pipeline itself is now historical — the discoveries are complete. The pipeline documents (reviews, validations, reconciliations) served their purpose but are now provenance artifacts, not working documents.

2. **6 documents are clearly authoritative and cannot be removed:** 03 (approved decisions), 06 (workflows), 15 (behaviour discovery), 21 (frozen baseline), 24 (final architecture), 27 (implementation blueprint).

3. **6 more documents contain unique information that must be preserved** but could be consolidated: 01 (business overview), 02 (glossary), 04 (open questions), 16 (Topic 3 attributes), 29 (RBAC), 30 (data pipeline).

4. **14 documents are superseded or historical** and should be archived: 00-conflict-register, 00-updated-audit-report, 07, 08, 09, 10, 11, 12, 13, 14, 17, 18, 20, 25, 26.

5. **3 conflicts remain unresolved at the document level:**
   - Admission Pathway: entity (file 18) vs. Value Object (file 15) — file 15 wins per behaviour evidence
   - File numbering errors in authority order references (files 13, 15)
   - RBAC defined in 5 places (files 21, 22, 23, 24, 27) with file 29 as canonical — older references are historical

6. **No information would be lost** if the pruning plan is followed, provided all archived documents remain accessible (not deleted).

---

## B. Current Documentation Inventory

| # | File | Purpose | Scope | Status | Authority | Unique Info? | Candidate Action |
|---|------|---------|-------|--------|-----------|-------------|-----------------|
| 1 | 00-conflict-register.md | Master reconciliation artifact | Cross-cutting (C1–C6, P1–P7) | reconciliation-artifact | High for audit trail | Yes — package fabrication findings, Packagist verification table | ARCHIVE |
| 2 | 00-updated-audit-report.md | Narrative audit summary + canonical set | Cross-cutting | reconciliation-artifact | High for audit trail | Yes — canonical document set, implementation baseline | ARCHIVE |
| 3 | 01-business-overview.md | Business identity, vision, personas, capabilities | Business | authoritative | High | Yes — narrative framing, "Critical Business Concern", capability relationships | CONSOLIDATE into business.md |
| 4 | 02-glossary.md | Canonical term dictionary | Terminology | authoritative | Medium-High | Yes — candidate concept promotion rule, topic source attribution | CONSOLIDATE into business.md |
| 5 | 03-approved-decisions.md | Complete approved decision register (A0-1→A9-3) | Business decisions | authoritative | Very High | Yes — all rationale statements, decision IDs | KEEP |
| 6 | 04-open-questions.md | Resolved open questions register | Business decisions | authoritative | High | Yes — resolution specificity (OQ1-1 priority, OQ4-1 no accounts, OQ6-8 trust signals), deferred items | CONSOLIDATE into business.md |
| 7 | 05-adrs.md | ADR placeholder | Architecture | draft/placeholder | None | No — empty | CONSOLIDATE into decisions.md |
| 8 | 06-business-workflows.md | Detailed workflow definitions (WF1–WF7) | Business workflows | authoritative | Very High | Yes — per-workflow rules, persona variations, triggers, preconditions, success outcomes | KEEP |
| 9 | 07-business-discovery-closure.md | Formal closure + summary of Business Discovery | Business governance | reconciliation-artifact | High for governance | Yes — 18 Discovery Principles (P1–P18), exit criteria, canonical doc inventory | ARCHIVE |
| 10 | 08-traceability-matrix.md | Traceability proof (96/96, 0 assumptions) | Business quality | review-artifact | High for QA | Yes — 7 traceability chains, cross-trace tables, unsupported assumptions audit | ARCHIVE |
| 11 | 09-business-discovery-freeze.md | Freeze regime + Change Proposal protocol | Business governance | authoritative for governance | Very High | Yes — 5 Freeze Principles, Change Proposal Protocol, NOT-frozen enumeration | ARCHIVE (governance rules consolidated) |
| 12 | 10-domain-discovery-readiness.md | Domain Discovery readiness gate | Phase transition | reconciliation-artifact | High for gate | Yes — precondition checklist, pre-seeded OQ priorities, readiness verdict | ARCHIVE |
| 13 | 11-domain-discovery-topic2.md | Original Topic 2 (entity relationships, aggregates) | Domain Discovery | partially-superseded | Medium | Yes — lifecycle state machines, temporal behaviour, identity stability, cardinality justifications | ARCHIVE (lifecycle/identity preserved by reference in 12) |
| 14 | 12-domain-discovery-topic2-revision.md | Revised Topic 2 (5 aggregate roots) | Domain Discovery | authoritative | High | Yes — Laravel Beyond CRUD philosophy, reclassification justifications, VO candidates, aggregate invariants | ARCHIVE (results in 21; reasoning unique) |
| 15 | 13-domain-discovery-consolidation.md | Pre-behaviour readiness consolidation | Domain Discovery | authoritative | Very High | Yes — 9-country expansion test, future pressure test, canonical entity/VO challenge narratives | ARCHIVE (results in 15/21; tests unique) |
| 16 | 14-architectural-review-global-domain.md | Global Domain normalization (F1–F14) | Domain Discovery | authoritative | High | Yes — 14 findings with Nigeria-specific audit trail, invariant rewording | ARCHIVE (corrections applied in 16/21; reasoning unique) |
| 17 | 15-domain-discovery-topic4-behaviour.md | Behaviour Discovery (final domain model) | Domain Discovery | authoritative | Very High | Yes — complete behavioural model, domain events, invariant assessment, Admission Pathway demotion | KEEP |
| 18 | 16-domain-discovery-topic3.md | Entity attributes & Value Objects | Domain Discovery | authoritative | High | Yes — complete attribute inventory, 25 VO definitions, DD3-1→DD3-13 | KEEP (or CONSOLIDATE into domain.md) |
| 19 | 17-domain-integrity-review.md | CDR — weakness/assumption identification | Domain Review | review-artifact | Medium-High | Yes — weaknesses W1–W5, hidden assumptions HA-1–HA-5, missing concepts MC-1–MC-3, bounded contexts | ARCHIVE |
| 20 | 18-domain-resolution-analysis.md | Resolve all 17's findings | Domain Review | superseded-in-part | High | Yes — multi-country semantic tests, per-finding reasoning, resolution register | ARCHIVE |
| 21 | 19-domain-architecture.md | Original domain architecture | Architecture | partially-superseded | Medium-High | Yes — original principle definitions, Spatie evaluation rationale, example flows, architectural risks | ARCHIVE |
| 22 | 20-domain-architecture-validation.md | Adversarial validation of 19 | Architecture | review-artifact | Medium | Yes — adversarial challenges, SMELL-1→SMELL-8, LBC alignment critique, 19-Actions recommendation | ARCHIVE |
| 23 | 21-domain-architecture-frozen-baseline.md | Canonical frozen architectural baseline | Architecture | authoritative | Very High | Yes — correction record, freeze declaration, final catalogue (F-1→F-13+), 28 VOs, 20 Actions, ADR-1→ADR-18 | KEEP |
| 24 | 22-post-freeze-platform-architecture-review.md | Platform/product architecture review | Architecture | partially-superseded | Medium | Yes — domain/app/infra/product classification, "no frozen decision reversed" guarantee, listing page architecture | ARCHIVE |
| 25 | 23-laravel-ecosystem-build-vs-buy-review.md | Laravel ecosystem build-vs-buy | Architecture | partially-superseded | Medium-High | Yes — package-by-package evaluation, build-vs-buy matrix, dependency risk, implementation sequencing, Web Push/Bulk Import specs | ARCHIVE (package decisions in 28; reasoning unique) |
| 26 | 24-final-platform-and-capability-architecture.md | Final pre-implementation architecture | Architecture | authoritative | Very High | Yes — content architecture (Option C), Samphina check, information architecture, simplicity audit, ADR register (31), READY verdict | KEEP |
| 27 | 25-pre-implementation-blueprint.md | Original implementation blueprint (Laravel 12) | Implementation | superseded | Low | Partially — original migration SQL, model code, Filament v3 resources (all historical) | ARCHIVE |
| 28 | 26-pre-implementation-reconciliation.md | Adversarial reconciliation of 25 | Implementation | partially-superseded | Medium-High for R2–R12 | Yes — adversarial reasoning, Decisions Confirmed table, LBC compliance, global expansion, remaining risks, forbidden list | ARCHIVE |
| 29 | 27-final-corrected-pre-implementation-blueprint.md | Canonical implementation blueprint (Laravel 13) | Implementation | authoritative | Highest | Yes — source of truth hierarchy, UNVERIFIED protocol, R1 override, 4-tier settings, security/privacy, media architecture | KEEP |
| 30 | 28-package-verification-audit.md | Package compatibility audit (61 packages) | Implementation | authoritative (factual) | High | Yes — individual verification records, fabricated package detection, forensic audit | KEEP (or CONSOLIDATE into implementation.md) |
| 31 | 29-rbac-decision.md | Canonical RBAC role inventory | Implementation | authoritative | High | Yes — Spatie-vs-OrgMember classification, superseded decisions table, policy check pattern | KEEP (or CONSOLIDATE into implementation.md) |
| 32 | 30-data-acquisition-pipeline.md | Data acquisition/ingestion pipeline design | Implementation | authoritative | High | Yes — entire pipeline design (unique, no other source) | KEEP |

---

## C. Duplication Analysis

### Type A — Exact Duplication

| Duplicated Content | Location A | Location B | Notes |
|--------------------|-----------|-----------|-------|
| Business overview narrative ≈ approved decisions | 01 §1–§9 | 03 A0–A9 | 01 is narrative rendering of 03's decisions. 03 has rationale; 01 has framing. |

### Type B — Historical Revision

| Earlier Version | Later Superseding Version | What Changed |
|----------------|--------------------------|-------------|
| 11 (Topic 2 original, 11 ARs) | 12 (Topic 2 revision, 5 ARs) | Aggregate boundary decisions revised |
| 19 (Domain Architecture, 27 VOs, 23 Actions) | 21 (Frozen Baseline, 28 VOs, 20 Actions) | Counts corrected, 4 must-fixes applied |
| 25 (Blueprint, Laravel 12) | 27 (Blueprint, Laravel 13) | Hard baseline upgrade, all R1–R12 applied |
| 17 (Integrity Review) | 18 (Resolution Analysis) | All 11 findings resolved |
| 18 (Resolution: Admission Pathway as entity) | 15 (Topic 4: demoted to VO) | Behaviour evidence overrides |

### Type C — Consolidatable

| Document | Target | What to Consolidate |
|----------|--------|---------------------|
| 01 (business overview) | 03 (approved decisions) | Narrative framing, capability relationships, "Critical Business Concern" |
| 02 (glossary) | 03 (approved decisions) | Candidate concept promotion rule, topic attribution |
| 04 (open questions) | 03 (approved decisions) | Resolution details, deferred items |
| 05 (ADRs placeholder) | 03 or new decisions.md | Structural placeholder for ADR recording |
| 16 (Topic 3 attributes) | 15 (Topic 4 behaviour) | Attribute inventory could append to behavioural model |
| 29 (RBAC) | 27 (implementation blueprint) | Already derived from §18; could be inline |
| 28 (package audit) | 27 (implementation blueprint) | Package verification facts could be an appendix |
| 30 (data pipeline) | 27 (implementation blueprint) | Pipeline design could be a section |

### Type D — Independent (Legitimate Standalone)

| Document | Reason |
|----------|--------|
| 03 (approved decisions) | Foundation of all downstream work; decision IDs used as traceability anchors |
| 06 (workflows) | Detailed workflow rules not reproducible from summaries |
| 15 (behaviour discovery) | Final domain model with behavioural evidence |
| 21 (frozen baseline) | Canonical frozen architecture — implementation contracts |
| 24 (final architecture) | Content architecture, information architecture, READY verdict |
| 27 (implementation blueprint) | The document to code from |

### Type E — Dangerous to Remove

| Document | Why Dangerous |
|----------|--------------|
| 09 (freeze) | Change Proposal Protocol governs all future modifications; removing it means no governance |
| 13 (consolidation) | 9-country expansion test and future pressure test exist ONLY here |
| 15 (behaviour discovery) | Complete behavioural model, domain events, invariant assessment — nowhere else |
| 27 (implementation blueprint) | The implementation baseline — nothing else has the source-of-truth hierarchy, settings architecture, or security section |
| 30 (data pipeline) | Entire pipeline design is unique — removing it means redesigning from scratch |

---

## D. Supersession Analysis

### Domain Architecture Chain

```
11 (Topic 2: 11 aggregate roots)
  ↓ partially superseded
12 (Topic 2 Revision: 5 aggregate roots)
  ↓ built upon
14 (Architectural Review: F1–F14 normalization)
  ↓ applied in
16 (Topic 3: attribute model)
  ↓ reviewed by
17 (Integrity Review: weaknesses + assumptions)
  ↓ resolved by
18 (Resolution Analysis: 11 findings resolved)
  ↓ consolidated by
13 (Consolidation: pre-behaviour readiness)
  ↓ behaviour discovery
15 (Topic 4: final behavioural model) ← AUTHORITY
```

**Authoritative result:** 15 (Topic 4) — 11 entities, 5 aggregate roots, complete behavioural model.

### Platform Architecture Chain

```
19 (Domain Architecture: original, 27 VOs, 23 Actions)
  ↓ validated by
20 (Validation: 4 must-fix, recommends 19 Actions)
  ↓ corrected by
21 (Frozen Baseline: 28 VOs, 20 Actions, FROZEN) ← AUTHORITY for domain arch
  ↓ extended by
22 (Post-Freeze Review: platform/product gaps)
  ↓ deepened by
23 (Build-vs-Buy: package evaluation)
  ↓ finalized by
24 (Final Architecture: content layer, READY verdict) ← AUTHORITY for full arch
```

**Authoritative result:** 21 (frozen domain) + 24 (final platform) — together define the complete architecture.

### Implementation Chain

```
25 (Blueprint: Laravel 12, Filament v3, 7 roles)
  ↓ reconciled by
26 (Reconciliation: R1–R12 corrections)
  ↓ corrected by
27 (Final Blueprint: Laravel 13, Filament v5, 11 roles) ← AUTHORITY
  ↓ verified by
28 (Package Audit: 61 packages verified)
```

**Authoritative result:** 27 (implementation blueprint) + 28 (package facts) + 29 (RBAC) + 30 (data pipeline).

### RBAC Chain

```
21 (7 flat roles)
  ↓ expanded by
26 (R2: 11 scoped roles)
  ↓ corrected by
27 (§18: 11 roles with OrganizationMember)
  ↓ extracted as
29 (Canonical RBAC decision) ← AUTHORITY
```

**Authoritative result:** 29 (RBAC decision) — supersedes all prior RBAC definitions.

---

## E. Conflict Report

| ID | Topic | Doc A | Doc B | Difference | Apparent Authority | Confidence | Human Decision? |
|----|-------|-------|-------|------------|-------------------|-----------|----------------|
| XF-1 | Admission Pathway classification | 18 (supporting entity) | 15 (Value Object) | 18 accepts as entity based on structural analysis; 15 demotes to VO based on behaviour evidence | 15 (behaviour evidence is the project's own methodology) | High | No — 15 wins by methodology |
| XF-2 | File numbering in authority orders | 13, 15 | Actual files | Both reference "Integrity Review (16)" and "Resolution Analysis (17)" but actual files are 17 and 18 | Editorial error | High | No — simple correction |
| XF-3 | RBAC in multiple locations | 21, 22, 23, 24, 27 | 29 | 5 documents contain RBAC definitions with varying detail; 29 is canonical | 29 (explicitly declared canonical) | High | No — 29 wins by declaration |
| XF-4 | Open question count in 07 | 07 section headers | 07 section lists | Domain Discovery header says "5" but lists 7; Product Discovery says "7" but lists 8 | Editorial error | High | No — simple correction |
| XF-5 | VO count progression | 16 (25), 18 (27), 21 (28) | — | Each document adds VOs discovered in its phase | 21 (28 VOs) is latest | High | No — latest is authoritative |
| XF-6 | Entity naming "Government Education Agency" vs "Education Authority" | 11, 12 | 14, 16, 17, 18 | Pre-review vs post-review naming | 14 (Education Authority) | High | No — 14's correction is canonical |

---

## F. Knowledge Preservation Matrix

| ID | Knowledge | Current Source | Proposed Destination | Preserved? | Conflict? |
|----|-----------|---------------|---------------------|-----------|-----------|
| K1 | 4 primary personas + priority | 01, 03, 04 | business.md | Yes | No |
| K2 | 6 secondary user groups | 01, 03 | business.md | Yes | No |
| K3 | 5 problem dimensions | 01, 03 | business.md | Yes | No |
| K4 | 4 evolution stages + MVP scope | 01, 03, 04 | business.md | Yes | No |
| K5 | 10 MVP + 5 future capabilities | 01, 03 | business.md | Yes | No |
| K6 | 7 workflows (WF1–WF7) with rules | 06 | workflows.md | Yes | No |
| K7 | Persona-workflow matrix | 06, 07 | workflows.md | Yes | No |
| K8 | 63 approved decisions (A0-1→A9-3) with rationale | 03 | decisions.md | Yes | No |
| K9 | 22 resolved open questions | 04 | decisions.md | Yes | No |
| K10 | 5 freeze principles + Change Proposal Protocol | 09 | decisions.md (governance section) | Yes | No |
| K11 | 11 entities (5 AR + 3 child + 3 supporting) | 15, 21 | domain.md | Yes | No |
| K12 | 28 Value Objects (12 genuine + 16 enums) | 21 | domain.md | Yes | No |
| K13 | Complete attribute model | 16 | domain.md | Yes | No |
| K14 | Complete behavioural model | 15 | domain.md | Yes | No |
| K15 | 29 domain events | 15 | domain.md | Yes | No |
| K16 | 20 application actions | 21 | domain.md | Yes | No |
| K17 | All invariants (22+ domain) | 15, 21 | domain.md | Yes | No |
| K18 | Admission Pathway = VO (not entity) | 15 | domain.md | Yes | XF-1 (resolved) |
| K19 | Global Domain normalization (F1–F14) | 14 | domain.md (applied corrections only) | Yes (results) | No |
| K20 | 9-country expansion test | 13 | domain.md | Yes | No |
| K21 | Future expansion pressure test | 13 | domain.md | Yes | No |
| K22 | Frozen architectural baseline | 21 | architecture.md | Yes | No |
| K23 | Content architecture (Option C, 4 models) | 24 | architecture.md | Yes | No |
| K24 | Information architecture | 24 | architecture.md | Yes | No |
| K25 | Search architecture (Typesense) | 22, 24 | architecture.md | Yes | No |
| K26 | SEO architecture | 22, 24 | architecture.md | Yes | No |
| K27 | TALL stack + Filament admin | 21, 24, 27 | architecture.md | Yes | No |
| K28 | 31 ADRs | 21, 22, 23, 24 | architecture.md (ADR register) | Yes | No |
| K29 | Laravel 13 + PHP 8.5 baseline | 27 | implementation.md | Yes | No |
| K30 | Filament v5 + Livewire v4 | 27 | implementation.md | Yes | No |
| K31 | 11-role RBAC with OrganizationMember | 29 | implementation.md | Yes | XF-3 (resolved) |
| K32 | 54 tables, migration ordering | 27 | implementation.md | Yes | No |
| K33 | 4-tier settings architecture | 27 | implementation.md | Yes | No |
| K34 | Source of truth hierarchy | 27 | implementation.md | Yes | No |
| K35 | 61 package verification records | 28 | implementation.md (appendix) | Yes | No |
| K36 | Data acquisition pipeline design | 30 | data-acquisition.md | Yes | No |
| K37 | 18 Discovery Principles (P1–P18) | 07 | decisions.md (or archive) | Yes | No |
| K38 | Traceability chains (7) + 96/96 proof | 08 | archive (quality evidence) | Yes (in archive) | No |
| K39 | Anti-patterns and forbidden list | 25, 26, 27 | implementation.md | Yes | No |
| K40 | Security and privacy architecture | 27 | implementation.md | Yes | No |
| K41 | Media architecture | 27 | implementation.md | Yes | No |
| K42 | Programme discovery URL architecture | 26, 27 | implementation.md | Yes | No |
| K43 | Study abroad architecture | 24, 27 | architecture.md | Yes | No |
| K44 | Community module architecture | 23, 27 | architecture.md | Yes | No |
| K45 | Notification architecture | 22, 24, 27 | architecture.md | Yes | No |

---

## G. Proposed Canonical Structure

```
docs/
├── 01-business.md
├── 02-decisions.md
├── 03-workflows.md
├── 04-domain.md
├── 05-architecture.md
├── 06-implementation.md
├── 07-data-acquisition.md
└── archive/
    ├── 00-conflict-register.md
    ├── 00-updated-audit-report.md
    ├── 07-business-discovery-closure.md
    ├── 08-traceability-matrix.md
    ├── 09-business-discovery-freeze.md
    ├── 10-domain-discovery-readiness.md
    ├── 11-domain-discovery-topic2.md
    ├── 12-domain-discovery-topic2-revision.md
    ├── 13-domain-discovery-consolidation.md
    ├── 14-architectural-review-global-domain.md
    ├── 17-domain-integrity-review.md
    ├── 18-domain-resolution-analysis.md
    ├── 19-domain-architecture.md
    ├── 20-domain-architecture-validation.md
    ├── 22-post-freeze-platform-architecture-review.md
    ├── 23-laravel-ecosystem-build-vs-buy-review.md
    ├── 25-pre-implementation-blueprint.md
    └── 26-pre-implementation-reconciliation.md
```

### Justification for Each Canonical Document

**01-business.md**
- **Purpose:** Single-entry business context — vision, personas, problem space, capabilities, glossary
- **Contents:** From 01 (narrative framing, capability relationships, "Critical Business Concern"), 02 (glossary with promotion rule), 04 (resolution details for deferred items)
- **Source documents:** 01, 02, 04
- **Why independent:** Business context is the foundation; everyone needs it first. Separating it from decisions makes both more scannable.
- **What NOT inside:** Detailed decision rationale (that's 02-decisions.md), workflow rules (that's 03-workflows.md)

**02-decisions.md**
- **Purpose:** Complete decision register — approved decisions, resolved open questions, governance rules, ADRs
- **Contents:** From 03 (all A0-1→A9-3 with rationale), 04 (resolution details, deferred items), 05 (ADR placeholder), 09 (freeze principles F1–F5, Change Proposal Protocol, NOT-frozen enumeration), 07 (18 Discovery Principles P1–P18)
- **Source documents:** 03, 04, 05, 07, 09
- **Why independent:** Decisions are the single most referenced document. Separating them from narrative business context and from domain/architecture decisions makes them the definitive "what did we decide and why" reference.
- **What NOT inside:** Domain architecture decisions (in 04-domain.md), platform architecture decisions (in 05-architecture.md), implementation specifics (in 06-implementation.md)

**03-workflows.md**
- **Purpose:** Detailed workflow definitions
- **Contents:** From 06 (all WF1–WF7 with rules, persona variations, triggers, preconditions, success outcomes, steps)
- **Source documents:** 06
- **Why independent:** Workflow rules are the bridge between business intent and domain behaviour. They're referenced by domain actions and UI design. Too specific to merge into business overview.
- **What NOT inside:** Capability definitions (in 01-business.md), domain actions (in 04-domain.md)

**04-domain.md**
- **Purpose:** Complete domain model — entities, attributes, behaviours, events, invariants, VOs
- **Contents:** From 15 (behavioural model, domain events, invariant assessment, Admission Pathway as VO), 16 (attribute inventory, VO definitions, DD3-1→DD3-13), 21 (frozen baseline aggregates, 28 VOs, 20 Actions, invariants)
- **Source documents:** 15, 16, 21 (domain sections)
- **Why independent:** The domain model is the most complex artifact. It's the primary input for implementation. Merging it with architecture would create an unmanageable document.
- **What NOT inside:** Platform/architecture decisions (in 05), implementation specifics (in 06), historical discovery reasoning (in archive)

**05-architecture.md**
- **Purpose:** Complete platform and capability architecture
- **Contents:** From 21 (frozen baseline architectural catalogue, Eloquent strategy, directory structure), 24 (content architecture, information architecture, Samphina check, simplicity audit, ADR register, READY verdict), 22 (search/SEO/notification architecture details), 23 (community module, Web Push/Bulk Import)
- **Source documents:** 21, 22, 23, 24
- **Why independent:** Architecture is the translation layer between domain and implementation. It contains the "how" that bridges "what" (domain) and "do" (implementation).
- **What NOT inside:** Domain model details (in 04), implementation code (in 06), package-by-package evaluation details (in archive)

**06-implementation.md**
- **Purpose:** The implementation blueprint — what to code, in what order, with what constraints
- **Contents:** From 27 (source of truth hierarchy, Laravel 13 baseline, Filament v5, RBAC, settings, security, media, implementation phases, forbidden list), 29 (RBAC role inventory, policy check pattern, superseded decisions), 28 (package verification records as appendix)
- **Source documents:** 27, 28, 29
- **Why independent:** This is the document developers and AI agents code from. It must be self-contained and unambiguous.
- **What NOT inside:** Architecture rationale (in 05), domain model (in 04), historical reasoning (in archive)

**07-data-acquisition.md**
- **Purpose:** Data acquisition and ingestion pipeline design
- **Contents:** From 30 (entire pipeline: source taxonomy, staging schema, adapter pattern, verification engine, provenance model, scheduled jobs, admin UI)
- **Source documents:** 30
- **Why independent:** Data acquisition is the most business-critical capability with the least overlap with other concerns. It defines its own tables, adapters, and jobs that don't fit naturally into any other document.
- **What NOT inside:** Domain model details (in 04), package lists (in 06 appendix)

---

## H. Migration Matrix

| Current File | Proposed Destination | Action | Reason | Risk |
|-------------|---------------------|--------|--------|------|
| 00-conflict-register.md | archive/ | ARCHIVE | Reconciliation artifact — valuable for audit trail but not needed for daily work | Low — audit trail preserved |
| 00-updated-audit-report.md | archive/ | ARCHIVE | Reconciliation artifact — canonical set and baseline now captured in canonical docs | Low — audit trail preserved |
| 01-business-overview.md | 01-business.md | CONSOLIDATE | Narrative framing and capability relationships merge into business doc | Low — content preserved |
| 02-glossary.md | 01-business.md | CONSOLIDATE | Glossary merges as section of business doc | Low — content preserved |
| 03-approved-decisions.md | 02-decisions.md | CONSOLIDATE | Core of decisions doc; absorbs 04, 05, parts of 07, 09 | Low — content preserved |
| 04-open-questions.md | 02-decisions.md | CONSOLIDATE | Resolutions and deferred items merge into decisions doc | Low — content preserved |
| 05-adrs.md | 02-decisions.md | CONSOLIDATE | ADR placeholder merges into decisions doc | None — empty file |
| 06-business-workflows.md | 03-workflows.md | KEEP | Renamed only | None |
| 07-business-discovery-closure.md | archive/ | ARCHIVE | Governance summary — principles and exit criteria are historical; Discovery Principles P1–P18 consolidated into 02-decisions.md | Low — principles preserved in decisions doc |
| 08-traceability-matrix.md | archive/ | ARCHIVE | QA proof — valuable but not needed for daily work | Low — traceability preserved in archive |
| 09-business-discovery-freeze.md | archive/ | ARCHIVE | Governance rules — F1–F5 and Change Proposal Protocol consolidated into 02-decisions.md | Low — governance rules preserved in decisions doc |
| 10-domain-discovery-readiness.md | archive/ | ARCHIVE | Phase transition gate — historical | Low — readiness verdict was YES, phase completed |
| 11-domain-discovery-topic2.md | archive/ | ARCHIVE | Partially superseded by 12; lifecycle/identity content preserved by reference | Low — 12 explicitly preserves these sections |
| 12-domain-discovery-topic2-revision.md | archive/ | ARCHIVE | Results in 21; reasoning (LBC philosophy, reclassification justifications) unique to archive | Low — results carried forward; reasoning accessible |
| 13-domain-discovery-consolidation.md | archive/ | ARCHIVE | Results in 15/21; 9-country test and future pressure test consolidated into 04-domain.md | Low — unique content preserved in archive and key results in domain doc |
| 14-architectural-review-global-domain.md | archive/ | ARCHIVE | Corrections applied in 16/21; reasoning trail (F1–F14) unique to archive | Low — corrections applied; reasoning accessible |
| 15-domain-discovery-topic4-behaviour.md | 04-domain.md | CONSOLIDATE | Core of domain doc (behavioural model, events, invariants) | Low — content preserved |
| 16-domain-discovery-topic3.md | 04-domain.md | CONSOLIDATE | Attribute model merges into domain doc | Low — content preserved |
| 17-domain-integrity-review.md | archive/ | ARCHIVE | Review artifact — weaknesses and assumptions resolved by 18 | Low — diagnostic reasoning preserved in archive |
| 18-domain-resolution-analysis.md | archive/ | ARCHIVE | Mostly superseded by 15 (Admission Pathway); other resolutions applied | Low — resolution reasoning preserved in archive |
| 19-domain-architecture.md | archive/ | ARCHIVE | Partially superseded by 21; original rationale and flows unique | Low — counts historical; reasoning accessible |
| 20-domain-architecture-validation.md | archive/ | ARCHIVE | Review artifact — corrections applied in 21 | Low — adversarial reasoning preserved in archive |
| 21-domain-architecture-frozen-baseline.md | 04-domain.md + 05-architecture.md | CONSOLIDATE | Domain sections → 04; architectural catalogue and Eloquent strategy → 05 | Low — content split logically |
| 22-post-freeze-platform-architecture-review.md | archive/ | ARCHIVE | Partially superseded by 24; search/SEO details consolidated into 05 | Low — unique classification and guarantee preserved in archive |
| 23-laravel-ecosystem-build-vs-buy-review.md | archive/ | ARCHIVE | Package decisions in 28; community/WebPush/BulkImport consolidated into 05 | Low — evaluation reasoning preserved in archive |
| 24-final-platform-and-capability-architecture.md | 05-architecture.md | CONSOLIDATE | Core of architecture doc | Low — content preserved |
| 25-pre-implementation-blueprint.md | archive/ | ARCHIVE | Fully superseded by 27; original code samples historical | Low — all versions superseded |
| 26-pre-implementation-reconciliation.md | archive/ | ARCHIVE | Corrections R2–R12 applied in 27; adversarial reasoning unique | Low — reasoning preserved in archive |
| 27-final-corrected-pre-implementation-blueprint.md | 06-implementation.md | CONSOLIDATE | Core of implementation doc | Low — content preserved |
| 28-package-verification-audit.md | 06-implementation.md (appendix) | CONSOLIDATE | Package facts become appendix of implementation doc | Low — content preserved |
| 29-rbac-decision.md | 06-implementation.md (section) | CONSOLIDATE | RBAC becomes section of implementation doc | Low — content preserved |
| 30-data-acquisition-pipeline.md | 07-data-acquisition.md | KEEP | Renamed only | None |

---

## I. Risks

| Risk | Severity | Description | Mitigation |
|------|----------|-------------|-----------|
| R1 | **HIGH** | Governance rules (F1–F5, Change Proposal Protocol) could become invisible if buried in decisions.md | Make governance a clearly delimited section with its own heading level in 02-decisions.md; add cross-reference from 04-domain.md and 05-architecture.md |
| R2 | **MEDIUM** | 9-country expansion test (file 13) and future pressure test are unique and not in any canonical document | Consolidate key findings (summary table) into 04-domain.md; full test remains in archive |
| R3 | **MEDIUM** | Traceability chains (file 08) are the QA proof for Business Discovery; removing from active docs means they're not immediately visible | Archive but reference from 02-decisions.md governance section |
| R4 | **MEDIUM** | Architectural review reasoning (F1–F14 in file 14) documents WHY Nigeria-specific items were corrected; without it, future developers may not understand the Global Domain design | Summary of corrections in 04-domain.md; full reasoning in archive |
| R5 | **LOW** | File 25's original migration SQL and model code is historical (Laravel 12, Filament v3) but shows the progression; losing it means losing concrete implementation history | Archive — historical code is not implementable |
| R6 | **LOW** | Admission Pathway classification conflict (entity vs VO) is resolved but the reasoning is split across files 17, 18, and 15 | Resolution noted in 04-domain.md; full reasoning in archive |
| R7 | **LOW** | Consolidating 21 into 04 + 05 requires careful section mapping to avoid losing the freeze declaration | Freeze declaration preserved as explicit section in 04-domain.md |

### Unsafe to Prune

**No document is unsafe to prune** provided:
1. All ARCHIVE documents remain accessible (not deleted)
2. The 7 canonical documents are created correctly with all consolidated content
3. Governance rules (F1–F5, Change Proposal Protocol) are explicitly included in 02-decisions.md
4. The 9-country expansion test summary is included in 04-domain.md
5. The freeze declaration is preserved in 04-domain.md

---

## J. Recommended Pruning Plan

### Phase 1: Create Canonical Documents (7 new files)

1. **Create 01-business.md** — Consolidate from 01, 02, 04
2. **Create 02-decisions.md** — Consolidate from 03, 04, 05, 07 (P1–P18), 09 (F1–F5, Change Proposal Protocol)
3. **Create 03-workflows.md** — Rename from 06 (no content change)
4. **Create 04-domain.md** — Consolidate from 15, 16, 21 (domain sections), 13 (expansion test summary)
5. **Create 05-architecture.md** — Consolidate from 21 (architecture sections), 22, 23, 24
6. **Create 06-implementation.md** — Consolidate from 27, 28 (appendix), 29 (section)
7. **Create 07-data-acquisition.md** — Rename from 30 (no content change)

### Phase 2: Archive Historical Documents (16 files)

Move to `archive/` directory:
- 00-conflict-register.md
- 00-updated-audit-report.md
- 07-business-discovery-closure.md
- 08-traceability-matrix.md
- 09-business-discovery-freeze.md
- 10-domain-discovery-readiness.md
- 11-domain-discovery-topic2.md
- 12-domain-discovery-topic2-revision.md
- 13-domain-discovery-consolidation.md
- 14-architectural-review-global-domain.md
- 17-domain-integrity-review.md
- 18-domain-resolution-analysis.md
- 19-domain-architecture.md
- 20-domain-architecture-validation.md
- 22-post-freeze-platform-architecture-review.md
- 23-laravel-ecosystem-build-vs-buy-review.md
- 25-pre-implementation-blueprint.md
- 26-pre-implementation-reconciliation.md

### Phase 3: Verify and Clean Up

1. Verify all 45 knowledge items (K1–K45) are present in canonical documents
2. Verify all 6 conflicts (XF-1–XF-6) are resolved or flagged
3. Fix file numbering errors in authority orders (XF-2, XF-4)
4. Update the reconciled archive zip

---

## AI-Agent Safety Evaluation

### Current Risks for AI Agents

| Risk | Description | Severity |
|------|-------------|----------|
| Conflicting RBAC definitions | 5 documents define RBAC differently; an agent might implement from any of them | **HIGH** |
| Historical version numbers | Files 25–26 contain Laravel 12/Filament v3 commands that look implementable but are wrong | **HIGH** |
| Admission Pathway ambiguity | Files 17–18 say "entity", file 15 says "VO"; agent might implement the wrong classification | **HIGH** |
| Multiple "final" documents | Files 21, 24, 27 all claim finality for different scopes; agent might confuse which is authoritative | **MEDIUM** |
| Off-by-one numbering | File references in 13, 15, 20, 22, 23 are off by one; agent following references will read wrong files | **MEDIUM** |
| 28 vs 32 document confusion | Original scope was 28 documents; archive now has 32; agent might miss the 4 new ones | **LOW** |

### How Proposed Structure Reduces These Risks

| Risk | Reduction |
|------|-----------|
| Conflicting RBAC | **Eliminated** — single section in 06-implementation.md |
| Historical versions | **Eliminated** — historical docs in archive/; canonical docs use Laravel 13/Filament v5 only |
| Admission Pathway | **Eliminated** — 04-domain.md states single authoritative classification (VO) |
| Multiple "final" docs | **Eliminated** — each canonical doc is clearly scoped; no competing "final" versions |
| Off-by-one numbering | **Eliminated** — canonical docs don't use sequential file references |
| Document count confusion | **Eliminated** — 7 canonical docs + archive/ is unambiguous |

---

## Authority Rules (Proposed Hierarchy)

```text
02-decisions.md (approved decisions + freeze principles)
        ↓
04-domain.md (frozen domain model)
        ↓
05-architecture.md (frozen architecture)
        ↓
06-implementation.md (implementation blueprint)
        ↓
07-data-acquisition.md (pipeline design)
        ↓
01-business.md (business context)
        ↓
03-workflows.md (workflow details)
        ↓
archive/ (historical — never authoritative)
```

**Rule:** When documents conflict, the higher document wins. Business context (01) and workflows (03) define intent but cannot override architectural or implementation decisions. Decisions (02) can override everything below via the Change Proposal Protocol.

---

# APPROVAL REQUIRED

## PROPOSED CHANGES

**Keep (rename only):**
- 06-business-workflows.md → 03-workflows.md
- 30-data-acquisition-pipeline.md → 07-data-acquisition.md

**Consolidate into new canonical documents:**
- 01 + 02 + 04 → **01-business.md**
- 03 + 04 + 05 + 07(P1–P18) + 09(F1–F5, Change Proposal) → **02-decisions.md**
- 15 + 16 + 21(domain) + 13(expansion summary) → **04-domain.md**
- 21(architecture) + 22 + 23 + 24 → **05-architecture.md**
- 27 + 28(appendix) + 29(section) → **06-implementation.md**

**Archive (move to archive/ directory, do NOT delete):**
- 00-conflict-register.md
- 00-updated-audit-report.md
- 07-business-discovery-closure.md
- 08-traceability-matrix.md
- 09-business-discovery-freeze.md
- 10-domain-discovery-readiness.md
- 11-domain-discovery-topic2.md
- 12-domain-discovery-topic2-revision.md
- 13-domain-discovery-consolidation.md
- 14-architectural-review-global-domain.md
- 17-domain-integrity-review.md
- 18-domain-resolution-analysis.md
- 19-domain-architecture.md
- 20-domain-architecture-validation.md
- 22-post-freeze-platform-architecture-review.md
- 23-laravel-ecosystem-build-vs-buy-review.md
- 25-pre-implementation-blueprint.md
- 26-pre-implementation-reconciliation.md

**Delete:**
- (none — all archived, none deleted)

**Create:**
- 01-business.md (new consolidated)
- 02-decisions.md (new consolidated)
- 04-domain.md (new consolidated)
- 05-architecture.md (new consolidated)
- 06-implementation.md (new consolidated)

**Result:** 7 canonical documents + 18 archived documents = 25 files (down from 32)

---

**DO NOT PROCEED WITH ANY FILE MODIFICATIONS UNTIL EXPLICIT APPROVAL IS RECEIVED.**
