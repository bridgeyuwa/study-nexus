# Document 29: RBAC Decision — Authoritative Role List

**Date:** 2026-08-08
**Authority:** Derived from Document 26 (file 26), Change R2 + §10
**Status:** Canonical — this document supersedes all prior RBAC role references

---

## 1. Role Inventory

| # | Role Name | Scope | Spatie Permission? | Key Permissions / Purpose |
|---|-----------|-------|:------------------:|---------------------------|
| 1 | `platform-admin` | Platform (global) | ✅ | All permissions. Full system access. |
| 2 | `platform-moderator` | Platform (global) | ✅ | Verify sources, moderate content, review community posts, handle reports. |
| 3 | `content-admin` | Platform (global) | ✅ | CRUD all domain entities + content types. Publish/unpublish. |
| 4 | `content-editor` | Platform (global) | ✅ | Create/edit/publish content. Cannot delete or manage domain entities. |
| 5 | `institution-owner` | Institution-scoped | ❌ (OrganizationMember) | Full control of institution + manage members + transfer ownership. |
| 6 | `institution-admin` | Institution-scoped | ❌ (OrganizationMember) | Manage institution data, programmes, admissions, scholarships. Cannot transfer ownership. |
| 7 | `institution-admissions` | Institution-scoped | ❌ (OrganizationMember) | Manage admission policies, cycles, deadlines. Read-only on other areas. |
| 8 | `institution-editor` | Institution-scoped | ❌ (OrganizationMember) | Edit descriptions, media, programme details. No status changes or admissions. |
| 9 | `institution-viewer` | Institution-scoped | ❌ (OrganizationMember) | View internal data and reports. No write access. |
| 10 | `registered-user` | User-level | ✅ | Save, follow, like, compare, community participation (post, answer, vote). |
| 11 | `guest` | User-level | ✅ | Browse only. No write access. |

**Total: 11 roles** (4 platform-global + 5 institution-scoped + 2 user-level)

---

## 2. Mechanism

| Layer | Mechanism | Storage | Package |
|-------|-----------|---------|---------|
| Global platform roles | Spatie Permission | `model_has_roles`, `model_has_permissions` | `spatie/laravel-permission` |
| Institution-scoped roles | OrganizationMember pivot | `organization_members.role` (string column) | Custom |
| Admin panel resource auth | Filament Shield | Auto-generated policies | `bezhansalleh/filament-shield` |
| API token auth | Laravel Sanctum | `personal_access_tokens` | `laravel/sanctum` |
| Object-level checks | Laravel Policies | Policy classes | First-party |

---

## 3. OrganizationMember Pivot Model

```php
class OrganizationMember extends Pivot
{
    // organization_members table columns:
    // - organization_type (morph: 'App\Domain\Institutions\Institution')
    // - organization_id
    // - user_id
    // - role (string: 'owner', 'admin', 'admissions', 'editor', 'viewer')
    // - created_at, updated_at
    
    // Key invariant: same user can be owner of Institution A 
    // and viewer of Institution B. Roles are scoped to the organization.
}
```

**Critical:** `organization_members.role` is a **string** column, NOT a FK to the Spatie `roles` table. This is per Document 26, Rec 8. Organization-scoped roles are a separate concept from global Spatie roles.

---

## 4. Policy Check Pattern

```php
// Example: Can user edit this institution's programmes?
public function updateProgramme(User $user, Institution $institution): bool
{
    return $user->hasRole('platform-admin') 
        || $user->hasRole('content-admin')
        || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
}
```

---

## 5. Superseded Decisions

| Prior Decision | Document | Superseded By | Reason |
|---------------|----------|--------------|--------|
| 7 flat roles | File 21 (frozen baseline) | This document (C5) | Cannot express multi-admin-per-institution |
| `super-admin` role name | File 23 §6 summary table | This document (C5) | Canonical name is `platform-admin` |
| `organization_members.role_id` FK | File 23 §6 code sample | This document (C5) + Doc 26 Rec 8 | Org-scoped role is a string concept, not FK to Spatie roles |

---

*This document resolves C5. No new roles or authorization behavior were invented during reconciliation.*
