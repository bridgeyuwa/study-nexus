# StudyNexus — Business Traceability Matrix

**Date:** 2026-08-07
**Purpose:** Every major artifact produced during Business Discovery is traced back to approved decisions. Any artifact that cannot be fully traced is explicitly identified as an unsupported assumption.

---

## Traceability Chains

### 1. Identity → Primary Users

| Derived Artifact | Tracing Decision(s) | Trace Status |
|-----------------|---------------------|--------------|
| StudyNexus is a comprehensive education knowledge platform | A0-1 | ✅ Fully traced |
| Vision: become the education infrastructure for Africa | A0-2 | ✅ Fully traced |
| Core interaction: search, discover, compare, verify | A0-3 | ✅ Fully traced |
| 4 primary user personas defined | A1-1 | ✅ Fully traced |
| All 4 are primary (mission-fulfilling) but not equal priority | A1-2 | ✅ Fully traced |
| Current behavior is fragmented, multi-source | A1-3 | ✅ Fully traced |
| StudyNexus replaces fragmented discovery | A1-4 | ✅ Fully traced |
| Persona priority ranking is deferred | A1-2, OQ1-1 | ✅ Fully traced (explicitly deferred) |

**Chain integrity:** Complete. Every primary user definition traces directly to Topic 0 (Identity) and Topic 1 (Primary Users) approved decisions.

---

### 2. Primary Users → Problem Space

| Derived Artifact | Tracing Decision(s) | Trace Status |
|-----------------|---------------------|--------------|
| Fragmentation pain: no trusted complete view | A3-1 | ✅ Fully traced |
| Trust pain: cannot assess reliability | A3-2 | ✅ Fully traced |
| Discoverability pain: requires known-target search | A3-3 | ✅ Fully traced |
| Comparison pain: no standardized information | A3-4 | ✅ Fully traced |
| Accessibility pain: information exists but inaccessible | A3-5 | ✅ Fully traced |
| Structured exploration concept | A3-6 | ✅ Fully traced |
| 4 information categories (Official, Verified, Historical, Community-Contributed) | A3-7 | ✅ Fully traced |
| Alternative admission pathways | A3-8 | ✅ Fully traced |
| Whether these 5 dimensions are complete | OQ3-1 | ✅ Fully traced (explicitly open) |

**Chain integrity:** Complete. Each problem dimension is a direct approved decision (A3-1 through A3-5). The completeness of the set is an open question, not an assumption.

---

### 3. Problem Space → Business Capabilities

| Derived Artifact | Tracing Decision(s) | Trace Status |
|-----------------|---------------------|--------------|
| 8 Core MVP capabilities | A5-1 | ✅ Fully traced |
| 2 Supporting MVP capabilities | A5-1 | ✅ Fully traced |
| 5 Future capabilities | A5-2 | ✅ Fully traced |
| Capability relationships (not execution order) | A5-3 | ✅ Fully traced |
| Compare, Search, Discover depend on Organized Knowledge | A5-4 | ✅ Fully traced |
| Present consumes outputs from Search, Discover, Compare | A5-4 | ✅ Fully traced |
| Verify improves Information Quality | A5-5 | ✅ Fully traced |
| Verify and Maintain are independent | A5-6 | ✅ Fully traced |
| Linking to authoritative sources is part of Present | A5-7 | ✅ Fully traced |
| Save/Share/Export/Print are product features, not capability | A5-8 | ✅ Fully traced |
| Whether 10 MVP capabilities are complete | OQ5-1 | ✅ Fully traced (explicitly open) |

**Capability-to-Problem trace:**

| Capability | Problem Dimension Addressed | Tracing |
|-----------|---------------------------|---------|
| Acquire Educational Information | Fragmentation (A3-1) | ✅ |
| Organize Educational Knowledge | Fragmentation (A3-1), Comparison (A3-4) | ✅ |
| Verify Educational Information | Trust (A3-2) | ✅ |
| Maintain Educational Knowledge | Trust (A3-2) | ✅ |
| Discover Educational Opportunities | Discoverability (A3-3) | ✅ |
| Search Educational Knowledge | Fragmentation (A3-1), Accessibility (A3-5) | ✅ |
| Compare Educational Opportunities | Comparison (A3-4) | ✅ |
| Present Educational Knowledge | Accessibility (A3-5), all dimensions | ✅ |
| Preserve Information Provenance | Trust (A3-2) | ✅ |
| Manage Information Quality | Trust (A3-2) | ✅ |

**Chain integrity:** Complete. Every capability traces to at least one approved problem dimension. Every capability definition traces to A5-1 or A5-2.

---

### 4. Business Capabilities → Business Workflows

| Derived Artifact | Tracing Decision(s) | Trace Status |
|-----------------|---------------------|--------------|
| WF1: Explore Educational Opportunities | A6-1 (Secondary Student), A7-1 (Undergraduate), A8-3 (Parent), A9-1 (Counsellor) | ✅ Fully traced |
| WF2: Evaluate Educational Opportunities | A6-1, A7-1, A8-3, A9-1 | ✅ Fully traced |
| WF3: Compare Educational Opportunities | A6-1, A7-1, A8-3, A9-1 | ✅ Fully traced |
| WF4: Assess Eligibility | A6-1, A7-1, A8-3, A9-1 | ✅ Fully traced |
| WF5: Assess Information Reliability | A6-1, A7-1, A8-3, A9-1 | ✅ Fully traced |
| WF6: Make an Educational Decision | A6-1, A7-1, A8-3, A9-1 | ✅ Fully traced |
| WF7: Understand Current Educational Journey | A7-1, A7-2, A7-3, A7-4 | ✅ Fully traced |
| WF1–WF6 are canonical (domain-defined) | A8-1 | ✅ Fully traced |
| WF7 is persona-specific | A8-2 | ✅ Fully traced |
| Parent exercises WF1–WF6 (no persona-specific workflow) | A8-3 | ✅ Fully traced |
| Counsellor exercises WF1–WF6 (no persona-specific workflow) | A9-1 | ✅ Fully traced |
| Workflows defined by business goals, not activities | A6-2 | ✅ Fully traced |
| Variations stay within workflow unless fundamentally different goal | A6-3 | ✅ Fully traced |

**Workflow-to-Capability trace:**

| Workflow | Capabilities Exercised | Tracing |
|----------|----------------------|---------|
| WF1 | Discover, Search, Present | ✅ A5-1, A5-4 |
| WF2 | Search, Present | ✅ A5-1 |
| WF3 | Compare, Present | ✅ A5-1, A5-4 |
| WF4 | Search, Present | ✅ A5-1 |
| WF5 | Verify, Present, Preserve Provenance | ✅ A5-1, A5-5 |
| WF6 | Present | ✅ A5-1 |
| WF7 | Search, Present, Maintain | ✅ A5-1, A5-6 |

**Chain integrity:** Complete. Every workflow traces to approved persona-evaluation decisions and exercises only approved capabilities.

---

### 5. Business Workflows → Candidate Business Concepts

| Derived Artifact | Introduced In | Tracing Decision(s) | Trace Status |
|-----------------|--------------|---------------------|--------------|
| Structured Exploration | WF1, Topic 3 | A3-6 | ✅ Fully traced (canonical, not candidate) |
| Comparison Dimension | WF3 | A6-1, A6-6 | ✅ Fully traced (candidate per A6-10) |
| Eligibility Status | WF4 | A6-1, A6-7 | ✅ Fully traced (candidate per A6-10) |
| Trust Signal | WF5 | A6-1, A6-8 | ✅ Fully traced (candidate per A6-10) |
| Educational Decision | WF6 | A6-1, A6-9 | ✅ Fully traced (candidate per A6-10) |
| Current Educational Journey | WF7 | A7-1, A7-2 | ✅ Fully traced (candidate per A6-10) |
| Standardized Information | WF3, Topic 3 | A3-4 | ✅ Fully traced (canonical glossary term) |
| Information Category | Topic 3 | A3-7 | ✅ Fully traced (canonical glossary term) |

**Promotion status:** 4 candidates (Comparison Dimension, Eligibility Status, Trust Signal, Educational Decision) are eligible for promotion but remain candidate per A6-10 until explicitly approved (OQ7-3). Current Educational Journey recurs in only 1 persona — not yet eligible.

**Chain integrity:** Complete. Every concept traces to the workflow that introduced it, which traces to approved decisions.

---

### 6. Evolution → Future Capabilities

| Derived Artifact | Tracing Decision(s) | Trace Status |
|-----------------|---------------------|--------------|
| 4-stage business evolution | A4-1 | ✅ Fully traced |
| MVP = Stage 1 | A4-2 | ✅ Fully traced |
| MVP exclusions | A4-3 | ✅ Fully traced |
| Geographic expansion only after Nigeria matures | A4-4 | ✅ Fully traced |
| Stage 3 trust/provenance concern | A4-5 | ✅ Fully traced |
| International expansion anticipated | A4-6 | ✅ Fully traced |
| Information quality is core concern | A4-7 | ✅ Fully traced |
| Decision support belongs in Capability Discovery | A4-8 | ✅ Fully traced |
| Business/revenue model deferred | A4-9 | ✅ Fully traced |
| Personalize guidance (Stage 2) | A5-2 | ✅ Fully traced |
| Support verified org participation (Stage 3) | A5-2 | ✅ Fully traced |
| Notify users (Stage 2) | A5-2 | ✅ Fully traced |
| Provide data to third parties (Stage 4) | A5-2 | ✅ Fully traced |
| Enable ecosystem collaboration (Stage 3/4) | A5-2 | ✅ Fully traced |

**Chain integrity:** Complete. Every future capability traces to A5-2. Every evolution principle traces to A4-1 through A4-9.

---

### 7. Approved Decisions → Glossary Terms

| Glossary Term | Tracing Decision(s) | Trace Status |
|--------------|---------------------|--------------|
| StudyNexus | A0-1 | ✅ Fully traced |
| Aggregate, Verify, Organize | A0-1 | ✅ Fully traced |
| Searchable, Comparable, Trustworthy | A0-1 | ✅ Fully traced |
| Primary User | A1-1 | ✅ Fully traced |
| Secondary School Student and Graduate | A1-1 | ✅ Fully traced |
| Undergraduate Student | A1-1 | ✅ Fully traced |
| Parent or Guardian | A1-1 | ✅ Fully traced |
| Guidance Counsellor / Teacher | A1-1 | ✅ Fully traced |
| JAMB | A1-5 | ✅ Fully traced |
| WAEC | A1-6 | ✅ Fully traced |
| Cut-off Mark | A1-1 (domain term confirmed in Topic 1) | ✅ Fully traced |
| Programme | A1-1 (domain term confirmed in Topic 1) | ✅ Fully traced |
| Secondary User | A2-1 | ✅ Fully traced |
| Educational Institution | A2-1 | ✅ Fully traced |
| Scholarship Provider | A2-1 | ✅ Fully traced |
| Government Education Agency | A2-1 | ✅ Fully traced |
| Strategic Partner | A2-5 | ✅ Fully traced |
| NECO, NABTEB, NUC, NBTE, NCCE | A2-8 | ✅ Fully traced |
| Innovation Enterprise Institution (IEI) | A2-9 | ✅ Fully traced |
| Structured Exploration | A3-6 | ✅ Fully traced |
| Information Category | A3-7 | ✅ Fully traced |
| Alternative Admission Pathway | A3-8 | ✅ Fully traced |
| Standardized Information | A3-4 | ✅ Fully traced |
| Accessibility | A3-5 | ✅ Fully traced |
| IJMB, JUPEB, Direct Entry | A3-8 | ✅ Fully traced |
| MVP | A4-2 | ✅ Fully traced |
| Stage 1–4 | A4-1 | ✅ Fully traced |
| Provenance | A4-5 | ✅ Fully traced |
| Business Capability, Core/Supporting/Future Capability | A5-1, A5-2 | ✅ Fully traced |
| Capability Relationship | A5-3 | ✅ Fully traced |
| Business Workflow | A6-2 | ✅ Fully traced |
| Canonical Workflow | A8-1 | ✅ Fully traced |
| Persona-Specific Workflow | A8-2 | ✅ Fully traced |

**Chain integrity:** Complete. Every glossary term traces to at least one approved decision.

---

## Unsupported Assumptions Audit

| Artifact | Potential Assumption | Audit Result |
|----------|---------------------|--------------|
| Persona priority ranking | Assumes personas can be ranked | Not assumed — explicitly deferred (A1-2, OQ1-1) |
| Completeness of problem dimensions | Assumes 5 dimensions are sufficient | Not assumed — explicitly open (OQ3-1) |
| Completeness of MVP capabilities | Assumes 10 capabilities are sufficient | Not assumed — explicitly open (OQ5-1) |
| Government agency data source | Assumes public sources by default | Not assumed — explicitly stated as default with partnership override (A2-11) |
| Candidate concept promotion | Assumes 4 concepts should be promoted | Not assumed — requires explicit approval per A6-10 (OQ7-3) |
| WF7 applicability beyond Undergrad | Assumes WF7 may apply to others | Not assumed — explicitly open (OQ7-2) |
| Business model/revenue model | Assumes model exists | Not assumed — explicitly deferred (A4-9, OQ4-4) |
| User accounts in MVP | Assumes accounts may be needed | Not assumed — explicitly open (OQ4-1) |
| Foreign institutions on day one | Assumes scope is Nigeria only | Not assumed — explicitly open (OQ1-3) |

**Result: No unsupported assumptions found.** Every potential assumption has been either explicitly approved as a decision, explicitly deferred as an open question, or explicitly stated as a default with an override path.

---

## Traceability Coverage Summary

| Traceability Chain | Artifacts | Fully Traced | Unsupported Assumptions |
|-------------------|-----------|:------------:|:----------------------:|
| Identity → Primary Users | 8 | 8 | 0 |
| Primary Users → Problem Space | 9 | 9 | 0 |
| Problem Space → Business Capabilities | 11 | 11 | 0 |
| Business Capabilities → Business Workflows | 13 | 13 | 0 |
| Business Workflows → Candidate Business Concepts | 8 | 8 | 0 |
| Evolution → Future Capabilities | 14 | 14 | 0 |
| Approved Decisions → Glossary Terms | 33 | 33 | 0 |
| **Total** | **96** | **96** | **0** |

**100% traceability. 0 unsupported assumptions.**
