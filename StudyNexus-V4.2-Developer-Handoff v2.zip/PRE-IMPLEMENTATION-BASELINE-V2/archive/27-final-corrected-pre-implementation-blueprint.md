# Document 26: Final Corrected Pre-Implementation Blueprint

> **⚠️ Reconciliation Note (2026-08-08):** C6 Resolution: Implementation baseline is **Filament v5 + Livewire v4 on Laravel 13**. Earlier documents (files 21–26) contain code samples written against Filament v5  <!-- was v3, upgraded per C6 --> / Livewire v3 APIs. Those examples are **historical** and are not implementation instructions. Filament v5  <!-- was v3, upgraded per C6 --> and Livewire v3 are incompatible with Laravel 13 (confirmed by file 28, blockers B1/B2). Do not copy v3-era code samples into implementation. Filament v5 exists to track Livewire v4; both v4.x and v5.x are actively maintained and Laravel-13-compatible.

> **⚠️ Reconciliation Note (2026-08-08):** Package Corrections (per forensic audit §5): (1) `minimolabs/laravel-webpush` → **INVALID/FABRICATED** — does not exist. Correct replacement already selected: `laravel-notification-channels/webpush`. (2) `bezhansalam/filament-shield` → **WRONG NAME** — correct: `bezhansalleh/filament-shield`. (3) `filament/tiptap-editor` → **DEPRECATED** — use native Filament RichEditor instead. (4) `spatie/laravel-rate-limits` → **INVALID/LIKELY FABRICATED** — does not exist under this name. Use Laravel's built-in RateLimiter facade or one of the real Spatie packages (`spatie/laravel-rate-limited-job-middleware` or `spatie/guzzle-rate-limiter-middleware`). (5) `pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard -->` → **UNVERIFIED** — resolve before installing. Do not introduce new packages during reconciliation; mark invalid ones and resolve separately.



**StudyNexus — The Single Coherent Implementation Blueprint**

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | FINAL CORRECTED PRE-IMPLEMENTATION BLUEPRINT |
| Supersedes | Document 24 (corrected by applying all 12 changes from Document 25) |
| Prerequisites | Documents 20 (Frozen Baseline), 21 (Post-Freeze Review), 22 (Ecosystem Review), 23 (Final Architecture), 24 (Original Blueprint), 25 (Reconciliation) |
| Hard Baseline | **Laravel 13.x + PHP 8.5** — no fallback |
| Author | StudyNexus Architecture Team |
| Purpose | Produce the single coherent implementation blueprint reconciling all authoritative decisions through Documents 20–25 and explicit product requirements, then subject it to a package/dependency verification before any code is generated. |

> "This document does not copy Document 24. It does not copy Document 25. It reconciles every authoritative decision into one implementation-ready blueprint, then audits itself for consistency before declaring readiness."

---

## Table of Contents

1. Source of Truth Hierarchy
2. Hard Platform Baseline (Laravel 13 + PHP 8.5)
3. Global Product Direction (Nigeria → Africa → Global)
4. Reconciliation Change Application Record
5. Spatie-First Package Principle
6. TALL Stack Enforcement
7. Typesense + SEO Architecture
8. Programme Discovery URL Design
9. Content Architecture
10. Study Abroad Composition
11. User Engagement
12. Comparison Architecture
13. Notification Architecture
14. Social Sharing
15. Community Architecture
16. Newsletter Architecture
17. Spam Protection
18. RBAC with spatie/laravel-permission (BookStack-Inspired)
19. Reference Data Classification
20. Database Design
21. Domain Freeze Protection
22. Laravel Beyond CRUD Audit
23. Settings Architecture
24. Implementation Phases
25. Final Package Matrix (Laravel 13 Baseline)
26. Final Architectural Inventory
27. Typesense Index Design
28. SEO Architecture
29. Media Architecture
30. Security and Privacy

---

## 1. Source of Truth Hierarchy

When documents conflict, the following authority order resolves the dispute. A higher-numbered document does not automatically supersede a lower-numbered one — it must explicitly state a correction with rationale. Where no explicit correction exists, the earlier document's decision stands.

| Priority | Document | Role |
|---|---|---|
| 1 | Business Discovery (Docs 01–10) | Product requirements, glossary, and approved decisions that started the project |
| 2 | Domain Discovery (Docs 11–19) | Entity relationships, aggregate boundaries, invariants, and domain events derived from Business Discovery |
| 3 | Doc 20 — Frozen Baseline | Canonical domain architecture; aggregate roots, entities, VOs, enums, Actions, events, invariants |
| 4 | Doc 21 — Post-Freeze Review | Platform/product capabilities reviewed against frozen baseline |
| 5 | Doc 22 — Ecosystem Review | Package selection, build-vs-buy decisions, dependency analysis |
| 6 | Doc 23 — Final Architecture | Content architecture, Study Abroad, Community, RBAC, SEO, final ADRs |
| 7 | Doc 24 — Original Blueprint | First implementation translation (contained errors corrected by Doc 25) |
| 8 | Doc 25 — Reconciliation | Adversarial correction of Doc 24; identified 12 required changes + 8 recommendations |
| 9 | **Doc 26 — This Document** | Final corrected blueprint applying all corrections; hard-baseline upgrade to Laravel 13 + PHP 8.5 |

**Conflict resolution rule:** If Document N says X and Document N+k says Y without explicitly correcting Document N, then X stands. Only an explicit correction with rationale overrides a prior decision. This prevents silent drift where a later document accidentally contradicts an earlier frozen decision.

**Hard-baseline override:** This document explicitly overrides Doc 25 Decision 1 ("Target Laravel 12") and Doc 25 Section 7 tech stack. The product decision is to target Laravel 13.x + PHP 8.5 as the implementation baseline with no fallback. Rationale: Doc 25 chose Laravel 12 as a conservative bet, but the product owner has now mandated Laravel 13 + PHP 8.5 as the hard platform baseline. All package versions in this document are evaluated against Laravel 13 + PHP 8.5, and any version that cannot be confirmed is marked UNVERIFIED pending a subsequent package audit.

## 2. Hard Platform Baseline (Laravel 13 + PHP 8.5)

This section establishes the non-negotiable technology baseline. Every subsequent decision in this document is evaluated against this baseline. There is no Laravel 12 fallback. There is no PHP 8.3 fallback.

### 2.1 Core Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| PHP | — | 8.5+ | Required baseline; no fallback |
| Laravel | `laravel/framework` | ^13.0 | Current stable; all packages must be compatible |
| PostgreSQL | — | 16+ | Primary data store (ADR-01) |
| Redis | — | 7+ | Cache + queue driver |
| Typesense | — | 29.x | Search engine (ADR-06) |
| Node.js | — | 22 LTS | Asset compilation (Vite) |

### 2.2 Frontend Stack (TALL)

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Tailwind CSS | `tailwindcss` | ^4.0 | Utility-first styling |
| Alpine.js | `alpinejs` | ^3.x | Lightweight client-side interactivity |
| Livewire | `livewire/livewire` | **UNVERIFIED** | Must verify Laravel 13 compatibility |
| Flux | `livewire/flux` | **UNVERIFIED** | Must verify compatibility with Livewire version for Laravel 13 |

### 2.3 Admin Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Filament | `filament/filament` | **UNVERIFIED** | Must verify Laravel 13 + PHP 8.5 compatibility |
| Tiptap | `filament/tiptap-editor  <!-- ⚠️ DEPRECATED: use native Filament RichEditor instead -->` | **UNVERIFIED** | Depends on Filament version |

### 2.4 Auth and Testing

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Laravel Breeze | `laravel/breeze` | **UNVERIFIED** | Must verify ^2.0 or later supports Laravel 13 |
| Laravel Sanctum | `laravel/sanctum` | **UNVERIFIED** | Must verify Laravel 13 compatibility |
| Laravel Scout | `laravel/scout` | **UNVERIFIED** | Must verify version with Typesense driver |
| Pest | `pestphp/pest` | ^3.x | Test framework |

### 2.5 UNVERIFIED Flag Protocol

Any package marked **UNVERIFIED** means its compatibility with Laravel 13 + PHP 8.5 cannot be confirmed from the documents available. These items require a separate package audit before `composer install`. The intent to use each package is documented; the version constraint is not. **Do not fabricate version numbers.** If a package does not yet support Laravel 13, the package audit must determine whether to wait, find an alternative, or contribute a compatibility fix.

### 2.6 Why Laravel 13, Not Laravel 12

Document 25 chose Laravel 12 for maturity and ecosystem stability. This document overrides that decision because the product owner has mandated Laravel 13 + PHP 8.5 as the hard baseline. The rationale for accepting this override: starting a new project on the current framework major avoids an upgrade cycle within the first year, PHP 8.5 provides performance and language improvements (readonly promoted constructors, fiber improvements, attribute enhancements), and Laravel 13's release cadence means it will receive security patches longer than Laravel 12. The risk — ecosystem packages may not yet support Laravel 13 — is managed by the UNVERIFIED protocol and the subsequent package audit.

## 3. Global Product Direction (Nigeria → Africa → Global)

StudyNexus launches in Nigeria, expands across Africa, then goes global. The architecture must accommodate this trajectory without requiring destructive redesign at any stage.

### 3.1 Launch: Nigeria

Nigeria is the primary dataset and the initial content market. Nigerian educational concepts — UTME, JAMB, O-Level, post-UTME, NUC accreditation — appear as enum values, reference data, and content, but they are **never hardcoded as architectural assumptions**. A `Country` value object (ISO 3166-1 alpha-2) discriminates Nigerian data from international data. Admission pathways like UTME and Post-UTME are enum values within `AdmissionPathway`, not separate entities. Accrediting bodies like NUC and NBTE are instances of `EducationAuthority` with `AuthorityType = Regulatory`, not dedicated domain concepts.

### 3.2 Expansion: Africa

African expansion requires: data entry for new countries, reference data seeding (currencies, qualification equivalencies, education authorities), translations via `spatie/laravel-translation-loader` (French for Francophone Africa, Portuguese for Lusophone Africa, Arabic for North Africa), and potential new enum values for country-specific admission pathways (e.g., KCSE for Kenya, WASSCE for Ghana/WA). None of these require domain model changes. All are data, configuration, and content additions.

### 3.3 Expansion: Global

Global expansion introduces institutions in the UK, US, Canada, Germany, Australia, and beyond. These are `Institution` models with `country ≠ NG`, not `ForeignInstitution` entities. Admission pathways like UCAS (UK) and CommonApp (US) are enum additions to `AdmissionPathway`. Study Abroad module composes existing domain entities with reference data. No domain redesign is required at any expansion stage.

### 3.4 Geographic Neutrality Test

| Question | Answer |
|---|---|
| Does any domain entity have Nigeria in its name? | No |
| Is any enum value Nigeria-only? | No — Nigerian pathways are values, not the enum itself |
| Can the platform represent a UK university without code changes? | Yes — Institution with country=GB |
| Can the platform represent a Kenyan admission system? | Yes — AdmissionPathway enum addition + reference data |
| Is there a "Nigerian database" separate from "international"? | No — single database, country-discriminated |

**The architecture is geographically neutral.** Expansion is always data + enum values + translations, never domain redesign.

## 4. Reconciliation Change Application Record

This section proves that every correction from Document 25 is actually applied throughout this document, not merely listed in a changelog. For each change, the section states the problem, the decision, what specifically changed, and where the correction manifests in this document.

### R1: Tech Stack Versions — OVERRIDDEN

**Original problem:** Document 24 specified Laravel 12; Doc 25 kept Laravel 12 as conservative choice.
**This document's decision:** Override to Laravel 13 + PHP 8.5 per hard platform baseline (Section 2).
**Where applied:** Section 2 (Hard Platform Baseline), Section 25 (Package Matrix), all version references throughout.

### R2: RBAC Expansion — APPLIED

**Original problem:** Doc 24 had 7 flat roles with single admin per institution.
**Decision:** 11 roles with institution-scoped membership via OrganizationMember pivot (BookStack-inspired).
**Where applied:** Section 18 (RBAC), Section 20 (Database Design — organization_members table), Section 24 (Implementation Phases — auth-first).

### R3: Missing Domain Enums — APPLIED

**Original problem:** 4 enums referenced in migrations were missing from the catalogue.
**Decision:** Added CoverageType, PolicyStatus, ProviderType, AuthorityType. Enum count: 16 → 20.
**Where applied:** Section 20 (Database Design — enum-referenced columns), Section 21 (Domain Freeze Protection — corrected enum count).

### R4: Value Object Count Reconciliation — APPLIED

**Original problem:** Doc 24 listed 11 VOs in one section but claimed 28 in another.
**Decision:** 14 non-enum VOs (added AuthorityJurisdiction, PhaseSequence, ValidityPeriod) + 20 enums = 34 total domain value objects.
**Where applied:** Section 21 (Domain Freeze Protection — VO count).

### R5: Reference → Domain FK Violation — APPLIED

**Original problem:** qualification_equivalencies FK violated namespace dependency rules.
**Decision:** Moved Qualification from App\Domain\Models to App\Reference\Models.
**Where applied:** Section 19 (Reference Data — Qualification now listed there), Section 20 (Database — Domain tables 10, Reference tables 7), Section 21 (Supporting entities 2, not 3).

### R6: Programme Discovery URL Architecture — APPLIED

**Original problem:** Doc 24 omitted cross-institution programme discovery URLs.
**Decision:** Added /programmes, /programmes/{discipline}, /programmes/{discipline}/{level} with controlled indexation.
**Where applied:** Section 8 (Programme Discovery URL Design), Section 7 (Typesense + SEO), Section 28 (SEO Architecture).

### R7: Livewire Usage Boundary — APPLIED

**Original problem:** No guidance on when to use vs not use Livewire.
**Decision:** Explicit boundary: Blade for SEO-critical, Livewire for interactive, Alpine for presentation-only.
**Where applied:** Section 6 (TALL Stack Enforcement — Livewire boundary table).

### R8: Expanded Engagement Features — APPLIED

**Original problem:** Only Save, Follow, Like; missing Compare, Share, Hide, Alert/Watchlist.
**Decision:** Added Compare (comparison_sets, Phase 2c), Share (client-side Alpine.js), Hide/Alert (Phase 3 deferred).
**Where applied:** Section 11 (User Engagement), Section 12 (Comparison Architecture), Section 20 (Database — comparison_sets table).

### R9: Notification Preferences Schema — APPLIED

**Original problem:** No notification preferences table.
**Decision:** Added notification_preferences with per-user, per-category, per-channel columns.
**Where applied:** Section 13 (Notification Architecture), Section 20 (Database — notification_preferences table).

### R10: Expanded Community Module — APPLIED

**Original problem:** No Report entity for moderation.
**Decision:** Added community_reports table. Phase 2a now includes Reports.
**Where applied:** Section 15 (Community Architecture), Section 20 (Database — community_reports table).

### R11: Breeze Version Constraint — APPLIED

**Original problem:** ^1.x is not a valid Composer constraint.
**Decision:** Mark as UNVERIFIED pending Laravel 13 compatibility check (was ^2.0 for Laravel 12; must re-verify for Laravel 13).
**Where applied:** Section 2 (Hard Platform Baseline), Section 25 (Package Matrix).

### R12: Scholarship Schema.org Type — APPLIED

**Original problem:** DatedMoneySpecification is not a standard Schema.org type.
**Decision:** Use Grant (https://schema.org/Grant).
**Where applied:** Section 28 (SEO Architecture — structured data table).

## 5. Spatie-First Package Principle

The project follows a **Spatie Preference, Not Bias** principle. Spatie packages are evaluated first for any capability because of their exceptional maintenance record, Laravel-first philosophy, and community adoption. However, Spatie packages are not automatically adopted — quality, fit, and layer compatibility determine adoption, not brand.

### 5.1 When Spatie Is Chosen

A Spatie package is chosen when it satisfies all of the following: active maintenance (commits within last 6 months), Laravel 13 compatibility (or UNVERIFIED with audit plan), test coverage above 80%, no layer violation (does not force business logic into infrastructure or presentation), and the custom code equivalent exceeds 100 lines (below that, writing custom code is preferred to avoid dependency).

### 5.2 When Spatie Is Rejected

A Spatie package is rejected when: it contradicts a frozen ADR (e.g., `spatie/laravel-event-sourcing` contradicts ADR-02), it is superseded by a better alternative (e.g., `spatie/laravel-fractal` superseded by `spatie/laravel-data`), it introduces lock-in to a specific vendor (e.g., `spatie/laravel-newsletter` locks to Mailchimp), it over-engineers a problem solvable with Laravel built-ins (e.g., `spatie/laravel-model-states` when guard clauses + PHP enums are LBC-idiomatic), or it conflicts with TALL stack coherence (e.g., assumes SPA patterns).

### 5.3 Rejected Spatie Packages (Carried Forward from Docs 22/25)

| Package | Reason |
|---|---|
| `spatie/laravel-event-sourcing` | Contradicts ADR-02 |
| `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| `spatie/laravel-model-states` | Guard clauses + enums are LBC-idiomatic |
| `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| `spatie/laravel-fractal` | Superseded by laravel-data |
| `spatie/valuestore` | Superseded by laravel-settings |
| `spatie/laravel-view-models` | Superseded by laravel-data |
| `spatie/laravel-geocoder` | Typesense geo filter handles location |
| `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| `spatie/laravel-feeds` | Near-zero relevance |
| `wireui/wireui` | Unnecessary when using Flux |
| `spatie/laravel-ray` | Dev-only, never in production dependencies |

## 6. TALL Stack Enforcement

The public-facing application uses the **TALL stack**: Laravel + Blade + Livewire + Flux + Alpine.js + Tailwind CSS. This is non-negotiable. There is no React, no Next.js, no Vue, no Inertia, no SPA, and no client-side routing. The server owns the page; JavaScript enhances it.

### 6.1 Stack Roles

| Technology | Role | Boundary |
|---|---|---|
| Laravel | Application framework, routing, middleware, DI container | Backend only |
| Blade | Server-rendered templates for SEO-critical content and layouts | SEO-critical pages, static content, page shells |
| Livewire | Server-driven reactive UI for interactive pages and forms | Filter pages, dashboards, forms, lazy-loaded sections |
| Flux | UI component library providing consistent design system for Livewire | Form inputs, buttons, cards, modals, tables |
| Alpine.js | Lightweight client-side interactivity for presentation-only behaviour | Share buttons, dropdowns, accordions, tooltips, mobile menu |
| Tailwind CSS | Utility-first CSS framework | All styling |
| Filament | Admin panel framework — **admin-facing only** | Never exposed to public users |

### 6.2 Livewire Usage Boundary (from R7)

| Context | Use Livewire? | Use Blade? | Use Alpine.js? | Rationale |
|---|---|---|---|---|
| SEO-critical detail pages (institution, programme, scholarship, article, guide) | No (except lazy-loaded sections) | Yes (server-rendered) | Yes (UI toggles) | SEO requires fully rendered HTML on first load |
| Search/filter/listing pages | Yes (wire:navigate for SPA-like transitions) | Yes (initial server render) | No | Livewire handles filter state, pagination, URL sync |
| Lazy-loaded sections (related content, community Q&A) | Yes (lazy component) | No | No | Loaded on demand, not SEO-critical |
| Authenticated dashboards | Yes | Yes (layout) | Yes (minor UI) | SEO irrelevant; interactivity primary |
| Forms (save, follow, report, ask question) | Yes | No | No | Livewire handles validation, submission, state |
| Static content (about, privacy, terms) | No | Yes | No | No interactivity needed |
| Share buttons, UI toggles | No | No | Yes | Pure client-side, no server round-trip |

**Rule of thumb:** Blade for SEO-critical first-load content. Livewire for interactivity. Alpine.js for presentation-only client-side behaviour. Never use Livewire where Blade suffices.

### 6.3 Anti-Patterns

- Making every page a Livewire component (degrades SEO, adds unnecessary server round-trips)
- Using Filament for public-facing UI (Filament is admin-only)
- Introducing React, Next.js, Vue, or Inertia anywhere in the codebase
- Client-side routing (the server owns the URL)
- Client-rendered SEO pages (search engines must see fully rendered HTML)

## 7. Typesense + SEO Architecture

Typesense is the search, discovery, and faceting engine. It is a **projection** of PostgreSQL data, not a replacement for it. Laravel/PostgreSQL remains authoritative for canonical entities, SEO pages, and structured data rendering.

### 7.1 The Separation

| Concern | Owned By | Rationale |
|---|---|---|
| Canonical entity data | PostgreSQL | Source of truth (ADR-01, P9) |
| SEO page rendering | Blade + Laravel | Server-rendered HTML for crawlers |
| Canonical URLs | Laravel routes | Stable, deliberate, controlled |
| Structured data | Blade templates | JSON-LD in server-rendered pages |
| Full-text search | Typesense | Optimized for search, not rendering |
| Faceted navigation | Typesense | Real-time faceting, filtering, sorting |
| Autocomplete | Typesense | Instant search API |
| Discovery/hub pages | Blade (initial) + Typesense (results) | SEO entry point + interactive results |

### 7.2 The Flow: Typesense → Laravel → Canonical Page

A user's search flow is: (1) Typesense returns search results with entity IDs and slugs, (2) each result links to a Laravel route that renders the canonical Blade page, (3) the canonical page is fully server-rendered with structured data, meta tags, and Open Graph. Typesense never renders a public page. It only provides the search/discovery API that Livewire or Blade consumes.

### 7.3 Sync Mechanism

Domain events → `UpdateSearchIndex` listener → queued Scout job. Eventual consistency with a stale tolerance of ≤5 seconds. If the Typesense index is corrupted, it can be fully rebuilt from PostgreSQL via `php artisan scout:import-all`.

### 7.4 Controlled Indexation

Not every URL combination is indexable. The SEO architecture deliberately controls which pages search engines can crawl: canonical entity pages are indexable, curated discovery pages are indexable, deep filter combinations (>3 query parameters) are noindex, paginated pages beyond page 1 are noindex, user profiles and search results pages are noindex. This prevents exponential URL explosion and conserves crawl budget.

## 8. Programme Discovery URL Design

Programme discovery operates at two levels: institution-scoped (a specific institution's programmes) and cross-institution (global discovery hubs). Both are required for a useful and SEO-effective information architecture.

### 8.1 URL Table

| URL | Purpose | Rendering | SEO |
|---|---|---|---|
| `/programmes` | Cross-institution programme search hub | Blade (initial) + Livewire (filters) + Typesense | Indexable (main listing) |
| `/programmes/{discipline}` | Discipline landing page (e.g., `/programmes/engineering`) | Blade (curated content) + Typesense results | Indexable (curated SEO page) |
| `/programmes/{discipline}/{level}` | Discipline + level landing (e.g., `/programmes/engineering/undergraduate`) | Blade + Typesense | Indexable (curated) |
| `/institutions/{inst-slug}/programmes` | Institution's programmes (paginated, filterable) | Blade + Livewire | Indexable (institution-scoped listing) |
| `/institutions/{inst-slug}/programmes/{prog-slug}` | Programme detail page (canonical) | Blade | Indexable (canonical detail page) |

### 8.2 Forbidden URL Patterns

- `/programmes/{slug}` → **FORBIDDEN** — programme slug is NOT globally unique; it is only unique within an institution
- `/programmes?discipline=X&level=Y&country=Z&institution-type=W&...` → **noindex** — deep filter combination with >3 params per ADR-24
- Every combination of discipline × level × country × type → **noindex** — exponential URL problem

### 8.3 Controllers

- `ProgrammeDiscoveryController` — handles `/programmes` and `/programmes/{discipline}` routes; thin controller invoking Query classes + returning Blade views with Typesense-powered results
- `InstitutionProgrammeController` — handles `/institutions/{inst}/programmes` listing
- `ProgrammeController` — handles `/institutions/{inst}/programmes/{prog}` detail page

## 9. Content Architecture

The content layer surrounds the frozen domain. It follows the **Option C** decision from Document 23: separate Eloquent models with shared traits/concerns. Each content type with genuinely distinct behaviour gets its own model. Content types that differ only in data (not behaviour) share a model with a type discriminator.

### 9.1 Content Models (4)

| Model | Table | Contents | Distinct Behaviour |
|---|---|---|---|
| `Article` | `articles` | News, announcements, institution updates | Time-sensitive publishing, news source attribution, Google News sitemap, breaking flag, chronological feed |
| `Guide` | `guides` | How-to guides, career guides, education guides, study-abroad guides | Structured sections with TOC, reading time, section navigation, evergreen lifecycle |
| `EducationalResource` | `educational_resources` | Project topics, seminar topics, research materials, study resources | Standard publishing + `resource_type` enum + discipline + academic level + download tracking |
| `ExamPreparation` | `exam_preparations` | Past questions, exam tips, subject reviews, exam prep material | Standard publishing + `prep_type` enum + exam body + year + subject + download tracking |

**Four models. Not twelve.** Project Topic, Seminar Topic, and Research Material are `resource_type` enum values within `EducationalResource`, not separate entities. Past Questions and Exam Tips are `prep_type` enum values within `ExamPreparation`.

### 9.2 Shared Traits

| Trait | Responsibility | Used By |
|---|---|---|
| `HasSlug` | Auto-generate URL slug from title on creation | All 4 content models |
| `IsPublishable` | Draft/published status, published_at, publish()/unpublish() | All 4 content models |
| `HasSeoMeta` | SEO title, description, canonical URL, Open Graph, noindex/nofollow | All 4 content models |
| `HasMedia` | Spatie Media Library integration for attachments/images | All 4 content models |
| `HasProvenance` | Author attribution, source URL, institution association (optional) | All 4 content models |
| `IsSearchable` | Typesense Scout integration for search projection | All 4 content models |
| `HasTags` | Spatie Tags integration for taxonomy/categorisation | All 4 content models |
| `HasSections` | Ordered content sections with titles and body | Guide only |

### 9.3 Content → Domain Dependency Rule

Content models reference domain entities (an Article about UNILAG references the Institution aggregate via `institution_id`). Domain models **never** reference content. The dependency is unidirectional: `App\Content\*` may import from `App\Domain\*`, but `App\Domain\*` must never import from `App\Content\*`. This preserves domain purity and ensures the frozen domain remains independent of the content layer.

## 10. Study Abroad Composition

Study Abroad is a **module** (`App\StudyAbroad\`), not a domain redesign. It composes existing domain entities with reference data and content to serve international education information needs.

### 10.1 What Study Abroad Uses (Composes)

| Capability | Implementation |
|---|---|
| International institutions | Existing `Institution` model with `country ≠ NG` |
| International programmes | Existing `Programme` model where `institution.country ≠ NG` |
| International scholarships | Existing `Scholarship` model targeting foreign institutions |
| Study abroad guides | Existing `Guide` model (study-abroad category/tag) |
| Study abroad news | Existing `Article` model (study-abroad category/tag) |
| Reference data | 6 tables: countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries |
| Presentation | 3 Livewire components: CountryPage, CompareDestinations, ScholarshipListing |

### 10.2 What Study Abroad Does NOT Create

- NO `ForeignInstitution` entity — use existing `Institution` with country code
- NO `VisaRequirement` entity — reference data, not domain
- NO `CountrySpecificProgramme` entity — programmes are programmes regardless of country
- NO domain model changes — Study Abroad composes existing entities; it does not introduce new aggregate roots or invariants

### 10.3 Feature Flag

Study Abroad is behind a `features.study_abroad` feature flag (default: disabled). It is activated in Phase 2b. The module is entirely self-contained within `App\StudyAbroad\` — removing the feature flag disables the module without affecting any other part of the system.

## 11. User Engagement

User engagement features allow students and other users to interact with educational content and opportunities. These are application/platform-layer capabilities, not domain entities. There is no generic `UserInteraction` god entity — each engagement type is modelled according to its actual behaviour and lifecycle.

### 11.1 Engagement Features

| Feature | Persisted? | Table | Phase | Implementation |
|---|---|---|---|---|
| **Save** | Yes | `saves` | 1h | morphToMany on User; "I want to return to this" |
| **Follow** | Yes | `follows` | 1h | morphToMany on User; "Tell me when something changes" |
| **Like** | Yes | `likes` | 1h | morphToMany on User; NOT a domain signal — no influence on trust/accreditation |
| **Compare** | Session/DB | `comparison_sets` | 2c | Livewire component; session for anonymous, DB for authenticated |
| **Share** | No | None | 1h | Client-side Alpine.js; window.open with platform-specific share URLs |
| **Hide/Not-Interested** | Yes | `hidden_items` | 3 | Affects feed visibility; deferred |
| **Alert/Watchlist** | Yes | `user_alerts` | 3 | User-defined conditions for notification triggers; deferred |

### 11.2 Key Distinctions

- **Save ≠ Follow:** Save = bookmark for later. Follow = subscribe to changes. These are different user intents with different notification implications.
- **Like is NOT a domain signal:** Likes do not influence trust scores, accreditation, or eligibility. They are a presentation-layer social signal only.
- **Compare is NOT a domain concept:** No `Comparison` aggregate, no invariants, no domain events. It is a product/presentation feature.
- **Share is client-side only:** No server-side tracking, no share count storage (ADR-25). This avoids database writes and privacy concerns.

### 11.3 Database Design Notes

Each persisted engagement table uses polymorphic relationships (`saves`, `follows`, `likes` all have `saveable_type/saveable_id`, `followable_type/followable_id`, `likeable_type/likeable_id`). Each has a `user_id` index for the common "get all items for user X" query pattern (Recommendation 5 from Doc 25).

## 12. Comparison Architecture

Comparison allows users to compare multiple programmes, institutions, or scholarships side-by-side. It is a **product/presentation feature**, not a domain concept.

### 12.1 Architecture

| Aspect | Decision |
|---|---|
| Anonymous users | Comparison sets stored in session (ephemeral, no persistence) |
| Authenticated users | Comparison sets persisted in `comparison_sets` table |
| UI | Livewire component with add/remove actions and side-by-side rendering |
| Data retrieval | Query classes fetch full entity data for comparison display |
| Limit | Maximum 4 items per comparison set (UX limit, not domain invariant) |

### 12.2 comparison_sets Table

```
comparison_sets
    id                  bigint PK
    user_id             bigint FK → users (nullable for anonymous merging)
    name                varchar(255) nullable
    resource_type       varchar(50)  -- 'programme', 'institution', 'scholarship'
    resource_ids        json         -- array of entity IDs being compared
    created_at / updated_at

    Index: user_id
```

### 12.3 Phase

Comparison is implemented in **Phase 2c** after the core engagement features (Save, Follow, Like) and the domain/content pages are complete.

## 13. Notification Architecture

StudyNexus uses Laravel's native notification system. No custom notification framework is built (ADR-22). Notifications are triggered by domain events and dispatched through listeners.

### 13.1 Notification Channels

| Channel | Package | Feature Flag | Phase |
|---|---|---|---|
| Database (in-app) | Laravel built-in | Always on | 1i |
| Email | Laravel built-in | Always on | 1i |
| Web Push | `laravel-notification-channels/webpush` | `features.web_push` | 1i |
| SMS | **UNVERIFIED** (Twilio/Vonage SDK) | `features.sms` | Phase 3 |

### 13.2 Notification Classes (Phase 1i)

| Notification | Trigger | Default Channels |
|---|---|---|
| AdmissionCycleOpened | Admission cycle activated | DB + Email + WebPush |
| ScholarshipDeadlineApproaching | 7-day / 1-day before deadline | DB + Email + SMS |
| NewArticlePublished | Followed institution publishes article | DB + WebPush |
| CommunityAnswerReceived | User's question answered (Phase 2a) | DB + Email |
| ProgrammeAdmissionStatusChanged | Admission status change | DB + Email |

### 13.3 Notification Preferences

Per-user, per-category, per-channel preferences stored in the `notification_preferences` table:

```
notification_preferences
    id                  bigint PK
    user_id             bigint FK → users (cascade delete)
    category            varchar(50) -- admission, scholarship, content, community
    email               boolean default true
    in_app              boolean default true
    web_push            boolean default false
    sms                 boolean default false
    digest_frequency    varchar(20) nullable -- instant, daily, weekly
    created_at / updated_at

    Unique: (user_id, category)
```

### 13.4 Digest Strategy

Digest aggregation is deferred until notification volume exceeds ~20 per user per day. Until then, each notification is dispatched immediately through the user's preferred channels. When digest is implemented, a scheduled job aggregates notifications by category and frequency, sending a single email/in-app summary instead of individual notifications.

## 14. Social Sharing

Social sharing is implemented as **client-side only** functionality using Alpine.js. There is no server-side share tracking, no share count storage, and no share analytics database table (ADR-25).

### 14.1 Implementation

| Platform | Mechanism |
|---|---|
| Twitter/X | `window.open` with pre-filled tweet text + URL |
| Facebook | FB.share SDK or `window.open` with sharer URL |
| WhatsApp | `https://wa.me/?text=` URL scheme |
| Telegram | `https://t.me/share/url=` URL scheme |
| LinkedIn | `window.open` with LinkedIn sharer URL |
| Copy Link | Alpine.js `navigator.clipboard.writeText()` with toast feedback |

### 14.2 Open Graph / Twitter Cards

All shareable entities (Institution, Programme, Scholarship, Article, Guide, EducationalResource, ExamPreparation) have Open Graph and Twitter Card meta tags rendered server-side via the `HasSeoMeta` trait. This ensures that when a URL is shared on any platform, the preview card shows the correct title, description, and image without client-side rendering.

### 14.3 What We Do NOT Build

- Share count tracking (privacy concern, unreliable APIs, ADR-25)
- Server-side share redirect URLs (unnecessary complexity)
- Share-to-email (email client share is a client feature, not server)

## 15. Community Architecture

Community is a **Stack Overflow + Reddit hybrid** module that lives in `App\Community\`. It is feature-flagged and does not pollute the frozen education domain.

### 15.1 Phase 2a Entities

| Entity | Purpose | Key Relationships |
|---|---|---|
| Question | Student's question about an education topic | Belongs to User, has many Answers, polymorphic subject (Institution, Programme, etc.) |
| Answer | Response to a Question | Belongs to User and Question, has Votes |
| Comment | Reply to Question or Answer | Belongs to User, polymorphic commentable |
| Vote | Upvote/downvote | Polymorphic, belongs to User, value (+1/-1) |
| Report | Flag content for moderation | Polymorphic reportable, belongs to reporter, status (pending/resolved/dismissed) |

### 15.2 Phase 3 (Deferred)

- Post — Reddit-style discussion post
- PostChannel — Topic/channel for Posts
- Reputation — User reputation based on contributions
- Badges — Achievement badges for community participation

### 15.3 Dependency Rule

Community references domain entities via polymorphic FK (a Question can be about an Institution or Programme). The domain **never** references community. The dependency is unidirectional: `App\Community\*` may import from `App\Domain\*`, but not the reverse.

### 15.4 Feature Flag

`features.community` — default: disabled. Activated in Phase 2a.

### 15.5 Moderation

Community moderation uses the `community_reports` table for user-flagged content. Platform moderators (`platform-moderator` role) can review, dismiss, or action reports. Automated moderation (rate limiting on posts, honeypot on forms) supplements manual review.

## 16. Newsletter Architecture

StudyNexus needs newsletter capability for distributing curated educational content and updates. The architecture uses Laravel Notifications + queue for multi-provider newsletter delivery, not `spatie/laravel-newsletter` (rejected for Mailchimp lock-in per ADR-022-3).

### 16.1 Architecture

| Aspect | Decision |
|---|---|
| Subscriber source | `follows` table — users who follow an institution/topic are newsletter subscribers |
| Delivery mechanism | Laravel Notification + queue job |
| Provider | **UNVERIFIED** — evaluate Mailgun, Postmark, or Amazon SES for transactional + broadcast email |
| Unsubscribe | Per-category unsubscribe via notification_preferences; one-click List-Unsubscribe header |
| Templates | Blade email templates with inline CSS (Premailer or CssInlinerPlugin) |
| Frequency | Digest-based: daily, weekly, monthly — controlled by notification_preferences.digest_frequency |

### 16.2 What We Do NOT Build

- Custom email builder UI (use Filament rich text editor for admin-curated newsletters)
- Separate subscriber table (reuse `follows` + `notification_preferences`)
- `spatie/laravel-newsletter` (Mailchimp-only, vendor lock-in)

## 17. Spam Protection

Multiple layers of spam protection operate across the platform. No single mechanism is sufficient; they compose to form a defence-in-depth strategy.

| Layer | Mechanism | Package | Scope |
|---|---|---|---|
| Form honeypot | Hidden field that bots fill | `spatie/laravel-honeypot` **UNVERIFIED** | Public forms (contact, community questions) |
| CSRF | Token validation on POST | Laravel built-in | All forms |
| Rate limiting | Per-IP and per-user throttle | Laravel `RateLimiter` | API endpoints, form submissions |
| Content moderation | User reports + admin review | Custom (community_reports) | Community content |
| Account creation | Email verification + optional captcha | Laravel built-in + **UNVERIFIED** reCAPTCHA (Phase 3) | Registration |
| Livewire protection | Built-in CSRF + spoofing protection | Livewire built-in | All Livewire forms |

`spatie/laravel-honeypot` is classified as Adopt Now from Doc 25, but its version for Laravel 13 is UNVERIFIED. Livewire's built-in CSRF may make honeypot redundant for Livewire forms; the package audit will determine whether to keep it for non-Livewire (Blade) forms only.

## 18. RBAC with spatie/laravel-permission (BookStack-Inspired)

StudyNexus uses `spatie/laravel-permission` as the **authorization engine** for global platform roles and permissions. But Spatie Permission is not the complete RBAC product. Institution/organization-level authorization uses a BookStack-inspired scoped membership model via the `OrganizationMember` pivot.

### 18.1 Two-Layer Authorization

| Layer | Mechanism | Scope | Storage |
|---|---|---|---|
| Global platform permissions | `spatie/laravel-permission` | Cross-cutting platform capabilities (admin, content, moderation) | Spatie `roles` + `permissions` tables |
| Organization-scoped permissions | `OrganizationMember` pivot | Entity-level privileges per institution/organization | `organization_members` table |

### 18.2 Global Platform Roles

| Role | Spatie Role Name | Key Permissions |
|---|---|---|
| Platform Admin | `platform-admin` | All permissions |
| Platform Moderator | `platform-moderator` | Verify sources, moderate content, review community |
| Content Admin | `content-admin` | CRUD all domain entities + content |
| Content Editor | `content-editor` | Create/edit/publish content |

### 18.3 Institution-Scoped Roles (via OrganizationMember)

| Role | Key Capabilities | Notes |
|---|---|---|
| `institution-owner` | Full control + manage members + transfer ownership | At least one owner must exist per institution |
| `institution-admin` | Manage institution data, programmes, admissions, scholarships, publish articles | Cannot manage members or transfer ownership |
| `institution-admissions` | Manage admission policies, cycles, deadlines | Read-only on other institution data |
| `institution-editor` | Edit descriptions, media, programme details | Cannot change status, manage admissions, or manage members |
| `institution-viewer` | View internal data and reports | Read-only access |

**These roles are initial defaults, not a rigid hierarchy.** The architecture allows institution roles and permissions to evolve. New roles can be added, existing role capabilities can be adjusted, and the role hierarchy can be reconfigured without code changes — the `OrganizationMember.role` is a string, not an enum, specifically to allow this flexibility.

### 18.4 User Roles

| Role | Key Capabilities |
|---|---|
| `registered-user` | Save, follow, like, compare, community participation |
| `guest` | Browse only |

### 18.5 OrganizationMember Pivot Design

```
organization_members
    id                  bigint PK
    user_id             bigint FK → users (cascade delete)
    organization_type   string (morph: 'institution', 'scholarship_provider', 'education_authority')
    organization_id     bigint (morph ID)
    role                string (e.g., 'owner', 'admin', 'admissions', 'editor', 'viewer')
    created_at / updated_at

    Unique: (organization_type, organization_id, user_id, role)
    Index: morphsIndex('organization')
```

**Critical distinction:** `OrganizationMember.role` is a **string** stored on the pivot, NOT a FK to the Spatie `roles` table. Spatie roles are for global platform permissions. Org-scoped roles are for entity-level privileges. These are two separate concepts that must not be conflated.

### 18.6 Key Invariant

The same user can be `owner` of Institution A and `viewer` of Institution B. Roles are scoped to the organization, not global. An institution can have **multiple** authorized users with different privileges. There is no `owner_id` or `admin_user_id` on the Institution aggregate — ownership is membership, not a domain property.

### 18.7 Policy Pattern

```php
class InstitutionPolicy
{
    public function update(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->hasRole('content-admin')
            || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
    }
}
```

### 18.8 Administrative UI

Filament resources provide the administrative UI for managing: global roles and permissions (via `bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) -->` **UNVERIFIED** for Laravel 13), organization memberships (custom Filament resource), and self-protection against administrators accidentally removing their own critical access (the UI must prevent the last platform-admin from demoting themselves and the last institution-owner from removing their ownership).

## 19. Reference Data Classification

Reference data is data that supports the domain model but is not itself subject to domain invariants or lifecycle events. It is managed via Filament CRUD, not through domain Actions.

### 19.1 Reference Tables (7)

| Table | Purpose | Namespace |
|---|---|---|
| `qualifications` | Educational qualification types (BSc, MSc, PhD, OND, HND, etc.) | `App\Reference\Models\Qualification` |
| `countries` | ISO 3166-1 country list with name, ISO code, continent | `App\Reference\Models\Country` |
| `currencies` | ISO 4217 currency list with name, code, symbol | `App\Reference\Models\Currency` |
| `qualification_equivalencies` | Cross-country qualification recognition mapping | `App\Reference\Models\QualificationEquivalency` |
| `tuition_fee_ranges` | Typical tuition ranges by country/institution type/level | `App\Reference\Models\TuitionFeeRange` |
| `cost_of_living_indices` | Cost of living data by country/city | `App\Reference\Models\CostOfLivingIndex` |
| `visa_requirement_summaries` | Visa requirement summaries by country pair | `App\Reference\Models\VisaRequirementSummary` |

### 19.2 Qualification Namespace Move (from R5)

`Qualification` was moved from `App\Domain\Models` to `App\Reference\Models` because: it has no domain invariants beyond referential integrity, it is managed via Filament CRUD (not domain Actions), its lifecycle (Active → Deprecated) is reference-data behaviour, not domain behaviour, and moving it eliminates the Reference → Domain FK violation in `qualification_equivalencies`.

### 19.3 Nigerian Terminology as Reference Data

Nigerian educational terminology (JAMB, UTME, O-Level, Post-UTME, NUC, NBTE, WAEC, NECO) appears as: enum values within existing enums (e.g., `AdmissionPathway::UTME`, `AuthorityType::Regulatory` with name='NUC'), instances of reference data (e.g., `EducationAuthority` with country='NG' and type='Regulatory'), and content (articles and guides about Nigerian admission processes). These are **never** hardcoded as domain entities. The architecture remains geographically neutral — Nigerian examples are data, not code.

## 20. Database Design

### 20.1 Table Inventory by Layer (51 tables)

| Layer | Tables | Count |
|---|---|---|
| Domain | institutions, programmes, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, information_sources, scholarship_providers, education_authorities | 10 |
| Content | articles, guides, guide_sections, educational_resources, exam_preparations | 5 |
| Auth/RBAC | users, roles, permissions, model_has_roles, model_has_permissions, role_has_permissions, organization_members, password_reset_tokens, personal_access_tokens | 9 |
| Engagement | saves, follows, likes, comparison_sets | 4 |
| Community | community_questions, community_answers, community_comments, community_votes, community_reports | 5 |
| Reference | qualifications, countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries | 7 |
| Notification | notification_preferences | 1 |
| Settings | platform_settings, institution_settings, user_preferences | 3 |
| SEO | url_redirects | 1 |
| Infrastructure | media, tags, taggables, activities, notifications, jobs, failed_jobs, cache, sessions | 9 |
| **Total** | | **54** |

### 20.2 Key Schema Decisions

- **Qualification in Reference** (R5): `qualifications` table lives in `App\Reference\Models`, FKs from `qualification_equivalencies` point within Reference namespace
- **OrganizationMember.role is string** (Rec 8): not a FK to Spatie roles; org-scoped role is a separate concept from global platform role
- **user_id indexes on engagement tables** (Rec 5): `saves`, `follows`, `likes` each have standalone `user_id` index for "get all items for user X" queries
- **Explicit FK on articles.institution_id** (Rec 6): `->constrained()->nullOnDelete()` for data integrity
- **Morph index on community_questions.subject** (Rec 7): `$table->morphsIndex('subject')` for polymorphic query performance
- **comparison_sets** (R8): new table for authenticated user comparison persistence
- **notification_preferences** (R9): new table for per-user, per-category, per-channel notification preferences
- **community_reports** (R10): new table for moderation reporting
- **Settings tables** (Section 23): platform_settings, institution_settings, user_preferences for structured application settings

### 20.3 Migration Dependencies

Migrations must execute in dependency order: (1) users + auth tables, (2) roles + permissions (Spatie), (3) reference data (countries, currencies, qualifications), (4) domain tables (institutions → programmes → scholarships → admission_cycles → admission_policies → eligibility_policies → accreditation_records → information_sources → scholarship_providers → education_authorities), (5) organization_members (depends on users + domain), (6) content tables (articles, guides, educational_resources, exam_preparations), (7) engagement tables (saves, follows, likes, comparison_sets), (8) community tables (community_questions → community_answers → community_comments → community_votes → community_reports), (9) notification_preferences, (10) settings tables, (11) SEO/infrastructure tables.

## 21. Domain Freeze Protection

The frozen domain model from Document 20 is preserved intact in this blueprint. No frozen decision has been changed. All corrections from Document 25 are additive or corrective at the implementation level — none reopen frozen ADRs.

### 21.1 Frozen Aggregate Roots (5)

| Aggregate Root | Key Invariants | Status |
|---|---|---|
| Institution | Name uniqueness within country; accreditation validity | Frozen |
| Programme | Unique within institution; award type consistency | Frozen |
| Scholarship | Application window validity; eligibility criteria non-empty | Frozen |
| Admission Cycle | Date ordering (open ≤ close ≤ results); at least one policy | Frozen |
| Information Source | URL or contact required; verification status | Frozen |

### 21.2 Frozen Child Entities (3)

AdmissionPolicy, EligibilityPolicy, AccreditationRecord — all frozen.

### 21.3 Supporting Entities (2, after Qualification move)

ScholarshipProvider, EducationAuthority — both frozen. Qualification moved to Reference (R5), which is a namespace reclassification, not a domain redesign.

### 21.4 Value Objects

14 non-enum VOs + 20 enums = 34 total domain value objects. The corrected list includes AuthorityJurisdiction, PhaseSequence, and ValidityPeriod that were missing from Doc 24.

### 21.5 Domain Events (29)

Plain PHP classes. No shared `DomainEvent` interface. No event store. Dispatched via Laravel's event dispatcher.

### 21.6 Application Actions (20)

Each Action meets the explicit Action Criterion (4 conditions from Doc 20 F4): multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization + complex validation.

### 21.7 Frozen Decisions Preserved

- `EducationalOpportunity` is NOT a domain entity (ADR-14)
- No generic `UserInteraction` domain entity (ADR-20)
- No repository pattern (ADR-04)
- No event sourcing (ADR-02)
- No SPA/React/Vue/Inertia (ADR-11)
- Domain never imports Content (Doc 23)
- Domain never imports Community (Doc 23)

## 22. Laravel Beyond CRUD Audit

Laravel Beyond CRUD (LBC) is the architectural philosophy. This section audits the blueprint against LBC principles.

| Concern | Verdict | Notes |
|---|---|---|
| Unnecessary repositories? | None | ADR-04 forbids them; Eloquent IS the repository |
| Unnecessary interfaces? | None | No DomainEvent interface (F2 correction preserved) |
| Unnecessary domain abstractions? | None | No EducationalOpportunity entity (ADR-14 preserved) |
| Ceremony-heavy DDD? | Minimal | VOs are readonly classes, not abstract hierarchies |
| Premature CQRS? | None | Queries are simple read wrappers, not a CQRS framework |
| Premature event sourcing? | None | Correctly forbidden; rejected in package matrix |
| Unnecessary DTO layers? | Verify | spatie/laravel-data is for request/response DTOs — must not leak into domain VOs |
| Unnecessary domain services? | One only | InstitutionMerger — genuinely cross-aggregate |
| Generic managers/services? | None | No EntityManager, ServiceManager, etc. |
| CRUD-shaped domain methods? | None | Domain methods enforce invariants, not just set fields |
| Over-fragmented Actions? | Justified | All 20 Actions meet the Action Criterion (4 conditions) |
| Eloquent as repository? | Correct | No persistence abstraction |
| Domain events as plain PHP? | Correct | No shared interface or trait |

**LBC Compliance Score: 9/10** — One minor concern: ensure `spatie/laravel-data` DTOs do not leak into domain layer. DTOs are application-layer only. Every proposed abstraction, interface, service, Action, Query, table, or package must earn its complexity under LBC's pragmatic philosophy.

## 23. Settings Architecture

The architecture must support multiple tiers of settings and preferences. Not everything is a setting — some things are application data with their own lifecycle, validation, and invariants. The architecture distinguishes between genuine configuration (settings) and domain/application data.

### 23.1 Settings Tiers

| Tier | Examples | Storage | Mechanism |
|---|---|---|---|
| Platform/System | site name, maintenance mode, default locale, default timezone, feature flags | `platform_settings` table | `spatie/laravel-settings` **UNVERIFIED** or custom typed settings |
| Administrative | registration controls, moderation settings, publishing defaults, community config, notification config, search config | `platform_settings` table (grouped by category) | Same mechanism as platform settings |
| Institution/Organization | institution profile preferences, notification preferences, permitted capabilities, membership/invitation settings | `institution_settings` table | Per-organization settings; each institution row is one organization's config |
| User Preferences | language, timezone, email preferences, in-app notification prefs, web push prefs, privacy prefs, accessibility/display prefs, personalization | `user_preferences` table | Per-user row; merged with platform defaults |
| Notification Preferences | per-channel, per-category notification routing | `notification_preferences` table | Dedicated table (see Section 13) |

### 23.2 Settings Table Design

**`platform_settings`**: Uses a group/key/value structure or `spatie/laravel-settings` typed settings classes. Platform settings are few (<100), change rarely, and are cached. Each setting has a type (string, boolean, integer, json), a default value, and a description.

**`institution_settings`**: Per-institution settings stored as a JSON column or EAV pattern. Institutions may override platform defaults. Settings are loaded via an `InstitutionSettings` class that merges platform defaults with institution overrides.

**`user_preferences`**: Per-user preferences stored as a JSON column on the users table or a dedicated `user_preferences` table. User preferences merge with institution settings and platform defaults in a priority cascade: user > institution > platform.

### 23.3 spatie/laravel-settings Evaluation

`spatie/laravel-settings` provides typed settings classes with caching, validation, and a Filament integration. It is a strong candidate for platform/system settings and administrative settings. However, it may not be appropriate for per-entity settings (institution_settings) or per-user preferences (user_preferences) where the data is more dynamic and numerous. The package audit will determine: (1) does it support Laravel 13? (2) is it a good fit for our multi-tier settings architecture? If not, we implement a lightweight custom settings mechanism using typed PHP classes + database + cache.

### 23.4 What Is NOT a Setting

- Domain entity fields (institution name, programme title) — these are application data
- Notification classes and channels — these are code, not configuration
- Feature flags that control module availability — these are in .env/config, not the settings table
- Reference data (countries, currencies) — these are database tables, not settings
- Engagement data (saves, follows) — these are user behaviour data, not preferences

## 24. Implementation Phases

### 24.1 Phase Sequence (Dependency-Correct)

| Phase | Name | Duration | Dependencies | Done When |
|---|---|---|---|---|
| **1a** | Laravel foundation + Auth + RBAC + Reference Data | 3 weeks | None | Users can register/login; roles/permissions seeded; reference data importable |
| **1b** | Domain Layer | 3 weeks | 1a | All 10 domain tables migrated; 20 Actions tested; Policies enforce RBAC |
| **1c** | Content Layer | 2 weeks | 1b | 4 content models + 8 traits + Filament CRUD for content |
| **1d** | Public Site — Domain Pages | 3 weeks | 1b | Institution/programme/scholarship detail pages; programme discovery hubs |
| **1e** | Public Site — Content Pages | 2 weeks | 1c | Article/guide/resource/exam-prep pages; content listing pages |
| **1f** | Search (Typesense) | 1 week | 1b, 1c | 7 Typesense collections; Scout sync; autocomplete; search results page |
| **1g** | SEO | 1 week | 1d, 1e | Canonical URLs; sitemaps; structured data; robots meta; Open Graph |
| **1h** | Engagement | 1 week | 1d, 1e | Save, Follow, Like, Share; notification_preferences seeded |
| **1i** | Notifications | 1 week | 1h | 5 notification classes; DB + Email channels; WebPush flag |
| **2a** | Community Module | 3 weeks | 1d, 1i | Question + Answer + Comment + Vote + Report; feature flag |
| **2b** | Study Abroad Module | 2 weeks | 1d, 1c | Reference data for international; Livewire components; feature flag |
| **2c** | Comparison | 1 week | 1h | comparison_sets; Livewire compare UI |
| **2d** | Exam Preparation | 1 week | 1c | ExamPrep model + UI + download tracking |
| **3** | Advanced Features | TBD | All above | Posts/Channels, Reputation, Badges, AI, API, SMS notifications |

**Total Phase 1: ~17 weeks.** Auth-first dependency is critical: domain model tests need authenticated users to verify Policies, OrganizationMember is referenced by domain Policies, reference data is needed by seeders, and Spatie Permission roles must exist before Filament resources can check authorization.

### 24.2 Phase Dependencies Diagram

```
1a (Foundation)
  ├── 1b (Domain)
  │     ├── 1c (Content)
  │     │     └── 1e (Content Pages)
  │     ├── 1d (Domain Pages)
  │     └── 1f (Search)
  ├── 1g (SEO) ← depends on 1d + 1e
  └── 1h (Engagement) ← depends on 1d + 1e
        ├── 1i (Notifications)
        │     └── 2a (Community)
        └── 2c (Comparison)
2b (Study Abroad) ← depends on 1d + 1c
2d (Exam Prep) ← depends on 1c
```

## 25. Final Package Matrix (Laravel 13 Baseline)

All packages are evaluated against **Laravel 13 + PHP 8.5**. Packages whose compatibility cannot be confirmed are marked **UNVERIFIED**. A subsequent package audit will resolve all UNVERIFIED items before `composer install`.

### 25.1 Adopt Now

| # | Package | Version | Purpose | Verification |
|---|---|---|---|---|
| 1 | `spatie/laravel-permission` | **UNVERIFIED** | RBAC engine | Must verify Laravel 13 support |
| 2 | `spatie/laravel-medialibrary` | **UNVERIFIED** | File/media management | Must verify Laravel 13 + PHP 8.5 |
| 3 | `spatie/laravel-tags` | **UNVERIFIED** | Taxonomy/tagging | Must verify Laravel 13 support |
| 4 | `spatie/laravel-activitylog` | **UNVERIFIED** | Audit trail | Must verify Laravel 13 + PHP 8.5 |
| 5 | `spatie/laravel-sitemap` | **UNVERIFIED** | XML sitemaps | Must verify Laravel 13 + PHP 8.5 |
| 6 | `spatie/laravel-honeypot` | **UNVERIFIED** | Spam protection | Must verify Laravel 13 support |
| 7 | `spatie/laravel-backup` | **UNVERIFIED** | Database/file backup | Must verify Laravel 13 + PHP 8.5 |
| 8 | `spatie/laravel-webhook-client` | **UNVERIFIED** | Incoming webhooks | Must verify Laravel 13 support |
| 9 | `spatie/laravel-personal-data-export` | **UNVERIFIED** | GDPR data export | Must verify Laravel 13 support |
| 10 | `spatie/laravel-data` | **UNVERIFIED** | Data transfer objects | Must verify Laravel 13 support |
| 11 | `spatie/laravel-sluggable` | **UNVERIFIED** | Slug generation | Must verify Laravel 13 support |
| 12 | `spatie/laravel-searchable` | **UNVERIFIED** | Search abstraction | Must verify Laravel 13 support |
| 13 | `spatie/laravel-query-builder` | **UNVERIFIED** | API filtering/sorting | Must verify Laravel 13 support |
| 14 | `maatwebsite/excel` | **UNVERIFIED** | Import/export | Must verify Laravel 13 support |
| 15 | `laravel-notification-channels/webpush` | **UNVERIFIED** | Web Push notifications | Must verify Laravel 13 support |
| 16 | `laravel/socialite` | **UNVERIFIED** | Social login | Must verify Laravel 13 support |
| 17 | `laravel/sanctum` | **UNVERIFIED** | API token auth | Must verify Laravel 13 support |
| 18 | `laravel/pulse` | **UNVERIFIED** | Application monitoring | Must verify Laravel 13 support |
| 19 | `bezhansalleh/filament-shield  <!-- ⚠️ Corrected: was bezhansalam (typo) -->` | **UNVERIFIED** | Filament + Permission integration | Must verify Filament version + Laravel 13 |
| 20 | `pxlrbt/filament-activity-log  <!-- ⚠️ Corrected: was filament/spatie-laravel-activitylog-plugin (UNVERIFIED for v5); pxlrbt/filament-activity-log is the Filament v4/v5-compatible community standard -->` | **UNVERIFIED** | Activity log in admin | Must verify Filament version |

### 25.2 Adopt When Needed

| Package | Trigger | Verification |
|---|---|---|
| `spatie/laravel-settings` | When admin-configurable settings needed | **UNVERIFIED** |
| `spatie/laravel-responsecache` | When traffic volume justifies | **UNVERIFIED** |
| `spatie/laravel-markdown` | When community feature begins | **UNVERIFIED** |
| `spatie/eloquent-sortable` | When display ordering needed | **UNVERIFIED** |
| `laravel/horizon` | When queue monitoring needed | **UNVERIFIED** |
| `spatie/laravel-webhook-server` | When outbound webhooks needed | **UNVERIFIED** |
| `spatie/browsershot` | When PDF export needed | **UNVERIFIED** |
| `spatie/laravel-translation-loader` | When Africa expansion begins | **UNVERIFIED** |
| `spatie/laravel-welcome-notification` | When onboarding implemented | **UNVERIFIED** |

### 25.3 Evaluate Later

| Package | Concern |
|---|---|
| `spatie/laravel-rate-limits  <!-- ⚠️ INVALID/DOES NOT EXIST: use Laravel RateLimiter facade or spatie/laravel-rate-limited-job-middleware -->` | Laravel's RateLimiter may suffice |
| `spatie/laravel-csp` | Content Security Policy — not launch-blocking |
| `laravel/passkeys` | WebAuthn — evaluate in 12 months |
| `spatie/laravel-health` | May be redundant with K8s probes |

### 25.4 Rejected (12 packages)

| Package | Reason |
|---|---|
| `spatie/laravel-event-sourcing` | Contradicts ADR-02 |
| `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| `spatie/laravel-model-states` | Guard clauses + enums are LBC-idiomatic |
| `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| `spatie/laravel-fractal` | Superseded by laravel-data |
| `spatie/valuestore` | Superseded by laravel-settings |
| `spatie/laravel-view-models` | Superseded by laravel-data |
| `spatie/laravel-geocoder` | Typesense geo filter handles location |
| `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| `spatie/laravel-feeds` | Near-zero relevance |
| `wireui/wireui` | Unnecessary when using Flux |
| `spatie/laravel-ray` | Dev-only, never production |

### 25.5 Custom Implementation Justified

| Component | Rationale |
|---|---|
| OrganizationMember pivot | No package matches scoped membership with string role; bounded and testable |
| Community system | SO+Reddit hybrid too specific for generic packages; spatie/laravel-comments is too simple |
| Search projection sync | Domain events → Scout is Laravel-native; no package needed |
| SEO faceted URL strategy | Controlled indexation is a product concern; no generic package |

## 26. Final Architectural Inventory

### 26.1 Namespace Architecture

```
app/
  ├── Domain/
  │     ├── Models/          (10 Eloquent models: 5 aggregates + 3 child entities + 2 supporting)
  │     ├── Enums/           (20 PHP enums)
  │     ├── ValueObjects/    (14 non-enum VOs)
  │     ├── Events/          (29 domain events, plain PHP)
  │     ├── Exceptions/      (domain exceptions)
  │     └── Services/        (InstitutionMerger only)
  ├── Application/
  │     ├── Actions/         (20 domain Actions + content/community actions)
  │     ├── Queries/         (read-side query classes)
  │     ├── DTOs/            (spatie/laravel-data request/response objects)
  │     ├── Policies/        (Laravel authorization Policies)
  │     └── Listeners/       (event listeners for side effects)
  ├── Content/
  │     ├── Models/          (Article, Guide, EducationalResource, ExamPreparation)
  │     ├── Concerns/        (HasSlug, IsPublishable, HasSeoMeta, HasMedia, etc.)
  │     ├── Enums/           (ResourceType, PrepType, ContentStatus)
  │     ├── Actions/         (content-specific actions)
  │     └── Queries/         (content-specific queries)
  ├── Community/
  │     ├── Models/          (Question, Answer, Comment, Vote, Report)
  │     ├── Actions/         (community actions)
  │     └── Queries/         (community queries)
  ├── StudyAbroad/
  │     ├── Livewire/        (CountryPage, CompareDestinations, ScholarshipListing)
  │     └── Queries/         (study abroad queries)
  ├── Reference/
  │     ├── Models/          (Qualification, Country, Currency, etc.)
  │     └── Seeders/         (reference data seeders)
  ├── Infrastructure/
  │     ├── Search/          (Typesense/Scout config, UpdateSearchIndex listener)
  │     ├── Integrations/    (third-party API clients)
  │     └── Persistence/     (Eloquent scopes, custom query builders)
  └── Presentation/
        ├── Livewire/        (interactive components)
        ├── Blade/           (Blade components & views)
        └── Filament/        (admin panel resources)
```

### 26.2 Controllers (12)

| Controller | Routes |
|---|---|
| HomeController | / |
| InstitutionController | /institutions/{slug} |
| InstitutionProgrammeController | /institutions/{inst}/programmes |
| ProgrammeController | /institutions/{inst}/programmes/{prog} |
| ProgrammeDiscoveryController | /programmes, /programmes/{discipline} |
| ScholarshipController | /scholarships/{slug} |
| ArticleController | /news/{slug} |
| GuideController | /guides/{slug} |
| ResourceController | /resources/{slug} |
| ExamPrepController | /exam-prep/{slug} |
| StudyAbroadController | /study-abroad/* |
| CommunityQuestionController | /community/questions/* |

### 26.3 Feature Flags

| Flag | Default | Module |
|---|---|---|
| `features.community` | false | Community module |
| `features.study_abroad` | false | Study Abroad module |
| `features.web_push` | false | Web Push notifications |
| `features.sms` | false | SMS notifications |
| `features.exam_preparation` | false | Exam Preparation module |

## 27. Typesense Index Design

### 27.1 Collections (7)

| Collection | Source Model | Key Fields | Facet Fields | Sort Fields |
|---|---|---|---|---|
| institutions | Institution | name, slug, type, country, city, description | type, country, state_province | created_at, name |
| programmes | Programme | name, slug, level, discipline, institution_name, institution_slug, mode_of_study | level, discipline, institution_type, country, mode_of_study | created_at, name |
| scholarships | Scholarship | name, slug, amount, provider_name, coverage_type | coverage_type, provider_type, level, country | deadline, amount |
| articles | Article | title, slug, category, institution_name | category, resource_type | published_at |
| guides | Guide | title, slug, category | category | published_at |
| educational_resources | EducationalResource | title, slug, resource_type, discipline, academic_level | resource_type, discipline, academic_level | published_at |
| exam_preparations | ExamPreparation | title, slug, prep_type, exam_body, subject, year | prep_type, exam_body, subject, year | published_at |

### 27.2 Sync Mechanism

Domain events → `UpdateSearchIndex` listener → queued Scout job → Typesense upsert. Eventual consistency with ≤5s stale tolerance. On failure, the queued job retries with exponential backoff. Full reindex is available via `php artisan scout:import-all`.

### 27.3 Denormalization

Programme documents denormalize `institution_name`, `institution_slug`, `institution_type`, and `country` from the parent Institution to avoid join queries in Typesense. These fields are updated when the parent Institution changes via the `InstitutionRenamed` or `InstitutionUpdated` events, which trigger re-indexing of all child Programmes.

## 28. SEO Architecture

### 28.1 Canonical URLs

| Entity | Canonical URL | Indexable? | Sitemap? |
|---|---|---|---|
| Institution | `/institutions/{slug}` | Yes | Yes |
| Programme | `/institutions/{inst}/programmes/{slug}` | Yes | Yes |
| Scholarship | `/scholarships/{slug}` | Yes | Yes |
| Article | `/news/{slug}` | Yes | Yes |
| Guide | `/guides/{slug}` | Yes | Yes |
| Educational Resource | `/resources/{slug}` | Yes | Yes |
| Exam Preparation | `/exam-prep/{slug}` | Yes | Yes |
| Programme Discovery | `/programmes` | Yes | Yes (main listing) |
| Discipline Landing | `/programmes/{discipline}` | Yes | Yes (curated) |
| Discipline + Level | `/programmes/{discipline}/{level}` | Yes | Yes (curated) |
| Deep Filter Combos | >3 query params | **noindex, follow** | **No** |
| User Profiles | `/users/{id}` | **noindex** | **No** |
| Search Results | `/search?q=...` | **noindex** | **No** |
| Paginated Pages | `?page=2+` | **noindex** (page 2+) | **No** |

### 28.2 Structured Data (Schema.org)

| Model | Schema.org Type | Key Properties |
|---|---|---|
| Institution | `CollegeOrUniversity` | name, url, address, telephone, logo |
| Programme | `EducationalOccupationalProgram` | name, provider, offers, programPrerequisites |
| Scholarship | `Grant` | name, description, amount, provider, applicationDeadline |
| Article | `NewsArticle` | headline, datePublished, author, image |
| Guide | `Article` | headline, datePublished, author |
| EducationalResource | `LearningResource` | name, about, educationalLevel |
| ExamPreparation | `LearningResource` | name, about, educationalLevel |

### 28.3 Sitemap Partitions (7)

`sitemap-institutions.xml`, `sitemap-programmes.xml`, `sitemap-scholarships.xml`, `sitemap-articles.xml`, `sitemap-guides.xml`, `sitemap-resources.xml`, `sitemap-exam-prep.xml`

### 28.4 Meta Tags via HasSeoMeta Trait

Every content model and domain detail page renders: `<title>`, `<meta name="description">`, `<link rel="canonical">`, `<meta name="robots">`, Open Graph tags (`og:title`, `og:description`, `og:image`, `og:url`, `og:type`), Twitter Card tags (`twitter:card`, `twitter:title`, `twitter:description`, `twitter:image`), and JSON-LD structured data.

## 29. Media Architecture

StudyNexus uses `spatie/laravel-medialibrary` for all media management. This provides: file uploads with validation, image conversions (responsive sizes), media collections per model, disk configuration (local → S3), and media model with custom properties.

### 29.1 Media Collections

| Model | Collection | Conversions | Purpose |
|---|---|---|---|
| Institution | `logo` | thumb (200x200), medium (400x400) | Institution logo |
| Institution | `gallery` | thumb, medium, large (800x600) | Campus photos |
| Programme | `brochure` | None | Programme brochure PDF |
| Scholarship | `images` | thumb, medium | Scholarship promotional images |
| Article | `images` | thumb, medium, large | Article header + body images |
| Guide | `images` | thumb, medium, large | Guide illustrations |
| EducationalResource | `files` | None | Downloadable resources |
| ExamPreparation | `files` | None | Past question papers, study packs |
| User | `avatar` | thumb (100x100) | User profile photo |

### 29.2 Storage

- Development: local disk (`storage/app/public`)
- Production: S3-compatible object storage (AWS S3, DigitalOcean Spaces, or MinIO)
- Image conversions generated on upload via queued job

### 29.3 Security

- File type validation (whitelist: jpg, png, gif, pdf, doc, docx)
- Maximum file size per collection (configurable)
- Virus scanning on upload (Phase 3 consideration)
- Media deletions remove files from disk (no orphaned files)

## 30. Security and Privacy

### 30.1 Authentication

- Laravel Breeze (Blade stack) for auth scaffolding: registration, login, password reset, email verification
- `laravel/socialite` for Google and Microsoft OAuth (reduces registration friction)
- `laravel/sanctum` for future API/mobile token authentication
- Password strength enforcement via validation rules
- Account lockout after failed attempts (Laravel built-in throttling)

### 30.2 Authorization

- Full RBAC architecture per Section 18
- Scoped authorization prevents privilege escalation across institutions
- Self-protection: UI prevents last admin from demoting themselves

### 30.3 Data Protection

| Concern | Mechanism |
|---|---|
| Personal data export | `spatie/laravel-personal-data-export` — GDPR Article 20 + Nigerian NDPR |
| Activity logging | `spatie/laravel-activitylog` — audit trail for domain entity changes |
| Rate limiting | Laravel `RateLimiter` — per-IP and per-user |
| CSRF | Laravel + Livewire built-in CSRF token validation |
| Honeypot | `spatie/laravel-honeypot` on public forms |
| File upload security | Type whitelist + size limit + virus scan (Phase 3) |
| Input validation | Form Requests + Livewire validation + spatie/laravel-data DTOs |

### 30.4 Account Deletion

Users can request account deletion. The system: anonymizes the user's personal data (name → 'Deleted User', email → hashed placeholder), retains their community contributions (questions, answers) with author attribution changed to 'Deleted User', removes their engagement data (saves, follows, likes, comparisons), removes their organization memberships, and dispatches a `UserDeleted` event that triggers search index cleanup and notification cleanup.

### 30.5 Privacy Notice

Installing `spatie/laravel-personal-data-export` does not make the platform GDPR-compliant. Compliance requires: a privacy policy, consent mechanisms, data processing records, a Data Protection Officer (for organizations meeting the threshold), and regular audits. The package provides a technical capability; legal compliance is a separate obligation that must be verified by qualified counsel.

---

## Final Consistency Audit and Verdict

### 31.1 Internal Consistency Check

| Check | Result |
|---|---|
| Laravel 13 used everywhere | YES — Section 2 hard baseline; no Laravel 12 references remain |
| PHP 8.5 used everywhere | YES — Section 2 hard baseline; no PHP 8.3 assumptions remain |
| No React/Next.js/SPA references | YES — Section 6 explicitly forbids; TALL stack only |
| Filament is admin-facing only | YES — Section 6.1 boundary; never in public site |
| Livewire/Flux/Blade are user/public-facing | YES — Section 6.2 boundary table specifies when each is used |
| RBAC supports multiple institution administrators | YES — Section 18: OrganizationMember pivot; multiple users per institution |
| RBAC is dynamically manageable | YES — Section 18: string roles, not hard-coded enum; Filament UI for role management |
| User settings/preferences exist | YES — Section 23: multi-tier settings architecture; user_preferences table |
| Admin/system settings exist | YES — Section 23: platform_settings + institution_settings tables |
| Notification architecture exists | YES — Section 13: 5 notifications, 4 channels, preferences table |
| Engagement features exist | YES — Section 11: Save, Follow, Like, Compare, Share + deferred features |
| Comparison architecture exists | YES — Section 12: comparison_sets, Livewire, Phase 2c |
| Community architecture exists | YES — Section 15: SO+Reddit hybrid, feature-flagged |
| Content architecture exists | YES — Section 9: 4 models + 8 traits |
| Study Abroad architecture exists | YES — Section 10: composes existing entities, feature-flagged |
| Typesense architecture exists | YES — Section 7 + Section 27: 7 collections, event-driven sync |
| SEO architecture exists | YES — Section 28: canonical URLs, structured data, sitemaps |
| Institution programme hubs exist | YES — Section 8: /institutions/{inst}/programmes |
| Global programme discovery exists | YES — Section 8: /programmes, /programmes/{discipline} |
| Africa/global expansion supported | YES — Section 3: geographically neutral; expansion is data + enums |
| Samphina-derived capabilities don't duplicate domain | YES — Section 9 + Section 19: Nigerian concepts are enum values/reference data |
| Frozen domain model intact | YES — Section 21: 5 aggregates, 3 child entities, 2 supporting, 20 Actions, 29 events |
| Package names not fabricated | YES — Section 25: all UNVERIFIED; no invented packages |
| Uncertain versions marked UNVERIFIED | YES — Section 25: all packages UNVERIFIED pending audit |
| All 12 Doc 25 corrections applied | YES — Section 4: R1-R12 all documented with where-applied |
| No generic UserInteraction entity | YES — Section 11: each engagement type is separate model |
| No EducationalOpportunity entity | YES — Section 21: ADR-14 preserved |
| Content → Domain unidirectional | YES — Section 9.3: domain never imports content |
| Community → Domain unidirectional | YES — Section 15.3: domain never references community |

### 31.2 Remaining Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| 1 | Package incompatibility with Laravel 13 + PHP 8.5 | **High** | Package audit before composer install; UNVERIFIED protocol |
| 2 | Content scope creep | High | Behaviour Test: model justified by distinct behaviour, not distinct data |
| 3 | Livewire-overuse | Medium | Section 6 boundary rule; code review checklist |
| 4 | RBAC complexity growth | Medium | Start with 5 institution roles; add only when user research demands |
| 5 | Settings architecture over-engineering | Medium | Start simple; add tiers as needed |
| 6 | Polymorphic relationship performance at scale | Low | Explicit indexes; hot paths use explicit FKs |
| 7 | Typesense + PostgreSQL consistency | Low | ≤5s stale tolerance; Scout queue + retry |
| 8 | Feature flag drift | Low | Feature flags in .env; documented defaults |

### 31.3 Explicit List of Things That MUST NOT Be Built

| # | Forbidden | Reason |
|---|---|---|
| 1 | Repository pattern / persistence interface | ADR-04 |
| 2 | Event sourcing / event store | ADR-02 |
| 3 | SPA (React, Vue, Inertia, Next.js) | ADR-11 |
| 4 | Filament in public site | ADR-12 |
| 5 | God table (single contents table) | Doc 23 |
| 6 | Domain importing Content namespace | Doc 23 |
| 7 | Nigerian-specific entities (JambRequirement, etc.) | Doc 23 |
| 8 | ABAC (Attribute-Based Access Control) | Doc 21 |
| 9 | Generic UserInteraction entity | ADR-20 |
| 10 | EducationalOpportunity domain entity | ADR-14 |
| 11 | ForeignInstitution / VisaRequirement entity | Doc 23 |
| 12 | Share count tracking | ADR-25 |
| 13 | Custom notification framework | ADR-22 |
| 14 | Hard-coded administrator hierarchy | This document |
| 15 | Single-admin institution assumption | This document |
| 16 | Generic settings JSON dumping ground | This document |
| 17 | Typesense as canonical content storage | ADR-06, P9 |
| 18 | Package hallucination | This document |
| 19 | Business logic in Filament Resource hooks | Doc 20 |
| 20 | Business logic in Livewire components | Doc 20 |

### 31.4 Architectural Drift Guards

Any future coding agent working on StudyNexus must NOT:

- Add a new entity without behavioural justification (Behaviour Test)
- Add a new package without verifying its existence, maintenance, and Laravel 13 compatibility
- Add a repository without justification that overrides ADR-04
- Introduce React, Next.js, Vue, or Inertia anywhere
- Bypass scoped authorization (always check both global permission AND org membership)
- Hard-code role assumptions (roles are strings, not enums; they evolve)
- Create Nigeria-specific domain abstractions where a universal concept exists
- Make domain depend on presentation or content
- Use Typesense as the source of truth (PostgreSQL is authoritative)
- Create indexable URL combinations without SEO analysis
- Put every piece of data into a generic JSON settings table
- Make Livewire the default for every page (Blade first, Livewire when needed)

### 31.5 Change Log

| # | Change | Before (Doc 24/25) | After (Doc 26) | Source |
|---|---|---|---|---|
| 1 | Framework version | Laravel 12, PHP 8.3 | Laravel 13, PHP 8.5 | Hard baseline override |
| 2 | RBAC roles | 7 flat roles | 11 roles + scoped membership | R2 |
| 3 | Domain enums | 16 | 20 (added CoverageType, PolicyStatus, ProviderType, AuthorityType) | R3 |
| 4 | Value objects | 11 non-enum | 14 non-enum (added AuthorityJurisdiction, PhaseSequence, ValidityPeriod) | R4 |
| 5 | Qualification namespace | App\Domain\Models | App\Reference\Models | R5 |
| 6 | Programme discovery URLs | Missing | /programmes, /programmes/{discipline}, /programmes/{discipline}/{level} | R6 |
| 7 | Livewire boundary | Unspecified | Explicit boundary table | R7 |
| 8 | Engagement features | Save, Follow, Like | + Compare, Share, Hide, Alert | R8 |
| 9 | Notification preferences | Missing | notification_preferences table | R9 |
| 10 | Community moderation | Missing | community_reports table | R10 |
| 11 | Breeze version | ^1.x (invalid) | UNVERIFIED for Laravel 13 | R11 |
| 12 | Scholarship Schema.org | DatedMoneySpecification | Grant | R12 |
| 13 | Package versions | Specific versions for Laravel 12 | All UNVERIFIED for Laravel 13 | Baseline upgrade |
| 14 | Settings architecture | Missing | 4-tier: platform, admin, institution, user | This document |
| 15 | Table count | 48 (Doc 24) | 54 | All corrections + settings |

### 31.6 Unresolved Decisions

| # | Decision | Status | Resolution Path |
|---|---|---|---|
| 1 | Livewire version compatible with Laravel 13 | UNVERIFIED | Package audit |
| 2 | Flux version compatible with Laravel 13 | UNVERIFIED | Package audit |
| 3 | Filament version compatible with Laravel 13 + PHP 8.5 | UNVERIFIED | Package audit |
| 4 | All Spatie package versions for Laravel 13 | UNVERIFIED | Package audit |
| 5 | laravel/breeze version for Laravel 13 | UNVERIFIED | Package audit |
| 6 | maatwebsite/excel version for Laravel 13 | UNVERIFIED | Package audit |
| 7 | Email delivery provider (Mailgun vs Postmark vs SES) | Not selected | Evaluate during Phase 1i |
| 8 | spatie/laravel-settings adoption for settings | Under evaluation | Package audit + architecture fit |
| 9 | ADR-09 (Notification vs Event) | Deferred | Resolve when notification volume demands it |
| 10 | ADR-13 (Search Index Consistency) | Deferred | Resolve when sync failures exceed tolerance |

### 31.7 Final Verdict

> **READY FOR PACKAGE VERIFICATION**

The architecture is sound. The domain model is frozen. All 12 corrections from Document 25 are applied. The content layer is correctly separated. The TALL stack is confirmed. The RBAC is expanded and scoped. The settings architecture is defined. The notification architecture is complete. The implementation sequence is dependency-correct. The anti-patterns are enumerated. The drift guards are in place.

The only remaining gate is the **package verification audit**: confirming that every UNVERIFIED package in Section 25 has a version compatible with Laravel 13 + PHP 8.5, or identifying an alternative. Once the package audit is complete, implementation may begin.

**Implementation readiness score: 8.2/10** — improved from Doc 25's 8.0 after applying all corrections, adding settings architecture, and resolving the Laravel 13 baseline. The remaining 1.8 points are reserved for the package audit risk (1.0) and the inevitable discoveries during implementation (0.8).

### 31.8 Next Action

1. **Perform package verification audit** against Laravel 13 + PHP 8.5 for every UNVERIFIED item in Section 25
2. Resolve any incompatibilities (find alternatives, wait for releases, or contribute fixes)
3. Once all packages are verified, begin implementation with:

```bash
composer create-project laravel/laravel studynexus "13.*"
```