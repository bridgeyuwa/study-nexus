# StudyNexus — Historical Documentation Archive

**Warning:** These documents are historical records of the StudyNexus discovery and architecture process. They are **not authoritative implementation instructions**. Current canonical documentation takes precedence.

---

## Purpose

This archive preserves the provenance of the StudyNexus project. The documents here record the step-by-step discovery, review, validation, and reconciliation process that produced the current canonical architecture. They exist for traceability, auditing, and historical reference — not as working documentation.

## Authority Rule

If a canonical document conflicts with an archived document, the **canonical document wins**. Always.

Canonical documents are located in the parent directory:

| File | Purpose |
|------|---------|
| `01-business.md` | Business context, personas, capabilities, workflows, glossary |
| `02-decisions.md` | Approved decisions, ADRs, rejected alternatives, change proposal protocol |
| `03-domain.md` | Domain model: entities, VOs, events, Actions, enums, invariants, behaviours |
| `04-architecture.md` | Architecture: stack, RBAC, search, SEO, content, packages |
| `05-implementation.md` | Implementation blueprint: project structure, schemas, packages, phases |
| `06-data-acquisition.md` | Data acquisition and ingestion pipeline |

## Known Historical Divergences

The following known differences exist between archived and canonical documents. This is not an exhaustive list — any difference should be resolved in favor of the canonical document.

| Topic | Archived Position | Canonical Position | Reason |
|-------|------------------|--------------------|--------|
| Admission Pathway | Entity (file 18) | Value Object (demoted) | Behaviour discovery evidence; no independent invariants |
| Entity count | 10 (file 27) | 11 | Admission Pathway demoted to VO; Qualification confirmed as aggregate root |
| Value Object count | 34 (file 27) | 28 | Arithmetic correction; Admission Pathway demoted from entity |
| Enum count | 20 (file 27) | 16 | Audit corrected miscount |
| RBAC roles | 7 flat roles (file 21) | 11 scoped roles | Multi-admin-per-institution requirement |
| RBAC mechanism | `role_id` FK (file 23) | `role` string column | Organization-scoped roles are separate from global Spatie roles |
| `super-admin` | Used in file 23 | `platform-admin` | Canonical role name |
| Laravel version | 12 (file 26) | ^13.0 | Filament v5 / Livewire v4 require Laravel 13 |
| Filament version | v3 (files 21-26) | v5 | Laravel 13 compatibility |
| Livewire version | v3 (files 21-26) | v4 | Laravel 13 compatibility |
| Activity log plugin | `filament/spatie-laravel-activitylog-plugin` | `pxlrbt/filament-activity-log` v3.1.1 | Original plugin unverified for Filament v5 |
| `minimolabs/laravel-webpush` | Listed in file 27 | **INVALID/FABRICATED** | Package does not exist; use `laravel-notification-channels/webpush` |
| `bezhansalam/filament-shield` | Listed in file 23 | `bezhansalleh/filament-shield` | Typo in original |
| `filament/tiptap-editor` | Listed in file 27 | **DEPRECATED** | Use native Filament RichEditor |

## Archive Contents

| File | Original Purpose | Why Archived |
|------|-----------------|--------------|
| `00-documentation-audit-report.md` | Documentation audit (32 files) | Audit artifact; superseded by reconciliation |
| `00-reconciliation-proposal.md` | 196-issue reconciliation proposal | Proposal artifact; pruning now executing |
| `07-business-discovery-closure.md` | Business discovery closure report | Consolidated into `01-business.md` |
| `08-traceability-matrix.md` | 96-artifact traceability | Consolidated into `02-decisions.md` |
| `09-business-discovery-freeze.md` | Freeze principles | Consolidated into `02-decisions.md` |
| `11-domain-discovery-topic2.md` | Entity relationships (original Topic 2) | Superseded by Topic 2 Revision (file 12) |
| `12-domain-discovery-topic2-revision.md` | Revised aggregate boundaries | Consolidated into `03-domain.md` |
| `13-domain-discovery-consolidation.md` | Topics 1-3 consolidation | Consolidated into `03-domain.md` |
| `14-architectural-review-global-domain.md` | Global domain normalization | Consolidated into `03-domain.md` |
| `17-domain-integrity-review.md` | Critical design review | Consolidated into `03-domain.md` |
| `18-domain-resolution-analysis.md` | Integrity review resolutions | Consolidated into `03-domain.md` |
| `19-domain-architecture.md` | Original domain architecture | Superseded by frozen baseline (file 21) |
| `20-domain-architecture-validation.md` | Architecture validation & ADR review | Consolidated into `04-architecture.md` |
| `22-post-freeze-platform-architecture-review.md` | Platform/product architecture review | Consolidated into `04-architecture.md` |
| `23-laravel-ecosystem-build-vs-buy-review.md` | Build-vs-buy & Spatie review | Consolidated into `04-architecture.md` |
| `26-pre-implementation-reconciliation.md` | Adversarial reconciliation | Consolidated into `05-implementation.md` |

## Implementation Rule

**Agents implementing StudyNexus MUST use the canonical documentation rather than historical archive documents.** If an agent encounters conflicting instructions between canonical and archived documents, the canonical instruction takes absolute precedence.

Do not copy code samples from archived documents without verifying them against the canonical platform baseline (Laravel ^13.0, PHP 8.5, Filament v5, Livewire v4). Archived code samples may reference Filament v3 / Livewire v3 APIs that are incompatible with Laravel 13.
