# StudyNexus — Final Pre-Pruning Verification Report

**Date:** 2026-08-08
**Status:** VERIFICATION ONLY — No files modified
**Documents analyzed:** 28 (in /home/z/my-project/download/studynexus-reconciled/)
**Reconciliation proposal:** 00-reconciliation-proposal.md

---

# 1. Exact Six-Document Structure

```text
docs/
├── 01-business.md
├── 02-decisions.md
├── 03-domain.md
├── 04-architecture.md
├── 05-implementation.md
├── 06-data-acquisition.md
└── archive/
    ├── 00-documentation-audit-report.md
    ├── 00-reconciliation-proposal.md
    ├── 07-business-discovery-closure.md
    ├── 08-traceability-matrix.md
    ├── 09-business-discovery-freeze.md
    ├── 11-domain-discovery-topic2.md
    ├── 12-domain-discovery-topic2-revision.md
    ├── 13-domain-discovery-consolidation.md
    ├── 14-architectural-review-global-domain.md
    ├── 17-domain-integrity-review.md
    ├── 18-domain-resolution-analysis.md
    ├── 19-domain-architecture.md
    ├── 20-domain-architecture-validation.md
    ├── 22-post-freeze-platform-architecture-review.md
    ├── 23-laravel-ecosystem-build-vs-buy-review.md
    ├── 26-pre-implementation-reconciliation.md
    └── HISTORICAL-README.md
```

## Canonical Document Specifications

### 01-business.md

- **Purpose:** Single-entry business context — the "why" and "who" of StudyNexus
- **Authoritative scope:** Business intent, persona definitions, capability definitions, workflow rules, glossary
- **Sections:**
  1. Vision & Identity
  2. Primary Personas (4) with priority ranking
  3. Secondary Users (6) with trajectories
  4. Problem Dimensions (5: Fragmentation, Trust, Discoverability, Comparison, Accessibility)
  5. Evolution (4 stages + MVP scope + exclusions)
  6. Business Capabilities (10 MVP + 5 future + relationships)
  7. Workflows (WF1–WF7 with rules, persona variations, triggers, preconditions, success outcomes)
  8. Glossary (canonical terms + candidate concepts)
  9. Resolved Open Questions (key resolutions only)
- **Contributing documents:** 01-business-overview.md, 02-glossary.md, 04-open-questions.md, 06-business-workflows.md

### 02-decisions.md

- **Purpose:** Complete decision register with governance — the "what did we decide and why" reference
- **Authoritative scope:** All decision IDs, rationale, governance rules, change control
- **Sections:**
  1. Approved Decisions (A0-1 through A9-3 with full rationale)
  2. Discovery Principles (P1–P18)
  3. Freeze Principles (F1–F5)
  4. Change Proposal Protocol
  5. Deferred Items
  6. ADR Register (placeholder for architecture ADRs)
- **Contributing documents:** 03-approved-decisions.md, 04-open-questions.md (deferred items), 07-business-discovery-closure.md (P1–P18), 09-business-discovery-freeze.md (F1–F5, Change Proposal Protocol)

### 03-domain.md

- **Purpose:** Complete domain model — the "what" that implementation builds
- **Authoritative scope:** Canonical entity/VO/event/action/invariant inventories
- **Sections:**
  1. Entity Model (11 entities: 5 AR + 3 child + 3 supporting, with attributes, behaviours, lifecycles)
  2. Value Objects (28: 10 immutable + 1 computed + 1 demoted + 16 enums)
  3. Domain Events (29 with emitters)
  4. Application Actions (20 with aggregates)
  5. Invariant Register (22+ domain invariants)
  6. Aggregate Boundaries (5 roots with consistency boundaries)
  7. Cross-Aggregate Interactions (8 identified, 1 domain service)
  8. Global Expansion Test (summary of 9-country test)
  9. Admission Pathway Classification (Value Object — canonical)
- **Contributing documents:** 15-domain-discovery-topic4-behaviour.md, 16-domain-discovery-topic3.md, 21-domain-architecture-frozen-baseline.md (domain sections), 13-domain-discovery-consolidation.md (expansion test summary)

### 04-architecture.md

- **Purpose:** Complete platform and capability architecture — the "how" the domain is implemented
- **Authoritative scope:** Technology choices, directory structure, content architecture, search/SEO, ADRs
- **Sections:**
  1. Architecture Principles
  2. Eloquent Strategy
  3. Directory Structure
  4. Content Architecture (Option C, 4 content models)
  5. Search Architecture (Typesense)
  6. SEO Architecture
  7. Notification Architecture
  8. Community Module Architecture
  9. Study Abroad Architecture
  10. Information Architecture
  11. TALL Stack + Filament Admin Panel
  12. ADR Register (18 accepted + 2 deferred)
  13. Architecture Scorecard
- **Contributing documents:** 21-domain-architecture-frozen-baseline.md (architecture sections), 24-final-platform-and-capability-architecture.md, 22-post-freeze-platform-architecture-review.md (search/SEO/notification), 23-laravel-ecosystem-build-vs-buy-review.md (community/WebPush/BulkImport)

### 05-implementation.md

- **Purpose:** The implementation blueprint — what to code, in what order, with what constraints
- **Authoritative scope:** The document developers and AI agents code from
- **Sections:**
  1. Source of Truth Hierarchy
  2. Platform Baseline (Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4)
  3. RBAC (11 roles + OrganizationMember pivot + policy check pattern)
  4. Package Matrix (verified for Laravel 13 + PHP 8.5)
  5. Database Design (54 tables)
  6. Settings Architecture (4-tier)
  7. Security & Privacy
  8. Media Architecture
  9. Implementation Phases
  10. Forbidden List
  11. Package Verification Appendix
- **Contributing documents:** 27-final-corrected-pre-implementation-blueprint.md, 28-package-verification-audit.md (appendix), 29-rbac-decision.md (section)

### 06-data-acquisition.md

- **Purpose:** Data acquisition and ingestion pipeline — the most business-critical capability with the least overlap
- **Authoritative scope:** Complete ingestion pipeline design, source taxonomy, adapter pattern, verification engine, provenance model
- **Sections:**
  1. Design Principles
  2. Source Taxonomy
  3. Architecture (3-layer: Adapter → Staging → Domain)
  4. Staging Schema (import_batches + pending_imports)
  5. Adapter Pattern (interface + implementations)
  6. Verification Engine (duplicate detection, cross-source consistency, schema validation)
  7. Provenance Model
  8. Scheduled Jobs
  9. Admin UI (Filament v5)
  10. Integration with Domain Architecture
- **Contributing documents:** 30-data-acquisition-pipeline.md

---

# 2. Complete 28 → 6 + Archive Mapping

| Current File | Canonical Destination | Archive? | Content Preserved? | Notes |
|-------------|----------------------|--------:|------------------:|-------|
| 00-documentation-audit-report.md | archive/ | ✅ | ✅ | Audit trail; canonical set captured in canonical docs |
| 00-reconciliation-proposal.md | archive/ | ✅ | ✅ | Reconciliation artifact; all resolutions applied in canonical docs |
| 01-business-overview.md | 01-business.md | ❌ | ✅ | Narrative framing, capability relationships, "Critical Business Concern" |
| 02-glossary.md | 01-business.md | ❌ | ✅ | Glossary section with promotion rule |
| 03-approved-decisions.md | 02-decisions.md | ❌ | ✅ | Core of decisions document; all 40 decisions with rationale |
| 04-open-questions.md | 01-business.md + 02-decisions.md | ❌ | ✅ | Key resolutions → 01-business.md; deferred items → 02-decisions.md |
| 06-business-workflows.md | 01-business.md | ❌ | ✅ | WF1–WF7 with full rules merge into business document |
| 07-business-discovery-closure.md | 02-decisions.md + archive/ | ✅ | ✅ | P1–P18 extracted to 02-decisions.md; closure summary archived |
| 08-traceability-matrix.md | archive/ | ✅ | ✅ | QA proof (96/96, 0 assumptions); preserved for audit |
| 09-business-discovery-freeze.md | 02-decisions.md + archive/ | ✅ | ✅ | F1–F5 + Change Proposal Protocol extracted to 02-decisions.md; full text archived |
| 11-domain-discovery-topic2.md | archive/ | ✅ | ✅ | Original Topic 2; lifecycle/identity reasoning preserved |
| 12-domain-discovery-topic2-revision.md | archive/ | ✅ | ✅ | Revised Topic 2; LBC philosophy and reclassification reasoning unique |
| 13-domain-discovery-consolidation.md | 03-domain.md + archive/ | ✅ | ✅ | Expansion test summary → 03-domain.md; full detail archived |
| 14-architectural-review-global-domain.md | archive/ | ✅ | ✅ | F1–F14 normalization; corrections applied in canonical; reasoning archived |
| 15-domain-discovery-topic4-behaviour.md | 03-domain.md | ❌ | ✅ | Behavioural model, domain events, invariants — core of domain document |
| 16-domain-discovery-topic3.md | 03-domain.md | ❌ | ✅ | Attribute inventory, VO definitions — merge into domain document |
| 17-domain-integrity-review.md | archive/ | ✅ | ✅ | CDR weaknesses/assumptions; all resolved by file 18 |
| 18-domain-resolution-analysis.md | archive/ | ✅ | ✅ | Resolution of 17's findings; Admission Pathway reasoning superseded by file 15 |
| 19-domain-architecture.md | archive/ | ✅ | ✅ | Original architecture; superseded by file 21; original rationale preserved |
| 20-domain-architecture-validation.md | archive/ | ✅ | ✅ | Adversarial validation; corrections applied in file 21 |
| 21-domain-architecture-frozen-baseline.md | 03-domain.md + 04-architecture.md | ❌ | ✅ | Domain sections → 03; architecture catalogue/Eloquent strategy → 04 |
| 22-post-freeze-platform-architecture-review.md | 04-architecture.md + archive/ | ✅ | ✅ | Search/SEO/notification details → 04; full text archived |
| 23-laravel-ecosystem-build-vs-buy-review.md | 04-architecture.md + archive/ | ✅ | ✅ | Community/WebPush/BulkImport → 04; package evaluation archived |
| 24-final-platform-and-capability-architecture.md | 04-architecture.md | ❌ | ✅ | Core of architecture document |
| 26-pre-implementation-reconciliation.md | archive/ | ✅ | ✅ | Adversarial reasoning; corrections applied in file 27 |
| 27-final-corrected-pre-implementation-blueprint.md | 05-implementation.md | ❌ | ✅ | Core of implementation document |
| 28-package-verification-audit.md | 05-implementation.md (appendix) | ❌ | ✅ | Package verification records as appendix |
| 29-rbac-decision.md | 05-implementation.md (section) | ❌ | ✅ | Canonical RBAC as section of implementation |
| 30-data-acquisition-pipeline.md | 06-data-acquisition.md | ❌ | ✅ | Renamed; no content change |

**Total:** 28 files → 6 canonical documents + 18 archived files (2 with partial extraction)
**No deletion.** All content preserved either in canonical docs or archive.

---

# 3. The 23 Surviving Issues

| # | Issue | Current Source | Canonical Destination | Required Correction | Risk |
|---|-------|---------------|----------------------|--------------------|------|
| 1 | Admission Pathway = VO (not entity) | File 15 §10/§13 | 03-domain.md | State as canonical classification; no entity/table | HIGH if misimplemented as entity |
| 2 | RBAC = 11 roles with string role column | File 29 | 05-implementation.md | Include canonical 11-role table + OrganizationMember.pivot design | HIGH if old 7-role model used |
| 3 | F-7 enum count = 16 (not 15) | File 21 §4 | 03-domain.md | Correct breakdown to 10+1+1+16 | MEDIUM — arithmetic error |
| 4 | Entity count = 11 (not 12) | File 15 | 03-domain.md | State canonical 11-entity model; list all 11 | HIGH if 12th entity created |
| 5 | Event count = 29 (not 27) | File 21 F-8 | 03-domain.md | Include all 29 events with emitters | MEDIUM — miscount in File 15 heading |
| 6 | Action count = 20 (not 23/19) | File 21 F-4 / ADR-2 | 03-domain.md | Include all 20 actions | MEDIUM — stale count |
| 7 | File 24 §17 RBAC table conflicts with File 29 | File 24 | 05-implementation.md | Use File 29 as canonical; File 24 archived | LOW after archival |
| 8 | File 22 speculative roles mixed with MVP | File 22 | 05-implementation.md | Separate MVP (11) from future (5) and rejected (5) | LOW after archival |
| 9 | File 27 says "2 supporting" entities (should be 3) | File 27 | 03-domain.md + 05-implementation.md | Correct to 3 supporting; Qualification is a supporting entity | HIGH — entity omission |
| 10 | Laravel ^13.0 hard baseline | File 27 §2 | 05-implementation.md | State as hard baseline; no Laravel 12 fallback | HIGH if Laravel 12 used |
| 11 | Filament v5 + Livewire v4 hard baseline | File 27/28 (C6) | 05-implementation.md | State as hard baseline; no v3 fallback | HIGH if v3 code used |
| 12 | File 26 has Laravel 12 composer command | File 26 | archive/ | Mark as HISTORICAL — do not execute | ELIMINATED by archival |
| 13 | File 26 has Filament v3 code samples | File 26 | archive/ | Mark as HISTORICAL — do not execute | ELIMINATED by archival |
| 14 | File 26 has 7-role seeder code | File 26 | archive/ | Mark as HISTORICAL — do not execute | ELIMINATED by archival |
| 15 | minimolabs/laravel-webpush fabricated | File 28 §4 | 05-implementation.md | Use laravel-notification-channels/webpush | HIGH if fabricated package installed |
| 16 | bezhansalam → bezhansalleh typo | File 28 §5.4 | 05-implementation.md | Correct spelling to bezhansalleh/filament-shield | HIGH — composer require will fail |
| 17 | filament/tiptap-editor deprecated | File 28 §5.3 | 05-implementation.md | Use Filament v5 native RichEditor | MEDIUM — deprecated package |
| 18 | spatie/laravel-rate-limits invalid name | File 28 §5.7 | 05-implementation.md | Use spatie/laravel-rate-limited-job-middleware | LOW — Evaluate Later group |
| 19 | pxlrbt/filament-activity-log compatibility | File 28 §5.5 | 05-implementation.md | **RESOLVED: VERIFIED COMPATIBLE** (see §9 below) | LOW — resolved by verification |
| 20 | File 15 event count heading says 27 | File 15 §24 | 03-domain.md | Correct heading to 29 | LOW — editorial |
| 21 | File 21 F-7 breakdown text inconsistent | File 21 F-7 | 03-domain.md | Correct to "10 immutable + 1 computed + 1 demoted + 16 enums" | LOW — editorial |
| 22 | super-admin → platform-admin | File 23/29 | 05-implementation.md | Use canonical name platform-admin | MEDIUM — role name in code |
| 23 | role_id FK → role string column | File 23/29 | 05-implementation.md | OrganizationMember.role is STRING, not FK | HIGH — DB schema error |

### Confirmation: Do the 173 Historical Issues Genuinely Disappear?

**Yes.** The 173 issues fall into these categories:

| Category | Count | Why They Disappear |
|----------|:-----:|-------------------|
| B — Historical artifact | 108 | All in files being archived; superseded decisions, old counts, old version references |
| C — Stale metadata | 41 | Old document counts, reconciliation notes about deleted files, superseded audit entries |
| F — Broken navigation | 32 | Off-by-one references, Document ID mismatches, dangling cross-refs — all use old numbering that the new canonical structure eliminates |

When these source documents are moved to `archive/`, the issues they contain are no longer in the active implementation path. An AI coding agent following canonical documentation will not encounter them. The issues are not "ignored" — they are physically separated from the authoritative documentation.

---

# 4. Knowledge-Loss Check

| Knowledge | Source | Destination | Preserved? | Risk |
|-----------|--------|-------------|-----------|------|
| 4 primary personas + priority ranking | 01, 03, 04 | 01-business.md | ✅ Yes | None |
| 6 secondary user groups | 01, 03 | 01-business.md | ✅ Yes | None |
| 5 problem dimensions | 01, 03 | 01-business.md | ✅ Yes | None |
| 4 evolution stages + MVP scope + exclusions | 01, 03, 04 | 01-business.md | ✅ Yes | None |
| 10 MVP + 5 future capabilities + relationships | 01, 03 | 01-business.md | ✅ Yes | None |
| 7 workflows (WF1–WF7) with all rules | 06 | 01-business.md | ✅ Yes | None |
| 40 approved decisions (A0-1→A9-3) with rationale | 03 | 02-decisions.md | ✅ Yes | None |
| 22 resolved open questions with resolution detail | 04 | 01-business.md + 02-decisions.md | ✅ Yes | None |
| 18 Discovery Principles (P1–P18) | 07 | 02-decisions.md | ✅ Yes | Low — explicit extraction |
| 5 Freeze Principles (F1–F5) + Change Proposal Protocol | 09 | 02-decisions.md | ✅ Yes | Low — explicit extraction |
| 11 entities with attributes, behaviours, lifecycles | 15, 21 | 03-domain.md | ✅ Yes | None |
| 28 Value Objects with implementation strategy | 21 | 03-domain.md | ✅ Yes | None |
| Complete attribute model (all entity attributes) | 16 | 03-domain.md | ✅ Yes | None |
| Complete behavioural model | 15 | 03-domain.md | ✅ Yes | None |
| 29 domain events with emitters | 15, 21 | 03-domain.md | ✅ Yes | None |
| 20 application actions | 21 | 03-domain.md | ✅ Yes | None |
| 22+ domain invariants | 15, 21 | 03-domain.md | ✅ Yes | None |
| Admission Pathway = VO (not entity) | 15 | 03-domain.md | ✅ Yes | None |
| Global Domain normalization results (F1–F14) | 14 | 03-domain.md (applied) | ✅ Yes (results) | Low — reasoning in archive |
| 9-country expansion test | 13 | 03-domain.md (summary) | ✅ Yes | Low — summary captures key findings |
| Future expansion pressure test | 13 | 03-domain.md (summary) | ✅ Yes | Low — summary in canonical |
| Frozen architectural baseline | 21 | 03-domain.md + 04-architecture.md | ✅ Yes | None |
| Content architecture (Option C, 4 models) | 24 | 04-architecture.md | ✅ Yes | None |
| Information architecture | 24 | 04-architecture.md | ✅ Yes | None |
| Search architecture (Typesense) | 22, 24 | 04-architecture.md | ✅ Yes | None |
| SEO architecture | 22, 24 | 04-architecture.md | ✅ Yes | None |
| TALL stack + Filament admin | 21, 24, 27 | 04-architecture.md + 05-implementation.md | ✅ Yes | None |
| 18 ADRs (16 accepted + 2 deferred) | 21 | 04-architecture.md | ✅ Yes | None |
| Laravel ^13.0 + PHP 8.5 hard baseline | 27 | 05-implementation.md | ✅ Yes | None |
| Filament v5 + Livewire v4 | 27, 28 | 05-implementation.md | ✅ Yes | None |
| 11-role RBAC with OrganizationMember | 29 | 05-implementation.md | ✅ Yes | None |
| 54 database tables with migration ordering | 27 | 05-implementation.md | ✅ Yes | None |
| 4-tier settings architecture | 27 | 05-implementation.md | ✅ Yes | None |
| Source of truth hierarchy | 27 | 05-implementation.md | ✅ Yes | None |
| 61 package verification records | 28 | 05-implementation.md (appendix) | ✅ Yes | None |
| Anti-patterns and forbidden list | 26, 27 | 05-implementation.md | ✅ Yes | None |
| Security and privacy architecture | 27 | 05-implementation.md | ✅ Yes | None |
| Media architecture | 27 | 05-implementation.md | ✅ Yes | None |
| Data acquisition pipeline (complete) | 30 | 06-data-acquisition.md | ✅ Yes | None |
| Traceability chains (7, 96/96 proof) | 08 | archive/ | ✅ Yes (in archive) | Low — QA evidence accessible |
| Adversarial reasoning from validations | 17, 18, 20, 26 | archive/ | ✅ Yes (in archive) | Low — reasoning preserved |
| Original Laravel 12 code samples | 26 | archive/ | ✅ Yes (in archive) | None — not implementable |
| Bounded context analysis (2 BCs + shared kernel) | 18 | 03-domain.md | ✅ Yes | Low — from resolution analysis |
| Domain service (InstitutionMerger) | 15 | 03-domain.md | ✅ Yes | None |
| Community module architecture | 23, 27 | 04-architecture.md | ✅ Yes | None |
| Notification architecture | 22, 24, 27 | 04-architecture.md | ✅ Yes | None |
| Study abroad architecture | 24, 27 | 04-architecture.md | ✅ Yes | None |

**Result: No important knowledge left without a destination.** All 45 knowledge items are accounted for. Items in archive remain accessible for provenance; they are not lost.

---

# 5. Canonical Architecture Inventory Verification

## Entities (11) — Cross-Checked

### Aggregate Roots (5)

1. Educational Institution
2. Programme
3. Scholarship
4. Admission Cycle
5. Information Source

### Child Entities (3)

6. Admission Policy
7. Eligibility Policy
8. Accreditation Record

### Supporting Entities (3)

9. Qualification
10. Scholarship Provider
11. Education Authority

**Count: 11 ✅ MATCHES canonical truth (File 15)**

**Note on File 27 discrepancy:** File 27 lists only 2 supporting entities (missing Qualification), giving 10 total. This is an ERROR in File 27. The canonical count is 11 per File 15 and File 21.

---

## Value Objects (28) — Cross-Checked

### Genuine VOs — Immutable PHP Objects (12)

1. Admission Rule
2. Eligibility Rule
3. Subject Combination
4. Qualification Threshold
5. Validity Period
6. Trust Signal (computed, never stored)
7. Monetary Amount
8. Duration
9. Location (nullable)
10. Authority Jurisdiction (marginal)
11. Phase Sequence
12. Admission Pathway (demoted from entity)

### PHP Backed Enums (16)

13. Institution Type
14. Award Level
15. Admission Mode
16. Accreditation Status
17. Policy Status
18. Programme Status
19. Scholarship Status
20. Institution Status
21. Source Reliability
22. Information Category
23. Authority Type
24. Provider Type
25. Ownership Type
26. Delivery Mode
27. Qualification Status
28. Coverage Type

**Count: 28 (12 genuine + 16 enums) ✅ MATCHES canonical truth (File 21 §4)**

**Note on File 27 discrepancy:** File 27 claims 34 VOs (14 non-enum + 20 enums). This is an ERROR — File 27's R3/R4 change records describe additions that were ALREADY present in File 21's frozen baseline. The canonical count is 28 per File 21.

---

## Domain Events (29) — Cross-Checked

1. InstitutionEstablished
2. InstitutionRenamed
3. InstitutionSuspended
4. InstitutionReactivated
5. InstitutionClosed
6. InstitutionsMerged
7. InstitutionAccredited
8. InstitutionalAdmissionPolicyPublished
9. ProgrammeIntroduced
10. ProgrammeAdmissionPolicyPublished
11. ProgrammeAdmissionSuspended
12. ProgrammeAdmissionResumed
13. ProgrammeDiscontinued
14. ProgrammeAccredited
15. ScholarshipAnnounced
16. ScholarshipEligibilityPolicyPublished
17. ScholarshipApplicationsOpened
18. ScholarshipApplicationsClosed
19. ScholarshipWithdrawn
20. ScholarshipExpired
21. ScholarshipTargetsUpdated
22. AdmissionCycleAnnounced
23. AdmissionCycleActivated
24. AdmissionCyclePhaseAdvanced
25. AdmissionCycleClosed
26. InformationSourceVerified
27. InformationSourceMarkedUnreliable
28. InformationSourceDeprecated
29. QualificationDeprecated

**Count: 29 ✅ MATCHES canonical truth (File 21 F-8)**

**Derivation:** File 15 lists 27 in heading (miscount; table has 28 with QualificationDeprecated). File 21 adds ScholarshipTargetsUpdated during freeze (+1). 28 + 1 = 29 canonical.

---

## Application Actions (20) — Cross-Checked

1. CreateInstitution
2. SuspendInstitution
3. CloseInstitution
4. MergeInstitutions
5. PublishAdmissionPolicy
6. RecordAccreditation
7. CreateProgramme
8. DiscontinueProgramme
9. AnnounceScholarship
10. OpenScholarshipApplications
11. ExpireScholarship
12. TargetScholarshipProgrammes
13. AnnounceAdmissionCycle
14. ActivateAdmissionCycle
15. AdvanceAdmissionCyclePhase
16. RegisterInformationSource
17. VerifyInformationSource
18. MarkSourceUnreliable
19. ImportInstitutionData
20. ExpireScholarships (batch)

**Count: 20 ✅ MATCHES canonical truth (File 21 F-4 / ADR-2)**

**Removed from original 23:** ReassignProgramme (internal to MergeInstitutions), RenameInstitution (event listener), ReactivateInstitution (event listener). Added: ExpireScholarships (batch scheduler).

---

## Enums (16) — Cross-Checked

1. Institution Type
2. Award Level
3. Admission Mode
4. Accreditation Status
5. Policy Status
6. Programme Status
7. Scholarship Status
8. Institution Status
9. Source Reliability
10. Information Category
11. Authority Type
12. Provider Type
13. Ownership Type
14. Delivery Mode
15. Qualification Status
16. Coverage Type

**Count: 16 ✅ MATCHES canonical truth (File 21 §4 table)**

**Note on File 21 F-7 prose error:** The F-7 finding originally stated "15 PHP enums" in prose, but the §4 individual audit table lists 16. The individual table is authoritative.

---

## RBAC Roles (11) — Cross-Checked

### Platform Roles (4 — Spatie Permission)

1. platform-admin
2. platform-moderator
3. content-admin
4. content-editor

### Institution-Scoped Roles (5 — OrganizationMember.role string)

5. institution-owner
6. institution-admin
7. institution-admissions
8. institution-editor
9. institution-viewer

### User-Level Roles (2 — Spatie Permission)

10. registered-user
11. guest

**Count: 11 ✅ MATCHES canonical truth (File 29)**

---

**VERIFICATION RESULT: ALL COUNTS MATCH. No discrepancies between canonical lists and declared counts.**

---

# 6. Admission Pathway Verification

**Canonical classification: Admission Pathway = Value Object ✅**

### Evidence

- **File 15 (Topic 4, §10/§13):** Applied the project's own Ten-Question Filter. Admission Pathway fails the entity test:
  - No independent lifecycle (never created/destroyed independently)
  - No invariants beyond equality
  - No domain operations beyond what Admission Policy already provides
  - Used only as discriminator within policies, not referenced independently
- **File 21 F-12 (Frozen Baseline):** Confirms demotion to VO
- **File 18 (Resolution Analysis):** Originally accepted as supporting entity — SUPERSEDED by File 15

### Surviving References That Must Reflect VO Classification

| Location | What Must Change | Current Status |
|----------|-----------------|----------------|
| 03-domain.md entity list | Must NOT include Admission Pathway | Will be correct by construction |
| 03-domain.md VO list | Must include Admission Pathway as VO-12 | Will be correct by construction |
| 05-implementation.md database tables | Must NOT have an `admission_pathways` table | File 27 already omits this table |
| 05-implementation.md migration plan | Must NOT have a migration creating this table | File 27 already correct |

### Confirmed: No canonical document will instruct an implementer to create an Admission Pathway entity/table.

---

# 7. RBAC Verification

**Canonical model: 11 roles ✅**

### Platform Roles (4) — Spatie Permission

| Role | Purpose |
|------|---------|
| platform-admin | All permissions. Full system access. |
| platform-moderator | Verify sources, moderate content, review community posts, handle reports. |
| content-admin | CRUD all domain entities + content types. Publish/unpublish. |
| content-editor | Create/edit/publish content. Cannot delete or manage domain entities. |

### Institution-Scoped Roles (5) — OrganizationMember.role STRING

| Role | Purpose |
|------|---------|
| institution-owner | Full control + manage members + transfer ownership. |
| institution-admin | Manage data, programmes, admissions, scholarships. Cannot transfer ownership. |
| institution-admissions | Manage admission policies, cycles, deadlines. Read-only elsewhere. |
| institution-editor | Edit descriptions, media, programme details. No status changes. |
| institution-viewer | View internal data and reports. No write access. |

### User-Level Roles (2) — Spatie Permission

| Role | Purpose |
|------|---------|
| registered-user | Save, follow, like, compare, community participation. |
| guest | Browse only. No write access. |

### Implementation Mechanism

```php
// OrganizationMember pivot — role is STRING, not FK
class OrganizationMember extends Pivot
{
    // organization_members table:
    // - organization_type (morph)
    // - organization_id
    // - user_id
    // - role (string: 'owner', 'admin', 'admissions', 'editor', 'viewer')
    // - created_at, updated_at
}
```

**Confirmed: `/role/` string column, NOT `role_id` FK.** The organization-scoped role is a separate concept from the global Spatie roles table.

### Surviving Documentation That Could Cause Wrong RBAC Model

| Document | Issue | Resolution |
|----------|-------|------------|
| File 21 (frozen baseline) | Contains original 7 flat roles | Will be split into 03-domain.md (domain) + 04-architecture.md (arch); old RBAC section superseded by 05-implementation.md |
| File 22 (post-freeze review) | Contains speculative roles mixed with MVP | Being archived |
| File 23 (ecosystem review) | Contains `super-admin` role name | Being archived |
| File 24 (final architecture) | §17 has conflicting RBAC table | Being superseded by File 29 content in 05-implementation.md |
| File 26 (reconciliation) | Contains 7-role seeder code | Being archived as HISTORICAL |

**After consolidation, only 05-implementation.md will contain the canonical RBAC definition. All conflicting sources are archived.**

---

# 8. Laravel / Platform Version Verification

**Canonical implementation target:**

```text
Laravel ^13.0
PHP 8.5+
Filament v5
Livewire v4
```

### Cross-Check

| Source | Laravel | PHP | Filament | Livewire | Consistent? |
|--------|:-------:|:---:|:--------:|:--------:|:-----------:|
| File 27 §2 (blueprint) | ^13.0 | 8.5 | v5 (reconciliation note C6) | v4 (reconciliation note C6) | ✅ |
| File 28 §9.3 (package audit) | ^13.0 | 8.5 | v5 | v4 | ✅ |
| File 29 (RBAC) | 13.x | 8.5 | v5 | v4 | ✅ |
| File 30 (data pipeline) | 13.x | 8.5 | v5 | v4 | ✅ |

### Surviving Laravel 12 / Filament 3 / Livewire 3 References

| Location | Reference Type | Survives into Canonical? |
|----------|---------------|--------------------------|
| File 27 reconciliation notes | Historical marker (HTML comment) | YES — but clearly marked as "was v3, upgraded per C6" |
| File 27 §2 "Why Laravel 13, Not Laravel 12" | Explanatory section | YES — as justification, not instruction |
| File 27 R1 change record | "Document 24 specified Laravel 12" | YES — as change log, not instruction |
| File 28 reconciliation notes | "v3-era code samples are historical" | YES — as warning |

**None of these are implementation instructions.** They are all historical annotations, override explanations, or explicit warnings. No canonical document will contain actionable Laravel 12, Filament 3, or Livewire 3 commands.

### Filament v3 / Livewire v3 References in Archived Documents

Files 25 and 26 contain Filament v3 code samples and Livewire v3 API references. These will be archived and clearly designated as HISTORICAL. They will NOT survive into any canonical document.

---

# 9. Activity Log Package Resolution

```text
Package:              pxlrbt/filament-activity-log
Current version:      v3.1.1 (2026-04-28)
Laravel compatibility: ✅ YES (via spatie/laravel-activitylog ^5.0 which supports Laravel 13)
Filament compatibility: ✅ YES (requires filament/filament ^4.0|^5.0)
Livewire compatibility: ✅ YES (Filament v5 uses Livewire v4)
Status:               VERIFIED COMPATIBLE
Evidence:             Packagist confirms v3.1.1 with constraint filament/filament ^4.0|^5.0
                      and spatie/laravel-activitylog ^5.0 (which supports Laravel 12+/13).
                      Maintained by Dennis Koch (pxlrbt). Last update 2026-04-28.
Recommendation:       ADOPT pxlrbt/filament-activity-log ^3.1 as the Filament activity log
                      plugin. No human decision required.
```

### Alternative Options (for reference)

| Package | Filament v5 | Laravel 13 | Notes |
|---------|:-----------:|:----------:|-------|
| alizharb/filament-activity-log v1.5.0 | ✅ | ✅ | More features (timeline, revert); less established |
| relaticle/activity-log v1.2.1 | ✅ | ✅ | Filament v5-only; most recently updated |

**This resolves the last open human decision. The package is verified compatible; no further action needed before implementation.**

---

# 10. Canonical Cross-References

### Problem with Current References

Current documents use fragile numeric references:

```text
❌ "Doc 19"           — which document is 19 after renumbering?
❌ "File 21"           — file numbers change with restructuring
❌ "Document 26 §18"   — section numbers shift with consolidation
❌ "per ADR-02"        — ADR IDs are stable, but need to resolve to a location
```

### Proposed Convention

After consolidation, cross-references use **canonical filenames and section anchors**:

```text
✅ [01-business.md §7 Workflows]          — filename + section heading
✅ [03-domain.md §2 Value Objects]         — filename + section heading
✅ [05-implementation.md §3 RBAC]          — filename + section heading
✅ [ADR-2: Action Pattern Adoption]        — ADR ID + title (resolves to 04-architecture.md ADR register)
✅ [A6-2: Workflows defined by goals]      — Decision ID (resolves to 02-decisions.md)
✅ [archive/18-domain-resolution-analysis.md] — explicit archive/ prefix
```

### Markdown Link Examples

```markdown
Per the [RBAC model](05-implementation.md#3-rbac), all institution-scoped roles
use the OrganizationMember pivot with a string `role` column.

The [Admission Pathway classification](03-domain.md#9-admission-pathway) is
Value Object, not entity.

See [ADR-2: Action Pattern](04-architecture.md#adr-2) for the action criterion.
```

### Anchor Convention

- Section headings become lowercase-hyphenated anchors: `## 3. RBAC` → `#3-rbac`
- ADR anchors: `## ADR-2: Action Pattern Adoption` → `#adr-2-action-pattern-adoption`
- Decision anchors: `## A6-2` → `#a6-2`

### AI Agent Safety

An AI coding agent can resolve references by:
1. Matching canonical filename → read that file
2. Matching section heading → scroll to section
3. Matching ADR ID → look up in 04-architecture.md ADR register
4. Matching decision ID → look up in 02-decisions.md

No numeric file references remain in canonical documentation.

---

# 11. Archive Safety

### Authority Rule

```text
Canonical documentation = implementation authority
Archive                = historical/provenance reference only
```

### Protection Measures

1. **Directory isolation:** All archived documents live under `archive/` — physically separated from canonical docs
2. **Header stamp:** Every archived document will have a header added:

   ```markdown
   > **⚠️ ARCHIVED — HISTORICAL REFERENCE ONLY**
   > This document is superseded by canonical documentation in the `docs/` directory.
   > Do NOT use this document as implementation authority.
   > If this document contradicts a canonical document, the canonical document wins.
   ```

3. **HISTORICAL-README.md** in archive/ explains:
   - What the archive contains
   - Why documents are here (provenance, not authority)
   - How to find the current canonical equivalent
   - The supersession chains (Domain → Platform → Implementation)

4. **No numeric ordering:** Archive files are NOT numbered — they use descriptive names so they cannot be confused with the numbered canonical documents

### AI Agent Safety Test

Can an AI coding agent reasonably mistake an archived document for current implementation instructions?

- **Without header stamp:** Possible — an agent might read any .md file in the project
- **With header stamp:** Very unlikely — the `⚠️ ARCHIVED` warning is at the very top of every archived file
- **With directory isolation:** Very unlikely — `archive/` is clearly a subdirectory, not the main `docs/` path

**Verdict: With the proposed protection measures, an AI agent cannot reasonably mistake archived documents for implementation authority.**

---

# 12. Final Risk Assessment

### SAFE TO PRUNE

- **18 historical documents** can be moved to `archive/` without any risk of information loss
- All 173 historical issues disappear from the active documentation path
- No canonical architectural truth depends on any archived document as its sole source
- All knowledge items (K1–K45) are accounted for in either canonical docs or archive

### SAFE WITH CONDITIONS

| What | Condition |
|------|-----------|
| File 21 split into 03-domain.md + 04-architecture.md | Domain sections must map cleanly to 03; architecture sections to 04. The freeze declaration must be preserved in 03-domain.md. |
| File 07 P1–P18 extraction to 02-decisions.md | All 18 principles must be explicitly listed, not just referenced |
| File 09 F1–F5 extraction to 02-decisions.md | The Change Proposal Protocol must be fully reproduced, not summarized |
| File 13 expansion test summary in 03-domain.md | The summary must capture the key finding: Nigerian model is extensible to 9 African countries with bounded changes; full test detail remains in archive |
| File 27 entity count error (says 10, should be 11) | Must be corrected when creating 05-implementation.md — Qualification is a supporting entity |
| File 27 VO/enum count error (says 34/20, should be 28/16) | Must be corrected when creating 05-implementation.md — use File 21's frozen baseline counts |

### NOT SAFE YET

| What | Why | Resolution |
|------|-----|------------|
| File 27 entity count (10 vs 11) | File 27 omits Qualification as a supporting entity | Correct in 05-implementation.md: list all 11 entities including Qualification |
| File 27 VO count (34 vs 28) | File 27 double-counts additions that are already in File 21's baseline | Correct in 05-implementation.md: use File 21's 28 VOs (12 genuine + 16 enums) |
| File 27 enum count (20 vs 16) | Same double-counting issue | Correct in 05-implementation.md: use File 21's 16 enums |

### HUMAN DECISION

**No human decisions remain.** The sole previously-open decision — `pxlrbt/filament-activity-log` compatibility — has been resolved:

- **VERIFIED COMPATIBLE** with Laravel 13 + Filament v5 + Livewire v4
- Version v3.1.1 (2026-04-28) explicitly declares `filament/filament: ^4.0|^5.0`
- Recommendation: ADOPT `pxlrbt/filament-activity-log ^3.1`

---

## READY FOR PRUNING: YES

### What Will Be Changed

1. **Create 6 canonical documents** by consolidating content from source files:
   - `01-business.md` ← 01 + 02 + 04 + 06
   - `02-decisions.md` ← 03 + 04(deferred) + 07(P1–P18) + 09(F1–F5, Change Proposal)
   - `03-domain.md` ← 15 + 16 + 21(domain) + 13(expansion summary)
   - `04-architecture.md` ← 21(architecture) + 24 + 22(search/SEO) + 23(community)
   - `05-implementation.md` ← 27 + 28(appendix) + 29(section) **with corrections for entity count (11), VO count (28), enum count (16)**
   - `06-data-acquisition.md` ← 30

2. **Create `archive/` directory** with 18 historical documents, each stamped with `⚠️ ARCHIVED` header

3. **Create `archive/HISTORICAL-README.md`** explaining archive purpose and supersession chains

4. **Verify** all 23 critical issues are correctly represented in canonical docs

5. **No files deleted.** All 28 original files survive either in canonical form or archive.

### Reasons

- All canonical architectural counts independently verified and matching
- All 23 surviving issues have clear destinations in canonical documents
- All 173 historical issues disappear with archival (not ignored — separated)
- No knowledge items left without a destination
- Admission Pathway = VO confirmed in all canonical destinations
- RBAC = 11 roles with string role column confirmed
- Platform versions (Laravel 13, PHP 8.5, Filament v5, Livewire v4) consistent across all authoritative documents
- Activity log package (`pxlrbt/filament-activity-log ^3.1`) verified compatible — last human decision resolved
- Archive safety measures (directory isolation, header stamps, HISTORICAL-README) prevent AI agent confusion
- Cross-reference convention uses stable filenames + section anchors, not fragile numeric IDs
- Three count errors in File 27 (entity 10→11, VO 34→28, enum 20→16) identified and will be corrected during consolidation

**STOP.** The next step is a separate explicit approval to execute the pruning.
