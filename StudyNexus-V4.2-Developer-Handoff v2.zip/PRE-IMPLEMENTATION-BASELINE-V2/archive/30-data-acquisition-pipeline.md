# Document 30: Data Acquisition & Ingestion Pipeline

**Date:** 2026-08-08
**Status:** Canonical design — addresses audit finding §17.3 (most business-critical capability, least architected)
**Authority:** Derived from Business Capability #1 ("Acquire Educational Information"), OQ2-5 resolution, and domain architecture (file 21)
**Platform baseline:** Laravel 13.x + PHP 8.5 + Filament v5 + Livewire v4

---

## 1. Design Principles

1. **Source of truth is the domain model.** Ingestion writes to domain aggregates through their public API (Actions, domain methods). Never bypass aggregate invariants by writing directly to tables.
2. **Ingestion does not modify canonical data without verification.** Every imported record enters a staging workflow. Only verified records update the canonical store.
3. **The system does not depend on active data feeds from agencies.** Per OQ2-5, information is primarily aggregated from public and official sources. Direct feeds are future enhancements.
4. **Idempotency is mandatory.** Re-running the same import must produce the same result. No duplicate entities, no double-counting, no side effects on re-import.
5. **Provenance is recorded for every data point.** Every entity and attribute carries source metadata: where it came from, when it was acquired, its verification status, and its trust classification.

---

## 2. Source Taxonomy

| Source Type | Examples | Access Method | Trust Level | Priority |
|-------------|----------|---------------|-------------|----------|
| **Official Registry** | JAMB, WAEC, NECO, NABTEB, NBTE, NUC | Public website, PDF reports, occasional API | High (Official) | P0 — day one |
| **Institution Website** | University of Lagos, UNIBEN, OAU, etc. | Web scraping (with rate limiting and respect for robots.txt) | Medium (Unverified → Verified after check) | P0 — day one |
| **Accreditation Body** | NUC, NBTE, NCCE | Published accreditation lists | High (Official) | P0 — day one |
| **Government Open Data** | FME, State MOE, UBEC | PDF, CSV, occasional portal | Medium-High (Official, may be stale) | P1 — post-MVP |
| **Scholarship Provider** | PTDF, Shell, MTN Foundation, State governments | Provider websites, press releases | Medium (Unverified initially) | P1 — post-MVP |
| **Community Contribution** | User reports, corrections | User submission via reporting workflow (OQ4-2) | Low (Community-Contributed) | P2 — when user accounts exist |
| **Data Partner (future)** | Direct API from institutions/agencies | Authenticated API, SFTP, webhook | High (Verified) | P3 — when partnerships exist |

---

## 3. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                     EXTERNAL SOURCES                                │
│  JAMB  WAEC  NUC  Institution Sites  Scholarship Sites  ...        │
└──────┬──────┬──────┬──────────┬──────────────┬──────────────────────┘
       │      │      │          │              │
┌──────▼──────▼──────▼──────────▼──────────────▼──────────────────────┐
│                    ADAPTER LAYER                                    │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐             │
│  │ PDF Parser  │  │ Web Scraper  │  │ CSV/JSON Parser│             │
│  │ (smalot/pdf)│  │ (spatie/crawler)│ │ (maatwebsite/excel)│       │
│  └──────┬──────┘  └──────┬───────┘  └──────┬────────┘             │
│         │                │                  │                       │
│         └────────────────┼──────────────────┘                       │
│                          ▼                                          │
│               ┌──────────────────────┐                              │
│               │  Normalized DTO      │                              │
│               │  (Source-agnostic)   │                              │
│               └──────────┬───────────┘                              │
└──────────────────────────┼──────────────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    STAGING LAYER                                    │
│  ┌──────────────────────┐  ┌─────────────────────┐                │
│  │  pending_imports     │  │  import_batches      │                │
│  │  (raw + normalized)  │  │  (batch tracking)    │                │
│  └──────────┬───────────┘  └──────────┬──────────┘                │
│             │                         │                             │
│  ┌──────────▼─────────────────────────▼──────────┐                 │
│  │         VERIFICATION ENGINE                   │                 │
│  │  • Duplicate detection (fuzzy matching)       │                 │
│  │  • Cross-source consistency check              │                 │
│  │  • Schema validation (domain rules)            │                 │
│  │  • Conflict detection & flagging               │                 │
│  └──────────┬────────────────────────────────────┘                 │
└─────────────┼───────────────────────────────────────────────────────┘
              │
              ▼  (verified records only)
┌─────────────────────────────────────────────────────────────────────┐
│                    DOMAIN LAYER (existing)                          │
│  ImportInstitutionData Action → Institution::establish()           │
│  RecordAccreditation Action    → Institution::recordAccreditation()│
│  RegisterInformationSource     → InformationSource::register()     │
│  VerifyInformationSource       → InformationSource::verify()       │
│                                                                     │
│  Events emitted: InstitutionEstablished, InstitutionAccredited,    │
│  InformationSourceVerified, etc. → UpdateSearchIndex               │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 4. Staging Schema

### 4.1 `import_batches`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Batch identity |
| `source_type` | string | Source taxonomy entry (e.g., "jamb_official", "institution_website") |
| `source_url` | string, nullable | URL or file path of the source |
| `adapter_class` | string | Fully qualified adapter class name |
| `status` | enum | `pending`, `parsing`, `parsed`, `verifying`, `verified`, `applying`, `completed`, `failed` |
| `total_records` | int | Records found in source |
| `verified_records` | int | Records that passed verification |
| `rejected_records` | int | Records that failed verification |
| `conflict_records` | int | Records that conflict with existing data |
| `applied_records` | int | Records successfully applied to domain |
| `started_at` | timestamp | When processing began |
| `completed_at` | timestamp, nullable | When processing completed |
| `error_log` | json, nullable | Structured error details |
| `metadata` | json | Source-specific metadata (scrape headers, PDF page count, etc.) |
| `created_by` | string | User or system process that initiated the import |

### 4.2 `pending_imports`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Record identity |
| `batch_id` | UUID (FK) | Parent batch |
| `entity_type` | string | Target domain entity (Institution, Programme, Scholarship, etc.) |
| `raw_data` | json | Raw data from source (before normalization) |
| `normalized_data` | json | Normalized, source-agnostic DTO |
| `verification_status` | enum | `pending`, `verified`, `rejected`, `conflict`, `duplicate` |
| `verification_notes` | json, nullable | Structured verification results |
| `matching_entity_id` | UUID, nullable | If matched to existing entity (for updates/duplicates) |
| `match_confidence` | float, nullable | Fuzzy match confidence score (0.0–1.0) |
| `applied_at` | timestamp, nullable | When record was applied to domain |
| `provenance` | json | Source, acquired_at, trust_level, verification_history |

---

## 5. Adapter Pattern

Each source type gets a dedicated adapter that implements a common interface:

```php
interface SourceAdapter
{
    /**
     * Fetch raw data from the external source.
     */
    public function fetch(SourceConfiguration $config): RawSourceData;

    /**
     * Normalize raw data into source-agnostic DTOs.
     */
    public function normalize(RawSourceData $raw): Collection; // Collection<NormalizedInstitutionDTO>

    /**
     * Validate a normalized record against domain rules.
     */
    public function validate(NormalizedDTO $dto): ValidationResult;
}
```

### Adapter Implementations

| Adapter | Source | Fetch Method | Key Challenges |
|---------|--------|-------------|----------------|
| `JambOfficialAdapter` | JAMB brochure/site | PDF download + parse | PDF structure varies by year; programme names differ from institutional names |
| `NucAccreditationAdapter` | NUC accreditation list | PDF/HTML parse | Accreditation status is time-bounded; must match to existing institutions |
| `InstitutionWebsiteAdapter` | Individual institution sites | Web scrape (spatie/crawler) | No standard schema; rate limiting; robots.txt compliance; structure changes |
| `ScholarshipProviderAdapter` | Provider websites | Web scrape | Press releases are unstructured; deadlines change frequently |
| `WaecResultAdapter` | WAEC official data | PDF/CSV parse | Subject code mapping; qualification equivalence |
| `CsvBulkImportAdapter` | Any CSV source | File upload + maatwebsite/excel | Column mapping; encoding; delimiter detection |

---

## 6. Verification Engine

### 6.1 Duplicate Detection

When a normalized record matches an existing entity:

| Match Confidence | Action |
|:---------------:|--------|
| ≥ 0.95 | **Auto-merge**: Update existing entity with new data (fields that changed only) |
| 0.80–0.94 | **Flag for review**: Present both records to a content admin for manual merge decision |
| 0.50–0.79 | **Likely different**: Create as new entity, but flag for spot-check |
| < 0.50 | **Distinct**: Create as new entity |

**Fuzzy matching strategy** (for institutions):
1. Exact match on JAMB code or NUC code (if available) → confidence = 1.0
2. Normalized name similarity (Levenshtein/TF-IDF) + same state + same type → confidence 0.80–0.95
3. Name similarity alone → confidence 0.50–0.79

### 6.2 Cross-Source Consistency

When two sources disagree on the same fact:

| Scenario | Resolution |
|----------|-----------|
| Official source says X, unofficial says Y | **Official wins.** Record unofficial as `InformationSource(MarkedUnreliable)` if contradiction is material. |
| Two official sources disagree | **Flag as conflict.** Do not auto-resolve. Present to content admin. Both sources retain their provenance. |
| New data contradicts verified existing data | **Flag for review.** Do not overwrite verified data without explicit admin approval. |

### 6.3 Schema Validation

Before a record enters the domain, validate it against the aggregate's invariants:
- Required fields present and non-empty
- Enum values are valid members of the target PHP enum
- Monetary amounts ≥ 0
- Dates are parseable and within reasonable ranges
- Location data has valid ISO 3166-1 country code (NG for Nigeria in MVP)
- Admission rule structure matches the expected rule type

---

## 7. Import Workflow

### 7.1 Automated Import (scheduled)

```
1. Scheduler triggers ImportJob for a configured source
2. ImportJob::handle()
   a. Create import_batches record (status: pending)
   b. Adapter::fetch() — retrieve raw data
   c. Update batch: status = parsing
   d. Adapter::normalize() — convert to DTOs
   e. Write to pending_imports (status: pending)
   f. Update batch: status = parsed, total_records = count
3. VerificationJob::handle()
   a. Update batch: status = verifying
   b. For each pending_import:
      - Duplicate detection → match_confidence, matching_entity_id
      - Cross-source consistency check
      - Schema validation
      - Set verification_status (verified/rejected/conflict/duplicate)
   c. Update batch counters
4. ApplicationJob::handle()
   a. Update batch: status = applying
   b. For each verified record:
      - Dispatch domain Action (ImportInstitutionData, etc.)
      - Action invokes aggregate method → emits domain event
   c. Update batch: status = completed, applied_records
```

### 7.2 Manual Import (admin-initiated)

1. Admin uploads a CSV/PDF via Filament admin panel
2. System creates an `import_batches` record with the uploaded file
3. Admin reviews the batch: sees total records, can preview normalized data
4. Admin triggers verification → same VerificationJob
5. Admin reviews flagged records (conflicts, low-confidence matches)
6. Admin resolves conflicts manually (merge, reject, create new)
7. Admin approves and applies → same ApplicationJob

---

## 8. Provenance Model

Every entity in the canonical store carries provenance metadata:

```php
// On every domain entity (via HasProvenance trait):
[
    'provenance' => [
        'source_type'       => 'jamb_official',
        'source_url'        => 'https://jamb.gov.ng/2026-brochure.pdf',
        'acquired_at'       => '2026-08-08T10:00:00Z',
        'last_verified_at'  => '2026-08-08T10:00:00Z',
        'trust_level'       => InformationCategory::Official,  // Official, Verified, Historical, CommunityContributed
        'verification_status' => SourceReliability::Verified,
        'import_batch_id'   => 'uuid-of-batch',
    ]
]
```

**Provenance is immutable once recorded.** If a field is updated from a different source, the old provenance is archived (not overwritten) and the new source is recorded. This provides a full audit trail of where every data point originated.

---

## 9. Scheduling & Operations

| Job | Schedule | Source | Queue |
|-----|----------|--------|-------|
| `JambBrochureImportJob` | Monthly (or on-demand when new brochure detected) | JAMB | `imports` |
| `NucAccreditationImportJob` | Quarterly (accreditation updates are periodic) | NUC | `imports` |
| `InstitutionWebsiteCrawlJob` | Weekly (detect changes to programme listings) | Institution sites | `imports` (rate-limited) |
| `ScholarshipProviderCrawlJob` | Weekly (detect new/changed scholarships) | Provider sites | `imports` (rate-limited) |
| `StaleDataDetectionJob` | Daily (flag entities not updated within threshold) | Internal | `maintenance` |
| `SearchIndexRebuildJob` | After each successful batch | Internal | `search` |

**Rate limiting:** All web-scraping jobs respect per-domain rate limits (configurable, default: 1 request/second per domain). Uses Laravel's `RateLimiter` facade. Respects `robots.txt`.

**Failure handling:** If a source becomes unavailable or returns unexpected data, the batch fails gracefully. The error is logged in `import_batches.error_log`. No partial data is applied — a batch is atomic: either all verified records are applied, or none are (with manual override available for partial application after admin review).

---

## 10. Required Packages

| Package | Version | Purpose | Already in Stack? |
|---------|---------|---------|:-----------------:|
| `spatie/crawler` | ^1.0 | Web scraping with rate limiting and robots.txt support | **NEW** |
| `smalot/pdfparser` | ^2.0 | PDF parsing for official brochures/lists | **NEW** |
| `maatwebsite/excel` | ^3.1 | CSV/Excel import for bulk data | ✅ Already adopted |
| `laravel/scout` | ^4.0 | Search index management after imports | ✅ Already adopted |
| `spatie/laravel-activitylog` | ^4.0 | Audit trail for all import operations | ✅ Already adopted |
| `spatie/laravel-rate-limited-job-middleware` | ^1.0 | Queue job rate limiting for crawl jobs | **NEW** |

**No fabricated packages.** All new additions are verified real packages from established vendors (Spatie, Smalot).

---

## 11. Admin UI (Filament v5)

| Resource | Purpose |
|----------|---------|
| `ImportBatchResource` | View all import batches, status, counts, error logs. Trigger re-runs. |
| `PendingImportResource` | View/resolve individual pending records. Manual merge/reject/approve. |
| `InformationSourceResource` | Manage source registry (add/edit/disable sources, configure adapters). |

**Authorization:** Only `platform-admin` and `content-admin` can initiate imports. `content-editor` can view batches and resolve conflicts but not apply changes. Institution-scoped users cannot modify imports (imports are a platform-level operation).

---

## 12. Integration with Existing Domain Architecture

This pipeline integrates with the existing domain through the **already-defined Actions**:

| Pipeline Step | Domain Action Invoked | Aggregate Method |
|---------------|----------------------|-----------------|
| New institution from import | `CreateInstitution` | `Institution::establish()` |
| Accreditation from import | `RecordAccreditation` | `Institution::recordAccreditation()` or `Programme::recordAccreditation()` |
| New programme from import | `CreateProgramme` | `Programme::introduce()` |
| Source verification | `VerifyInformationSource` | `InformationSource::verify()` |
| Source flagged unreliable | `MarkSourceUnreliable` | `InformationSource::markUnreliable()` |
| Batch data import | `ImportInstitutionData` | Orchestrates multiple creates/updates |

**No new domain Actions are introduced.** The ingestion pipeline is an application-layer orchestration that feeds data through the existing domain API.

---

*This document resolves audit finding §17.3. The data-acquisition pipeline is now architected to the same depth as the domain core and search/SEO layers.*
