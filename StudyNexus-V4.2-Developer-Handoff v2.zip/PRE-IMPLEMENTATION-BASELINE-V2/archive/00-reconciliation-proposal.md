# StudyNexus — Reconciliation & Consolidation Proposal

**Date:** 2026-08-08  
**Status:** ANALYSIS ONLY — No files modified  
**Audit issues identified:** 196  
**Issues requiring survival into canonical docs:** 23  
**Issues that disappear with consolidation:** 173  

---

## 1. Executive Summary

The StudyNexus documentation archive contains 28 files (after 5 safe deletions). These documents faithfully record a rigorous discovery pipeline, but the pipeline is now complete. The documents that served the pipeline (reviews, validations, reconciliations, revisions) are provenance artifacts that should not be treated as working documentation.

**Key findings:**

- The archive contains **6 authoritative documents** whose content must be preserved as-is or consolidated
- **18 documents** are historical/review/reconciliation artifacts that belong in an archive
- Of the 196 audited issues, **only 23** need to survive into the consolidated documentation — the remaining 173 disappear when their source documents are archived
- **5 canonical resolutions** are required before consolidation can begin
- **1 human decision** is needed (Filament activity log plugin for v5)

**Canonical truth is well-established.** The StudyNexus architecture has clear authority chains and the audit found no unresolved architectural contradictions — only historical drift from superseded decisions.

---

## 2. Canonical Architecture Inventory

### Platform

| Component | Canonical Version | Source | Historical |
|-----------|:-----------------:|--------|------------|
| Laravel | **^13.0** | File 27 §2 (hard baseline override) | 12.* in files 25–26 |
| PHP | **8.5+** | File 27 §2 | 8.3 in files 25–26 |
| PostgreSQL | **16+** | File 27 §2 | — |
| Redis | **7+** | File 27 §2 | — |
| Typesense | **29.x** | File 27 §2 | — |
| Livewire | **^4.0** | File 28 §9.3 (verified) | ^3.0 in files 25–26 |
| Filament | **v5.x** | File 27/28 reconciliation note (C6) | v3 in files 19–26 |
| Tailwind CSS | **^4.0** | File 27 §2 | — |
| Alpine.js | **^3.x** | File 27 §2 | — |
| Node.js | **22 LTS** | File 27 §2 | — |

### Domain Entities

| ID | Entity | Classification | Aggregate Root | Key Invariants |
|----|--------|---------------|:--------------:|---------------|
| ENT-01 | Educational Institution | Aggregate Root | ✅ | INV-I1–I5 |
| ENT-02 | Programme | Aggregate Root | ✅ | INV-P1–P6 |
| ENT-03 | Scholarship | Aggregate Root | ✅ | INV-S1–S5 |
| ENT-04 | Admission Cycle | Aggregate Root | ✅ | INV-C1–C3 |
| ENT-05 | Information Source | Aggregate Root | ✅ | INV-IS1–IS3 |
| ENT-06 | Admission Policy | Child Entity | — | Immutable after publication |
| ENT-07 | Eligibility Policy | Child Entity | — | Immutable after publication |
| ENT-08 | Accreditation Record | Child Entity | — | Immutable after creation |
| ENT-09 | Qualification | Supporting Entity | — | Reference data |
| ENT-10 | Scholarship Provider | Supporting Entity | — | Weakest entity |
| ENT-11 | Education Authority | Supporting Entity | — | Reference data with jurisdiction |

**Count: 11 entities (5 AR + 3 child + 3 supporting)**

### Value Objects

| ID | Value Object | Type | Behavioural? |
|----|-------------|------|:------------:|
| VO-01 | Admission Rule | Immutable PHP Object | Yes |
| VO-02 | Eligibility Rule | Immutable PHP Object | Yes |
| VO-03 | Subject Combination | Immutable PHP Object | Yes |
| VO-04 | Qualification Threshold | Immutable PHP Object | Yes |
| VO-05 | Validity Period | Immutable PHP Object | Yes |
| VO-06 | Monetary Amount | Immutable PHP Object | Yes |
| VO-07 | Duration | Immutable PHP Object | Yes |
| VO-08 | Location | Immutable PHP Object (nullable) | Yes |
| VO-09 | Authority Jurisdiction | Immutable PHP Object | Marginal |
| VO-10 | Phase Sequence | Immutable PHP Object | Yes |
| VO-11 | Trust Signal | Computed (never stored) | N/A |
| VO-12 | Admission Pathway | Immutable PHP Object (demoted from entity) | No |
| VO-13 | Institution Type | PHP BackedEnum | Yes |
| VO-14 | Award Level | PHP BackedEnum | Yes |
| VO-15 | Admission Mode | PHP BackedEnum | Yes |
| VO-16 | Accreditation Status | PHP BackedEnum | No |
| VO-17 | Policy Status | PHP BackedEnum | No |
| VO-18 | Programme Status | PHP BackedEnum | No |
| VO-19 | Scholarship Status | PHP BackedEnum | No |
| VO-20 | Institution Status | PHP BackedEnum | No |
| VO-21 | Source Reliability | PHP BackedEnum | No |
| VO-22 | Information Category | PHP BackedEnum | No |
| VO-23 | Authority Type | PHP BackedEnum | No |
| VO-24 | Provider Type | PHP BackedEnum | No |
| VO-25 | Ownership Type | PHP BackedEnum | No |
| VO-26 | Delivery Mode | PHP BackedEnum | No |
| VO-27 | Qualification Status | PHP BackedEnum | No |
| VO-28 | Coverage Type | PHP BackedEnum | No |

**Count: 28 VOs (10 immutable + 1 computed + 1 demoted + 16 enums)**

### Domain Events

| ID | Event | Emitter |
|----|-------|---------|
| EVT-01 | InstitutionEstablished | Institution |
| EVT-02 | InstitutionRenamed | Institution |
| EVT-03 | InstitutionSuspended | Institution |
| EVT-04 | InstitutionReactivated | Institution |
| EVT-05 | InstitutionClosed | Institution |
| EVT-06 | InstitutionsMerged | InstitutionMerger |
| EVT-07 | InstitutionAccredited | Institution |
| EVT-08 | InstitutionalAdmissionPolicyPublished | Institution |
| EVT-09 | ProgrammeIntroduced | Programme |
| EVT-10 | ProgrammeAdmissionPolicyPublished | Programme |
| EVT-11 | ProgrammeAdmissionSuspended | Programme |
| EVT-12 | ProgrammeAdmissionResumed | Programme |
| EVT-13 | ProgrammeDiscontinued | Programme |
| EVT-14 | ProgrammeAccredited | Programme |
| EVT-15 | ScholarshipAnnounced | Scholarship |
| EVT-16 | ScholarshipEligibilityPolicyPublished | Scholarship |
| EVT-17 | ScholarshipApplicationsOpened | Scholarship |
| EVT-18 | ScholarshipApplicationsClosed | Scholarship |
| EVT-19 | ScholarshipWithdrawn | Scholarship |
| EVT-20 | ScholarshipExpired | Scholarship |
| EVT-21 | ScholarshipTargetsUpdated | Scholarship |
| EVT-22 | AdmissionCycleAnnounced | AdmissionCycle |
| EVT-23 | AdmissionCycleActivated | AdmissionCycle |
| EVT-24 | AdmissionCyclePhaseAdvanced | AdmissionCycle |
| EVT-25 | AdmissionCycleClosed | AdmissionCycle |
| EVT-26 | InformationSourceVerified | InformationSource |
| EVT-27 | InformationSourceMarkedUnreliable | InformationSource |
| EVT-28 | InformationSourceDeprecated | InformationSource |
| EVT-29 | QualificationDeprecated | Qualification |

**Count: 29 domain events**

### Application Actions

| ID | Action | Aggregate(s) |
|----|--------|-------------|
| ACT-01 | CreateInstitution | Institution |
| ACT-02 | SuspendInstitution | Institution |
| ACT-03 | CloseInstitution | Institution |
| ACT-04 | MergeInstitutions | Institution ×2, Programme ×N |
| ACT-05 | PublishAdmissionPolicy | Programme or Institution |
| ACT-06 | RecordAccreditation | Programme or Institution |
| ACT-07 | CreateProgramme | Programme, Institution |
| ACT-08 | DiscontinueProgramme | Programme |
| ACT-09 | AnnounceScholarship | Scholarship |
| ACT-10 | OpenScholarshipApplications | Scholarship |
| ACT-11 | ExpireScholarship | Scholarship |
| ACT-12 | TargetScholarshipProgrammes | Scholarship, Programme |
| ACT-13 | AnnounceAdmissionCycle | AdmissionCycle |
| ACT-14 | ActivateAdmissionCycle | AdmissionCycle |
| ACT-15 | AdvanceAdmissionCyclePhase | AdmissionCycle |
| ACT-16 | RegisterInformationSource | InformationSource |
| ACT-17 | VerifyInformationSource | InformationSource |
| ACT-18 | MarkSourceUnreliable | InformationSource |
| ACT-19 | ImportInstitutionData | Multiple |
| ACT-20 | ExpireScholarships | Scholarship ×N (batch) |

**Count: 20 application actions**

### RBAC Roles

| ID | Role | Scope | MVP? | Mechanism |
|----|------|-------|:----:|-----------|
| ROL-01 | platform-admin | Platform (global) | ✅ | Spatie Permission |
| ROL-02 | platform-moderator | Platform (global) | ✅ | Spatie Permission |
| ROL-03 | content-admin | Platform (global) | ✅ | Spatie Permission |
| ROL-04 | content-editor | Platform (global) | ✅ | Spatie Permission |
| ROL-05 | institution-owner | Institution-scoped | ✅ | OrganizationMember.role (string) |
| ROL-06 | institution-admin | Institution-scoped | ✅ | OrganizationMember.role (string) |
| ROL-07 | institution-admissions | Institution-scoped | ✅ | OrganizationMember.role (string) |
| ROL-08 | institution-editor | Institution-scoped | ✅ | OrganizationMember.role (string) |
| ROL-09 | institution-viewer | Institution-scoped | ✅ | OrganizationMember.role (string) |
| ROL-10 | registered-user | User-level | ✅ | Spatie Permission |
| ROL-11 | guest | User-level | ✅ | Spatie Permission |

**Count: 11 roles (4 platform + 5 institution-scoped + 2 user)**

---

## 3. Resolved Count Matrix

### Entities: 12 → 11

```
12 entities (files 13, 18 — pre-Topic 4)
    ↓
Admission Pathway added as supporting entity (+1) — file 18
    ↓
Topic 4 Behaviour Discovery (file 15) — Admission Pathway has no lifecycle,
no invariant, no behaviour beyond equality comparison
    ↓
Admission Pathway DEMOTED to Value Object (−1 entity, +1 VO)
    ↓
11 entities (5 AR + 3 child + 3 supporting) — CANONICAL
```

### Value Objects: 27 → 28

```
25 VOs (file 16 — Topic 3, pre-resolution)
    ↓
Admission Mode added (+1) — file 18 Finding 2
Country added as reference wrapper (+1) — file 18 Finding 4
    ↓
27 VOs (file 18 — Resolution Analysis)
    ↓
Admission Pathway demoted from entity (+1 VO) — file 15
    ↓
28 VOs (10 immutable + 1 computed + 1 demoted + 16 enums) — CANONICAL
```

### Domain Events: 27 → 29

```
27 events (file 15 §24 heading — miscounted; actual table has 28)
    ↓
ScholarshipTargetsUpdated added during freeze (+1) — file 21
    ↓
29 events (file 21 F-8) — CANONICAL
```

### Application Actions: 23 → 20

```
23 Actions (file 19 — original architecture)
    ↓
ReassignProgramme removed (internal to MergeInstitutions) −1
RenameInstitution removed (handled by event listener) −1
ReactivateInstitution removed (handled by event listener) −1
ExpireScholarships added (batch scheduler) +1
    ↓
20 Actions (file 21 F-4, ADR-2) — CANONICAL
```

### Enums: 15 → 16

```
15 enums (file 21 F-7 — arithmetic error in prose)
    ↓
CoverageType added by file 26 Change R3
    ↓
16 PHP Backed Enums (file 21 §4 individual audit table) — CANONICAL
```

---

## 4. Admission Pathway Resolution

```
Previous classification: Supporting Entity (file 18 §1, accepted)
Current classification: Value Object (file 15 §10/§13, demoted)
Reason for change: Behaviour Discovery (file 15) applied the project's own
  Ten-Question Filter. Admission Pathway fails the entity test:
  - No independent lifecycle (never created/destroyed independently)
  - No invariants beyond equality
  - No domain operations beyond what Admission Policy already provides
  - Used only as discriminator within policies, not referenced independently
  The structural analysis in file 18 could not detect this because it
  predates behaviour discovery.
Superseded documents: File 17 (RI-1 recommends as entity), File 18 (Finding 1
  accepts as entity), File 13 (confirms as entity "with reservation")
Canonical authority: File 15 (Topic 4 Behaviour Discovery) §10/§13,
  confirmed by File 21 F-12 (frozen baseline)
```

---

## 5. RBAC Resolution

### MVP Roles (11 — all canonical)

| Role | Scope | Purpose | Mechanism |
|------|-------|---------|-----------|
| platform-admin | Global | Full system access | Spatie Permission |
| platform-moderator | Global | Verify sources, moderate content, handle reports | Spatie Permission |
| content-admin | Global | CRUD all domain entities + content; publish/unpublish | Spatie Permission |
| content-editor | Global | Create/edit/publish content; cannot delete domain entities | Spatie Permission |
| institution-owner | Scoped | Full control + manage members + transfer ownership | OrganizationMember.role string |
| institution-admin | Scoped | Manage data, programmes, admissions, scholarships | OrganizationMember.role string |
| institution-admissions | Scoped | Manage admission policies, cycles, deadlines; read-only elsewhere | OrganizationMember.role string |
| institution-editor | Scoped | Edit descriptions, media, programme details; no status changes | OrganizationMember.role string |
| institution-viewer | Scoped | View internal data and reports; no write | OrganizationMember.role string |
| registered-user | User | Save, follow, like, compare, community participation | Spatie Permission |
| guest | User | Browse only; no write | Spatie Permission |

### Future Roles (NOT in MVP — data additions, not code changes)

| Role | Scope | Origin | Status |
|------|-------|--------|--------|
| provider-admin | Scholarship Provider | File 22 §5 | Speculative — no Scholarship Provider aggregate in MVP |
| provider-staff | Scholarship Provider | File 22 §5 | Speculative — same |
| authority-admin | Education Authority | File 22 §5 | Speculative — no Education Authority aggregate in MVP |
| authority-staff | Education Authority | File 22 §5 | Speculative — same |
| guardian | User | File 22 §5 | Speculative — no requirement |

### Rejected

| Role | Origin | Reason |
|------|--------|--------|
| super-admin | File 23 §6 | Replaced by platform-admin (File 29) |
| Content Contributor | File 24 §17 | No canonical equivalent; content-editor covers this |
| Community Moderator | File 24 §17 | platform-moderator covers this |
| student | File 22 §5 | registered-user is canonical |
| tutor | File 22 §5 | No requirement |

### Permissions Model

- **Global roles:** Spatie Permission (`spatie/laravel-permission ^6.0`)
- **Scoped roles:** OrganizationMember pivot with `role` STRING column (not FK)
- **Admin policies:** Filament Shield (`bezhansalleh/filament-shield`)
- **API tokens:** Laravel Sanctum (`laravel/sanctum ^4.0`)
- **Object-level:** Laravel Policies (first-party)

---

## 6. Laravel Version Resolution

```
Canonical Laravel version: ^13.0
Canonical PHP version: 8.5+
Historical versions: Laravel 12.x + PHP 8.3 (files 25–26)
Reason for transition: Product owner mandate; Laravel 13 is current stable;
  all packages must be compatible; no fallback
Current implementation target: Laravel 13 + PHP 8.5 + PostgreSQL 16 + Redis 7
```

Historical Laravel 12 references in files 25–26 are correctly identified as
historical by reconciliation notes. They do NOT need individual repair — those
files will be archived. The implementation blueprint (file 27) already uses
Laravel 13 as the hard baseline.

---

## 7. Package Resolution

### Approved (Adopt Now — 20 packages)

All verified for Laravel 13 + PHP 8.5 per file 28 §9.3:

spatie/laravel-permission ^6.0, spatie/laravel-medialibrary ^11.0, spatie/laravel-tags ^4.0, spatie/laravel-activitylog ^5.0, spatie/laravel-sitemap ^7.0, spatie/laravel-honeypot ^4.0, spatie/laravel-backup ^9.0, spatie/laravel-webhook-client ^3.0, spatie/laravel-personal-data-export ^4.0, spatie/laravel-data ^4.0, spatie/laravel-sluggable ^4.0, spatie/laravel-searchable ^3.0, spatie/laravel-query-builder ^3.0, maatwebsite/excel ^3.1, laravel-notification-channels/webpush ^8.0, laravel/socialite ^5.0, laravel/sanctum ^4.0, laravel/pulse ^1.0, bezhansalleh/filament-shield (corrected spelling), pxlrbt/filament-activity-log (UNVERIFIED for v5 — needs human decision)

### Adopt When Needed (9)

spatie/laravel-settings, spatie/laravel-responsecache, spatie/laravel-markdown, spatie/eloquent-sortable, laravel/horizon, spatie/laravel-webhook-server, spatie/browsershot, spatie/laravel-translation-loader, spatie/laravel-welcome-notification

### Evaluate Later (4)

spatie/laravel-rate-limited-job-middleware, spatie/laravel-csp, laravel/passkeys, spatie/laravel-health

### Rejected (12)

spatie/laravel-event-sourcing, spatie/laravel-comments, spatie/laravel-model-states, spatie/laravel-newsletter, spatie/laravel-fractal, spatie/valuestore, spatie/laravel-view-models, spatie/geocoder (was "laravel-geocoder"), spatie/laravel-menu, spatie/laravel-feed (was "laravel-feeds"), wireui/wireui, spatie/laravel-ray

### Fabricated/Invalid → Corrected

| Invalid Package | Status | Replacement | Action |
|----------------|--------|-------------|--------|
| minimolabs/laravel-webpush | FABRICATED | laravel-notification-channels/webpush ^8.0 | Replace |
| bezhansalam/filament-shield | TYPO | bezhansalleh/filament-shield | Correct spelling |
| filament/tiptap-editor | DEPRECATED | Filament v5 native RichEditor | Replace |
| spatie/laravel-rate-limits | INVALID NAME | spatie/laravel-rate-limited-job-middleware | Replace |
| filament/spatie-laravel-activitylog-plugin | WRONG PACKAGE | pxlrbt/filament-activity-log | Replace |

---

## 8. Issue Reclassification

Of 196 issues, classified by survival necessity:

| Category | Count | Keep/Fix? | Reason |
|----------|:-----:|:---------:|--------|
| **A — Must survive** (architectural decisions) | 5 | ✅ Yes | Admission Pathway VO, RBAC 11-role, F-7 enum count, entity count 11, event count 29 |
| **B — Historical artifact** (disappears with archive) | 108 | ❌ No | Stale counts, old version refs, superseded decisions — all in files being archived |
| **C — Stale metadata** (disappears with consolidation) | 41 | ❌ No | Old document counts, reconciliation notes about deleted files |
| **D — Architectural inconsistency** (must resolve) | 4 | ✅ Yes | File 24 RBAC table, File 22 speculative roles, File 27 supporting entity count, File 21 F-7 breakdown |
| **E — Dangerous instruction** (must fix) | 6 | ✅ Yes | Laravel 12 composer commands in file 26, Filament v3 code in file 26, 7-role seeder in file 26 |
| **F — Broken navigation** (disappears with restructure) | 32 | ❌ No | Off-by-one refs, Document ID mismatches, dangling refs — all use old numbering that consolidation eliminates |

**23 issues must survive into canonical documentation.** 173 disappear with consolidation.

### Issues Requiring Action in Canonical Docs

| # | Issue | Category | Destination | Treatment |
|---|-------|----------|-------------|-----------|
| 1 | Admission Pathway = VO (not entity) | A | 04-domain.md | State as canonical classification |
| 2 | RBAC = 11 roles, string role column | A | 06-implementation.md | Include canonical role table |
| 3 | F-7 enum count = 16 (not 15) | D | 04-domain.md | Correct breakdown |
| 4 | Entity count = 11 (not 12) | A | 04-domain.md | State canonical 11-entity model |
| 5 | Event count = 29 (not 27) | A | 04-domain.md | Include all 29 events |
| 6 | Action count = 20 (not 23/19) | A | 04-domain.md | Include all 20 actions |
| 7 | File 24 §17 RBAC table conflicts with File 29 | D | 06-implementation.md | Use File 29 as canonical |
| 8 | File 22 speculative roles mixed with MVP | D | 06-implementation.md | Separate MVP from future |
| 9 | File 27 says "2 supporting" (should be 3) | D | 04-domain.md | Correct to 3 supporting |
| 10 | Laravel 13 + PHP 8.5 baseline | A | 06-implementation.md | State as hard baseline |
| 11 | Filament v5 + Livewire v4 | A | 06-implementation.md | State as hard baseline |
| 12 | File 26 has Laravel 12 composer command | E | Archive (file 26) | Mark as HISTORICAL — do not execute |
| 13 | File 26 has Filament v3 code samples | E | Archive (file 26) | Mark as HISTORICAL — do not execute |
| 14 | File 26 has 7-role seeder code | E | Archive (file 26) | Mark as HISTORICAL — do not execute |
| 15 | minimolabs/laravel-webpush fabricated | A | 06-implementation.md | Use laravel-notification-channels/webpush |
| 16 | bezhansalam → bezhansalleh typo | A | 06-implementation.md | Correct spelling |
| 17 | filament/tiptap-editor deprecated | A | 06-implementation.md | Use native RichEditor |
| 18 | spatie/laravel-rate-limits invalid | A | 06-implementation.md | Use spatie/laravel-rate-limited-job-middleware |
| 19 | pxlrbt/filament-activity-log UNVERIFIED for v5 | A | 06-implementation.md | Flag for human decision |
| 20 | File 15 event count header says 27 | D | 04-domain.md | Correct to 29 |
| 21 | File 21 F-7 breakdown inconsistent | D | 04-domain.md | Correct to "10 immutable + 1 computed + 1 demoted + 16 enums" |
| 22 | super-admin → platform-admin | A | 06-implementation.md | Use canonical name |
| 23 | role_id FK → role string | A | 06-implementation.md | Use string column design |

---

## 9. Proposed Canonical Documentation Structure

```
docs/
├── 01-business.md
├── 02-decisions.md
├── 03-domain.md
├── 04-architecture.md
├── 05-implementation.md
├── 06-data-acquisition.md
└── archive/
```

### 01-business.md
- **Purpose:** Single-entry business context
- **Source documents:** 01, 02, 04, 06
- **Sections:** Vision & Identity, Personas (4 primary + 6 secondary), Problem Dimensions (5), Evolution (4 stages + MVP scope), Capabilities (10 MVP + 5 future), Workflows (WF1–WF7 with rules), Glossary, Resolved Open Questions
- **Owns:** Business intent, persona definitions, capability definitions, workflow rules
- **Excludes:** Decision rationale (02), domain model (03), architecture (04)

### 02-decisions.md
- **Purpose:** Complete decision register with governance
- **Source documents:** 03, 04, 07, 09
- **Sections:** Approved Decisions (A0-1 → A9-3 with rationale), Discovery Principles (P1–P18), Freeze Principles (F1–F5), Change Proposal Protocol, Deferred Items, ADRs
- **Owns:** All decision IDs and rationale, governance rules
- **Excludes:** Domain decisions (in 03), architecture decisions (in 04)

### 03-domain.md
- **Purpose:** Complete domain model
- **Source documents:** 15, 16, 21 (domain sections), 13 (expansion test summary)
- **Sections:** Entity Model (11 entities with attributes, behaviours, lifecycles), Value Objects (28 with implementation strategy), Domain Events (29), Application Actions (20), Invariant Register, Aggregate Boundaries, Global Expansion Test, Cross-Aggregate Interactions
- **Owns:** Canonical entity/VO/event/action/invariant inventories
- **Excludes:** Platform/architecture decisions (04), implementation specifics (05)

### 04-architecture.md
- **Purpose:** Complete platform and capability architecture
- **Source documents:** 21 (architecture sections), 24, 22 (search/SEO), 23 (community/WebPush)
- **Sections:** Architecture Principles (P1–P10), Eloquent Strategy, Directory Structure, Content Architecture (Option C), Search (Typesense), SEO, Notifications, Community, Study Abroad, Information Architecture, TALL Stack + Filament Admin, ADR Register (31), Architecture Scorecard
- **Owns:** "How" the domain is implemented; directory structure; technology choices
- **Excludes:** Domain model details (03), implementation code (05)

### 05-implementation.md
- **Purpose:** The implementation blueprint — what to code, in what order
- **Source documents:** 27, 28, 29
- **Sections:** Source of Truth Hierarchy, Platform Baseline (Laravel 13 + PHP 8.5 + Filament v5 + Livewire v4), RBAC (11 roles + OrganizationMember), Package Matrix (verified), Database Design (54 tables), Settings Architecture, Security & Privacy, Media Architecture, Implementation Phases, Forbidden List, Package Verification Appendix
- **Owns:** The document developers and AI agents code from
- **Excludes:** Architecture rationale (04), domain model (03)

### 06-data-acquisition.md
- **Purpose:** Data acquisition and ingestion pipeline
- **Source documents:** 30
- **Sections:** Design Principles, Source Taxonomy, Architecture (3-layer), Staging Schema, Adapter Pattern, Verification Engine, Provenance Model, Scheduled Jobs, Admin UI
- **Owns:** Complete ingestion pipeline design
- **Excludes:** Everything else

---

## 10. Full Consolidation Matrix

| Current File | Primary Content | Destination | Treatment |
|-------------|----------------|-------------|-----------|
| 01-business-overview.md | Business identity, personas, capabilities | 01-business.md | Consolidate |
| 02-glossary.md | Term definitions | 01-business.md | Consolidate |
| 03-approved-decisions.md | 63 decisions with rationale | 02-decisions.md | Consolidate |
| 04-open-questions.md | 22 resolved questions | 01-business.md + 02-decisions.md | Consolidate |
| 06-business-workflows.md | WF1–WF7 with rules | 01-business.md | Consolidate |
| 07-business-discovery-closure.md | Closure summary, P1–P18 | 02-decisions.md (P1–P18) | Extract + Archive |
| 08-traceability-matrix.md | QA proof (96/96) | archive/ | Archive |
| 09-business-discovery-freeze.md | F1–F5, Change Proposal Protocol | 02-decisions.md (governance) | Extract + Archive |
| 11-domain-discovery-topic2.md | Original Topic 2 | archive/ | Archive |
| 12-domain-discovery-topic2-revision.md | Revised Topic 2 (5 ARs) | archive/ | Archive |
| 13-domain-discovery-consolidation.md | Pre-behaviour consolidation | 03-domain.md (expansion test) | Extract + Archive |
| 14-architectural-review-global-domain.md | F1–F14 normalization | archive/ | Archive |
| 15-domain-discovery-topic4-behaviour.md | Behaviour discovery | 03-domain.md | Consolidate |
| 16-domain-discovery-topic3.md | Attribute model | 03-domain.md | Consolidate |
| 17-domain-integrity-review.md | CDR — weaknesses/assumptions | archive/ | Archive |
| 18-domain-resolution-analysis.md | Resolution of 17's findings | archive/ | Archive |
| 19-domain-architecture.md | Original domain architecture | archive/ | Archive |
| 20-domain-architecture-validation.md | Validation of 19 | archive/ | Archive |
| 21-domain-architecture-frozen-baseline.md | Frozen baseline | 03-domain.md + 04-architecture.md | Split + Consolidate |
| 22-post-freeze-platform-architecture-review.md | Platform review | 04-architecture.md (search/SEO) | Extract + Archive |
| 23-laravel-ecosystem-build-vs-buy-review.md | Package evaluation | 04-architecture.md (community) | Extract + Archive |
| 24-final-platform-and-capability-architecture.md | Final architecture | 04-architecture.md | Consolidate |
| 26-pre-implementation-reconciliation.md | Reconciliation of 25 | archive/ | Archive |
| 27-final-corrected-pre-implementation-blueprint.md | Implementation blueprint | 05-implementation.md | Consolidate |
| 28-package-verification-audit.md | Package audit | 05-implementation.md (appendix) | Consolidate |
| 29-rbac-decision.md | Canonical RBAC | 05-implementation.md (section) | Consolidate |
| 30-data-acquisition-pipeline.md | Data pipeline | 06-data-acquisition.md | Rename |
| 00-documentation-audit-report.md | This audit | archive/ | Archive |

---

## 11. Archive Candidates

18 documents to archive (preserved for provenance, NOT authoritative):

00-documentation-audit-report.md, 07, 08, 09, 11, 12, 13, 14, 17, 18, 19, 20, 22, 23, 26

**Archive rule:** Archive documents are historical reference only. They must NOT be treated as implementation authority. If an archive document contradicts a canonical document, the canonical document wins unconditionally.

---

## 12. Information-Loss Risks

| Information | Current Source | Proposed Destination | Risk | Mitigation |
|-------------|---------------|---------------------|------|-----------|
| 18 Discovery Principles (P1–P18) | File 07 | 02-decisions.md | Low — explicitly extracted | Verify extraction |
| 5 Freeze Principles (F1–F5) + Change Proposal Protocol | File 09 | 02-decisions.md | Low — explicitly extracted | Verify extraction |
| 7 Traceability chains (96/96) | File 08 | archive/ | Low — QA proof, not needed daily | Accessible in archive |
| 9-country expansion test (full detail) | File 13 | 03-domain.md (summary) + archive/ | Low — summary in canonical, full in archive | Verify summary captures key result |
| 14 Global Domain findings (F1–F14) | File 14 | archive/ | Low — corrections applied in canonical docs | Reasoning trail in archive |
| Original Laravel 12 code samples | File 26 | archive/ | None — not implementable | Clearly marked HISTORICAL |
| Adversarial reasoning from validation | File 20 | archive/ | Low — results applied in canonical | Reasoning accessible in archive |

**No information is lost.** All unique content either survives in canonical docs or remains accessible in archive.

---

## 13. Remaining Human Decisions

| # | Decision | Context | Options |
|---|----------|---------|---------|
| 1 | **pxlrbt/filament-activity-log compatibility with Filament v5** | File 28 marks this as UNVERIFIED for v4/v5. The package exists on Packagist but v5 compatibility is unconfirmed. | (a) Verify manually on Packagist/GitHub before implementation, (b) Use Spatie activity log backend without Filament UI plugin initially, (c) Build custom Filament resource for activity log |

All other decisions have been resolved through the reconciliation.

---

## 14. Recommended Cleanup Sequence

1. **Create 6 canonical documents** by consolidating from source files
2. **Create archive/ directory** and move 18 historical documents
3. **Verify all 23 critical issues** are correctly represented in canonical docs
4. **Rebuild archive zip**
5. **Delete no files** — archive everything

---

# HUMAN APPROVAL REQUIRED

**PROPOSED:**

**Create (6 new canonical documents):**
- 01-business.md (from 01 + 02 + 04 + 06)
- 02-decisions.md (from 03 + 04 + 07[P1–P18] + 09[F1–F5, Change Proposal])
- 03-domain.md (from 15 + 16 + 21[domain] + 13[expansion summary])
- 04-architecture.md (from 21[architecture] + 24 + 22[search/SEO] + 23[community])
- 05-implementation.md (from 27 + 28[appendix] + 29[section])
- 06-data-acquisition.md (from 30)

**Archive (18 documents — preserve, do not delete):**
- 00-documentation-audit-report.md, 07, 08, 09, 11, 12, 13, 14, 17, 18, 19, 20, 22, 23, 26

**Delete:**
- (none)

**One human decision required:**
- pxlrbt/filament-activity-log compatibility with Filament v5 — verify before implementation?

**DO NOT PROCEED until explicitly approved.**
