StudyNexus
Domain Resolution Analysis
Stabilization of Domain Foundation Post-Integrity Review
Date: 2026-08-07
Status: Awaiting Approval
Authority: Business Discovery (frozen) > Domain Discovery Topics 1–3 > Architectural Review > Domain Integrity Review

# Executive Summary
This document resolves all 11 findings from the Domain Integrity Review against the canonical Business Discovery and existing Domain Discovery Topics 1–3. Each finding is challenged, not merely accepted: the objective is to distinguish genuine domain concepts from modeling or implementation concerns.
The resolution produces 8 accepted modifications, 3 rejected recommendations, 1 new entity (Admission Pathway as supporting entity), 3 new Value Objects (Admission Mode, Financial Coverage, Country), 2 demoted concepts (Country from entity to reference data, Admission Cycle from universal to pattern-based), and 6 revised assumptions. The bounded-context assessment yields 2 genuine bounded contexts for MVP plus 1 conceptual grouping.
Final Verdict: READY FOR BEHAVIOUR DISCOVERY WITH MINOR REVISIONS
The domain foundation is stable. All findings are resolved. The model requires targeted corrections (4 required, 4 recommended) that do not constitute redesign. The stable domain language remains valid across all 9 test countries and all 9 future capabilities.
# Finding 1: Admission Pathway
## Integrity Review Claim
The integrity review identified Admission Pathway as a possible supporting entity (RI-1, MC-2) because it appears to be a universal concept and helps express admission rules across countries. Currently an open question (OQ-D3-1), the glossary defines it at A3-8.
## Multi-Country Semantic Test
### Nigeria
UTME: The standard route via the Unified Tertiary Matriculation Examination. Entry at 100-level. Defined by JAMB. Every candidate for first-degree admission takes this examination.
Direct Entry: For holders of ND, HND, NCE, IJMB, JUPEB, or equivalent qualifications. Entry at 200-level or 300-level depending on qualification. Defined by JAMB and individual institutions. The pathway determines both the accepted qualifications and the entry level.
IJMB/JUPEB: Advanced-level programmes specifically designed as admission pathways. Entry at 200-level. These are qualifications that exist solely because of a pathway.
### United Kingdom
UCAS Standard Route: A-Levels → university via the standard UCAS application. Entry at year 1. This is the dominant pathway and is deeply embedded in the UCAS cycle.
Foundation Year: A pre-undergraduate year for students who do not meet direct entry requirements (often international students). Entry at year 0 (foundation) then year 1. Offered by institutions, not coordinated centrally.
Access Course: For mature students without traditional qualifications. Entry at year 1. A distinct pathway with different qualification requirements.
Clearing: A post-results pathway that operates outside the main UCAS cycle. Semantically distinct — it has different rules, different timing, and different availability.
### United States
Freshman Admission: Standard entry for first-year students, typically requiring SAT/ACT + high school transcript. Entry at year 1.
Transfer Admission: For students with existing college credit. Entry at year 2 or 3 depending on credits. Transfer articulation agreements define which credits transfer. This is a fundamentally different pathway with different requirements, different evaluation criteria, and different entry levels.
Early Decision/Early Action: These are application strategies, not admission pathways. They use the same requirements as freshman admission with a different timeline. Semantically distinct from pathways.
### Germany
Standard Route (Abitur): Abitur → university. This is the default pathway for German nationals.
International Applicant Pathway: For non-German qualifications. Requires assessment by uni-assist. Different qualification evaluation, different language requirements. A genuinely distinct pathway.
Fachhochschule Route: Fachabitur → Fachhochschule (applied university). A different entry qualification leading to a different type of institution. Semantically, this is a pathway with a different terminal qualification type.
## Analysis Against Entity Criteria
## Critical Question: Are Pathways Semantically Identical Across Countries?
No. 'Direct Entry' in Nigeria (ND/HND → 200-level) is semantically different from 'Transfer' in the US (college credits → year 2/3 based on credit count). They share the abstract pattern of 'entering at an advanced level based on prior qualifications,' but the rules, qualification types, and entry-level determination mechanisms differ. However, this is precisely the pattern the model already handles: the concept is universal, the specifics are reference data. The same approach used for Qualification (universal concept, authority-scoped identity, country-specific values) applies to Admission Pathway.
## Challenge: Should Admission Pathway Be Part of Admission Policy?
No. Admission Pathway exists independently of any specific policy. A pathway (e.g., Direct Entry) is defined by an authority (JAMB) and referenced by multiple admission policies across multiple institutions and programmes. If pathways were embedded in Admission Policy, the same pathway would be duplicated across every policy that uses it, and pathway-level invariants (e.g., 'Direct Entry always enters at 200-level') could not be expressed. This is the same reason Qualification is a separate supporting entity rather than embedded in Admission Rules.
## Challenge: Should Admission Pathway Be a Value Object?
No. Value objects are defined by their attributes and have no identity. But 'Direct Entry' has identity — it is the same concept whether referenced by UNILAG's policy or UI's policy. Two pathways with the same name but different defining authorities (e.g., JAMB's Direct Entry vs. a UK Foundation Year) are not equal. This requires identity, which is the defining characteristic of an entity, not a value object. The integrity review's original rejection of Admission Pathway as a VO in Topic 3 (rejected VOs list) was correct: it has identity and is referenced across aggregates.
## Resolution
ACCEPT: Admission Pathway becomes a Supporting Entity
Entity Specification:
Classification: Supporting Entity (like Qualification)
Identity: Name + Defining Authority (authority-scoped, same pattern as Qualification)
Attributes: Name (String, identity component), Defining Authority (Reference to Education Authority, identity component), Entry Level (Integer, e.g., 100, 200, 300), Accepted Qualifications (Collection of References to Qualification), Description (String, free-text), Status (Pathway Status enum: Active, Deprecated)
Referenced by: Admission Rule (each rule may optionally specify a pathway)
Aggregate root: No — StudyNexus references but does not manage pathways in MVP
Impact on Admission Rule (VO-1):
Add optional attribute: pathway — Reference to Admission Pathway (or null)
An Admission Rule may now express: 'For Direct Entry pathway, ND with Lower Credit → 200-level'
Rules without a pathway reference apply to all pathways (the default/standard route)
Rationale for acceptance:
Admission Pathway satisfies all entity criteria: it has identity, is referenced across aggregates, carries independent domain rules, exists universally across educational systems, and fills a gap in the ubiquitous language (A3-8). It follows the exact same pattern as Qualification — a supporting entity with authority-scoped identity that StudyNexus references but does not manage. Introducing it makes Admission Rules more expressive and the domain language more complete without adding aggregate-level complexity.
# Finding 2: Admission Mode
## Integrity Review Claim
The integrity review identified a major hidden assumption (HA-2): the model appears to assume that admission is always cycle-based. The review proposed Admission Mode (Cyclic/Rolling) as an attribute on Programme to address this.
## Multi-Country Admission Pattern Test
## Analysis: Is Admission Mode a Distinct Domain Concept?
Yes. The distinction between cyclic and rolling admission is not merely an implementation detail — it has domain consequences:
Cyclic: Policy scoping:
Admission Policy is scoped to an Admission Cycle. Rolling: Admission Policy is standing (not cycle-scoped). This directly affects the identity composition of Admission Policy.
Cyclic: Temporal structure:
Admission occurs within defined phases (application period, review period, decision period). Rolling: No phases — applications are received and evaluated continuously.
Cyclic: User behaviour:
Users must apply before a deadline within a specific cycle. Rolling: Users may apply at any time. This affects WF4 (Assess Eligibility) and WF6 (Make Educational Decision).
Cyclic: Data model:
Admission Cycle entity is required. Rolling: No Admission Cycle is needed (or a trivial one is used).
## Challenge: Is Admission Mode an Attribute of Programme, Admission Policy, or Admission Cycle?
### Programme?
Yes. The admission mode is a characteristic of the programme itself. A Master’s programme at a US university uses rolling admission regardless of which admission policy or cycle is involved. The programme determines how admission works. This is the most natural home.
### Admission Policy?
No. Admission Policy describes requirements, not the temporal pattern of admission. A policy says 'what' is required; admission mode says 'when' and 'how' applications are processed. These are different concerns. Furthermore, a programme with rolling admission has one standing policy, while a cyclic programme has one policy per cycle — the mode determines the policy cardinality, not the other way around.
### Admission Cycle?
No. This would be circular: Admission Cycle exists only when admission is cyclic. A rolling admission programme has no meaningful cycle. Placing mode on the cycle would mean the cycle must exist before you can determine whether a cycle is needed.
### Derived?
No. Admission mode is not derived from other attributes. It is an intrinsic characteristic of how a programme admits students, determined by the institution and the programme’s design.
## Resolution
ACCEPT: Admission Mode becomes a Value Object on Programme
Value Object Specification:
Name: Admission Mode (VO-26)
Values: Cyclic (admission occurs within defined, time-bounded cycles), Rolling (applications accepted and evaluated continuously), Multiple-Intake (multiple named intake periods per year, each with its own deadline)
Default: Cyclic (maintains backward compatibility with the current model)
Impact on existing model:
Programme gains attribute: Admission Mode (VO-26), default Cyclic, not country-varying
Admission Policy: For Cyclic programmes, identity remains Governed Entity + Admission Cycle. For Rolling programmes, identity becomes Governed Entity + standing (no cycle reference). This is a minor modification to the identity composition rule.
Admission Cycle: Becomes optional for a programme. A Cyclic programme has one or more cycles. A Rolling programme has none. This does not demote Admission Cycle — it remains an aggregate root for cyclic programmes.
INV-P2 revision: 'Only one active Admission Policy per Admission Cycle' becomes 'Only one active Admission Policy per Admission Cycle (Cyclic) or per Programme (Rolling)'.
Why not force all systems into the Nigerian-style cycle:
Because doing so would make the model unable to represent the majority of graduate programmes in the US, UK, Canada, Germany, and Australia. The model must represent the domain as it is, not as Nigeria’s structure suggests it should be. Admission Mode is a small addition (one attribute with three values) that preserves the existing model while making it globally valid.
# Finding 3: Admission Cycle Re-evaluation
## Question: Is Admission Cycle the Primary Temporal Axis?
Admission Cycle is one temporal pattern among several. With the introduction of Admission Mode (Finding 2), the model now explicitly acknowledges that not all admission is cycle-based. Admission Cycle is the temporal axis for Cyclic programmes only.
## Universality Test
## Is Admission Cycle Actually an Entity, or One Pattern Among Several?
Admission Cycle is genuinely an entity — for cyclic admission. It has identity (Period/Year + Defining Authority), lifecycle (phases advance through transitions), invariants (INV-C1 through INV-C3), and is referenced by Admission Policies and Programmes. It is not merely a pattern; it is a domain concept with structure and rules.
However, the current model over-generalizes by making Admission Cycle the universal temporal axis. The correct model is:
Admission Mode on Programme determines the temporal pattern
Cyclic programmes reference one or more Admission Cycles
Rolling programmes have no Admission Cycle reference
Multiple-Intake programmes reference multiple Admission Cycles (one per intake)
## Resolution
MODIFY: Admission Cycle remains an Aggregate Root but is no longer the universal temporal axis
Changes:
Admission Cycle remains an aggregate root with all current attributes and invariants — no structural changes to the entity itself
The relationship between Programme and Admission Cycle changes from 'every programme has an admission cycle' to 'a Cyclic programme references one or more admission cycles'
The Participating Programmes collection on Admission Cycle becomes the inverse: programmes with Admission Mode = Cyclic that reference this cycle
No removal of temporal modelling — Admission Cycle is preserved for cyclic systems; Admission Mode enables representation of non-cyclic systems
Why not remove Admission Cycle:
Because cycle-based admission is the dominant pattern in the initial operating context (Nigeria) and remains common across most of the 9 test countries. Removing it would simplify the model at the cost of being unable to represent the most important temporal pattern. The correct approach is to keep Admission Cycle for cyclic systems and add Admission Mode to handle the cases where cycles do not apply.
# Finding 4: Country
## Integrity Review Claim
The integrity review proposed Country as a first-class Value Object (RI-3, MC-1), arguing that it appears frequently and has domain meaning in StudyNexus.
## Challenge: What Is Country’s True Nature?
Country appears in the current model as a string (ISO country code) in three places:
Education Authority: Country of Operation
Scholarship Provider: Country of Operation
Location VO: Country Code
And it is implicitly used by:
Institution Type values (country-specific taxonomy)
Award Level values (country-specific names)
Qualification definitions (authority-scoped, authorities are country-scoped)
Admission Cycle phases (country-specific configurations)
Authority Jurisdiction rules (country-specific regulatory structures)
Currency (country determines default currency)
## Analysis: Is Country a Domain Concept?
Country is not a domain concept in the educational domain. It is a geopolitical and administrative concept. The educational domain does not define countries; it operates within them. In DDD terms, Country is reference data — a standardized set of values used to scope and configure the domain, not a concept that participates in business operations or invariants.
Consider the distinction:
Qualification is a domain concept — it participates in invariants (INV-9), is referenced by business rules, and has domain-specific meaning (a WAEC SSCE is educationally different from a SAT)
Education Authority is a domain concept — it grants accreditation, defines qualifications, and participates in jurisdiction invariants
Country is not a domain concept — it does not participate in any educational invariant. It scopes the domain but is not part of the domain’s internal logic
## Analysis: Value Object vs. Reference Entity vs. Reference Data
## Resolution
REJECT as Value Object. ACCEPT as Standardized Reference Data with a lightweight wrapper.
Decision:
Country should not be a domain Value Object because it is not a domain concept. It is standardized reference data (ISO 3166-1) that scopes and configures the domain. Promoting it to a Value Object would imply it has domain meaning, which it does not — it has administrative and scoping meaning.
However, using raw strings for country codes across the model creates validation scatter (every entity that uses a country code must independently validate it). The pragmatic solution is:
Create a Country VO as a thin type-safe wrapper over ISO 3166-1 data — not because Country is a domain concept, but because type safety and validation centralisation are engineering concerns that prevent bugs
Document explicitly: 'Country is reference data, not a domain concept. The VO wrapper exists for type safety and validation, not because Country has domain meaning.'
The VO contains: ISO alpha-2 code (String), display name (String, for presentation)
Equality: by ISO code (two Country VOs are equal if they have the same ISO code)
Why this is the correct level:
If Country were a domain Value Object, it would imply that the domain has opinions about countries — e.g., that certain business rules change based on country. But in StudyNexus’s domain, business rules change based on Education Authority jurisdiction, Qualification scope, and Admission Cycle scope — not based on country directly. Country is the administrative scope within which these domain concepts operate, but the domain logic is expressed through Authority, Qualification, and Cycle, not through Country.
# Finding 5: Tertiary-Only Assumption
## Integrity Review Claim
The integrity review identified HA-1: the model assumes tertiary education only. Every entity and example refers to tertiary. Business Discovery does not explicitly scope StudyNexus to tertiary.
## What Does Business Discovery Actually Say?
A0-1: 'comprehensive education knowledge platform' — not 'tertiary education platform'
A0-2: 'education infrastructure for Africa' — not 'tertiary education infrastructure'
A1-1: Primary users include 'Secondary School Student and Graduate' — but they are preparing to pursue tertiary, not seeking secondary opportunities
A2-1: Secondary users include 'Educational Institutions' — not specifically 'Tertiary Educational Institutions'
A3-8: 'Alternative Admission Pathways include Direct Entry, IJMB, JUPEB, diploma pathways, and other recognized admission routes into tertiary education' — explicitly says 'into tertiary education'
## The Three Options
## Analysis: What Is the Stable Abstraction?
The key insight is that the current model’s core abstractions — Educational Institution, Programme, Qualification, Admission Policy, Scholarship — are not inherently tertiary-specific. They are education-opportunity-specific. What makes them tertiary-only is:
The specific Institution Type values (University, Polytechnic, College of Education)
The specific Qualification Level values (Tertiary Entrance, Diploma, Sub-Degree, Professional)
The specific Award Level values (B.Sc., M.Sc., Ph.D., ND, HND)
The assumption of admission cycles (secondary schools do not have admission cycles in the Nigerian sense)
All of these are reference data, not domain structure. The model already handles this: value objects are universal, values are country-specific data (DD3-3). The same principle applies to education-level scoping.
## Resolution
MAKE EXPLICIT: Document the tertiary-only assumption. No structural change.
Decision:
The current domain scope is tertiary/post-secondary education. This is explicitly documented as a scoping assumption, not a domain constraint. The domain abstractions (Institution, Programme, Qualification, Scholarship, etc.) are education-opportunity abstractions that are valid beyond tertiary. When secondary education or vocational education is added, the change is reference data (new Institution Type values, new Qualification Level values, new Award Level values) — not structural redesign.
The stable abstraction:
Educational Institution = any organisation that offers educational programmes (not just tertiary)
Programme = any structured educational offering (not just a degree programme)
Qualification = any credential used for admission or eligibility assessment (not just tertiary entrance qualifications)
Scholarship = any financial award for education (not just tertiary scholarships)
What must change when expanding beyond tertiary:
Institution Type values: add Secondary School, Primary School, Training Centre, etc. (reference data)
Qualification Level values: add Primary, Pre-Secondary, etc. (reference data)
Admission Mode: Secondary schools may use different admission patterns (e.g., placement exams, catchment-area admission)
No entity restructuring, no new aggregate roots, no invariant changes
Revised assumption:
A-R1 (revised): 'The current domain scope is tertiary/post-secondary education. The domain abstractions are designed to be valid across education levels. Expansion beyond tertiary requires reference data additions and potential Admission Mode value extensions, not structural redesign of the core domain model.'
# Finding 6: Location-Bound Assumption
## Integrity Review Claim
The integrity review identified HA-3: the model assumes educational opportunities are inherently location-bound. Location is mandatory on Educational Institution. Online programmes challenge this.
## Analysis: Where Does Location Belong?
## Should Location Be on Institution, Campus, Programme, or Delivery Mode?
### Institution?
Location on Institution is correct for the institution’s identity. A physical institution has a location that is part of what it is. But for online-only institutions, the institution’s location is administrative, not discoverable. Making Location mandatory forces every institution to have a discoverable location, which is wrong for online-only institutions.
### Campus?
Campus is a legitimate domain concept for multi-campus institutions. However, introducing Campus as an entity requires domain evidence that Campus has identity, lifecycle, and business rules beyond being a named location. In the current model, a Campus would be: (1) a named location within an institution, (2) a reference point for programmes offered at that campus, (3) potentially with its own accreditation status. For MVP, this is over-modelling — most institutions in Nigeria have a single campus, and multi-campus information can be handled through the Programme–Institution relationship and a campus attribute on Programme.
### Programme?
Location on Programme would handle the case where the same programme is offered at multiple campuses. But this conflates programme identity with delivery location. A B.Sc. Computer Science is the same programme whether offered at the main campus or a satellite campus — the curriculum is the same, the award is the same, the admission requirements are the same. Location is a delivery detail, not a programme attribute.
### Delivery Mode?
Delivery Mode is currently an enum (Full-Time, Part-Time, Distance, Blended, Online). It partially addresses location: 'Online' implies no physical location, 'Full-Time' implies a physical location. But Delivery Mode is about how the programme is delivered, not where. A programme can be Full-Time at multiple campuses.
## Resolution
MODIFY: Location becomes optional on Educational Institution. No new entities.
Changes:
Location on Educational Institution changes from mandatory to optional
Add Is Location-Relevant (Boolean, derived) to Educational Institution: true if the institution has any programmes with non-Online delivery mode, false if all programmes are online-only
For online-only institutions, Location may be null or may contain only the country code (for administrative/regulatory purposes)
No new entities (Campus, Programme Offering) — the domain evidence does not justify them for MVP
Why not introduce Campus:
Because Campus does not have independent business behaviour in the current scope. A campus is a named location that programmes reference. For MVP, if a programme is offered at a specific campus, the campus name can be an attribute on the programme (a simple string, like Faculty). If Campus later needs identity, lifecycle, accreditation, or independent search, it can be promoted to a supporting entity — but this should be demand-driven, not speculative.
Revised assumption:
A-R2 (revised): 'Educational opportunities may be location-bound, location-optional, or location-irrelevant. Location on Educational Institution is optional. For physical institutions, location is identity-defining and discoverable. For online-only institutions, location is administrative. The domain does not require a Campus entity for MVP.'
# Finding 7: Currency Assumption
## Integrity Review Claim
The integrity review identified HA-4: the model assumes one currency per Monetary Amount (VO-9). The current VO contains amount + currency code, with no multi-currency conversion.
## Analysis: How Should Monetary Values Be Modeled Globally?
Monetary Amount (VO-9) already correctly groups amount + currency. This is the standard pattern for modeling money in domain models (Martin Fowler’s Money pattern). The current VO prevents the error of comparing 100 NGN with 100 USD — they are not equal because the currencies differ.
The question is not whether Monetary Amount is correctly modeled (it is), but whether the domain requires richer concepts:
## Resolution
NO CHANGE for MVP. Document expansion path.
Decision:
Monetary Amount (VO-9) is correctly modeled. The single-currency assumption is explicit and acceptable for MVP. No structural changes are needed.
Expansion path (documented, not implemented):
Multi-currency scholarships: Model as separate Monetary Amount fields (tuition coverage + living stipend), each with its own currency. This is additive — new fields on Scholarship, no VO change.
Currency conversion: Infrastructure/service concern, not a domain concern. A read model can perform conversion for display without affecting the domain model.
Cost structure: If the domain eventually needs to model the full cost of attendance (tuition + fees + accommodation + living), each component is a separate Monetary Amount. This is additive and does not require restructuring Monetary Amount.
Revised assumption:
A-R3 (revised): 'Monetary Amount uses a single currency per value. Multi-currency scenarios (study abroad, international scholarships) are modeled as multiple Monetary Amounts with different currencies, not as a single multi-currency VO. Currency conversion is an infrastructure concern, not a domain operation.'
# Finding 8: Static Qualification Assumption
## Integrity Review Claim
The integrity review identified HA-5: qualifications are treated as static, external concepts with no business operations. StudyNexus records them but does not manage them.
## Analysis: What Does Qualification Actually Represent?
The current Qualification entity represents a credential type — a category of qualification defined by an authority. 'WAEC SSCE', 'JAMB UTME', 'A-Level', 'SAT' are credential types. They are stable reference concepts: WAEC SSCE has been a qualification type since 1952, and its definition changes very slowly.
This is distinct from a qualification possessed by a person. A person’s WAEC SSCE result (5 credits including Mathematics and English) is an instance of the credential type. The current model does not represent this instance, and for good reason: StudyNexus is an opportunity discovery platform, not a student records system.
## Are These Two Concepts Incorrectly Combined?
## Challenge: WF4 Requires Comparing User Qualifications Against Requirements
WF4 (Assess Eligibility) involves a user comparing their own qualifications against admission/eligibility requirements. This workflow needs:
The qualification type (from the Qualification entity) — what qualification is required
The threshold (from Qualification Threshold) — what level is required
The user’s qualification results — what the user has achieved
The user’s qualification results are input to the assessment, not domain entities. They are provided by the user (or imported from an external system) at assessment time. They do not need to be persisted as domain entities because:
StudyNexus is not a student records system (per Business Discovery scope)
Qualification results are personal data with privacy implications
Results change over time (multiple sittings, improved scores) — this is the user’s concern, not the domain’s
The assessment result (eligible / not eligible / partially eligible) is what matters for the domain, not the stored instance
## What About Qualification Expiration and Verification?
Some qualifications expire (professional certifications that require renewal). Some require verification (a degree certificate must be verified by the issuing institution). These are real concerns, but they are concerns of the credential instance, not the credential type. The credential type (e.g., 'PMP Certification') does not expire — a specific person’s PMP certification expires. This confirms that expiration and verification belong to the instance concept, which is outside StudyNexus’s current domain scope.
## Resolution
CONFIRM: Qualification represents a Credential Type. No structural change.
Decision:
Qualification correctly represents a credential type. It is not conflated with credential instances. The model is sound.
Clarifications documented:
Qualification = credential type (defined by authority, stable, referenced by rules)
Credential instance = a person’s qualification result (not modeled, input to WF4)
Qualification has an administrative lifecycle (Recognized, Deprecated, Replaced) managed by data operations, not business workflows
Expiration, verification, and multiple attempts are instance-level concerns that belong to a future user/person context, not the opportunity discovery context
Revised assumption:
A-R4 (revised): 'Qualification represents a credential type, not a credential instance. A credential type is a stable reference concept defined by an Education Authority. A credential instance (a person’s qualification result) is input data for eligibility assessment, not a domain entity. StudyNexus does not manage student records; it discovers opportunities and assesses eligibility against requirements.'
# Finding 9: Authority Type
## Integrity Review Claim
The integrity review identified RC-2: Authority Type is modeled as a singular attribute while assumption A-D3-8 states 'Education Authority can have multiple Authority Types.' NUC is both Regulatory and Accrediting; JAMB is Coordinating, Examining, and Admissions.
## Multi-Country Evidence
## Resolution
ACCEPT: Authority Type becomes a collection (Set of Authority Type)
Decision:
This is a data model correction, not a structural change. The value object (VO-21, Authority Type) remains unchanged. The multiplicity on Education Authority changes from 1 to 1..N. This was already identified in the integrity review as RC-2 and is confirmed by multi-country evidence.
Impact:
Education Authority: Authority Type attribute changes from single value to collection
No new entity, no new VO, no invariant changes
Authority Jurisdiction logic is unaffected — jurisdiction determines scope, not type
# Finding 10: Admission Policy vs Eligibility Policy
## Integrity Review Claim
The integrity review (RC-1) required documentation explaining why Admission Policy and Eligibility Policy remain separate despite structural similarity. The review noted they share lifecycle states, status VOs, and structurally similar rule collections.
## Re-evaluation: Are They Genuinely Different Domain Concepts?
### Semantic Test: Programme Admission Requirements vs Scholarship Eligibility Requirements
### Are these the same concept with different parameters?
No. The semantic difference is real and significant:
Admission Policy answers: 'What qualifications must a candidate have to be admitted to this programme?' The focus is qualification-centric. Rules specify qualifications, thresholds, and subject combinations. Non-qualification criteria (e.g., age limits, residency requirements) are secondary.
Eligibility Policy answers: 'What conditions must a candidate meet to receive this scholarship?' The focus is condition-diverse. Rules include qualification requirements, but also geographic restrictions ('must be from Niger Delta'), demographic criteria ('must be female'), financial need assessment, and academic performance benchmarks (CGPA). Qualification criteria are one input among many.
### Would merging them simplify the model?
Merging would create a single 'Policy' entity with a type discriminator (Admission vs Eligibility) and a polymorphic rule collection. This would:
Introduce a shared abstraction that LBC explicitly warns against (DD2-8)
Make the rule structure polymorphic (Admission Rules vs Eligibility Rules are different VOs)
Create a dual-parent (Programme/Institution vs Scholarship) that the current model already handles separately
Obscure the semantic difference in the ubiquitous language — 'admission requirements' and 'eligibility criteria' are different domain terms used by different stakeholders
### Are they in separate bounded contexts?
Not currently. Both belong to the Opportunity Discovery context. They could potentially belong to separate sub-contexts (Admissions and Financial Aid), but this split is premature for MVP.
## Resolution
CONFIRM: Admission Policy and Eligibility Policy remain separate entities
Rationale for separation:
They serve different domain purposes: admission to a programme vs eligibility for a financial award
Their rule structures are genuinely different (VO-1 vs VO-2), not merely parameterised variants of the same VO
Their identity compositions differ (entity+cycle vs scholarship+period)
Their parent entities differ (programme/institution vs scholarship)
Their ubiquitous language terms are different ('admission requirements' vs 'eligibility criteria')
Merging would require a shared abstraction (premature generalization per LBC and DD2-8)
The shared lifecycle (Draft → Published → Active → Superseded → Retired) is coincidental, not conceptual — many domain entities share lifecycles without being the same concept
Documentation requirement (per RC-1):
The separation rationale must be documented in the domain model to prevent future developers from 'fixing' the structural similarity by introducing a shared Policy abstraction. This is now documented in this resolution.
# Finding 11: Bounded Contexts
## Integrity Review Claim
The integrity review proposed three bounded contexts: Opportunity Discovery, Trust & Accreditation, and Reference Framework.
## DDD Bounded Context Criteria
A bounded context in the DDD sense is defined by:
Ubiquitous language: A context has its own language where terms have specific meanings
Model divergence: The same concept may be modeled differently in different contexts
Invariants: A context has its own consistency boundaries and invariant enforcement
Ownership: A context owns its data and defines its operations
Independent change: A context can evolve without requiring changes in other contexts
## Evaluation of Proposed Contexts
### BC-1: Opportunity Discovery
Verdict: Genuine bounded context. The Opportunity Discovery context has its own language, invariants, and ownership. It can be deployed and tested independently.
### BC-2: Trust & Accreditation
Verdict: Genuine bounded context. The Trust context has its own language, invariants, and ownership. Trust events (source verified, accreditation revoked) happen on different timelines from opportunity events (cycle opened, policy published).
### BC-3: Reference Framework
Verdict: NOT a bounded context in the DDD sense. It is a conceptual grouping of reference data that both other contexts use. It has no domain model, no ubiquitous language, no invariants, and no business operations. It is a shared kernel / reference data layer, not a bounded context.
## Should Admissions and Scholarships Be Separate Contexts?
Within Opportunity Discovery, two sub-domains are visible: Admissions (Admission Policy, Admission Cycle, Admission Rule) and Financial Aid (Scholarship, Eligibility Policy, Eligibility Rule). However:
They share the same ubiquitous language core: 'qualification', 'threshold', 'eligibility assessment'
They share the same workflows: WF4 (Assess Eligibility) operates on both admission and scholarship eligibility
They share the same reference data: Qualification, Education Authority
They do not have model divergence: the same Qualification entity is used identically in both
Splitting them would create two contexts that share most of their language and reference data, with minimal benefit. For MVP, they belong together. If Financial Aid grows significantly (fellowships, grants, bursaries, work-study programmes), it may warrant a separate context — but this is a future decision.
## Resolution
2 Bounded Contexts + 1 Shared Kernel for MVP
Implementation for MVP:
Single Laravel application with domain-level namespace separation
Opportunity Discovery domain: App\Domain\Opportunity
Trust & Accreditation domain: App\Domain\Trust
Reference data: App\Domain\Shared (shared kernel)
Cross-context references via domain IDs (not ORM relations between contexts)
Refactor into separate applications/deployments only when the code shows the seams (likely Stage 2+)
# Global Modeling Test
## Post-Resolution Model Tested Against 9 Countries
Key result: With Admission Mode + Admission Pathway added, the domain model requires ZERO structural changes across all 9 countries.
## Future Capability Test
Test result: Does the stable domain language remain valid while country-specific and future concepts can be added without redesigning the core?
YES
The domain language (Institution, Programme, Qualification, Scholarship, Admission Policy, Eligibility Policy, Admission Cycle, Information Source, Education Authority, Admission Pathway, Admission Mode) remains stable. Country-specific concepts are reference data. Future capabilities are either additive (new reference data values) or separate bounded contexts (International Mobility). No core redesign is required.
# Compiled Deliverables
## 1. Resolution for Each Finding
## 2. Accepted Recommendations
Admission Pathway as supporting entity (from RI-1, MC-2)
Admission Mode (Cyclic/Rolling/Multiple-Intake) on Programme (from HA-2, OQ-R1)
Authority Type as collection (from RC-2)
Application Deadline on Scholarship (from RC-3, DD3-11)
Faculty on Programme (from RC-4, DD3-10)
Country as type-safe reference wrapper (modified from RI-3, MC-1)
Location optional on Educational Institution (from HA-3)
Admission/Eligibility Policy separation rationale documented (from RC-1)
## 3. Rejected Recommendations
Country as domain Value Object (RI-3 original form) — Country is reference data, not a domain concept. Accepted as type-safe wrapper instead.
Campus as entity (implicit in HA-3 analysis) — Domain evidence does not justify a separate entity for MVP.
Programme Offering as entity (MC-3) — Already rejected in integrity review. Confirmed: per-cycle variation is handled through Admission Policy.
## 4. Modified Domain Concepts
## 5. New Entities
## 6. New Value Objects
## 7. Removed or Demoted Concepts
## 8. Revised Assumptions
## 9. Revised Open Questions
## 10. Updated Bounded-Context Assessment
Implementation approach for MVP:
Single Laravel application with domain namespaces (App\Domain\Opportunity, App\Domain\Trust, App\Domain\Shared)
No cross-context Eloquent relations — use domain ID references
Refactor to separate deployments when the code shows the seams (Stage 2+)
## 11. Global Expansion Assessment
## 12. Final Domain Foundation Readiness Verdict
## Required Changes Summary
## Revised Entity Count
5 Aggregate Roots: Educational Institution, Programme, Scholarship, Admission Cycle, Information Source
3 Child Entity Types: Admission Policy, Eligibility Policy, Accreditation Record
4 Supporting Entities: Qualification, Scholarship Provider, Education Authority, Admission Pathway
12 entities total (was 11, +1 Admission Pathway)
## Revised Value Object Count
15 Domain-Meaningful VOs: Admission Rule, Eligibility Rule, Subject Combination, Qualification Threshold, Validity Period, Trust Signal, Institution Type, Award Level, Monetary Amount, Duration, Location, Authority Jurisdiction, Phase Sequence, Admission Mode, Country
12 Enum-like VOs: Accreditation Status, Policy Status, Programme Status, Scholarship Status, Institution Status, Source Reliability, Information Category, Authority Type, Provider Type, Ownership Type, Delivery Mode, Qualification Status
27 total proposed VOs (was 25, +2 Admission Mode and Country)

# Final Verdict
READY FOR BEHAVIOUR DISCOVERY WITH MINOR REVISIONS
The domain foundation is stable. All 11 findings from the Domain Integrity Review have been resolved against the canonical Business Discovery and existing Domain Discovery Topics 1–3. The resolutions distinguish genuine domain concepts (Admission Pathway, Admission Mode) from modeling concerns (Country as reference data, Campus as premature entity) and implementation concerns (Currency conversion, attribute-level provenance).
What makes this 'minor revisions' rather than 'ready':
4 required data model corrections must be applied before Behaviour Discovery (Authority Type collection, Application Deadline, Faculty, Policy separation documentation)
4 recommended additions should be applied before Behaviour Discovery to ensure the domain language is complete (Admission Pathway, Admission Mode, Country wrapper, Location optional)
These are targeted corrections and additions, not a redesign. No aggregate boundaries change. No invariants are invalidated. No entity relationships are fundamentally restructured.
What changed from the integrity review's verdict:
The integrity review said 'YES, WITH MINOR REVISIONS' with 4 required + 2 recommended changes. This resolution confirms that verdict but with deeper analysis: 2 of the recommended changes (Admission Pathway, Admission Mode) are upgraded to strongly recommended because multi-country testing proves they are necessary for global validity, not merely nice-to-have. The Country recommendation is modified from 'domain Value Object' to 'type-safe reference wrapper' based on challenging its domain nature. All other findings either confirm the existing model or produce documentation changes only.
What to do next:
Apply the 8 changes listed in the Required Changes Summary. Then proceed to Behaviour Discovery, which will define the business operations on each aggregate root, the domain events they produce, and the application services that orchestrate them. The stable domain language and entity boundaries established here provide the foundation for that work.

| Criterion | Assessment | Evidence |
| --- | --- | --- |
| Identity | YES | Named pathways have identity: 'Direct Entry', 'Foundation Year', 'Transfer Admission'. Domain experts discuss pathways by name. Identity is name + defining authority. |
| Lifecycle | Weak | Pathways are stable reference concepts. A pathway is introduced (e.g., IJMB was introduced in 1976) and rarely deprecated. Lifecycle is administrative, not business-driven. |
| Independent Business Rules | YES | Pathways determine: (1) accepted qualifications, (2) entry level, (3) additional criteria. These are genuine domain rules, not merely data. |
| Referenced by Other Entities | YES | Admission Rules would reference pathways. Currently, rules encode pathway logic implicitly through qualification + threshold combinations. |
| Country-Specific or Universal? | Universal | Every country has admission pathways. The concept is universal; the specific pathways are data. |


| Country | Cyclic Admission? | Rolling Admission? | Multiple Intake? | Continuous? | Details |
| --- | --- | --- | --- | --- | --- |
| Nigeria | Dominant | Rare | No | No | JAMB defines a single national cycle. Institutions follow. All admission is cycle-bound. |
| Ghana | Dominant | Rare | No | No | Similar to Nigeria. GTEC/UCC define admission cycles. |
| Kenya | Dominant | Rare | No | No | KUCCPS defines a placement cycle. Institutional cycles follow. |
| South Africa | Dominant | Some | No | No | Most programmes have annual cycles. Some professional programmes accept rolling applications. |
| UK | Common | Common | Some | No | UCAS cycle is cyclic. But many postgraduate programmes use rolling admission. Clearing is a secondary cyclic window. |
| US | Common | Very common | Yes | Some | Undergraduate: cyclic (with early decision/action). Graduate: rolling is the norm. Community colleges: continuous enrollment. Online programmes: multiple start dates. |
| Canada | Common | Common | Yes | Some | Similar to US. Undergraduate: 3 intake periods (Fall, Winter, Spring/Summer). Graduate: often rolling. CEGEP: cyclic. |
| Germany | Mixed | Common | Some | Yes | NC programmes: cyclic. Non-NC programmes: often rolling or continuous. Summer semester provides a second intake for many programmes. |
| Australia | Common | Common | Yes | No | Main intake: Feb/Mar. Mid-year intake: Jul/Aug. Some programmes accept rolling applications. TAFEs: multiple intakes. |


| Question | Answer | Evidence |
| --- | --- | --- |
| Is Admission Cycle truly universal? | No — it is common but not universal | Rolling admission programmes have no cycle. Continuous enrollment has no cycle. |
| Does every programme have an admission cycle? | No | US graduate programmes, UK postgraduate programmes, German non-NC programmes, online programmes with rolling admission |
| Can a programme exist without one? | Yes | A programme with rolling admission exists and admits students without any cycle entity. |
| Can multiple cycles overlap? | Yes | Nigeria: JAMB national cycle and institutional cycles overlap. Australia: Feb and Jul intakes are overlapping cycles for different semesters. |
| Can admission occur without a discrete cycle? | Yes | Rolling admission, continuous enrollment |
| Can rolling admission coexist with named intake periods? | Yes | Some programmes accept rolling applications but also have preferred intake dates (e.g., 'apply anytime, but cohort starts in September and January') |


| Modeling Level | Definition | Fits Country? | Reasoning |
| --- | --- | --- | --- |
| Value Object | Defined by attributes, no identity, compared by value | Partially | Country ISO code is compared by value, but Country is not 'part of' any entity in the domain sense — it scopes the entity's context |
| Reference Entity | Has identity, referenced by other entities, may have lifecycle | No | Countries do not have a business lifecycle within StudyNexus. A country is not 'created' or 'deprecated' by business operations. |
| Standardized Reference Dataset | External data loaded into the system, used for validation and scoping | YES | Country is ISO 3166-1 data. It is loaded, not created. It is used for validation (valid country code) and scoping (which reference data applies). |
| Domain Concept | Participates in business operations and invariants | No | No invariant references Country. No business operation acts on Country. |


| Scope | Description | Implications |
| --- | --- | --- |
| A: Tertiary only | The domain covers tertiary/post-secondary education | Current model is correct. Institution Types are tertiary types. Qualifications are tertiary-relevant. Admission is tertiary admission. |
| B: Formal education broadly | The domain covers all formal education from primary through postgraduate | Institution Types expand. Qualifications expand. New workflows (e.g., primary school discovery). Model complexity increases significantly. |
| C: Education and training broadly | The domain covers all education, training, and certification opportunities | Vastly broader scope. Includes MOOCs, bootcamps, corporate training, professional certifications, informal learning. Fundamental redesign needed. |


| Concept | Location Relationship | Examples |
| --- | --- | --- |
| Physical institution | Location is identity-defining | University of Lagos is in Lagos. Location is part of what makes it UNILAG. |
| Multi-campus institution | Multiple locations under one identity | University of London has multiple colleges. Federal University of Technology has multiple campuses. |
| Online-only institution | Location is administrative, not discoverable | Coursera, Udacity, Open University (UK). Administrative HQ exists but is irrelevant to students. |
| Hybrid programme | Location is one delivery option among several | MBA with on-campus and online tracks. Location matters for on-campus, not for online. |
| Distance learning | Location is the student’s location, not the institution’s | UK Open University: students are everywhere. Institution’s location is irrelevant. |
| Programme across locations | Location belongs to the offering, not the programme | A B.Sc. offered at both the main campus and a satellite campus. |


| Concept | Needed for MVP? | Needed for Expansion? | Modeling Approach |
| --- | --- | --- | --- |
| Single-currency Monetary Amount | Yes | Yes | Current VO-9. Correct and sufficient. |
| Multi-currency scholarship (tuition in one currency, stipend in another) | No | Yes (study abroad) | Model as two separate Monetary Amounts with different currencies. No VO change needed. |
| Currency conversion | No | Maybe | Not a domain concern. Conversion is an infrastructure/service concern. If needed, it is a read-model concern, not a domain operation. |
| Cost Structure (tuition + fees + accommodation + living costs) | No | Maybe | Each cost component is a separate Monetary Amount on the appropriate entity. Tuition is on Programme. Accommodation and living costs are not domain attributes of any current entity. |


| Concept | Current Model | Should Be | Reasoning |
| --- | --- | --- | --- |
| Credential Type (Qualification) | Entity with identity, attributes, status | Correct | A credential type is a domain concept. It has identity (name + authority), is referenced by rules, and has domain significance. |
| Credential Instance (a person's qualification) | Not modeled | Not modeled (correct for MVP) | StudyNexus does not manage student records. WF4 (Assess Eligibility) compares a user's qualifications against requirements, but the user's qualifications are input data, not domain entities. |


| Authority | Country | Types (Real-World) | Single Type Can Represent? |
| --- | --- | --- | --- |
| JAMB | Nigeria | Coordinating, Examining, Admissions | No — loses critical domain meaning |
| NUC | Nigeria | Regulatory, Accrediting | No — regulatory and accrediting are distinct functions |
| WAEC | Nigeria | Examining | Yes (single type) |
| UCAS | UK | Coordinating, Admissions | No — coordinating applications and processing admissions are distinct |
| OfS | UK | Regulatory | Yes (single type) |
| ABET | US | Accrediting | Yes (single type) |
| CUE | Kenya | Regulatory, Accrediting | No — same as NUC |
| KUCCPS | Kenya | Coordinating, Admissions | No — same as JAMB |
| CHE | South Africa | Accrediting, Standard-Setting | No — CHE both accredits and sets the HEQSF |


| Dimension | Admission Policy | Eligibility Policy |
| --- | --- | --- |
| Domain purpose | Determines who can be admitted to a programme | Determines who can apply for a scholarship |
| Governed by | Programme or Institution | Scholarship |
| Rule nature | Qualification-centric: qualification + threshold + subjects | Broader: qualification + threshold + geographic + demographic + financial need |
| Rule structure (VO) | Admission Rule (VO-1): qualification, threshold, subject combination, rule type, description | Eligibility Rule (VO-2): qualification (optional), threshold (optional), condition type, condition text, rule type |
| Identity composition | Governed Entity + Admission Cycle | Owning Scholarship + Applicable Period |
| Temporal scoping | Cycle-scoped (one policy per admission cycle) | Period-scoped (one policy per offering period) |
| Parent entity | Programme or Institution (polymorphic) | Scholarship (single type) |
| Domain language | 'Admission requirements', 'entry criteria', 'cut-off marks' | 'Eligibility criteria', 'qualification requirements', 'application conditions' |
| Workflow | WF4: Assess Eligibility for admission | WF4: Assess Eligibility for scholarship |
| Change frequency | May change per cycle (new admission requirements each year) | May change per offering (new eligibility criteria each year) |


| Criterion | Assessment |
| --- | --- |
| Language | 'Opportunity', 'programme', 'scholarship', 'admission requirements', 'eligibility' — self-contained language |
| Model divergence | Internal model is self-consistent. References Trust context for provenance but does not need to understand trust internals. |
| Invariants | INV-P1 through INV-P5, INV-S1 through INV-S5, INV-C1 through INV-C3, INV-I3, INV-P4 — these are internal to this context |
| Ownership | Owns Institution, Programme, Scholarship, Admission Cycle, Admission Policy, Eligibility Policy |
| Independent change | Can add new opportunity types (fellowships, grants) without affecting Trust context |


| Criterion | Assessment |
| --- | --- |
| Language | 'Trust signal', 'provenance', 'accreditation', 'reliability', 'verification' — distinct from opportunity language |
| Model divergence | Accreditation in this context = quality assessment. Accreditation in Opportunity context = a signal used for comparison. Different perspectives on the same concept. |
| Invariants | INV-IS1 through INV-IS3, INV-2, INV-10 — these govern trust and jurisdiction, not opportunity structure |
| Ownership | Owns Information Source, Accreditation Record. References Education Authority. |
| Independent change | Trust assessment can evolve (new reliability algorithms, attribute-level provenance) without affecting opportunity structure |


| Criterion | Assessment |
| --- | --- |
| Language | No distinct language — uses terms from both other contexts (Institution Type, Award Level, etc.) |
| Model divergence | No model to diverge — this is a data store, not a domain model |
| Invariants | No domain invariants — only data integrity constraints (valid ISO codes, non-empty values) |
| Ownership | No business operations to own — data is loaded and referenced |
| Independent change | Reference data changes do not require code changes, but they affect both other contexts |


| Context | Type | Entities | Language | Can Deploy Independently? |
| --- | --- | --- | --- | --- |
| Opportunity Discovery | Bounded Context | Institution, Programme, Scholarship, Admission Cycle, Admission Policy, Eligibility Policy, Qualification, Admission Pathway | opportunity, programme, admission, eligibility, scholarship | Yes |
| Trust & Accreditation | Bounded Context | Information Source, Accreditation Record, Education Authority | trust, provenance, accreditation, reliability, verification | Yes |
| Reference Framework | Shared Kernel | All VOs and reference data (Institution Type, Award Level, Country, etc.) | No distinct language | No — supporting layer |


| Country | Structural Changes? | What Differs (Reference Data Only) |
| --- | --- | --- |
| Nigeria | No | Current reference data. Admission Mode default = Cyclic. Admission Pathways: UTME, Direct Entry. |
| Ghana | No | Institution Types (University, University College, Polytechnic, Technical Institute). Authorities (GTEC, NAB, WAEC). Qualifications (WASSCE, BECE). Admission Mode = Cyclic. |
| Kenya | No | Institution Types (University, National Polytechnic, Technical College). Authorities (CUE, KNEC, KUCCPS). Qualifications (KCSE, KCPE). Admission Pathways: standard KCSE, diploma progression. |
| South Africa | No | Institution Types (University, University of Technology, TVET College). Authorities (CHE, SAQA, Umalusi). Qualifications (NSC, NATED). NQF levels. |
| UK | No | Institution Types (University, College, FE College). Authorities (OfS, QAA, UCAS). Qualifications (A-Levels, GCSE, BTEC). Admission Mode = Cyclic (UG) + Rolling (PG). Admission Pathways: standard, Foundation, Access, Clearing. |
| US | No | Institution Types (Research University, Liberal Arts College, Community College). Authorities (regional accreditors, ABET). Qualifications (SAT, ACT, AP). Admission Mode = Cyclic (UG) + Rolling (Grad). Admission Pathways: freshman, transfer. |
| Canada | No | Institution Types (University, University College, College, CEGEP). Provincial authorities. Admission Mode = Multiple-Intake (3 periods) + Rolling (Grad). |
| Germany | No | Institution Types (Universität, Fachhochschule). Authorities (KMK, HRK, ASIIN). Qualifications (Abitur, Fachabitur). Admission Mode = Cyclic (NC) + Rolling (non-NC). Admission Pathways: standard, international applicant. |
| Australia | No | Institution Types (University, TAFE, Private College). Authorities (TEQSA, AQF, VTAC). Admission Mode = Multiple-Intake (Feb + Jul) + Rolling. |


| Capability | Core Domain Changes? | Bounded Context | Details |
| --- | --- | --- | --- |
| Domestic education discovery | No | Opportunity Discovery | Already the core function. No changes. |
| Study abroad | No (new context) | New: International Mobility | Visa requirements, partner institutions, credit transfer. Separate bounded context with integration points. |
| Scholarships | No | Opportunity Discovery | Already modeled. No changes. |
| Admissions | No | Opportunity Discovery | Already modeled. No changes. |
| Student visa information | No (new context) | International Mobility | Legal/administrative domain, not educational. Separate context. |
| Online education | No | Opportunity Discovery | Handled by Delivery Mode = Online + Is Location-Relevant = false. |
| Vocational education | No | Opportunity Discovery | New Institution Type + Qualification Level values (reference data). |
| Professional certifications | No | Opportunity Discovery | Certification body = Education Authority (non-governmental, accrediting). Certification = Qualification. |
| Postgraduate education | No | Opportunity Discovery | New Award Level values + Admission Mode = Rolling (common for PG). |


| # | Finding | Resolution | Action |
| --- | --- | --- | --- |
| 1 | Admission Pathway | ACCEPT as supporting entity | New entity: Admission Pathway (supporting) |
| 2 | Admission Mode | ACCEPT as Value Object on Programme | New VO: Admission Mode (VO-26) |
| 3 | Admission Cycle | MODIFY: no longer universal temporal axis | Relationship Programme→Admission Cycle becomes optional |
| 4 | Country | REJECT as domain VO; ACCEPT as reference data wrapper | New VO: Country (VO-27, type-safe reference wrapper) |
| 5 | Tertiary-Only | MAKE EXPLICIT: document assumption | No structural change; revised assumption A-R1 |
| 6 | Location-Bound | MODIFY: Location optional on Institution | No new entities; revised assumption A-R2 |
| 7 | Currency | NO CHANGE for MVP | Document expansion path; revised assumption A-R3 |
| 8 | Static Qualification | CONFIRM: represents credential type | No structural change; revised assumption A-R4 |
| 9 | Authority Type | ACCEPT: multiplicity change | Authority Type → collection on Education Authority |
| 10 | Policy Separation | CONFIRM: separate entities | Document rationale (this document) |
| 11 | Bounded Contexts | 2 genuine BCs + 1 shared kernel | Opportunity Discovery + Trust & Accreditation + Reference Framework (shared) |


| Concept | Modification | Impact |
| --- | --- | --- |
| Programme | Add Admission Mode attribute (VO-26, default Cyclic) | Minor: one new attribute |
| Programme | Add Faculty attribute (String) per DD3-10 | Minor: one new attribute (already decided) |
| Scholarship | Add Application Deadline attribute (Date) per DD3-11 | Minor: one new attribute (already decided) |
| Educational Institution | Location becomes optional | Minor: multiplicity change |
| Education Authority | Authority Type becomes collection (1..N) | Minor: multiplicity change |
| Admission Policy | Identity composition: Cyclic = Entity+Cycle; Rolling = Entity+standing | Minor: conditional identity rule |
| Admission Rule (VO-1) | Add optional pathway reference | Minor: one optional attribute |
| Admission Cycle | Relationship to Programme becomes optional (only for Cyclic programmes) | Minor: relationship cardinality change |


| Entity | Classification | Identity | Attributes |
| --- | --- | --- | --- |
| Admission Pathway | Supporting Entity | Name + Defining Authority | Name, Defining Authority, Entry Level, Accepted Qualifications, Description, Status |


| VO # | Name | Values | Used By |
| --- | --- | --- | --- |
| VO-26 | Admission Mode | Cyclic, Rolling, Multiple-Intake | Programme |
| VO-27 | Country | ISO alpha-2 code + display name | Location, Education Authority, Scholarship Provider (type-safe wrapper over ISO 3166-1) |


| Concept | Action | Reasoning |
| --- | --- | --- |
| Admission Cycle as universal temporal axis | Demoted to pattern-based | No longer the sole temporal pattern. One pattern (Cyclic) among several (Rolling, Multiple-Intake). |
| Country as potential domain entity | Demoted to reference data | Country is reference data with a type-safe wrapper, not a domain concept with business meaning. |
| Admission Pathway as open question (OQ-D3-1) | Promoted to entity | Resolved: pathway has identity, is referenced across aggregates, and fills a ubiquitous language gap. |


| ID | Assumption | Replaces |
| --- | --- | --- |
| A-R1 | The current domain scope is tertiary/post-secondary education. The domain abstractions are designed to be valid across education levels. Expansion beyond tertiary requires reference data additions and potential Admission Mode value extensions, not structural redesign. | HA-1 (implicit tertiary-only) |
| A-R2 | Educational opportunities may be location-bound, location-optional, or location-irrelevant. Location on Educational Institution is optional. The domain does not require a Campus entity for MVP. | HA-3 (location-bound) |
| A-R3 | Monetary Amount uses a single currency per value. Multi-currency scenarios are modeled as multiple Monetary Amounts. Currency conversion is an infrastructure concern, not a domain operation. | HA-4 (single currency) |
| A-R4 | Qualification represents a credential type, not a credential instance. A credential instance is input data for eligibility assessment, not a domain entity. StudyNexus does not manage student records. | HA-5 (static qualifications) |
| A-R5 | Admission is not universally cycle-based. Admission Mode (Cyclic/Rolling/Multiple-Intake) on Programme determines the temporal pattern. Admission Cycle exists only for Cyclic programmes. | HA-2 (cycle-based admission) |
| A-R6 | Country is standardized reference data (ISO 3166-1), not a domain concept. A type-safe VO wrapper exists for validation and type safety, not because Country has domain meaning. | MC-1 (Country as domain VO) |


| ID | Question | Status | Impact |
| --- | --- | --- | --- |
| OQ-D3-1 | Should Admission Pathway be a domain entity? | RESOLVED: Yes, supporting entity | High (filled ubiquitous language gap) |
| OQ-R1 | Should Programme have Admission Mode? | RESOLVED: Yes, VO-26 on Programme | High (global validity) |
| OQ-R5 | Should the model support secondary education? | RESOLVED: Not now; abstractions are valid across levels. Reference data expansion when needed. | Low for MVP |
| OQ-R2 | Should Scholarship targeting support criteria-based targeting? | OPEN | Medium |
| OQ-R3 | Should 'Educational Opportunity' be acknowledged as a ubiquitous language term with no entity? | OPEN | Low |
| OQ-R4 | Should Trust Signals be per-entity or per-attribute? | OPEN | Low for MVP |
| OQ-D3-2 | Should tuition be tracked per cycle/year? | OPEN | Low for MVP |
| OQ-D3-7 | Should accreditation renewal modify existing records? | RESOLVED: No; new record per event (confirmed C-4) | Low |
| OQ-NEW-1 | Should Admission Pathway reference an Admission Cycle (for cycle-specific pathway rules)? | NEW | Low for MVP; pathway is authority-defined, not cycle-defined |


| Context | Type | Entities | Can Deploy Independently? | Cross-Context Communication |
| --- | --- | --- | --- | --- |
| Opportunity Discovery | Bounded Context | Institution, Programme, Scholarship, Admission Cycle, Admission Policy, Eligibility Policy, Qualification, Admission Pathway | Yes | References Trust for provenance; uses Shared for reference data |
| Trust & Accreditation | Bounded Context | Information Source, Accreditation Record, Education Authority | Yes | Referenced by Opportunity for trust signals; uses Shared for reference data |
| Reference Framework | Shared Kernel | All VOs (Institution Type, Award Level, Country, etc.) | No | Used by both contexts; changes are configuration, not code |


| Expansion | Core Changes? | Context | Approach |
| --- | --- | --- | --- |
| New country (Ghana, Kenya, etc.) | No — reference data only | Shared Kernel | Load new Institution Types, Qualifications, Authorities, Pathways |
| Study abroad | No — new context | New: International Mobility | Visa, credit transfer, partner institutions, language requirements |
| Online education expansion | No | Opportunity Discovery | Delivery Mode = Online, Is Location-Relevant = false |
| Vocational education | No — reference data | Opportunity Discovery | New Institution Type + Qualification Level values |
| Professional certifications | No | Opportunity Discovery | Certification body = Education Authority, Certification = Qualification |
| Fellowships/Grants | No — potential new aggregate roots | Opportunity Discovery | Same structure as Scholarship; separate entities per LBC |
| Secondary education | No — reference data | Opportunity Discovery | New Institution Type values, Qualification Level values |
| Research opportunities | No — new context | New: Research Discovery | PhD positions, post-docs, research topics |


| Dimension | Pre-Resolution | Post-Resolution | Improvement |
| --- | --- | --- | --- |
| Correctness | 8/10 | 9/10 | Admission Mode fixes rolling admission gap; Admission Pathway fills language gap |
| Completeness | 7/10 | 9/10 | Two missing concepts resolved (Pathway, Mode); two missing attributes added (Deadline, Faculty) |
| Conceptual Integrity | 9/10 | 9/10 | Maintained; all changes are additive or corrective |
| Extensibility | 8/10 | 9/10 | Zero structural changes needed across 9 countries |
| Consistency | 9/10 | 9/10 | Maintained; no invariant conflicts introduced |
| Ubiquitous Language | 7/10 | 9/10 | Admission Pathway and Admission Mode fill language gaps |
| Long-Term Maintainability | 8/10 | 9/10 | Explicit assumptions prevent future misinterpretation |


| # | Change | Type | Effort | Source |
| --- | --- | --- | --- | --- |
| 1 | Authority Type → Collection (RC-2) | Data model correction | Trivial | Finding 9 |
| 2 | Add Application Deadline to Scholarship (RC-3) | Attribute addition | Trivial | DD3-11 |
| 3 | Add Faculty to Programme (RC-4) | Attribute addition | Trivial | DD3-10 |
| 4 | Add Admission Pathway as supporting entity | New entity | Small | Finding 1 |
| 5 | Add Admission Mode (VO-26) to Programme | New VO + attribute | Small | Finding 2 |
| 6 | Add Country (VO-27) as type-safe reference wrapper | New VO | Small | Finding 4 |
| 7 | Location optional on Educational Institution | Multiplicity change | Trivial | Finding 6 |
| 8 | Document policy separation rationale | Documentation | Trivial | Finding 10 |
