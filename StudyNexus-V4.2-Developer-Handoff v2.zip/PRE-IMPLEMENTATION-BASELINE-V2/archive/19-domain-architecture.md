# StudyNexus — Domain Architecture

> **⚠️ Reconciliation Note (2026-08-08):** C2 Resolution: This document states "Value Objects (27)" and "Enum-like (13)". Authoritative recount from the implementation matrix (§5) and the frozen baseline (file 21) confirms **28 Value Objects** total: 12 genuine domain VOs (immutable PHP objects, including 1 computed + 1 demoted-from-entity) + 16 PHP Backed Enums. The original "13 enums" count omitted 3 behavioural enums (InstitutionType, AwardLevel, AdmissionMode) that are implemented as PHP Backed Enums despite having domain behaviour. Headers below are historical; the authoritative count is in file 21 §10.

# Laravel Beyond CRUD + TALL Stack + Spatie Integration

**Date:** 2026-08-07
**Status:** Domain Architecture
**Prerequisite:** Domain Discovery Topics 1–4 (complete and reviewed), Consolidation (13), Behaviour Discovery (14)
**Architectural Philosophy:** Laravel Beyond CRUD (Brent Roose & Freek Van der Herten) — Pragmatic Domain-Driven Design
**Stack:** TALL (Laravel + Blade + Livewire + Flux + Tailwind CSS) + Filament (Admin)
**Objective:** Translate the discovered domain into a practical Laravel Beyond CRUD architecture that is the simplest Laravel application accurately expressing the domain, protecting important business rules, remaining pleasant to develop, and growing from Nigeria → Africa → global education without requiring a rewrite.

---

## 1. Architectural Principles

The architecture of StudyNexus is governed by eight principles derived from Laravel Beyond CRUD, the domain discovery process, and the project's global-first ambitions. These principles are not aspirational — they are decision criteria. When two approaches conflict, the principle with higher priority wins.

### P1: Domain Accuracy Over Theoretical Purity

The code structure must reflect the StudyNexus domain as discovered through Topics 1–4. This means aggregate boundaries, domain operations, and invariants must be expressible and enforceable in code. It does NOT mean every domain concept needs a dedicated class, interface, or abstraction. The question is always: "Does this code structure make it easy to see and protect the business rules?" — not "Does this code structure conform to a DDD textbook?"

### P2: Pragmatic Laravel Idioms

When Laravel provides a convention that adequately serves the domain, use it. Do not introduce repositories, services, or abstractions merely because they are "proper DDD." Introduce them when they express genuine domain concepts or protect meaningful business rules. Eloquent models are the default persistence mechanism. Actions are the default command mechanism. Events are the default integration mechanism.

### P3: Invariant Protection at Aggregate Boundaries

The five aggregate roots exist because they protect real business invariants (22 invariants discovered in Behaviour Discovery). The architecture must make it difficult to violate these invariants. This means: aggregate roots are the entry points for state changes. Child entities are not independently modifiable. Cross-aggregate references use identity, not object references.

### P4: Separate Domain from Application from Presentation

Domain objects (entities, value objects, domain events, invariants) contain business rules that would exist regardless of Laravel. Application objects (actions, queries, DTOs, event listeners) orchestrate use cases. Presentation objects (Livewire components, Blade templates, Filament resources) render and capture interaction. The dependency direction is Presentation → Application → Domain. Never the reverse.

### P5: Global-First, Nigeria-First-Dataset

Nigeria is the first dataset, not the architectural boundary. Nigerian concepts (JAMB, WAEC, NUC, UTME) are instances of universal concepts (Education Authority, Qualification, Admission Pathway). The architecture must not hardcode Nigerian assumptions into entity names, aggregate rules, value objects, enums, services, or workflows. At the same time, do not over-generalize merely because global expansion is planned. Generalize where genuinely universal; configure where the variation is data; defer where future variation is speculative.

### P6: TALL Stack — No SPA

StudyNexus uses Laravel + Blade + Livewire + Flux + Tailwind CSS for all user-facing interfaces. Filament is the admin panel. There is no React, Next.js, Vue, or separate frontend application. Server-rendered HTML with Livewire interactivity is the architecture. This is not a limitation — it is a deliberate choice for SEO, simplicity, and team velocity.

### P7: Proven Packages Before Reinvention

Spatie packages are evaluated for every requirement they cover. However, a package must never dictate the domain model. Model the domain correctly first; then determine whether a package provides appropriate infrastructure. Rejection of a package is as important as adoption — every rejection is documented with rationale.

### P8: Evolvable Without Rewrite

The architecture must support expansion from Nigeria → Africa → global education without requiring a rewrite. This means: bounded contexts can be extracted later; new aggregate roots can be added; supporting entities can be promoted when invariant justification emerges; read models can evolve independently. The architecture must not be a distributed system today, but must not preclude one tomorrow.

---

## 2. Canonical Domain Model

The canonical domain model is frozen from Domain Discovery Topics 1–4. This section records the model for architectural reference. **These decisions are not suggestions — they are constraints on the architecture.**

### Aggregate Roots (5)

| # | Entity | Identity | Invariants | Domain Operations | Domain Events |
|---|--------|----------|:----------:|-------------------|---------------|
| 1 | Educational Institution | Official Name + Institution Type + Registration Identifier | 5 (INV-I1–I5) | establish, rename, publishAdmissionPolicy, recordAccreditation, suspend, reactivate, close, mergeWith | 8 events |
| 2 | Programme | Programme Name + Owning Institution + Award Level | 6 (INV-P1–P6) | introduce, publishAdmissionPolicy, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, reassignTo (internal) | 6 events |
| 3 | Scholarship | Scholarship Name + Offering Provider + Application Period | 5 (INV-S1–S5) | announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, targetProgrammes, targetInstitutions, expire | 7 events |
| 4 | Admission Cycle | Period/Year + Defining Authority | 3 (INV-C1–C3) | announce, activate, advancePhase, close, archive | 5 events |
| 5 | Information Source | Source Name + Source Type + Retrievable Reference | 3 (INV-IS1–IS3) | register, verify, markUnreliable, deprecate | 3 events |

### Child Entities (3)

| Entity | Parent | Identity | Key Property |
|--------|--------|----------|--------------|
| Admission Policy | Programme or Institution | Governed Entity + Applicable Admission Cycle | Immutable after publication; supersession chain |
| Eligibility Policy | Scholarship | Owning Scholarship + Applicable Period | Immutable after publication; supersession chain |
| Accreditation Record | Programme or Institution | Accredited Entity + Granting Authority + Effective Period Start | Immutable after creation; status derived from record sequence |

### Supporting Entities (3)

| Entity | Identity | Behaviour | Justification |
|--------|----------|-----------|---------------|
| Qualification | Qualification Name + Defining Authority | deprecate | Referential integrity for admission/eligibility rules |
| Scholarship Provider | Official Name | deprecate | INV-S1 normalization (weakest entity) |
| Education Authority | Abbreviation or Official Name | deprecate | Jurisdiction validation target for accreditation |

### Demoted Entity → Value Object

**Admission Pathway:** Demoted from supporting entity to VO in Behaviour Discovery. No invariants, no autonomous lifecycle, no behaviour. Serves as discriminator within Admission Policy. Valid values are reference data.

### Value Objects (28)  <!-- ⚠️ Corrected: was 27, actual count is 28 per recount -->

**Domain-Meaningful (14):** Admission Rule, Eligibility Rule, Subject Combination, Qualification Threshold, Validity Period, Trust Signal, Monetary Amount, Duration, Location, Authority Jurisdiction, Phase Sequence, Institution Type, Award Level, Admission Mode

**Enum-like (13):** Accreditation Status, Policy Status, Programme Status, Scholarship Status, Institution Status, Source Reliability, Information Category, Authority Type, Provider Type, Ownership Type, Delivery Mode, Qualification Status, Coverage Type

### Domain Events (29)  <!-- ⚠️ Corrected: was 27, actual count is 29 per frozen baseline §10 -->

As enumerated in Behaviour Discovery Section 16. Each is a business fact emitted by an aggregate root, consumed by application-layer listeners for read model projections, search index updates, notification dispatch, and trust signal recalculation.

### Read-Model Queries (7)

| Query | Derives From | Nature |
|-------|-------------|--------|
| isAdmitting | Programme lifecycle + Admission Cycle current phase + Admission Policy existence | Cross-aggregate read model |
| isApplicableTo | Scholarship targeting + Programme/Institution identity | Scholarship aggregate read |
| isReliable | Information Source reliability status | Source aggregate read |
| isAdmissionOpen | Admission Cycle current phase | Cycle aggregate read |
| getTrustSignal | Information Source provenance + verification history | Computed projection |
| getAccreditationStatus | Accreditation Record collection for entity | Collection-derived read |
| getCurrentActivePolicy | Policy collection for entity + scope | Collection-derived read |

### Domain Services (1)

**InstitutionMerger** — The only domain service. Coordinates the institution merge operation across Institution and Programme aggregates within a single transaction. Enforces INV-P1 (programme ownership) during reassignment. No other cross-aggregate interaction requires a domain service.

### Bounded Contexts

| Context | Entities | Implementation Strategy |
|---------|----------|------------------------|
| Opportunity Discovery | Institution, Programme, Scholarship, Admission Cycle, Admission Policy, Eligibility Policy, Admission Pathway (VO), Qualification | Primary Laravel app context |
| Trust & Accreditation | Information Source, Accreditation Record, Education Authority | Same Laravel app; namespace separation |
| Reference Framework (Shared Kernel) | Qualification, Scholarship Provider, Education Authority, Institution Type, Award Level, Authority Type, all enum VOs, Country | Shared within the app; no separate deployment |

**MVP Decision:** Single Laravel application implementing all three bounded contexts with namespace separation. Refactor seams exist for future context extraction.

---

## 3. Aggregate Architecture

### Aggregate Root 1: Educational Institution

**Eloquent Model:** `Institution`
**Table:** `institutions`
**Contains:**
- Identity attributes: `official_name`, `institution_type` (VO cast), `registration_identifier`
- Mutable attributes: `location` (VO cast, nullable), `ownership_type` (enum cast), `year_established`, `website_url`, `description`
- Status: `status` (InstitutionStatus enum)
- Collections: `admissionPolicies()` (hasMany), `accreditationRecords()` (hasMany)
- References: `country_code` (reference data)

**Invariants enforced in code:**
- INV-I1: Valid type validated in `establish()` — Application-layer validation against reference data before domain operation
- INV-I2: Jurisdiction check in `recordAccreditation()` — Application-layer guard querying Education Authority
- INV-I3: One active policy per cycle enforced in `publishAdmissionPolicy()` — checks existing active policy for the same cycle
- INV-I4: Non-empty official name enforced in `establish()` and `rename()`
- INV-I5: Closed state check at the start of every business operation

**Public domain operations:**
- `establish(name, type, registrationId, ...)` — Creates institution in Operational state. Emits `InstitutionEstablished`.
- `rename(newName)` — Changes official name. Emits `InstitutionRenamed`.
- `publishAdmissionPolicy(cycleId, rules, sourceRef)` — Creates/supersedes admission policy. Emits `InstitutionalAdmissionPolicyPublished`.
- `recordAccreditation(authorityId, status, validityPeriod, sourceRef)` — Adds accreditation record. Emits `InstitutionAccredited`.
- `suspend()` — Sets status to Suspended. Emits `InstitutionSuspended`.
- `reactivate()` — Sets status to Operational (from Suspended only). Emits `InstitutionReactivated`.
- `close()` — Sets status to Closed (terminal). Emits `InstitutionClosed`.
- `mergeWith(targetInstitutionId)` — Coordinates merge via InstitutionMerger domain service. Emits `InstitutionsMerged`.

**What it must NOT know about:**
- Programme details beyond identity (programme count is a read model query)
- Scholarship details beyond identity
- Current Admission Cycle phase (that is a read model concern)
- Search index state
- UI state

### Aggregate Root 2: Programme

**Eloquent Model:** `Programme`
**Table:** `programmes`
**Contains:**
- Identity attributes: `programme_name`, `award_level` (VO cast), `faculty`
- References: `institution_id` (belongsTo Institution), `admission_mode` (AdmissionMode enum)
- Mutable attributes: `duration` (VO cast), `delivery_mode` (enum cast), `description`, `tuition_fee` (MonetaryAmount VO cast, nullable)
- Status: `status` (ProgrammeStatus enum)
- Collections: `admissionPolicies()` (hasMany), `accreditationRecords()` (hasMany)

**Invariants enforced in code:**
- INV-P1: `institution_id` is set at `introduce()` and never changes except via `reassignTo()` (domain service only)
- INV-P2: One active policy per cycle enforced in `publishAdmissionPolicy()`
- INV-P3: Query invariant — `isAdmitting` is a read model, not an aggregate operation
- INV-P4: Award level validated against institution type — Application-layer guard
- INV-P5: Jurisdiction check in `recordAccreditation()` — Application-layer guard
- INV-P6: Discontinued state check at the start of every business operation

**Public domain operations:**
- `introduce(name, institutionId, awardLevel, ...)` — Creates programme in Admitting state. Emits `ProgrammeIntroduced`.
- `publishAdmissionPolicy(cycleId, rules, sourceRef)` — Creates/supersedes admission policy. Emits `ProgrammeAdmissionPolicyPublished`.
- `suspendAdmission()` — Sets status to Suspended. Emits `ProgrammeAdmissionSuspended`.
- `resumeAdmission()` — Sets status to Admitting. Emits `ProgrammeAdmissionResumed`.
- `discontinue()` — Sets status to Discontinued (terminal). Emits `ProgrammeDiscontinued`.
- `recordAccreditation(authorityId, status, validityPeriod, sourceRef)` — Adds accreditation record. Emits `ProgrammeAccredited`.
- `reassignTo(newInstitutionId)` — Internal operation for InstitutionMerger only. Changes institution_id.

**What it must NOT know about:**
- Institution's current status (application layer validates before operation)
- Scholarship targeting (unidirectional — Scholarship knows Programme, not vice versa)
- Current Admission Cycle phase
- Whether applications are open (read model)

### Aggregate Root 3: Scholarship

**Eloquent Model:** `Scholarship`
**Table:** `scholarships`
**Contains:**
- Identity attributes: `scholarship_name`, `application_deadline` (date)
- References: `provider_id` (belongsTo ScholarshipProvider), `country_code` (reference data)
- Mutable attributes: `coverage_type` (enum cast), `value` (MonetaryAmount VO cast, nullable), `description`, `eligibility_criteria_summary`
- Status: `status` (ScholarshipStatus enum)
- Collections: `eligibilityPolicies()` (hasMany), `targetProgrammeIds` (JSON/array), `targetInstitutionIds` (JSON/array)

**Invariants enforced in code:**
- INV-S1: Provider is set at `announce()` and never changes
- INV-S2: One active eligibility policy per period enforced in `publishEligibilityPolicy()`
- INV-S3: State guard: `openApplications` requires Announced state
- INV-S4: State guard: `closeApplications` requires Open state
- INV-S5: `openApplications` requires at least one published Eligibility Policy

**Public domain operations:**
- `announce(name, providerId, ...)` — Creates scholarship in Announced state. Emits `ScholarshipAnnounced`.
- `publishEligibilityPolicy(rules, period, sourceRef)` — Creates/supersedes eligibility policy. Emits `ScholarshipEligibilityPolicyPublished`.
- `openApplications()` — Sets status to Open. Emits `ScholarshipApplicationsOpened`.
- `closeApplications()` — Sets status to Closed. Emits `ScholarshipApplicationsClosed`.
- `withdraw()` — Sets status to Withdrawn (terminal). Emits `ScholarshipWithdrawn`.
- `targetProgrammes(programmeIds)` — Updates target programme list. Emits `ScholarshipTargetsUpdated`.
- `targetInstitutions(institutionIds)` — Updates target institution list. Emits `ScholarshipTargetsUpdated`.
- `expire()` — Sets status to Expired (terminal). Emits `ScholarshipExpired`.

**What it must NOT know about:**
- Programme or Institution details beyond identity
- Whether targeted programmes still exist (read model concern)
- Application submission state (out of scope for discovery platform)

### Aggregate Root 4: Admission Cycle

**Eloquent Model:** `AdmissionCycle`
**Table:** `admission_cycles`
**Contains:**
- Identity attributes: `period_year`, `period_label`
- References: `defining_authority_id` (belongsTo EducationAuthority)
- Mutable attributes: `phase_sequence` (PhaseSequence VO cast), `current_phase_index`
- Status: `status` (enum: Upcoming, Active, Closed, Archived)
- Dates: `start_date`, `end_date`

**Invariants enforced in code:**
- INV-C1: Start and end dates are set at `announce()` and are required
- INV-C2: `advancePhase()` only allows advancing to the next phase in the sequence — no backwards, no skipping
- INV-C3: End date must be after start date

**Public domain operations:**
- `announce(periodYear, authorityId, phases, startDate, endDate)` — Creates cycle in Upcoming state. Emits `AdmissionCycleAnnounced`.
- `activate()` — Sets status to Active (from Upcoming only). Emits `AdmissionCycleActivated`.
- `advancePhase()` — Advances current phase by one step. Emits `AdmissionCyclePhaseAdvanced`.
- `close()` — Sets status to Closed. Emits `AdmissionCycleClosed`.
- `archive()` — Sets status to Archived (terminal).

**What it must NOT know about:**
- Which programmes are associated (programmes hold cycle IDs, not vice versa)
- Whether programmes are currently admitting (read model concern)
- Scholarship or Institution state

### Aggregate Root 5: Information Source

**Eloquent Model:** `InformationSource`
**Table:** `information_sources`
**Contains:**
- Identity attributes: `source_name`, `source_type`, `retrievable_reference`
- Mutable attributes: `last_verified_at`, `information_category` (enum)
- Status: `reliability` (SourceReliability enum)

**Invariants enforced in code:**
- INV-IS1: Cannot be simultaneously Verified and Unreliable — state machine enforces
- INV-IS2: Cannot verify a Deprecated source — guard in `verify()`
- INV-IS3: Retrievable reference is required at `register()`

**Public domain operations:**
- `register(name, type, reference, category)` — Creates source in Registered state.
- `verify()` — Sets reliability to Verified. Emits `InformationSourceVerified`.
- `markUnreliable()` — Sets reliability to Unreliable. Emits `InformationSourceMarkedUnreliable`.
- `deprecate()` — Sets reliability to Deprecated (terminal). Emits `InformationSourceDeprecated`.

**What it must NOT know about:**
- Which entities reference it (trust signal recalculation is application-layer)
- Search index state

---

## 4. Entity → Eloquent Mapping Strategy

### Core Principle

**Eloquent Model ≠ Aggregate Root by default.** In StudyNexus, Eloquent models serve as the persistence representation of aggregate roots, but the aggregate's domain operations are expressed through dedicated methods on the model, not through raw attribute assignment. The mapping strategy is:

| Domain Concept | Laravel Implementation | Rationale |
|---------------|----------------------|-----------|
| Aggregate Root | Eloquent Model with domain operation methods | Pragmatic: Eloquent is Laravel's ORM; creating a separate domain entity + repository for every aggregate is over-engineering for a small team |
| Child Entity | Eloquent Model with BelongsTo parent | Lifecycle controlled by parent aggregate's domain operations; no independent controller/routes |
| Supporting Entity | Eloquent Model | Simple CRUD management via Filament; referenced by ID |
| Value Object (domain-meaningful) | Custom Eloquent Cast | Laravel's cast system is perfect for VO persistence — encode/decode to/from DB column(s) |
| Value Object (enum-like) | PHP 8.1+ Backed Enum with Eloquent casting | Native enum support; no package needed |
| Domain Operation | Method on Eloquent Model (or Action class for orchestration) | Simple operations live on the model; complex orchestration lives in Actions |
| Domain Event | Laravel Event dispatched from model method | Native Laravel events; no event sourcing framework |
| Read-Model Query | Dedicated Query class or Eloquent scope | Keeps query logic out of domain models |

### Mapping Table

| Domain Entity | Eloquent Model | Table | Key Casts | Relationships |
|--------------|----------------|-------|-----------|---------------|
| Educational Institution | `App\Models\Institution` | `institutions` | `institution_type` → InstitutionType VO, `location` → Location VO, `status` → InstitutionStatus enum, `ownership_type` → OwnershipType enum | hasMany AdmissionPolicy, hasMany AccreditationRecord |
| Programme | `App\Models\Programme` | `programmes` | `award_level` → AwardLevel VO, `duration` → Duration VO, `admission_mode` → AdmissionMode enum, `delivery_mode` → DeliveryMode enum, `tuition_fee` → MonetaryAmount VO, `status` → ProgrammeStatus enum | belongsTo Institution, hasMany AdmissionPolicy, hasMany AccreditationRecord |
| Scholarship | `App\Models\Scholarship` | `scholarships` | `coverage_type` → CoverageType enum, `value` → MonetaryAmount VO, `status` → ScholarshipStatus enum | belongsTo ScholarshipProvider, hasMany EligibilityPolicy |
| Admission Cycle | `App\Models\AdmissionCycle` | `admission_cycles` | `phase_sequence` → PhaseSequence VO, `status` → AdmissionCycleStatus enum | belongsTo EducationAuthority |
| Information Source | `App\Models\InformationSource` | `information_sources` | `reliability` → SourceReliability enum, `information_category` → InformationCategory enum | — |
| Admission Policy | `App\Models\AdmissionPolicy` | `admission_policies` | `rules` → JSON (collection of AdmissionRule VOs), `validity_period` → ValidityPeriod VO, `status` → PolicyStatus enum, `admission_pathway` → AdmissionPathway VO (nullable) | belongsTo Programme or Institution (polymorphic), belongsTo AdmissionCycle |
| Eligibility Policy | `App\Models\EligibilityPolicy` | `eligibility_policies` | `rules` → JSON (collection of EligibilityRule VOs), `validity_period` → ValidityPeriod VO, `status` → PolicyStatus enum | belongsTo Scholarship |
| Accreditation Record | `App\Models\AccreditationRecord` | `accreditation_records` | `status` → AccreditationStatus enum, `validity_period` → ValidityPeriod VO | belongsTo Accreditable (polymorphic: Programme or Institution), belongsTo EducationAuthority |
| Qualification | `App\Models\Qualification` | `qualifications` | `status` → QualificationStatus enum | belongsTo EducationAuthority |
| Scholarship Provider | `App\Models\ScholarshipProvider` | `scholarship_providers` | — | — |
| Education Authority | `App\Models\EducationAuthority` | `education_authorities` | `authority_types` → JSON (collection of AuthorityType enums), `jurisdiction` → AuthorityJurisdiction VO | — |

### Polymorphic Relationships

Admission Policy and Accreditation Record use polymorphic relationships because they can belong to either an Institution or a Programme. This is Laravel-idiomatic and avoids duplicate table structures.

- `admission_policies`: `governed_entity_type` (Institution/Programme), `governed_entity_id`
- `accreditation_records`: `accreditable_type` (Institution/Programme), `accreditable_id`

### Eloquent Model Guardrails

To prevent anemic models and protect invariants:

1. **`$guarded = []` is forbidden.** Every model uses `$fillable` with explicit attribute list.
2. **Direct attribute assignment is discouraged for domain operations.** Use `$model->performOperation()` instead of `$model->status = 'closed'; $model->save()`.
3. **Child entities have no independent update endpoints.** Their lifecycle is controlled through parent aggregate operations.
4. **Status transitions use named methods**, not raw status assignment. Each method validates preconditions and dispatches events.
5. **Eloquent accessors/mutators are used for VO casts**, not for business logic.

---

## 5. Value Object Implementation Strategy

### Classification Approach

Each of the 27 Value Objects is classified by its optimal implementation strategy. The classification considers: Does PHP 8.1+ enum suffice? Is immutable object needed? Does the VO have complex structure requiring a cast? Is it reference data?

### Implementation Matrix

| # | Value Object | Strategy | Implementation | Rationale |
|---|-------------|----------|----------------|-----------|
| 1 | Admission Rule | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\AdmissionRule` cast to/from JSON column | Complex structure (qualification ref, threshold, subjects, rule type); natural JSON representation |
| 2 | Eligibility Rule | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\EligibilityRule` cast to/from JSON column | Complex structure; similar pattern to Admission Rule |
| 3 | Subject Combination | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\SubjectCombination` | Set of subjects + combination type; JSON is natural |
| 4 | Qualification Threshold | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\QualificationThreshold` | qualification ref + comparator + value + scale; structured |
| 5 | Validity Period | Immutable PHP Object + Custom Cast | `App\Domain\ValueObjects\ValidityPeriod` → two date columns | Start + end dates; storing as separate columns enables date range queries |
| 6 | Trust Signal | Computed (never stored) | Query/Read model only | Derived attribute per Behaviour Discovery |
| 7 | Monetary Amount | Immutable PHP Object + Custom Cast | `App\Domain\ValueObjects\MonetaryAmount` → amount + currency columns | Requires separate columns for amount (decimal) and currency (string) for DB queries |
| 8 | Duration | Immutable PHP Object + Custom Cast | `App\Domain\ValueObjects\Duration` | value + unit; simple structure |
| 9 | Location | Immutable PHP Object + Custom Cast (nullable) | `App\Domain\ValueObjects\Location` → country + region + city columns | Separate columns for geographic queries; nullable for online-only institutions |
| 10 | Authority Jurisdiction | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\AuthorityJurisdiction` | Jurisdiction type + criteria; structured data |
| 11 | Phase Sequence | Immutable PHP Object + JSON Cast | `App\Domain\ValueObjects\PhaseSequence` | Ordered list of phases; JSON preserves ordering |
| 12 | Institution Type | PHP Backed Enum | `App\Domain\Enums\InstitutionType:string` | Fixed set of types; values are data (University, Polytechnic, College, etc.) |
| 13 | Award Level | PHP Backed Enum | `App\Domain\Enums\AwardLevel:string` | Fixed set of levels; values are data |
| 14 | Admission Mode | PHP Backed Enum | `App\Domain\Enums\AdmissionMode:string` | Three values: Cyclic, Rolling, MultipleIntake |
| 15 | Accreditation Status | PHP Backed Enum | `App\Domain\Enums\AccreditationStatus:string` | Fixed enum |
| 16 | Policy Status | PHP Backed Enum | `App\Domain\Enums\PolicyStatus:string` | Fixed enum |
| 17 | Programme Status | PHP Backed Enum | `App\Domain\Enums\ProgrammeStatus:string` | Fixed enum |
| 18 | Scholarship Status | PHP Backed Enum | `App\Domain\Enums\ScholarshipStatus:string` | Fixed enum |
| 19 | Institution Status | PHP Backed Enum | `App\Domain\Enums\InstitutionStatus:string` | Fixed enum |
| 20 | Source Reliability | PHP Backed Enum | `App\Domain\Enums\SourceReliability:string` | Fixed enum |
| 21 | Information Category | PHP Backed Enum | `App\Domain\Enums\InformationCategory:string` | Fixed enum |
| 22 | Authority Type | PHP Backed Enum | `App\Domain\Enums\AuthorityType:string` | Used as collection on EducationAuthority |
| 23 | Provider Type | PHP Backed Enum | `App\Domain\Enums\ProviderType:string` | Fixed enum |
| 24 | Ownership Type | PHP Backed Enum | `App\Domain\Enums\OwnershipType:string` | Fixed enum |
| 25 | Delivery Mode | PHP Backed Enum | `App\Domain\Enums\DeliveryMode:string` | Fixed enum |
| 26 | Qualification Status | PHP Backed Enum | `App\Domain\Enums\QualificationStatus:string` | Fixed enum |
| 27 | Coverage Type | PHP Backed Enum | `App\Domain\Enums\CoverageType:string` | Fixed enum |

### Additional Value Object: Admission Pathway (Demoted from Entity)

| VO | Strategy | Implementation | Rationale |
|----|----------|----------------|-----------|
| Admission Pathway | Immutable PHP Object | `App\Domain\ValueObjects\AdmissionPathway` (name + authority ref) | Used as discriminator within Admission Policy rules; no independent lifecycle |

### Custom Eloquent Cast Pattern

For complex VOs stored across multiple columns:

```php
// Example: MonetaryAmount cast
class MonetaryAmountCast implements CastsAttributes
{
    public function get(Model $model, string $key, mixed $value, array $attributes): ?MonetaryAmount
    {
        if (! isset($attributes['amount']) || ! isset($attributes['currency'])) {
            return null;
        }
        return new MonetaryAmount(
            amount: (string) $attributes['amount'],
            currency: $attributes['currency']
        );
    }

    public function set(Model $model, string $key, mixed $value, array $attributes): array
    {
        if ($value === null) {
            return ['amount' => null, 'currency' => null];
        }
        return ['amount' => $value->amount, 'currency' => $value->currency];
    }
}
```

For VOs stored as JSON:

```php
// Example: AdmissionRule cast
class AdmissionRuleCast implements CastsAttributes
{
    public function get(Model $model, string $key, mixed $value, array $attributes): ?AdmissionRule
    {
        if ($value === null) return null;
        $data = json_decode($value, true);
        return AdmissionRule::fromArray($data);
    }

    public function set(Model $model, string $key, mixed $value, array $attributes): ?string
    {
        if ($value === null) return null;
        return json_encode($value->toArray());
    }
}
```

### Why Not Spatie Laravel Data for VOs?

Spatie Laravel Data is excellent for application-layer DTOs (request/response transformation), but domain Value Objects should remain plain PHP objects. Reasons:
1. VOs express domain equality semantics, not wire format semantics.
2. VOs are immutable and compared by value — Laravel Data adds wire-format concerns.
3. VOs should not have `fromRequest()` or `toResponse()` methods — those are DTO responsibilities.
4. A VO should remain testable without Laravel infrastructure.

**Decision:** Domain VOs = plain immutable PHP objects with Eloquent casts. DTOs = Spatie Laravel Data objects. Never the same class.

---

## 6. Application Actions

### When Is an Action Worth Having?

In Laravel Beyond CRUD, an Action is a single-purpose class representing one application use case. An Action is worth having when:

1. **The operation involves orchestration** — more than one domain operation, validation step, or side effect.
2. **The operation involves application-layer concerns** — authorization, validation, notification, search index update.
3. **The operation is complex enough** that putting it in a controller makes the controller fat.
4. **The operation is reused** across multiple entry points (HTTP, console, queue, API).

Simple domain operations (e.g., `rename`) that are single method calls on the aggregate with trivial application orchestration can live directly in the controller or Livewire component. Not every operation needs an Action class.

### Action Inventory

| Action | Domain Operation(s) | Application Concerns | Entry Points | Justification |
|--------|--------------------|--------------------|-------------|---------------|
| `CreateInstitution` | `Institution::establish()` | Authorization, jurisdiction validation, search index | HTTP, Filament, Import | Orchestrates validation + domain + indexing |
| `RenameInstitution` | `Institution::rename()` | Authorization, search index | HTTP, Filament | Simple, but index update needed |
| `SuspendInstitution` | `Institution::suspend()` | Authorization, cascade notification | HTTP, Filament | Needs cascade coordination |
| `ReactivateInstitution` | `Institution::reactivate()` | Authorization, search inclusion | HTTP, Filament | Moderate orchestration |
| `CloseInstitution` | `Institution::close()` | Authorization, cascade to programmes, search exclusion | HTTP, Filament | Significant cascade |
| `MergeInstitutions` | `InstitutionMerger::merge()` | Authorization, transactional coordination, search rebuild | Filament only | Most complex operation in domain |
| `PublishAdmissionPolicy` | `Programme/Institution::publishAdmissionPolicy()` | Authorization, cycle validation, rule validation, search update | HTTP, Filament | Complex validation orchestration |
| `RecordAccreditation` | `Programme/Institution::recordAccreditation()` | Authorization, jurisdiction guard, trust signal trigger | HTTP, Filament | Guard + trigger pattern |
| `CreateProgramme` | `Programme::introduce()` | Authorization, institution validation, award level guard | HTTP, Filament, Import | Multiple validations |
| `DiscontinueProgramme` | `Programme::discontinue()` | Authorization, scholarship flag cascade | HTTP, Filament | Cascade needed |
| `ReassignProgramme` | `Programme::reassignTo()` | Internal only (domain service) | Domain service only | No independent invocation |
| `AnnounceScholarship` | `Scholarship::announce()` | Authorization, provider validation | HTTP, Filament | Moderate |
| `OpenScholarshipApplications` | `Scholarship::openApplications()` | Authorization, policy check, notification | HTTP, Filament | Notification trigger |
| `ExpireScholarship` | `Scholarship::expire()` | Scheduled (console/queue) | Scheduler | Time-based trigger |
| `TargetScholarshipProgrammes` | `Scholarship::targetProgrammes()` | Authorization, programme existence check | HTTP, Filament | Existence validation |
| `AnnounceAdmissionCycle` | `AdmissionCycle::announce()` | Authorization, authority validation | HTTP, Filament | Moderate |
| `ActivateAdmissionCycle` | `AdmissionCycle::activate()` | Authorization, read model update trigger | HTTP, Filament, Scheduler | Read model coordination |
| `AdvanceAdmissionCyclePhase` | `AdmissionCycle::advancePhase()` | Authorization, notification dispatch | HTTP, Filament, Scheduler | Notification trigger |
| `RegisterInformationSource` | `InformationSource::register()` | Authorization, reference validation | Filament, Import | Moderate |
| `VerifyInformationSource` | `InformationSource::verify()` | Authorization, trust signal cascade trigger | Filament | Cascade trigger |
| `MarkSourceUnreliable` | `InformationSource::markUnreliable()` | Authorization, trust cascade | Filament | Cascade |
| `ImportInstitutionData` | Multiple creates/updates | Parsing, validation, deduplication, batch processing | Console, Queue | Significant orchestration |
| `ExpireScholarships` (batch) | Multiple `Scholarship::expire()` | Time-based batch | Scheduler | Periodic batch |

### Actions NOT Needed

These operations are simple enough to call directly from controllers/Livewire:

- `Institution::rename()` (except when search index needs synchronous update — then `RenameInstitution`)
- `Programme::suspendAdmission()` / `Programme::resumeAdmission()` — single domain call + auth
- `Scholarship::closeApplications()` — single domain call + auth
- `Scholarship::withdraw()` — single domain call + auth
- `AdmissionCycle::close()` / `AdmissionCycle::archive()` — single domain call + auth
- `InformationSource::deprecate()` — single domain call + auth

### Action Location

```
app/Actions/
    Institutions/
        CreateInstitution.php
        RenameInstitution.php
        SuspendInstitution.php
        ReactivateInstitution.php
        CloseInstitution.php
        MergeInstitutions.php
    Programmes/
        CreateProgramme.php
        PublishAdmissionPolicy.php
        RecordAccreditation.php
        DiscontinueProgramme.php
    Scholarships/
        AnnounceScholarship.php
        OpenScholarshipApplications.php
        ExpireScholarship.php
        TargetScholarshipProgrammes.php
    AdmissionCycles/
        AnnounceAdmissionCycle.php
        ActivateAdmissionCycle.php
        AdvanceAdmissionCyclePhase.php
    InformationSources/
        RegisterInformationSource.php
        VerifyInformationSource.php
        MarkSourceUnreliable.php
    Imports/
        ImportInstitutionData.php
    Scheduled/
        ExpireScholarships.php
```

---

## 7. Domain Services

### InstitutionMerger — The Only Domain Service

**Location:** `App\Domain\Services\InstitutionMerger`

**Why a domain service?** The merge operation must coordinate across two Institution aggregates and all their Programme aggregates within a single transactional boundary. Neither Institution alone can orchestrate this — it requires loading multiple aggregates and ensuring INV-P1 (programme ownership) holds across the reassignment.

**Interface:**

```php
class InstitutionMerger
{
    /**
     * Merge target institution into initiating institution.
     *
     * @throws InstitutionMergeException if merge cannot proceed
     */
    public function merge(Institution $initiating, Institution $target): void
    {
        // 1. Validate both institutions are Operational
        // 2. Load all programmes belonging to target
        // 3. Reassign each programme to initiating institution
        // 4. Transfer accreditation records
        // 5. Close target institution
        // 6. Dispatch InstitutionsMerged event
        // All within DB transaction
    }
}
```

**Transaction boundary:** DB transaction wrapping the entire operation. If any step fails, all changes roll back. This is the only operation requiring strong cross-aggregate consistency.

### Why No Other Domain Services?

The Behaviour Discovery confirmed that all other cross-aggregate interactions are handled through:
- Reference IDs (weak consistency)
- Application-layer validation (guard clauses)
- Eventual consistency via domain events (read model updates)

This is exactly the Laravel Beyond CRUD ideal: minimal domain services indicate well-drawn aggregate boundaries.

---

## 8. Domain Events

### Implementation Strategy

Domain events use Laravel's native event system. Each event is a plain PHP class implementing the domain event contract. Events are dispatched from aggregate root methods and consumed by application-layer listeners.

**Location:**
```
app/Domain/Events/          — Domain event classes
app/Listeners/              — Application-layer listeners
```

### Event Architecture

Domain events carry the minimum data needed for downstream reactions. They do NOT carry the full aggregate state — consumers reload what they need.

**Base contract:**

```php
interface DomainEvent
{
    public function eventType(): string;
    public function aggregateId(): string;
    public function aggregateType(): string;
    public function occurredAt(): DateTimeImmutable;
}
```

### Event Flow

```
Aggregate Root
    ↓ (dispatches)
Domain Event
    ↓ (Laravel event system)
Application Listeners:
    ├── UpdateReadModel
    ├── UpdateSearchIndex
    ├── DispatchNotifications
    ├── RecalculateTrustSignal
    └── LogActivity (Spatie)
```

### Full Event Register (27 events)

| Event | Emitted By | Payload | Listeners |
|-------|-----------|---------|-----------|
| `InstitutionEstablished` | Institution | institutionId, name, type | SearchIndex, ActivityLog |
| `InstitutionRenamed` | Institution | institutionId, oldName, newName | SearchIndex, ActivityLog |
| `InstitutionSuspended` | Institution | institutionId | SearchIndex, ProgrammeStatusCascade |
| `InstitutionReactivated` | Institution | institutionId | SearchIndex, ProgrammeStatusRestore |
| `InstitutionClosed` | Institution | institutionId | SearchIndex, ProgrammeDiscontinueCascade, ScholarshipFlag |
| `InstitutionsMerged` | Institution | initiatingId, targetId | SearchRebuild, ProgrammeReassignment |
| `InstitutionAccredited` | Institution | institutionId, authorityId, status | TrustSignal, SearchIndex |
| `InstitutionalAdmissionPolicyPublished` | Institution | institutionId, cycleId, policyId | SearchIndex, OpportunityFeed |
| `ProgrammeIntroduced` | Programme | programmeId, institutionId | SearchIndex, ActivityLog |
| `ProgrammeAdmissionPolicyPublished` | Programme | programmeId, cycleId, policyId | SearchIndex, OpportunityFeed |
| `ProgrammeAdmissionSuspended` | Programme | programmeId | SearchIndex |
| `ProgrammeAdmissionResumed` | Programme | programmeId | SearchIndex |
| `ProgrammeDiscontinued` | Programme | programmeId | SearchIndex, ScholarshipFlag |
| `ProgrammeAccredited` | Programme | programmeId, authorityId, status | TrustSignal, SearchIndex |
| `ScholarshipAnnounced` | Scholarship | scholarshipId, providerId | SearchIndex, CandidateNotification |
| `ScholarshipEligibilityPolicyPublished` | Scholarship | scholarshipId, policyId | EligibleCandidateRecalc |
| `ScholarshipApplicationsOpened` | Scholarship | scholarshipId | SearchIndex, CandidateNotification |
| `ScholarshipApplicationsClosed` | Scholarship | scholarshipId | SearchIndex |
| `ScholarshipWithdrawn` | Scholarship | scholarshipId | SearchIndex, ApplicantNotification |
| `ScholarshipExpired` | Scholarship | scholarshipId | SearchIndex |
| `ScholarshipTargetsUpdated` | Scholarship | scholarshipId, programmeIds, institutionIds | SearchIndex |
| `AdmissionCycleAnnounced` | AdmissionCycle | cycleId, authorityId | SearchIndex |
| `AdmissionCycleActivated` | AdmissionCycle | cycleId | ReadModelUpdate |
| `AdmissionCyclePhaseAdvanced` | AdmissionCycle | cycleId, phaseName | ReadModelUpdate, NotificationDispatch |
| `AdmissionCycleClosed` | AdmissionCycle | cycleId | ReadModelUpdate |
| `InformationSourceVerified` | InformationSource | sourceId | TrustSignalRecalc |
| `InformationSourceMarkedUnreliable` | InformationSource | sourceId | TrustSignalRecalc |
| `InformationSourceDeprecated` | InformationSource | sourceId | TrustSignalCascade, DataProvenanceFlag |
| `QualificationDeprecated` | Qualification | qualificationId | PolicyCreationGuard |

(QualificationDeprecated is technically from a supporting entity but has genuine downstream impact: preventing deprecated qualifications from being used in new policies.)

---

## 9. Application Events vs Activity Log

### Three Distinct Mechanisms

StudyNexus uses three distinct event/logging mechanisms. Collapsing them into one is forbidden.

| Mechanism | Purpose | Contains | Implemented By |
|-----------|---------|----------|---------------|
| **Domain Events** | Business facts that other parts of the system react to | Aggregate ID, event type, business payload, timestamp | Laravel Events (`app/Domain/Events/`) |
| **Application Events** | Application workflow integration (not business facts) | Workflow context, integration payload | Laravel Events (`app/Events/`) |
| **Activity Log** | Operational audit trail: who did what, when, from where | Causer, subject, description, properties, IP | Spatie `laravel-activitylog` |

### Domain Events vs Application Events

| Criterion | Domain Event | Application Event |
|-----------|-------------|-------------------|
| Source | Aggregate root (domain operation) | Application layer (workflow, integration) |
| Meaning | "A business fact occurred" | "An application workflow step occurred" |
| Consumer | Any domain-aware listener | Specific integration point |
| Example | `InstitutionClosed` | `DataImportCompleted`, `BatchProcessingFailed`, `SearchIndexRebuildCompleted` |
| Persistence | No (unless needed for audit) | No |
| Test | Domain unit test | Integration test |

### Activity Log (Spatie)

Spatie `laravel-activitylog` records operational history:
- Who performed the action (causer: user, system, import job)
- What was affected (subject: institution, programme, etc.)
- Description of the action
- Properties (before/after values for important changes)
- Timestamp and IP

**What gets logged:**
- All admin actions (Filament operations)
- All status transitions (publish, suspend, close, merge, etc.)
- All verification actions
- All import operations
- All moderation actions

**What does NOT get logged:**
- Read queries
- Search index updates (infrastructure concern)
- Notification dispatch (infrastructure concern)
- Trust signal recalculation (infrastructure concern)

---

## 10. Read Models and Queries

### Design Philosophy

The Behaviour Discovery established that `isAdmitting`, `isApplicableTo`, `isReliable`, and `isAdmissionOpen` are read-model queries, not domain operations. This means:

1. No single aggregate owns all the data needed to answer these questions.
2. The queries derive their answers from multiple aggregates' current state.
3. They are eventually consistent — the answer may be stale for a brief period after a state change.
4. They are optimized for read performance, not write consistency.

### Query Architecture

```
app/Queries/
    Institutions/
        GetInstitutionDetails.php
        SearchInstitutions.php
        GetInstitutionAccreditationStatus.php
    Programmes/
        GetProgrammeDetails.php
        IsProgrammeAdmitting.php          ← read-model query
        GetProgrammeAccreditationStatus.php
        SearchProgrammes.php
    Scholarships/
        GetScholarshipDetails.php
        IsScholarshipApplicableTo.php     ← read-model query
        SearchScholarships.php
    AdmissionCycles/
        IsAdmissionOpen.php               ← read-model query
        GetCurrentCyclePhase.php
    InformationSources/
        IsSourceReliable.php              ← read-model query
        GetTrustSignal.php                ← computed projection
    Opportunities/
        GetOpportunityFeed.php            ← Educational Opportunity read model
        CompareOpportunities.php
```

### Key Read-Model Queries Implementation

#### `IsProgrammeAdmitting`

This is the most architecturally significant query in the system. It combines:
- Programme status (Admitting vs Suspended vs Discontinued)
- Admission Cycle current phase (is the cycle in its admission period?)
- Admission Policy existence (does the programme have a published policy for this cycle?)

```php
class IsProgrammeAdmitting
{
    public function check(Programme $programme, ?AdmissionCycle $cycle = null): bool
    {
        // If programme is not in Admitting status, it's not admitting
        if ($programme->status !== ProgrammeStatus::Admitting) {
            return false;
        }

        // Rolling/Multiple-Intake: no cycle needed; admitting if status is Admitting
        if ($programme->admission_mode !== AdmissionMode::Cyclic) {
            return true;
        }

        // Cyclic: check cycle phase and policy existence
        if ($cycle === null) {
            $cycle = $this->getCurrentCycleForProgramme($programme);
        }

        if ($cycle === null || !$cycle->isInAdmissionPhase()) {
            return false;
        }

        return $programme->hasActivePolicyForCycle($cycle->id);
    }
}
```

#### `GetTrustSignal`

Trust signal is a computed projection based on:
- Information source reliability
- Verification history
- Information category weight
- Provenance depth

This is NEVER stored — it is computed on demand or cached with a TTL.

### Eloquent Query Scopes

For simpler queries that don't cross aggregate boundaries, Eloquent scopes are appropriate:

```php
// On Institution model
public function scopeOperational(Builder $query): Builder
{
    return $query->where('status', InstitutionStatus::Operational);
}

public function scopeInCountry(Builder $query, string $countryCode): Builder
{
    return $query->where('country_code', $countryCode);
}

// On Programme model
public function scopeAdmitting(Builder $query): Builder
{
    return $query->where('status', ProgrammeStatus::Admitting);
}
```

### Educational Opportunity Read Model

"Educational Opportunity" is NOT a domain entity (CD-2). It is a read model / projection that composes:
- Programme details
- Institution details
- Current admission status (isAdmitting)
- Current accreditation status
- Available scholarships
- Trust signal

This read model powers:
- Opportunity feed pages
- Comparison interfaces
- Search results
- Recommendation features

It can be implemented as:
- A dedicated database view or materialized view
- A cached query with TTL
- A search index document (Typesense/Elasticsearch)

For MVP: cached Eloquent query with eager loading. For scale: search index document.

---

## 11. Search Architecture

### Principle: Search Is Infrastructure, Not Domain

Search is a projection of domain data optimized for discovery. The domain model is the source of truth. Search indexes are eventually consistent copies. The domain must never be coupled to a specific search engine.

### Architecture

```
Domain Aggregate
    ↓ (domain event)
Domain Event Listener
    ↓ (extracts searchable data)
Search Index Updater
    ↓ (formats document)
Search Engine (Typesense / pgvector / Elasticsearch)
    ↑ (query)
Search Query Service
    ↑ (results)
Public UI / API
```

### MVP Strategy: Database Queries + Meilisearch/Typesense

For MVP, use Laravel Scout with a driver that supports:
- Full-text search on programme names, institution names, scholarship names
- Filtering by country, institution type, award level, admission status, delivery mode
- Faceted navigation for discovery pages
- Geospatial search (if Location is present)

**Recommended:** Typesense (via `laravel-scout-typesense` driver) for:
- Typo-tolerant search (essential for educational institution names)
- Faceted filtering
- Geo search
- Low operational overhead (single binary)

**Fallback:** PostgreSQL full-text search with `tsvector` columns + `spatie/laravel-query-builder` for filtering. Sufficient for early MVP with < 100K records.

### What Search Must NOT Do

- Search must not become the domain model. It is a read projection.
- Search must not enforce business rules. Invariants are in the domain.
- Search must not be the source of truth. Domain events → search index updates.
- Search results must link to domain-sourced detail pages, not search-stored data.

### SEO Integration

Search architecture must support:
- Indexable programme/institution/scholarship detail pages
- Faceted navigation with crawlable URLs
- Sitemap generation (`spatie/laravel-sitemap`)
- Schema.org structured data (`spatie/schema-org`)
- Canonical URLs for every entity

---

## 12. Repository Policy

### Decision: No Repositories for MVP

Laravel Beyond CRUD explicitly warns against creating repositories "just because DDD says so." In a Laravel application, Eloquent IS the repository. Creating a `InstitutionRepositoryInterface` + `InstitutionRepository` pair that delegates 100% to Eloquent adds indirection without value.

### When a Repository Would Be Justified

| Criterion | Current Assessment | Future Trigger |
|-----------|-------------------|----------------|
| Multiple persistence backends | No — single PostgreSQL | If CQRS requires separate read/write stores |
| Testing without database | Yes, but Laravel's in-memory SQLite + factories suffice | If tests become too slow (unlikely at StudyNexus scale) |
| Complex query composition beyond Eloquent | No — Query classes handle this | If query complexity exceeds Eloquent's expressiveness |
| Domain model ≠ persistence model | No — Eloquent models ARE the aggregate persistence representation | If aggregate reconstruction requires complex mapping |

**Verdict:** No repositories for MVP. Eloquent models serve as the aggregate persistence representation. Query classes handle read-model concerns. If a genuine need for repositories emerges (e.g., separate read store for CQRS), introduce them at that point with a refactor seam, not preemptively.

### What We Use Instead

| Need | Laravel Mechanism |
|------|-------------------|
| Find aggregate by ID | `Institution::findOrFail($id)` |
| Complex read queries | Dedicated `app/Queries/` classes |
| Cross-aggregate reads | Query classes that join across models |
| Batch operations | Actions with `chunk()` processing |
| Domain operation persistence | `$model->save()` within domain method |

---

## 13. Persistence Strategy

### Eloquent as Persistence Mechanism

Eloquent models serve as the persistence representation of aggregate roots. Domain operations are methods on the model that validate preconditions, mutate state, and dispatch events. The model is saved as a side effect of the domain operation (within the method or in the calling Action).

### Database Design Principles

1. **Tables follow aggregate roots.** One table per aggregate root + one table per child entity.
2. **Foreign keys enforce referential integrity** for aggregate membership (child → parent) and supporting entity references.
3. **JSON columns** for complex VOs that don't need individual query access (Admission Rules, Eligibility Rules, Phase Sequence).
4. **Separate columns** for VOs that need query access (Monetary Amount → amount + currency columns; Location → country + region + city columns; Validity Period → start_date + end_date columns).
5. **Polymorphic relationships** for Admission Policy (Programme or Institution) and Accreditation Record (Programme or Institution).
6. **No EAV patterns.** No generic "attributes" or "properties" tables.
7. **Soft deletes ONLY for admin safety** on aggregate roots. Child entities follow parent lifecycle. Supporting entities use deprecation (status flag), not soft delete.
8. **Timestamps:** All tables have `created_at` and `updated_at`. Domain events carry their own `occurred_at` which may differ from `created_at` (e.g., event sourced from import data).

### Migration Strategy

```
database/migrations/
    0001_create_reference_tables.php          — countries, education_authorities, qualifications, scholarship_providers
    0002_create_institutions_table.php        — aggregate root
    0003_create_programmes_table.php          — aggregate root
    0004_create_scholarships_table.php        — aggregate root
    0005_create_admission_cycles_table.php    — aggregate root
    0006_create_information_sources_table.php — aggregate root
    0007_create_admission_policies_table.php  — child entity (polymorphic)
    0008_create_eligibility_policies_table.php — child entity
    0009_create_accreditation_records_table.php — child entity (polymorphic)
```

Reference tables first (supporting entities), then aggregate roots, then child entities. This respects FK dependency order.

### Value Object Persistence Summary

| VO | Storage | Rationale |
|----|---------|-----------|
| Admission Rule | JSON column in admission_policies | Collection of rules; no need to query individual rules |
| Eligibility Rule | JSON column in eligibility_policies | Same pattern |
| Subject Combination | Embedded in Admission Rule JSON | Part of rule structure |
| Qualification Threshold | Embedded in Rule JSON | Part of rule structure |
| Validity Period | Two date columns | Date range queries needed |
| Monetary Amount | amount (decimal) + currency (string) columns | Numeric queries on amount; filtering by currency |
| Duration | value (int) + unit (string) columns | Numeric queries |
| Location | country, region, city columns | Geographic queries; nullable |
| Phase Sequence | JSON column | Ordered list; no per-phase queries needed |
| Authority Jurisdiction | JSON column | Structured data; jurisdiction queries are reference data |
| Admission Pathway | JSON or two columns (name, authority_id) | Discriminator within policy; simple structure |
| All enums | String columns | PHP backed enum casting; human-readable in DB |

---

## 14. Provenance Implementation

### Provenance as Cross-Cutting Concern

The domain has provenance on child entities (Admission Policy, Eligibility Policy, Accreditation Record all carry a `source_reference`). The question is: how to implement provenance without polluting every domain class?

### Layered Approach

| Layer | Mechanism | What It Tracks |
|-------|-----------|---------------|
| **Domain** | `source_reference` attribute on child entities | Which Information Source provided this data |
| **Application** | Spatie Activity Log | Who performed the action, when, from where |
| **Infrastructure** | Eloquent timestamps | `created_at`, `updated_at` for every record |
| **Read Model** | Trust Signal computation | Derived trust from source reliability + verification history |

### Implementation

1. **Child entities carry `source_id` (FK to information_sources).** This is a domain attribute, not infrastructure. It answers: "Where did this information come from?"

2. **Spatie Activity Log records who changed what.** This is an application/operational concern. It answers: "Who entered/modified this data, and when?"

3. **Trust Signal is computed from source reliability.** This is a read-model projection. It answers: "How trustworthy is this information?"

4. **No Eloquent trait for provenance.** Provenance is not uniformly needed on all entities — only on child entities that carry sourced data. A trait would add provenance columns to tables that don't need them (e.g., Admission Cycle phases are administrative, not sourced). Use explicit `source_id` columns where the domain requires provenance.

### What NOT to Do

- Do not create a generic `ProvenanceTrait` that adds `source_id`, `verified_at`, `verified_by` to every model.
- Do not create a `ProvenanceLog` aggregate root for MVP (CD-4).
- Do not store audit history in domain events — use Spatie Activity Log.
- Do not compute Trust Signal synchronously on every write — use event-driven recalculation.

---

## 15. Filament Boundary

### What Filament Is Responsible For

Filament provides the internal/admin panel for StudyNexus. It is responsible for:

1. **CRUD-like administrative interfaces** for supporting entities (Qualification, Scholarship Provider, Education Authority) that have no complex domain operations beyond `deprecate`.
2. **Aggregate management forms** that invoke Actions (not direct model manipulation).
3. **Verification workflows** (Information Source verification, data moderation).
4. **Data management dashboards** (overview statistics, recent changes, pending verifications).
5. **Import management** (triggering data import jobs, reviewing import results).
6. **User/role management** (leveraging Spatie Permission).

### What Filament Must NOT Do

1. **Filament must not implement business rules.** A Filament Resource's `save()` method must invoke an Action, not directly manipulate model attributes.
2. **Filament must not bypass aggregate operations.** Closing an institution via Filament must call `CloseInstitution` Action, not set `status = 'closed'`.
3. **Filament must not become the domain layer.** Domain operations, invariants, and events live in `app/Domain/` and `app/Actions/`, not in Filament Resources.
4. **Filament must not define value objects.** VOs are domain concepts; Filament forms use form schemas that map to/from VOs.
5. **Filament Resources must not contain cross-aggregate orchestration.** That belongs in Actions or domain services.

### Example: Institution Resource in Filament

```php
class InstitutionResource extends Resource
{
    // Form schema maps to domain attributes, NOT to raw DB columns
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('official_name')->required(),
                Select::make('institution_type')  // backed by InstitutionType VO
                    ->options(InstitutionType::class)
                    ->required(),
                // ... other fields
            ]);
    }

    // Actions invoke domain Actions, not direct save
    public static function table(Table $table): Table
    {
        return $table
            ->actions([
                Action::make('suspend')
                    ->action(fn (Institution $record) => app(SuspendInstitution::class)->execute($record)),
                Action::make('close')
                    ->action(fn (Institution $record) => app(CloseInstitution::class)->execute($record)),
            ]);
    }
}
```

### Filament Location

```
app/Filament/
    Resources/
        InstitutionResource.php
        ProgrammeResource.php
        ScholarshipResource.php
        AdmissionCycleResource.php
        InformationSourceResource.php
        QualificationResource.php        // supporting entity — simple CRUD
        ScholarshipProviderResource.php  // supporting entity — simple CRUD
        EducationAuthorityResource.php   // supporting entity — simple CRUD
    Pages/
        Dashboard.php
    Clusters/                            // if grouping is needed
```

---

## 16. Livewire + Flux Boundary

### What Livewire/Flux Is Responsible For

Livewire components handle the user-facing interactive experiences:

1. **Public discovery pages** — search, filter, browse institutions/programmes/scholarships.
2. **Detail pages** — institution, programme, scholarship detail views.
3. **Comparison interfaces** — comparing opportunities side-by-side.
4. **Eligibility assessment** — "Am I eligible for this scholarship/programme?"
5. **Authenticated dashboards** — saved opportunities, application tracking, preferences.
6. **Interactive components** — filters, sort controls, pagination, favourite/bookmark toggles.

### What Livewire/Flux Must NOT Do

1. **Livewire components must not enforce aggregate invariants.** Invariants belong in the domain model (Eloquent model methods).
2. **Livewire components must not perform domain transitions.** State changes must go through Actions, not direct model manipulation.
3. **Livewire components must not contain domain calculations.** Calculations like `isAdmitting` belong in Query classes.
4. **Livewire components must not dispatch domain events.** Events are dispatched by domain operations, not by UI interactions.
5. **Livewire components must not directly access the database** for write operations. They may read via Query classes and write via Actions.

### Dependency Direction

```
Blade/Flux Component
    ↓ (renders)
Livewire Component
    ↓ (calls)
Action (application layer)
    ↓ (invokes)
Domain Model (aggregate root method)
    ↓ (persists)
Eloquent / Database

Livewire Component
    ↓ (calls)
Query (application layer)
    ↓ (reads)
Eloquent / Search Index
```

### Example: Programme Search Component

```php
class ProgrammeSearch extends Component
{
    public string $query = '';
    public ?string $country = null;
    public ?string $awardLevel = null;

    // Rendering uses a Query, not raw Eloquent
    public function getProgrammesProperty()
    {
        return app(SearchProgrammes::class)->search(
            query: $this->query,
            country: $this->country,
            awardLevel: $this->awardLevel,
        );
    }

    public function render()
    {
        return view('livewire.programme-search', [
            'programmes' => $this->programmes,
        ]);
    }
}
```

### Livewire Location

```
app/Livewire/
    Public/
        InstitutionSearch.php
        ProgrammeSearch.php
        ScholarshipSearch.php
        InstitutionDetail.php
        ProgrammeDetail.php
        ScholarshipDetail.php
        OpportunityComparison.php
        EligibilityChecker.php
    Authenticated/
        Dashboard.php
        SavedOpportunities.php
        Preferences.php
        EligibilityAssessments.php
```

---

## 17. Blade Boundary

### What Blade Is Responsible For

Blade templates are the presentation layer. They:

1. **Render HTML** with Tailwind CSS styling.
2. **Compose layouts** (public layout, authenticated layout, admin layout).
3. **Display domain data** passed from Livewire components or controllers.
4. **Include Flux components** for UI primitives (buttons, inputs, dropdowns, modals).
5. **Render SEO metadata** (title, description, canonical URL, Schema.org structured data).

### What Blade Must NOT Do

1. **Blade must not contain business logic.** No `@if($institution->status === 'operational')` — use computed properties or accessor methods.
2. **Blade must not perform database queries.** All data is passed in.
3. **Blade must not make authorization decisions.** Use policies/middleware.
4. **Blade must not format domain data.** VOs know how to present themselves (via `__toString()` or dedicated presentation methods).

### Blade Location

```
resources/views/
    layouts/
        public.blade.php
        authenticated.blade.php
    pages/
        home.blade.php
        institutions/
            index.blade.php
            show.blade.php
        programmes/
            index.blade.php
            show.blade.php
        scholarships/
            index.blade.php
            show.blade.php
    livewire/
        public/
            institution-search.blade.php
            programme-search.blade.php
            ...
        authenticated/
            dashboard.blade.php
            ...
    components/
        opportunity-card.blade.php
        accreditation-badge.blade.php
        trust-signal.blade.php
        admission-status.blade.php
   partials/
        seo-meta.blade.php
        schema-org.blade.php
```

---

## 18. Spatie Package Evaluation Matrix

| Package | StudyNexus Need | Use? | Architectural Layer | Reason |
|---------|----------------|------|---------------------|--------|
| `laravel-permission` | Role-based access control for admin, staff, users | **Adopt now** | Application (Authorization) | Standard RBAC need; no domain requirement that the package cannot express. Custom ACL would reinvent this. |
| `laravel-medialibrary` | Institution logos, programme media, scholarship documents, accreditation documents, source documents | **Adopt now** | Application (Media) | Proven media management with conversions, collections, and associating media to any model. Avoids custom file management. |
| `laravel-activitylog` | Administrative audit trail, verification history, moderation actions | **Adopt now** | Application (Audit) | Activity logging is cross-cutting; Spatie provides clean integration. Domain events are NOT audit logs — they serve different purposes. |
| `laravel-sluggable` | Public-facing URLs for institutions, programmes, scholarships | **Adopt now** | Application (Routing) | SEO-friendly URLs; slug is NOT domain identity (CD: slugs are presentation concern). |
| `laravel-query-builder` | API/query filtering for public search, Filament filtering | **Adopt now** | Application (Query) | Standardized filtering/includes/sorts for API endpoints and complex queries. Reduces boilerplate. |
| `laravel-data` | Application-layer DTOs, request data, API resources, import data transformation | **Adopt now** | Application (Data Transfer) | Excellent for request→domain and domain→response transformation. NOT for domain VOs — VOs remain plain PHP objects. |
| `laravel-model-states` | State machines for Institution, Programme, Scholarship, Admission Cycle, Information Source | **Reject** | — | State machines are simple enough with PHP enums + named transition methods. `laravel-model-states` adds a layer of indirection (State, Transition, StateConfig classes) that is not justified when each aggregate has at most 5 states and 3-4 transitions. The domain model's named methods (`suspend()`, `close()`, `activate()`) already express state transitions clearly. Adding the package would obscure the domain intent behind framework classes. |
| `laravel-settings` | Application-configurable settings (e.g., default trust thresholds, feature flags) | **Adopt later** | Application (Configuration) | No settings need for MVP. When feature flags or configurable thresholds are needed, this is the right package. |
| `laravel-sitemap` | Large SEO surface for institutions, programmes, scholarships | **Adopt now** | Infrastructure (SEO) | Essential for SEO; large public surface requires sitemaps. Integrates cleanly with routes. |
| `schema-org` | Structured data for institution/programme/scholarship pages | **Adopt now** | Presentation (SEO) | Schema.org markup is critical for search engine understanding of educational content. Must remain separate from domain model. |
| `laravel-backup` | Database/file backups | **Adopt now** | Infrastructure (Operations) | Standard operational requirement; not domain architecture. |
| `laravel-schedule-monitor` | Monitoring scheduled tasks (scholarship expiration, cycle activation) | **Adopt later** | Infrastructure (Operations) | When scheduled tasks are in place, this provides monitoring. Not needed until scheduler is active. |
| `laravel-newsletter` | Newsletter integration | **Evaluate when feature arrives** | Application (Integration) | No newsletter need for MVP. |
| `laravel-fractal` | API transformation layer | **Reject** | — | Spatie Laravel Data serves the same purpose more idiomatically in modern Laravel. Fractal is a legacy package; Data is the replacement. |
| `laravel-tags` | Tagging institutions/programmes | **Evaluate when feature arrives** | Application (Content) | Tags are a future consideration for content organization. |
| `laravel-comments` | User comments on opportunities | **Evaluate when feature arrives** | Application (Content) | Community features are future scope. |
| `laravel-feed` | RSS/Atom feeds for opportunity updates | **Evaluate when feature arrives** | Application (Content) | Feeds are a nice-to-have for power users. |

---

## 19. Package Adoption Strategy

### Phase 1: MVP (Adopt Now)

| Package | Purpose | Integration Point |
|---------|---------|-------------------|
| `laravel-permission` | Admin roles, staff roles, user permissions | `app/Policies/`, Filament, middleware |
| `laravel-medialibrary` | Institution logos, accreditation docs, source docs | Eloquent models with `HasMedia` interface |
| `laravel-activitylog` | Audit trail for all admin actions | Actions dispatch activity logs; Filament logs automatically |
| `laravel-sluggable` | SEO-friendly public URLs | Institution, Programme, Scholarship models |
| `laravel-query-builder` | API/query filtering | Query classes, API controllers |
| `laravel-data` | Request DTOs, API resources, import data | Actions, controllers, API resources |
| `laravel-sitemap` | SEO sitemaps | Console command / scheduled task |
| `schema-org` | Structured data | Blade templates / view composers |
| `laravel-backup` | Operational backups | Scheduled task |

### Phase 2: Growth (Adopt Later)

| Package | Trigger |
|---------|---------|
| `laravel-settings` | When configurable thresholds or feature flags are needed |
| `laravel-schedule-monitor` | When scheduled tasks are in production and need monitoring |

### Phase 3: Community Features (Evaluate When Feature Arrives)

| Package | Trigger |
|---------|---------|
| `laravel-newsletter` | When newsletter/email campaigns are needed |
| `laravel-tags` | When content tagging/categorization beyond enum types is needed |
| `laravel-comments` | When community features (user reviews, Q&A) are needed |
| `laravel-feed` | When RSS/Atom feeds are requested |

### Rejections (with rationale)

| Package | Rejection Reason |
|---------|-----------------|
| `laravel-model-states` | PHP enums + named methods express state transitions clearly. The package adds indirection without clarity for StudyNexus's simple state machines. |
| `laravel-fractal` | Superseded by `laravel-data` for modern Laravel. |

---

## 20. Dependency Direction

### Proposed Rule

```
Presentation (Blade, Livewire, Flux, Filament)
    ↓ depends on
Application (Actions, Queries, DTOs, Event Listeners, Policies)
    ↓ depends on
Domain (Models, Value Objects, Enums, Domain Events, Domain Services)

Infrastructure (Search, Queue, Mail, Storage, Cache)
    ↓ implements
Application contracts where appropriate
```

### Key Constraints

1. **Presentation never depends on Infrastructure directly.** If a Livewire component needs to trigger a search, it calls a Query (Application), which may use Infrastructure internally.
2. **Domain never depends on Application or Presentation.** Domain models have no knowledge of HTTP, Livewire, Filament, or any application concern.
3. **Domain never depends on Infrastructure.** Domain models don't know about search engines, queues, or mail. Events are dispatched; listeners (Application layer) decide what infrastructure to invoke.
4. **Actions depend on Domain and may depend on Infrastructure** (e.g., for search index updates). This is acceptable — Actions are the orchestration layer.
5. **Filament Resources depend on Actions and Domain Models.** They never contain business logic directly.

### What This Prevents

| Forbidden | Why |
|-----------|-----|
| Livewire component calling `Institution::create()` directly | Bypasses Action's orchestration (auth, validation, events) |
| Filament Resource implementing merge logic | Business rule belongs in domain service, not admin UI |
| Domain Model dispatching a notification | Notification is application/infrastructure concern |
| Blade template querying the database | Data must be passed in from controller/component |
| Action depending on another Action (chaining) | Use domain events for cascading effects |

### Enforcement

- **Code review discipline** is the primary enforcement mechanism for a small team.
- **Static analysis** (PHPStan/Pint) can enforce some rules (e.g., `app/Domain/` classes must not import from `app/Actions/` or `app/Livewire/`).
- **Namespace conventions** make violations visible: if a `App\Domain\*` class imports `App\Livewire\*`, it's immediately wrong.

---

## 21. Testing Architecture

### Testing Layers

| Layer | Type | Scope | Tools |
|-------|------|-------|-------|
| Domain | Unit | VOs, enums, model methods, invariants, state transitions | PHPUnit (no DB) |
| Application | Feature | Actions, queries, event listeners | PHPUnit + DB (SQLite in-memory) |
| Presentation | Browser | Livewire interactions, Filament workflows | PHPUnit + Livewire testing |
| Integration | End-to-end | Full request cycle, search, import | PHPUnit + DB (MySQL/PostgreSQL) |

### Domain Tests (Highest Priority)

Every invariant and state transition must have a domain unit test:

```php
class InstitutionTest extends TestCase
{
    public function test_cannot_close_already_closed_institution(): void
    {
        $institution = Institution::factory()->closed()->make();

        $this->expectException(InvalidStateTransitionException::class);
        $institution->close();
    }

    public function test_cannot_publish_policy_when_closed(): void
    {
        $institution = Institution::factory()->closed()->make();

        $this->expectException(InvalidStateException::class);
        $institution->publishAdmissionPolicy(...);
    }
}
```

### Test Location

```
tests/
    Unit/
        Domain/
            Models/
                InstitutionTest.php
                ProgrammeTest.php
                ScholarshipTest.php
                AdmissionCycleTest.php
                InformationSourceTest.php
            ValueObjects/
                MonetaryAmountTest.php
                ValidityPeriodTest.php
                PhaseSequenceTest.php
                AdmissionRuleTest.php
    Feature/
        Actions/
            CreateInstitutionTest.php
            MergeInstitutionsTest.php
            PublishAdmissionPolicyTest.php
        Queries/
            IsProgrammeAdmittingTest.php
            GetTrustSignalTest.php
    Browser/
        Livewire/
            ProgrammeSearchTest.php
            EligibilityCheckerTest.php
```

---

## 22. Global Expansion Analysis

### Testing Against 9 Countries

| Country | Admission Structure | Key Concepts | Architecture Impact |
|---------|-------------------|-------------|---------------------|
| **Nigeria** | Cyclic (JAMB), UTME/Direct Entry/Post-UTME | NUC, WAEC, JAMB | Zero structural changes; initial dataset |
| **Ghana** | Cyclic, similar WAEC ecosystem | GTEC, WAEC | Zero changes; reference data additions |
| **Kenya** | Cyclic, KCSE-based | CUE, KNEC | Zero changes; reference data additions |
| **South Africa** | Cyclic + some rolling | CHE, SAQA | Zero changes; Admission Mode VO supports mixed |
| **UK** | UCAS cycle (Cyclic), Clearing (Rolling), Adjustment | OfS, QAA | Zero changes; UCAS = Admission Cycle; Clearing = Rolling phase |
| **USA** | Rolling + Early Decision/Action + Regular | CHEA, regional accreditors | Zero changes; Admission Mode = Rolling/Multiple-Intake; Early Decision = Admission Pathway VO |
| **Canada** | Rolling with deadlines | Provincial regulators | Zero changes; similar to US pattern |
| **Germany** | Cyclic (winter/summer semester) | KMK, AQ Germany | Zero changes; two intakes per year = Multiple-Intake via Admission Mode |
| **Australia** | Semester-based (February, July) | TEQSA | Zero changes; Multiple-Intake via Admission Mode |

### Expansion Assessment

**Zero structural changes required for all 9 countries.** All variation is captured by:
- Reference data (Education Authorities, Qualifications, Admission Pathways)
- Admission Mode VO (Cyclic / Rolling / Multiple-Intake)
- Configurable Phase Sequences
- Authority Jurisdiction data

### Future Bounded Context Emergence

| Future Feature | Likely New BC | Existing Concepts Supporting It |
|---------------|--------------|-------------------------------|
| Student Applications | Application Management | Programme, Scholarship, Admission Cycle, Admission Policy |
| Credential Evaluation | Credential Assessment | Qualification, Education Authority |
| Visa Information | Immigration & Mobility | Country (reference data), Education Authority |
| Student Accommodation | Student Services | Institution, Location |
| Education Financing | Financial Services | Monetary Amount, Scholarship |
| Language Requirements | Language Assessment | Qualification (language test as qualification type) |
| Standardized Tests | Assessment | Qualification (test as qualification type), Education Authority |

---

## 23. Study Abroad Expansion Analysis

### Principle: No Giant "Study Abroad" Aggregate

Study Abroad is not a single concept — it is a set of concerns that emerge when education crosses national boundaries. The architecture must not create a monolithic "Study Abroad" bounded context. Instead, new concepts emerge naturally from existing ones.

### What Existing Domain Already Supports

| Study Abroad Concern | Existing Domain Concept | How It Works |
|---------------------|----------------------|--------------|
| Institutions abroad | Educational Institution (country = non-Nigeria) | Zero changes; Location VO + Country reference data |
| Programmes abroad | Programme (institution = foreign) | Zero changes |
| Admission requirements | Admission Policy + Admission Rules | Zero changes; rules can express any requirement |
| Qualification requirements | Qualification Threshold in rules | Zero changes |
| Intake cycles | Admission Cycle + Admission Mode | Zero changes |
| Tuition | Monetary Amount on Programme | Zero changes; currency is part of the VO |
| Scholarships for study abroad | Scholarship (targeting foreign programmes) | Zero changes |
| Accreditation | Accreditation Record + Education Authority | Zero changes; foreign authorities are just more reference data |

### What Would Require New Domain Concepts

| Study Abroad Concern | New Domain Concept | Likely BC | When |
|---------------------|-------------------|-----------|------|
| Visa requirements | VisaRequirement (entity), ImmigrationAuthority (supporting) | Immigration & Mobility | Stage 3+ |
| Language proficiency requirements | Can be expressed as Qualification Threshold (IELTS ≥ 6.5) — **no new concept needed** | — | — |
| Credential evaluation | CredentialEquivalence (entity), EvaluatingBody (supporting) | Credential Assessment | Stage 3+ |
| Application process tracking | Application (aggregate root), ApplicationStep (child) | Application Management | Stage 2+ |
| Proof of funds | FinancialRequirement (VO within Eligibility Rule) — **possibly expressible in existing model** | — | Evaluate at Stage 2 |
| Student accommodation | AccommodationListing (aggregate root) | Student Services | Stage 3+ |
| Travel preparation | TravelGuidance (reference data) | Student Services | Stage 4+ |
| International student services | ServiceOffering (aggregate root) | Student Services | Stage 3+ |

### Deferred Bounded Contexts

The following bounded contexts are anticipated but NOT built until justified by user demand:

1. **Application Management** — Students applying to programmes through StudyNexus
2. **Credential Assessment** — Comparing qualifications across national systems
3. **Immigration & Mobility** — Visa requirements, immigration rules
4. **Student Services** — Accommodation, travel, international student support
5. **Financial Services** — Education loans, currency conversion, payment

Each of these will be evaluated against the same LBC principles when the time comes. None should be anticipated architecturally beyond ensuring the existing model is extensible.

---

## 24. SEO Architecture

### SEO Importance

StudyNexus has a very large public information surface: potentially millions of pages for institutions, programmes, and scholarships across 9+ countries. SEO is not an afterthought — it is a core discovery mechanism.

### TALL Stack SEO Advantages

| Feature | TALL Stack Support |
|---------|-------------------|
| Server-rendered HTML | ✅ Blade renders full HTML; no client-side rendering gap |
| Crawlable content | ✅ Search engines see complete content on first request |
| Fast initial page load | ✅ No JS bundle download; HTML + CSS only |
| Canonical URLs | ✅ Route model binding with slugs |
| Structured data | ✅ `spatie/schema-org` generates JSON-LD in Blade |
| Sitemaps | ✅ `spatie/laravel-sitemap` generates XML sitemaps |
| Meta tags | ✅ Blade partials render `<title>`, `<meta>`, Open Graph, Twitter Cards |

### URL Structure

```
/institutions/{slug}                              — Institution detail
/institutions/{slug}/programmes                   — Institution's programmes
/programmes/{slug}                                — Programme detail
/scholarships/{slug}                              — Scholarship detail
/admission-cycles/{slug}                          — Admission cycle detail (less SEO-critical)
/search?q=...&country=...&type=...&level=...      — Search/filter pages
```

### Schema.org Integration

```php
// In Blade template for programme detail
$schema = Schema::course()
    ->name($programme->programme_name)
    ->provider(Schema::educationalOrganization()
        ->name($programme->institution->official_name)
    )
    ->offers(Schema::offer()
        ->price($programme->tuition_fee?->amount)
        ->priceCurrency($programme->tuition_fee?->currency)
    );
```

**Critical:** Schema.org objects are presentation-layer constructs. They map FROM domain models but are NOT domain objects. The domain model must never import `spatie/schema-org`.

### Sitemap Strategy

- **Institution sitemap:** One sitemap for all institutions (likely < 50K URLs)
- **Programme sitemap:** One or more sitemaps (potentially > 50K URLs; split by country)
- **Scholarship sitemap:** One sitemap (likely < 50K URLs)
- **Sitemap index:** Aggregates all sitemaps
- **Generation:** Scheduled command runs daily/weekly depending on update frequency

### Faceted Navigation

Faceted filter pages (e.g., `/programmes?country=ng&type=university&level=undergraduate`) must be:
- Indexable for high-value facet combinations
- Canonicalized to avoid duplicate content
- No-indexed for low-value or near-duplicate combinations

---

## 25. What NOT to Build

This section is as important as what to build. Each item is something StudyNexus must NOT implement, with rationale.

| Item | Why NOT |
|------|---------|
| **Microservices** | Single Laravel application is sufficient. Premature distribution adds operational complexity without benefit. Bounded contexts can be extracted later if needed. |
| **Separate frontend (React/Next.js/Vue)** | TALL stack provides server-rendered interactivity. SPA would sacrifice SEO and add team coordination overhead. |
| **Repository for every model** | Eloquent IS the repository. Adding `InstitutionRepositoryInterface` + `InstitutionRepository` that delegates 100% to Eloquent is pure indirection. |
| **CQRS framework** | Read models are handled by Query classes. Full CQRS (separate read/write models, event sourcing) is unjustified at StudyNexus scale. |
| **Event sourcing** | Domain events are integration mechanisms, not the source of truth. The database is the source of truth. Event sourcing adds complexity without business justification. |
| **Elaborate plugin architecture** | StudyNexus is not a platform for third-party plugins. Bounded contexts can be added as modules within the Laravel app. |
| **Unnecessary interfaces** | `InstitutionRepositoryInterface`, `SearchServiceInterface`, etc. are not needed unless there are multiple implementations. YAGNI. |
| **Giant "Educational Opportunity" abstraction** | CD-2: "Educational Opportunity" is a read model / facade, not a domain entity. Do not create `OpportunityInterface` or `AbstractOpportunity`. |
| **Generic "Policy" abstraction** | CD-3: Admission Policy ≠ Eligibility Policy. Do not create `PolicyInterface` or `AbstractPolicy`. Their structural similarity is coincidental, not conceptual. |
| **Custom ACL system** | Spatie Permission handles RBAC. Custom ACL reinvents proven functionality. |
| **Speculative Study Abroad domain** | Study Abroad concepts will emerge naturally. Do not create a `StudyAbroad` module before user demand. |
| **laravel-model-states** | PHP enums + named methods express state transitions clearly for StudyNexus's simple state machines. |
| **Shared base entity class** | Each aggregate has different operations. A `BaseEntity` with `status` + generic `transition()` would obscure domain intent. |
| **Generic "status" transition framework** | Each aggregate's state machine is specific. A generic framework would make transitions invisible to domain experts. |
| **API versioning framework** | API is secondary to TALL stack. Version when needed, not preemptively. |
| **GraphQL** | REST + Livewire covers all client needs. GraphQL adds complexity without benefit for a server-rendered app. |

---

## 26. Proposed Laravel Directory Structure

### Design Decision: Domain-Organized Within App

After evaluating two options:

**Option A: Flat structure** (`app/Models/`, `app/Actions/`, `app/Domain/`)
**Option B: Domain-organized** (`app/Domain/Institutions/`, `app/Domain/Programmes/`, etc.)

**Selected: Hybrid** — Domain concepts are organized by aggregate within `app/Domain/`, but Actions and Queries use a flat structure grouped by entity name. This balances domain visibility with Laravel convention.

### Complete Directory Structure

```
app/
    Domain/
        Models/                     — Eloquent models (aggregate roots + child entities + supporting)
            Institution.php
            Programme.php
            Scholarship.php
            AdmissionCycle.php
            InformationSource.php
            AdmissionPolicy.php
            EligibilityPolicy.php
            AccreditationRecord.php
            Qualification.php
            ScholarshipProvider.php
            EducationAuthority.php
        ValueObjects/               — Domain value objects (plain PHP, immutable)
            AdmissionRule.php
            EligibilityRule.php
            SubjectCombination.php
            QualificationThreshold.php
            ValidityPeriod.php
            MonetaryAmount.php
            Duration.php
            Location.php
            AuthorityJurisdiction.php
            PhaseSequence.php
            AdmissionPathway.php
            TrustSignal.php
        Enums/                      — PHP 8.1+ backed enums
            InstitutionType.php
            AwardLevel.php
            AdmissionMode.php
            AccreditationStatus.php
            PolicyStatus.php
            ProgrammeStatus.php
            ScholarshipStatus.php
            InstitutionStatus.php
            SourceReliability.php
            InformationCategory.php
            AuthorityType.php
            ProviderType.php
            OwnershipType.php
            DeliveryMode.php
            QualificationStatus.php
            CoverageType.php
            AdmissionCycleStatus.php
        Events/                     — Domain events
            InstitutionEstablished.php
            InstitutionRenamed.php
            InstitutionSuspended.php
            InstitutionReactivated.php
            InstitutionClosed.php
            InstitutionsMerged.php
            InstitutionAccredited.php
            InstitutionalAdmissionPolicyPublished.php
            ProgrammeIntroduced.php
            ProgrammeAdmissionPolicyPublished.php
            ProgrammeAdmissionSuspended.php
            ProgrammeAdmissionResumed.php
            ProgrammeDiscontinued.php
            ProgrammeAccredited.php
            ScholarshipAnnounced.php
            ScholarshipEligibilityPolicyPublished.php
            ScholarshipApplicationsOpened.php
            ScholarshipApplicationsClosed.php
            ScholarshipWithdrawn.php
            ScholarshipExpired.php
            ScholarshipTargetsUpdated.php
            AdmissionCycleAnnounced.php
            AdmissionCycleActivated.php
            AdmissionCyclePhaseAdvanced.php
            AdmissionCycleClosed.php
            InformationSourceVerified.php
            InformationSourceMarkedUnreliable.php
            InformationSourceDeprecated.php
            QualificationDeprecated.php
        Services/                   — Domain services (only 1)
            InstitutionMerger.php
        Exceptions/                 — Domain exceptions
            InvalidStateTransitionException.php
            InvariantViolationException.php
            InstitutionMergeException.php
        Casts/                      — Custom Eloquent casts for VOs
            MonetaryAmountCast.php
            ValidityPeriodCast.php
            LocationCast.php
            DurationCast.php
            AdmissionRuleCast.php
            EligibilityRuleCast.php
            PhaseSequenceCast.php
            AuthorityJurisdictionCast.php
            AdmissionPathwayCast.php

    Actions/                        — Application actions (one per use case)
        Institutions/
            CreateInstitution.php
            RenameInstitution.php
            SuspendInstitution.php
            ReactivateInstitution.php
            CloseInstitution.php
            MergeInstitutions.php
        Programmes/
            CreateProgramme.php
            PublishAdmissionPolicy.php
            RecordAccreditation.php
            DiscontinueProgramme.php
        Scholarships/
            AnnounceScholarship.php
            OpenScholarshipApplications.php
            ExpireScholarship.php
            TargetScholarshipProgrammes.php
        AdmissionCycles/
            AnnounceAdmissionCycle.php
            ActivateAdmissionCycle.php
            AdvanceAdmissionCyclePhase.php
        InformationSources/
            RegisterInformationSource.php
            VerifyInformationSource.php
            MarkSourceUnreliable.php
        Imports/
            ImportInstitutionData.php
        Scheduled/
            ExpireScholarships.php
            ActivateCycles.php

    Queries/                        — Read-model queries
        Institutions/
            GetInstitutionDetails.php
            SearchInstitutions.php
            GetInstitutionAccreditationStatus.php
        Programmes/
            GetProgrammeDetails.php
            IsProgrammeAdmitting.php
            SearchProgrammes.php
        Scholarships/
            GetScholarshipDetails.php
            IsScholarshipApplicableTo.php
            SearchScholarships.php
        AdmissionCycles/
            IsAdmissionOpen.php
            GetCurrentCyclePhase.php
        InformationSources/
            IsSourceReliable.php
            GetTrustSignal.php
        Opportunities/
            GetOpportunityFeed.php
            CompareOpportunities.php

    Data/                           — Spatie Laravel Data DTOs
        InstitutionData.php
        ProgrammeData.php
        ScholarshipData.php
        AdmissionCycleData.php
        AdmissionPolicyData.php
        EligibilityPolicyData.php
        ImportData/
            InstitutionImportRow.php

    Policies/                       — Laravel authorization policies
        InstitutionPolicy.php
        ProgrammePolicy.php
        ScholarshipPolicy.php
        AdmissionCyclePolicy.php
        InformationSourcePolicy.php

    Listeners/                      — Domain event listeners (application layer)
        UpdateSearchIndex.php
        UpdateReadModel.php
        DispatchNotifications.php
        RecalculateTrustSignal.php
        LogActivity.php

    Livewire/                       — Livewire components
        Public/
            InstitutionSearch.php
            ProgrammeSearch.php
            ScholarshipSearch.php
            InstitutionDetail.php
            ProgrammeDetail.php
            ScholarshipDetail.php
            OpportunityComparison.php
            EligibilityChecker.php
        Authenticated/
            Dashboard.php
            SavedOpportunities.php
            Preferences.php
            EligibilityAssessments.php

    Filament/                       — Filament admin panel
        Resources/
            InstitutionResource.php
            ProgrammeResource.php
            ScholarshipResource.php
            AdmissionCycleResource.php
            InformationSourceResource.php
            QualificationResource.php
            ScholarshipProviderResource.php
            EducationAuthorityResource.php
        Pages/
            Dashboard.php

    Support/                        — Shared application utilities
        CountryReference.php        — ISO 3166-1 wrapper (not a domain VO)
        ReferenceDataSeeder.php     — Reference data seeding helpers

config/
    studyNexus.php                  — Domain-specific configuration

database/
    migrations/
    seeders/
        CountrySeeder.php           — ISO 3166-1 data
        NigeriaReferenceDataSeeder.php  — Nigerian authorities, qualifications, pathways
        GhanaReferenceDataSeeder.php    — Ghana reference data (when needed)
        ...

routes/
    web.php                         — Public routes (Blade/Livewire)
    authenticated.php               — Authenticated user routes
    filament.php                    — Filament admin routes (auto-generated)
    api.php                         — API routes (if needed later)

tests/
    Unit/Domain/
    Feature/Actions/
    Feature/Queries/
    Browser/Livewire/
```

### Why This Structure

1. **`app/Domain/`** is the heart — anyone opening the codebase sees the domain model first.
2. **Domain models are in `Domain/Models/`**, not `app/Models/`, to keep domain concepts together.
3. **Actions are flat** (not nested per entity in Domain/) because Actions are application-layer use cases, not domain concepts. They orchestrate domain + infrastructure.
4. **Queries are separate from Actions** — reads and writes have different concerns.
5. **Livewire and Filament are top-level** — they are architectural boundaries, not domain concepts.
6. **Eloquent model location** uses `Domain/Models/` instead of Laravel's default `app/Models/`. This requires updating `Models` namespace in `app.php` config. The trade-off is worth it for domain cohesion.

---

## 27. Example End-to-End Flows

### Flow 1: Admin Creates a New Institution

```
1. Admin navigates to Filament → Institutions → "New Institution"

2. Filament Resource renders form:
   - official_name, institution_type, registration_identifier,
     ownership_type, country, location, year_established, website_url

3. Admin fills form and clicks "Create"

4. Filament calls CreateInstitution Action:
   app(Actions\Institutions\CreateInstitution::class)->execute($data)

5. CreateInstitution Action:
   a. Authorize: $this->authorize('create', Institution::class)
   b. Validate jurisdiction: Country + InstitutionType valid combination
   c. Domain operation: $institution = Institution::establish($name, $type, $regId, ...)
   d. Persist: $institution->save()
   e. Dispatch event: InstitutionEstablished event fires
   f. Activity log: activity()->log('Created institution ' . $institution->official_name)
   g. Search index: UpdateSearchIndex listener triggers

6. Return: Institution ID to Filament for redirect

Data flow:
  Filament Form → Action → Domain Model → Database
                         → Event → Listeners (Search, Activity, Notification)
```

### Flow 2: Student Searches for Programmes

```
1. Student visits /programmes?q=computer+science&country=ng&type=university

2. Route hits ProgrammeSearch Livewire component

3. Livewire component calls SearchProgrammes Query:
   app(Queries\Programmes\SearchProgrammes::class)->search(
       query: 'computer science',
       country: 'ng',
       institutionType: 'university',
   )

4. SearchProgrammes Query:
   a. If search engine available: query Typesense/Elasticsearch
   b. If not: Eloquent query with scopes + full-text search
   c. Apply filters (country, type, award level, delivery mode)
   d. Apply sorting (relevance, name, tuition)
   e. Paginate results
   f. Eager-load institution relationship for display

5. Livewire renders results using Blade template:
   - Each result shows: programme name, institution name, award level,
     tuition fee, admission status badge, accreditation badge, trust signal

6. Student clicks a programme → ProgrammeDetail Livewire component

7. ProgrammeDetail calls GetProgrammeDetails Query:
   - Full programme data
   - Institution data
   - Current admission status (IsProgrammeAdmitting query)
   - Accreditation status (derived from records)
   - Available scholarships (Scholarship targeting this programme)
   - Trust signal

Data flow:
  Livewire → Query → Search Engine / Eloquent → Read Model
         → Blade → HTML (server-rendered)
```

### Flow 3: Scholarship Applications Open (Scheduled)

```
1. Scheduled task runs: php artisan scholarship:check-applications

2. Command calls ExpireScholarships Action:
   app(Actions\Scheduled\ExpireScholarships::class)->execute()

3. ExpireScholarships Action:
   a. Find all scholarships with application_deadline < now() AND status = Open
   b. For each: $scholarship->closeApplications()
   c. Find all scholarships with application_deadline < now() - grace AND status = Closed
   d. For each: $scholarship->expire()

4. Each domain operation dispatches events:
   - ScholarshipApplicationsClosed → UpdateSearchIndex, DispatchNotifications
   - ScholarshipExpired → UpdateSearchIndex

5. Notification listener sends emails to:
   - Applicants who were watching this scholarship
   - Admin team for expired scholarships

Data flow:
  Scheduler → Action → Domain Model → Database
                       → Events → Listeners (Search, Notification, Activity)
```

### Flow 4: Admin Merges Two Institutions

```
1. Admin selects two institutions in Filament, clicks "Merge"

2. Filament calls MergeInstitutions Action:
   app(Actions\Institutions\MergeInstitutions::class)->execute($initiating, $target)

3. MergeInstitutions Action:
   a. Authorize: $this->authorize('merge', Institution::class)
   b. Validate: both institutions are Operational
   c. Confirm with admin: programmes, accreditation, scholarships will be affected

4. InstitutionMerger domain service (within DB transaction):
   a. Load all programmes belonging to target institution
   b. For each programme: $programme->reassignTo($initiating->id)
   c. Transfer accreditation records from target to initiating
   d. $target->close() — sets target to Closed status
   e. Dispatch InstitutionsMerged event

5. Event listeners:
   - UpdateSearchIndex: rebuild search documents for all affected entities
   - LogActivity: record merge with before/after properties
   - DispatchNotifications: notify programme administrators of ownership change

6. If any step fails: DB transaction rolls back; no partial state

Data flow:
  Filament → Action → Domain Service → Multiple Domain Models → Database (transactional)
                              → Event → Listeners (Search, Activity, Notification)
```

---

## 28. Architectural Risks and Trade-offs

### Risk Register

| ID | Risk | Severity | Mitigation | Decision |
|----|------|:--------:|------------|----------|
| R1 | **Eloquent model = aggregate root coupling** — Changes to persistence (e.g., separate read store) require refactoring the aggregate root | Medium | Aggregate operations are methods on the model; extraction to a separate domain class is possible if needed. Refactor seam: domain operations are already named methods, not raw attribute access. | Accept for MVP. Pragmatic LBC choice. |
| R2 | **Filament admin bypasses Actions** — Developers may add business logic directly in Filament Resources | Medium | Code review convention: Filament Resources must invoke Actions. Architecture decision record (ADR). | Enforce via convention + review. |
| R3 | **Domain events vs Activity Log confusion** — Developers may log every domain event as activity, or treat activity log entries as domain events | Low | Clear documentation (this document). Distinct namespaces. Different interfaces. | Accept. Training issue, not architectural. |
| R4 | **Read model staleness** — `isAdmitting` query may return stale data after cycle phase advance | Low | Eventual consistency is acceptable for discovery. Users expect a slight delay. Real-time precision is for application systems, not discovery. | Accept. Eventual consistency is correct for this domain. |
| R5 | **Polymorphic relationships performance** — Admission Policy and Accreditation Record use polymorphic belongsTo | Low | Index on `(accreditable_type, accreditable_id)`. PostgreSQL handles polymorphic queries well. If performance becomes an issue, consider separate tables. | Accept. Standard Laravel pattern. |
| R6 | **Single bounded context for MVP** — Opportunity Discovery and Trust & Accreditation share a single Laravel app | Low | Namespace separation provides conceptual boundaries. Refactor seam exists for future extraction. | Accept. Pragmatic. |
| R7 | **Spatie package lock-in** — Deep integration with Spatie packages may make replacement expensive | Low | Spatie packages are widely adopted, well-maintained, and follow Laravel conventions. Replacement is unlikely and would be gradual if needed. | Accept. Pragmatic risk. |
| R8 | **No repositories = harder to test domain in isolation** — Domain operations that call `save()` require a database | Medium | Laravel's in-memory SQLite + factories provide fast testing. Domain logic (invariant checks, state transitions) can be tested on unsaved model instances. | Accept. SQLite is fast enough. |
| R9 | **JSON columns for complex VOs** — Querying inside JSON (e.g., finding all programmes with a specific admission rule) is harder | Medium | JSON columns are for data that is primarily read as a whole (rules collection). If individual rule querying is needed, extract to a separate table. For MVP, JSON is appropriate. | Accept for MVP. Revisit if rule-level queries are needed. |
| R10 | **Admission Pathway as VO** — If pathways later acquire behaviour (e.g., pathway-specific rules that are maintained centrally), promoting back to entity is a structural change | Low | Promotion requires: (1) invariant justification, (2) identity beyond discriminator, (3) autonomous lifecycle. None of these exist today. If they emerge, the promotion is additive (add table, add model). | Accept. Demotion was correct based on behavioural evidence. |

### Key Trade-offs

| Trade-off | Choice | Alternative | Why This Way |
|-----------|-------|-------------|-------------|
| Pragmatism vs Purity | Eloquent = aggregate persistence | Separate domain entities + repositories | Small team; Eloquent is sufficient; LBC philosophy |
| Convenience vs Safety | Actions invoked by convention | Mandatory Action for every write | Not every write needs orchestration; simple operations can skip Action |
| Eventual vs Strong consistency | Read models are eventually consistent | Synchronous cross-aggregate queries | Discovery domain tolerates staleness; real-time is for application systems |
| Single vs Multiple BCs | Single Laravel app for MVP | Separate contexts per BC | Pragmatic; namespace separation provides boundary; extraction later |
| JSON vs Normalized | JSON columns for policy rules | Separate rule tables | Rules are always read/written as a collection; JSON is natural |
| TALL vs SPA | Server-rendered + Livewire | React/Next.js frontend | SEO critical; team expertise; simplicity |

---

## 29. Architecture Decision Records Required Before Implementation

Before writing implementation code, the following ADRs must be documented and approved:

| ADR # | Title | Decision | Status |
|-------|-------|----------|--------|
| ADR-1 | Eloquent Model as Aggregate Root Persistence | Use Eloquent models directly as aggregate persistence representation; no separate domain entity classes | **Proposed** |
| ADR-2 | Action Pattern Adoption | Use Laravel Beyond CRUD Actions for orchestrated operations; simple operations may bypass Actions | **Proposed** |
| ADR-3 | Domain Event Implementation | Use Laravel native events; no event sourcing; events dispatched from domain methods | **Proposed** |
| ADR-4 | Value Object Persistence | Custom Eloquent casts for complex VOs; PHP enums for enum-like VOs; JSON for collection VOs | **Proposed** |
| ADR-5 | Read Model Strategy | Dedicated Query classes; Eloquent scopes for simple queries; eventual consistency for cross-aggregate queries | **Proposed** |
| ADR-6 | Search Engine Selection | Scout + Typesense for MVP; PostgreSQL full-text as fallback; domain never coupled to search engine | **Proposed** |
| ADR-7 | Spatie Package Adoption | Adopt 9 packages now; defer 2; evaluate 4 later; reject 2 | **Proposed** |
| ADR-8 | Filament vs Custom Admin | Filament for admin; domain rules remain outside Filament; Actions as integration point | **Proposed** |
| ADR-9 | Bounded Context Implementation | Single app with namespace separation for MVP; refactor seams for future extraction | **Proposed** |
| ADR-10 | Namespace and Directory Structure | `app/Domain/` for domain; `app/Actions/` for use cases; `app/Queries/` for reads; `app/Livewire/` and `app/Filament/` for presentation | **Proposed** |
| ADR-11 | Polymorphic vs Separate Tables | Polymorphic for Admission Policy and Accreditation Record (shared structure, different parents) | **Proposed** |
| ADR-12 | Repository Decision | No repositories; Eloquent IS the repository; introduce only if genuine need emerges | **Proposed** |
| ADR-13 | Reference Data Management | Supporting entities managed via Filament CRUD; seeded for initial markets; Country as ISO wrapper | **Proposed** |
| ADR-14 | Testing Strategy | Domain unit tests (highest priority); feature tests for Actions; browser tests for Livewire | **Proposed** |

---

## 30. Final Readiness Assessment

### Architecture vs Domain Discovery Alignment

| Domain Discovery Requirement | Architecture Response | Aligned? |
|-----------------------------|---------------------|:--------:|
| 5 aggregate roots with 22 invariants | Eloquent models with domain operation methods + invariant checks | ✅ |
| 3 child entities with parent-controlled lifecycle | Eloquent models with BelongsTo; no independent controllers | ✅ |
| 3 supporting entities (reference data) | Eloquent models with Filament CRUD management | ✅ |
| 27 value objects | 13 PHP enums + 14 immutable PHP objects with Eloquent casts | ✅ |
| 27 domain events | Laravel native events dispatched from domain methods | ✅ |
| 7 read-model queries | Dedicated Query classes | ✅ |
| 1 domain service | InstitutionMerger in `app/Domain/Services/` | ✅ |
| Admission Pathway demoted to VO | AdmissionPathway VO with reference data | ✅ |
| isAdmitting = read-model query | IsProgrammeAdmitting Query class | ✅ |
| Educational Opportunity = facade | GetOpportunityFeed Query class (read model) | ✅ |
| Admission Policy ≠ Eligibility Policy | Separate models, separate tables, no shared abstraction | ✅ |
| No shared Policy abstraction | No PolicyInterface, no AbstractPolicy | ✅ |
| Global-first, Nigeria-first-dataset | No hardcoded Nigerian concepts; reference data seeding | ✅ |
| TALL stack only | Laravel + Blade + Livewire + Flux + Tailwind; no SPA | ✅ |
| Filament for admin | Filament resources invoke Actions; no business logic in Filament | ✅ |
| Spatie before reinvention | 9 adopted, 2 deferred, 4 later, 2 rejected with rationale | ✅ |
| LBC pragmatic philosophy | Eloquent = aggregate; no repos; Actions for orchestration; no over-engineering | ✅ |

### Architecture Quality Assessment

| Criterion | Assessment | Score |
|-----------|-----------|:-----:|
| Domain accuracy (code structure reflects domain) | Aggregate boundaries, domain operations, and invariants are expressible and enforceable | 9/10 |
| Pragmatism (simplest architecture that works) | Eloquent models, native events, Actions for orchestration only, no unnecessary abstractions | 9/10 |
| Invariant protection | Domain operation methods with precondition checks; state transition guards; activity log for audit | 8/10 |
| Separation of concerns | Domain → Application → Presentation; dependency direction enforced by convention + static analysis | 8/10 |
| Global extensibility | 9 countries tested; 0 structural changes; reference data additions only | 9/10 |
| SEO support | Server-rendered, crawlable, Schema.org, sitemaps, canonical URLs | 9/10 |
| Team velocity | TALL stack (familiar Laravel); no SPA build step; Filament for admin (rapid); Actions are simple classes | 9/10 |
| Evolvability | Bounded context seams; namespace separation; new aggregates addable; supporting entities promotable | 8/10 |
| Testability | Domain unit tests without DB; feature tests with SQLite; Livewire component tests | 8/10 |
| Documentation | ADRs, this architecture document, domain discovery artifacts | 9/10 |

### Remaining Decisions Before Implementation

| Decision | Impact | When |
|----------|--------|------|
| Search engine selection (Typesense vs PostgreSQL FTS) | Infrastructure; not domain | Before search feature implementation |
| Queue driver (Redis vs Database) | Infrastructure; not domain | Before async event processing |
| Cache strategy for read models | Infrastructure; not domain | Before production deployment |
| Media storage (S3 vs local) | Infrastructure; not domain | Before media upload feature |
| CI/CD pipeline | Infrastructure; not domain | Before first deployment |
| Nigeria reference data seeding content | Data; not architecture | Before launch |

### Verdict

## **READY FOR IMPLEMENTATION PLANNING**

The domain architecture is complete. All 30 sections have been addressed. The architecture:

1. **Accurately expresses the domain** — aggregate boundaries, invariants, domain operations, and value objects are directly implementable.
2. **Protects important business rules** — domain operation methods with precondition checks and state transition guards.
3. **Remains pleasant to develop** — TALL stack, Filament admin, Actions for orchestration, no unnecessary abstractions.
4. **Can grow from Nigeria → Africa → global** — zero structural changes for 9 countries; bounded context seams for future expansion.
5. **Follows Laravel Beyond CRUD philosophy** — pragmatic, not academic; Eloquent is the default; abstractions only when justified.
6. **Preserves all Topic 1–4 decisions** — no domain decisions reversed; Admission Pathway demotion respected; isAdmitting = read model respected; Policy separation respected.

The 14 ADRs should be documented and approved before implementation begins. The architecture document should be treated as a living document — it will evolve as implementation reveals practical considerations not visible at the architecture level.

---

### Architectural Summary

**Stack:** Laravel + Blade + Livewire + Flux + Tailwind CSS + Filament (admin)
**Philosophy:** Laravel Beyond CRUD (Pragmatic Domain-Driven Design)
**Domain:** 5 aggregate roots, 3 child entities, 3 supporting entities, 27 VOs, 27 domain events, 7 queries, 1 domain service, 22 invariants
**Structure:** `app/Domain/` (models, VOs, enums, events, services) + `app/Actions/` (use cases) + `app/Queries/` (reads) + `app/Livewire/` (public UI) + `app/Filament/` (admin UI)
**Spatie:** 9 adopted now, 2 deferred, 4 evaluate later, 2 rejected
**No:** Repositories, Event Sourcing, CQRS framework, SPA, Microservices, Generic abstractions
**Ready for:** Implementation planning with 14 ADRs to approve
