# StudyNexus — Open Questions

**Business Discovery Status:** FROZEN (2026-08-07) — per 09-business-discovery-freeze.md
**Last updated:** 2026-08-08 (owner decisions applied)

## Resolved Questions

| ID | Topic | Question | Resolution | Date |
|----|-------|----------|-----------|------|
| OQ1-1 | Primary Users | What is the priority ranking of the four primary personas? | **Priority:** 1. Secondary School Student/Graduate, 2. Undergraduate Student, 3. Parent/Guardian, 4. Guidance Counsellor/Teacher. The first two are primary usage personas. Parents are high-impact decision influencers. Counsellors/teachers are lower-volume but strategically valuable professional users. | 2026-08-08 |
| OQ1-3 | Primary Users | Can users research foreign institutions on day one? | **No.** Day One is strictly Nigerian institutions and Nigerian education data. Foreign institutions are future scope. Long-term direction is African education infrastructure, but Nigeria is the initial bounded domain. | 2026-08-08 |
| OQ1-4 | Primary Users | Do personas require distinct interface patterns? | **Core interaction is shared;** workflows and interfaces adapt to persona goals. Do not build four separate products. Shared capabilities underpin goal-oriented workflows. | 2026-08-08 |
| OQ2-3 | Secondary Users | When are institution management features expected? | **Post-MVP.** Institution management features come after the public discovery/information layer is established. | 2026-08-08 |
| OQ2-4 | Secondary Users | When are scholarship provider management features expected? | **Post-MVP.** Scholarship-provider management follows the public scholarship discovery/data layer. | 2026-08-08 |
| OQ2-5 | Data Acquisition | Do Government Education Agencies actively provide data? | **Initially, information is primarily aggregated from public and official sources.** Government agencies are authoritative sources, but the system should not depend on agencies actively providing data. Direct data partnerships/feeds are future enhancements. | 2026-08-08 |
| OQ3-1 | Problem Space | Are these the complete set of problem dimensions? | **Yes** for the current business-discovery model. Fragmentation, Trust, Discoverability, Comparison and Accessibility are the established primary problem dimensions. New dimensions require explicit change proposal/evidence. | 2026-08-08 |
| OQ3-4 | Problem Space | Relative severity of the five problem dimensions per persona? | **Deferred detailed persona-by-persona scoring.** Fragmentation, Discoverability and Trust are foundational; Comparison is especially important during decision-making; Accessibility cuts across all personas. | 2026-08-08 |
| OQ4-1 | Evolution | Does the MVP require user accounts/identity? | **No account required** for core MVP discovery, search, comparison and information access. Accounts should only be introduced when persistent/personal capabilities justify them. | 2026-08-08 |
| OQ4-2 | Evolution | What user feedback mechanisms exist for information quality? | **Users can report information as incorrect, outdated, missing or conflicting.** Reports enter an information-quality workflow and do not directly modify canonical data. | 2026-08-08 |
| OQ4-3 | Evolution | What does "decision support" mean as a business capability? | **Both, progressively.** Initially: structured consolidation, discovery, comparison and verification. As reliable structured data and rules mature: recommendation and eligibility assessment. StudyNexus should support decisions rather than make opaque decisions on behalf of users. | 2026-08-08 |
| OQ4-4 | Evolution | What is the business model/revenue model? | **Deferred exact monetisation mechanics.** Strategic model: free core discovery/search/information access, with future monetisation through institution/provider services, premium capabilities and relevant education-related commercial services. Monetisation should not drive the core information architecture. | 2026-08-08 |
| OQ5-1 | Capabilities | Are these 10 capabilities the complete MVP set? | **The 10 capabilities constitute the current MVP capability baseline**, not an immutable statement of every future capability. Changes should follow the established business-discovery/change-proposal process. | 2026-08-08 |
| OQ6-1 | Workflows | What constitutes "sufficient" information for a decision? | **Decision-dependent.** An evaluation is sufficient when the information required for the specific decision is available, sufficiently trustworthy, current for the relevant period, and comparable across alternatives. | 2026-08-08 |
| OQ6-2 | Workflows | What are the standard comparison dimensions? | **Common foundation:** identity, location, eligibility/requirements, cost/benefit, timing, availability, authority/provenance and status — with category-specific dimensions for institutions, programmes, scholarships and other opportunity types. | 2026-08-08 |
| OQ6-3 | Workflows | Does StudyNexus perform eligibility assessment? | **Both.** Initially: provide authoritative requirements for self-assessment. Progressively: structured eligibility assessment where underlying requirements and rules are sufficiently reliable and machine-actionable. | 2026-08-08 |
| OQ6-5 | Workflows | Does StudyNexus provide decision support beyond information aggregation? | **Yes.** Through structured comparison, relevant opportunity discovery, requirement/eligibility assessment and recommendation. | 2026-08-08 |
| OQ6-6 | Workflows | What parameters guide structured exploration per persona? | **Goal/workflow-driven, not persona-driven.** Parameters: goal, opportunity category, education level/stage, location, field/subject, eligibility, timing, cost and other decision-specific constraints. | 2026-08-08 |
| OQ6-7 | Workflows | What specific information types are required per opportunity category? | **Each category requires its own evaluation model** built from common primitives: identity, eligibility, requirements, cost/benefit, location, timing, availability, authority/provenance and status. | 2026-08-08 |
| OQ6-8 | Workflows | How do trust signals differ across Information Categories? | **Official** = directly attributable to an authoritative institution/agency. **Verified** = independently checked by StudyNexus. **Historical** = valid for a previous period/version. **Community-Contributed** = user-supplied information not established as authoritative. | 2026-08-08 |
| OQ7-1 | Workflows | What information is most critical for an undergraduate's current journey? | **Current institution, programme, academic level/year, academic calendar, academic requirements/status, courses, assessments, fees, deadlines, institutional policies/procedures, scholarships/opportunities and progression/transfer information.** | 2026-08-08 |
| OQ7-2 | Workflows | Does WF7 apply only to Undergraduate Students? | **Yes.** WF7 (Understand Current Educational Journey) is specifically for enrolled undergraduate students. Other personas should not receive duplicated versions. | 2026-08-08 |
| OQ7-3 | Workflows | Should the four candidate concepts be promoted to canonical? | **No.** Do not automatically promote. Their status should depend on identity, lifecycle, ownership, persistence and independent business behavior. They may instead be domain concepts/value objects or attributes of other domain objects. | 2026-08-08 |

## Remaining Open Questions

*All 22 original questions have been resolved as of 2026-08-08. No questions remain open.*

| ID | Topic | Question | Status | Resolution |
|----|-------|----------|--------|------------|
| *(none)* | | | | All resolved — see above |

## Deferred Items (resolved but require future action)

| ID | What Was Deferred | When to Act |
|----|-------------------|-------------|
| OQ4-4 | Exact monetisation mechanics | When business model is tested against real usage data |
| OQ3-4 | Detailed persona-by-persona severity scoring | When user research data is available |
