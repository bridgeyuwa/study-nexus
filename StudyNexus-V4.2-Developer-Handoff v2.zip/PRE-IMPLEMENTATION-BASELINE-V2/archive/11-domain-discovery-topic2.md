# StudyNexus — Domain Discovery: Topic 2
# Entity Relationships, Aggregate Boundaries & Lifecycles

**Date:** 2026-08-07
**Status:** Awaiting Approval
**Prerequisite:** Topic 1 (Core Domain Entities) — Approved with amendments
**Business Discovery Status:** Frozen (immutable)

---

## Topic 1 Amendments Applied

The following amendments from Topic 1 approval are incorporated into this analysis:

1. **Admission Requirement → Policy-based model**: Individual requirements are not entities. Admission Policy and Eligibility Policy contain rules that express requirements.
2. **Admission Cycle**: Introduced as a first-class domain entity representing time-bounded admission processes.
3. **Accreditation → Accreditation Record**: Renamed to clarify that each record represents a specific accreditation event (grant, renewal, suspension, etc.), not a standing status.
4. **Faculty/Department**: Deferred for re-evaluation during later discovery.

---

## Candidate Domain Entities (Post-Topic 1)

### Core Entities
- Educational Institution
- Programme
- Scholarship
- Qualification
- Admission Cycle
- Accreditation Record

### Supporting Entities
- Scholarship Provider
- Government Education Agency
- Information Source

### Policy Entities
- Admission Policy
- Eligibility Policy

---

## Summary of Understanding

The Nigerian education system organizes around institutions that offer programmes, each governed by admission policies that vary by admission cycle. Regulatory agencies (NUC, NBTE, NCCE) grant accreditation to institutions and programmes. Examination bodies (JAMB, WAEC, NECO, NABTEB) define qualifications that serve as admission requirements. Scholarship providers offer scholarships governed by eligibility policies. All information in StudyNexus traces to information sources for provenance.

The domain exhibits a central tension: entities are strongly owned (a programme cannot exist without an institution, a policy cannot exist without its governing entity) yet are independently accessed (users search for programmes, compare scholarships, check accreditation). This requires aggregate roots with mandatory parent references — a pattern where business ownership is composition but domain access patterns demand independent aggregate boundaries.

Admission cycles introduce a temporal axis that cuts across the static ownership hierarchy. Policies, accreditation records, and admission cycles are all time-bounded, creating a domain where the same programme has different admission rules, different accreditation status, and different cycle participation from year to year.

---

## DD2-1: Aggregate Boundaries

### Decision

Every entity is an aggregate root. No entity is a child entity within another aggregate.

### Justification

| Entity | Aggregate Root? | Always Owned? | Exists Independently? | Own Lifecycle? | Justification |
|--------|:---:|:---:|:---:|:---:|---------------|
| Educational Institution | **Yes** | No | Yes | Yes | Top-level organizational entity. Not owned by any other aggregate. Users search for and compare institutions directly (WF1, WF2, WF3). |
| Programme | **Yes** | Composition by Institution | Yes (with mandatory parent) | Yes | Cannot exist without an Institution, but has its own identity, lifecycle, and invariants. Users search for and compare programmes independently (WF1, WF2, WF3). Embedding within Institution aggregate would create an aggregate of unbounded size — a university may offer 100+ programmes. |
| Scholarship | **Yes** | Aggregation by Provider | Yes | Yes | Has its own lifecycle (announced → open → closed → expired). Users discover and compare scholarships independently (WF1, WF2, WF3). A provider does not compositionally own scholarships — if a provider ceases, the scholarship remains as information. |
| Qualification | **Yes** | No | Yes | Yes | Reference entity in the domain. Referenced by admission policies and eligibility policies. Not owned by any aggregate. Very stable lifecycle. |
| Admission Cycle | **Yes** | No | Yes | Yes | Time-bounded process entity. Has its own lifecycle (upcoming → opened → in_progress → closed). Users search by cycle ("2024/2025 admission"). Not owned by any single institution or programme — a cycle spans multiple institutions. |
| Accreditation Record | **Yes** | No | Yes (with mandatory references) | Yes | Represents a specific accreditation event. Has its own lifecycle (granted → renewed → revoked → expired). Referenced by both the accredited entity and the granting agency. Not owned by either — it is a fact about the relationship between them. |
| Scholarship Provider | **Yes** | No | Yes | Yes | Independent organizational entity. Referenced by Scholarships. Not owned by any aggregate. |
| Government Education Agency | **Yes** | No | Yes | Yes | Independent regulatory/examination entity. Referenced by Accreditation Records and Qualifications. Not owned by any aggregate. |
| Information Source | **Yes** | No | Yes | Yes | Cross-cutting provenance entity. Referenced by virtually every other entity. Must be independently addressable for trust assessment (WF5). Not owned by any aggregate. |
| Admission Policy | **Yes** | Composition by Programme or Institution | Yes (with mandatory parent) | Yes | Has its own lifecycle (draft → published → active → superseded → retired). Contains rules that are independently accessed during eligibility assessment (WF4). Embedding within Programme aggregate would load all historical policies unnecessarily. |
| Eligibility Policy | **Yes** | Composition by Scholarship | Yes (with mandatory parent) | Yes | Has its own lifecycle identical to Admission Policy. Contains rules independently accessed during scholarship eligibility assessment (WF4). |

### Key Insight: Aggregate Roots with Mandatory Parent References

Programme, Admission Policy, and Eligibility Policy are compositionally owned by another entity but are still aggregate roots. This is not a contradiction — it reflects that:

1. **Business ownership is composition**: A Programme cannot exist without an Institution. An Admission Policy cannot exist without a Programme. These are invariant business rules of the Nigerian education system.
2. **Domain access patterns demand independent boundaries**: Users do not load an entire institution to view a programme. Users do not load a programme's entire history to see current admission requirements. Aggregate boundaries serve access patterns, not just ownership.
3. **Aggregate size is bounded by access, not ownership**: An institution with 100 programmes would violate aggregate size boundaries if programmes were embedded. An programme with 20 years of admission policies would violate boundaries if policies were embedded.

The mandatory parent reference is an invariant of the child aggregate, not a structural nesting.

### Domain Decision

> **DD2-1**: All eleven candidate domain entities are aggregate roots. Programme, Admission Policy, and Eligibility Policy carry a mandatory composition invariant — they cannot exist without their parent entity — but are not structurally nested within the parent aggregate. Aggregate boundaries are determined by access patterns and invariant enforcement, not solely by ownership.

---

## DD2-2: Ownership Relationships

### Relationship Inventory

| # | Parent | Child | Relationship Type | Justification |
|---|--------|-------|-------------------|---------------|
| 1 | Educational Institution | Programme | **Composition** | A Programme cannot exist without an Institution. If the Institution ceases to operate, its Programmes cease to admit. The Programme's identity is institution-scoped (a programme is "Computer Science at University of Lagos", not "Computer Science" in isolation). This is a fundamental invariant of the Nigerian education system — no programme exists unaffiliated. |
| 2 | Programme | Admission Policy | **Composition** | An Admission Policy cannot exist without a Programme (or, for institutional-level policies, without an Institution). The policy governs admission for a specific entity. Without the governed entity, the policy has no meaning. |
| 3 | Educational Institution | Admission Policy | **Composition** (institutional-level) | Some admission requirements are set at the institutional level (minimum O'level credits, post-UTME requirements). These policies belong to the Institution. |
| 4 | Scholarship | Eligibility Policy | **Composition** | An Eligibility Policy cannot exist without a Scholarship. The policy defines who qualifies for a specific scholarship. Without the scholarship, the policy has no purpose. |
| 5 | Scholarship Provider | Scholarship | **Aggregation** | A Scholarship is offered by a Provider, but the Scholarship exists as information independently. If a Provider ceases operations, the Scholarship remains as a historical record. The Provider does not compositionally own the Scholarship — it announces and administers it, but StudyNexus records it as independent knowledge. |
| 6 | Government Education Agency | Accreditation Record | **Association** (with mandatory participant) | An Agency grants an Accreditation Record, but does not own it. The Record is a fact about the relationship between an Agency and an Institution/Programme. The Agency cannot revoke the Record's existence — it can only change the Record's status (suspend, revoke). The Agency is a mandatory participant in the relationship, not an owner. |
| 7 | Educational Institution | Accreditation Record | **Association** | An Institution is the subject of accreditation, not the owner of the record. The Record exists as an independent fact. The Institution cannot create or destroy accreditation records — only the granting Agency can. |
| 8 | Programme | Accreditation Record | **Association** | Same rationale as Institution → Accreditation Record. In Nigeria, NUC accredits specific programmes (programme accreditation is distinct from institutional accreditation). The Programme is the subject, not the owner. |
| 9 | Admission Cycle | Programme | **Association** | An Admission Cycle involves Programmes, but does not own them. Programmes exist across many cycles. A cycle references the programmes participating in it. |
| 10 | Admission Cycle | Educational Institution | **Association** | An Admission Cycle involves Institutions, but does not own them. Institutions exist across many cycles. |
| 11 | Government Education Agency | Qualification | **Association** | An Agency defines/awards a Qualification, but the Qualification exists as a domain concept independently. WAEC exists as a concept whether or not we reference the WAEC agency. |
| 12 | Scholarship | Programme | **Association** | A Scholarship may target specific Programmes, but does not own them. The Scholarship references the Programmes it applies to. |
| 13 | Scholarship | Educational Institution | **Association** | A Scholarship may target specific Institutions, but does not own them. The Scholarship references the Institutions it applies to. |
| 14 | Information Source | *(all entities)* | **Association** (cross-cutting) | Information Source is referenced by all entities for provenance. It owns no entity and no entity owns it. |

### Composition vs Aggregation vs Association Principles

| Type | Definition | Delete Behaviour | Domain Examples |
|------|-----------|------------------|----------------|
| **Composition** | Child cannot exist without parent. Child's identity is parent-scoped. | Deleting parent conceptually deletes child (though in a knowledge platform, historical records may be retained). | Institution→Programme, Programme→Admission Policy, Scholarship→Eligibility Policy |
| **Aggregation** | Child belongs to parent but can exist independently. Parent "has" child. | Deleting parent does not delete child. | Scholarship Provider→Scholarship |
| **Association** | Entities reference each other. Neither owns the other. | Either entity can exist without the other. | Agency↔Accreditation Record, Scholarship↔Programme, Information Source↔any entity |

### Domain Decision

> **DD2-2**: The domain has three composition relationships (Institution→Programme, Programme/Institution→Admission Policy, Scholarship→Eligibility Policy), one aggregation relationship (Scholarship Provider→Scholarship), and all other relationships are associations. Composition reflects existential dependency in the Nigerian education system. Aggregation reflects administrative but not existential dependency. Association reflects independent entities that reference each other.

---

## DD2-3: Identity Rules

### Business Identity for Each Entity

| Entity | Business Identity | Scope | Stable? | Changes Over Time? | Justification |
|--------|-------------------|-------|:-------:|:------------------:|---------------|
| Educational Institution | Official name + institution type + regulatory body registration | National | No (name can change) | Yes (renaming) | "University of Ife" became "Obafemi Awolowo University". The institution is the same continuing entity. Identity is the continuing legal entity, not the current name. |
| Programme | Programme name + owning Institution + award level | Institution-scoped | Mostly | Rarely (renaming, restructuring) | "Computer Science" at "University of Lagos" at "B.Sc." level uniquely identifies the programme. Programme names occasionally change (e.g., "Computer Engineering" → "Computer & Electrical Engineering"). |
| Scholarship | Scholarship name + offering Provider + applicable year/period | Provider-scoped | Mostly | Rarely | "Shell Undergraduate Scholarship" by "Shell Nigeria" for "2024". The same scholarship name may recur annually with different terms. |
| Qualification | Qualification name + awarding/examining body | National | Yes | No | "WAEC SSCE", "JAMB UTME", "NCE", "ND", "HND". These are stable domain concepts. |
| Admission Cycle | Year/period + scope level (national/institutional/programme) | Temporal | Yes | No | "2024/2025 UTME Cycle" (national), "2024/2025 UNILAG Admission Cycle" (institutional). Once defined, a cycle's identity is fixed. |
| Accreditation Record | Accredited entity + granting Agency + grant date/effective period | Entity+Agency-scoped | Yes | No | "Computer Science at UNILAG" accredited by "NUC" effective "2023-06-01". Each record is a historical fact that does not change. |
| Scholarship Provider | Official organization name | National | No (name can change) | Yes (renaming, restructuring) | "TotalEnergies" (renamed from "Total"). The provider is the same continuing entity. |
| Government Education Agency | Official name / recognized abbreviation | National | Yes | Rarely | "JAMB", "NUC", "WAEC". These are long-standing bodies with stable identities. |
| Information Source | Source name + source type + retrievable reference | Source-scoped | Mostly | Can become invalid | "UNILAG official website" (URL may change). Identity is the logical source, not the current URL. |
| Admission Policy | Governed entity (Programme or Institution) + applicable Admission Cycle | Entity+Cycle-scoped | Yes (for a given cycle) | Superseded by next cycle's policy | "Computer Science at UNILAG admission requirements for 2024/2025". Once published for a cycle, the policy's identity is fixed. |
| Eligibility Policy | Owning Scholarship + applicable period | Scholarship+Period-scoped | Yes (for a given period) | Superseded by next period's policy | "Shell Scholarship eligibility for 2024". Once published, the policy's identity is fixed. |

### Identity Stability Classification

| Stability | Entities | Implication |
|-----------|----------|-------------|
| **Stable** (identity never changes) | Qualification, Admission Cycle, Accreditation Record, Government Education Agency, Admission Policy, Eligibility Policy | Identity can be used as a reliable reference. No temporal identity tracking needed. |
| **Mostly stable** (identity rarely changes) | Programme, Scholarship, Information Source | Identity changes are exceptional events (renaming, restructuring). Must support identity change as a business event. |
| **Evolving** (name may change, entity continues) | Educational Institution, Scholarship Provider | Name changes are a recognized pattern in Nigeria. Must distinguish between the continuing entity and its current name. |

### Identity Scoping Rules

1. **Programme identity is institution-scoped**: "Computer Science" is not a unique programme — it must be qualified by its Institution. Two institutions may offer "Computer Science" as different programmes with different requirements, accreditation, and characteristics.

2. **Admission Policy identity is entity+cycle-scoped**: The same Programme has a different Admission Policy for each Admission Cycle. A policy's identity includes the cycle it applies to.

3. **Eligibility Policy identity is scholarship+period-scoped**: The same Scholarship has a different Eligibility Policy for each offering period.

4. **Accreditation Record identity is entity+agency+period-scoped**: The same Programme can have multiple accreditation records from the same agency over time (grant, renewal, etc.). Each is a distinct record.

5. **Scholarship identity is provider-scoped**: The same Scholarship name may be used by different providers. Two providers may each offer a "Merit Scholarship" — these are different scholarships.

6. **Qualification identity is national**: Qualifications are not scoped to any institution. "WAEC SSCE" is the same qualification regardless of which institution references it.

### Domain Decision

> **DD2-3**: Business identity is determined by the combination of intrinsic properties and scoping context. Five entities have stable identity (Qualification, Admission Cycle, Accreditation Record, Government Education Agency, Admission/Eligibility Policy). Two entities have evolving identity that requires continuing-entity semantics (Educational Institution, Scholarship Provider). Programme identity is always institution-scoped. Policy identities are always time-scoped (to a cycle or period). Identity rules reflect Nigerian education system conventions, not implementation convenience.

---

## DD2-4: Lifecycles

### Educational Institution

```
established → operational → suspended → closed
                    ↓              ↓
                  merged        renamed
                                  ↓
                              operational
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Established | Institution has been officially recognized (NUC/NBTE/NCCE approval) but is not yet admitting students. | **Yes** — new institution in the landscape |
| Operational | Institution is functioning and admitting students. | No (initial state after establishment) |
| Suspended | Institution's operations have been suspended by regulatory authority (e.g., NUC denies approval). | **Yes** — affects all programmes and students |
| Closed | Institution has been permanently closed or derecognized. | **Yes** — removes from active landscape |
| Merged | Institution has merged with another institution. The merged institution's identity may be absorbed. | **Yes** — restructures the landscape |
| Renamed | Institution's official name has changed. The entity continues under a new name. | **Yes** — affects discoverability |

**Transitions are business events** because each changes the institutional landscape visible to users. Mergers and renames are particularly significant — they affect how users discover and reference institutions.

### Programme

```
introduced → admitting → suspended → discontinued
                 ↓           ↓
               full       resumed → admitting
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Introduced | Programme has been approved/announced but is not yet admitting students. | **Yes** — new programme available |
| Admitting | Programme is actively admitting students in the current cycle. | State change (depends on cycle) |
| Suspended | Programme is not admitting — may be due to accreditation issues, low enrollment, or institutional decision. | **Yes** — affects eligibility |
| Discontinued | Programme is no longer offered. | **Yes** — removes from active landscape |
| Resumed | A suspended programme resumes admitting. | **Yes** — reopens eligibility |

**Key insight**: "Admitting" is not a permanent state — it depends on the intersection of the Programme's lifecycle state and the current Admission Cycle state. A programme may be "admitting" in one cycle and not in another.

### Scholarship

```
announced → open → closed → expired
               ↓
            withdrawn
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Announced | Scholarship has been published but applications are not yet open. | **Yes** — new opportunity |
| Open | Applications are being accepted. | **Yes** — actionable opportunity |
| Closed | Application period has ended. | **Yes** — no longer actionable |
| Expired | Scholarship period has fully elapsed. | State change (natural progression) |
| Withdrawn | Scholarship has been cancelled by the provider before completion. | **Yes** — unusual, affects planning |

### Qualification

```
recognized → deprecated → replaced
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Recognized | Qualification is currently recognized in the Nigerian education system. | No (initial state) |
| Deprecated | Qualification is being phased out but may still be accepted by some institutions. | **Yes** — affects admission policies |
| Replaced | Qualification has been replaced by a successor qualification (e.g., a new vocational certification replaces an old one). | **Yes** — affects eligibility |

Qualification lifecycle is minimal. Most qualifications (WAEC SSCE, JAMB UTME, NCE, ND, HND) are stable and long-recognized. Deprecation is rare.

### Admission Cycle

```
upcoming → registration_open → examination_period → results_released → admission_period → closed → archived
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Upcoming | Cycle has been announced but registration has not begun. | **Yes** — planning phase |
| Registration Open | Candidates can register for the cycle (e.g., UTME registration). | **Yes** — actionable |
| Examination Period | Examinations are being conducted. | **Yes** — critical period |
| Results Released | Examination results are available. | **Yes** — enables evaluation |
| Admission Period | Institutions are conducting admission (post-UTME, screening, list releases). | **Yes** — critical period |
| Closed | The admission cycle has concluded. All admission lists are finalized. | **Yes** — concludes cycle |
| Archived | The cycle is historical. | State change |

**Note**: This lifecycle is described from the national (JAMB) perspective. Institutional admission cycles may have different phases (e.g., post-UTME, screening, departmental admission). The specific phases are an open question (OQ2-6).

### Accreditation Record

```
granted → renewed → expired
   ↓         ↓
interim   partial
   ↓         ↓
suspended  suspended
   ↓
revoked
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Granted | Full accreditation has been granted by the regulatory body. | **Yes** — validates quality |
| Interim | Interim/provisional accreditation granted (typically for new programmes pending full review). | **Yes** — provisional quality signal |
| Partial | Partial accreditation — some components accredited, others not. | **Yes** — mixed quality signal |
| Renewed | Accreditation has been renewed (typically after a 5-year review for NUC). | **Yes** — continued validation |
| Suspended | Accreditation has been suspended pending review or due to deficiencies. | **Yes** — warning signal |
| Revoked | Accreditation has been permanently revoked. | **Yes** — severe quality signal |
| Expired | Accreditation period has ended and has not been renewed. | **Yes** — requires attention |

**Nigerian context**: NUC accreditation follows a specific process — interim accreditation for new programmes (after resource verification), then full accreditation after the first set of graduates. Full accreditation is valid for 5 years. NBTE and NCCE have similar but not identical processes.

### Scholarship Provider

```
active → inactive → dissolved
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Active | Provider is currently operating and offering scholarships. | No (initial state) |
| Inactive | Provider has temporarily ceased operations or scholarship offerings. | **Yes** — affects scholarship availability |
| Dissolved | Provider has permanently ceased to exist. | **Yes** — historical only |

### Government Education Agency

```
established → active → restructured → dissolved
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Established | Agency has been created by legislation. | **Yes** (rare) |
| Active | Agency is currently operating. | No (initial state) |
| Restructured | Agency has been reorganized (e.g., merged with another, renamed, new mandate). | **Yes** (rare) |
| Dissolved | Agency has been dissolved. | **Yes** (very rare) |

Government Education Agency lifecycle is extremely stable in practice. JAMB, NUC, WAEC, NECO, NABTEB, NBTE, NCCE have been operating for decades.

### Information Source

```
discovered → verified → unreliable → deprecated
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Discovered | Source has been identified but not yet verified for reliability. | No (initial state) |
| Verified | Source has been confirmed as reliable and current. | **Yes** — trust signal |
| Unreliable | Source has been assessed as unreliable (outdated, incorrect, unavailable). | **Yes** — trust warning |
| Deprecated | Source is no longer accessible or relevant. | **Yes** — provenance impact |

### Admission Policy

```
draft → published → active → superseded → retired
```

| State | Description | Business Event? |
|-------|-------------|:---------------:|
| Draft | Policy is being prepared but not yet published. | No (internal state) |
| Published | Policy has been published for the applicable admission cycle. | **Yes** — enables eligibility assessment |
| Active | Policy is currently in effect for an active admission cycle. | State change (cycle-dependent) |
| Superseded | Policy has been replaced by a newer policy for a subsequent cycle. | **Yes** — historical reference |
| Retired | Policy is no longer relevant and should not be referenced. | **Yes** — cleanup |

### Eligibility Policy

```
draft → published → active → superseded → retired
```

Identical lifecycle pattern to Admission Policy. Same states and transitions, applied to scholarship eligibility instead of admission.

### Lifecycle Event Classification

| Category | Entities | Rationale |
|----------|----------|-----------|
| **Always business events** | Educational Institution, Programme, Scholarship, Admission Cycle, Accreditation Record, Admission Policy, Eligibility Policy | State transitions in these entities directly affect the educational landscape and user decision-making. Every transition is meaningful in the domain. |
| **Mostly business events** | Qualification, Scholarship Provider, Information Source | Transitions are infrequent but significant when they occur. |
| **Rarely business events** | Government Education Agency | Transitions are exceptional (institutional restructuring at the national level). Most state changes are merely administrative. |

### Domain Decision

> **DD2-4**: Each entity has a defined lifecycle with explicit states and transitions. Lifecycle transitions for Institution, Programme, Scholarship, Admission Cycle, Accreditation Record, and both Policy types are business events because they directly alter the educational landscape visible to users. Programme admission state is cycle-dependent — a Programme is "admitting" only when its lifecycle state and the current Admission Cycle state align. Accreditation Record lifecycle reflects Nigerian regulatory practice (interim → full → renewal cycle with possible suspension/revocation).

---

## DD2-5: Temporal Behaviour

### Temporal Analysis by Entity

| Entity | Time-Bounded? | Versioning Required? | Historical Versions Domain-Relevant? | Justification |
|--------|:---:|:---:|:---:|---------------|
| Educational Institution | Partially (name, ownership) | Yes (name changes) | **Yes** | Users may search for an institution by its former name ("University of Ife" → "Obafemi Awolowo University"). The name history is domain knowledge, not just audit trail. A2-7 requires linking back to authoritative sources, which may reference old names. |
| Programme | Yes (requirements, tuition, accreditation) | Yes (annual changes) | **Yes** | Admission requirements change per cycle. Tuition changes annually. These are not corrections — they are new domain facts. Users comparing admission trends across years need historical programme data (WF3 comparison across cycles). |
| Scholarship | Yes (deadlines, amounts, criteria) | Yes (per offering period) | **Yes** | Each annual offering may have different terms. Previous years' scholarships are reference material for students planning future applications. |
| Qualification | Minimal | No | **No** | Qualifications are stable domain concepts. Deprecation/replacement is rare. Historical versions are not domain-relevant. |
| Admission Cycle | Entirely (time-bounded by definition) | N/A (each cycle is a distinct entity) | **Yes** | Historical cycles are the basis for trend analysis. "What was the cut-off mark for Computer Science at UNILAG in 2022/2023?" is a domain query, not a product feature. |
| Accreditation Record | Entirely (granted for a period) | N/A (each record is a distinct entity) | **Yes** | Accreditation history is domain knowledge. "When was this programme last fully accredited?" is a meaningful domain question that affects trust assessment (WF5). |
| Scholarship Provider | Partially (name, operational status) | Yes (name changes) | **Partially** | Name history is useful for discoverability but less critical than institution name history. |
| Government Education Agency | Minimal | No | **No** | Agencies are stable. Historical versions are not domain-relevant. |
| Information Source | Yes (currency, availability) | Yes (URL changes, content updates) | **Partially** | Knowing when a source was last verified is domain-relevant (trust assessment). Full version history of source content is a product concern. |
| Admission Policy | Entirely (per admission cycle) | N/A (each policy version is a distinct entity) | **Yes** | Previous admission policies are domain reference material. "What were the requirements last year?" is a domain query during WF4. |
| Eligibility Policy | Entirely (per offering period) | N/A (each policy version is a distinct entity) | **Yes** | Same rationale as Admission Policy. |

### Temporal Model Classification

| Pattern | Description | Entities | Domain Treatment |
|---------|-------------|----------|-----------------|
| **Time-bounded entity** | Entity exists for a defined period. Each instance is distinct. | Admission Cycle, Accreditation Record, Admission Policy, Eligibility Policy | Each time-bounded instance is a separate entity instance. No versioning needed — each is a distinct record. |
| **Evolving entity** | Entity persists but its attributes change over time. Historical values are domain-relevant. | Educational Institution, Programme, Scholarship, Information Source | Entity has a current state and a history of changes. Both current and historical values are domain knowledge. |
| **Stable entity** | Entity rarely changes. Historical versions are not domain-relevant. | Qualification, Government Education Agency | Current state only. Changes are exceptional events, not regular patterns. |
| **Administrative entity** | Entity changes are infrequent and primarily administrative. | Scholarship Provider | Current state with minimal history. Name changes are tracked for discoverability. |

### Key Temporal Insights

1. **Admission policies are not "versions" of the same entity** — they are distinct entities scoped to specific admission cycles. The 2023/2024 admission policy for Computer Science at UNILAG and the 2024/2025 policy are two separate Admission Policy entities, not two versions of one entity. This is a domain decision, not an implementation choice — each policy is a distinct set of rules published for a specific cycle.

2. **Accreditation records are not "versions"** — each grant, renewal, or status change is a distinct Accreditation Record entity. The current accreditation status is derived from the most recent record, not stored as a mutable state.

3. **Institution and Programme attribute changes are domain events**, not mere data updates. When UNILAG's tuition changes, the previous tuition remains domain knowledge (for comparison, for students currently enrolled under the old fee structure, for historical analysis).

4. **Admission Cycle is the primary temporal axis** of the domain. Most time-bounded entities are scoped to one or more admission cycles. This makes Admission Cycle a central organizing concept, not just another entity.

### Domain Decision

> **DD2-5**: The domain exhibits four temporal patterns. Time-bounded entities (Admission Cycle, Accreditation Record, both Policy types) are distinct entity instances per period — they are not versioned, they are separate entities. Evolving entities (Institution, Programme, Scholarship, Information Source) maintain both current state and domain-relevant history. Stable entities (Qualification, Government Education Agency) require only current state. Admission Cycle is the primary temporal axis of the domain — most time-bounded concepts are scoped to admission cycles. Historical versions of evolving entities are domain knowledge (supporting trend comparison and trust assessment), not merely product history.

---

## DD2-6: Relationship Cardinality

### Cardinality Table

| # | Entity A | Relationship | Entity B | Cardinality | Business Justification |
|---|----------|-------------|----------|-------------|----------------------|
| 1 | Educational Institution | offers | Programme | 1:N (composition) | An institution offers many programmes. A programme belongs to exactly one institution. In Nigeria, a university may offer 50-100+ programmes. No programme exists unaffiliated. |
| 2 | Programme | governed by | Admission Policy | 1:N | A programme has one active admission policy per cycle, but multiple policies over time (one per cycle). At any given time, one is active; across time, many. |
| 3 | Educational Institution | governed by | Admission Policy | 1:N | An institution has institutional-level admission requirements. Same pattern as programme — one active per cycle, many over time. |
| 4 | Scholarship | governed by | Eligibility Policy | 1:N | Same pattern — one active per period, many over time. |
| 5 | Scholarship Provider | offers | Scholarship | 1:N (aggregation) | A provider offers many scholarships over time. Each scholarship has exactly one provider. |
| 6 | Government Education Agency | grants | Accreditation Record | 1:N | An agency grants many accreditation records over time. Each record is granted by exactly one agency. |
| 7 | Educational Institution | subject of | Accreditation Record | 1:N | An institution is the subject of many accreditation records over time. Each record references exactly one institution. NUC grants both institutional accreditation and programme-specific accreditation. |
| 8 | Programme | subject of | Accreditation Record | 1:N | A programme is the subject of many accreditation records over time. Each record references exactly one programme (for programme-level accreditation) or is institutional-level. |
| 9 | Admission Cycle | involves | Educational Institution | M:N | A cycle involves many institutions. An institution participates in many cycles (one per year). JAMB's UTME cycle involves all participating institutions. |
| 10 | Admission Cycle | involves | Programme | M:N | A cycle involves many programmes. A programme participates in many cycles. |
| 11 | Programme | requires | Qualification | M:N | A programme's admission policy requires certain qualifications (e.g., WAEC SSCE with specific subjects, JAMB UTME with minimum score). A qualification is required by many programmes. |
| 12 | Government Education Agency | defines/awards | Qualification | 1:N | An agency defines or awards many qualifications (e.g., WAEC awards SSCE and GCE; JAMB administers UTME). A qualification is associated with exactly one primary agency. |
| 13 | Scholarship | targets | Programme | M:N | A scholarship may target multiple programmes (e.g., "all engineering programmes"). A programme may be eligible for multiple scholarships. |
| 14 | Scholarship | targets | Educational Institution | M:N | A scholarship may target specific institutions or be open to all. An institution's students may be eligible for many scholarships. |
| 15 | Information Source | provides information about | *(all entities)* | 1:N (per entity) | Each information source may provide information about many entities. Each entity's information traces to one or more sources (provenance). |
| 16 | Admission Policy | applies to | Admission Cycle | N:1 | Each admission policy applies to exactly one admission cycle. A cycle has many policies (one per programme, plus institutional policies). |
| 17 | Eligibility Policy | applies to | Admission Cycle (or period) | N:1 | Each eligibility policy applies to a specific period/cycle. A cycle/period has many eligibility policies. |
| 18 | Educational Institution | regulated by | Government Education Agency | M:N | An institution is regulated by multiple agencies (e.g., a university is regulated by NUC for accreditation and JAMB for admission standards). An agency regulates many institutions. |

### Cardinality Requiring Nigerian Domain Justification

| Relationship | Cardinality | Nigerian Domain Justification |
|-------------|-------------|------------------------------|
| Institution → Agency | M:N | A university is regulated by NUC (accreditation) and interacts with JAMB (admission). A polytechnic is regulated by NBTE and also interacts with JAMB. The regulatory relationship is genuinely many-to-many. |
| Accreditation Record → Institution/Programme | Can reference either | NUC grants both institutional accreditation (assessing the entire institution) and programme accreditation (assessing specific programmes). An Accreditation Record may reference an Institution (for institutional accreditation) or a Programme (for programme accreditation), but not both simultaneously for the same record. |
| Scholarship → Institution | M:N | Some scholarships are institution-specific (e.g., "PTDF scholarship for oil-producing communities' students at federal universities"). Others are open to all institutions. This is genuinely many-to-many. |
| Scholarship → Programme | M:N | Some scholarships target specific programme categories (e.g., "engineering scholarships", "medical scholarships"). Others are open to all programmes. |

### Open Question on Accreditation Record Scope

> **OQ2-1**: Does an Accreditation Record always reference a Programme, or can it reference an Institution without referencing a specific Programme (for institutional-level accreditation)? In Nigerian practice, NUC grants both institutional accreditation and programme accreditation. These may be different record types or the same type with an optional Programme reference. This is deferred to Product Discovery for structural resolution but does not affect the domain relationship — the cardinality is 1:N from both Institution and Programme perspectives.

### Domain Decision

> **DD2-6**: All major relationships and their cardinalities are defined above. The domain has one composition 1:N (Institution→Programme), one aggregation 1:N (Provider→Scholarship), and multiple association M:N relationships. The M:N relationships (Cycle↔Institution, Cycle↔Programme, Scholarship↔Institution, Scholarship↔Programme, Institution↔Agency) are genuine many-to-many in the Nigerian education system — they are not artifacts of modelling convenience. Accreditation Record can reference either an Institution or a Programme (but not both in the same record), reflecting NUC's dual accreditation practice.

---

## DD2-7: Cross-Aggregate References

### Principle

Aggregate roots reference other aggregate roots. No aggregate root is structurally contained within another aggregate root. Ownership (composition) is expressed through mandatory references and invariants, not through structural nesting.

### Reference Analysis

| Question | Answer | Justification |
|----------|--------|---------------|
| Should Scholarships own Programmes? | **No** | A Scholarship references Programmes it applies to. Programmes exist independently of any Scholarship. If a Scholarship is withdrawn, the Programme continues. The Scholarship does not control the Programme's lifecycle, identity, or invariants. |
| Should Programmes own Scholarships? | **No** | A Programme references available Scholarships. Scholarships exist independently of any Programme. A Scholarship may target many Programmes — no single Programme "owns" a shared Scholarship. |
| Should Accreditation Records own Agencies? | **No** | An Accreditation Record references the granting Agency. The Agency exists independently. The Record cannot exist without referencing an Agency (mandatory reference), but the Agency is not contained within the Record. |
| Should Agencies own Accreditation Records? | **No** | An Agency grants many Records, but does not own them. The Records exist as facts about the agency's regulatory actions. Deleting an Agency does not erase the accreditation history of institutions. |
| Should Information Sources own anything? | **No** | Information Source is a cross-cutting concern. It is referenced by other entities for provenance. It does not own any entity. An Information Source provides information about many entities — it cannot own them all. |
| Should Admission Cycles own Programmes? | **No** | A Cycle involves many Programmes, but Programmes exist across many Cycles. The Cycle does not control the Programme's lifecycle. |
| Should Admission Policies own Qualifications? | **No** | An Admission Policy references Qualifications as part of its rules. Qualifications exist independently. Multiple policies reference the same Qualification. |
| Should Institutions own Accreditation Records? | **No** | An Institution is the subject of accreditation, not the owner of the records. Only the granting Agency creates accreditation records. The Institution cannot self-accredit. |

### Reference Direction Rules

| From | To | Direction | Mandatory? | Justification |
|------|----|-----------|:----------:|---------------|
| Programme | Institution | Upward (child → parent) | **Yes** | Composition — Programme cannot exist without Institution. |
| Admission Policy | Programme or Institution | Upward (child → parent) | **Yes** | Composition — Policy cannot exist without governed entity. |
| Eligibility Policy | Scholarship | Upward (child → parent) | **Yes** | Composition — Policy cannot exist without Scholarship. |
| Scholarship | Scholarship Provider | Upward (to provider) | **Yes** | Each Scholarship has exactly one Provider. |
| Accreditation Record | Government Education Agency | Lateral (to grantor) | **Yes** | Each Record is granted by exactly one Agency. |
| Accreditation Record | Institution or Programme | Lateral (to subject) | **Yes** | Each Record accredits exactly one entity. |
| Admission Policy | Admission Cycle | Lateral (to cycle) | **Yes** | Each Policy applies to exactly one Cycle. |
| Admission Cycle | Institution | Lateral (participants) | No | A Cycle involves many Institutions; references are associative. |
| Scholarship | Programme | Lateral (targets) | No | A Scholarship may target Programmes; references are associative. |
| Scholarship | Institution | Lateral (targets) | No | A Scholarship may target Institutions; references are associative. |
| *(any entity)* | Information Source | Downward/lateral (provenance) | Varies | Provenance reference — required for verified information, optional for community-contributed (per A3-7). |

### Domain Decision

> **DD2-7**: Cross-aggregate references follow three patterns. **Upward references** (child → parent in composition) are mandatory and represent existential dependency. **Lateral references** between independent aggregates are optional or mandatory depending on the business rule. **Provenance references** (any entity → Information Source) are cross-cutting and required for verified information per A4-5. No aggregate root owns another aggregate root. Ownership is expressed through mandatory references and invariants, not structural nesting.

---

## DD2-8: Shared Concepts

### Evaluation

| Proposed Abstraction | Would Abstract | Verdict | Rationale |
|---------------------|---------------|--------|-----------|
| **Educational Opportunity** | Institution, Programme, Scholarship | **Rejected** | These entities share the pattern of being "discoverable and comparable" (users explore, evaluate, and compare them in WF1-WF3), but they are fundamentally different domain concepts with different identities, lifecycles, invariants, and relationships. An Institution is an organization that offers programmes. A Programme is a course of study. A Scholarship is funding. "Educational Opportunity" is a useful *search and presentation concept* (Product Decision) — it enables unified discovery results and comparison views — but it is not a domain entity with its own identity and invariants. In the Nigerian education domain, people distinguish clearly between "schools", "courses", and "scholarships". No domain rule operates uniformly across all three. |
| **Educational Authority** | Government Education Agency, Scholarship Provider | **Rejected** | These entities have fundamentally different roles. A Government Education Agency is a regulatory/examination body established by legislation (JAMB, NUC, WAEC). A Scholarship Provider is a funding organization (corporate, NGO, government department). They have different relationships (Agency grants Accreditation Records; Provider offers Scholarships), different lifecycles, different invariants, and different domain rules. They share no invariant that applies to both. The only shared pattern is "an organization" — which is too abstract to be domain-relevant. |
| **Policy** | Admission Policy, Eligibility Policy | **Rejected (for now)** | Both policy types share a structural pattern (rules, lifecycle of draft→published→active→superseded→retired). However, they govern different domain concerns (admission vs. scholarship eligibility), belong to different parent entities (Programme/Institution vs. Scholarship), and enforce different invariants. "Policy" as a domain abstraction would exist only to share a lifecycle pattern — that is a software convenience, not a domain justification. **Defer**: If additional policy types emerge during later discovery (e.g., Fee Policy, Progression Policy, Graduation Policy), and they share invariants beyond lifecycle, re-evaluate. |
| **Educational Offering** | Programme, Scholarship | **Rejected** | This is weaker than Educational Opportunity. Programme and Scholarship are both "offered" to students but have no shared identity, invariant, or domain rule. The concept does not exist in Nigerian education discourse. |

### Decision on Government Education Agency Naming

Topic 1 left open whether to rename "Government Education Agency" to "Education Authority". Analysis:

- All Nigerian education bodies in scope are government agencies (JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies).
- "Government Education Agency" is the canonical glossary term (A2-1, A2-8).
- "Education Authority" would be broader but less precise — it could include non-government entities.
- No non-government education authority has been identified in the domain.
- The current name is more precise and already canonical.

> **Decision**: Retain "Government Education Agency". No justification for renaming has emerged. The current name is precise and canonical.

### Domain Decision

> **DD2-8**: All four proposed abstractions (Educational Opportunity, Educational Authority, Policy, Educational Offering) are rejected as domain entities. They exist as patterns across entities, not as entities with their own identity, invariants, or domain rules. Educational Opportunity is a Product Decision (unified search/discovery). Policy may be re-evaluated if additional policy types emerge. "Government Education Agency" is retained as the precise, canonical name.

---

## DD2-9: Domain Invariants

### Invariants Derived from the Nigerian Education System

| ID | Invariant | Domain Source | Verification |
|----|-----------|---------------|-------------|
| INV-1 | A Programme belongs to exactly one Institution. | No programme exists unaffiliated in the Nigerian education system. Every programme is offered by a specific institution. | Structural — enforced by Programme's mandatory Institution reference. |
| INV-2 | An Accreditation Record is granted by exactly one Government Education Agency. | In Nigeria, accreditation is granted by a single regulatory body: NUC for universities, NBTE for polytechnics/IEIs, NCCE for colleges of education. No record is jointly granted. | Structural — enforced by Accreditation Record's mandatory Agency reference. |
| INV-3 | The granting agency for an Accreditation Record is determined by the accredited Institution's type. | NUC accredits universities. NBTE accredits polytechnics and IEIs. NCCE accredits colleges of education. This is a regulatory rule, not a choice. | Business rule — NUC does not accredit polytechnic programmes; NBTE does not accredit university programmes. |
| INV-4 | A Scholarship has exactly one Provider. | Every scholarship is offered by a specific organization. No scholarship is self-originating. | Structural — enforced by Scholarship's mandatory Provider reference. |
| INV-5 | An Admission Policy belongs to exactly one Programme or one Institution (never neither, never both). | Admission requirements are always for a specific entity — either institutional-level or programme-level. They cannot be unattached. They cannot simultaneously be both institutional and programme-level. | Structural — enforced by Admission Policy's mandatory parent reference (exactly one of Programme or Institution). |
| INV-6 | An Eligibility Policy belongs to exactly one Scholarship. | Eligibility criteria are always for a specific scholarship. They cannot be unattached. | Structural — enforced by Eligibility Policy's mandatory Scholarship reference. |
| INV-7 | An Admission Cycle is time-bounded — it has a defined start and end. | Every admission cycle in Nigeria has defined periods (JAMB announces registration dates, exam dates, result dates). No cycle is open-ended. | Business rule — enforced by Admission Cycle's temporal bounds. |
| INV-8 | A Programme's current admission status is determined by both the Programme's lifecycle state and the current Admission Cycle state. | A programme that is "admitting" in its lifecycle may not be admitting if the admission cycle is "closed". A programme that is "suspended" is not admitting regardless of the cycle. | Business rule — admission is the conjunction of programme state and cycle state. |
| INV-9 | A Qualification is recognized by at least one authority in the Nigerian education system. | StudyNexus records qualifications that are recognized in Nigeria. Unrecognized qualifications are outside scope (per A4-4, A4-6 — Nigeria first). | Business rule — scope constraint. |
| INV-10 | An Accreditation Record's subject (Institution or Programme) must be of the appropriate type for the granting Agency. | NUC accredits universities and their programmes. NBTE accredits polytechnics/IEIs and their programmes. NCCE accredits colleges of education and their programmes. Cross-accreditation does not occur. | Business rule — regulatory structure of Nigerian education. |

### Invariants Specific to StudyNexus's Domain Model

| ID | Invariant | Model Source | Verification |
|----|-----------|-------------|-------------|
| INV-11 | Every piece of verified information traces to at least one Information Source. | A4-5 (provenance), A5-7 (linking to authoritative sources), capability "Preserve Information Provenance". | Structural — verified information requires provenance reference. |
| INV-12 | An Admission Policy applies to exactly one Admission Cycle. | Time-bounded by definition (DD2-5). A policy for the 2023/2024 cycle is distinct from the 2024/2025 policy. | Structural — enforced by Admission Policy's mandatory Cycle reference. |
| INV-13 | An Eligibility Policy applies to exactly one time period (typically an Admission Cycle or scholarship year). | Time-bounded by definition (DD2-5). | Structural — enforced by Eligibility Policy's mandatory period reference. |

### Invariants Rejected as Not True in the Nigerian Domain

| Proposed Invariant | Why Rejected |
|-------------------|-------------|
| "A Programme has exactly one Accreditation Record." | False — a Programme has many accreditation records over time (grant, renewals, possible suspensions). Current status is derived from the most recent record. |
| "An Institution has exactly one Accreditation Record." | Same — many records over time. |
| "A Programme has exactly one Admission Policy." | False — one per admission cycle. Many over time. |
| "A Scholarship is always for a specific Institution." | False — some scholarships are open to all institutions (e.g., federal government scholarships). |
| "A Scholarship is always for a specific Programme." | False — some scholarships are open to all programmes or broad categories. |
| "An Admission Cycle belongs to exactly one Institution." | False — the JAMB UTME cycle is national, spanning all institutions. Institutional cycles are scoped to an institution but exist within the national cycle. |
| "Qualification identity is institution-scoped." | False — qualifications are national concepts. "WAEC SSCE" is the same regardless of institution. |

### Domain Decision

> **DD2-9**: The domain has 13 invariants. 10 are derived from the Nigerian education system (INV-1 through INV-10). 3 are specific to StudyNexus's domain model (INV-11 through INV-13). The most significant invariants are: Programme always belongs to one Institution (INV-1), accreditation agency is determined by institution type (INV-3), admission status is the conjunction of programme state and cycle state (INV-8), and verified information always traces to a source (INV-11). Seven proposed invariants were rejected as not true in the Nigerian education domain.

---

## DD2-10: Aggregate Interaction

### How Aggregates Influence Each Other (Business Perspective)

| # | Source Aggregate | Influences | Target Aggregate | Mechanism | Business Description |
|---|-----------------|-----------|-----------------|-----------|---------------------|
| 1 | Educational Institution | constrains | Programme | Ownership invariant | If an Institution closes or is suspended, its Programmes cease admitting. An Institution's regulatory type (university, polytechnic, college) determines which Agency can accredit its Programmes (INV-3). An Institution's general admission requirements (institutional Admission Policy) set the baseline that Programme-level policies build upon. |
| 2 | Programme | constrains | Admission Policy | Ownership invariant | A Programme's lifecycle state (suspended, discontinued) determines whether its Admission Policy is relevant. A discontinued programme's admission policy is retired. |
| 3 | Admission Cycle | enables/constrains | Admission Policy | Temporal scoping | An Admission Cycle's state determines whether an Admission Policy is active. A policy for an upcoming cycle is "published" but not yet "active" — it becomes active when the cycle opens. A policy becomes "superseded" when the cycle closes. |
| 4 | Admission Cycle | enables | Programme | Temporal context | An Admission Cycle determines whether a Programme is currently admitting. The same Programme is "admitting" in one cycle and not in another. Users evaluate a Programme within the context of a specific cycle. |
| 5 | Accreditation Record | affects | Programme (and Institution) | Trust signal | A Programme's accreditation status (derived from its most recent Accreditation Record) is a trust signal (WF5). A suspended or revoked accreditation affects whether users should consider the Programme. An institution's overall accreditation status affects trust in all its Programmes. |
| 6 | Government Education Agency | governs | Accreditation Record | Regulatory authority | Only the granting Agency can change an Accreditation Record's status (renew, suspend, revoke). No other entity can alter accreditation status. |
| 7 | Government Education Agency | constrains | Institution | Regulatory framework | An Agency's regulations determine what an Institution must demonstrate for accreditation. The Agency's policies set the standards that Programmes must meet. |
| 8 | Scholarship Provider | enables | Scholarship | Administrative authority | A Provider announces, opens, closes, and may withdraw a Scholarship. The Provider's operational status affects whether the Scholarship is currently available. |
| 9 | Scholarship | constrains | Eligibility Policy | Ownership invariant | A Scholarship's lifecycle state determines whether its Eligibility Policy is relevant. A withdrawn or expired scholarship's eligibility policy is retired. |
| 10 | Scholarship | targets | Programme / Institution | Applicability | A Scholarship's applicability is determined by which Programmes and Institutions it targets. This affects whether the Scholarship appears in search results for a given Programme or Institution. |
| 11 | Eligibility Policy | gates | Scholarship | Selection criteria | An Eligibility Policy determines whether a user qualifies for a Scholarship. The policy's rules are the criteria against which a user's qualifications are assessed (WF4). |
| 12 | Admission Policy | gates | Programme | Selection criteria | An Admission Policy determines whether a user qualifies for a Programme's admission. The policy's rules are the criteria against which a user's qualifications are assessed (WF4). |
| 13 | Qualification | enables | Admission Policy / Eligibility Policy | Requirement language | Qualifications are the vocabulary of admission and eligibility policies. A policy's rules are expressed in terms of Qualifications (e.g., "requires WAEC SSCE with 5 credits including Mathematics and English"). |
| 14 | Information Source | supports | *(all entities)* | Provenance | Every entity's information traces to an Information Source. The Source's reliability affects the trustworthiness of the information it supports. An unreliable source degrades trust in all information it provides (WF5). |

### Interaction Patterns

**Pattern 1: Ownership Constraint**
Parent entity's lifecycle constrains child entity's relevance.
- Institution closing → Programmes cease admission
- Programme discontinuation → Admission Policy retired
- Scholarship withdrawal → Eligibility Policy retired
- Provider dissolution → Scholarships become historical

**Pattern 2: Temporal Enablement**
A time-bounded entity enables or constrains another entity's current state.
- Admission Cycle state → whether Programme is currently admitting
- Admission Cycle state → whether Admission Policy is currently active
- Scholarship deadline → whether applications are open

**Pattern 3: Regulatory Authority**
An authority entity controls the status of another entity's records.
- Agency grants, renews, suspends, revokes Accreditation Records
- Agency determines which Institution types it can accredit

**Pattern 4: Trust Propagation**
An entity's status affects the trustworthiness of related entities.
- Accreditation status → trust signal for Programme and Institution
- Information Source reliability → trust signal for all information from that source

**Pattern 5: Policy Gating**
A policy entity determines eligibility/qualification for another entity.
- Admission Policy → whether a user qualifies for a Programme
- Eligibility Policy → whether a user qualifies for a Scholarship

**Pattern 6: Applicability**
An entity targets or applies to other entities, affecting discoverability.
- Scholarship targets Programmes/Institutions → appears in relevant search results
- Admission Cycle involves Institutions/Programmes → structures temporal access

### Domain Decision

> **DD2-10**: Aggregates interact through six business patterns: ownership constraint (parent lifecycle constrains child relevance), temporal enablement (cycles enable/constrain current state), regulatory authority (agencies control accreditation status), trust propagation (accreditation and source reliability affect trust signals), policy gating (policies determine eligibility), and applicability (targeting affects discoverability). No aggregate directly modifies another aggregate's state — influence flows through business rules, lifecycle constraints, and reference-based trust signals. These interactions are business concepts, not software events.

---

## Relationship Diagrams

### Ownership and Composition (Textual Diagram)

```
┌─────────────────────────────────────────────────────────┐
│                    COMPOSITION                           │
│                                                          │
│  Educational Institution ──◆ Programme                   │
│       │                                                  │
│       └──◆ Admission Policy (institutional-level)        │
│                                                          │
│  Programme ──◆ Admission Policy (programme-level)        │
│                                                          │
│  Scholarship ──◆ Eligibility Policy                      │
│                                                          │
│  ──◆ = composition (child cannot exist without parent)    │
└─────────────────────────────────────────────────────────┘
```

### Aggregation (Textual Diagram)

```
┌─────────────────────────────────────────────────────────┐
│                    AGGREGATION                           │
│                                                          │
│  Scholarship Provider ──◇ Scholarship                    │
│                                                          │
│  ──◇ = aggregation (child exists independently)          │
└─────────────────────────────────────────────────────────┘
```

### All Relationships (Textual Diagram)

```
                         Government Education Agency
                         ┌──────────┬──────────┐
                    defines│     grants│    regulates│
                         ▼          ▼            ▼
                   Qualification  Accreditation  Educational
                                  Record     Institution
                    ┌───────────────┐      ┌──────┤
                    │subject of      │      │offers│
                    └───────┬───────┘      ▼      │
                            │          Programme   │
                    ┌───────┴───────┐   ┌──────┤  │
                    │(also subject  │   │governed│  │
                    │ of Programme) │   │  by    │  │
                    └──────────────┘   ▼      │  │
                                      Admission │  │
                                       Policy   │  │
                                         │      │  │
                                    applies to  │  │
                                         ▼      │  │
                                    Admission ◄─┘  │
                                      Cycle         │
                                    ┌──────┐        │
                                    │involves       │
                                    └──────┘        │
                                                     │
  Scholarship Provider                               │
  ┌──────────┐                                      │
  │  offers  │                                      │
  └────┬─────┘                                      │
       ▼                                            │
  Scholarship ──────────────────targets──────────────┘
  ┌──────┤
  │governed│
  │  by    │
  ▼       │
  Eligibility   targets
  Policy      Programme

  Information Source ◄── (provenance reference from all entities)
```

---

## Aggregate Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                        AGGREGATE ROOTS                                │
│                                                                       │
│  ┌─────────────────────┐    ┌─────────────────────┐                  │
│  │ Educational         │    │ Programme           │                  │
│  │ Institution         │    │  [mandatory ref to  │                  │
│  │                     │    │   Institution]      │                  │
│  └─────────────────────┘    └─────────────────────┘                  │
│                                                                       │
│  ┌─────────────────────┐    ┌─────────────────────┐                  │
│  │ Scholarship         │    │ Qualification       │                  │
│  │  [mandatory ref to  │    │                     │                  │
│  │   Provider]         │    └─────────────────────┘                  │
│  └─────────────────────┘                                              │
│                                                                       │
│  ┌─────────────────────┐    ┌─────────────────────┐                  │
│  │ Admission Cycle     │    │ Accreditation       │                  │
│  │                     │    │ Record              │                  │
│  └─────────────────────┘    │  [mandatory ref to │                  │
│                              │   Agency + Entity] │                  │
│  ┌─────────────────────┐    └─────────────────────┘                  │
│  │ Scholarship Provider│                                              │
│  └─────────────────────┘    ┌─────────────────────┐                  │
│                              │ Government Education│                  │
│  ┌─────────────────────┐    │ Agency              │                  │
│  │ Information Source  │    └─────────────────────┘                  │
│  └─────────────────────┘                                              │
│                                                                       │
│  ┌─────────────────────┐    ┌─────────────────────┐                  │
│  │ Admission Policy    │    │ Eligibility Policy  │                  │
│  │  [mandatory ref to  │    │  [mandatory ref to  │                  │
│  │   Programme/Inst +  │    │   Scholarship +     │                  │
│  │   Cycle]            │    │   Period]           │                  │
│  └─────────────────────┘    └─────────────────────┘                  │
│                                                                       │
│  All entities are aggregate roots.                                    │
│  Mandatory references enforce composition invariants.                  │
│  No structural nesting.                                               │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Lifecycle Diagrams

### Primary Entity Lifecycles

```
Educational Institution          Programme
═════════════════════           ═════════

established ──→ operational      introduced ──→ admitting
     │              │                │              │
     │          merged              │           suspended
     │              │                │              │
     │         (continues)           │           resumed
     │              │                │              │
     │          renamed              │              ↓
     │              │                │          admitting
     ↓              ↓                ↓
  suspended ──→ closed           discontinued


Scholarship                      Admission Cycle
═══════════                     ═══════════════

announced ──→ open ──→ closed   upcoming ──→ registration_open
     │          │                │              │
     │      withdrawn            │              ↓
     │          │                │     examination_period
     ↓          ↓                │              │
  (expired)  (withdrawn)         │              ↓
                                │     results_released
                                │              │
                                │              ↓
                                │     admission_period
                                │              │
                                ↓              ↓
                               closed ──→ archived
```

### Policy Lifecycles

```
Admission Policy / Eligibility Policy
═════════════════════════════════════

draft ──→ published ──→ active ──→ superseded ──→ retired
```

### Accreditation Record Lifecycle

```
Accreditation Record
════════════════════

     granted ──→ renewed ──→ expired
       │           │
       ↓           ↓
    interim     partial
       │           │
       ↓           ↓
    suspended   suspended
       │
       ↓
     revoked
```

---

## Identity Rules Summary

| Entity | Identity Components | Scope | Stability |
|--------|-------------------|-------|-----------|
| Educational Institution | Continuing entity (current official name + type + registration) | National | Evolving |
| Programme | Name + Institution + award level | Institution-scoped | Mostly stable |
| Scholarship | Name + Provider + period | Provider-scoped | Mostly stable |
| Qualification | Name + awarding body | National | Stable |
| Admission Cycle | Period + scope level | Temporal | Stable |
| Accreditation Record | Subject entity + Agency + effective date | Entity+Agency-scoped | Stable |
| Scholarship Provider | Continuing entity (current official name) | National | Evolving |
| Government Education Agency | Official abbreviation | National | Stable |
| Information Source | Logical source identity (not URL) | Source-scoped | Mostly stable |
| Admission Policy | Governed entity + Admission Cycle | Entity+Cycle-scoped | Stable |
| Eligibility Policy | Scholarship + period | Scholarship+Period-scoped | Stable |

---

## Cardinality Tables

### Core Relationships

| From | To | Type | Cardinality | Mandatory? |
|------|----|------|:-----------:|:----------:|
| Institution | Programme | Composition | 1:N | Child requires parent |
| Institution | Admission Policy | Composition | 1:N | Child requires parent |
| Programme | Admission Policy | Composition | 1:N | Child requires parent |
| Scholarship | Eligibility Policy | Composition | 1:N | Child requires parent |
| Scholarship Provider | Scholarship | Aggregation | 1:N | Child requires parent |
| Agency | Accreditation Record | Association | 1:N | Record requires Agency |
| Institution | Accreditation Record | Association | 1:N | — |
| Programme | Accreditation Record | Association | 1:N | — |

### Cross-Entity Relationships

| From | To | Type | Cardinality | Mandatory? |
|------|----|------|:-----------:|:----------:|
| Admission Cycle | Institution | Association | M:N | No |
| Admission Cycle | Programme | Association | M:N | No |
| Admission Policy | Admission Cycle | Association | N:1 | Yes |
| Eligibility Policy | Cycle/Period | Association | N:1 | Yes |
| Scholarship | Programme | Association | M:N | No |
| Scholarship | Institution | Association | M:N | No |
| Programme | Qualification | Association | M:N | No |
| Agency | Qualification | Association | 1:N | No |
| Institution | Agency | Association | M:N | No |

### Provenance

| From | To | Type | Cardinality |
|------|----|------|:-----------:|
| Any entity | Information Source | Association | M:N |

---

## Assumptions

| ID | Assumption | Rationale | Risk | Resolution |
|----|-----------|-----------|------|-----------|
| A2-1 | An Admission Policy always applies to exactly one Admission Cycle. | Policies are time-bounded by definition. A policy that spans multiple cycles would be two policies. | Low — this is consistent with Nigerian practice where admission requirements may change each year. | If evidence emerges of policies spanning multiple cycles, re-evaluate. |
| A2-2 | Accreditation Record can reference either an Institution or a Programme, but not both simultaneously. | NUC grants institutional and programme accreditation as separate events. | Medium — some accreditation may evaluate both simultaneously. | OQ2-1 — resolve during detailed domain modelling. |
| A2-3 | A Scholarship always has exactly one Provider. | Every scholarship is offered by a specific organization. | Low — co-sponsored scholarships exist but have a primary administrator. | Verify with Nigerian scholarship data. |
| A2-4 | Admission Cycle is the primary temporal organizing concept for the domain. | The Nigerian admission system revolves around JAMB's annual cycle. | Low — this is clearly observable. | If institution-specific cycles become dominant, re-evaluate. |
| A2-5 | Programme's admission status is determined by Programme lifecycle + Admission Cycle state. | A programme only admits when it is in "admitting" state AND the cycle is in "admission period" state. | Low — this is consistent with observed practice. | If programmes can admit outside of cycles, re-evaluate. |
| A2-6 | Information Source is an aggregate root, not a value object within other entities. | Sources are independently verified, assessed for reliability, and referenced by multiple entities. | Low — provenance is a core capability (A5-7). | If sources are always entity-specific, could become a value object. |

---

## Open Questions

| ID | Topic | Question | Status | Assigned To |
|----|-------|----------|--------|-------------|
| OQ2-1 | Accreditation Scope | Does an Accreditation Record always reference a Programme, or can it reference an Institution without a Programme (for institutional-level accreditation)? | Active | Domain Discovery (Topic 3 or Product Discovery) |
| OQ2-2 | Admission Cycle Scope | Should Admission Cycle be modelled as a single entity with scope (national/institutional/programme), or as separate entity types (JAMB Cycle, Institutional Admission Period)? | Active | Domain Discovery (Topic 3) |
| OQ2-3 | Institutional Admission Policy | When an Institution has both institutional-level and programme-level admission requirements, are these two separate Admission Policy entities (one parented by Institution, one by Programme), or a single policy with a hierarchical rule structure? | Active | Domain Discovery (Topic 3) |
| OQ2-4 | Scholarship-Programme Targeting | When a Scholarship targets "all engineering programmes", is this a direct M:N reference to specific Programme entities, or a rule-based eligibility criterion within the Eligibility Policy? | Active | Domain Discovery (Topic 3) |
| OQ2-5 | Faculty/Department | Should Faculty/Department be introduced as a domain entity between Institution and Programme? This affects the ownership hierarchy (Institution → Faculty → Department → Programme) and may affect how admission policies and accreditation are scoped. | Active | Domain Discovery (later topic) |
| OQ2-6 | Admission Cycle Phases | Are the lifecycle phases for Admission Cycle (registration_open, examination_period, results_released, admission_period, closed) correct for all cycle types? Institutional cycles may have different phases than the national JAMB cycle. | Active | Domain Discovery (Topic 3) |
| OQ2-7 | Qualification Hierarchy | Do qualifications form a hierarchy (e.g., BSc requires NCE/ND which requires WAEC SSCE)? If so, is this hierarchy part of the domain model, or is it captured within Admission/Eligibility Policy rules? | Active | Domain Discovery (Topic 3) |
| OQ2-8 | Cross-Agency Accreditation | Can a Programme be accredited by more than one agency simultaneously (e.g., a professional body in addition to NUC)? If so, how does this affect INV-2 and INV-10? | Active | Domain Discovery (Topic 3) |

---

## Traceability to Business Discovery

| Domain Decision | Traces To | Business Decision/Concept |
|----------------|-----------|--------------------------|
| DD2-1 (All entities are aggregate roots) | A0-3, A5-4 | Core interaction (search, discover, compare) requires independent entity access; capability relationships show entities are accessed independently |
| DD2-1 (Programme is aggregate root with mandatory parent) | A1-1, A3-3 | Programme is a primary search/discovery target; discoverability requires independent access |
| DD2-2 (Institution→Programme composition) | A1-5, A2-8 | Nigerian education system: every programme belongs to an institution; JAMB processes are institution-scoped |
| DD2-2 (Provider→Scholarship aggregation) | A2-4 | Scholarship Providers are potential future primary users; scholarships outlive provider dissolution |
| DD2-2 (Agency↔Accreditation association) | A2-5, A2-8 | Agencies are strategic partners (data providers), not owners of accreditation facts |
| DD2-3 (Programme identity is institution-scoped) | A1-5 | JAMB processes use institution+programme as the identification unit |
| DD2-3 (Policy identity is time-scoped) | A4-2, A5-1 | Maintain capability requires temporal tracking; admission requirements change per cycle |
| DD2-4 (Lifecycle states) | A5-1 (Maintain), A5-7 | Maintain capability keeps information current; lifecycle states are the basis for currency assessment |
| DD2-5 (Admission Cycle as temporal axis) | A3-3, A3-6 | Discoverability is cycle-aware; structured exploration is cycle-scoped |
| DD2-5 (Historical versions are domain knowledge) | A3-4, A5-4 | Comparison capability requires cross-cycle comparison; "what were requirements last year?" is a domain query |
| DD2-6 (M:N relationships) | A0-3, A3-3 | Core interaction involves comparing and discovering across entities; M:N relationships enable these interactions |
| DD2-7 (Cross-aggregate references) | A4-5, A5-7 | Provenance requires cross-entity references; linking to authoritative sources is a cross-cutting concern |
| DD2-8 (Rejected abstractions) | A6-2, A6-3 | Workflows defined by business goals; shared patterns across workflows don't imply shared entities |
| DD2-9 (INV-3: Agency determined by institution type) | A2-8 | NUC, NBTE, NCCE each regulate a specific institution type |
| DD2-9 (INV-8: Admission = Programme state ∧ Cycle state) | A1-5, A5-1 | JAMB admission process is cycle-driven; programme admission is cycle-dependent |
| DD2-9 (INV-11: Verified info traces to source) | A4-5, A5-7 | Provenance preservation is a supporting capability; linking to authoritative sources is a decision |
| DD2-10 (Interaction patterns) | A5-3, A5-4 | Capability relationships describe dependencies; aggregate interaction mirrors capability interaction at the entity level |

---

## Classification Table

| Concept | Classification | Justification |
|---------|---------------|---------------|
| Educational Institution | **Domain Concept** | Core entity in the Nigerian education system. Has identity, lifecycle, and invariants independent of StudyNexus. |
| Programme | **Domain Concept** | Core entity. A programme of study at an institution. Has identity, lifecycle, and invariants independent of StudyNexus. |
| Scholarship | **Domain Concept** | Core entity. Financial award for education. Has identity and lifecycle independent of StudyNexus. |
| Qualification | **Domain Concept** | Reference entity in the Nigerian education system. Defined by examining/awarding bodies. Exists independently of StudyNexus. |
| Admission Cycle | **Domain Concept** | Time-bounded process in the Nigerian admission system. JAMB defines national cycles; institutions define institutional cycles. Exists independently of StudyNexus. |
| Accreditation Record | **Domain Concept** | A fact about accreditation granted by a regulatory body. Exists as a record of a real-world event, independent of StudyNexus. |
| Scholarship Provider | **Domain Concept** | Real-world organization that offers scholarships. Has identity and lifecycle independent of StudyNexus. |
| Government Education Agency | **Domain Concept** | Real-world regulatory/examination body (JAMB, NUC, etc.). Has identity independent of StudyNexus. |
| Information Source | **Domain Concept** | A real-world source of information (website, document, agency publication). Exists independently of StudyNexus. |
| Admission Policy | **Domain Concept** | The published admission requirements for a programme or institution for a specific cycle. Exists in the real world (on institution websites, in JAMB brochures) independent of StudyNexus. |
| Eligibility Policy | **Domain Concept** | The published eligibility criteria for a scholarship for a specific period. Exists in the real world independent of StudyNexus. |
| Educational Opportunity | **Product Decision** | A useful abstraction for unified search/discovery UI, but not a domain entity with its own identity or invariants. |
| Educational Authority | **Product Decision** | Would abstract Agency and Provider for UI convenience, but no domain rule applies to both. |
| Policy (shared abstraction) | **Product Decision** (deferred) | Shares lifecycle pattern across Admission and Eligibility policies, but no shared invariant. May become domain concept if more policy types emerge. |
| Educational Offering | **Product Decision** | Would abstract Programme and Scholarship for presentation convenience. No domain justification. |
| Composition (ownership type) | **Domain Concept** | Reflects existential dependency in the Nigerian education system (e.g., Programme cannot exist without Institution). |
| Aggregation (ownership type) | **Domain Concept** | Reflects administrative but not existential dependency (e.g., Scholarship Provider → Scholarship). |
| Aggregate Root | **Technical Decision** | A DDD pattern for defining transactional and access boundaries. The decision about which entities are aggregate roots is informed by domain access patterns but the concept itself is technical. |
| Mandatory Reference | **Technical Decision** | Implementation mechanism for enforcing composition invariants across aggregate boundaries. The *business rule* (Programme requires Institution) is a Domain Concept; the *mechanism* (mandatory reference) is technical. |
| Lifecycle State | **Domain Concept** | The states and transitions of each entity reflect real-world business events in the Nigerian education system. |
| Temporal Axis | **Domain Concept** | Admission Cycle as the temporal organizing principle reflects the structure of the Nigerian admission system. |

---

## Topic 1 Challenges

### Challenge 1: Admission Policy Dual Parenting

**Issue**: Topic 1 established Admission Policy as a policy entity, but the ownership analysis reveals that Admission Policy may be parented by either a Programme or an Institution (for institutional-level requirements). This is dual parenting — an entity that can be compositionally owned by one of two different entity types.

**Assessment**: This is not a contradiction with Topic 1 — Topic 1 identified Admission Policy as a domain entity without specifying its ownership. The dual parenting is a discovery of this topic.

**Resolution**: Admission Policy has exactly one parent: either a Programme or an Institution (never both, never neither). This is captured in INV-5 and does not require a Change Proposal. Open question OQ2-3 addresses whether institutional and programme-level policies should be separate entity types.

### Challenge 2: Admission Cycle's Central Role

**Issue**: Topic 1 introduced Admission Cycle as a first-class entity, but this topic reveals that Admission Cycle is not just "an entity" — it is the primary temporal axis of the domain. Most time-bounded entities are scoped to admission cycles. This elevates its importance beyond what Topic 1 may have intended.

**Assessment**: This is a deeper understanding, not a contradiction. Topic 1 correctly identified Admission Cycle as a first-class entity. This topic reveals its structural significance.

**Resolution**: No Change Proposal needed. The elevated role of Admission Cycle is a domain discovery, not a revision. It should inform subsequent topics (especially domain events and business rules).

### Challenge 3: Accreditation Record Dual Subject

**Issue**: Accreditation Record can be the subject of either an Institution (institutional accreditation) or a Programme (programme accreditation). This is structurally similar to Admission Policy's dual parenting but semantically different — Accreditation Record is not "owned" by its subject; the subject is what the record is about.

**Assessment**: This is consistent with Nigerian practice (NUC grants both institutional and programme accreditation). The record references its subject; it is not compositionally owned by it.

**Resolution**: Captured in OQ2-1. No Change Proposal needed — the association relationship (not composition) already accommodates this.

---

## Summary

Topic 2 has determined the complete relationship structure of the StudyNexus domain:

1. **All eleven entities are aggregate roots**, with composition enforced through mandatory references rather than structural nesting. This reflects the domain's access patterns (entities are independently searched, discovered, and compared) while respecting ownership invariants (Programme cannot exist without Institution).

2. **Three composition relationships** establish existential dependencies: Institution→Programme, Programme/Institution→Admission Policy, Scholarship→Eligibility Policy. One aggregation relationship (Provider→Scholarship) reflects administrative but not existential dependency. All other relationships are associations.

3. **Identity is scoped**: Programme identity is institution-scoped, policy identities are time-scoped (to cycles/periods), accreditation records are entity+agency-scoped. Five entities have stable identity; two have evolving identity requiring continuing-entity semantics.

4. **Lifecycles are business events**: State transitions for the primary entities are meaningful in the educational landscape, not merely administrative state changes. Programme admission state is the conjunction of programme lifecycle state and admission cycle state.

5. **Admission Cycle is the temporal axis**: Most time-bounded entities are scoped to admission cycles. This makes Admission Cycle a central organizing concept. Time-bounded entities are distinct instances per period (not versions of the same entity).

6. **Four shared concept abstractions were rejected**: Educational Opportunity, Educational Authority, Policy, and Educational Offering are product decisions, not domain entities. They share patterns but not invariants.

7. **Thirteen domain invariants** have been identified — ten from the Nigerian education system and three from StudyNexus's model. Seven proposed invariants were rejected as not true in the Nigerian domain.

8. **Six interaction patterns** describe how aggregates influence each other: ownership constraint, temporal enablement, regulatory authority, trust propagation, policy gating, and applicability.

9. **Eight open questions** have been raised for resolution in later topics, primarily around the structural details of dual-parenting (Admission Policy), cycle scoping, and the role of Faculty/Department.

10. **No contradictions with Topic 1** have been discovered. Three challenges were identified and resolved — all are deeper understandings, not revisions.

---

**Approval Required**: This document requires explicit approval before proceeding to Topic 3. Specifically awaiting approval of:
- DD2-1 through DD2-10 (all domain decisions)
- Assumptions A2-1 through A2-6
- Open Questions OQ2-1 through OQ2-8
- Rejection of all four shared concept abstractions
- Retention of "Government Education Agency" naming
- Topic 1 challenge resolutions
