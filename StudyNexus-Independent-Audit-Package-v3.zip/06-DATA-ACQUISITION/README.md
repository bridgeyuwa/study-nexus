# 06-DATA-ACQUISITION — Data Acquisition Research

## Authority: Supplementary to Canonical

The authoritative data acquisition specification is in 01-CANONICAL/06-data-acquisition.md.
This section contains any additional research or context beyond the canonical document.

## Current Contents

No additional data acquisition research documents were discovered in the project
workspace beyond the canonical specification. The canonical document covers:

- Source taxonomy (JAMB, IBASS, NUC, NBTE, NCCE, institutional websites)
- Ingestion architecture (SOURCE → OBSERVATION → RECONCILIATION → ASSERTION)
- Verification and provenance
- Source trust hierarchy
- Import staging

## Additional Context Available in Governance

The governance documents in 04-GOVERNANCE/ contain important context about:
- Provenance model decisions (ND-4: hybrid provenance)
- External identifier model (BD-5: generic external_identifiers)
- InformationSource semantics (ND-5: no institution_id, nullable authority_id)
- Source-reference ON DELETE semantics
