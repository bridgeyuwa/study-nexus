# 01-CANONICAL — Current Canonical Authority

## Authority: TIER 1 — HIGHEST

These six documents are the **frozen V2 canonical architecture** for StudyNexus.

They are the single authoritative reference for implementation. Where any other document
in this package conflicts with these canonical documents, the canonical documents prevail.

## Why These Are Authoritative

These documents were produced through a rigorous reconciliation and amendment process:

1. **32 original documents** were reconciled into 6 canonical + archive
2. **Five foundational decisions** (BD-1, BD-3, BD-5, ND-5, ND-4) were made through adversarial review
3. **Canonical amendment** updated all 6 documents to reflect the foundational decisions
4. **Consistency audit** verified alignment across all canonical documents
5. **V2 baseline** was frozen on 2026-08-17 as the immutable implementation reference

## V2 Immutability

These files are **byte-for-byte copies** from the frozen PRE-IMPLEMENTATION-BASELINE-V2.
They MUST NOT be modified. Their SHA-256 hashes match the V2 MANIFEST.md exactly.

## Relationship to Implementation Plan

The IMPLEMENTATION-PLAN.md (in 03-IMPLEMENTATION/) is a derived document that maps these
canonical specifications into a concrete phased execution plan. If the implementation plan
contradicts these canonical documents, the canonical documents are correct.

## Documents That Must NOT Override These

- Historical archive documents (07-HISTORICAL/)
- Product research (05-PRODUCT-STRATEGY/) — non-authoritative
- Governance documents (04-GOVERNANCE/) — explain decisions, don't supersede canonical
- Previous baseline versions (V1) — superseded

## Document Summary

| File | Purpose | Scope |
|------|---------|-------|
| 01-business.md | Business Context | Vision, personas, problem space, capabilities, workflows |
| 02-decisions.md | Decisions & ADRs | Approved decisions, ADRs, rejected alternatives |
| 03-domain.md | Domain Model | Entities, VOs, events, Actions, enums, invariants |
| 04-architecture.md | Architecture | Stack, RBAC, search, SEO, content, packages |
| 05-implementation.md | Implementation Blueprint | Schema, packages, phases |
| 06-data-acquisition.md | Data Acquisition | Sources, ingestion, verification, provenance |
