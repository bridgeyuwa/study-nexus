# StudyNexus — Decisions & Architecture Decision Records

This document is the canonical consolidation of all approved business decisions, architecture decision records, resolved open questions, rejected alternatives, and the change proposal protocol governing modifications to frozen artifacts. It supersedes all prior per-document decision fragments and serves as the single source of truth for what has been decided, what has been rejected, and what has been deferred.

**Canonical Architecture:** 11 domain entities (5 aggregate roots + 3 child + 3 supporting), 2 infrastructure entities (ExternalIdentifier, FieldProvenance), 28 Value Objects, 29 domain events, 20 Actions, 16 enums, 11 RBAC roles. Staging entities (ImportBatch, PendingImport) are ephemeral and not counted as domain entities.

**Business Discovery Freeze Date:** 2026-08-07
**Architecture Freeze Date:** 2026-08-08

---

## 1. Business Discovery Decisions

The following 40 decisions (A0-1 through A9-3) were approved during Business Discovery and are immutable per the Business Discovery Freeze (see Section 8). They cannot be modified without a Change Proposal that satisfies the protocol defined in Section 8. These decisions were derived from stakeholder definitions, stakeholder confirmations, and approved business discovery with explicit rationale for each.

### 1.1 Identity & Vision (A0)

| ID | Decision | Rationale |
|----|----------|-----------|
| A0-1 | StudyNexus is a comprehensive education knowledge platform that aggregates, verifies, organizes, and makes educational information across Nigeria searchable, comparable, and trustworthy. | Stakeholder definition |
| A0-2 | Long-term vision: become the education infrastructure for Africa. | Stakeholder definition |
| A0-3 | Users search, discover, compare, and verify educational opportunities and information. | Stakeholder definition |

### 1.2 Primary Users (A1)

| ID | Decision | Rationale |
|----|----------|-----------|
| A1-1 | Primary users are four personas: Secondary School Student and Graduate, Undergraduate Student, Parent/Guardian, Guidance Counsellor/Teacher. | Stakeholder definition; refined to explicitly include current SS3 students, not only graduates. |
| A1-2 | All four are primary because solving their problems directly fulfills the platform's mission. However, they do not have equal business value — priority is to be determined later using business impact, usage frequency, and strategic value. | Stakeholder definition; priority deferred. |
| A1-3 | Current user behavior is manual, multi-source, fragmented discovery across JAMB, WAEC, institution websites, scholarship sites, PDFs, blogs, social media, WhatsApp groups, and friends. | Stakeholder definition |
| A1-4 | StudyNexus replaces fragmented discovery with a single trusted source. | Stakeholder definition |
| A1-5 | JAMB = Joint Admissions and Matriculation Board. Established domain terminology, not an assumption. | Stakeholder confirmation |
| A1-6 | WAEC = West African Examinations Council. Established domain terminology, not an assumption. | Stakeholder confirmation |

### 1.3 Secondary Users & Architecture Principles (A2)

| ID | Decision | Rationale |
|----|----------|-----------|
| A2-1 | Secondary users are six groups: Educational Institutions, Scholarship Providers, Government Education Agencies, Educational Researchers/Analysts, Employers (future), Developers (long-term). | Stakeholder definition |
| A2-2 | Primary users define day-one product strategy. Secondary users benefit from data but are not required for the initial value proposition. | Stakeholder definition |
| A2-3 | Educational Institutions are potential future primary users if institution management/verification/profile features are introduced. Not guaranteed — depends on future product strategy and business priorities. | Stakeholder definition; refined to reflect uncertainty. |
| A2-4 | Scholarship Providers are potential future primary users if direct scholarship creation/management is supported. Not guaranteed — depends on future product strategy and business priorities. | Stakeholder definition; refined to reflect uncertainty. |
| A2-5 | Government Education Agencies are strategic partners (data providers), not on a path to becoming primary users. | Stakeholder definition |
| A2-6 | Employers and Developers are outside initial scope; no planned promotion to primary. | Stakeholder definition |
| A2-7 | StudyNexus links users back to authoritative sources (e.g., government agencies) where appropriate. | Stakeholder definition |
| A2-8 | NECO = National Examinations Council, NABTEB = National Business and Technical Examinations Board, NUC = National Universities Commission, NBTE = National Board for Technical Education, NCCE = National Commission for Colleges of Education. Established domain terminology, not assumptions. | Stakeholder confirmation |
| A2-9 | Innovation Enterprise Institution (IEI) = a category of institution recognized within the Nigerian tertiary education system, distinct from universities, polytechnics, and colleges of education. Not a tech hub or startup incubator. | Stakeholder confirmation |
| A2-10 | Secondary users should influence architectural flexibility where doing so does not significantly increase complexity. Future extensibility should be considered, but must not compromise the simplicity of the day-one product. | Stakeholder confirmation |
| A2-11 | Default assumption: StudyNexus acquires information from publicly available authoritative sources unless a formal partnership with an Education Authority exists. | Stakeholder definition |

### 1.4 Problem Space (A3)

| ID | Decision | Rationale |
|----|----------|-----------|
| A3-1 | Fragmentation pain: No trusted source presents a complete, connected view of educational information. | Stakeholder definition |
| A3-2 | Trust pain: Users cannot confidently assess the reliability of educational information. Includes inability to distinguish official, verified, historical, and community-contributed information. | Stakeholder definition |
| A3-3 | Discoverability pain: Information is available only if the user already knows exactly what to search for. Users should be able to discover educational opportunities through structured exploration as well as direct search. | Stakeholder definition; refined as business outcome, not implementation commitment. |
| A3-4 | Comparison pain: Absence of standardized, comparable information across educational opportunities. | Stakeholder definition |
| A3-5 | Accessibility pain: Educational information exists but is practically inaccessible to many users due to format, connectivity, device, or usability barriers. Distinct from Discoverability. | Stakeholder definition |
| A3-6 | Structured exploration = the ability for users to discover relevant educational opportunities without already knowing their exact names or identifiers. Implementation determined during Product Design and Architecture. | Stakeholder definition; business concept, not implementation. |
| A3-7 | The four information categories (Official, Verified, Historical, Community-Contributed) are business concepts. Whether all are supported on day one is a Product Roadmap decision. | Stakeholder definition |
| A3-8 | Alternative Admission Pathways include Direct Entry, IJMB, JUPEB, diploma pathways, and other recognized admission routes into tertiary education. | Stakeholder confirmation |

### 1.5 Strategic Evolution (A4)

| ID | Decision | Rationale |
|----|----------|-----------|
| A4-1 | Four-stage strategic business evolution: (1) Trusted Education Knowledge Base, (2) Personalized Education Companion, (3) Education Ecosystem, (4) Education Infrastructure. Each stage builds on the previous. These describe business evolution, not a fixed chronological product roadmap — some capabilities may arrive earlier or later depending on business priorities. | Stakeholder definition; refined to separate business evolution from product roadmap. |
| A4-2 | MVP = Stage 1: Trusted Education Knowledge Base. Focused on solving Fragmentation, Trust, Discoverability, Comparison, and Accessibility. | Stakeholder definition |
| A4-3 | MVP explicitly excludes: institution self-service, scholarship provider self-service, public APIs, developer platform, multi-country support, marketplace/transactional features. | Stakeholder definition |
| A4-4 | Geographic expansion beyond Nigeria only after the Nigerian model has matured and proven successful. | Stakeholder definition |
| A4-5 | The business should support information originating from different authorities and contributors while preserving trust and provenance. This supports the Stage 3 transition to external contributions. | Stakeholder definition; refined to keep at business level. |
| A4-6 | International expansion should be anticipated but not optimized for until the Nigerian model is mature. | Stakeholder definition |
| A4-7 | Maintaining information quality is a core business concern. How users participate in information quality (e.g., feedback, flagging) is a Product Discovery decision. | Stakeholder definition |
| A4-8 | Decision support is a business capability. Its definition belongs in Capability Discovery; implementation belongs in Product Design. | Stakeholder definition |
| A4-9 | Business model and revenue model deserve their own discovery topic (Business Strategy Discovery). | Stakeholder definition |

### 1.6 Capabilities (A5)

| ID | Decision | Rationale |
|----|----------|-----------|
| A5-1 | 10 MVP capabilities: 8 Core (Acquire, Organize, Verify, Maintain, Discover, Search, Compare, Present) + 2 Supporting (Preserve Provenance, Manage Information Quality). | Stakeholder definition |
| A5-2 | 5 Future capabilities: Personalize guidance (Stage 2), Support verified org participation (Stage 3), Notify users (Stage 2), Provide data to third parties (Stage 4), Enable ecosystem collaboration (Stage 3/4). | Stakeholder definition |
| A5-3 | Capability relationships describe what requires or benefits from what — not a fixed execution order. Workflows that compose capabilities will be discovered later. | Stakeholder definition; refined to separate capabilities from workflows. |
| A5-4 | Compare, Search, and Discover each depend on Organized Educational Knowledge. Present consumes outputs from Search, Discover, and Compare. | Stakeholder definition |
| A5-5 | Verify improves Information Quality (via Manage Information Quality). | Stakeholder definition |
| A5-6 | Verify and Maintain are independent business capabilities. No mandatory ordering between them. | Stakeholder definition |
| A5-7 | Linking users back to authoritative sources is part of Present Educational Knowledge, not Acquire. | Stakeholder confirmation |
| A5-8 | Save, Share, Export, Print are product features, not part of the Present business capability. Present means making knowledge understandable and accessible. | Stakeholder definition |

### 1.7 Workflows — Secondary School Student & Graduate (A6)

| ID | Decision | Rationale |
|----|----------|-----------|
| A6-1 | Secondary School Student and Graduate has 6 primary workflows: Explore, Evaluate, Compare, Assess Eligibility, Assess Information Reliability, Make an Educational Decision. | Derived from approved business discovery; refined per stakeholder approval |
| A6-2 | Workflows are defined by business goals, not by search activities. | Stakeholder refinement |
| A6-3 | Variations within a workflow remain within the same workflow unless they introduce fundamentally different business goals. | Stakeholder refinement |
| A6-4 | StudyNexus supports informed decision-making but does not perform applications (MVP). | Stakeholder definition |
| A6-5 | Evaluate workflow goal: "Gather sufficient information about an educational opportunity to make an informed decision." Specific information types (tuition, accreditation, etc.) belong to business rules and future domain discovery, not the workflow definition. | Stakeholder refinement — keep workflow definition stable; specific information may evolve |
| A6-6 | Compare workflow: users review available comparison criteria relevant to the decision. The workflow does not assume users define the comparison model. | Stakeholder refinement — avoid assuming user-driven comparison model |
| A6-7 | Assess Eligibility goal: "Determine whether the user's qualifications satisfy the published admission requirements." The method of assessment (performed by StudyNexus, self-assisted, or presented for review) is an open question deferred to Product Discovery. | Stakeholder refinement — do not assume StudyNexus performs or does not perform assessment |
| A6-8 | Assess Information Reliability uses "Trust Signals" — an implementation-neutral concept that may include provenance, verification status, publication dates, official sources, editorial review, or other mechanisms. "Provenance indicators" are not introduced as a separate concept. | Stakeholder refinement — keep business language implementation-neutral |
| A6-9 | WF6 is "Make an Educational Decision" (not "Prepare for an Application Decision"). The workflow ends with the user deciding. What happens after (applying, researching further, postponing, rejecting) is outside workflow scope. This makes the workflow reusable for scholarships, programmes, institutions, and future educational opportunities. | Stakeholder refinement — broader, reusable workflow |
| A6-10 | Newly introduced business concepts from workflow discovery are placed in "Candidate Business Concepts" until they recur across multiple workflows or personas. Promotion to canonical requires explicit approval. | Stakeholder refinement — prevent premature glossary accumulation |

### 1.8 Workflows — Undergraduate Student (A7)

| ID | Decision | Rationale |
|----|----------|-----------|
| A7-1 | Undergraduate Student has 7 workflows: the 6 shared workflows (WF1-WF6) plus 1 persona-specific workflow: Understand Current Educational Journey (WF7). | Derived from approved business discovery |
| A7-2 | WF1-WF6 are the first confirmed shared workflow set across multiple primary personas (Secondary School Student and Graduate, Undergraduate Student). The business goals are identical; context and variations differ per persona. | Stakeholder confirmation — workflows are defined by domain business goals, not by persona |
| A7-3 | WF7 (Understand Current Educational Journey) is defined by the user's business goal, not by the object being viewed or the information it may present. | Stakeholder refinement — workflows are named and defined by goals, not objects |
| A7-4 | WF7 is distinct from evaluation workflows because the user is managing an existing educational commitment, not evaluating whether to pursue a new opportunity. | Stakeholder confirmation — fundamentally different business goal |
| A7-5 | Specific information types relevant to WF7 (e.g., programme requirements, academic regulations, graduation requirements) are examples only and do not become part of the workflow definition. They belong to business rules and future domain discovery. | Stakeholder refinement — consistent with A6-5 (workflow definitions remain stable) |

### 1.9 Workflows — Canonical Consolidation (A8)

| ID | Decision | Rationale |
|----|----------|-----------|
| A8-1 | Canonical workflows are those whose business goals recur independently across multiple primary personas. They are defined by the domain, not by any individual persona. WF1-WF6 are canonical. | Stakeholder approval — consolidation step |
| A8-2 | Persona-specific workflows address goals unique to a particular persona's relationship with the domain. WF7 is persona-specific (Undergraduate Student). | Stakeholder approval — consolidation step |
| A8-3 | Parent or Guardian exercises the 6 canonical workflows (WF1-WF6) with no persona-specific workflow. The parent acts as proxy decision-maker on behalf of their child — this affects how they execute workflows, not what goals they pursue. | Stakeholder approval |
| A8-4 | Canonical workflow consolidation replaces persona-by-persona discovery as the primary approach. Remaining personas are evaluated for genuinely new business goals, not re-derivation of existing workflows. | Stakeholder approval — avoid unnecessary duplication; allow canonical model to emerge naturally |

### 1.10 Workflows — Guidance Counsellor/Teacher & Discovery Closure (A9)

| ID | Decision | Rationale |
|----|----------|-----------|
| A9-1 | Guidance Counsellor or Teacher exercises the 6 canonical workflows (WF1-WF6) with no persona-specific workflow. Evaluated against 4 conditions for new workflow creation; no business goal satisfies all 4 conditions. | Derived from approved business discovery using rigorous 4-condition test |
| A9-2 | Differences between personas may change workflow execution context (who initiates, on whose behalf, how frequently, proactively vs reactively), but do not necessarily introduce new business goals. | Stakeholder approval — execution context is not equivalent to business goal |
| A9-3 | Business Discovery is complete. All 4 primary personas have been evaluated. 6 canonical workflows + 1 persona-specific workflow are confirmed. No blocking gaps remain for Domain Discovery. | Stakeholder approval — Discovery Checkpoint passed |

---

## 2. Resolved Open Questions

All 22 original open questions have been resolved as of 2026-08-08. These resolutions complement the approved decisions by answering questions that were deliberately left open during Business Discovery. They carry the same authority as approved decisions for the purposes of downstream phases.

| ID | Topic | Question | Resolution | Date |
|----|-------|----------|-----------|------|
| OQ1-1 | Primary Users | What is the priority ranking of the four primary personas? | Priority: 1. Secondary School Student/Graduate, 2. Undergraduate Student, 3. Parent/Guardian, 4. Guidance Counsellor/Teacher. The first two are primary usage personas. Parents are high-impact decision influencers. Counsellors/teachers are lower-volume but strategically valuable professional users. | 2026-08-08 |
| OQ1-3 | Primary Users | Can users research foreign institutions on day one? | No. Day One is strictly Nigerian institutions and Nigerian education data. Foreign institutions are future scope. Long-term direction is African education infrastructure, but Nigeria is the initial bounded domain. | 2026-08-08 |
| OQ1-4 | Primary Users | Do personas require distinct interface patterns? | Core interaction is shared; workflows and interfaces adapt to persona goals. Do not build four separate products. Shared capabilities underpin goal-oriented workflows. | 2026-08-08 |
| OQ2-3 | Secondary Users | When are institution management features expected? | Post-MVP. Institution management features come after the public discovery/information layer is established. | 2026-08-08 |
| OQ2-4 | Secondary Users | When are scholarship provider management features expected? | Post-MVP. Scholarship-provider management follows the public scholarship discovery/data layer. | 2026-08-08 |
| OQ2-5 | Data Acquisition | Do Government Education Agencies actively provide data? | Initially, information is primarily aggregated from public and official sources. Government agencies are authoritative sources, but the system should not depend on agencies actively providing data. Direct data partnerships/feeds are future enhancements. | 2026-08-08 |
| OQ3-1 | Problem Space | Are these the complete set of problem dimensions? | Yes for the current business-discovery model. Fragmentation, Trust, Discoverability, Comparison and Accessibility are the established primary problem dimensions. New dimensions require explicit change proposal/evidence. | 2026-08-08 |
| OQ3-4 | Problem Space | Relative severity of the five problem dimensions per persona? | Deferred detailed persona-by-persona scoring. Fragmentation, Discoverability and Trust are foundational; Comparison is especially important during decision-making; Accessibility cuts across all personas. | 2026-08-08 |
| OQ4-1 | Evolution | Does the MVP require user accounts/identity? | No account required for core MVP discovery, search, comparison and information access. Accounts should only be introduced when persistent/personal capabilities justify them. | 2026-08-08 |
| OQ4-2 | Evolution | What user feedback mechanisms exist for information quality? | Users can report information as incorrect, outdated, missing or conflicting. Reports enter an information-quality workflow and do not directly modify canonical data. | 2026-08-08 |
| OQ4-3 | Evolution | What does "decision support" mean as a business capability? | Both, progressively. Initially: structured consolidation, discovery, comparison and verification. As reliable structured data and rules mature: recommendation and eligibility assessment. StudyNexus should support decisions rather than make opaque decisions on behalf of users. | 2026-08-08 |
| OQ4-4 | Evolution | What is the business model/revenue model? | Deferred exact monetisation mechanics. Strategic model: free core discovery/search/information access, with future monetisation through institution/provider services, premium capabilities and relevant education-related commercial services. Monetisation should not drive the core information architecture. | 2026-08-08 |
| OQ5-1 | Capabilities | Are these 10 capabilities the complete MVP set? | The 10 capabilities constitute the current MVP capability baseline, not an immutable statement of every future capability. Changes should follow the established business-discovery/change-proposal process. | 2026-08-08 |
| OQ6-1 | Workflows | What constitutes "sufficient" information for a decision? | Decision-dependent. An evaluation is sufficient when the information required for the specific decision is available, sufficiently trustworthy, current for the relevant period, and comparable across alternatives. | 2026-08-08 |
| OQ6-2 | Workflows | What are the standard comparison dimensions? | Common foundation: identity, location, eligibility/requirements, cost/benefit, timing, availability, authority/provenance and status — with category-specific dimensions for institutions, programmes, scholarships and other opportunity types. | 2026-08-08 |
| OQ6-3 | Workflows | Does StudyNexus perform eligibility assessment? | Both. Initially: provide authoritative requirements for self-assessment. Progressively: structured eligibility assessment where underlying requirements and rules are sufficiently reliable and machine-actionable. | 2026-08-08 |
| OQ6-5 | Workflows | Does StudyNexus provide decision support beyond information aggregation? | Yes. Through structured comparison, relevant opportunity discovery, requirement/eligibility assessment and recommendation. | 2026-08-08 |
| OQ6-6 | Workflows | What parameters guide structured exploration per persona? | Goal/workflow-driven, not persona-driven. Parameters: goal, opportunity category, education level/stage, location, field/subject, eligibility, timing, cost and other decision-specific constraints. | 2026-08-08 |
| OQ6-7 | Workflows | What specific information types are required per opportunity category? | Each category requires its own evaluation model built from common primitives: identity, eligibility, requirements, cost/benefit, location, timing, availability, authority/provenance and status. | 2026-08-08 |
| OQ6-8 | Workflows | How do trust signals differ across Information Categories? | Official = directly attributable to an authoritative institution/agency. Verified = independently checked by StudyNexus. Historical = valid for a previous period/version. Community-Contributed = user-supplied information not established as authoritative. | 2026-08-08 |
| OQ7-1 | Workflows | What information is most critical for an undergraduate's current journey? | Current institution, programme, academic level/year, academic calendar, academic requirements/status, courses, assessments, fees, deadlines, institutional policies/procedures, scholarships/opportunities and progression/transfer information. | 2026-08-08 |
| OQ7-2 | Workflows | Does WF7 apply only to Undergraduate Students? | Yes. WF7 (Understand Current Educational Journey) is specifically for enrolled undergraduate students. Other personas should not receive duplicated versions. | 2026-08-08 |
| OQ7-3 | Workflows | Should the four candidate concepts be promoted to canonical? | No. Do not automatically promote. Their status should depend on identity, lifecycle, ownership, persistence and independent business behavior. They may instead be domain concepts/value objects or attributes of other domain objects. | 2026-08-08 |

---

## 3. Architecture Decision Records

The following ADRs were developed during Domain Architecture (per `19-domain-architecture.md`), validated during the adversarial validation review (per `20-domain-architecture-validation.md`), corrected where necessary, and promoted to Accepted or Deferred status in the frozen baseline (per `21-domain-architecture-frozen-baseline.md`). ADR-1 through ADR-14 originated in the architecture document; ADR-15 and ADR-16 were added by the frozen baseline to resolve validation-identified gaps; ADR-17 and ADR-18 are intentional deferments. ADR-19 through ADR-23 were added by the canonical amendment phase to formalize approved business decisions BD-1, BD-3, BD-5, ND-5, and ND-4.

### ADR-1: Eloquent Model as Aggregate Root Persistence

**Status:** Accepted

**Context:** The domain model has 5 aggregate roots with protected invariants, domain operations, and consistency boundaries. The architecture must decide how to persist these aggregates while maintaining domain integrity. Three options exist: (A) separate domain entity classes with repositories mapping to Eloquent, (B) domain entities composing Eloquent models, (C) Eloquent models containing domain behaviour directly.

**Decision:** Use Eloquent models directly as the aggregate persistence representation with domain operations as named methods. No separate domain entity classes. This is Option C — the Eloquent model IS the aggregate's persistence representation with domain operations as named methods. Domain operations (e.g., `Institution::suspend()`, `Programme::discontinue()`) are named methods on the Eloquent model that enforce invariants before mutating state. There are no separate domain entity classes, no repositories, and no persistence mapping layer.

**Consequences:** The domain model is tightly coupled to Eloquent, but this is the pragmatic Laravel Beyond CRUD choice. Aggregate operations are directly testable on model instances. The cost is that switching to a separate read store would require refactoring the aggregate root — but this is a low-probability event for MVP. The benefit is simplicity, reduced class count, and direct alignment with Laravel conventions. The coupling is acknowledged honestly: Eloquent IS the repository, and InstitutionMerger's direct aggregate loading is documented as a known seam where repositories could be introduced if aggregate reconstruction becomes complex.

---

### ADR-2: Action Pattern Adoption

**Status:** Accepted

**Context:** The application has operations ranging from simple single-domain calls (rename an institution) to complex cross-aggregate orchestrations (merge two institutions). The architecture must decide which operations deserve the Action pattern and which can live directly in controllers or Livewire components.

**Decision:** Adopt the Laravel Beyond CRUD Action pattern for operations that meet at least one of four explicit criteria: (1) Multi-step orchestration — coordinates more than one domain operation, validation step, or application concern in a single transaction; (2) Multi-entry-point reuse — invoked from multiple entry points (HTTP + Filament + Import) and a single Action class provides the reusable orchestration point; (3) Significant cascade — triggers cascading effects across multiple aggregates requiring explicit transactional coordination beyond event listeners; (4) Authorization + complex validation — requires authorization checks AND non-trivial validation that cannot be expressed as a Form Request alone. Search index updates are NOT sufficient justification (handled by event listeners). Authorization alone is NOT sufficient (Laravel Policies handle at controller/Livewire level). The final canonical count is 20 Actions.

**Consequences:** Every Action has documented justification against the criterion. Simple domain calls (rename, reactivate) bypass Actions and live in controllers/Livewire components, with event listeners handling side effects. The Action count was reduced from 23 to 20 through the validation process, removing RenameInstitution, ReactivateInstitution, and ReassignProgramme. Two marginal Actions (AnnounceAdmissionCycle, TargetScholarshipProgrammes) were retained with explicit justification. The discipline must be maintained during implementation to prevent Action proliferation — any new Action must meet at least one criterion.

---

### ADR-3: Domain Event Implementation

**Status:** Accepted

**Context:** Domain events represent business facts that other parts of the system react to (search index updates, trust signal recalculation, notifications, audit logging). The architecture must decide the implementation mechanism: shared interface, shared trait, or plain classes.

**Decision:** Domain events are plain PHP classes with constructor-injected payload. No shared interface. No shared trait. Listeners type-hint the specific event class. Each event carries the minimum payload needed by its listeners. The `occurredAt` timestamp is set in the constructor as an immutable default. There are 29 canonical domain events. No event sourcing; events are fire-and-forget business facts dispatched from domain methods.

**Consequences:** This is the simplest approach that works — consistent with Laravel Beyond CRUD's "avoid ceremony that provides no business value." No generic handler processes events polymorphically, so no interface or trait is needed. If a generic handler is required in the future, a trait or interface can be introduced then, driven by actual demand. Laravel's event system dispatches any object without requiring an interface, so there is no runtime cost to this decision.

---

### ADR-4: Value Object Persistence

**Status:** Accepted

**Context:** The domain has 28 Value Objects that must be persisted to the database. Some are complex immutable PHP objects (AdmissionRule, EligibilityRule), some are PHP backed enums (InstitutionType, AwardLevel), and some are computed (TrustSignal). The architecture must decide how each category is persisted.

**Decision:** Custom Eloquent casts for complex VOs (AdmissionRule, EligibilityRule, SubjectCombination, QualificationThreshold, ValidityPeriod, MonetaryAmount, Duration, Location, AuthorityJurisdiction, PhaseSequence, AdmissionPathway). PHP backed enums for enum-like VOs (16 enums total). JSON columns for collection VOs (rules stored as JSON arrays within their parent cast). Computed VOs (TrustSignal) are never stored — they are derived by queries. Domain VOs and Spatie Laravel Data DTOs are never the same class.

**Consequences:** Each VO has a single, documented persistence strategy. Complex VOs maintain type safety through custom casts. Enums get native Laravel enum casting. The boundary between domain VOs (plain PHP, in `App\Domain\ValueObjects\`) and DTOs (Laravel Data, in `App\Data\`) is strict and unambiguous.

---

### ADR-5: Read Model Strategy

**Status:** Accepted

**Context:** Some queries (isAdmitting, isApplicableTo, isReliable, isAdmissionOpen) derive answers from multiple aggregates and serve read concerns. These should not be domain operations on any single aggregate.

**Decision:** Dedicated Query classes in `App\Queries\` for all read concerns. Eloquent eager-loading for simple queries. Cross-aggregate queries (isAdmitting, isApplicableTo) are eventually consistent read-model queries. The write model is the authoritative source; read models are projections that may lag slightly.

**Consequences:** Clear separation between write operations (Actions + domain methods) and read operations (Query classes). Read models are eventually consistent — acceptable for a discovery domain where users expect slight lag but not for transactional systems. 15 canonical queries defined across institutions, programmes, scholarships, admission cycles, information sources, and opportunities.

---

### ADR-6: Search Engine Selection

**Status:** Accepted

**Context:** The platform needs faceted search with autocomplete for institutions, programmes, and scholarships. Two options: PostgreSQL full-text search (no additional infrastructure) or Typesense via Laravel Scout (purpose-built search engine with faceted search).

**Decision:** Start with PostgreSQL full-text search as the initial implementation. Switch to Typesense via Scout when PostgreSQL FTS latency exceeds 200ms at 10k programmes or when faceted search response time exceeds 100ms. The domain is never coupled to the search engine — all indexing is triggered by domain events via the UpdateSearchIndex listener. Scout provides the abstraction layer for switching.

**Consequences:** Zero additional infrastructure for MVP. The search engine is an infrastructure concern, not a domain concern. Domain events trigger indexing; the domain model is unaware of search infrastructure. The switch trigger is quantitative and measurable.

---

### ADR-7: Spatie Package Adoption

**Status:** Accepted

**Context:** The Laravel ecosystem has Spatie packages that address cross-cutting concerns. The architecture must evaluate each package for adoption, deferral, or rejection with explicit rationale and timing.

**Decision:** 5 packages adopted now (permission, medialibrary, activitylog, sluggable, query-builder, data — these are architectural dependencies). 2 adopted when ready (backup when deploying to production; sitemap when public pages exist). 5 evaluated later (settings, schedule-monitor, newsletter, ray, schema-org). 3 rejected (laravel-model-states — PHP enums + domain methods + events are cleaner for current state machines; laravel-fractal — Laravel Data provides superior DTO/transformer support; valuestore — laravel-settings is a better fit). laravel-data is adopted for DTOs only; domain VOs remain plain PHP classes.

**Consequences:** Clear distinction between architectural dependencies (application cannot function without them) and optional infrastructure tooling (application functions without them). Rejected packages have explicit rationale and reconsideration conditions.

---

### ADR-8: Filament vs Custom Admin

**Status:** Accepted

**Context:** The platform needs an admin panel for managing institutions, programmes, scholarships, authorities, sources, and moderation. Two options: build a custom admin with Livewire or adopt FilamentPHP.

**Decision:** FilamentPHP for all admin/back-office operations. Domain rules remain outside Filament — Filament Resources invoke Actions, never contain business logic. The Filament boundary is strict: no domain operations, no invariant checks, no state transitions in Filament Resource hooks. Filament is a consumer of the domain, not a participant.

**Consequences:** Rapid admin development, consistent UI, automatic policy integration via Filament Shield. The risk (developers adding business logic in Filament Resources) is mitigated by convention and code review. Filament is an architectural boundary, not a domain layer.

---

### ADR-9: Bounded Context Implementation

**Status:** Accepted

**Context:** DDD recommends separate bounded contexts per subdomain. The MVP has a single core domain (Opportunity Discovery + Trust & Provenance). Future bounded contexts (Application Management, Immigration & Visa, Qualification Equivalency, User Profiles & Journey, Payment & Transactions) are identified but not needed for MVP.

**Decision:** Single Laravel application with namespace separation for MVP. `App\Domain\` contains the domain model. `App\Actions\` contains use cases. `App\Queries\` contains reads. `App\Livewire\` and `App\Filament\` contain presentation. Namespace separation provides refactor seams for future bounded context extraction without requiring microservices or separate applications.

**Consequences:** Pragmatic for MVP — one deployment, one database, one codebase. The namespace structure provides clear conceptual boundaries. Future extraction to separate contexts is possible without architectural rewrite because the domain model is already namespaced separately from presentation and infrastructure.

---

### ADR-10: Namespace and Directory Structure

**Status:** Accepted

**Context:** Laravel's default namespace places models in `App\Models\`. The domain model includes models, VOs, enums, events, services, casts, and exceptions. The architecture must decide whether to use Laravel defaults or a domain-organized namespace.

**Decision:** `App\Domain\` is canonical for all domain model artifacts. `App\Domain\Models\` is the canonical model namespace (requires `config/app.php` update for `models_namespace`). `App\Domain\ValueObjects\`, `App\Domain\Enums\`, `App\Domain\Events\`, `App\Domain\Services\`, `App\Domain\Exceptions\`, `App\Domain\Casts\` complete the domain namespace. No `App\Domain\Repositories\`, no `App\Domain\Services\Interfaces\`, no `App\Domain\Aggregates\` — every directory serves a concrete purpose.

**Consequences:** Anyone opening the codebase sees the domain model first and in one place. Domain cohesion is high — sibling VOs, enums, events, and services are co-located. The cost is a one-line config change and non-default model namespace. No directory exists merely because DDD books commonly show it.

---

### ADR-11: Polymorphic vs Separate Tables

**Status:** Accepted

**Context:** Admission Policy and Accreditation Record each belong to either an Institution or a Programme (polymorphic parent). The architecture must decide whether to use Laravel's polymorphic relationships or separate tables per parent type.

**Decision:** Polymorphic relationships for Admission Policy (`governable_type` + `governable_id`) and Accreditation Record (`accreditable_type` + `accreditable_id`). These share identical structure regardless of parent type. Index on `(accreditable_type, accreditable_id)` and `(governable_type, governable_id)` for query performance.

**Consequences:** Fewer tables, simpler schema, DRY code. The trade-off is polymorphic query performance — mitigated by PostgreSQL's handling of polymorphic queries and proper indexing. If performance becomes an issue, separate tables can be introduced as a refactor.

---

### ADR-12: Repository Decision

**Status:** Accepted

**Context:** DDD traditionally uses repositories to abstract persistence from the domain model. With Eloquent models as aggregate roots, repositories would add a layer between the Action and the model.

**Decision:** No repositories. Eloquent IS the repository. Actions and domain services query and persist Eloquent models directly. The only known seam is InstitutionMerger, which directly loads and persists multiple aggregates within a transaction. If aggregate reconstruction becomes complex, introduce a Repository per aggregate at that point.

**Consequences:** Fewer classes, simpler code, direct Eloquent access. The InstitutionMerger coupling is documented as a known seam. The decision is pragmatic: for MVP, Eloquent's query builder and relationship methods provide all needed persistence operations. A repository layer would add indirection without concrete benefit.

---

### ADR-13: Reference Data Management

**Status:** Accepted

**Context:** Three supporting entities (Qualification, Scholarship Provider, Education Authority) have identity but no protected invariants. They are reference data — managed by admins, rarely changed, used as FK targets by domain entities.

**Decision:** Supporting entities are managed via Filament CRUD resources. They are seeded for initial markets (Nigeria first, then other countries). Country is an ISO 3166-1 wrapper (`App\Support\CountryReference`), not a domain VO. Reference data seeders are per-country (`NigeriaReferenceDataSeeder`, `GhanaReferenceDataSeeder`, etc.).

**Consequences:** Simple admin management for reference data. No domain operations, no invariants, no events for supporting entities. They are data, not behaviour. New countries require new seeders and potentially new InstitutionType/AwardLevel enum cases (see ADR-15).

---

### ADR-14: Testing Strategy

**Status:** Accepted

**Context:** The architecture has four layers: domain (models, VOs, enums), application (Actions, Queries), presentation (Livewire, Filament), and infrastructure (search, queue, cache). Tests must be prioritized by domain importance.

**Decision:** Four test layers in priority order: (1) Domain Unit — invariants, state transitions, VO equality, enum behaviour (PHPUnit on model instances without DB); (2) Feature (Actions) — Action orchestration, authorization, event dispatch (PHPUnit with SQLite in-memory); (3) Feature (Queries) — query correctness, read model accuracy (PHPUnit with SQLite + factories); (4) Browser (Livewire) — UI interactions, form submission, search (Laravel Dusk or Livewire testing). Domain tests are highest priority because they verify business rules that must hold regardless of UI or infrastructure.

**Consequences:** Domain invariants are testable without database setup — the fastest and most reliable test tier. Feature tests use SQLite in-memory for speed. The testing strategy aligns with the architectural philosophy: domain first, infrastructure last.

---

### ADR-15: InstitutionType and AwardLevel — Enum vs Reference Data

**Status:** Accepted (new, added by frozen baseline)

**Context:** InstitutionType and AwardLevel are currently PHP backed enums. Adding a new institution type (e.g., "Language School" for Study Abroad) or award level (e.g., "Certificate" for vocational education) requires a code change — a new enum case must be added and deployed. The tension is between type safety (enums with behaviour methods like `isDegreeGranting()`) and data flexibility (reference data tables allowing admin-configured values without code changes).

**Decision:** Retain as PHP enums for MVP. Enum values are domain concepts with behaviour (e.g., `InstitutionType::University->isDegreeGranting()`). Reference data tables cannot express this behaviour without additional code. The set of institution types and award levels is relatively stable — new values are added infrequently. Code changes for new enum values are trivial and carry zero deployment risk in Laravel (no migration needed, just add the case). Migration trigger: when adding the 4th+ country requires 3+ new InstitutionType or AwardLevel values that don't fit the existing enum, evaluate migrating to a reference data table with a hybrid approach (enum for behaviour, table for extensible values).

**Consequences:** Strong type safety for MVP. The enum-vs-reference-data tension is explicitly acknowledged with a measurable migration trigger. No speculative abstraction created for a problem that does not yet exist.

---

### ADR-16: Domain Event Interface Contract

**Status:** Accepted (new, added by frozen baseline)

**Context:** The validation identified the DomainEvent interface as ceremonial — it required four methods that provided no runtime value. Three options were considered: (1) remove entirely, (2) replace with a trait providing default implementations, (3) keep with justification.

**Decision:** Remove entirely (Option 1). Domain events are plain PHP classes. No shared interface, no shared trait. No consumer requires polymorphic event processing. The four methods (eventType, aggregateId, aggregateType, occurredAt) are derivable from the class itself. If a generic handler that processes any domain event polymorphically is needed in the future, a trait or interface can be introduced then — driven by actual demand, not speculative ceremony.

**Consequences:** Simpler code, fewer abstractions, consistent with Laravel Beyond CRUD's pragmatism. Each event carries its own payload in constructor parameters. Listeners type-hint the specific event class. The decision is reversible if evidence of need emerges.

---

### ADR-17: Caching and Performance Strategy

**Status:** Deferred

**Context:** Production performance requirements are unknown. Caching strategy, database indexing, eager loading patterns, and scalability thresholds cannot be meaningfully decided without production data.

**Decision:** Deferred until production performance requirements are known. The approach will be: Redis for read-model caching, model caching for frequently-accessed institutions/programmes, HTTP cache for public pages, cache invalidation via domain event listeners. Database indexing strategy defined during migration creation. Eager loading defined in Query classes.

**Consequences:** Not a blocker — the architecture is sound without explicit caching. Premature optimization is avoided. The deferral is documented and intentional.

---

### ADR-18: Data Ingestion Architecture

**Status:** Deferred

**Context:** The ImportInstitutionData Action exists as a placeholder. The full import pipeline design depends on the first real data source, which determines format (CSV/JSON/API), validation rules, deduplication strategy, and conflict resolution policy.

**Decision:** Deferred until the first real data source is integrated. Concerns to address: import sources, formats, validation pipeline (schema + domain + business rules), deduplication strategy (matching on name + type + country or registration identifier), conflict resolution (newer-wins, manual review, trust-based), provenance tracking, batch processing, error handling, and monitoring.

**Consequences:** The placeholder Action ensures the import concern is not forgotten. The deferral avoids speculative design for unknown source formats. The hybrid provenance model (entity-level provenance JSONB + field_provenance for selective attribution per ND-4) already supports import-attributed data.

---

### ADR-19: Uniform BIGINT Primary Keys (BD-1)

**Status:** Accepted

**Context:** The baseline mixed UUID and BIGINT primary keys across domain and reference tables. disciplines and cut_off_marks used UUID PKs while the main domain entities used BIGINT. FK references from programmes.discipline_id and cut_off_marks.programme_id/admission_cycle_id were UUID, creating an inconsistency with the BIGINT convention used everywhere else.

**Decision:** ALL canonical/domain tables use BIGINT auto-increment PKs. UUID remains ONLY for staging/import identities: import_batches.id, pending_imports.id. disciplines.id → BIGINT, cut_off_marks.id → BIGINT. All FK references to these tables → BIGINT. pending_imports.matching_entity_id → BIGINT.

**Consequences:** Consistent PK type across all domain and reference tables. Simplified FK management. UUID retained only where ephemeral staging identity benefits outweigh consistency (import batches/records).

---

### ADR-20: AdmissionCycle PhaseSequence with Stable Phase IDs (BD-3)

**Status:** Accepted

**Context:** The original AdmissionCycle model used a PhaseSequence Value Object but did not specify the phase identification strategy. Mutable phase labels could cause current_phase references to break if labels changed.

**Decision:** phase_sequence is a JSONB Value Object containing ordered phases with stable immutable phase IDs and mutable phase labels. current_phase is authoritative domain state referencing a stable phase ID (never a mutable label). Phase IDs and ordering are immutable after cycle activation. current_phase membership invariant: current_phase must be a member of phase_sequence. Phase transitions use explicit pessimistic locking via lockForUpdate() inside transaction. Domain events dispatched after successful transaction commit.

**Consequences:** Phase identity is stable even if labels change. current_phase is always resolvable. Pessimistic locking prevents concurrent phase transition race conditions. No hardcoded timestamp-based phase schema.

---

### ADR-21: Generic External Identifiers (BD-5)

**Status:** Accepted

**Context:** The baseline considered per-entity external code columns (jamb_code, nuc_code, nbte_code, ncce_code) on canonical entities. This approach is fragile — each new authority requires a schema migration and code changes.

**Decision:** No jamb_code/nuc_code/nbte_code/ncce_code columns on canonical entities. Instead, a generic ExternalIdentifier model with: entity_type VARCHAR(255), entity_id BIGINT, authority_id BIGINT FK → education_authorities (NOT NULL — the assigning authority), identifier_type VARCHAR(100), identifier VARCHAR(255), status VARCHAR(50) DEFAULT 'active', valid_from TIMESTAMP DEFAULT NOW(), valid_until TIMESTAMP NULL, source_id BIGINT NULL FK → information_sources (nullable — the observing source; NULL = editorial entry), replaced_by_id BIGINT NULL FK → external_identifiers (self-referencing), retirement_reason TEXT NULL, metadata JSONB NULL. Historical identifiers preserved. Active uniqueness enforced via partial unique indexes. No is_primary flag. status controls lifecycle (active/retired/superseded). valid_until is for temporal validity, NOT an active-state mechanism.

**Consequences:** Adding a new authority's code requires data insertion, not schema migration. Historical identifier transitions are fully tracked. Single model replaces N per-entity code columns.

---

### ADR-22: InformationSource as Independent Aggregate Root (ND-5)

**Status:** Accepted

**Context:** The baseline had InformationSource belongsTo Institution (institution_id FK), making sources institution-scoped. This is incorrect — an InformationSource (e.g., "JAMB Official Brochure 2026") is not owned by a single institution; it may provide data about many institutions.

**Decision:** InformationSource is an independent aggregate root with no institution_id FK. Instead, authority_id BIGINT NULL FK → education_authorities (nullable — NULL means the source is not published by an EducationAuthority). InformationSource belongsTo EducationAuthority (nullable). Remove belongsTo Institution relationship.

**Consequences:** Sources are institution-independent, correctly modeling real-world information sources. The authority_id link captures the publishing authority when applicable. Institution-specific source verification is handled through the provenance model (ND-4).

---

### ADR-23: Hybrid Provenance Model (ND-4)

**Status:** Accepted

**Context:** The baseline had primary_source_id on entities for provenance, which only captures one source per entity and cannot represent field-level attribution or conflicting sources.

**Decision:** Entity-level provenance JSONB on each entity for lightweight source metadata. field_provenance table for selective source attribution/conflict/history: entity_type VARCHAR(255), entity_id BIGINT, field_name VARCHAR(255), source_id BIGINT NULL FK → information_sources (nullable — NULL = editorial assertion), observed_value TEXT, confidence SMALLINT NULL (nullable for retroactive records), verification_status VARCHAR(50) DEFAULT 'unverified' (enum, NOT boolean is_verified), observed_at TIMESTAMP, superseded_at TIMESTAMP NULL, superseded_by_id BIGINT NULL FK → field_provenance (self-referencing), retroactive BOOLEAN DEFAULT FALSE. No is_active — derive active from superseded_at IS NULL. No value_hash. ON DELETE RESTRICT for source references. No primary_source_id on entities. 80/20 model: Category A = 5 fields (always provenance), Category B = 6 fields (provenance on conflict), Category C = all others (no provenance). field_provenance is NOT a complete observation log.

**Consequences:** Field-level provenance captures source conflicts and attribution without the overhead of logging every field. The 80/20 model (11 provenance-whitelisted fields) focuses provenance effort on the fields that matter most. Entity-level provenance JSONB provides lightweight whole-entity source metadata.

---

## 4. Platform & Version Decisions

The following platform and version decisions supersede all earlier references to Laravel 12, PHP 8.3, Filament v3, and Livewire v3. These decisions were driven by Filament v5's compatibility requirements and the need for a current, long-term-support PHP runtime.

### Laravel ^13.0

Laravel 13 is the canonical framework version. It is required by Filament v5, which mandates Laravel 13 as its minimum framework version. Laravel 12 is explicitly rejected as the implementation baseline — while Laravel 12 was the version referenced in earlier architecture drafts, Filament v5's release and its Laravel 13 dependency make Laravel 13 the only viable choice. Laravel 13 also provides improved native enum support, enhanced Eloquent casting, and continued TALL stack alignment. The `^13.0` constraint allows minor updates within the major version.

### PHP 8.5

PHP 8.5 is the canonical runtime version. It supersedes the earlier PHP 8.3 reference. PHP 8.5 provides readonly class promotion, improved attribute handling, and performance improvements that benefit the domain model's extensive use of readonly properties and backed enums. The PHP version is dictated by Laravel 13's minimum requirement and the desire for the most current stable runtime.

### Filament v5 + Livewire v4

Filament v5 is the canonical admin panel version. It is incompatible with Laravel 12 and requires Laravel 13 as its framework base. Filament v5 provides Filament Shield (for policy-based resource authorization), improved resource customization, and native Livewire v4 integration. Filament v3 is explicitly rejected — it is incompatible with both Laravel 13 and Livewire v4, and its continued maintenance is limited as the community transitions to v5. Livewire v4 is the canonical version for public-facing interactive UI, providing improved performance, better Alpine.js integration, and Flux component support.

### PostgreSQL 16+

PostgreSQL 16 or later is the canonical database. It provides advanced full-text search capabilities (used as the initial search implementation per ADR-6), native JSON indexing for VO columns, robust polymorphic relationship support, and strong data integrity constraints. PostgreSQL's FTS serves as the initial search engine before a potential Typesense migration.

### Tailwind CSS + Flux + Alpine.js

Tailwind CSS is the utility-first CSS framework. Flux provides the reusable UI component and design-system layer. Alpine.js handles lightweight browser-side interactions (dropdowns, tooltips, toggles). These are part of the TALL stack (Tailwind + Alpine + Laravel + Livewire) that is canonical per the architecture freeze.

---

## 5. RBAC Decisions

The authoritative role model is defined in `29-rbac-decision.md` and supersedes all prior role references in `21-domain-architecture-frozen-baseline.md` and earlier documents. The 11-role model was derived from the pre-implementation reconciliation (Change R2) and resolves correction C5.

### 5.1 Role Inventory

The 11 roles are organized into three scopes: platform-global (4 roles), institution-scoped (5 roles), and user-level (2 roles). Platform-global roles are stored via Spatie Permission in the standard `model_has_roles` and `model_has_permissions` tables. Institution-scoped roles are stored via a custom `OrganizationMember` pivot model with a string `role` column. User-level roles are stored via Spatie Permission.

| # | Role Name | Scope | Spatie Permission | Key Permissions / Purpose |
|---|-----------|-------|:-----------------:|---------------------------|
| 1 | `platform-admin` | Platform (global) | Yes | All permissions. Full system access. |
| 2 | `platform-moderator` | Platform (global) | Yes | Verify sources, moderate content, review community posts, handle reports. |
| 3 | `content-admin` | Platform (global) | Yes | CRUD all domain entities + content types. Publish/unpublish. |
| 4 | `content-editor` | Platform (global) | Yes | Create/edit/publish content. Cannot delete or manage domain entities. |
| 5 | `institution-owner` | Institution-scoped | No (OrganizationMember) | Full control of institution + manage members + transfer ownership. |
| 6 | `institution-admin` | Institution-scoped | No (OrganizationMember) | Manage institution data, programmes, admissions, scholarships. Cannot transfer ownership. |
| 7 | `institution-admissions` | Institution-scoped | No (OrganizationMember) | Manage admission policies, cycles, deadlines. Read-only on other areas. |
| 8 | `institution-editor` | Institution-scoped | No (OrganizationMember) | Edit descriptions, media, programme details. No status changes or admissions. |
| 9 | `institution-viewer` | Institution-scoped | No (OrganizationMember) | View internal data and reports. No write access. |
| 10 | `registered-user` | User-level | Yes | Save, follow, like, compare, community participation (post, answer, vote). |
| 11 | `guest` | User-level | Yes | Browse only. No write access. |

### 5.2 Mechanism

| Layer | Mechanism | Storage | Package |
|-------|-----------|---------|---------|
| Global platform roles | Spatie Permission | `model_has_roles`, `model_has_permissions` | `spatie/laravel-permission` |
| Institution-scoped roles | OrganizationMember pivot | `organization_members.role` (string column) | Custom |
| Admin panel resource auth | Filament Shield | Auto-generated policies | `bezhansalleh/filament-shield` |
| API token auth | Laravel Sanctum | `personal_access_tokens` | `laravel/sanctum` |
| Object-level checks | Laravel Policies | Policy classes | First-party |

### 5.3 OrganizationMember Pivot Model

The `OrganizationMember` pivot model uses a morphable relationship to link users to organizations (institutions). The `organization_members.role` column is a **string** column, NOT a foreign key to the Spatie `roles` table. This is a critical design decision: institution-scoped roles are a separate concept from global Spatie roles. The same user can be owner of Institution A and viewer of Institution B — roles are scoped to the organization, not global.

The pivot stores: `organization_type` (morph via Relation::morphMap: `institution`, `scholarship_provider`, `education_authority`), `organization_id`, `user_id`, `role` (string: `owner`, `admin`, `admissions`, `editor`, `viewer`), `created_at`, `updated_at`.

Policy checks combine global role checks with organization-scoped membership checks. For example, to determine whether a user can edit an institution's programmes: the user must have the `platform-admin` or `content-admin` global role, OR be an organization member with role `owner`, `admin`, or `editor` for that specific institution.

---

## 6. Important Rejected Decisions

This section documents decisions that were explicitly considered and rejected, with rationale. Documenting rejections prevents future regression — anyone proposing a previously rejected alternative must address the original rejection rationale with new evidence.

### Admission Pathway as Entity

**Rejected:** Admission Pathway as a domain entity with its own table, model, and lifecycle.

**Canonical:** Admission Pathway is a Value Object (`App\Domain\ValueObjects\AdmissionPathway.php`).

**Rationale:** The Domain Discovery behaviour audit (Topic 41/15) established that Admission Pathway has no independent lifecycle, no protected invariants, no identity beyond its value, and no autonomous business operations. It is a discriminator within an Admission Policy — a named admission route (UTME, Direct Entry, IJMB, JUPEB, diploma) with an optional authority reference. Promotion back to entity would require: (1) invariant justification, (2) identity beyond discriminator, (3) autonomous lifecycle. None of these exist. If they emerge, the promotion is additive (add table, add model), not structurally breaking.

### 7-Role Flat RBAC Model

**Rejected:** A flat 7-role model (e.g., super-admin, data-manager, content-editor, data-viewer, student, counsellor, guest) stored entirely via Spatie Permission.

**Canonical:** 11-role model with 4 platform-global + 5 institution-scoped + 2 user-level roles (see Section 5).

**Rationale:** A flat role model cannot express the multi-admin-per-institution requirement. If Institution A has Admin Alice and Institution B has Admin Bob, a flat `institution-admin` Spatie role gives Alice admin access to ALL institutions, not just Institution A. The OrganizationMember pivot with institution-scoped roles solves this — Alice can be `institution-admin` for Institution A and `institution-viewer` for Institution B, with roles scoped to the organization. A flat model would require either per-institution permission explosion or a custom authorization layer that reimplements scoping.

### `role_id` Foreign Key in OrganizationMember

**Rejected:** `organization_members.role_id` as a FK to the Spatie `roles` table.

**Canonical:** `organization_members.role` as a string column (`owner`, `admin`, `admissions`, `editor`, `viewer`).

**Rationale:** Institution-scoped roles are a separate concept from global Spatie roles. Spatie's `roles` table stores global roles (platform-admin, content-admin, etc.) with permissions. Institution-scoped roles do not have permissions in the Spatie sense — they are positional roles within an organization that map to different authorization checks in Laravel Policies. Using a FK would conflate two different role concepts and require creating Spatie role entries for each institution-scoped role, polluting the global role namespace and creating maintenance complexity. The string column is simpler, clearer, and correctly models the domain concept.

### `super-admin` Role Name

**Rejected:** `super-admin` as the name for the top-level platform role.

**Canonical:** `platform-admin`.

**Rationale:** The name `platform-admin` is consistent with the naming convention (scope-prefix + function) used by all other roles: `platform-moderator`, `content-admin`, `content-editor`, `institution-owner`, `institution-admin`, `institution-admissions`, `institution-editor`, `institution-viewer`, `registered-user`, `guest`. The `super-admin` name was used in earlier summary tables but does not follow the convention and was superseded during the RBAC reconciliation.

### Laravel 12 as Implementation Baseline

**Rejected:** Laravel 12 as the framework version for implementation.

**Canonical:** Laravel ^13.0.

**Rationale:** Filament v5 requires Laravel 13 as its minimum framework version. Laravel 12 is incompatible with Filament v5 and Livewire v4, which are canonical per the architecture. Using Laravel 12 would force either (a) staying on Filament v3 (also rejected — incompatible with Laravel 13 and limited maintenance), or (b) a mid-project framework migration from Laravel 12 to 13 when Filament v5 is adopted. Starting on Laravel 13 avoids this migration entirely.

### Filament v3

**Rejected:** Filament v3 as the admin panel version.

**Canonical:** Filament v5.

**Rationale:** Filament v3 is incompatible with both Laravel 13 and Livewire v4. Filament v5 is the current major version with active maintenance, Filament Shield support for policy-based authorization, native Livewire v4 integration, and improved resource customization. Filament v3's maintenance is limited as the ecosystem transitions to v5.

### 34 Value Objects

**Rejected:** 34 Value Objects (from earlier architecture drafts).

**Canonical:** 28 Value Objects (12 immutable PHP objects + 16 PHP backed enums).

**Rationale:** The frozen baseline's Value Object audit (per `21-domain-architecture-frozen-baseline.md`, Section 4) individually verified each VO against the criteria: genuine domain meaning, immutability, invariants, and correct classification. The audit confirmed 28 VOs. The 34-count was an earlier draft that included speculative VOs or double-counted concepts that are better modeled as enum cases or attributes. The 28-count is authoritative because each VO is individually named, justified, and classified.

### 20 Enums

**Rejected:** 20 PHP backed enums (from earlier counts).

**Canonical:** 16 PHP backed enums.

**Rationale:** The frozen baseline corrected an arithmetic error in the VO summary table. The range 13-28 in the audit table spans 16 slots (not 13 or 15 as earlier summaries stated). The authoritative recount confirms 16 PHP Backed Enums: 3 behavioural (InstitutionType, AwardLevel, AdmissionMode with domain methods like `isDegreeGranting()`) and 13 pure (AccreditationStatus, PolicyStatus, ProgrammeStatus, ScholarshipStatus, InstitutionStatus, SourceReliability, InformationCategory, AuthorityType, ProviderType, OwnershipType, DeliveryMode, QualificationStatus, CoverageType). The Section 4 VO audit table that individually names all 28 VOs is authoritative.

### 10 Entities

**Rejected:** 10 entities (from earlier counts that omitted Admission Policy as a child entity or merged Eligibility Policy into Scholarship).

**Canonical:** 11 entities (5 aggregate roots + 3 child entities + 3 supporting entities).

**Rationale:** The canonical entity count includes: 5 aggregate roots (Educational Institution, Programme, Scholarship, Admission Cycle, Information Source), 3 child entities (Admission Policy, Eligibility Policy, Accreditation Record — each with lifecycle controlled by their parent aggregate), and 3 supporting entities (Qualification, Scholarship Provider, Education Authority — reference data with no invariants). Admission Policy and Eligibility Policy are distinct entities with different domain purposes, different parent types, and different rule structures — they are not merged.

---

## 7. Deferred Decisions

The following decisions are explicitly deferred — they are not decided yet, and their deferral is documented and intentional. Each has a clear trigger that will prompt the decision.

### Exact Monetisation Mechanics (OQ4-4)

The strategic model is established (free core discovery/search/information access, with future monetisation through institution/provider services, premium capabilities, and relevant education-related commercial services). However, the exact mechanics — pricing tiers, payment integration, billing cycles, free-vs-paid feature boundaries — are deferred until the business model is tested against real usage data. Monetisation should not drive the core information architecture. This deferral ensures the domain model is not distorted by premature commercial assumptions.

### Persona Severity Scoring (OQ3-4)

The relative severity of the five problem dimensions (Fragmentation, Trust, Discoverability, Comparison, Accessibility) per persona is deferred until user research data is available. The current understanding is that Fragmentation, Discoverability, and Trust are foundational; Comparison is especially important during decision-making; Accessibility cuts across all personas. Detailed scoring requires quantitative user research that has not yet been conducted. This deferral prevents premature optimization of the UX for assumed severity rankings.

### Candidate Concept Promotion (OQ7-3)

The four candidate business concepts from workflow discovery are not automatically promoted to canonical. Their status depends on identity, lifecycle, ownership, persistence, and independent business behavior. They may instead be domain concepts, value objects, or attributes of other domain objects. Promotion requires explicit approval with evidence — this prevents premature glossary accumulation and ensures each canonical concept earns its place.

### Performance/Caching Strategy (ADR-17)

Deferred until production performance requirements are known. The approach will be Redis for read-model caching, model caching for frequently-accessed institutions/programmes, HTTP cache for public pages, cache invalidation via domain event listeners. Database indexing defined during migration creation. This is not a gap — it is intentional avoidance of premature optimization.

### Data Ingestion Pipeline (ADR-18)

Deferred until the first real data source is integrated. The ImportInstitutionData Action exists as a placeholder. Source-specific concerns (format, validation rules, deduplication, conflict resolution) cannot be designed without knowing the source. The hybrid provenance model (entity-level JSONB + field_provenance per ND-4/ADR-23) already supports import-attributed data.

### Search Engine Selection (Typesense vs PostgreSQL FTS)

PostgreSQL FTS is the initial implementation. Switch to Typesense when PostgreSQL FTS latency exceeds 200ms at 10k programmes or faceted search response time exceeds 100ms. The decision is deferred to production performance testing.

### Queue Driver (Redis vs Database)

Both options are viable for MVP. Database driver works for low volume. Redis needed for production async event processing at scale. Deferred to implementation.

### Custom PHPStan Rules

Code review as enforcement mechanism is acknowledged but insufficient for long-term discipline. Custom PHPStan rules to enforce Action Criterion, namespace conventions, and domain model access patterns will be added during implementation. Deferred to the implementation phase.

---

## 8. Change Proposal Protocol

Business Discovery is frozen as of 2026-08-07 (per `09-business-discovery-freeze.md`). The Architecture is frozen as of 2026-08-08 (per `21-domain-architecture-frozen-baseline.md`). The following principles and protocol govern all modifications to frozen artifacts.

### 8.1 Freeze Principles

| ID | Principle |
|----|-----------|
| F1 | Business Discovery is complete and frozen. No modifications to approved business decisions, workflows, capabilities, problem dimensions, or persona definitions are permitted without a Change Proposal. |
| F2 | Approved decisions (A0-1 through A9-3) are immutable unless explicitly reopened through a Change Proposal. A Change Proposal must identify the decision to be changed, the proposed modification, the rationale, and the impact on all dependent artifacts. |
| F3 | Domain Discovery may derive from Business Discovery but may not silently modify it. If Domain Discovery reveals information that contradicts an approved business decision, the contradiction must be recorded as a Change Proposal — not resolved by altering the business decision. |
| F4 | Any contradiction discovered in later phases (Domain Discovery, Product Discovery, Architecture, etc.) that conflicts with an approved business decision must be recorded as a Change Proposal rather than altering the approved decision. The Change Proposal is evaluated against the full dependency chain documented in the Traceability Matrix. |
| F5 | New concepts introduced during later phases must trace back to approved business decisions or be explicitly marked as assumptions. Assumptions must be documented in the Open Questions log with a clear path to resolution. Unresolved assumptions do not modify approved decisions. |

### 8.2 Change Proposal Protocol

To modify any frozen artifact, the following steps must be completed:

1. **Identify** the specific approved decision or artifact to be changed.
2. **Document** the Change Proposal with:
   - Target decision/artifact ID
   - Proposed modification
   - Rationale (what new information necessitates the change?)
   - Impact analysis (which other artifacts are affected, per Traceability Matrix?)
3. **Evaluate** whether the change invalidates other approved decisions.
4. **Approve or reject** the Change Proposal explicitly.
5. If approved, **update all dependent artifacts** consistently.
6. **Record** the Change Proposal and its resolution in the decision log.

A Change Proposal may be raised by any subsequent discovery phase but must be resolved before the dependent artifact can be considered authoritative.

### 8.3 What Is NOT Frozen

The following items remain mutable by design:

| Item | Why Mutable |
|------|------------|
| Open Questions | These are questions, not decisions. They may be answered in later phases without a Change Proposal. |
| Candidate Business Concepts | Per A6-10, these may be promoted to canonical with explicit approval. Promotion does not modify approved decisions. |
| ADRs | Architecture Decision Records are created and superseded as architecture evolves. New ADRs do not modify business decisions. |
| Implementation details | Product Discovery, Architecture, and implementation phases make decisions within the boundaries set by Business Discovery. |
| Deferred decisions | Items in Section 7 are not yet decided and will be resolved when their triggers are met. |

### 8.4 Architectural Freeze

In addition to the Business Discovery freeze, the Architecture is frozen per `21-domain-architecture-frozen-baseline.md`. Frozen architectural decisions (F-1 through F-19) require a formal ADR supersession to change. The superseding ADR must: (1) cite the original ADR being superseded, (2) present concrete evidence (production incident, performance data, user feedback, new domain discovery), (3) evaluate alternatives, and (4) acknowledge the cost of change. Theoretical concerns alone are insufficient to supersede a frozen decision.

---

*End of Decisions & Architecture Decision Records*
