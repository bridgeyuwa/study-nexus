# Package Scope & Discovery Log

**Date:** 2026-08-18

---

## Source Directories Inspected

| Directory | Purpose | Files Found |
|-----------|---------|-------------|
| /home/z/my-project/download/ | Root download directory | ~30 standalone documents |
| /home/z/my-project/download/PRE-IMPLEMENTATION-BASELINE-V2/ | Frozen V2 baseline | 54 files (6 canonical + 4 product-experience + 10 governance + 21 archive + 3 meta) |
| /home/z/my-project/download/studynexus-reconciled/ | Reconciled archive (V1 era) | 41 files |
| /home/z/my-project/download/PRE-IMPLEMENTATION-BASELINE/ | V1 baseline | ~35 files |
| /home/z/my-project/download/HOSTILE-REVIEWS/ | Hostile review documents | 1 file |

## Candidate Files Discovered

Total candidate files across all directories: ~160

## Files Included

### 01-CANONICAL (7 files)
6 canonical documents + 1 README. Byte-for-byte copies from frozen V2 baseline.

### 02-PRODUCT-EXPERIENCE (4 files)
4 product experience documents from frozen V2 baseline.

### 03-IMPLEMENTATION (6 files)
- IMPLEMENTATION-PLAN.md (current, post-correction)
- IMPLEMENTATION-PLAN-FINAL-AUDIT.md (GO verdict)
- IMPLEMENTATION-PLAN-FINAL-CLEANUP-REPORT.md (3 cleanup items resolved)
- IMPLEMENTATION-PLAN-CORRECTION-REPORT.md (20 corrections documented)
- IMPLEMENTATION-PLAN-AUDIT.md (original hostile audit — historical)
- IMPLEMENTATION-MODEL-RECONCILIATION.md (impl model reconciliation)

### 04-GOVERNANCE (18 files)
10 V2 governance documents + 5 standalone governance + 1 historical challenge +
1 hostile review + 1 V1 baseline report.

### 05-PRODUCT-STRATEGY (1 file)
README only. No dedicated competitive research files were discovered.

### 06-DATA-ACQUISITION (1 file)
README only. Canonical 06-data-acquisition.md is in 01-CANONICAL/.

### 07-HISTORICAL (32 files)
31 key historical documents from V2 archive + V2 baseline report + V2 README + V2 MANIFEST.

### 08-INDEPENDENT-AUDIT-GUIDE (2 files)
INDEPENDENT-AUDIT-BRIEF.md + AUDIT-QUESTIONS.md.

### 00-ORIENTATION (4 files)
README.md + CURRENT-STATE-MAP.md + AUTHORITY-HIERARCHY.md + PACKAGE-SCOPE.md (this file).

### Root (2 files)
MANIFEST.md + STUDYNEXUS-INDEPENDENT-AUDIT-PACKAGE-V3-REPORT.md.

## Files Deliberately Excluded

| File / Category | Reason |
|-----------------|--------|
| PRE-IMPLEMENTATION-BASELINE/ (V1 full copy) | Superseded by V2. V1 canonical docs are older versions of V2 canonical. Including V1 as a complete parallel baseline would create confusion. Key V1 differences are documented in CANONICAL-AMENDMENT-REPORT.md. |
| studynexus-reconciled/ (V1-era reconciled) | Duplicate of V1 baseline materials. The V2 archive already contains the same historical documents. |
| StudyNexus-Pre-Implementation-Baseline.zip | ZIP of V1 baseline — redundant with directory. |
| StudyNexus-Pre-Implementation-Baseline-v2.zip | ZIP of V2 baseline — redundant with V2 directory. |
| StudyNexus-Reconciled-Archive.zip | ZIP of reconciled archive — redundant with directory. |
| *.pdf files | PDF versions exist as duplicates of .md versions. Including only the .md source versions which are more useful for an LLM reviewer. |
| V2 archive files not in historical_files list | Some archive files (e.g., 08-traceability-matrix.md, VERIFICATION-REPORT.md) were included; all 31 V2 archive documents are included for completeness. |

## Duplicate Handling

Several documents exist in multiple locations:
- **Standalone governance docs** (CANONICAL-AMENDMENT-REPORT.md, etc.) are byte-identical
  to V2/governance/ versions. Only one copy is included (from V2/governance/).
- **studynexus-reconciled/ canonical docs** are V1-era versions. Not included (superseded).
- **studynexus-reconciled/ product experience docs** are byte-identical to V2 versions.
  Only V2 versions are included.

## Authority Classification

| Classification | Count | Basis |
|----------------|-------|-------|
| TIER 1 — Authoritative (Canonical) | 6 | Frozen V2 canonical documents |
| TIER 2 — Current (Product Experience) | 4 | Frozen V2 product experience |
| TIER 3 — Current (Implementation) | 6 | Current implementation plan + validations |
| TIER 4 — Governance | 18 | Decision evidence and audit trail |
| TIER 5 — Product Research | 1 | Non-authoritative research |
| TIER 6 — Historical | 32 | Superseded material |
| Meta | 8 | Orientation, guides, manifest, report |

## Additional Material Discovered

During the discovery process, the following were noted:

1. **PRODUCT-DISCOVERY-CHALLENGE.md** — Found in studynexus-reconciled/. This is a
   historical challenge document that identified the ProgrammeStatus/InstitutionStatus
   inconsistency. This was resolved in V2 (lifecycle states separated from publication).
   Included in 04-GOVERNANCE/ as historical evidence.

2. **IMPLEMENTATION-MODEL-RECONCILIATION.md** — Found as standalone. Documents
   reconciliation between the implementation model and canonical architecture.
   Included in 03-IMPLEMENTATION/ as it's directly relevant.

3. **CANONICAL-AUTHORITY-MATRIX.md** — Found as standalone. Documents which canonical
   document is authoritative for each concept. Included in 04-GOVERNANCE/.

4. **No competitive teardown documents** — No dedicated competitive research or market
   analysis files were found in the project workspace. This is a notable gap.
   The 01-business.md canonical document contains high-level competitor identification
   and differentiation strategy.

5. **HOSTILE-REVIEWS/external-identifiers-status-vs-validity.md** — Found in dedicated
   hostile reviews directory. Included in 04-GOVERNANCE/ as it's relevant to the
   external identifier model (BD-5).
