# Authority Hierarchy

**Date:** 2026-08-18

---

When documents conflict, higher-tier documents override lower-tier documents.

## TIER 1 — Current Canonical Authority (HIGHEST)

**Source:** 01-CANONICAL/

These 6 documents are the frozen V2 canonical architecture. They are the single
authoritative reference for implementation.

| Document | Content |
|----------|---------|
| 01-business.md | Vision, personas, problem space, capabilities, workflows |
| 02-decisions.md | Approved decisions, ADRs (including ADR-19 BIGINT PKs), rejected alternatives |
| 03-domain.md | Entities, value objects, events, Actions, enums, invariants, behaviour |
| 04-architecture.md | Stack, RBAC, search, SEO, content, packages |
| 05-implementation.md | Project structure, database schema, packages, phases |
| 06-data-acquisition.md | Source taxonomy, ingestion, verification, provenance |

**Override rule:** If anything else contradicts these, these win.

## TIER 2 — Product Experience Authority

**Source:** 02-PRODUCT-EXPERIENCE/

Current UX/UI/product-experience documents governing the first vertical slice.

| Document | Content |
|----------|---------|
| PRODUCT-EXPERIENCE-DISCOVERY.md | Discovery UX architecture, search paradigm |
| PRODUCT-EXPERIENCE-ARCHITECTURE.md | Product experience technical architecture |
| FIRST-VERTICAL-SLICE-UX.md | UX specification for first vertical slice |
| FIRST-VERTICAL-SLICE-UI.md | UI specification for first vertical slice |

**Override rule:** These govern UX/UI. If the implementation plan contradicts these
on UX matters, the product experience documents win. If they contradict canonical
architecture, canonical wins.

## TIER 3 — Current Implementation Plan

**Source:** 03-IMPLEMENTATION/

The current IMPLEMENTATION-PLAN.md and its validation documents.

| Document | Status |
|----------|--------|
| IMPLEMENTATION-PLAN.md | Current (post 20 corrections + 3 cleanup items) |
| IMPLEMENTATION-PLAN-FINAL-AUDIT.md | GO verdict with 3 conditions (now resolved) |
| IMPLEMENTATION-PLAN-FINAL-CLEANUP-REPORT.md | Confirms 3 cleanup items resolved |
| IMPLEMENTATION-PLAN-CORRECTION-REPORT.md | Documents 20 corrections from hostile audit |

**Override rule:** Implementation plan is derived from canonical. If it contradicts
canonical, canonical wins. Implementation plan governs execution order and packaging.

## TIER 4 — Governance / Decision Evidence

**Source:** 04-GOVERNANCE/

Documents that explain HOW the architecture reached its current form. These are
evidence of the decision process, not specifications themselves.

Key documents:
- FOUNDATIONAL-DECISIONS-BRIEF.md — 5 foundational decisions (BD-1, BD-3, BD-5, ND-5, ND-4)
- FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md — Adversarial review of those decisions
- CANONICAL-AMENDMENT-REPORT.md — What changed from V1 to V2
- FINAL-LINEAGE-SEMANTICS-RESOLUTION.md — Lineage/provenance semantic decisions
- SECOND-ORDER-ARCHITECTURE-REVIEW.md — Second-order effects review
- ADVERSARIAL-DECISION-REVIEW.md — Full adversarial decision review

**Override rule:** These explain decisions. They do NOT override canonical or product experience.

## TIER 5 — Product Strategy / Competitive Research

**Source:** 05-PRODUCT-STRATEGY/

Non-authoritative product research used to shape the product. Includes competitor
analysis and feature universe considerations.

**Override rule:** This is NON-AUTHORITATIVE. It does NOT override any other tier.
Competitor features are NOT StudyNexus requirements unless they appear in canonical.

## TIER 6 — Historical

**Source:** 07-HISTORICAL/

Superseded material preserved for traceability. Includes V1 baseline, domain discovery
process documents, previous architecture iterations, and rejected proposals.

**Override rule:** Historical documents NEVER override current documents. They are
evidence of the discovery process, not specifications.
