# 05-PRODUCT-STRATEGY — Product Strategy & Competitive Research

## Authority: NON-AUTHORITATIVE PRODUCT RESEARCH

This section contains product strategy and competitive research materials.

**IMPORTANT:** This material is NON-AUTHORITATIVE. It informed the product design
but does NOT constrain the architecture. Competitor features listed here are NOT
StudyNexus requirements unless they appear in the canonical documents.

## Current Contents

The canonical business document (01-business.md in 01-CANONICAL/) contains the
authoritative product vision, personas, problem space, and capability definitions.

No separate competitive teardown documents or market research files were discovered
in the project workspace. This is a notable gap — an independent auditor should
evaluate whether the architecture and implementation plan adequately support the
long-term product capabilities described in 01-business.md.

## Long-Term Capability Areas (from 01-business.md)

Based on the canonical business document, the following capability areas are
relevant for long-term product evolution:

- Programme discovery (core)
- Institution discovery (core)
- Faceted search (core)
- Programme-first search paradigm (core)
- Scholarships
- Admission information
- Accreditation status
- Examinations (JAMB, post-UTME)
- Rankings / league tables
- Maps / geolocation
- Institution facilities & campus life
- Content / news / FAQs
- SEO / programmatic SEO
- Alerts / notifications
- Recommendations / personalised discovery
- B2B / institutional partnerships
- Analytics / data quality dashboards
- Mobile-first responsive design
- African expansion beyond Nigeria
- International expansion
- AI-assisted discovery

## Competitors Identified (from business context)

### Global
- Bachelorsportal / Mastersportal / PhDportal (Discipline-driven portals)
- educations.com
- IDP
- ApplyBoard
- Study.eu

### Africa / Nigeria
- Academics.ng
- SchoolNews
- MySchoolGist
- UniAssist Africa

### Key Differentiators
- Nigeria-first, Africa-first positioning
- Programme-first discovery (vs institution-first)
- Verified data provenance and trust
- Comprehensive admission information
- Open/transparent data sources
