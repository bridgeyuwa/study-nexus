# Audit Questions — Independent Challenge Framework

**Purpose:** Structured challenge framework for independent audit of StudyNexus
**Auditor:** Explicitly encouraged to identify omissions NOT listed below

---

## Product

1. **Is the product model coherent?** Does the canonical architecture form a consistent
   whole, or are there internal contradictions between the business vision, domain model,
   and implementation plan?

2. **Is programme-first discovery actually the right foundation?** Most education platforms
   are institution-first. Is inverting this paradigm justified by user research, or is it
   an assumption? What are the failure modes?

3. **Are long-term product capabilities adequately accommodated?** The canonical
   architecture targets the first vertical slice. Does it leave room for scholarships,
   examinations, rankings, recommendations, B2B, and other future capabilities?

4. **Are there obvious strategic gaps?** What important product capabilities are missing
   from both the current architecture AND the long-term vision?

5. **Is the Nigeria-first positioning a strength or a constraint?** Does starting with
   Nigeria create architectural commitments that hinder African/international expansion?

## Domain

6. **Are the aggregate boundaries correct?** Do the 5 aggregate roots (Institution,
   Programme, Scholarship, AdmissionCycle, InformationSource) properly encapsulate
   their invariants? Are any aggregates too large or too small?

7. **Are relationships semantically correct?** Are all entity relationships properly
   classified (composition vs aggregation vs association)? Are cascade behaviours correct?

8. **Are lifecycle models complete?** Do InstitutionStatus, ProgrammeStatus, and
   ScholarshipStatus cover all realistic states? Are transitions valid?

9. **Are Value Objects appropriate?** Are the 28 value objects properly motivated?
   Should any be entities? Should any entities be value objects?

10. **Are there hidden EAV patterns?** Does the provenance model, external_identifiers,
    or any other generic structure create a de facto entity-attribute-value architecture?

11. **Are supporting entities actually justified?** Are Discipline, AdmissionMode, and
    other supporting entities genuinely needed, or could they be value objects/enums?

12. **Is the Discipline entity necessary?** Disciplines could be a simple enum or
    lookup table. Is the entity status (with lifecycle) justified?

## Identity

13. **Are BIGINT canonical PKs appropriate?** ADR-19 mandates BIGINT for all canonical
    tables. Is this the right choice vs UUID? What are the migration and federation
    implications?

14. **Are UUID staging identities correctly bounded?** UUIDs are used only for
    external_identifiers. Is this scope correct, or should UUIDs appear elsewhere
    (e.g., for distributed ingestion)?

15. **Are external identifiers modelled correctly?** The generic external_identifiers
    table (BD-5) replaces typed columns (jamb_code, nuc_code). Is this model
    sufficiently queryable? Does it create performance concerns?

16. **Is slug/public identity independent from DB identity?** Slugs are derived from
    names. Is the slug generation strategy robust for renames, merges, and conflicts?

## Data Lineage

17. **Is the SOURCE → OBSERVATION → RECONCILIATION → CANONICAL ASSERTION → PUBLICATION
    model coherent?** Does the acquisition pipeline form a consistent data flow? Are
    there gaps or inconsistencies?

18. **Is provenance sufficient?** The 80/20 provenance model tracks 11 fields explicitly.
    Is this enough? Are there fields that need provenance but don't have it?

19. **Is the 80/20 field-provenance strategy defensible?** Category A (5 fields, always
    provenance) + Category B (6 fields, on-conflict provenance) + Category C (no
    provenance). Is this the right boundary? Could it lead to information loss?

20. **Can provenance become a hidden EAV architecture?** The field_provenance table
    is effectively an EAV for provenance metadata. At what scale does this become
    a performance or complexity problem?

21. **Are information-loss decisions acceptable?** Category C fields have no provenance.
    If a Category C field is wrong, there's no way to trace or correct it. Is this
    acceptable for the Nigerian education data quality context?

## InformationSource / EducationAuthority

22. **Are their semantics correct?** InformationSource represents any data source
    (website, API, manual entry). EducationAuthority represents official regulatory
    bodies. Is this distinction clear and useful?

23. **Is authority_id nullable for the right reasons?** ND-5 makes authority_id nullable
    because not all sources have an associated authority (e.g., a university website
    is a source but not an authority). Is this correct? Does it create query complexity?

24. **Can all important source types be represented?** JAMB, NUC, NBTE, NCCE,
    institutional websites, newspapers, user reports — can the SourceReliability enum
    and InformationSource model capture all of these appropriately?

## AdmissionCycle

25. **Is PhaseSequence JSONB correct?** Using JSONB for admission phases with stable
    string IDs (instead of a separate phases table) is a deliberate denormalization.
    Is this justified? What are the query implications?

26. **Is current_phase genuinely authoritative?** The current_phase field on
    AdmissionCycle is derived from PhaseSequence data. Could it become stale or
    inconsistent? Are concurrency guarantees sufficient?

27. **Are stable phase IDs sufficient?** Phase IDs are strings like "application",
    "screening", "admission". Are these sufficient for all admission cycle types?
    What about custom or multi-stage processes?

28. **Are concurrency guarantees implementable?** lockForUpdate() is specified for
    phase transitions. Is this sufficient for the expected concurrency patterns?

## Search / Typesense

29. **Is PostgreSQL correctly the source of truth?** Typesense is a search projection.
    Is the sync strategy correct? What happens on Typesense failure?

30. **Is Typesense appropriately scoped?** Is Typesense the right choice for the
    faceted search requirements? Are there features needed that Typesense doesn't
    support well?

31. **Are facet/search needs supported?** The product experience requires faceted
    search by discipline, location, ownership type, delivery mode, etc. Are these
    properly mapped to Typesense capabilities?

32. **Is search architecture compatible with the long-term recommendation engine?**
    Recommendations require different data access patterns than search. Does the
    Typesense-as-projection architecture leave room for recommendation systems?

## Product Experience

33. **Does the domain support the UX?** Can the domain model provide all the data
    needed by the UX specifications? Are there data gaps between what the UX needs
    and what the domain provides?

34. **Does the implementation plan faithfully implement the UI/UX documents?** Check
    the implementation plan against the product experience documents for gaps or
    contradictions.

35. **Are there missing data dependencies?** The Programme Detail page needs admission
    information, institution data, and scholarship data. Are all these relationships
    properly modelled and queryable?

## SEO

36. **Does the architecture support the intended SEO universe?** StudyNexus intends
    programmatic SEO for programme-by-location-by-institution combinations. Does the
    slug/URL architecture support this?

37. **Are there safeguards against thin programmatic SEO?** Auto-generated pages for
    every programme × institution × location combination could create thin content.
    Are there quality gates?

38. **Are slugs, redirects, canonical URLs and projections sufficiently supported?**
    The architecture mentions slug management but doesn't detail the redirect/canonical
    URL strategy. Is this adequately specified?

## Implementation

39. **Does IMPLEMENTATION-PLAN.md faithfully map the architecture?** Check every
    table, every enum, every relationship, every Action, every event in the
    implementation plan against the canonical documents.

40. **Are migration dependencies correct?** Are foreign key dependencies and migration
    ordering properly captured in the phase sequence?

41. **Is the phase sequencing sensible?** 7 phases (0-6). Is anything in an earlier
    phase that should be later, or vice versa?

42. **Is anything unnecessarily complex?** The implementation plan is detailed.
    Are there areas where simpler approaches would work?

43. **Is anything missing?** Are there architectural requirements in the canonical
    documents that the implementation plan doesn't address?

44. **Is the contract-freeze gate sufficient?** The plan requires freezing certain
    contracts before parallel Phase 2 work. Are the right things frozen? Is anything
    missing from the freeze list?

## Competitive Strategy

45. **Does the current architecture leave room for useful capabilities discovered from
    competitors?** Which competitor features are genuinely important to accommodate?

46. **Which competitor-derived capabilities should NOT influence the architecture?**
    Not every competitor feature is a requirement. Which should be explicitly excluded?

47. **Are there likely future moats the current design accidentally prevents?** Could
    the current architecture create barriers to features that would become competitive
    advantages (e.g., AI-powered recommendations, real-time admission tracking)?

## Blind Spots

> **"What important thing would a competent architect reviewing StudyNexus independently
> notice that the original authors may have missed?"**

The reviewer is explicitly encouraged to identify omissions, contradictions, risks,
and opportunities NOT listed in this brief. The questions above are a starting point,
not a boundary.
