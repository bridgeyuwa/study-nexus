# Independent Audit Brief

**Date:** 2026-08-18
**Purpose:** Orient an independent reviewer (LLM or human architect) to challenge StudyNexus
**Contains:** NO conclusions. Only orientation.

---

## Current State

- **Discovery is closed** — no new product discovery will be conducted before implementation
- **V2 architecture is frozen** — canonical documents are immutable
- **Implementation plan is ready** — post 20 corrections + 3 cleanup items
- **No code has been written** — Phase 0 has not begun
- **No migrations have been written**
- **No Laravel project has been scaffolded**
- **Contract-freeze gate required** before parallel Phase 2 work

## What StudyNexus Is

StudyNexus is a **Nigeria-first, search-first education discovery platform**.

Its core purpose is to help Nigerian students discover programmes of study, understand
admission requirements, and make informed education decisions — starting with the
programme (not the institution) as the primary discovery axis.

### Core Job-to-Be-Done

> "Help me find the right programme for my interests and qualifications, and show me
> how to get admitted."

### Primary User

Nigerian secondary school leavers and prospective undergraduates preparing for
tertiary education. Secondary users include parents, guidance counsellors, and
institutional administrators.

### Key Differentiator

**Programme-first discovery.** Most education platforms (Bachelorsportal, IDP, etc.)
are institution-first — you browse institutions, then their programmes. StudyNexus
inverts this: you discover programmes across all institutions, filtered by discipline,
location, admission requirements, and other facets.

## Product Vision (Long-Term)

StudyNexus aims to become the **authoritative, trusted source of verified education
information in Nigeria**, then expand across Africa. The long-term vision includes:

- Programme and institution discovery (core — first vertical slice)
- Verified data with transparent provenance and source attribution
- Comprehensive admission information (JAMB cut-offs, post-UTME, O'Level requirements)
- Scholarships and financial aid
- Accreditation status tracking
- Examination information
- Future: recommendations, personalised discovery, B2B, analytics, AI-assisted discovery

## First Vertical Slice

The implementation targets this user journey first:

```
Homepage → Programme Search → Faceted Results → Programme Detail → Institution Detail → Admission Information
```

## Architecture Methodology

StudyNexus follows **Laravel Beyond CRUD (2nd Edition)** — pragmatic Domain-Driven Design
as described by Brent Roose and Freek Van der Herten. The architecture prioritizes domain
accuracy over theoretical purity.

## Key Architecture Decisions

| Decision | ID | Choice |
|----------|----|--------|
| All canonical PKs are BIGINT | BD-1 / ADR-19 | No UUIDs for canonical tables |
| AdmissionCycle phases use JSONB | BD-3 | PhaseSequence with stable phase IDs |
| Generic external_identifiers | BD-5 | No jamb_code/nuc_code columns on entities |
| InformationSource is independent AR | ND-5 | No institution_id, nullable authority_id |
| Hybrid provenance model | ND-4 | Entity-level JSONB + field_provenance 80/20 |

## Authority Hierarchy

1. **01-CANONICAL/** — Frozen V2 canonical documents (HIGHEST authority)
2. **02-PRODUCT-EXPERIENCE/** — Current UX/UI specifications
3. **03-IMPLEMENTATION/** — Implementation plan (derived from canonical)
4. **04-GOVERNANCE/** — Decision evidence (explanatory, not prescriptive)
5. **05-PRODUCT-STRATEGY/** — Non-authoritative research
6. **07-HISTORICAL/** — Superseded material (NEVER authoritative)

## Important Cautions

### DO NOT assume previous GLM audits are correct.

Multiple audits have been conducted on this architecture. They generally reached "GO"
verdicts. An independent auditor must NOT assume these verdicts are correct. Verify
claims against primary source documents.

### DO NOT assume the architecture is correct merely because it's frozen.

Freezing the architecture means the team has committed to it, not that it's been
independently validated. The purpose of this package is to enable independent validation.

### DO NOT treat historical documents as authoritative.

Archive documents from the discovery process may contain models, schemas, and designs
that were superseded by the V2 canonical documents. Always check canonical first.

### DO NOT treat competitor features as requirements.

Product research identifies competitor capabilities for strategic awareness. Only
features in the canonical documents are actual requirements.

### Pay special attention to:

- **Provenance model** — The 80/20 field-provenance strategy is novel and may have
  hidden costs or EAV-like properties
- **InformationSource semantics** — The decision to make it an independent AR with
  nullable authority_id is unusual and needs independent validation
- **Programme-first discovery** — The inverted discovery paradigm is the core
  differentiator but also the core architectural risk
- **AdmissionCycle PhaseSequence** — JSONB-based phase model with stable IDs needs
  careful concurrency and consistency analysis
- **Publication vs lifecycle** — The separation of is_published from domain status
  (e.g., ProgrammeStatus) is architecturally important and easy to confuse
