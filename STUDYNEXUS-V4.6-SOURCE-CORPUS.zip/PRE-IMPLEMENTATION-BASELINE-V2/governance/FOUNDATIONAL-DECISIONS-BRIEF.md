# Foundational Decisions Brief

**Date:** 2026-08-10 (V4.6 supersession note: 2026-08-19)
**Scope:** Six foundational decisions that must be resolved before any reconciliation can be executed
**Status:** ANALYSIS COMPLETE — awaiting human resolution of all six decisions
**Constraint:** No canonical documents modified. No baseline modified. No code. No migrations. No reconciliation executed.

> **V4.6 supersession note (2026-08-19):** This brief was authored when the V2-era counts (11 domain entities, 3 child entities, 3 supporting entities, 28 VOs, 16 enums, 58 tables) were current. The V4.6 canonical counts are: **13 domain entities** (5 AR + 4 child + 4 supporting), **29 VOs**, **17 enums**, **61 tables** — see `canonical/03-domain.md` §2/§3 and `canonical/05-implementation.md` §4. Where this brief refers to "3 child entities" or "3 supporting entities" or "11 domain entities", those references are the V2-era counts and should be read as historical context for the decision being discussed, not as current canonical counts. The V4.6 RBAC role strings (`owner`, `admin`, `admissions`, `editor`, `viewer` bare strings) have also superseded the `institution-*` prefixed strings referenced in this brief.

---

## Decision Inventory

| ID | Decision | Severity | Blocks Reconciliation? |
|----|----------|----------|----------------------|
| BD-1 | Primary-key strategy | CRITICAL | Yes — every migration, every FK, every Typesense doc, every import mapping |
| BD-2 | Morph type convention | CRITICAL | Yes — every polymorphic column in every migration |
| BD-3 | AdmissionCycle phase storage | CRITICAL | Yes — admission_cycles migration schema |
| BD-4 | Deletion/cascade strategy | HIGH | Yes — every FK declaration in every migration |
| D1 | AdmissionCycle ownership | CRITICAL | Yes — admission_cycles FK direction |
| D3 | Scholarship provider relationship | HIGH | Yes — scholarships FK vs morph columns |

---

# BD-1 — Primary-Key Strategy

## 1. Current Evidence

### Where UUID is mentioned and what it is used for

**1a. UUID as explicit primary key (2 tables only):**

| Table | Document | Line | Evidence |
|-------|----------|------|----------|
| `disciplines` | 03-domain.md | 478 | `id UUID Primary key` |
| `cut_off_marks` | 03-domain.md | 504 | `id UUID Primary key` |

Both are confirmed by DDL in archive governance documents (DISCOVERY-CLOSURE.md — which incorporates the original product-discovery challenge content) with `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`.

**1b. UUID as foreign key (cut_off_marks only):**

| FK | Document | Evidence |
|----|----------|----------|
| `cut_off_marks.programme_instance_id` | 03-domain.md line 505, 05-implementation.md line 276 | `BIGINT, FK → programme_instances(id), ON DELETE CASCADE` |
| `cut_off_marks.admission_cycle_id` | 03-domain.md line 506, 05-implementation.md line 276 | `UUID, FK → admission_cycles(id), ON DELETE CASCADE` |
| `cut_off_marks.source_id` | 03-domain.md line 509, 05-implementation.md line 276 | `UUID, FK nullable → information_sources(id), ON DELETE SET NULL` |
| `programmes.discipline_id` | 03-domain.md line 295, 05-implementation.md line 256 | `UUID FK nullable → disciplines` |

**1c. UUID for data-acquisition staging layer:**

| Table | Document | Line | Evidence |
|-------|----------|------|----------|
| `import_batches` | 06-data-acquisition.md | 94 | `id UUID Batch identity` |
| `pending_imports` | 06-data-acquisition.md | 114 | `id UUID Record identity` |
| `pending_imports.batch_id` | 06-data-acquisition.md | 115 | `UUID (FK) Parent batch` |
| `pending_imports.matching_entity_id` | 06-data-acquisition.md | 121 | `UUID, nullable — If matched to existing entity` |

**Critical implication:** `matching_entity_id` being UUID implies domain entity PKs are UUID. If domain PKs are bigint, this column type is wrong.

**1d. UUID as Typesense document ID:**

| Collection | Document | Line | Evidence |
|------------|----------|------|----------|
| Programme | PRODUCT-EXPERIENCE-ARCHITECTURE.md | 1159 | `id = Programme UUID (string) → Document ID` |
| Institution | PRODUCT-EXPERIENCE-ARCHITECTURE.md | 1185 | `id = Institution UUID (string) → Document ID` |

**1e. UUID in frozen domain architecture archive:**

| Document | Line | Evidence |
|----------|------|----------|
| archive/21-domain-architecture-frozen-baseline.md | 584-591 | All 8 entities have UUID identity columns: Institution, Programme, Scholarship, AdmissionCycle, InformationSource = UUID; AdmissionPolicy, EligibilityPolicy, AccreditationRecord = UUID (composite) |

**1f. UUID as "auto-increment PK" for supporting entities:**

| Entity | Document | Line | Evidence |
|--------|----------|------|----------|
| Qualification | 03-domain.md | 55 | `auto-increment PK` |
| ScholarshipProvider | 03-domain.md | 56 | `auto-increment PK` |
| EducationAuthority | 03-domain.md | 57 | `auto-increment PK` |

**1g. UUID in product experience as document identifier:**

PRODUCT-EXPERIENCE-ARCHITECTURE.md and FIRST-VERTICAL-SLICE-UX.md reference "Institution UUID" and "Programme UUID" as document identifiers in Typesense and URL contexts, but do not define PK strategy.

### Where bigint is mentioned

**1h. bigint PK in reconciliation deliverable:**

IMPLEMENTATION-MODEL-RECONCILIATION.md assigns `id bigint PK` to all 11 domain tables (educational_institutions, programmes, scholarships, admission_cycles, information_sources, admission_policies, eligibility_policies, accreditation_records, qualifications, scholarship_providers, education_authorities). All FKs are also `bigint FK`.

**1i. bigint PK for organization_members:**

05-implementation.md line 282: `id bigint PK` — the only table in 05-implementation.md with an explicitly typed PK.

**1j. bigint for all morph IDs:**

IMPLEMENTATION-MODEL-RECONCILIATION.md: `governable_id bigint (morph)`, `accreditable_id bigint (morph)`.

### Where PK type is unstated

For 5 of 5 aggregate roots (Institution, Programme, Scholarship, AdmissionCycle, InformationSource), 03-domain.md **does not explicitly state the PK type**. 05-implementation.md also leaves `id` untyped for these tables. The only explicit PK-type declarations in canonical documents are:
- `disciplines`: UUID PK
- `cut_off_marks`: UUID PK
- Qualification, ScholarshipProvider, EducationAuthority: auto-increment PK (implying bigint)
- `import_batches`, `pending_imports`: UUID PK

### Slug usage

| Entity | Document | Usage |
|--------|----------|-------|
| Institution | 05-implementation.md line 254, 04-architecture.md | `slug` column, unique within country. Used in URLs: `/institutions/{institution-slug}` |
| Programme | 05-implementation.md line 256, 04-architecture.md | `slug` column, unique within institution `(institution_id, slug)`. URLs: `/institutions/{institution-slug}/programmes/{programme-slug}` |
| Scholarship | 05-implementation.md line 258 | `slug` column |
| Discipline | 03-domain.md line 480, 05-implementation.md line 274 | `slug VARCHAR(100)`, globally unique |

Slugs serve as **public-facing URL identifiers**, not as primary keys. They are derived from entity names and are mutable (with 301 redirect support via `url_redirects` table).

## 2. Contradictions

| Contradiction | Documents | Nature |
|---------------|-----------|--------|
| disciplines/cut_off_marks have UUID PK | 03-domain.md | Explicit UUID for 2 tables |
| Aggregate root PKs unstated | 03-domain.md, 05-implementation.md | Neither document declares PK type for 5 aggregate roots |
| Reconciliation assumes bigint PK | IMPLEMENTATION-MODEL-RECONCILIATION.md | All 11 tables get `bigint PK` |
| Staging layer implies UUID domain PKs | 06-data-acquisition.md | `matching_entity_id UUID` references domain entities |
| Typesense uses UUID as doc ID | PRODUCT-EXPERIENCE-ARCHITECTURE.md | Programme/Institution UUID as document ID |
| Supporting entities get auto-increment | 03-domain.md | Qualification/ScholarshipProvider/EducationAuthority = auto-increment |
| Frozen archive says UUID for all entities | archive/21-domain-architecture-frozen-baseline.md | All 8 entities have UUID identity |

**Core problem:** No ADR governs PK type. Three signals point to UUID (06-data-acquisition.md, PRODUCT-EXPERIENCE-ARCHITECTURE.md, archive/21). The reconciliation deliverable assumed bigint. The canonical 03-domain.md is silent on 5 of 5 aggregate root PKs but explicitly uses UUID for 2 tables (disciplines, cut_off_marks).

## 3. Options

### Option A: bigint (auto-increment) for all domain entities

- Every domain table gets `id bigIncrements` / `id bigint PK`
- FKs are `bigint FK`
- Laravel Eloquent default convention
- Staging `matching_entity_id` must change from UUID to bigint
- Typesense doc IDs become string-casted bigint values (e.g., `"12345"`)
- disciplines and cut_off_marks change from UUID PK to bigint PK (overriding 03-domain.md)

### Option B: UUID for all domain entities

- Every domain table gets `id uuid PK DEFAULT gen_random_uuid()`
- FKs are `uuid FK`
- Requires `->uuid()` in migrations, custom `UsesUuid` trait on models
- Staging `matching_entity_id` type is correct as-is
- Typesense doc IDs remain UUID strings
- disciplines and cut_off_marks remain UUID PK (consistent with 03-domain.md)
- Supporting entities (Qualification, ScholarshipProvider, EducationAuthority) override 03-domain.md's "auto-increment PK" declaration
- Eloquent default convention overridden; `->find()` works but requires UUID casting

### Option C: ULID for all domain entities

- Every domain table gets `id ulid PK`
- FKs are `ulid FK`
- Requires `symfony/uid` (built into PHP 8.5+), custom ULID trait
- Time-sortable (unlike UUID v4), lexicographically ordered
- Not mentioned or used anywhere in current documentation
- Same staging/Typesense implications as UUID
- Less Laravel ecosystem support than UUID (no built-in `->ulid()` migration method as of Laravel 13)

### Option D: Mixed — UUID for aggregate roots, bigint for supporting entities

- 5 aggregate roots + disciplines + cut_off_marks = UUID PK
- 3 supporting entities (Qualification, ScholarshipProvider, EducationAuthority) = bigint PK (auto-increment)
- 3 child entities (AdmissionPolicy, EligibilityPolicy, AccreditationRecord) = UUID PK
- Matches 03-domain.md most closely (supports its UUID on disciplines/cut_off_marks and auto-increment on supporting)
- FKs crossing the boundary (e.g., Scholarship → ScholarshipProvider) are UUID → bigint, which is valid
- Staging `matching_entity_id` needs to be polymorphic or type-aware
- More complex but respects existing document declarations

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A (bigint) | Overrides 03-domain.md explicit UUID on disciplines/cut_off_marks. Supporting entity auto-increment preserved. |
| B (UUID) | Overrides 03-domain.md "auto-increment PK" on Qualification/ScholarshipProvider/EducationAuthority. Preserves UUID on disciplines/cut_off_marks. |
| C (ULID) | Overrides all existing PK declarations. Introduces technology not currently referenced anywhere. |
| D (Mixed) | Preserves all existing 03-domain.md PK declarations exactly. |

### Database schema

| Option | Impact |
|--------|--------|
| A | All PKs/FKs are bigint. 4-byte index width. Standard Laravel convention. disciplines/cut_off_marks lose UUID. |
| B | All PKs/FKs are UUID (16-byte). Wider indexes, larger storage. No Laravel default for `->uuid()` PK in migrations (requires `$table->uuid('id')->primary()`). |
| C | All PKs/FKs are ULID (26-char string). Wider than bigint, narrower than UUID string. Less mature tooling. |
| D | Aggregate/child = UUID (16-byte), supporting = bigint (8-byte). Mixed index widths. FKs cross boundary. |

### Relationships

| Option | Impact |
|--------|--------|
| A | All FKs homogeneous bigint. Morph IDs are bigint. Simple. |
| B | All FKs homogeneous UUID. Morph IDs are UUID. Requires morph ID type change. |
| C | All FKs homogeneous ULID. Morph IDs are ULID. |
| D | Most FKs UUID, some bigint. Morph IDs need special handling (morph targets have different ID types). |

### Imports / data acquisition

| Option | Impact |
|--------|--------|
| A | `matching_entity_id` in pending_imports changes from UUID to bigint. Entity matching uses bigint IDs. Simpler FK joins. |
| B | `matching_entity_id` stays UUID. Entity matching uses UUID IDs. Consistent with staging design. |
| C | `matching_entity_id` changes to ULID. All existing UUID references in 06-data-acquisition.md change. |
| D | `matching_entity_id` needs type awareness — aggregate matches are UUID, supporting matches are bigint. More complex staging. |

### Search projections (Typesense)

| Option | Impact |
|--------|--------|
| A | Typesense doc IDs become `"12345"` (bigint cast to string). PRODUCT-EXPERIENCE-ARCHITECTURE.md references "Programme UUID" / "Institution UUID" as doc IDs — these become mislabeled. Scout's `getScoutKey()` returns PK value; works with bigint. |
| B | Typesense doc IDs remain UUID strings. PRODUCT-EXPERIENCE-ARCHITECTURE.md wording is correct. Scout works. |
| C | Typesense doc IDs become ULID strings. PRODUCT-EXPERIENCE-ARCHITECTURE.md wording needs update. |
| D | Typesense doc IDs for aggregate roots are UUID, supporting entity IDs are bigint. Most search projections are on aggregate roots, so this works. |

### URLs

| Option | Impact |
|--------|--------|
| A | URLs use slugs (already defined). PK type is irrelevant to URLs. |
| B | URLs use slugs. UUID available as alternative opaque identifier if needed for API. |
| C | URLs use slugs. ULID available as time-sortable opaque identifier. |
| D | URLs use slugs. UUID available for aggregate roots. |

### History/versioning

| Option | Impact |
|--------|--------|
| A | spatie/laravel-activitylog uses bigint PK (default). No change needed. |
| B | Activity log subject_id would need to accommodate UUID. Spatie supports this via `->uuidMorphs()`. |
| C | Activity log would need ULID morphs. Custom work. |
| D | Activity log needs mixed morphs. More complex. |

### Application code

| Option | Impact |
|--------|--------|
| A | Zero deviation from Laravel convention. No trait, no custom casts, no migration overrides. `$model->id` is int. |
| B | Every model needs `UsesUuid` trait or equivalent. Migrations use `$table->uuid('id')->primary()`. Route model binding works with UUID. `$model->id` is string. |
| C | Every model needs `UsesUlid` trait. Migrations use `$table->char('id', 26)->primary()`. Route model binding works. `$model->id` is string. More custom code. |
| D | Aggregate/child models use UUID trait. Supporting models use default. Migration and model code is heterogeneous. |

### Laravel ecosystem fit

| Option | Impact |
|--------|--------|
| A | Perfect fit. Eloquent, Scout, Spatie, Filament all default to bigint auto-increment. |
| B | Good fit. Laravel supports UUID PKs. Spatie packages support UUID subjects. Scout works. Filament supports UUID keys. Minor configuration overhead. |
| C | Moderate fit. Laravel has no built-in ULID migration helper. Requires custom implementation. Higher risk of package incompatibility. |
| D | Moderate fit. Mixed PK types require careful handling in shared infrastructure (activity log, scout). |

### External data acquisition

| Option | Impact |
|--------|--------|
| A | External sources provide name/code-based identifiers (JAMB code, NUC code). These are stored as attributes, not PKs. Entity matching is by business attributes, not PK. bigint PK is assigned on insert. |
| B | UUID PK is generated on insert. External identifiers stored as attributes. Same matching strategy. UUID provides no advantage for external matching (external sources don't provide UUIDs). |
| C | Same as B, but ULID is time-sortable — minor advantage for chronological queries on staging data. |
| D | Same as B for aggregates, A for supporting entities. |

### Entity matching

| Option | Impact |
|--------|--------|
| A | Matching by business attributes (JAMB code, name, state). PK assigned after match. Simple. |
| B | Matching by business attributes. UUID PK assigned after match. UUID provides globally unique identity — useful if entities are referenced across system boundaries (future API consumers, data exports). |
| C | Matching by business attributes. ULID PK assigned. Time-sortability useful for import ordering. |
| D | Same as B for aggregates, A for supporting. |

### Debugging/operations

| Option | Impact |
|--------|--------|
| A | `id = 12345` — easy to read, copy, communicate. Log entries are short. |
| B | `id = 550e8400-e29b-41d4-a716-446655440000` — harder to read, longer logs. But globally unique — no collision risk across environments/tables. |
| C | `id = 01H5S2YJA00000000000000000` — shorter than UUID, time-prefix aids debugging chronology. |
| D | Aggregate entities have long UUID IDs, supporting entities have short bigint IDs. Inconsistent but manageable. |

### Storage/index efficiency

| Option | Impact |
|--------|--------|
| A | bigint = 8 bytes. B-tree index depth is minimal for ~10K-100K entities. FK joins are fast. Storage minimal. |
| B | UUID = 16 bytes. 2× storage for PK+FK columns. B-tree index slightly deeper. Negligible for StudyNexus scale (tens of thousands, not billions). PostgreSQL handles UUID natively via `uuid` type (not varchar). |
| C | ULID = 26 bytes as string (or 16 bytes as binary). String storage is larger. Binary representation possible but requires custom handling. |
| D | Most tables use UUID (16 bytes). Supporting tables use bigint (8 bytes). FK joins crossing boundary need type conversion. |

## 5. Recommendation

**Recommendation: Option A — bigint auto-increment for all domain entities.**

Rationale:

1. **Laravel convention alignment.** Every package in the stack (Eloquent, Scout, Spatie, Filament, ActivityLog) defaults to bigint auto-increment. Zero configuration overhead, zero custom traits, zero migration overrides.

2. **StudyNexus does not need UUID for its actual requirements:**
   - **External data acquisition:** External sources identify entities by business attributes (JAMB code, NUC code, name), not by UUID. Entity matching is attribute-based, not PK-based.
   - **Distributed/external processing:** StudyNexus is a monolith with queued jobs, not a distributed microservice system. There is no cross-service PK collision risk.
   - **Public URLs:** Already solved by slugs, not PKs.
   - **Typesense doc IDs:** Scout's `getScoutKey()` works with any PK type. The doc ID being `"12345"` vs `"550e8400..."` is functionally equivalent.
   - **Canonical identity:** Entity identity is defined by domain attributes (name + type for Institution, name + award type + institution for Programme), not by a synthetic PK.

3. **The UUID signals in documentation are weak or misattributed:**
   - disciplines/cut_off_marks having UUID PK in 03-domain.md appears to be an artifact of the domain discovery process (these were the last tables designed, under "search optimization" context), not a deliberate PK strategy decision.
   - 06-data-acquisition.md's `matching_entity_id UUID` is a staging design choice, not a domain PK declaration — it can be changed to bigint.
   - PRODUCT-EXPERIENCE-ARCHITECTURE.md's "Institution UUID" / "Programme UUID" are Typesense document ID labels, not domain PK declarations.
   - archive/21-domain-architecture-frozen-baseline.md is superseded by canonical documents; it records an intermediate design, not a final decision.

4. **Cost of UUID is real but benefit is marginal for this scale.** At tens of thousands of entities, the storage/index penalty of UUID is negligible — but the development overhead (custom traits, non-default migration patterns, package configuration) is not negligible.

**However**, this recommendation is labeled as a recommendation, not an existing decision. The documents are genuinely ambiguous. A team that prefers UUID for future-proofing (API design, data export, multi-tenant readiness) has a valid argument. The key constraint is: **this must be decided before any migration is written.**

## 6. Implementation Impact

| Reconciliation Change | Depends on BD-1 | Nature of Dependency |
|----------------------|-----------------|---------------------|
| All 45 proposed changes in 05-implementation-RECONCILIATION-PROPOSAL.md | Yes | Every FK type declaration assumes bigint |
| IMPLEMENTATION-MODEL-RECONCILIATION.md schema | Yes | All PK/FK declarations assume bigint |
| Change 4 (AdmissionCycle FK) | Yes | `education_authority_id bigint FK` |
| Change 5 (AccreditationRecord morph) | Yes | `accreditable_id bigint (morph)` |
| Change 6 (InformationSource FK direction) | Yes | `information_source_id bigint FK` |
| Change 27 (add provenance FKs) | Yes | All `information_source_id bigint FK` |
| Change 31 (replace morph with FK) | Yes | `scholarship_provider_id bigint FK` |
| 06-data-acquisition.md `matching_entity_id` | Yes | Currently UUID — must change if bigint |
| Typesense collection schemas | Yes | Doc ID format changes |

## 7. Dependency

**BD-1 has no dependencies on other decisions.** It is the most foundational — all other decisions assume a PK type. BD-1 must be resolved first.

---

# BD-2 — Morph Type Convention

## 1. Current Evidence

### Polymorphic columns in the system

| Column | Table | Morph Targets | Documented In |
|--------|-------|---------------|---------------|
| `organization_type` | organization_members | Institution, ScholarshipProvider, EducationAuthority | 05-implementation.md, 04-architecture.md, 02-decisions.md |
| `governable_type` | admission_policies | Programme, Institution | 02-decisions.md (ADR-11), IMPLEMENTATION-MODEL-RECONCILIATION.md |
| `accreditable_type` | accreditation_records | Programme, Institution | 02-decisions.md (ADR-11), IMPLEMENTATION-MODEL-RECONCILIATION.md |
| `saveable_type` | saves | Institution, Programme, Scholarship | 04-architecture.md |
| `followable_type` | follows | Institution, Programme, Scholarship | 04-architecture.md |
| `likeable_type` | likes | Institution, Programme, Scholarship | 04-architecture.md |

### Evidence of short aliases

05-implementation.md line 284: `organization_type string (morph: 'institution', 'scholarship_provider', 'education_authority')`

### Evidence of FQCN

04-architecture.md line 224: `organization_type (morph: 'App\Domain\Models\Institution')`
02-decisions.md line 449: `organization_type (morph, e.g., App\Domain\Models\Institution)`

### Reconciliation deliverable values

IMPLEMENTATION-MODEL-RECONCILIATION.md line 355: `governable_type string (morph) — 'Programme' or 'EducationalInstitution'`
IMPLEMENTATION-MODEL-RECONCILIATION.md line 378: `accreditable_type string (morph) — 'Programme' or 'EducationalInstitution'`

These use unqualified class names (neither short alias nor FQCN) — a third convention.

### Laravel default behavior

Without `Relation::enforceMorphMap()`, Laravel stores the fully qualified class name (e.g., `App\Models\Institution`) in `_type` columns. With `Relation::enforceMorphMap()`, Laravel stores short aliases defined in `App\Providers\AppServiceProvider`.

### No configuration specified

No document defines `Relation::enforceMorphMap()` or any morph map configuration.

## 2. Contradictions

| Contradiction | Documents |
|---------------|-----------|
| Short aliases (`'institution'`) | 05-implementation.md |
| FQCN (`App\Domain\Models\Institution`) | 04-architecture.md, 02-decisions.md |
| Unqualified class name (`'Programme'`, `'EducationalInstitution'`) | IMPLEMENTATION-MODEL-RECONCILIATION.md |
| Laravel default (FQCN `App\Models\Institution`) | Implicit — no morphMap configured |

Three different conventions exist across documents, and none matches Laravel's actual default behavior for the project's model namespace.

## 3. Options

### Option A: Laravel default — FQCN stored in _type columns

- `_type` values: `App\Models\Institution`, `App\Models\Programme`, etc.
- No `Relation::enforceMorphMap()` needed
- Fragile to model namespace renames (if `App\Models` becomes `App\Domain\Institutions`, all _type values change)
- Most compatible with existing 02-decisions.md and 04-architecture.md (which use FQCN)

### Option B: Short aliases via morphMap

- `_type` values: `institution`, `programme`, `scholarship`, `scholarship_provider`, `education_authority`
- Requires `Relation::enforceMorphMap()` in AppServiceProvider
- Resilient to model namespace renames
- Most compatible with 05-implementation.md
- Requires migration to convert any existing FQCN values to short aliases

### Option C: Unqualified class names via morphMap

- `_type` values: `Institution`, `Programme`, `ScholarshipProvider`
- Requires `Relation::enforceMorphMap()`
- Compromise: more readable than FQCN, more specific than short aliases
- Currently used in IMPLEMENTATION-MODEL-RECONCILIATION.md
- Risk: collision if two models have the same short name in different namespaces

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A | No domain impact. Morph types are implementation details. |
| B | No domain impact. Morph types are implementation details. |
| C | No domain impact. Morph types are implementation details. |

### Database schema

| Option | Impact |
|--------|--------|
| A | `_type` columns store long strings (30-40 chars). Slightly more storage. Migration `where` clauses on `_type` are verbose. |
| B | `_type` columns store short strings (10-25 chars). Less storage. Migration `where` clauses are concise. Requires morphMap config. |
| C | `_type` columns store medium strings (15-25 chars). Requires morphMap config. Risk of name collision. |

### Relationships

| Option | Impact |
|--------|--------|
| A | Standard Laravel. No special handling. |
| B | `Relation::enforceMorphMap()` makes short aliases mandatory. Attempting to store FQCN throws exception. |
| C | Same as B but with different map values. |

### Imports

| Option | Impact |
|--------|--------|
| A | Import code must set `_type` to FQCN string. Fragile to namespace changes. |
| B | Import code sets `_type` to short alias. Robust. |
| C | Import code sets `_type` to unqualified name. |

### Application code

| Option | Impact |
|--------|--------|
| A | Zero custom code. Laravel default. |
| B | One-time `Relation::enforceMorphMap()` definition in AppServiceProvider. All models listed once. |
| C | Same as B. Slightly more care needed to avoid collisions. |

### Laravel ecosystem fit

| Option | Impact |
|--------|--------|
| A | Perfect. All packages expect this. |
| B | Excellent. `enforceMorphMap` is a first-class Laravel feature. All major packages (Spatie, Filament) support it. |
| C | Good. Same mechanism as B. |

## 5. Recommendation

**Recommendation: Option B — Short aliases via morphMap.**

Rationale:

1. **Namespace resilience.** If models move from `App\Models` to `App\Domain\Institutions\Models`, short aliases remain unchanged. FQCN values require a data migration on every namespace change.

2. **Data migration safety.** Short aliases are stable across refactors. FQCN values are coupled to code structure.

3. **Readability.** `WHERE organization_type = 'institution'` is more readable than `WHERE organization_type = 'App\Domain\Models\Institution'`.

4. **Laravel support.** `Relation::enforceMorphMap()` is official, documented, and recommended for production applications.

5. **Consistent with 05-implementation.md.** The implementation blueprint already uses short aliases. Reconciling to short aliases requires no 05 correction for this concern.

## 6. Implementation Impact

| Reconciliation Change | Depends on BD-2 | Nature of Dependency |
|----------------------|-----------------|---------------------|
| Change 5 (AccreditationRecord morph) | Yes | `accreditable_type` value format |
| AdmissionPolicy morph | Yes | `governable_type` value format |
| OrganizationMember morph | Yes | `organization_type` value format |
| Engagement morphs (saves, follows, likes) | Yes | `saveable_type`, `followable_type`, `likeable_type` value format |
| 06-data-acquisition.md import code | Yes | Sets `_type` values during import |

## 7. Dependency

**BD-2 depends on BD-1.** If PKs are UUID, morph `_id` columns are UUID. If PKs are bigint, morph `_id` columns are bigint. The morph type convention is independent of PK type, but the morph ID column type is determined by BD-1.

---

# BD-3 — AdmissionCycle Phase Storage

## 1. Current Evidence

### 03-domain.md (canonical): PhaseSequence Value Object

- **VO definition** (line 81): `PhaseSequence — Ordered list of admission cycle phases with timing. Phase names and count are data (Nigeria: Registration → Examination → Results → Admission; UK UCAS: Application → Decisions → Reply → Clearing). Implementation: Immutable PHP Object + JSON Cast`
- **Domain method** (line 319): `announce(period, authorityId, phaseSequence, startDate, endDate): void` — accepts PhaseSequence as parameter
- **Domain method** (line 321): `advancePhase(): void` — Advances to next phase in sequence. Enforces INV-C2 (no backwards, no skipping).
- **State machine** (line 325): `Within Active, phase advances sequentially through the configured PhaseSequence`
- **Invariant** (line 242): `INV-C2: Phase transitions follow the defined sequence (no backwards, no skipping) — advancePhase() — HIGH`
- **Domain event** (line 144): `AdmissionCyclePhaseAdvanced | Admission Cycle | advancePhase() | cycleId, previousPhase, currentPhase, occurredAt`
- **Domain action** (line 176): `AdvanceAdmissionCyclePhase`

### 05-implementation.md: Separate timestamp columns

- **Table schema** (line 260): `admission_cycles: id, institution_id FK, name, admission_pathway (string), academic_year, opens_at, closes_at, results_at, status, created_at, updated_at`
- **No PhaseSequence column.** No `current_phase` column. No `phases` JSON column. Three timestamps (`opens_at`, `closes_at`, `results_at`) represent a hardcoded 3-phase model.

### archive/19-domain-architecture.md (intermediate): Both approaches

- **Line 237**: `phase_sequence (PhaseSequence VO cast), current_phase_index`
- **Line 308**: `AdmissionCycle: phase_sequence → PhaseSequence VO, status → AdmissionCycleStatus enum`
- **Line 356**: `PhaseSequence: Immutable PHP Object + JSON Cast — App\Domain\ValueObjects\PhaseSequence — Ordered list of phases; JSON preserves ordering`

### IMPLEMENTATION-MODEL-RECONCILIATION.md (reconciled): JSON column

- **Line 333**: `phases json (PhaseSequence VO) — Ordered phases`
- **Line 132**: `PhaseSequence: Ordered sequence of phases within an AdmissionCycle — 05 missing — ADDED`

## 2. Contradictions

| Aspect | 03-domain.md | 05-implementation.md | Resolution |
|--------|-------------|---------------------|------------|
| Phase storage | PhaseSequence VO (JSON cast) | 3 separate timestamp columns | 03-domain.md governs |
| Current phase tracking | `advancePhase()` + `current_phase_index` | Not tracked | 03-domain.md governs |
| Phase flexibility | Data-driven (N phases, any names) | Hardcoded 3 phases (opens/closes/results) | 03-domain.md governs |
| `advancePhase()` operation | Defined with INV-C2 | Not implementable (no sequence to advance) | 03-domain.md governs |
| Domain event `AdmissionCyclePhaseAdvanced` | Defined with payload | Cannot be emitted | 03-domain.md governs |

The 05-implementation.md approach hardcodes a 3-phase model (opens → closes → results) that cannot represent the actual Nigerian admission cycle phases (Registration → Examination → Results → Admission) or any variation.

## 3. Options

### Option A: PhaseSequence VO as JSON column (03-domain.md position)

- `admission_cycles.phases` = JSON column storing PhaseSequence VO
- `admission_cycles.current_phase` = string or int tracking current position
- PhaseSequence VO: `[{name: "Registration", starts_at: "...", ends_at: "..."}, {name: "Examination", ...}, ...]`
- `advancePhase()` operates on the sequence
- INV-C2 enforceable: next phase must be next in sequence
- Flexible: any number of phases, any names, any ordering

### Option B: Separate timestamp columns (05-implementation.md position)

- `admission_cycles.opens_at`, `closes_at`, `results_at` = 3 timestamp columns
- Hardcoded 3-phase model
- No `advancePhase()` possible (no sequence to advance)
- No `AdmissionCyclePhaseAdvanced` event
- INV-C2 not enforceable
- Simple queries: `WHERE opens_at <= NOW() AND closes_at > NOW()`
- Cannot represent actual Nigerian cycle phases

### Option C: Separate `admission_cycle_phases` child table

- Normalized child table: `admission_cycle_phases(id, admission_cycle_id, name, order, starts_at, ends_at, status)`
- Each phase is a row
- `advancePhase()` updates current phase on parent
- INV-C2 enforceable via order column
- More queryable than JSON (SQL WHERE on phase dates)
- More complex: additional table, additional model, additional migration

### Option D: Hybrid — PhaseSequence JSON for structure + denormalized current phase

- `admission_cycles.phases` = JSON (PhaseSequence VO) for the sequence definition
- `admission_cycles.current_phase` = string (name of current phase)
- `admission_cycles.opens_at`, `closes_at` = denormalized from current phase boundaries for simple queries
- `advancePhase()` updates both JSON-managed state and denormalized columns
- Most complex but most queryable

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A | Full domain fidelity. PhaseSequence VO, advancePhase(), INV-C2, AdmissionCyclePhaseAdvanced event all work. |
| B | Domain model broken. PhaseSequence VO cannot be implemented. advancePhase() cannot be implemented. INV-C2 cannot be enforced. Event cannot be emitted. |
| C | Domain model works. PhaseSequence concept split across rows. advancePhase() works. INV-C2 enforceable. |
| D | Domain model works. PhaseSequence VO + denormalized columns. advancePhase() updates both. |

### Database schema

| Option | Impact |
|--------|--------|
| A | 1 JSON column + 1 current_phase column. Phases are not individually queryable by SQL. |
| B | 3 timestamp columns. Simple. Cannot represent >3 phases. |
| C | New child table + FK. Each phase is a row. Fully queryable. |
| D | JSON + current_phase + 2 denormalized timestamps. Moderate complexity. |

### Relationships

| Option | Impact |
|--------|--------|
| A | No new relationships. PhaseSequence is a VO, not an entity. |
| B | No new relationships. |
| C | AdmissionCycle hasMany AdmissionCyclePhase (new child entity). Changes aggregate boundary — phases become child entities. |
| D | No new relationships. |

### Imports

| Option | Impact |
|--------|--------|
| A | Import must construct PhaseSequence JSON from source data. JAMB brochures define phases implicitly by date ranges. |
| B | Import sets 3 timestamps. Simpler but lossy. |
| C | Import creates phase rows. More INSERT statements. |
| D | Import constructs JSON + sets denormalized columns. |

### Search projections

| Option | Impact |
|--------|--------|
| A | Typesense can index current_phase as a string facet. Phase dates in JSON are not individually searchable. |
| B | Typesense can index opens_at/closes_at as date fields. |
| C | Typesense can index current phase name and dates from child records. |
| D | Typesense indexes current_phase + denormalized dates. Best of both. |

### Application code

| Option | Impact |
|--------|--------|
| A | PhaseSequence VO class with JSON cast. advancePhase() method. ~50 lines of VO code. |
| B | No VO needed. Simple timestamp comparisons. ~5 lines. But domain operations are lost. |
| C | AdmissionCyclePhase model + migration. Phase management via Eloquent. ~100 lines. |
| D | PhaseSequence VO + denormalized column sync. ~80 lines. |

## 5. Recommendation

**Recommendation: Option A — PhaseSequence VO as JSON column.**

Rationale:

1. **03-domain.md is authoritative.** The domain model explicitly defines PhaseSequence as a VO with JSON cast, advancePhase() as a domain operation, and INV-C2 as a high-priority invariant. Option B (05-implementation.md) cannot implement these.

2. **Pragmatic Laravel idiom.** JSON casts for VOs are the Beyond CRUD pattern used throughout the domain model (MonetaryAmount, Location, etc.). PhaseSequence is consistent with this pattern.

3. **The Nigerian reality requires flexible phases.** UTME cycles have Registration → Examination → Results → Admission. Post-UTME cycles have Application → Screening → Results. Direct Entry has Application → Assessment → Admission. A hardcoded 3-column model cannot represent these variations.

4. **SQL queryability is not needed for phase data.** The UI needs to display current phase and its dates. The admin needs to see the full sequence. Neither requires `WHERE phase_start > X` across cycles. The primary query is `WHERE status = Active`, with current phase retrieved from the JSON.

5. **Option C (child table) over-normalizes a Value Object.** PhaseSequence is a VO, not an entity. Making it a child table introduces an entity boundary that the domain model does not define, violating the aggregate boundary established in 03-domain.md.

## 6. Implementation Impact

| Reconciliation Change | Depends on BD-3 | Nature of Dependency |
|----------------------|-----------------|---------------------|
| Change 4 (AdmissionCycle schema) | Yes | Phase column definition |
| admission_cycles migration | Yes | Column list changes |
| PhaseSequence VO implementation | Yes | Code depends on storage format |
| AdvanceAdmissionCyclePhase action | Yes | Operation depends on VO |
| AdmissionCyclePhaseAdvanced event | Yes | Payload depends on VO |
| Typesense admission cycle collection | Yes | Indexable fields change |

## 7. Dependency

**BD-3 depends on D1.** If AdmissionCycle belongsTo Institution (D1 = Institution), the phase model may differ from if it belongsTo EducationAuthority. Authority-scoped cycles (JAMB) have standardized national phases; institution-scoped cycles may have more variable phases. This affects the PhaseSequence default template but not the storage mechanism.

---

# BD-4 — Deletion/Cascade Strategy

## 1. Current Evidence

### Domain-level lifecycle operations (NOT deletion)

03-domain.md defines terminal state transitions for every entity. These are **status changes**, not deletions:

| Entity | Terminal Operation | Terminal State | Cascade Effect |
|--------|-------------------|----------------|----------------|
| Institution | `close()` | Closed | Programmes discontinued + Scholarships flagged (via events) |
| Programme | `discontinue()` | Discontinued | Scholarships flagged (via event) |
| Scholarship | `withdraw()` / `expire()` | Withdrawn / Expired | None |
| AdmissionCycle | `close()` / `archive()` | Closed / Archived | Policies become historical |
| InformationSource | `deprecate()` | Deprecated | Trust signal cascade |
| Qualification | `deprecate()` | Deprecated | Prevents new references |
| ScholarshipProvider | `deprecate()` | Deprecated | Prevents new scholarships |
| EducationAuthority | `deprecate()` | Deprecated | Prevents new references |

### Soft deletes: zero mentions in canonical documents

No canonical document (02, 03, 04, 05) mentions `deleted_at`, `SoftDeletes`, or soft delete.

Archive document (19-domain-architecture.md line 937): "Soft deletes ONLY for admin safety on aggregate roots. Child entities follow parent lifecycle. Supporting entities use deprecation (status flag), not soft delete."

### FK ON DELETE rules (only 5 defined out of ~20+)

| FK Relationship | Rule | Document |
|-----------------|------|----------|
| `cut_off_marks.programme_instance_id → programme_instances` | ON DELETE CASCADE | 03-domain.md, 05-implementation.md |
| `cut_off_marks.admission_cycle_id → admission_cycles` | ON DELETE CASCADE | 03-domain.md, 05-implementation.md |
| `cut_off_marks.source_id → information_sources` | ON DELETE SET NULL | 03-domain.md, 05-implementation.md |
| `organization_members.user_id → users` | cascade delete | 05-implementation.md |
| `articles.institution_id → institutions` | nullOnDelete | 05-implementation.md |

All other FKs have **no ON DELETE rule specified**.

### Immutable entities

03-domain.md states AccreditationRecords are "immutable child entities; never deleted." AdmissionPolicies "become historical" on cycle closure.

## 2. Contradictions

| Contradiction | Description |
|---------------|-------------|
| Domain model says close/deprecate, not delete | 03-domain.md defines terminal states for every entity |
| 05-implementation.md has some cascade rules | cut_off_marks cascade, articles nullOnDelete — but majority undefined |
| No soft delete policy | Canonical docs silent; archive says "only for admin safety on aggregate roots" |
| No comprehensive FK ON DELETE spec | Only 5 of ~20+ FKs have rules |
| Admin workflow unclear | Can an admin hard-delete an Institution? Or only close it? |

## 3. Options

### Option A: Status-based lifecycle only — no hard deletes, no soft deletes

- All aggregate roots and supporting entities use status transitions (close/deprecate) as their only "removal" mechanism
- No `deleted_at` column on any table
- FK ON DELETE: `RESTRICT` on all domain FKs (prevent accidental hard deletion)
- Admin UI: "Delete" button performs status transition, not SQL DELETE
- Content/infrastructure tables (articles, notifications, jobs) may allow hard delete
- Rationale: The domain model already defines complete lifecycle for every entity

### Option B: Soft deletes on aggregate roots + status lifecycle

- Aggregate roots get `deleted_at` (SoftDeletes trait) as admin safety net
- Status transitions remain the primary "removal" path
- FK ON DELETE: `RESTRICT` (soft-deleted rows remain, so FK integrity is preserved)
- Admin can soft-delete, then hard-delete after review period
- Rationale: Archive/19 recommends this pattern; provides recovery from admin mistakes

### Option C: Soft deletes on all entities

- Every table gets `deleted_at`
- FK ON DELETE: `RESTRICT` (all rows remain when soft-deleted)
- Admin can soft-delete anything
- Rationale: Maximum safety, but contradicts domain model's explicit status lifecycle

### Option D: Cascade delete for children + restrict for cross-aggregate

- Within aggregates: child entities CASCADE on parent hard-delete (e.g., AccreditationRecord CASCADE on Institution delete)
- Across aggregates: FK RESTRICT (e.g., Programme.institution_id RESTRICT — cannot delete Institution with active Programmes)
- Status lifecycle remains primary path
- Hard delete available only for empty aggregates (no active children)
- Rationale: Matches Eloquent's default behavior for `$cascadeDeletes` on hasMany

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A | Full alignment. Domain lifecycle is the only removal mechanism. No conflict between status and soft-delete. |
| B | Minor conflict: an entity can be both Closed (domain) and soft-deleted (admin). Two "inactive" states. |
| C | Major conflict: every entity has both a domain lifecycle and a soft-delete flag. Confusing. |
| D | Domain lifecycle is primary. Hard-delete is a maintenance operation, not a domain operation. |

### Database schema

| Option | Impact |
|--------|--------|
| A | No `deleted_at` columns. All FKs get `RESTRICT` ON DELETE. Simple. |
| B | 5 aggregate root tables get `deleted_at`. FKs `RESTRICT`. |
| C | All tables get `deleted_at`. FKs `RESTRICT`. |
| D | No `deleted_at`. Children CASCADE within aggregate. Cross-aggregate FKs RESTRICT. |

### Relationships

| Option | Impact |
|--------|--------|
| A | All FKs RESTRICT. Hard deletion of any entity with dependents is blocked at DB level. Admin must close/deprecate instead. |
| B | Same as A for FK constraints. Soft-deleted rows satisfy FK constraints. |
| C | Same as A. |
| D | Children auto-deleted when parent hard-deleted. Cross-aggregate references prevent deletion. |

### Imports

| Option | Impact |
|--------|--------|
| A | Import never deletes. Only creates/updates/deprecates. Simple. |
| B | Import never deletes. Soft-deletes are admin-only. |
| C | Import never deletes. Soft-deletes are admin-only. |
| D | Import never deletes. Cascade is admin-only maintenance. |

### Application code

| Option | Impact |
|--------|--------|
| A | Every model needs a `canBeDeleted()` check that validates no FK conflicts. Controllers call domain `close()`/`deprecate()` instead of `delete()`. |
| B | Aggregate roots use SoftDeletes trait. Controllers call `delete()` for soft-delete, domain methods for status change. Must distinguish `Closed` (domain) from `soft-deleted` (admin). |
| C | All models use SoftDeletes. Heavy. Many queries need `withTrashed()`. |
| D | Models define `$cascadeDeletes` for children. Controllers must check cross-aggregate FKs before hard-delete. |

### History/versioning

| Option | Impact |
|--------|--------|
| A | Activity log records status transitions. No deletion events. |
| B | Activity log records soft-deletes as events. Two deletion paths to audit. |
| C | Activity log records all soft-deletes. Heavy. |
| D | Activity log records cascading deletes. Complex audit trail. |

## 5. Recommendation

**Recommendation: Option A — Status-based lifecycle only, FK RESTRICT on all domain FKs.**

Rationale:

1. **The domain model already defines complete lifecycle.** Every entity has a terminal state. There is no need for a parallel deletion mechanism. The domain is richer than a boolean deleted/active — it distinguishes Closed from Deprecated from Withdrawn from Expired, each with different business meaning.

2. **Soft deletes add confusion.** An entity can be both "Closed" (domain state) and "soft-deleted" (admin action). Which takes precedence? Which is the "real" state? This ambiguity violates domain model clarity.

3. **RESTRICT prevents data loss.** With FK RESTRICT on all domain relationships, accidental hard deletion is impossible at the database level. The admin must close/deprecate (domain operation) rather than delete.

4. **Admin workflow is clear.** "Delete" in the admin UI = status transition (close/deprecate). "Purge" = hard-delete after entity has no dependents (maintenance operation, not primary workflow).

5. **Consistent with the archive recommendation** (with refinement). Archive/19 says "soft deletes only for admin safety on aggregate roots." Option A goes further: even aggregate roots don't need soft deletes because the status lifecycle provides the same safety (Closed is effectively "soft-deleted" from a business perspective, and can be reversed with a `reopen()` operation if needed).

## 6. Implementation Impact

| Reconciliation Change | Depends on BD-4 | Nature of Dependency |
|----------------------|-----------------|---------------------|
| All FK declarations in all migrations | Yes | ON DELETE clause for every FK |
| Change 5 (AccreditationRecord morph) | Yes | ON DELETE for morph FK |
| Change 6 (InformationSource FK) | Yes | ON DELETE for information_source_id |
| Admin UI delete buttons | Yes | Delete action behavior |
| Filament resource configuration | Yes | `canDelete()` policy |

## 7. Dependency

**BD-4 has no dependencies on other decisions.** It is independent of PK type, morph convention, ownership, or phase storage. It governs FK behavior, which applies regardless of FK type.

---

# D1 — AdmissionCycle Ownership

## 1. Current Evidence

### 03-domain.md (canonical): AdmissionCycle belongsTo EducationAuthority

- **Relationship table** (line 431): `AdmissionCycle belongsTo EducationAuthority | N:1 | Authority defines the cycle and its scope | Authority deprecation prevents new cycles; existing unaffected`
- **Domain method** (line 319): `announce(period, authorityId, phaseSequence, startDate, endDate)` — takes `authorityId`, not `institutionId`
- **Domain event** (line 143): `AdmissionCycleAnnounced` payload includes `cycleId, authorityId, period, occurredAt`
- **Cross-aggregate reference** (line 327): `References Education Authority (FK)`

### 05-implementation.md: AdmissionCycle belongsTo Institution

- **Aggregate root definition** (line 146): `AdmissionCycle -- ... Relationships: belongsTo Institution, hasMany AdmissionPolicies`
- **Table schema** (line 260): `admission_cycles: id, institution_id FK, name, ...`
- **Filament navigation** (line 401-404): Admission Cycles nested under Programmes group (institution context)

### Supporting documents

- **02-decisions.md / 04-architecture.md**: Consistent with 03-domain.md (EducationAuthority)
- **archive/19-domain-architecture.md** (line 233-236): `References: defining_authority_id (belongsTo EducationAuthority)`
- **IMPLEMENTATION-MODEL-RECONCILIATION.md** (line 51): `belongsTo EducationAuthority (FK: education_authority_id) — 05 had belongsTo Institution — CHANGED`
- **BASELINE-RECONCILIATION-AUDIT.md**: F-C04 CRITICAL, Classification C

### Nigerian education reality

JAMB (Joint Admissions and Matriculation Board) defines the national UTME admission cycle. This is an EducationAuthority-scoped cycle. However, individual institutions also define their own Post-UTME screening cycles and Direct Entry assessment windows. These are institution-scoped cycles.

**03-domain.md's model captures the JAMB cycle but not the institutional sub-cycles. 05-implementation.md's model captures institutional cycles but not the JAMB authority-level cycle.**

## 2. Contradictions

| Aspect | 03-domain.md | 05-implementation.md |
|--------|-------------|---------------------|
| FK column | `education_authority_id` | `institution_id` |
| Owner entity | EducationAuthority | Institution |
| Domain method param | `authorityId` | (not defined) |
| Event payload | `authorityId` | (not defined) |
| Admin scope | Authority-level admins manage cycles | Institution-level admins manage cycles |
| Canonical cluster support | 02, 04, archive/19 all agree | 05 only |

## 3. Options

### Option A: AdmissionCycle belongsTo EducationAuthority (03-domain.md position)

- FK: `education_authority_id → education_authorities`
- AdmissionCycle is authority-scoped
- Authority admins create and manage cycles
- Domain methods work as defined: `announce(..., authorityId, ...)`
- Institutional sub-cycles (Post-UTME, Direct Entry) would need a different mechanism (e.g., AdmissionPolicy with institution scope, or a separate entity)

### Option B: AdmissionCycle belongsTo Institution (05-implementation.md position)

- FK: `institution_id → institutions`
- AdmissionCycle is institution-scoped
- Institution admins create and manage cycles
- Domain method `announce()` would change to take `institutionId` instead of `authorityId`
- JAMB national cycle cannot be represented (JAMB is not an Institution)
- Contradicts 03-domain.md, 02-decisions.md, 04-architecture.md, archive/19

### Option C: AdmissionCycle belongsTo EducationAuthority + Institution scope via AdmissionPolicy

- FK: `education_authority_id → education_authorities` (AdmissionCycle)
- Institution-specific admission details are modeled through AdmissionPolicy (which already has polymorphic `governable_type` for Programme/Institution)
- Authority defines the cycle (dates, phases); Institution defines its policies within that cycle
- AdmissionPolicy.governable_type = 'institution' allows institution-level admission rules
- Matches 03-domain.md + uses existing polymorphism

### Option D: AdmissionCycle has both FKs (hybrid)

- `education_authority_id` (nullable FK) — for authority-level cycles (JAMB UTME)
- `institution_id` (nullable FK) — for institution-level cycles (Post-UTME, DE)
- Constraint: exactly one must be non-null
- Most flexible but most complex
- Changes AdmissionCycle from a simple N:1 relationship to a dual-scoped entity
- Breaks the aggregate root definition (which aggregate boundary?)

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A | Domain model unchanged. 03-domain.md is correct as-is. Institutional sub-cycles not modeled (may need future ADR). |
| B | Domain model must change. `announce()` signature changes. Event payload changes. Authority-scoped cycles cannot be represented. |
| C | Domain model unchanged. AdmissionPolicy's existing polymorphism handles institution scope. Clean separation of concerns. |
| D | Domain model changes. AdmissionCycle becomes dual-scoped. New invariant needed: exactly one FK is non-null. Aggregate boundary unclear. |

### Database schema

| Option | Impact |
|--------|--------|
| A | `admission_cycles.education_authority_id` (FK). Simple. |
| B | `admission_cycles.institution_id` (FK). Simple. |
| C | `admission_cycles.education_authority_id` (FK). No schema change for AdmissionCycle. AdmissionPolicy already has morph columns. |
| D | Two nullable FK columns. Check constraint. More complex. |

### Relationships

| Option | Impact |
|--------|--------|
| A | EducationAuthority hasMany AdmissionCycle. Institution has no direct cycle relationship. |
| B | Institution hasMany AdmissionCycle. EducationAuthority has no direct cycle relationship. |
| C | EducationAuthority hasMany AdmissionCycle. Institution → AdmissionPolicy (via morph). Both connected appropriately. |
| D | Both entities have hasMany AdmissionCycle. AdmissionCycle is dual-owned. |

### Imports

| Option | Impact |
|--------|--------|
| A | JAMB imports create authority-scoped cycles. Institution imports do not create cycles. |
| B | Institution imports create institution-scoped cycles. JAMB cycle not importable. |
| C | JAMB imports create authority-scoped cycles. Institution imports create AdmissionPolicies within those cycles. |
| D | Both import paths work. Most flexible. |

### Search projections

| Option | Impact |
|--------|--------|
| A | Search can facet by education authority. Cannot facet by institution (no direct link). |
| B | Search can facet by institution. Cannot facet by education authority. |
| C | Search can facet by authority (via cycle) and by institution (via policy morph). |
| D | Both facets available. |

### URLs

| Option | Impact |
|--------|--------|
| A | `/authorities/{slug}/cycles/{slug}` or `/cycles/{slug}` |
| B | `/institutions/{slug}/cycles/{slug}` |
| C | `/cycles/{slug}` (authority-scoped); institution policies at `/institutions/{slug}/policies/` |
| D | Both URL patterns needed. |

### Application code

| Option | Impact |
|--------|--------|
| A | Minimal change. Filament resource scoped to EducationAuthority. |
| B | Significant change. Domain methods, events, actions all change. |
| C | No domain change. Filament resources: AdmissionCycleResource scoped to authority, AdmissionPolicyResource scoped to institution. |
| D | Most code change. Dual-scope logic, nullable FK checks, conditional queries. |

## 5. Recommendation

**Recommendation: Option C — AdmissionCycle belongsTo EducationAuthority + Institution scope via AdmissionPolicy.**

Rationale:

1. **Preserves the canonical domain model.** 03-domain.md's AdmissionCycle definition is correct as-is. No domain methods, events, or invariants change.

2. **Handles the Nigerian reality.** JAMB defines the national cycle (authority-scoped). Institutions define their policies within that cycle (institution-scoped via AdmissionPolicy's existing `governable_type` polymorphism). This is exactly how the domain model was designed — AdmissionPolicy's polymorphism exists for this purpose.

3. **No new entities or FKs.** The admission_cycles table gets `education_authority_id` (as 03-domain.md defines). AdmissionPolicy already has `governable_type` + `governable_id`. No schema additions needed.

4. **Clean aggregate boundary.** AdmissionCycle belongsTo EducationAuthority. AdmissionPolicy belongsTo AdmissionCycle with polymorphic governable. No ambiguity.

5. **Option D (dual FK) is anti-pattern.** Two nullable FKs with a mutual exclusion constraint violates the single-responsibility principle for aggregate roots and makes the aggregate boundary unclear.

## 6. Implementation Impact

| Reconciliation Change | Depends on D1 | Nature of Dependency |
|----------------------|---------------|---------------------|
| Change 4 (AdmissionCycle FK) | Yes | FK direction: education_authority_id vs institution_id |
| admission_cycles migration | Yes | Column definition |
| Filament AdmissionCycleResource | Yes | Scoping and navigation |
| AnnounceAdmissionCycle action | Yes | Parameter: authorityId vs institutionId |
| AdmissionCycleAnnounced event | Yes | Payload: authorityId vs institutionId |
| 06-data-acquisition.md import | Yes | JAMB imports create authority-scoped cycles |

## 7. Dependency

**D1 depends on BD-1.** The FK column type (bigint vs UUID) is determined by BD-1.

D1 does not depend on BD-3 (phase storage works the same regardless of owner), though D1 may influence the default PhaseSequence template (authority cycles have standardized national phases; institutional policies don't need phases).

---

# D3 — Scholarship Provider Relationship

## 1. Current Evidence

### 03-domain.md (canonical): Scholarship belongsTo ScholarshipProvider (direct FK)

- **Relationship table** (line 426): `Scholarship belongsTo ScholarshipProvider | N:1 | Provider is part of scholarship identity (INV-S1) | Provider deprecation prevents new scholarships; existing unaffected`
- **Invariant INV-S1** (line 35): `A Scholarship has exactly one Provider` — enforced by FK constraint
- **ProviderType enum**: `Government, Corporate, NGO, Institution` (no "Other")
- **Domain action** (line 170-171): `AnnounceScholarship: Announce a new scholarship with provider validation | Authorization + provider validation`

### 05-implementation.md: Scholarship morphTo provider (polymorphic)

- **Aggregate root definition** (line 144): `Scholarship -- ... Relationships: morphTo provider (ScholarshipProvider or Institution)`
- **Table schema** (line 258): `scholarships: id, provider_type, provider_id (morph), name, slug, amount (JSON), ...`
- **ProviderType enum** (line 196): `Government, Corporate, NGO, Institution, Other`
- **ScholarshipProvider entity** (line 160): `morphMany Scholarships` (supporting entity, not aggregate root)

### Supporting documents

- **02-decisions.md / 04-architecture.md**: Consistent with 03-domain.md (direct FK)
- **archive/19-domain-architecture.md** (line 307): `Scholarship belongsTo ScholarshipProvider, hasMany EligibilityPolicy`
- **IMPLEMENTATION-MODEL-RECONCILIATION.md** (line 42): `belongsTo ScholarshipProvider (FK: scholarship_provider_id) — 05 had polymorphic morphTo provider — SIMPLIFIED to direct FK`
- **BASELINE-RECONCILIATION-AUDIT.md**: F-H10 HIGH, Classification C

### Key question: Can an Institution directly offer scholarships?

Nigerian universities do offer their own scholarships (e.g., University of Lagos scholarship for indigent students). With direct FK, the institution must be represented as a ScholarshipProvider record with `type = Institution`. With polymorphic, the institution is referenced directly.

## 2. Contradictions

| Aspect | 03-domain.md | 05-implementation.md |
|--------|-------------|---------------------|
| Relationship | belongsTo ScholarshipProvider (FK) | morphTo provider (polymorphic) |
| FK columns | `scholarship_provider_id` | `provider_type` + `provider_id` |
| INV-S1 enforcement | DB FK constraint (trivial) | Application-level (loosened) |
| ProviderType.Other | Absent (4 values) | Present (5 values) |
| Admin UX | Single dropdown (ScholarshipProviders) | Dual selection (type + entity) |

## 3. Options

### Option A: Direct FK to ScholarshipProvider (03-domain.md position)

- `scholarships.scholarship_provider_id → scholarship_providers`
- INV-S1 enforced by DB FK constraint
- When an Institution offers scholarships, create a ScholarshipProvider record with `type = Institution` and link it to the institution
- Admin UX: single dropdown of ScholarshipProviders
- Import: scholarship references a provider (must exist or be created)
- Simple schema, strong invariant

### Option B: Polymorphic provider (05-implementation.md position)

- `scholarships.provider_type` + `scholarships.provider_id`
- Provider can be ScholarshipProvider or Institution directly
- INV-S1 loosened — a Scholarship can have a provider of any morph type
- Admin UX: dual selection (type + entity)
- Import: must determine provider type and resolve entity
- More flexible, weaker invariant

### Option C: Direct FK + Institution ScholarshipProvider auto-creation

- Same as Option A, but with a domain convention: when an Institution is established, a corresponding ScholarshipProvider (type = Institution) is automatically created
- Links: ScholarshipProvider.institution_id → institutions (nullable FK, set when type = Institution)
- Ensures every Institution can be a scholarship provider without manual setup
- Maintains INV-S1 and direct FK simplicity
- Adds one FK to ScholarshipProvider table

## 4. Consequences

### Domain model

| Option | Impact |
|--------|--------|
| A | INV-S1 trivially enforced. Domain model unchanged. Institution-as-provider requires manual ScholarshipProvider record. |
| B | INV-S1 loosened. Domain model changes: provider is polymorphic, not a single entity type. |
| C | INV-S1 enforced. Domain model unchanged. Institution-as-provider is automatic. |

### Database schema

| Option | Impact |
|--------|--------|
| A | `scholarship_provider_id` FK. Remove `provider_type` + `provider_id`. 2 columns removed, 1 added. |
| B | `provider_type` + `provider_id` morph columns. Remove `scholarship_provider_id`. |
| C | `scholarship_provider_id` FK. `scholarship_providers.institution_id` nullable FK added. 1 column added to scholarship_providers. |

### Relationships

| Option | Impact |
|--------|--------|
| A | Scholarship → ScholarshipProvider (N:1). ScholarshipProvider hasMany Scholarships. |
| B | Scholarship morphTo Provider (ScholarshipProvider or Institution). Institution morphMany Scholarships (as provider). |
| C | Scholarship → ScholarshipProvider (N:1). ScholarshipProvider → Institution (optional). Institution hasMany ScholarshipProviders (where type = Institution). |

### Imports

| Option | Impact |
|--------|--------|
| A | Import must find/create ScholarshipProvider before creating Scholarship. Extra step for institution-offered scholarships. |
| B | Import sets provider_type + provider_id. No prerequisite record for Institution providers. |
| C | Import finds/creates ScholarshipProvider. For Institution providers, auto-creation ensures the record exists. Same import logic as A but with guarantee. |

### Search projections

| Option | Impact |
|--------|--------|
| A | Typesense: `provider_name` (denormalized), `provider_type` (from ScholarshipProvider.type). |
| B | Typesense: `provider_type` (from morph), `provider_name` (denormalized). |
| C | Same as A. |

### Application code

| Option | Impact |
|--------|--------|
| A | Simple. `Scholarship::create(['scholarship_provider_id' => $provider->id])`. |
| B | Moderate. `Scholarship::create(['provider_type' => Institution::class, 'provider_id' => $institution->id])`. Morph type depends on BD-2. |
| C | Slightly more than A. Auto-creation logic in Institution::establish() or a domain event listener. |

## 5. Recommendation

**Recommendation: Option C — Direct FK + Institution ScholarshipProvider auto-creation.**

Rationale:

1. **Preserves INV-S1.** The invariant "A Scholarship has exactly one Provider" is enforced by the DB FK constraint, not by application logic. This is the strongest possible enforcement.

2. **Handles the practical case.** When an Institution is established, a ScholarshipProvider record (type = Institution) is automatically created. This eliminates the manual setup step that makes Option A awkward for institution-offered scholarships.

3. **Avoids polymorphic complexity.** No `provider_type`/`provider_id` morph columns. No BD-2 dependency for this relationship. Admin UI is a simple dropdown. Import logic is straightforward.

4. **The link is optional but automatic.** `ScholarshipProvider.institution_id` is a nullable FK. When `type = Institution`, it is set to the linked institution. When `type = Government/Corporate/NGO`, it is null. This is a clean, queryable relationship.

5. **Consistent with 03-domain.md.** The canonical domain model says Scholarship belongsTo ScholarshipProvider via direct FK. Option C preserves this exactly.

## 6. Implementation Impact

| Reconciliation Change | Depends on D3 | Nature of Dependency |
|----------------------|---------------|---------------------|
| Change 17 (Scholarship provider FK) | Yes | FK vs morph columns |
| Change 31 (schema: replace morph with FK) | Yes | Column definitions |
| Change 13 (ProviderType: remove Other) | Partially | Independent of FK direction |
| scholarships migration | Yes | Column list |
| ScholarshipProvider model | Yes | May add institution_id FK (Option C) |
| Filament ScholarshipResource | Yes | Provider selection UI |
| Typesense scholarships collection | Yes | Provider field definitions |

## 7. Dependency

**D3 depends on BD-1** (FK type: bigint vs UUID).
**D3 depends on BD-2** (if polymorphic is chosen, morph type convention applies — but if direct FK is chosen, BD-2 is irrelevant for this relationship).
**D3 depends on D1 indirectly** (if AdmissionCycle belongsTo EducationAuthority, and institutions are not first-class cycle owners, the Institution-as-scholarship-provider pattern becomes more important — institutions need a way to participate in the ecosystem without being cycle owners).

---

# Decision Dependency Order

```
BD-1 (Primary-key strategy)
  ↓
BD-2 (Morph type convention) ← depends on BD-1 for morph _id column type
  ↓
BD-4 (Deletion/cascade strategy) ← independent, but must be resolved before migrations
  ↓
D1 (AdmissionCycle ownership) ← depends on BD-1 for FK type
  ↓
BD-3 (AdmissionCycle phase storage) ← depends on D1 for phase template context
  ↓
D3 (Scholarship provider relationship) ← depends on BD-1 for FK type, BD-2 if polymorphic
```

**Minimum resolution order:**

| Step | Decision | Reason |
|------|----------|--------|
| 1 | **BD-1** | No dependencies. All other decisions assume a PK type. Must be first. |
| 2 | **BD-4** | No dependencies. Independent of PK type (RESTRICT/CASCADE applies to any FK type). Can be resolved in parallel with BD-2. |
| 2 | **BD-2** | Depends on BD-1 (morph _id column type). Can be resolved in parallel with BD-4. |
| 3 | **D1** | Depends on BD-1 (FK column type). Independent of BD-2, BD-4. |
| 4 | **BD-3** | Depends on D1 (owner context affects phase template). |
| 5 | **D3** | Depends on BD-1 (FK type). Depends on BD-2 only if polymorphic chosen (unlikely per recommendation). |

**Practical resolution order (accounting for human decision flow):**

1. **BD-1** — PK strategy is the foundation. Everything else derives from it.
2. **BD-2 + BD-4** — Can be resolved in parallel. Both are independent of each other and of D1.
3. **D1** — Ownership decision. Requires understanding of PK type (from BD-1).
4. **BD-3** — Phase storage. Requires understanding of ownership (from D1).
5. **D3** — Provider relationship. Requires understanding of PK type (from BD-1).

---

# Human Approval Table

| ID | Decision | Must resolve before reconciliation? | Recommended option | Human decision required? |
|----|----------|--------------------------------------|--------------------|------------------------|
| BD-1 | Primary-key strategy | **YES** — blocks every migration, FK, Typesense doc, import mapping | A: bigint auto-increment | **YES** — no ADR exists; 3 documents signal UUID; reconciliation assumed bigint; genuine ambiguity |
| BD-2 | Morph type convention | **YES** — blocks every polymorphic column in every migration | B: Short aliases via morphMap | **YES** — 3 contradictory conventions across documents; no morphMap configured |
| BD-3 | AdmissionCycle phase storage | **YES** — blocks admission_cycles migration | A: PhaseSequence VO as JSON | **YES** — 03-domain.md and 05-implementation.md define materially different schemas |
| BD-4 | Deletion/cascade strategy | **YES** — blocks every FK ON DELETE declaration | A: Status lifecycle only, FK RESTRICT | **YES** — no document comprehensively defines FK cascade behavior |
| D1 | AdmissionCycle ownership | **YES** — blocks admission_cycles FK direction | C: belongsTo EducationAuthority + Institution scope via AdmissionPolicy | **YES** — CRITICAL finding; canonical cluster says EducationAuthority; 05-implementation.md says Institution; real Nigerian context supports both |
| D3 | Scholarship provider relationship | **YES** — blocks scholarships FK vs morph columns | C: Direct FK + Institution ScholarshipProvider auto-creation | **YES** — canonical cluster says direct FK; 05-implementation.md says polymorphic; both are defensible |

---

*This brief provides all evidence, contradictions, options, consequences, and recommendations for six foundational decisions. No reconciliation has been executed. No canonical documents have been modified. No code has been written. No migrations have been created. Awaiting human resolution.*
