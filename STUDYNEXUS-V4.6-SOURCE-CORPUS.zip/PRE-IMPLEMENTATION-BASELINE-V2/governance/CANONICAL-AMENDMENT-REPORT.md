# StudyNexus — Canonical Amendment Report

**Date:** 2026-08-17
**Phase:** CANONICAL AMENDMENT (post FINAL-LINEAGE-SEMANTICS-RESOLUTION)
**Status:** AMENDMENTS APPLIED
**Constraint:** No migrations written. No application code written. No Laravel scaffolding. Frozen baseline unmodified.

---

## 1. Files Modified

| File | Amendments | Type |
|------|-----------|------|
| `01-business.md` | 1 | Terminology fix (Government Education Agency → Education Authority) |
| `02-decisions.md` | 5+ | New ADRs (ADR-19 through ADR-23), header count update, morphMap aliases, SourceReliability enum |
| `03-domain.md` | 7+ | InformationSource independence, PhaseSequence stable IDs, BIGINT PK/FK, ExternalIdentifier §14, Hybrid Provenance §15, enum alignment, self-referencing FK docs |
| `04-architecture.md` | 6+ | Infrastructure entities, Provenance architecture, Concurrency section, stable phase ID format, morphMap, RBAC/table count |
| `05-implementation.md` | 15+ | Migration schemas, BIGINT conversions, migration ordering fix, ON DELETE behaviors, CHECK constraints, index specs, enum alignment, infrastructure entities |
| `06-data-acquisition.md` | 4 | 80/20 provenance model, matching_entity_id BIGINT, provenance JSONB rewrite, no import_batch_id |

**Total files modified:** 6 of 6 canonical documents
**Total files created:** 0 (no new canonical documents)
**Baseline ZIP:** UNTOUCHED

---

## 2. Exact Amendments Applied

### 2.1 Foundational Decisions (BD-1, BD-3, BD-5, ND-5, ND-4)

| Decision | Amendment |
|----------|-----------|
| **BD-1** | disciplines.id → BIGINT; cut_off_marks.id → BIGINT; all canonical PKs/FKs → BIGINT; discipline_id FK → BIGINT; programme_id/admission_cycle_id FKs → BIGINT; matching_entity_id → BIGINT. UUID retained only for import_batches.id and pending_imports.id. Added as ADR-19. |
| **BD-3** | Replaced timestamp-based phase schema with phase_sequence JSONB + current_phase. Documented stable immutable phase IDs (application-generated string slugs), mutable phase labels, ordering immutability after activation, current_phase membership invariant. current_phase references stable phase ID, never mutable label. Added as ADR-20. |
| **BD-5** | Removed jamb_code/nuc_code/nbte_code/ncce_code columns from entities. Added generic external_identifiers model with authority_id NOT NULL, source_id NULL, replaced_by_id, retirement_reason. Documented INV-EI1 and INV-EI2 partial unique indexes. Added as ADR-21. |
| **ND-5** | Removed institution_id from InformationSource. Added authority_id BIGINT NULL FK → education_authorities. NULL = source not published by an EducationAuthority. InformationSource is independent aggregate root. Added as ADR-22. |
| **ND-4** | Added hybrid provenance model: entity-level provenance JSONB (no import_batch_id) + field_provenance for selective attribution. source_id NULL = editorial assertion. No is_active. No primary_source_id. No value_hash. No is_verified. 80/20 model: Category A = 5 fields, Category B = 6 fields. Added as ADR-23. |

### 2.2 Schema Changes

| Table | Change |
|-------|--------|
| `disciplines` | PK: UUID → BIGINT |
| `cut_off_marks` | PK: UUID → BIGINT; all FKs → BIGINT |
| `programmes` | discipline_id: UUID FK → BIGINT FK |
| `information_sources` | Removed institution_id; added authority_id BIGINT NULL FK |
| `accreditation_records` | valid_to → valid_until |
| `admission_cycles` | Added phase_sequence JSONB; added current_phase VARCHAR; phase ID documentation |
| `pending_imports` | matching_entity_id: UUID → BIGINT |
| `external_identifiers` | NEW: entity_type, entity_id, authority_id NOT NULL, identifier_type, identifier, status, valid_from, valid_until, source_id NULL, replaced_by_id, retirement_reason, metadata JSONB |
| `field_provenance` | NEW: entity_type, entity_id, field_name, source_id NULL, observed_value, confidence NULL, verification_status, observed_at, superseded_at, superseded_by_id, retroactive, timestamps |

### 2.3 Enum Alignments

| Enum | Before | After | Rationale |
|------|--------|-------|-----------|
| VerificationStatus | Pending, Verified, Rejected (05-impl) | unverified, verified, disputed, superseded, stale | Lineage resolution authoritative; 5-value set captures full lifecycle |
| InstitutionType | 7 values (05-impl) | 4 values + ADR-15 trigger note | 03-domain.md authoritative for MVP |
| ScholarshipStatus | Active, Closed, Upcoming (05-impl) | Draft, Announced, Open, Closed, Expired, Withdrawn | 03-domain.md authoritative |
| ProviderType | 5 values (05-impl) | 4 values | 03-domain.md authoritative |
| AuthorityType | 5 values (05-impl) | 4 values | 03-domain.md authoritative |
| PolicyStatus | 3 values (05-impl) | 4 values | 03-domain.md authoritative |
| SourceReliability | Unverified, Verified, Unreliable, Deprecated (03-domain) | Registered, Verified, Unreliable, Deprecated | "Registered" more precise for initial state |

### 2.4 Implementation Specifications Added

| Specification | Location | Details |
|---------------|----------|---------|
| Migration ordering | 05-implementation.md §4.1, §4.6 | education_authorities before information_sources (FK dependency) |
| ON DELETE behaviors | 05-implementation.md §4.7 | RESTRICT (9 FKs), CASCADE (5 FKs), SET NULL (1 FK) |
| CHECK constraints | 05-implementation.md §4.9 | external_identifiers (2), field_provenance (3) |
| Index specifications | 05-implementation.md §4.8 | external_identifiers (3), field_provenance (4) |
| Stable phase ID format | 04-architecture.md, 05-implementation.md | Application-generated string slugs, immutable after activation |
| Self-referencing FK handling | 03-domain.md §14, 05-implementation.md §3.5 | NULL for first record; ON DELETE RESTRICT; no circular chains |
| INV-EI1 + INV-EI2 indexes | 03-domain.md §14, 05-implementation.md §3.5 | Both partial unique indexes documented explicitly |
| Concurrency | 04-architecture.md | lockForUpdate() for AdmissionCycle phase transitions, events after commit |

---

## 3. Decisions Reflected

| Decision ID | Decision | Reflected In |
|-------------|----------|-------------|
| BD-1 | Uniform BIGINT PKs | 02, 03, 04, 05, 06 |
| BD-3 | PhaseSequence JSONB + stable phase IDs | 02, 03, 04, 05 |
| BD-5 | Generic external_identifiers | 02, 03, 04, 05 |
| ND-5 | InformationSource independent, no institution_id | 02, 03, 04, 05, 06 |
| ND-4 | Hybrid provenance 80/20 | 02, 03, 04, 05, 06 |
| D-1 | Remove is_active from field_provenance | 03, 04, 05 |
| D-2 | source_id NULLable = editorial assertion | 03, 04, 05 |
| D-3 | current_phase references stable phase ID | 03, 04, 05 |
| D-4 | replaced_by_id + retirement_reason on ExternalIdentifier | 03, 05 |
| D-5 | field_provenance.confidence nullable | 03, 05 |
| D-6 | lockForUpdate for AdmissionCycle phase transitions | 04, 05 |

---

## 4. Old Contradictory Statements Removed/Reclassified

| Old Statement | Location | Action |
|---------------|----------|--------|
| "InformationSource belongsTo Institution" | 05-implementation.md | Removed; replaced with belongsTo EducationAuthority (nullable) |
| "information_sources table with institution_id FK" | 05-implementation.md | Removed; replaced with authority_id NULL FK |
| "Provenance is recorded for every data point" | 06-data-acquisition.md | Replaced with 80/20 model language |
| "discipline_id UUID FK" | 03-domain.md, 05-implementation.md | Changed to BIGINT FK |
| "cut_off_marks: UUID PK/FKs" | 05-implementation.md | Changed to BIGINT PK/FKs |
| "matching_entity_id UUID" | 06-data-acquisition.md | Changed to BIGINT |
| "valid_to" on accreditation_records | 05-implementation.md | Changed to valid_until |
| "VerificationStatus: Pending, Verified, Rejected" | 05-implementation.md | Changed to 5-value enum from lineage resolution |
| "Government Education Agency" | 01-business.md, 02-decisions.md | Changed to Education Authority |
| Full class path as morph type | 04-architecture.md, 02-decisions.md | Changed to morphMap short aliases |
| "information_sources before education_authorities" in migration order | 05-implementation.md | Reordered |

---

## 5. Entity/VO/Event/Action/Enum/Table Counts

> **V4.6 supersession note (2026-08-19):** The counts shown below are the V2-era counts captured at amendment time. The authoritative V4.6 counts are: 13 entities (5+4+4), 29 VOs (12+17 enums), 17 enums, 61 tables. See `canonical/03-domain.md` §2/§3 and `canonical/05-implementation.md` §4 for the current counts. The V2-era counts below are preserved as the historical amendment record.

| Concept | V2-era count (SUPERSEDED) | V4.6 count (AUTHORITATIVE) | Breakdown |
|---------|---------------------------|----------------------------|-----------|
| Domain Entities | 11 | **13** | 5 aggregate roots + 4 child entities + 4 supporting entities |
| Infrastructure Entities | 2 | 2 | ExternalIdentifier, FieldProvenance |
| Staging Entities | 2 | 2 | ImportBatch, PendingImport (ephemeral, UUID PKs) |
| Value Objects | 28 | **29** | 12 non-enum + 17 backed enums |
| Enums | 16 | **17** | 3 behavioural + 14 pure |
| Domain Events | 29 | 29 | Plain PHP classes |
| Actions | 20 | 20 | Application-layer orchestration |
| RBAC Roles | 11 | 11 | 4 platform-global + 5 organization-scoped + 2 user-level |
| Database Tables | 58 | **61** | Across 10 layers |
| Category A Fields | 5 | 5 | name, type, status, accreditation_status, cut_off_mark |
| Category B Fields | 6 | 6 | founded_year, location, website, admission_requirements, application_deadline, amount |
| Total Provenance-Whitelisted Fields | 11 | 11 | Category A (5) + Category B (6) |

---

## 6. Cross-Document Consistency Results

| Dimension | Result |
|-----------|--------|
| InformationSource: independent AR, no institution_id, nullable authority_id | CONSISTENT across all 6 docs |
| EducationAuthority: authoritative body definition | CONSISTENT |
| ExternalIdentifier: authority_id NOT NULL, source_id NULL, no is_primary, status lifecycle | CONSISTENT |
| FieldProvenance: source_id NULL, no is_active, observed_value TEXT, verification_status enum (5 values), confidence nullable | CONSISTENT |
| BD-1: BIGINT PKs for all canonical tables | CONSISTENT |
| BD-3: PhaseSequence JSONB, stable phase IDs, current_phase → ID | CONSISTENT |
| BD-5: No jamb_code columns, generic external_identifiers | CONSISTENT |
| ND-5: No institution_id on InformationSource | CONSISTENT |
| ND-4: Hybrid provenance, 80/20, Category A=5, Category B=6 | CONSISTENT |
| Concurrency: lockForUpdate for AdmissionCycle phase transitions | CONSISTENT |
| PK/FK types: BIGINT for disciplines, cut_off_marks, all FK refs | CONSISTENT |
| ON DELETE behaviors | CONSISTENT (fully specified in 05-implementation.md §4.7) |
| Morph conventions: morphMap short aliases | CONSISTENT |
| Deletion strategy: RESTRICT for provenance source refs | CONSISTENT |
| Enum values: all 17 enums aligned (V4.6) | CONSISTENT (after fixes) |
| verification_status: 5-value enum | CONSISTENT (after fix) |
| Migration ordering: education_authorities before information_sources | CONSISTENT (after fix) |

**0 remaining contradictions detected.**

---

## 7. Remaining Contradictions

**None.** All contradictions identified during the amendment process have been resolved. The canonical documents are internally consistent.

---

## 8. Migration-Readiness Assessment

| Category | Items | Status |
|----------|-------|--------|
| Table schemas | All 61 tables (V4.6) | READY — schemas fully specified |
| PK/FK types | All BIGINT for canonical, UUID for staging | READY |
| Nullability semantics | source_id, authority_id | READY — fully documented |
| Migration ordering | Dependency chain documented | READY — corrected order |
| ON DELETE behaviors | 15 FK behaviors | READY — fully specified in §4.7 |
| CHECK constraints | 5 CHECK constraints | READY — specified in §4.9 |
| Partial unique indexes | INV-EI1 + INV-EI2 | READY — both documented |
| Index specifications | Infrastructure table indexes | READY — specified in §4.8 |
| Enum values | All 17 enums (V4.6) | READY — aligned across all docs |
| Stable phase IDs | Format, immutability | READY — string slugs documented |
| Self-referencing FKs | Handling + ON DELETE | READY — documented |
| Historical identifier migration | jamb_code → external_identifiers | READY — greenfield, no data migration |

**Assessment: READY FOR MIGRATION WRITING.** A competent Laravel developer can write migrations from the amended canonical documentation without making architectural decisions.

---

## 9. Whether a NEW Baseline Should Now Be Created

**Yes.** The canonical documents have been amended to reflect all approved decisions from the FINAL-LINEAGE-SEMANTICS-RESOLUTION. The working documents are now internally consistent, migration-ready, and represent the converged architecture. A new frozen baseline should be created to capture this state as the implementation reference, superseding the PRE-IMPLEMENTATION-BASELINE for all future work.

The existing PRE-IMPLEMENTATION-BASELINE remains untouched as immutable historical evidence. The new baseline would be a separate artifact capturing the post-amendment state.

---

*Canonical Amendment Report — 2026-08-17 — Amendments Applied*
