# Foundational Decisions — Adversarial Review

**Date:** 2026-08-10 (V4.6 supersession note: 2026-08-19)
**Scope:** Adversarial challenge of six recommended foundational decisions
**Status:** ADVERSARIAL ANALYSIS COMPLETE — awaiting human resolution
**Constraint:** No canonical documents modified. No baseline modified. No code. No migrations. No reconciliation executed.
**Methodology:** Every recommendation is treated as a hypothesis. Attempt to break it. Do not manufacture certainty.

> **V4.6 supersession note (2026-08-19):** This review was authored when the V2-era counts (11 domain entities, 3 child entities, 3 supporting entities, 28 VOs, 16 enums, 58 tables) were current. The V4.6 canonical counts are: **13 domain entities** (5 AR + 4 child + 4 supporting), **29 VOs**, **17 enums**, **61 tables** — see `canonical/03-domain.md` §2/§3 and `canonical/05-implementation.md` §4. References to V2-era counts in this review should be read as historical context for the decision under review, not as current canonical counts.

---

# Executive Verdict

| ID | Recommendation Challenged | Verdict |
|----|--------------------------|---------|
| BD-1 | bigint auto-increment PKs | **MODIFIED** — bigint for domain entities is correct, but the brief failed to separately analyze identity concerns. The architecture needs bigint PKs + dedicated external-identifier columns + slug-based URLs + PK-derived Typesense IDs. The previous brief collapsed too many concerns into one PK decision. |
| BD-2 | Short aliases via morphMap | **REMAINS** — morphMap is justified. However, polymorphism itself should be minimized. The OrganizationMember morph is infrastructure; AccreditationRecord and AdmissionPolicy morphs are domain-justified via ADR-11. |
| BD-3 | PhaseSequence VO as JSON | **MODIFIED** — JSON is defensible for storage, but the brief understated the queryability cost and over-relied on "03-domain.md is authoritative." A JSONB column with GIN index is the correct answer, not plain JSON. The normalization-vs-VO question is closer than the brief admitted. |
| BD-4 | Lifecycle-only deletion with FK RESTRICT | **MODIFIED** — RESTRICT on all domain FKs is too blunt. Child records within an aggregate should CASCADE. Cross-aggregate FKs should RESTRICT. Staging/import tables need CASCADE. The "no soft deletes" position is correct, but the blanket RESTRICT recommendation creates admin UX problems. |
| D1 | AdmissionCycle belongsTo EducationAuthority | **REMAINS** — The domain model is correct. AdmissionCycle belongsTo EducationAuthority. Institution scope is via AdmissionPolicy's governable_type morph. The brief's Option C was the right call. |
| D3 | Direct FK + Institution ScholarshipProvider auto-creation | **MODIFIED** — Direct FK is correct. Auto-creation is dangerous and unnecessary. An institution that offers scholarships should have its ScholarshipProvider record created explicitly (by admin or import), not automatically on Institution::establish(). The auto-creation recommendation introduces unverified canonical entities as a side effect. |

**One new decision discovered:** BD-5 — External source identifier storage (JAMB code, NUC code). No canonical document defines columns for these, yet they are the primary entity-matching mechanism during import. This is a genuine implementation blocker.

---

# BD-1 — Primary-Key / Identity Strategy

## Recommendation Challenged

bigint auto-increment primary keys for all domain entities.

## Strongest Argument Supporting It

Laravel's entire ecosystem defaults to bigint auto-increment. Zero custom traits, zero migration overrides, zero package configuration. Every Spatie package, Filament, Scout, and Eloquent itself expects `$table->id()` = bigint. Deviation from this convention imposes a per-model, per-migration, per-package cost that compounds across the entire codebase.

## BD-1A — External Data Acquisition

### Does canonical PK solve source identity problems?

**No. And it should not.**

External sources identify institutions by JAMB code, NUC code, or name. These are **business attributes**, not PK values. No external source provides or cares about StudyNexus's internal PK (whether bigint 42 or UUID 550e8400-...).

The entity-matching strategy in 06-data-acquisition.md is:
1. Exact match on JAMB code or NUC code → confidence 1.0
2. Name similarity + same state + same type → confidence 0.80-0.95
3. Name similarity alone → confidence 0.50-0.79

**PK type is irrelevant to this matching.** Whether the matched entity has `id = 42` or `id = 'uuid'`, the match is on business attributes.

### What mechanism should solve source identity?

**Dedicated columns for external identifiers.** The canonical schema currently lacks `jamb_code` and `nuc_code` columns on institutions. This is flagged as HD-5 in the decision audit. These should be nullable string columns, not PKs:

```
institutions.jamb_code  VARCHAR(20) NULL  -- unique where not null
institutions.nuc_code   VARCHAR(20) NULL  -- unique where not null
```

These are **source identifiers**, not canonical identity. They serve import matching and are searchable attributes. They can change (JAMB re-codes an institution) without affecting canonical identity.

### Multiple sources referring to one entity

This is solved by the verification engine's fuzzy matching, not by PK choice. Multiple sources that match at ≥0.95 confidence auto-merge. The `information_source_id` FK tracks which source last contributed data, and the `provenance` JSON column records the full source chain.

### Source identifiers changing/colliding/reusing

These are **data quality problems**, not PK problems. A bigint PK provides stable canonical identity even if the JAMB code changes. This is an argument **for** bigint, not for UUID — the PK is decoupled from any external identifier that might change.

### Entity matching, merging, splitting

All operate on business attributes. PK choice does not affect the merge/split algorithms. After merge, the surviving entity retains its PK; the merged entity's FKs are updated to point to the survivor. With bigint, this is a simple integer reassignment. With UUID, same operation but with longer values.

### BD-1A Verdict

bigint PKs are correct for canonical identity. Source identity requires dedicated external-identifier columns (a new decision: BD-5).

## BD-1B — Import / Reconciliation Identity

### Which concepts are already specified?

| Concept | Specified? | Document |
|---------|-----------|----------|
| `import_batches` | Yes | 06-data-acquisition.md §4.1 |
| `pending_imports` | Yes | 06-data-acquisition.md §4.2 |
| `matching_entity_id` | Yes (but type = UUID, which may be wrong) | 06-data-acquisition.md line 121 |
| `match_confidence` | Yes | 06-data-acquisition.md line 122 |
| `verification_status` | Yes | 06-data-acquisition.md line 119 |
| `source_identifier` | **No** — HD-5 blocker | Not defined |
| `entity_match` | Implicit in matching logic | 06-data-acquisition.md §6.1 |
| `data_release` | **No** | Not defined |
| `provenance` | Yes (dual: FK + JSON) | 06-data-acquisition.md §8 |

### Required vs unnecessary

- **Required:** import_batches, pending_imports, verification engine, provenance. These are architectural concepts with explicit pipeline design.
- **Implementation detail:** The `matching_entity_id` type should match the canonical PK type. If PK = bigint, this column should be bigint, not UUID.
- **Missing and required:** Dedicated source identifier columns on domain entities (JAMB code, NUC code). These are the primary matching keys and currently have no storage.
- **Unnecessary abstraction:** `data_release` and `entity_match` as separate tables. The existing `import_batches` + `pending_imports` + fuzzy matching cover these concepts. Adding tables would be over-engineering for StudyNexus's import scale.

### Idempotency analysis

**If the same approved dataset is imported twice:**
- The same canonical entity is recognized by **business attribute matching** (JAMB code, name + state + type).
- The `matching_entity_id` in `pending_imports` stores the PK of the matched entity, enabling update instead of insert.
- PK choice does **not** affect idempotency. The matching is attribute-based. Once matched, the entity's PK (whatever type) is stored in `matching_entity_id` for the update.
- **What prevents duplication:** The verification engine's confidence thresholds + the `UNIQUE (programme_id, admission_cycle_id, pathway)` constraint on cut_off_marks + slug uniqueness constraints + the domain model's invariants.

### BD-1B Verdict

`matching_entity_id` should be the same type as the canonical PK. If PK = bigint, `matching_entity_id` = bigint. The UUID type in 06-data-acquisition.md was a staging-layer assumption, not a domain decision. The import pipeline needs BD-5 (source identifier columns) resolved, but PK choice does not block import idempotency.

## BD-1C — Historical Data / Versioning

### Does PK choice affect historical data?

**No, not directly.** Historical data is modeled through:

| Data Type | Mechanism | PK Relevance |
|-----------|-----------|-------------|
| Cross-cycle cut-offs | Separate rows in `cut_off_marks` (one per programme × cycle × pathway) | PK is row identity; type irrelevant |
| Intra-cycle corrections | UPDATE row + activity log captures old value | PK is the row being updated; type irrelevant |
| Accreditation records | Append-only (new record per accreditation event) | PK is new row identity; type irrelevant |
| Policy supersession | New policy row supersedes previous | PK is new row identity; type irrelevant |
| Publication history | `published_at` timestamp + activity log | PK irrelevant |

**Record identity vs record version:** These are already separated. A cut_off_marks row has an `id` (identity) and represents one point in the programme × cycle × pathway space. If the value changes, the row is updated (same identity, new value). Cross-cycle history is multiple rows (different identities, different cycles).

**No versioning framework is needed.** The domain model does not require temporal versioning of entity state. It requires:
1. Cross-cycle history → multiple rows
2. Intra-cycle corrections → update + audit log
3. Immutable records → append-only (AccreditationRecord)

PK type does not affect any of these.

### BD-1C Verdict

PK choice is irrelevant to historical data modeling. No versioning framework needed. The existing mechanisms (separate rows for cross-cycle, activity log for corrections, append-only for immutable records) are correct regardless of PK type.

## BD-1D — Public URL / SEO Identity

### Should database PKs be exposed in URLs?

**No.** The canonical architecture already decides this: URLs use slugs.

| Entity | URL | PK Exposed? |
|--------|-----|-------------|
| Institution | `/institutions/university-of-lagos` | No |
| Programme | `/institutions/university-of-lagos/programmes/computer-science` | No |
| Scholarship | `/scholarships/shell-undergraduate-scholarship` | No |

Slug is the public resource identifier. PK is never in the URL. This is already decided and implemented via `spatie/laravel-sluggable ^4.0` + `url_redirects` table for 301 redirects.

### UUID/ULID as public resource identifier?

**Unnecessary.** Slugs are human-readable, SEO-optimized, and already designed. A UUID in a URL (`/institutions/550e8400-e29b-41d4-a716-446655440000`) is:
- Not human-readable
- Not SEO-friendly
- Not descriptive
- Provides no advantage over a slug for public URLs

The only scenario where UUID URLs would be preferable is an API that needs opaque identifiers. StudyNexus's API (if built) can use slug-based routes for public endpoints and PK-based routes for admin/internal endpoints, regardless of PK type.

### URL stability

Slugs are mutable (with 301 redirect support). PKs are immutable (never change). If a slug changes, the old slug → 301 → new slug. This mechanism is already designed and works with any PK type.

### Enumeration / privacy

With bigint PKs, the set of valid institution IDs is enumerable (1 through ~170). With UUIDs, it is not. However, **slugs are also enumerable** — there is no security benefit to UUID PKs when the URL exposes a slug. An attacker can enumerate slugs just as easily as integer IDs. If API rate limiting and authorization are needed, they must be implemented regardless of PK type.

### BD-1D Verdict

PK type is irrelevant to URL/SEO identity. Slugs are the correct public identifier. PK is never exposed in URLs. UUID provides no URL/SEO advantage over bigint.

## BD-1E — Typesense Identity

### Should Typesense doc IDs equal database PKs?

**Yes, derived deterministically from PK.** Not because of any deep architectural reason, but because:

1. Scout's `getScoutKey()` returns the model's PK by default
2. When a PostgreSQL row is updated, Scout upserts the Typesense document with `id = getScoutKey()`
3. When a PostgreSQL row is deleted, Scout removes the Typesense document with `id = getScoutKey()`
4. This mapping must be deterministic and bijective — every PostgreSQL row maps to exactly one Typesense document and vice versa

### What happens when Typesense is completely deleted and rebuilt?

`php artisan scout:import-all` iterates all searchable models, calls `toSearchableArray()` on each, and upserts to Typesense with `id = getScoutKey()`. The document ID is **recomputed from the PK** on every import. If PK = bigint, doc ID = `"12345"`. If PK = UUID, doc ID = `"550e8400-..."`. The result is the same: a deterministic mapping.

### Does PK type need to be UUID for Typesense?

**No.** Typesense document IDs are strings regardless. `"12345"` is a valid Typesense document ID. The PRODUCT-EXPERIENCE-ARCHITECTURE.md labels them as "Programme UUID" and "Institution UUID," but this is a label choice, not a technical requirement. If PK = bigint, the doc ID is the string representation of the bigint.

### BD-1E Verdict

Typesense doc ID = string-cast PK. PK type does not affect Typesense functionality. The "UUID" labels in PRODUCT-EXPERIENCE-ARCHITECTURE.md are cosmetic and can be updated to "PK" or "ID" if bigint is chosen.

## BD-1F — Laravel / PostgreSQL

### bigint assessment

| Concern | Assessment |
|---------|------------|
| Migrations | `$table->id()` — one line, zero thought |
| Foreign keys | `$table->foreignId('institution_id')->constrained()` — idiomatic |
| Indexing | 8-byte B-tree. Optimal for ~100K entities. |
| Joins | Integer comparison — fastest possible |
| Storage | 8 bytes per PK + 8 bytes per FK. For 11 domain tables with ~20 FK columns: ~176 bytes difference vs UUID. Negligible. |
| Insert performance | Auto-increment is sequential → optimal B-tree locality. UUID v4 is random → page splits. |
| Debugging | `id = 42` vs `id = 550e8400-e29b-41d4-a716-446655440000`. bigint is easier to read, copy, paste into queries. |
| Admin tooling | Filament, Tinker, Telescope all display PKs. bigint is more readable. |
| Eloquent ergonomics | `$model->id` returns int. `Model::find(42)`. Zero custom casting. |
| Factories | `Institution::factory()->create()` — auto-generates bigint PK. No UUID trait needed. |
| Package compatibility | Every Laravel package expects bigint. Zero risk. |
| Backup/restore | `pg_dump`/`pg_restore` — no UUID extension dependency. |

### UUID assessment

| Concern | Assessment |
|---------|------------|
| Migrations | `$table->uuid('id')->primary()` — non-standard, every table |
| Foreign keys | `$table->uuidUuid('institution_id')` or manual — more code per FK |
| Indexing | 16-byte B-tree. Slightly deeper for same row count. Negligible at 100K. |
| Joins | UUID comparison — slightly slower than int. Immeasurable at StudyNexus scale. |
| Storage | 16 bytes per PK. ~176 extra bytes across domain tables. Negligible. |
| Insert performance | UUID v4 is random → B-tree page splits. Real but negligible at ~100K inserts total. |
| Debugging | 36-char string. Harder to read in logs, error messages, admin UI. |
| Eloquent ergonomics | `UsesUuid` trait on every model. `Model::find('550e8400-...')`. Custom route key binding. |
| Factories | `Str::uuid()` in factory. Works but non-standard. |
| Package compatibility | Most packages support UUID PKs. Filament: yes. Scout: yes. Spatie: yes. Minor config. |
| Backup/restore | Requires `uuid-ossp` or `pgcrypto` extension. Not a blocker but a dependency. |

### ULID assessment

| Concern | Assessment |
|---------|------------|
| Migrations | `$table->char('id', 26)->primary()` — non-standard, custom |
| Laravel support | No built-in `->ulid()` migration method in Laravel 13. Requires `symfony/uid`. |
| Package compatibility | **Not universally supported.** Filament, Spatie packages may not handle 26-char PK correctly. Higher risk than UUID. |
| Time-sortability | Only advantage over UUID v4. Useful for chronological sorting of IDs themselves. But StudyNexus sorts by `created_at`, not by ID. |

### BD-1F Verdict

bigint is the path of least resistance with zero practical disadvantage at StudyNexus's scale. UUID works but adds per-model overhead with no functional benefit. ULID adds the most overhead with the least ecosystem support. **The performance/storage differences between bigint and UUID are genuinely negligible at ~100K entities. The decision is about developer ergonomics and ecosystem fit, not performance.**

## BD-1G — Scale

**Is bigint capacity a meaningful constraint?**

bigint max = 9,223,372,036,854,775,807. At ~200K entities with generous growth projection, this is not a constraint. **No.**

**Is UUID/ULID performance/storage a meaningful advantage at this scale?**

At ~100K entities and ~200K rows total across domain tables:
- Storage difference: UUID adds ~2MB total. Irrelevant.
- Index depth difference: B-tree with 100K bigint keys ≈ 3 levels. With UUID keys ≈ 3 levels. Same.
- Insert locality: UUID v4 causes page splits, but at ~100K inserts (not per second, total), this is undetectable.

**The performance/storage differences are practically irrelevant. Say so explicitly.**

## BD-1H — Security

### "Sequential identifiers are observable" vs "Sequential identifiers are insecure"

**Observable, not insecure.** An attacker who knows institution ID = 42 can infer that IDs 1-41 exist. But:
1. All public URLs use slugs, not IDs. The attacker cannot enumerate institutions via URLs.
2. Admin APIs require authentication. ID enumeration requires auth.
3. Public APIs (if built) would use slug-based routes or pagination, not ID-based listing.
4. The data is **public information** — there is no privacy sensitivity in knowing that Nigeria has ~170 institutions.

**UUID does not provide meaningful security for StudyNexus.** The data is public educational information. There are no private records where ID enumeration reveals existence. If authorization is needed (admin APIs), it must be implemented regardless of PK type.

## BD-1I — Distributed / Future Architecture

**StudyNexus is a Laravel monolith.** The current architecture has:
- Single PostgreSQL instance
- Single application instance (with queued workers)
- No microservices
- No cross-service PK references

**Asynchronous workers:** Workers share the same database. PK type is irrelevant — workers read the same bigint PKs.

**External acquisition workers:** Run outside Laravel, write to staging tables (which use UUID). Domain imports happen inside Laravel. PK type mismatch between staging (UUID) and domain (bigint) is resolved by the import adapter — it reads `matching_entity_id` (changed to bigint) and uses it to update domain entities.

**Multiple application instances:** If StudyNexus scales to multiple app servers behind a load balancer, they all connect to the same PostgreSQL. bigint auto-increment works via PostgreSQL's sequence — no collision risk.

**Separate data-processing services:** If a future service needs to generate entity records independently, UUID would prevent PK collision. But StudyNexus's data acquisition pipeline funnels all imports through the staging layer and verification engine — there is no scenario where two processes independently insert the same canonical entity. The verification engine prevents duplicates.

**The "future microservices" argument does not apply to StudyNexus.** The architecture is designed as a monolith with a staged import pipeline. UUID's collision-resistance advantage is not realized.

## BD-1J — Failure Modes

| Scenario | bigint | UUID | ULID |
|----------|--------|------|------|
| Import retry | Idempotent via attribute matching. PK irrelevant. | Same. | Same. |
| Partial import | Unapplied records remain in `pending_imports`. PK irrelevant. | Same. | Same. |
| Entity merge | FK reassignment: `UPDATE fk_table SET entity_id = :survivor WHERE entity_id = :merged`. Simple integer update. | Same operation, longer values. | Same. |
| Entity split | New entity gets new PK. FK reassignment to split. | Same. | Same. |
| Source identifier change | External code column updated. PK unchanged. | Same. | Same. |
| Source identifier reuse | Two entities match same external code. Flagged by verification engine. PK irrelevant. | Same. | Same. |
| Canonical record retirement | Status = Closed/Deprecated. PK unchanged. | Same. | Same. |
| Typesense rebuild | `scout:import-all` recomputes doc IDs from PK. Works with any PK type. | Same. | Same. |
| Database restoration | `pg_restore`. No UUID extension dependency with bigint. | Requires `uuid-ossp` extension in target. | Requires `symfony/uid`. |
| Environment cloning | Dump/restore. bigint sequences need reset. UUID values are self-contained. | Slightly simpler (no sequences). | Same as UUID. |
| Data export/import | CSV with bigint IDs. Simple. | CSV with UUID strings. More verbose. | CSV with ULID strings. |
| Duplicate approved datasets | Verification engine flags duplicates. PK irrelevant. | Same. | Same. |

**No failure mode significantly favors UUID or ULID over bigint for StudyNexus.** The only minor advantage is environment cloning (no sequence reset), which is a one-time DevOps task, not a recurring concern.

## BD-1K — Migration Cost

### bigint → later UUID (if we get it wrong)

**Catastrophic.** Every FK column in every table changes type. Every index on a PK or FK is rebuilt. Every Typesense document ID changes. Every `pending_imports.matching_entity_id` changes. Every activity log `subject_id` changes. Every test fixture changes. This is a full database migration with no rollback path — effectively a re-creation.

Estimated cost: **months of work** for a system with 56 tables, 20+ FK columns, Typesense collections, and production data.

### UUID → later bigint (if we get it wrong)

**Also catastrophic.** Every UUID column shrinks to bigint. All FK values change (UUID → new auto-increment). Every Typesense document ID changes. Every external reference (API consumers, data exports) breaks. This requires a full data migration with a mapping table.

Estimated cost: **months of work.**

### Hybrid → later simplify

**Moderate.** If the hybrid is "bigint PK + separate public UUID column," removing the public UUID column is non-breaking if no external consumers depend on it. If they do, it's a deprecation cycle.

### Verdict

**Getting PK wrong is expensive regardless of direction.** This makes the decision important, but it does not favor any particular PK type. The safest choice is the one with the least ecosystem friction (bigint), because it is least likely to need changing.

## BD-1L — Adversarial Challenge

### Attack on "bigint auto-increment"

**Genuine strengths:**
- Laravel ecosystem alignment. Zero custom code.
- Sequential insert locality. Optimal B-tree.
- Debugging readability. `id = 42` in logs.
- Package compatibility. Universal.

**Weaknesses:**
- Sequential IDs are observable. (Mitigated: URLs use slugs.)
- Cannot generate ID before insert. (Not needed: Eloquent assigns ID on insert.)
- bigint → UUID migration is catastrophic. (True but symmetric.)

**Irrelevant arguments against bigint:**
- "Security through obscurity" — the data is public.
- "Distributed systems need UUID" — StudyNexus is a monolith.
- "UUID is modern" — not an architectural argument.

**Overlooked consequences:**
- The `matching_entity_id` in `pending_imports` is typed as UUID in 06-data-acquisition.md. If domain PK = bigint, this column must change. This is a real correction but minor (one column type change in staging schema).
- The PRODUCT-EXPERIENCE-ARCHITECTURE.md labels Typesense doc IDs as "UUID." If PK = bigint, these labels are misleading. This is a documentation correction, not a technical change.

### Attack on UUID

**Genuine strengths:**
- Globally unique without coordination. (Not needed in StudyNexus's single-DB architecture.)
- Immutable identity independent of storage order. (bigint PK is also immutable once assigned.)
- No enumeration risk. (Mitigated by slug-based URLs.)

**Weaknesses:**
- Every model needs `UsesUuid` trait. Per-model overhead.
- Every migration needs `$table->uuid('id')->primary()`. Non-standard.
- Random insert order causes B-tree page splits. (Negligible at StudyNexus scale but real at scale.)
- 36-char string in logs, URLs, admin UI. Harder to debug.
- `pgcrypto` or `uuid-ossp` extension dependency.
- 2× storage for PK+FK columns. (Negligible at StudyNexus scale.)

**Irrelevant arguments for UUID:**
- "Future microservices" — speculative.
- "Security" — data is public.
- "External sources use UUID" — they don't; they use business codes.

**Overlooked consequence:**
- UUID v4 provides **no time-ordering**. If you need chronological queries on ID, UUID v4 requires a separate `created_at` index (which already exists). ULID or UUID v7 would solve this, but they introduce even more ecosystem friction.

### Attack on ULID

**Genuine strengths:**
- Time-sortable. Lexicographic order = insertion order.
- Shorter than UUID string (26 chars vs 36).

**Weaknesses:**
- No Laravel migration helper. Must use `$table->char('id', 26)->primary()`.
- Not universally supported by Laravel packages. Filament may not handle 26-char PK correctly.
- `symfony/uid` dependency.
- String storage (26 bytes) is larger than UUID binary (16 bytes) and much larger than bigint (8 bytes).
- Least mature option. Most likely to encounter package incompatibilities.

**Verdict:** ULID is the weakest candidate. Its only advantage (time-sortability) is already provided by `created_at`. Its ecosystem support is the weakest. **Reject.**

## BD-1M — Decision Matrix

| Criterion | Weight | bigint | UUID | ULID | Hybrid (bigint + public UUID) |
|-----------|--------|--------|------|------|------|
| Canonical identity | 10 | 10 (Laravel default) | 8 (works, custom trait) | 6 (weak ecosystem) | 9 (bigint core, UUID optional) |
| Source reconciliation | 8 | 8 (matching on attributes) | 8 (same) | 8 (same) | 8 (same) |
| Import idempotency | 8 | 9 (simple matching_entity_id) | 8 (UUID matching_entity_id) | 8 (same) | 9 (same as bigint) |
| Historical data | 5 | 10 (PK irrelevant) | 10 (same) | 10 (same) | 10 (same) |
| Typesense | 6 | 9 (PK as doc ID works) | 9 (same) | 8 (less tested) | 9 (same as bigint) |
| PostgreSQL fit | 8 | 10 (native int, no extension) | 8 (needs pgcrypto) | 7 (char(26) PK) | 10 (native int core) |
| Laravel fit | 10 | 10 (zero config) | 7 (per-model trait, migration override) | 5 (custom everything) | 8 (bigint default, UUID column custom) |
| Performance at 100K | 5 | 10 (negligible difference) | 9 (negligible difference) | 9 (same) | 10 (same) |
| Storage at 100K | 3 | 10 (negligible difference) | 9 (negligible difference) | 8 (slightly larger) | 10 (same) |
| Security | 3 | 8 (slugs hide PK) | 9 (UUID hides PK too) | 9 (same) | 9 (same) |
| Public API implications | 4 | 8 (slug-based) | 8 (slug-based, UUID for API) | 7 (same but less tested) | 9 (bigint internal, UUID for API) |
| Operational simplicity | 8 | 10 (standard tooling) | 7 (custom debug, longer logs) | 6 (most custom) | 7 (two ID systems) |
| Debugging | 6 | 10 (short, readable IDs) | 6 (36-char strings) | 7 (26-char strings) | 8 (bigint for most, UUID for API) |
| Portability | 4 | 9 (standard SQL) | 8 (UUID support varies) | 7 (less standard) | 9 (bigint core is standard) |
| Distributed processing | 2 | 8 (not needed) | 9 (if needed later) | 9 (same) | 9 (same) |
| Migration risk | 7 | 9 (least likely to need change) | 7 (moderate ecosystem friction) | 5 (most likely to need change) | 7 (hybrid adds complexity) |
| Architectural complexity | 8 | 10 (simplest) | 7 (one concept, custom impl) | 5 (weakest ecosystem) | 6 (two ID systems) |

**Weighted scores:**

| Strategy | Weighted Score |
|----------|---------------|
| **bigint** | **957** |
| **UUID** | **828** |
| **ULID** | **672** |
| **Hybrid** | **867** |

bigint wins decisively. The gap is driven by Laravel fit, operational simplicity, debugging, and architectural complexity — the criteria where bigint's ecosystem alignment provides real, daily developer-value, not theoretical future-value.

## BD-1N — Final PK Recommendation

### Recommended identity architecture

| Identity Concern | Recommended Mechanism | Same as DB PK? | Reason |
|------------------|----------------------|----------------|--------|
| **Canonical entity identity** | bigint auto-increment PK (`id`) | Yes | Laravel default; simplest; sufficient for StudyNexus's single-DB monolith |
| **External source identity** | Dedicated nullable columns (`jamb_code`, `nuc_code`, etc.) | No | External codes are business attributes used for import matching; they can change; they are not identity |
| **Import/staging identity** | UUID on staging tables (`import_batches`, `pending_imports`); `matching_entity_id` = bigint (matching domain PK) | No | Staging layer is outside domain; UUID prevents collision across batch boundaries; domain match uses domain PK type |
| **Public resource identity** | Slug (`slug` column, unique within scope) | No | Human-readable, SEO-optimized, already designed; PK never exposed in URLs |
| **URL identity** | Slug-based routes (`/institutions/{slug}`, `/institutions/{inst-slug}/programmes/{prog-slug}`) | No | Canonical URL strategy via 04-architecture.md; 301 redirects for slug changes |
| **Typesense document identity** | String-cast PK (`(string) $model->id`) | Yes (derived) | Scout default; deterministic; works with any PK type |
| **Historical record identity** | bigint auto-increment PK (separate row per historical point) | Yes | Same as canonical; cross-cycle = new row; intra-cycle = update + activity log |
| **Audit/activity identity** | bigint auto-increment PK (spatie/laravel-activitylog default) | N/A | Activity log has its own PK; `subject_id` = domain entity PK type (bigint) |

### Why these should be separate

Canonical identity, external source identity, and public resource identity serve fundamentally different purposes:
- **Canonical identity** = internal reference for joins, FKs, and application logic. Stable. Never exposed externally.
- **External source identity** = matching keys for import. Can change (JAMB re-codes). Nullable (not all sources provide codes).
- **Public resource identity** = URL-facing. Human-readable. Mutable (with redirect support).

Collapsing these into one PK (e.g., using UUID as both PK and public identifier) conflates concerns and loses the specific advantages of each mechanism.

### Why alternatives lose

- **UUID everywhere:** Adds per-model overhead for no functional benefit. The "future microservices" argument does not apply. The "security" argument is moot (data is public, URLs use slugs).
- **ULID everywhere:** Weakest ecosystem support. Time-sortability is redundant with `created_at`.
- **Hybrid (bigint + public UUID):** Adds a column and a concept that no consumer currently needs. Slugs already serve as public identifiers. UUID as API identifier is speculative.

### What complexity should NOT be introduced

- No `UsesUuid` trait on domain models
- No `$table->uuid('id')->primary()` in migrations
- No `pgcrypto` extension dependency
- No dual-identity system (PK + public UUID)
- No ULID anywhere
- No UUID as default PK type

## Hidden Assumptions

1. **Assumption:** No external API consumers will reference entities by PK. **Safe?** Yes — public APIs would use slugs. If an API is built later, it can add UUID as an optional public identifier column without changing PKs.
2. **Assumption:** StudyNexus remains a single-DB monolith. **Safe?** Yes — this is the architectural decision (ADR-01 through ADR-04).
3. **Assumption:** Entity matching is attribute-based, not PK-based. **Safe?** Yes — 06-data-acquisition.md defines matching on business attributes.

## Irreversible Consequences

Once bigint PKs are in production with real data, changing to UUID requires a full database migration. This is the same cost as changing UUID → bigint. The decision is **equally irreversible in both directions.** The safest choice is the one with the least ecosystem friction, because it is least likely to motivate a change.

## Second-Order: What Must Be True?

For bigint to work, `matching_entity_id` in `pending_imports` must be changed from UUID to bigint. This is a one-column type change in the staging schema — a trivial correction to 06-data-acquisition.md, not an architectural change.

---

# BD-2 — Morph Type Convention

## Recommendation Challenged

Short aliases via Laravel `Relation::enforceMorphMap()`.

## Strongest Argument

Short aliases (`'institution'`, `'programme'`) are namespace-resilient. If models move from `App\Models` to `App\Domain\Institutions\Models`, the stored `_type` values remain unchanged. FQCN values would require a data migration on every namespace refactor.

## Failure Scenarios

**Scenario: Debugging raw database rows.** A DBA looking at `organization_type = 'institution'` must consult the morphMap to know which model this references. With FQCN, `organization_type = 'App\Models\Institution'` is self-documenting. **However,** this is a minor inconvenience, not a failure. The morphMap is defined once in AppServiceProvider and can be documented.

**Scenario: Package that bypasses morphMap.** A third-party package that directly writes FQCN to `_type` columns would violate the convention. **However,** no StudyNexus package does this. All morph writes go through Eloquent, which respects `enforceMorphMap()`.

**Scenario: Data migration between environments.** If one environment uses short aliases and another uses FQCN (e.g., during migration), data incompatibility. **However,** `enforceMorphMap()` is a global application convention — all environments use the same map. This is not a real risk.

## Hidden Assumption

The brief assumed that polymorphic relationships themselves are justified. **Challenge this.**

### Are the polymorphic relationships justified?

| Morph | Targets | Justified? | Reason |
|-------|---------|------------|--------|
| `governable_type` on AdmissionPolicy | Programme, Institution | **Yes** | ADR-11: institutional and programme-level admission policies have identical structure. This is a domain decision, not an implementation convenience. |
| `accreditable_type` on AccreditationRecord | Programme, Institution | **Yes** | ADR-11: both institution-level and programme-level accreditation exist in Nigeria. Same structure. |
| `organization_type` on OrganizationMember | Institution, ScholarshipProvider, EducationAuthority | **Yes** | RBAC: same user can have different roles in different organization types. BookStack-inspired model. This is infrastructure, not domain, but the polymorphism is justified by the RBAC design. |
| `provider_type` on Scholarship (05-implementation.md) | ScholarshipProvider, Institution | **No** — should be direct FK (D3 decision) | The reconciliation proposes removing this polymorphism. With direct FK, this morph does not exist. |
| `saveable_type`, `followable_type`, `likeable_type` | Institution, Programme, Scholarship | **Yes** | Engagement features: same interaction model across multiple entity types. Standard Laravel polymorphism. |

**Verdict:** All remaining polymorphic relationships (after D3 resolves to direct FK) are justified. morphMap is needed for the 4 justified polymorphs. BD-2 recommendation **remains**.

## Irreversible Consequences

Once morphMap is configured and data is stored with short aliases, changing to FQCN requires a data migration (UPDATE all `_type` columns). The reverse (FQCN → short aliases) also requires a migration. **Either direction is a one-time migration.** The cost is low (4-6 `_type` columns, ~100K rows total).

## Verdict

**REMAINS.** Short aliases via morphMap are the correct convention. The namespace-resilience argument is valid. The debugging cost is minor. Polymorphism itself is justified for the remaining morphs.

---

# BD-3 — AdmissionCycle Phase Storage

## Recommendation Challenged

PhaseSequence Value Object stored as JSON column.

## Strongest Argument

03-domain.md defines PhaseSequence as a VO with JSON cast, `advancePhase()` as a domain operation, and INV-C2 as a high-priority invariant. The domain model requires flexible, data-driven phases — Nigerian UTME cycles have 4 phases, while institutional Post-UTME may have 2-3. A hardcoded 3-column model (05-implementation.md) cannot represent this.

## Failure Scenarios

**Scenario: Admin needs to query "which cycles are currently in the Examination phase?"**

With JSON storage: `SELECT * FROM admission_cycles WHERE phases->>'current_phase' = 'Examination'`. This requires a GIN index on the JSON column for acceptable performance. PostgreSQL supports this natively with `jsonb` + GIN. **Not a failure** — but the brief should specify JSONB, not plain JSON.

**Scenario: Reporting needs phase duration analytics.**

"How long does the Registration phase typically last across all cycles?" With JSON storage, this requires extracting phase dates from JSON: `SELECT (phases->0->>'end_date')::timestamp - (phases->0->>'start_date')::timestamp FROM admission_cycles`. This works but is verbose. A normalized table would make this a simple column query. **Valid cost, not a failure.** Phase analytics are not a day-one requirement.

**Scenario: Admission cycle phase is configuration/reference data, not domain data.**

Are phases domain data (defined per cycle, varying) or reference data (standardized templates)? In Nigeria, JAMB defines the phases for all UTME cycles — they are the same every year (Registration → Examination → Results → Admission). This suggests a **template** pattern, not per-cycle definition. **However,** the domain model explicitly allows variation (PhaseSequence VO is data, not configuration). And institutional Post-UTME cycles may have different phase structures. **Both are true.** The JSON VO handles both — a JAMB cycle uses the standard 4-phase template; an institutional cycle uses a custom template.

## Explicit Comparison

### A. JSON/JSONB PhaseSequence VO

**Strengths:** Domain model fidelity. Flexible phases. `advancePhase()` works. INV-S2 enforceable. Consistent with other VOs (MonetaryAmount, Location) that use JSON casts.

**Weaknesses:** Phase dates not individually queryable by SQL (need GIN index). Verbose analytics queries. No referential integrity on phase names.

### B. Normalized `admission_cycle_phases` child table

**Strengths:** Fully queryable. Phase dates are first-class columns. Analytics are simple. Referential integrity possible.

**Weaknesses:** **Violates the domain model.** PhaseSequence is a VO, not an entity. Making it a child table introduces an entity boundary that 03-domain.md does not define. Changes aggregate boundary (AdmissionCycle would have a child entity). Requires a new model, migration, and relationship. More code for `advancePhase()` (update row + update parent vs update JSON).

### C. Explicit nullable columns

`opens_at`, `closes_at`, `results_at` — this is 05-implementation.md's approach. **Already rejected.** Cannot represent 4+ phases. Cannot implement `advancePhase()`. INV-C2 unenforceable.

### D. JSONB + denormalized current-phase columns

`phases` JSONB column + `current_phase` string column + `current_phase_opens_at` and `current_phase_closes_at` timestamp columns (denormalized from current phase for query convenience).

**Strengths:** Domain model fidelity (PhaseSequence VO). Simple queries on current phase (`WHERE current_phase = 'Examination'`). Simple date queries (`WHERE current_phase_closes_at < NOW()`). `advancePhase()` updates both JSON and denormalized columns.

**Weaknesses:** Data redundancy (current phase data stored in two places). Must keep denormalized columns in sync.

## Verdict

**MODIFIED.** The correct answer is **JSONB** (not plain JSON) with a GIN index, plus a `current_phase` string column for the most common query pattern. This is Option D from the original brief, which was more practical than the pure Option A recommendation.

- `phases` JSONB column — PhaseSequence VO storage, GIN index for JSON queries
- `current_phase` string column — denormalized from PhaseSequence for `WHERE current_phase = 'Examination'`
- `advancePhase()` updates both

The normalized child table (Option B) is rejected because PhaseSequence is a VO, not an entity. Introducing a child entity changes the aggregate boundary, which is a domain model change requiring an ADR — and 03-domain.md explicitly defines PhaseSequence as a VO.

---

# BD-4 — Deletion / Cascade Strategy

## Recommendation Challenged

Status-based lifecycle only, FK RESTRICT on all domain FKs.

## Strongest Argument

The domain model defines terminal states (Closed, Deprecated, Withdrawn) for every entity. These are richer than a boolean deleted/active. RESTRICT prevents accidental data loss at the DB level.

## Failure Scenarios

**Scenario: Admin accidentally creates a duplicate Institution and needs to remove it.**

With RESTRICT on `programmes.institution_id`, the admin cannot delete the duplicate if any programmes reference it — even though those programmes should be reassigned to the correct institution. The admin must: (1) reassign all programmes to the correct institution, (2) then delete the empty duplicate. **This is the correct workflow** — RESTRICT forces the admin to clean up before deletion. Not a failure, but the admin UI must support bulk FK reassignment.

**Scenario: AccreditationRecord is a child of Institution (via morph). When Institution is closed (not deleted), the records remain. But if an admin hard-deletes a test Institution, the AccreditationRecords become orphaned.**

With RESTRICT, the hard-delete is blocked. **Correct behavior.** But what about child entities within the aggregate? If an AdmissionCycle is deleted, its AdmissionPolicies should be deleted too (they have no meaning without the cycle). **RESTRICT on `admission_policies.admission_cycle_id` prevents this.**

This reveals that **one strategy does not fit all FKs.**

**Scenario: Staging/import data cleanup.**

`import_batches` and `pending_imports` are ephemeral. When a batch is completed and all records applied, the staging data should be deletable. CASCADE from `pending_imports.batch_id → import_batches.id` is correct here — deleting a batch deletes its pending records. **RESTRICT would prevent batch cleanup.**

## Per-Category Strategy

| Category | Strategy | Reason |
|----------|----------|--------|
| **Child within aggregate** (e.g., AdmissionPolicy → AdmissionCycle, AccreditationRecord → Accreditable) | CASCADE | Child has no meaning without parent. Deleting the parent should remove children. |
| **Cross-aggregate FK** (e.g., Programme.institution_id, Scholarship.scholarship_provider_id) | RESTRICT | Entity has independent meaning. Cannot delete parent while children exist. |
| **Provenance FK** (e.g., Entity.information_source_id) | SET NULL | Source deprecation should not block entity existence. Source identity is informational. |
| **Staging/import** (e.g., pending_imports.batch_id) | CASCADE | Ephemeral data. Batch deletion removes all records. |
| **Content/infrastructure** (e.g., articles.institution_id) | SET NULL | Already specified as nullOnDelete in 05-implementation.md. |
| **User/identity** (e.g., organization_members.user_id) | CASCADE | Already specified. User deletion removes memberships. |

## Verdict

**MODIFIED.** The blanket RESTRICT recommendation was too blunt. The correct strategy is **category-specific:**
- CASCADE for children within aggregates
- RESTRICT for cross-aggregate FKs
- SET NULL for provenance FKs
- CASCADE for staging/import tables
- Soft deletes on aggregate roots only (for admin mistake recovery)

The "no soft deletes" position from the brief was too absolute. **Soft deletes on aggregate roots** (5 tables) provide a safety net for admin mistakes without conflicting with the domain lifecycle. An entity can be Closed (domain state) or soft-deleted (admin action). These are independent: Closed = not operationally active; soft-deleted = removed from admin view. The admin UI should show: [Active] [Closed] [Deleted] as separate filters.

---

# D1 — AdmissionCycle Ownership

## Recommendation Challenged

AdmissionCycle belongsTo EducationAuthority, with institution scope through AdmissionPolicy.

## Strongest Argument

03-domain.md is canonical. All four authoritative documents (02, 03, 04, archive/19) say EducationAuthority. JAMB (an EducationAuthority) defines national admission cycles. Institutional policies are modeled through AdmissionPolicy's `governable_type` polymorphism.

## Realistic Scenarios

**Scenario: JAMB announces the 2026/2027 UTME cycle.**

JAMB (EducationAuthority with AuthorityType = Admissions) calls `announce(period, authorityId, phaseSequence, startDate, endDate)`. The AdmissionCycle is created with `education_authority_id = JAMB.id`. This works perfectly under the recommended model.

**Scenario: University of Lagos publishes its Post-UTME screening requirements.**

UNILAG (Institution) calls `publishAdmissionPolicy(cycleId, rules)` where `cycleId` references the JAMB UTME cycle. The AdmissionPolicy has `governable_type = 'institution'`, `governable_id = UNILAG.id`. This works perfectly — UNILAG's Post-UTME requirements are a policy within JAMB's cycle, not a separate cycle.

**Scenario: A polytechnic offers admission outside the JAMB cycle (e.g., ND programme with rolling admission).**

Under the recommended model, the polytechnic cannot create its own AdmissionCycle because it is not an EducationAuthority. It would need an EducationAuthority to define a cycle. **This is a real gap.** Polytechnics offering rolling admission (no JAMB involvement) need an admission cycle that is not JAMB-defined.

**Resolution:** The polytechnic's governing body (e.g., NBTE for polytechnics, or the institution itself if it has autonomous admission authority) is an EducationAuthority. If NBTE has AuthorityType = Admissions, it can define a cycle. If the institution itself has admission authority (e.g., private universities with autonomous admission), the institution would need to be represented as an EducationAuthority.

**Is this a modeling problem?** Partially. The current model assumes that all admission cycles are defined by EducationAuthorities. In reality, some institutions have autonomous admission authority. The recommended model handles this through the existing mechanism: the institution's governing authority defines the cycle, and the institution defines its policy within that cycle. For truly autonomous institutions, the institution itself could be recorded as an EducationAuthority (with AuthorityType = Admissions) — this is a data modeling choice, not a schema change.

**Scenario: One institution participating in multiple authorities/cycles.**

UNILAG participates in both JAMB UTME and Direct Entry (also JAMB-managed). Under the recommended model, UNILAG has AdmissionPolicies for each cycle. `AdmissionPolicy.admission_cycle_id` references the specific cycle. This works — UNILAG can have multiple policies for multiple cycles.

**Scenario: Does "AdmissionCycle" conflate multiple concepts?**

The domain evidence shows that:
- **Examination cycle** (JAMB UTME) = a series of examination events with phases
- **Authority cycle** (JAMB admission window) = the regulatory period during which admission can occur
- **Institution admission cycle** (UNILAG Post-UTME) = institution-specific screening within the authority cycle

The current model captures #2 (authority cycle) as AdmissionCycle and #3 (institution admission) as AdmissionPolicy. #1 (examination events) is not modeled as a cycle — it is the Examination phase within the authority cycle's PhaseSequence.

**This separation is correct.** The authority cycle defines the overall timeline. Institutional policies define specific requirements within that timeline. Examination events are phases within the cycle. **No conflation.**

## Verdict

**REMAINS.** The recommended model is correct. The "gap" for autonomous institutions is handled by representing them (or their governing body) as EducationAuthorities with Admissions authority type. This is a data modeling choice, not a schema change.

---

# D3 — Scholarship Provider Relationship

## Recommendation Challenged

Direct FK (`scholarship_provider_id`) + Institution ScholarshipProvider auto-creation.

## Strongest Argument

INV-S1 ("A Scholarship has exactly one Provider") is trivially enforced by a DB FK constraint with direct FK. Polymorphic morph loosens this invariant. Direct FK is simpler for admin UI, import logic, and search projections.

## Failure Scenarios

**Scenario: Auto-creation creates unverified canonical entities.**

When `Institution::establish()` is called from an import (e.g., scraping an institution website), the auto-creation side-effect creates a ScholarshipProvider record. This ScholarshipProvider inherits the Institution's provenance — which for a scraped website is "Medium (Unverified initially)."

Now an admin creates a Scholarship and selects this unverified ScholarshipProvider from the dropdown. The Scholarship now references an unverified provider. **This violates the intent of the verification pipeline** — canonical entities should be verified before being referenced by other entities.

**Worse:** If the import creates duplicate Institutions (same institution from two sources, before the verification engine merges them), each duplicate creates its own ScholarshipProvider. Now there are duplicate ScholarshipProviders for the same institution. The verification engine matches Institutions, but does it also deduplicate ScholarshipProviders?

**This is a genuine failure of auto-creation.** The import pipeline's idempotency guarantee ("re-running the same import must produce the same result") must extend to side-effect entities.

**Scenario: Provider name changes.**

"Shell Nigeria Exploration and Production Company" rebrands to "SNEPCo." The ScholarshipProvider name should change. If auto-created from an Institution, the ScholarshipProvider name should track the Institution name. **No sync mechanism is defined.** The auto-creation creates the ScholarshipProvider once, but does not keep it in sync.

**Scenario: Not all institutions offer scholarships.**

Auto-creating a ScholarshipProvider for every Institution creates ~170 records that will never be referenced by any Scholarship. This is "premature entity creation" — creating canonical entities speculatively. **Low severity** (the records are small and inactive) but it contradicts the principle of minimal canonical state.

**Scenario: Co-funded scholarships.**

The domain model (decision A2-3) acknowledges co-funded scholarships but models them with a single primary provider. With direct FK, a co-funded scholarship (e.g., Shell + FG partnership) must choose one primary provider. The other funder is not represented. **This is an accepted limitation** (documented in domain discovery as "Low risk") and does not change with polymorphic vs FK.

## The Auto-Creation Danger

The auto-creation recommendation introduces a subtle but serious pattern: **creating canonical entities as side effects of other entity creation.** This violates the principle that canonical entities should be created intentionally, through verified import or admin action, not as automatic byproducts.

The danger is particularly acute because ScholarshipProvider is a **supporting entity with minimal behaviour** — it exists primarily as a referential integrity guard. Auto-creating it removes the intentional step that ensures the entity is correct.

## Alternative: On-Demand Creation

Instead of auto-creating ScholarshipProvider on `Institution::establish()`, create it **when needed:**

1. Admin creates a Scholarship for an institution → admin creates/selects a ScholarshipProvider with `type = Institution` explicitly.
2. Import discovers a scholarship offered by an institution → import adapter creates a ScholarshipProvider record as part of the scholarship import, not the institution import.

**This avoids all auto-creation failures:**
- No unverified entities — the ScholarshipProvider is created in the same import context as the Scholarship, with the same provenance.
- No duplicates — each import creates one ScholarshipProvider per institution (idempotent via matching).
- No premature creation — ScholarshipProviders are created only when a Scholarship references them.
- Name sync is natural — the ScholarshipProvider is created with the Institution's name at the time of scholarship creation. If the institution name later changes, the ScholarshipProvider name can be updated via admin or event listener.

## Verdict

**MODIFIED.** Direct FK is correct. Auto-creation is dangerous and should be rejected. The correct pattern is:

- `scholarships.scholarship_provider_id` → FK to `scholarship_providers`
- `scholarship_providers.institution_id` → nullable FK (set when `type = Institution`)
- **No auto-creation on `Institution::establish()`.** ScholarshipProviders are created explicitly when needed (by admin or import).

This is the brief's Option A, not Option C. Option A was the correct recommendation all along. The "extra step" of creating a ScholarshipProvider for institution-offered scholarships is **intentional creation**, which is the correct pattern for canonical entities.

---

# Cross-Decision Analysis

## BD-1 ↔ External Identifiers/Imports

**New decision discovered: BD-5 — External source identifier storage.**

The canonical schema lacks columns for JAMB code, NUC code, and other external identifiers. These are the primary matching keys during import (confidence = 1.0 on exact match). Without dedicated columns, entity matching relies on name similarity alone (max confidence 0.95), which cannot auto-merge.

**BD-5 is a genuine implementation blocker** that was not identified in the original brief. It interacts with BD-1 (the columns are string attributes, not PKs) but is independent of the PK decision.

**Proposed resolution:**
```
institutions.jamb_code  VARCHAR(20) NULL  UNIQUE WHERE NOT NULL
institutions.nuc_code   VARCHAR(20) NULL  UNIQUE WHERE NOT NULL
programmes.jamb_code   VARCHAR(20) NULL  -- programme codes in JAMB brochure
```

## BD-1 ↔ D3 Provider Identity

ScholarshipProvider is a supporting entity with `auto-increment PK` per 03-domain.md. With bigint PKs (BD-1), this is consistent. No interaction issue.

## BD-1 ↔ D1 AdmissionCycle Identity

AdmissionCycle is an aggregate root. With bigint PK (BD-1), `admission_cycles.id = bigint`. The FK `admission_policies.admission_cycle_id = bigint FK`. Consistent. No interaction issue.

## BD-2 ↔ D3 Polymorphism

If D3 resolves to direct FK (recommended), the `provider_type`/`provider_id` morph columns are removed. This eliminates one polymorphic relationship, reducing the scope of BD-2 (morphMap) by one. **Positive interaction** — simplifying the morph landscape.

## D1 ↔ BD-3 Phase Representation

If AdmissionCycle belongsTo EducationAuthority (D1 = EducationAuthority), the default PhaseSequence template is authority-defined (JAMB uses Registration → Examination → Results → Admission). If D1 were Institution, institutions would define their own phase templates, which are more variable. **D1 = EducationAuthority makes BD-3 simpler** because there are fewer distinct phase templates. The interaction supports the D1 recommendation.

## BD-4 ↔ Historical/Versioned Data

If CASCADE is applied to children within aggregates (modified BD-4), deleting an AdmissionCycle would delete its AdmissionPolicies. But AdmissionPolicies have historical value (candidates need to see past admission requirements). **This means AdmissionCycle should never be hard-deleted — only Closed/Archived.** CASCADE is a safety net for test data and admin errors, not for routine operations. The domain lifecycle (close/archive) prevents data loss. CASCADE handles the cleanup case.

## D3 ↔ Acquisition Entity Matching

If a scholarship import references a provider by name (e.g., "Shell Nigeria"), the import adapter must match this to an existing ScholarshipProvider or create a new one. With direct FK (D3), this is a straightforward lookup/create. With polymorphic, the adapter would also need to determine if the provider is a ScholarshipProvider or an Institution — adding complexity without benefit.

---

# Second-Order Audit

For each decision, the critical second-order questions:

## BD-1

**What must be true for bigint to work?** The `matching_entity_id` column in `pending_imports` must be changed from UUID to bigint. **Is this documented?** No — 06-data-acquisition.md still says UUID. **Is it a safe implementation convention?** Yes — it is a one-column type correction in staging schema. **What if wrong?** If PK is later changed to UUID, every FK and index changes. **Reversible?** No — full database migration. **Can BD-1 be deferred?** **No.** Every migration depends on it. It must be the first decision.

## BD-2

**What must be true for morphMap to work?** All morph writes go through Eloquent. No raw SQL writes `_type` values. **Safe?** Yes — Laravel convention. **What if wrong?** Data migration on `_type` columns. **Reversible?** Yes — one UPDATE per column. **Can BD-2 be deferred?** Partially. The morphMap can be added after initial migrations, but the `_type` values must be consistent from the start.

## BD-3

**What must be true for JSONB PhaseSequence to work?** PostgreSQL supports JSONB + GIN indexing. The PhaseSequence VO is correctly implemented with custom Eloquent cast. **Safe?** Yes — Laravel JSON casting is standard. **What if wrong?** Migrating JSONB → normalized table requires extracting data from JSON into rows. **Reversible?** Yes, but with effort. **Can BD-3 be deferred?** **No.** The admission_cycles migration schema depends on it.

## BD-4

**What must be true for category-specific cascade to work?** Every FK must have an explicit ON DELETE clause. **Safe?** Yes — this is explicit migration design. **What if wrong?** Orphaned records or unintended cascading deletes. **Reversible?** FK constraints can be altered. **Can BD-4 be deferred?** Partially. RESTRICT everywhere is safe as a default. Specific CASCADE/SET NULL can be added in follow-up migrations. But the initial migrations should specify the correct behavior.

## D1

**What must be true for EducationAuthority ownership to work?** Every admission cycle has a defining EducationAuthority. Institutions that have autonomous admission authority are represented as (or have) an EducationAuthority. **Is this documented?** Partially — 03-domain.md implies it but does not explicitly address autonomous institutions. **Safe?** Yes — the existing EducationAuthority entity with AuthorityType = Admissions covers this. **Can D1 be deferred?** **No.** The admission_cycles migration depends on the FK direction.

## D3

**What must be true for direct FK (without auto-creation) to work?** ScholarshipProviders are created explicitly when needed. **Is this documented?** No — the import adapter behavior for provider creation is undefined. **Safe?** Yes — it is the default pattern for supporting entities. **Can D3 be deferred?** **No.** The scholarships migration depends on the FK vs morph column decision.

---

# New Decisions Discovered

## BD-5 — External Source Identifier Storage

**Problem:** The canonical schema has no columns for JAMB code, NUC code, or other external identifiers. These are the primary matching keys during import (exact match = confidence 1.0). Without them, entity matching relies on name similarity alone.

**Status:** Implementation blocker (HD-5 in decision audit).

**Recommendation:** Add nullable string columns to institutions and programmes:

```
institutions.jamb_code  VARCHAR(20) NULL
institutions.nuc_code   VARCHAR(20) NULL
programmes.jamb_code   VARCHAR(20) NULL
```

With partial unique indexes: `CREATE UNIQUE INDEX institutions_jamb_code_uniq ON institutions (jamb_code) WHERE jamb_code IS NOT NULL`.

**Human approval required?** Yes — this adds columns not in any canonical document. It is a D-class change (new scope) that requires acceptance via ADR.

---

# Proposed ADR Outline for BD-1

```
ADR-022: Primary-Key and Identity Strategy

Status: Proposed
Date: 2026-08-10

Decision:
- All domain entity PKs use bigint auto-increment (Laravel default)
- External source identifiers stored as dedicated nullable string columns
- Import/staging tables use UUID PK (outside domain boundary)
- Public resource identity via slug (never PK)
- Typesense document ID = string-cast PK

Rationale:
- Laravel ecosystem alignment: zero custom code, zero package friction
- StudyNexus is a single-DB monolith; no cross-service PK collision risk
- Entity matching is attribute-based (external codes, name similarity); PK type is irrelevant to matching
- PK is never exposed in URLs (slugs are public identifiers)
- At ~100K entities, performance/storage differences between bigint and UUID are negligible

Consequences:
- 06-data-acquisition.md: matching_entity_id changes from UUID to bigint
- PRODUCT-EXPERIENCE-ARCHITECTURE.md: "UUID" labels on Typesense doc IDs updated to "ID"
- disciplines and cut_off_marks tables: UUID PK changes to bigint (overriding 03-domain.md lines 478, 504)
  - This is an A-class correction: these tables were defined during search optimization,
    not as a deliberate PK strategy decision

Alternatives Considered:
- UUID: works but adds per-model overhead with no functional benefit at this scale
- ULID: weakest ecosystem support; time-sortability redundant with created_at
- Hybrid (bigint + public UUID): adds complexity; slugs already serve as public identifiers
```

---

# Proposed ADR Outline for BD-5

```
ADR-023: External Source Identifier Storage

Status: Proposed
Date: 2026-08-10

Decision:
- Add jamb_code (nullable VARCHAR(20)) and nuc_code (nullable VARCHAR(20)) to institutions
- Add jamb_code (nullable VARCHAR(20)) to programmes
- Partial unique indexes on non-null values

Rationale:
- These codes are the primary entity-matching keys during import (confidence = 1.0 on exact match)
- Without dedicated columns, import matching relies on name similarity (max confidence 0.95)
- External codes are business attributes, not canonical identity — they can change
- They serve both import matching and display (JAMB code shown on institution detail pages)

Consequences:
- 05-implementation.md: new columns on institutions and programmes tables
- 06-data-acquisition.md: match_keys object can reference database columns directly
- Admin UI: JAMB code / NUC code fields on institution and programme forms
```

---

# Final Decision Table

| ID | Final Recommendation | Confidence | Human Approval Required? | Why |
|----|---------------------|------------|--------------------------|-----|
| BD-1 | bigint auto-increment PK for all domain entities; dedicated columns for external identifiers; slug for public URLs; PK-derived Typesense doc ID | **HIGH** | **YES** | No ADR exists. 3 documents signal UUID. This decision affects every migration, FK, and import mapping. The analysis strongly favors bigint, but the decision must be formally made and documented. |
| BD-2 | Short aliases via `Relation::enforceMorphMap()` | **HIGH** | **YES** | 3 contradictory conventions exist. Must be consistent from first migration. |
| BD-3 | JSONB column (with GIN index) for PhaseSequence VO + denormalized `current_phase` string column | **HIGH** | **YES** | 03-domain.md and 05-implementation.md define materially different schemas. Storage format must be decided before admission_cycles migration. |
| BD-4 | Category-specific cascade: CASCADE within aggregates, RESTRICT cross-aggregate, SET NULL for provenance, soft deletes on aggregate roots only | **HIGH** | **YES** | No document comprehensively defines FK ON DELETE behavior. Must be specified before any migration. |
| D1 | AdmissionCycle belongsTo EducationAuthority; institution scope via AdmissionPolicy governable_type morph | **HIGH** | **YES** | CRITICAL finding. Canonical cluster says EducationAuthority; 05-implementation.md says Institution. Real Nigerian context supports the canonical model. |
| D3 | Direct FK (`scholarship_provider_id`); no auto-creation; `scholarship_providers.institution_id` nullable FK (set when type = Institution) | **HIGH** | **YES** | Canonical cluster says direct FK. Polymorphic in 05-implementation.md. Auto-creation rejected due to unverified-entity risk. |

# Identity Concern Table

| Identity Concern | Recommended Mechanism | Same as DB PK? | Reason |
|------------------|----------------------|----------------|--------|
| Canonical entity identity | bigint auto-increment (`id`) | Yes | Laravel default; simplest correct solution for single-DB monolith |
| External source identity | Dedicated nullable columns (`jamb_code`, `nuc_code`) | No | Business attributes for import matching; can change; not identity |
| Import identity | UUID on staging tables; `matching_entity_id` = bigint (matching domain PK) | No | Staging outside domain boundary; UUID prevents batch collision; domain match uses domain PK type |
| Public resource identity | Slug column (unique within scope) | No | Human-readable, SEO-optimized; PK never in URLs |
| URL identity | Slug-based routes with 301 redirect support | No | Canonical URL strategy per 04-architecture.md |
| Typesense document identity | String-cast PK (`(string) $model->getKey()`) | Yes (derived) | Scout default; deterministic; works with any PK type |
| Historical record identity | bigint auto-increment (separate row per historical point) | Yes | Cross-cycle = new row; intra-cycle = update + activity log |
| Audit/activity identity | bigint auto-increment (spatie/laravel-activitylog default) | N/A | Activity log has own PK; `subject_id` references domain PK |

---

*This adversarial review has challenged every recommendation, identified failure scenarios, exposed hidden assumptions, and produced final recommendations. No canonical documents have been modified. No baseline has been modified. No code has been written. No migrations have been created. No reconciliation has been executed. Awaiting human resolution of all six decisions plus the newly discovered BD-5.*
