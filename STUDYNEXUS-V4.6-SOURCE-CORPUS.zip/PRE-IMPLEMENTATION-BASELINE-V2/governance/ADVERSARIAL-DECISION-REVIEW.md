# StudyNexus — Adversarial Decision Review

**Date:** 2026-08-17 (V4.6 supersession note: 2026-08-19)
**Purpose:** Rigorous adversarial review of five proposed foundational decisions before any implementation or migration work begins.
**Constraint:** No canonical documents modified. No migrations. No application code. No silent resolution of any decision.

> **V4.6 supersession note (2026-08-19):** This review was authored when the V2-era counts (11 domain entities, 28 VOs, 16 enums, 58 tables) were current. The V4.6 canonical counts are: **13 domain entities**, **29 VOs**, **17 enums**, **61 tables** — see `canonical/03-domain.md` §2/§3 and `canonical/05-implementation.md` §4. References to "11 domain entities" in this review are V2-era and should be read as historical context for the decision under review, not as current canonical counts.

---

## PART 1 — REOPEN THE FIVE DECISIONS

Each of the five decisions is reopened with full adversarial scrutiny. For each decision we present: (1) the architectural question, (2) canonical evidence, (3) contradictions found, (4) assumptions in previous analysis, (5) attack on the previously recommended option, (6) hidden second-order consequences, (7) evaluation across all dimensions, (8) classification, (9) confidence, and (10) evidence that would change the conclusion.

---

### 1.1 BD-1 — Residual UUID Question

**1. Architectural Question**

What type should primary keys be for StudyNexus's 11 domain entities, 2 reference/query models (Discipline, CutOffMark), and staging tables? Should the system use UUID for all primary keys, bigint for all primary keys, or a heterogeneous mix? The previous recommendation was Option D: bigint domain PKs with UUID only for disciplines.

**2. Canonical Evidence**

- **03-domain.md**: `establish(name, type, registrationIdentifier, ...)` — mentions `registrationIdentifier` as a parameter to the Institution factory method but does not specify what type the PK should be. The domain model defines entities by their invariants, operations, and consistency boundaries — not by their persistence identity type.
- **05-implementation.md**: The `disciplines` table uses `id UUID Primary key`. The `programmes` table has `discipline_id (UUID FK nullable, references disciplines)`. The `cut_off_marks` table uses `programme_id (UUID FK, references programmes, ON DELETE CASCADE)`, `admission_cycle_id (UUID FK, references admission_cycles, ON DELETE CASCADE)`, and `source_id (UUID FK nullable, references information_sources, ON DELETE SET NULL)`.
- **05-implementation.md**: `OrganizationMember` uses `bigint PK` and `bigint (morph ID)` — this is a direct inconsistency with the UUID usage elsewhere in the same document.
- **06-data-acquisition.md**: `import_batches` uses UUID for `id`. `pending_imports` uses UUID for `id` and `matching_entity_id`.
- **No canonical document explicitly states what PK type aggregate roots should use.** The implementation doc is the only place where PK types appear, and it is internally inconsistent.

**3. Contradictions**

- 05-implementation.md is **internally inconsistent**: it uses UUID for `disciplines.id` and UUID FKs in `cut_off_marks`, but `bigint` for `OrganizationMember`. Within a single canonical document, two different PK strategies coexist without explanation.
- The implementation doc uses UUID FKs in `cut_off_marks` referencing `programmes` and `admission_cycles`, but **never states what the PK type of those referenced tables IS**. This is a gap, not just an inconsistency — if `programmes.id` is `bigint`, then `programme_id (UUID FK)` is a **type mismatch** that PostgreSQL would reject.
- There is a genuine contradiction between the UUID FK references in `cut_off_marks` and the bigint PK pattern used in `OrganizationMember`. The document does not acknowledge this contradiction or explain why different tables use different strategies.

**4. Assumptions in Previous Analysis**

- Assumed "cross-environment seeding stability" requires UUID for disciplines — this assumption was never challenged. Stable seeded bigint IDs (using explicit ID values in seeders like `['id' => 1, 'name' => 'Engineering', 'slug' => 'engineering']`) achieve the same goal with less complexity.
- Assumed FK and referenced PK must be the same type — this is not merely an assumption but a **PostgreSQL hard constraint**. You cannot have `programme_id uuid REFERENCES programmes(id)` if `programmes.id` is `bigint`. PostgreSQL enforces type matching on foreign keys.
- Assumed UUID is appropriate for import/staging tables — this is reasonable since import jobs may run concurrently and generate records independently, but it should be stated explicitly rather than assumed.
- Did NOT question whether disciplines need UUID at all — the seeding stability argument was accepted at face value without examining alternatives.
- Did NOT verify whether the UUID FK references in `cut_off_marks` are consistent with the (unspecified) PK types of the referenced tables.

**5. Attack on Option D (bigint + UUID for disciplines only)**

Option D creates **FK type heterogeneity**: most foreign keys in the system would be `bigint`, but `discipline_id` would be `UUID`. This means:

- **Eloquent relationship definitions need explicit key type overrides.** By default, Laravel assumes all FKs are the same type as the parent PK. Mixed types require manual configuration on every relationship involving disciplines.
- **Any join across `discipline_id` and other FKs requires type awareness.** A query joining programmes (bigint `institution_id`, UUID `discipline_id`) with institutions (bigint `id`) is straightforward, but the developer must remember which FK is which type.
- **Developer cognitive load increases.** Every time a developer writes a migration or defines a relationship involving disciplines, they must remember: "discipline_id is UUID, everything else is bigint." This is a tax on every future developer.
- **The justification for disciplines UUID (seeding stability) is weak.** Stable seeded bigint IDs achieve the same goal. Explicit ID values in seeders (`['id' => 1, 'name' => 'Engineering']`) are the standard Laravel pattern for reference data. Deterministic UUIDs (UUIDv5 from namespace + slug) also work but add complexity for no benefit over explicit seeded IDs.
- **If `cut_off_marks` references `programmes` with UUID FK but `programmes` has bigint PK, that's a TYPE MISMATCH** — this is a serious bug in the current canonical document, not a design decision. Option D does not address this bug; it accepts the inconsistency.
- Using UUID for disciplines but bigint elsewhere creates **anomaly in the schema** that has no domain justification. No domain invariant says "disciplines need UUID identity." No business requirement demands it. The only justification is a weak operational preference (seeding stability) that has simpler alternatives.

**6. Hidden Second-Order Consequences**

- **FK type heterogeneity means ORM relationships need explicit type annotations.** In Laravel/Eloquent, when you define `return $this->belongsTo(Discipline::class)`, the framework assumes the FK column type matches the parent PK type. With mixed types, you need `return $this->belongsTo(Discipline::class, 'discipline_id')` with additional configuration, and some operations (like `sync()`, `attach()`) may behave unexpectedly with type mismatches.
- **Any future table referencing both a bigint-PK entity and disciplines needs mixed-type FKs.** A hypothetical `programme_discipline_tags` table would have `programme_id bigint` and `discipline_id uuid` — two FK columns of different types. This is valid SQL but increases the cognitive burden for every developer who interacts with this schema.
- **Typesense document IDs are strings regardless** — PK type doesn't affect search indexing or querying. Typesense accepts any string as a document ID. Whether the ID is `"42"` or `"550e8400-e29b-41d4-a716-446655440000"` makes no functional difference.
- **URL slugs are used for public URLs, not PKs** — PK type doesn't affect SEO or URL structure. Institutions are identified by slug (`/institutions/university-of-lagos`), not by PK.
- **Import matching uses business identifiers (JAMB code, name), not PKs** — PK type doesn't affect data acquisition. The import pipeline matches on JAMB code, NUC code, name similarity, and slug — never on PK value.
- **Database tooling and debugging** — UUID values are harder to read in logs, debugging sessions, and ad-hoc queries. `WHERE id = 42` is more immediately comprehensible than `WHERE id = '550e8400-e29b-41d4-a716-446655440000'`. This is a minor but persistent developer experience cost.
- **Backup and restore** — UUIDs double the storage for PK and FK columns. For a schema with many FK relationships, this adds up. Larger backups mean longer restore times.

**7. Evaluation Across All Dimensions**

| Dimension | Assessment |
|-----------|------------|
| **Domain modeling** | bigint is simpler; no domain concept requires UUID identity. No invariant, operation, or consistency boundary depends on PK type. |
| **Relational integrity** | Homogeneous PK types are simpler. Mixed types create confusion and risk type mismatches. PostgreSQL enforces FK/PK type matching — heterogeneous types require constant vigilance. |
| **Laravel/Eloquent ergonomics** | bigint is Laravel's default. UUID requires explicit configuration (`$table->uuid('id')->primary()`, custom casting, relationship overrides). Every UUID PK is a deviation from the framework's conventions. |
| **PostgreSQL behavior** | bigint is 8 bytes, UUID is 16 bytes. bigint is faster for joins (smaller index entries, better cache locality), index scans, and sequential access. UUID random inserts cause B-tree page splits and index fragmentation. |
| **Indexing/query performance** | bigint B-tree indexes are smaller (8 bytes per key vs 16) and faster. For a table with 4 FKs, that's 32 bytes of bigint FK data vs 64 bytes of UUID FK data per row — a 2x difference that compounds across millions of rows. |
| **Data acquisition/import** | PK type is irrelevant — matching uses business identifiers. Import pipeline creates records through Actions, not through distributed direct writes. |
| **Reconciliation** | No impact. Reconciliation operates on business keys, not PKs. |
| **Provenance** | No impact. Provenance references sources and import batches, not PKs. |
| **Search/Typesense** | No impact. Typesense uses string IDs regardless. |
| **SEO** | No impact. URLs use slugs, not PKs. |
| **Admin workflow** | No impact. Filament admin panels work with both types; bigint is the default. |
| **Future expansion** | UUID only helps if distributed writes are needed (multi-primary PostgreSQL, CockroachDB, etc.). StudyNexus is single-writer PostgreSQL. No credible path to distributed writes has been articulated. |
| **Data migration cost** | bigint → UUID migration is expensive (all FKs must change type, all referencing code must change). UUID → bigint is also expensive. Starting with the wrong type has a high switching cost. |
| **Operational complexity** | Homogeneous types are simpler. One PK type means one mental model, one set of conventions, one set of tooling assumptions. |
| **Developer cognitive load** | One PK type is simpler than two. Every developer must learn and remember "disciplines use UUID" under Option D. Under uniform bigint, no special knowledge is needed. |
| **Testing complexity** | bigint with auto-increment is simpler in tests. UUID requires generation in factories. Explicit seeded IDs for reference data are even simpler. |
| **Long-term maintainability** | Homogeneous PK types reduce the surface area for bugs (type mismatches, forgotten type overrides, incorrect FK assumptions). |

**8. Classification**

This is an **IMPLEMENTATION DETAIL**, not a foundational decision. No domain invariant depends on PK type. The canonical documents never specify PK type. The decision affects only the persistence layer. However, because the implementation doc is internally inconsistent and the inconsistency could propagate into migrations, it must be resolved before migration work begins.

**9. Confidence**

**MEDIUM** — the analysis is clear and the technical arguments strongly favor uniform bigint, but there are reasonable people who prefer UUID for distributed scenarios or for "future-proofing." If StudyNexus never needs distributed writes (which is the expected case), bigint is unambiguously better. The MEDIUM confidence reflects the possibility that distributed requirements could emerge, not any weakness in the current analysis.

**10. Evidence That Would Change Conclusion**

If StudyNexus will need multi-primary-write PostgreSQL (e.g., multi-region deployment with writeable replicas in Lagos and Accra), UUID becomes strongly preferred because it eliminates PK collision risk across write nodes. If a credible path to distributed writes is articulated, the conclusion should be revisited. Absent that, uniform bigint is the correct choice.

---

### 1.2 BD-3 — AdmissionCycle Phase Storage

**1. Architectural Question**

Should admission cycle phases be stored as a JSONB Value Object (PhaseSequence) on the `admission_cycles` table, or as a normalized child table with one row per phase? The previous recommendation was Option A: JSONB PhaseSequence Value Object.

**2. Canonical Evidence**

- **03-domain.md**: PhaseSequence is VO #11 — "Ordered list of admission cycle phases with timing. Phase names and count are data (Nigeria: Registration → Examination → Results → Admission; UK UCAS: Application → Decisions → Reply → Clearing)."
- **03-domain.md**: "Phase names and count are data" — this is a key canonical statement. Phases vary by country/authority. The set of phases is NOT fixed; it's data that differs per educational system.
- **02-decisions.md**: "JSON columns for collection VOs (rules stored as JSON arrays within their parent cast)" — the ADR on VO casts recommends JSON columns for collection VOs.
- **04-architecture.md**: PhaseSequence is listed as a VO with custom Eloquent cast.
- **05-implementation.md**: `admission_cycles` table has `id, institution_id FK, name, admission_pathway (string — AdmissionPathway VO), academic_year, opens_at, closes_at, results_at, status`. No `phases` column, no `current_phase` column, no child table for phases.

**3. Contradictions**

- The canonical documents say PhaseSequence is a VO, which implies JSONB storage per the ADR on VO casts. BUT the `admission_cycles` table in the implementation doc has **no column for storing phases at all**. This is a gap — the domain model defines a PhaseSequence VO, but the implementation schema doesn't persist it.
- The canonical documents define `advancePhase()` as a domain method on AdmissionCycle that needs to know "current phase" and advance to "next phase." But the `admission_cycles` table has **no `current_phase` column**. Without it, the system cannot track which phase a cycle is currently in.
- The `status` column on `admission_cycles` may be intended to track the current phase, but `status` is typically a lifecycle status (draft, active, closed, archived), not a phase name (registration, examination, results, admission). These are different concepts.

**4. Assumptions in Previous Analysis**

- Assumed "domain VO = JSONB persistence" — this is a false equivalence. The domain model and persistence model CAN differ. A VO in the domain can be persisted as JSONB, as a normalized child table, or as a hybrid (JSONB + extracted columns).
- Assumed JSONB is sufficient for all phase-related operations — did not consider the need for independent querying of current phase.
- Did not consider the `current_phase` gap in the implementation schema.
- Assumed Filament can handle JSONB editing with custom components — this is true but underestimates the development cost of custom form components vs. using standard Filament relation managers for a child table.

**5. Attack on Option A (JSONB Only)**

- If phases are stored purely as JSONB, querying "all cycles currently in Examination phase" requires a JSONB containment query: `WHERE phases @> '[{"name": "examination", "status": "current"}]'`. This is possible with GIN indexing but less ergonomic and less performant than `WHERE current_phase = 'examination'`.
- Filtering by current phase in Typesense requires denormalization anyway — you'd need to include `current_phase` as a top-level field in the Typesense document regardless of how phases are stored in PostgreSQL.
- Notification dispatch on phase advance (e.g., "notify all applicants that Examination phase has begun") needs to know the current phase. With JSONB-only storage, this requires loading the PhaseSequence VO and computing the current phase from the JSONB data. This works but adds a read+compute step that a `current_phase` column would eliminate.
- "Allow administrative editing" of phases is awkward with pure JSONB — Filament would need a custom form component that understands the PhaseSequence structure. A normalized child table would use Filament's built-in `Repeatable` or `RelationManager`, which is less custom code.
- The claim "domain VO = JSONB persistence" is a **false equivalence**. Domain model and persistence model are separate concerns. The PhaseSequence VO is correct in the domain; its persistence strategy is an independent decision.

**6. Hidden Second-Order Consequences**

- If phases become queryable (e.g., "show me all cycles in Registration phase across all institutions"), JSONB queries are slower and more complex than column-based queries. For a dashboard showing phase distribution across 500 cycles, `SELECT current_phase, COUNT(*) FROM admission_cycles GROUP BY current_phase` is trivial with a column but requires JSONB aggregation with JSONB storage.
- If phases need to be exposed via API (e.g., `/api/cycles?phase=examination`), JSONB requires custom query builders. A `current_phase` column works with standard Laravel query scopes.
- Analytics on phase transitions (how long did each phase take on average?) require either JSONB path queries or application-level computation. With JSONB, you'd extract `starts_at` and `ends_at` for each phase from the JSONB array and compute durations. This is doable but not as clean as querying a normalized table.
- The `advancePhase()` domain method must update `current_phase` atomically with the PhaseSequence state. This is a consistency requirement that the domain model enforces, but the persistence layer must support it. A `current_phase` column makes this explicit; JSONB-only makes it implicit.
- Phase-advanced events (for the event-sourced notification system) need to carry the old and new phase. With a `current_phase` column, this is trivial to detect in an Eloquent model event. With JSONB-only, you'd need to compare the old and new JSONB values, which is more complex.

**7. Evaluation Across Dimensions**

| Dimension | Assessment |
|-----------|------------|
| **Domain modeling** | PhaseSequence as VO is correct — phases are part of the cycle's consistency boundary, have no independent lifecycle, and no identity beyond their value. |
| **Relational integrity** | JSONB doesn't enforce referential integrity on phase names. A typo in a phase name ("examinaton" instead of "examination") would be silently accepted. A child table with a CHECK constraint or enum would prevent this. |
| **Laravel/Eloquent** | JSONB casts are well-supported; child table is also well-supported. Both approaches are idiomatic Laravel. |
| **PostgreSQL** | JSONB indexing with GIN is possible; child table with B-tree is faster for queries. For the expected scale (100-500 admission cycles), the performance difference is negligible. |
| **Performance** | For ~100-500 admission cycles, performance difference between JSONB and child table is negligible. Neither approach will be a bottleneck. |
| **Data acquisition** | Importing phases as JSONB is simpler (one column to populate vs. multiple rows in a child table). The import pipeline can set the entire PhaseSequence at once. |
| **Admin workflow** | JSONB requires a custom Filament component; child table uses standard Filament `Repeatable` or `RelationManager`. Custom components add development and maintenance cost. |
| **Query ergonomics** | `current_phase` column is superior for filtering, grouping, and notification triggers. JSONB requires specialized queries. |

**8. Classification**

This is **borderline between implementation detail and foundational**. The domain model is clear (VO), but the persistence question affects query capability, notification triggers, and API design. The missing `current_phase` column is a gap in the implementation doc that must be fixed regardless of the PhaseSequence storage decision.

**9. Confidence**

**HIGH** — the JSONB + `current_phase` hybrid is clearly the best solution. It preserves domain VO integrity while enabling the queries and notifications that the system needs.

**10. Evidence That Would Change Conclusion**

If phase analytics become a primary feature (e.g., a dashboard showing phase duration statistics, phase transition timelines, cross-institution phase comparisons), a normalized child table may be better for analytical queries. For the current MVP scope, JSONB + `current_phase` is optimal.

---

### 1.3 BD-5 — External Identifier Model

**1. Architectural Question**

How should external identifiers (JAMB codes, NUC codes, etc.) be modeled on the Institution entity? Should they be source-specific columns (`jamb_code`, `nuc_code`) on the `institutions` table, or a generic `external_identifiers` table? The previous recommendation was Option A: source-specific columns for MVP.

**2. Canonical Evidence**

- **03-domain.md**: `establish(name, type, registrationIdentifier, ...)` — mentions `registrationIdentifier` as a parameter but doesn't define its type, storage, or relationship to JAMB/NUC codes.
- **06-data-acquisition.md**: "Exact match on JAMB code or NUC code (if available) → confidence = 1.0" — the fuzzy matching algorithm relies on JAMB code and NUC code for high-confidence matching. This implies these identifiers exist and are queryable.
- **05-implementation.md**: **No `jamb_code` or `nuc_code` columns appear on the `institutions` table** in the implementation doc. The table has `id, name, slug, type, tier, ownership, year_established, location (Location VO), website_url, is_active, provenance, created_at, updated_at`.
- **04-architecture.md P5**: "Global-First, Nigeria-First-Dataset. Nigeria is the first dataset, not the architectural boundary. Nigerian concepts (JAMB, WAEC, NUC, UTME) are instances of universal concepts." — This principle directly governs this decision.

**3. Contradictions**

- The domain model mentions `registrationIdentifier` in `establish()`, but the implementation schema doesn't have it as a column or a related table. This is a gap — the domain says institutions have identifiers, but the implementation doesn't persist them.
- The data acquisition doc relies on JAMB code and NUC code for fuzzy matching (`confidence = 1.0`), but they don't exist as columns in the implementation schema. The matching algorithm references identifiers that the schema cannot store.
- P5 says Nigerian concepts are instances of universal concepts — but `jamb_code`/`nuc_code` as column names encode Nigeria-specific assumptions into the schema. A `jamb_code` column is not an instance of a universal concept; it's a hard-coded Nigerian concept.

**4. Assumptions in Previous Analysis**

- Assumed "wait until the third source" is a valid migration trigger — this is arbitrary and was not critically examined.
- Assumed column-based identifiers are "simpler for MVP" — simpler to code, yes, but not simpler to maintain when the migration comes.
- Assumed the migration from columns to a generic table would be "routine" — it's not; it requires data migration, FK changes, application code changes, Filament resource changes, import adapter changes, search projection changes, and test updates.
- Did NOT evaluate whether the migration from columns → generic table is actually cheaper than building the generic table from day one.

**5. Attack on Option A (source-specific columns for MVP)**

- `jamb_code` and `nuc_code` **ENCODE Nigeria-specific assumptions into the schema**. These column names are not universal concepts — they are Nigerian regulatory body abbreviations. This directly violates P5 (Global-First, Nigeria-First-Dataset).
- When Kenya adds KUCCPS code, Ghana adds GTEC code, South Africa adds CHE code, each requires a **schema migration** (adding a new column). With a generic table, adding a new authority's code requires zero schema changes — just a new row in `education_authorities` and a new identifier record.
- The "wait until third source" migration trigger is **arbitrary**. JAMB + NUC is already TWO sources. WAEC, NBTE, NCCE are P0/P1 sources right behind them. The trigger would fire almost immediately after MVP launch.
- Migrating from columns → generic table is **NOT cheap**:
  - Data migration: copy `jamb_code`/`nuc_code` values to the new `external_identifiers` table, creating the proper FK> records
  - Application code: every reference to `$institution->jamb_code` must change to `$institution->externalIdentifiers()->where('authority_id', $jamb)->first()->value`
  - Filament resources: form schemas and table columns must be rebuilt
  - Import adapters: must change to write to `external_identifiers` table instead of setting columns on `institutions`
  - Search projections: Typesense document building must change
  - Tests: all feature tests referencing identifiers must be updated
  - Estimated effort: 2-3 days of focused work + regression risk
- Provenance **FUNDAMENTALLY favors** generic external identifiers from day one. Every identifier IS a source assertion: "JAMB says this institution's code is 12345." This is exactly the data model that the provenance system requires. Column-based identifiers cannot carry provenance metadata (who assigned=assigned this code, when was it verified, is it still valid).

**6. Hidden Second-Order Consequences**

- If identifiers are columns, adding a new authority's code requires a migration. Each migration is a deployment, a test cycle, and a risk. With 54 African countries each having 1-3 regulatory bodies, the column approach doesn't scale.
- If identifiers are in a generic table, the import/verification engine can **naturally create identifier records** as part of the import process. The import pipeline already has a source taxonomy — external identifiers should align with it.
- Column-based identifiers cannot represent **historical values**. When an institution changes its JAMB code (e.g., due to a merger), the old code is lost. A generic table can store both current and historical identifiers with validity periods.
- Column-based identifiers cannot represent **verification status per identifier**. A JAMB code might be verified (confirmed against the JAMB brochure) while an NUC code is unverified. With columns, verification is entity-level; with a generic table, verification can be per-identifier.
- The data acquisition pipeline's matching engine already handles identifiers as key-value pairs (JAMB code → "12345", NUC code → "67890"). Persisting them as columns requires flattening this structure; persisting them as a generic table preserves it.

**7. Evaluation Across Dimensions**

| Dimension | Assessment |
|-----------|------------|
| **Domain modeling** | `registrationIdentifier` in `establish()` suggests ONE identifier, but institutions have MANY (JAMB code, NUC code, institutional code, website URL). The generic table correctly models the one-to-many relationship. |
| **Relational integrity** | Generic table with FK to institution and FK to education_authority is normalized and enforces referential integrity. Columns are denormalized and cannot reference the authority. |
| **Laravel/Eloquent** | Both approaches work. Generic table uses polymorphic relationships (well-supported). Columns are simpler to read but harder to query across identifier types. |
| **PostgreSQL** | Generic table is normalized (3NF). Columns are denormalized (1NF with repeating group). Normalized is cleaner. |
| **P5 compliance** | Generic table is P5-compliant (identifiers are instances of a universal concept). Nigeria-specific columns violate P5. |
| **Data acquisition** | Generic table aligns naturally with the import pipeline (identifiers as key-value pairs from sources). |
| **Future expansion** | Generic table requires zero schema changes for new authorities. Columns require a migration per new authority. |
| **Provenance** | Generic table supports per-identifier provenance (source, verification status, validity period). Columns cannot. |

**8. Classification**

This is **FOUNDATIONAL**. It encodes whether the schema is Nigeria-specific or global-first. It directly affects P5 compliance. Getting this wrong means either building a Nigeria-specific schema that must be refactored, or building a global-first schema from day one that avoids the refactoring entirely.

**9. Confidence**

**HIGH** — the arguments for a generic table are overwhelming. The only argument for columns is "less code now," which is negated by the certain migration cost later.

**10. Evidence That Would Change Conclusion**

If the MVP literally only ever encounters ONE external identifier per institution, columns would be simpler. But the data acquisition doc already names JAMB AND NUC as P0 sources — that's two identifiers from two different authorities. A single-institution-identifier scenario is unrealistic for StudyNexus.

---

### 1.4 ND-5 — InformationSource Classification

**1. Architectural Question**

Is InformationSource correctly modeled as an aggregate root with `institution_id` FK? Can a source be institution-independent? Should the relationship between sources and institutions be modeled differently? The previous recommendation was InformationSource as aggregate root with nullable `institution_id`.

**2. Canonical Evidence**

- **03-domain.md**: InformationSource is aggregate root #5 with invariants INV-IS1 through INV-IS3:
  - INV-IS1: "Source cannot be simultaneously verified and unreliable"
  - INV-IS2: "A deprecated source cannot be verified"
  - INV-IS3: "Every registered source has a retrievable reference"
- **03-domain.md**: InformationSource has `register()`, `verify()`, `markUnreliable()`, `deprecate()` methods — these are lifecycle operations on the source itself, not operations that require an institution context.
- **05-implementation.md**: `information_sources` table has `institution_id FK` — **hard FK, NOT nullable**. This is a strong constraint that ties every source to exactly one institution.
- **06-data-acquisition.md**: Source taxonomy includes:
  - JAMB brochure (covers ALL institutions)
  - NUC accreditation list (covers MANY institutions)
  - Institution websites (covers ONE institution)
  - These are fundamentally different in their institutional scope.

**3. Contradictions**

- The implementation doc has `institution_id` as a **hard FK** on `information_sources`. This means every InformationSource record MUST be associated with exactly one institution.
- BUT a JAMB brochure is ONE source that covers ALL institutions — it doesn't belong to one institution. Under the hard FK model, you'd need to create 500+ InformationSource records (one per institution) for a single JAMB brochure, which is semantically wrong — it's one source, not 500.
- An NUC accreditation list is ONE source covering many institutions — same problem.
- The implementation doc's hard FK makes it **impossible to represent multi-institution sources correctly**. This is not a design trade-off; it's a **bug in the implementation doc**.
- The domain model's invariants (INV-IS1 through INV-IS3) are about source verification status, not about institutional association. The domain model doesn't require `institution_id` on InformationSource — the implementation doc added it independently.

**4. Assumptions in Previous Analysis**

- Assumed nullable `institution_id` is a sufficient fix — this was not critically examined. Nullable FK allows institution-independent sources, but it doesn't address the deeper problem: the relationship "this source provides information about this entity" is not a property of the source; it's a property of the provenance link.
- Did NOT consider whether `institution_id` should be removed entirely rather than made nullable.
- Did NOT consider how the data acquisition pipeline's import_batches already implicitly model the source-to-entity relationship.

**5. Attack on Previous Recommendation (nullable institution_id)**

- Nullable `institution_id` is a **HALF measure**. It allows institution-independent sources, but it still conflates two distinct concepts:
  - **"What IS this source?"** — a JAMB brochure, a URL, a person, a document. This is a property of InformationSource.
  - **"What entity does this source PROVIDE INFORMATION ABOUT?"** — this institution, this programme, this scholarship. This is NOT a property of InformationSource; it's a property of the provenance link between the source and the entity.
- These are DIFFERENT questions. `institution_id` answers the second question, but a single source can provide information about MANY entities. Putting `institution_id` on InformationSource says "this source is about this institution," which is wrong for JAMB/NUC sources.
- The correct model is: InformationSource represents "what the source IS" (no `institution_id` at all), and provenance/claims on entities reference the source. The JAMB brochure is one InformationSource. When it provides data about University of Lagos, that provenance link is on the Institution entity (via HasProvenance trait), not on InformationSource.
- With nullable `institution_id`, the FK is meaningless for the most important sources (JAMB, NUC) and meaningful only for institution-specific sources (institution websites). This creates an asymmetric relationship where the FK is sometimes populated and sometimes null, which is harder to reason about than a clean separation.

**6. Hidden Second-Order Consequences**

- If `institution_id` stays on InformationSource (even as nullable), then when JAMB provides data about 500 institutions, you have two bad options:
  - (a) Create 500 InformationSource records (one per institution) — semantically wrong (it's one source), creates 500 verification records to maintain, and violates the aggregate root's consistency boundary.
  - (b) Create one InformationSource with null `institution_id` — the FK is meaningless for the most common and most important sources.
- The data acquisition pipeline creates `import_batches` that reference a source, then imports data for many entities from that batch. A single import batch from JAMB produces data for 500 institutions. This implies sources are entity-agnostic — the batch-to-entity relationship is many-to-many, not one-to-one.
- If `institution_id` is removed, the `cut_off_marks.source_id` FK pattern becomes the model for how entities reference sources — through provenance, not through a FK on the source. This is consistent and clean.
- Removing `institution_id` simplifies the InformationSource aggregate root — it becomes a pure "source identity and verification" aggregate, with no entity-specific responsibilities. This is a better aggregate root boundary.

**7. Evaluation Across Dimensions**

| Dimension | Assessment |
|-----------|------------|
| **Domain modeling** | Removing `institution_id` from InformationSource is MORE correct — a source is a source, entity references are through provenance. The aggregate root's invariants are all about source verification, not about entity association. |
| **Relational integrity** | If `institution_id` is removed, all entity-to-source references go through provenance/claims — this is cleaner and more consistent. The `cut_off_marks.source_id` pattern becomes the norm. |
| **Laravel/Eloquent** | Both approaches work. Removing the FK simplifies the model (fewer relationships to define). |
| **Data acquisition** | Source-agnostic InformationSource aligns perfectly with the import pipeline (one source → one batch → many entities). |
| **Provenance** | This is the core of the provenance model — provenance on entities references sources, not the other way around. Removing `institution_id` makes provenance the authoritative source-to-entity link. |

**8. Classification**

**FOUNDATIONAL**. The current implementation doc has a bug (hard `institution_id` FK that can't represent JAMB brochures correctly). This is not a design preference; it's a modeling error that would cause data integrity problems in production.

**9. Confidence**

**HIGH** — the JAMB brochure example alone proves that `institution_id` on InformationSource is incorrect. No credible counter-argument has been presented.

**10. Evidence That Would Change Conclusion**

If every source in practice always concerns exactly one institution, `institution_id` would be appropriate. But this is false — JAMB and NUC sources concern all institutions, and this is known from day one. There is no scenario in StudyNexus's domain where all sources are institution-specific.

---

### 1.5 ND-4 — Provenance Model

**1. Architectural Question**

How should provenance (source attribution) be modeled on domain entities? Should provenance be entity-level only, field-level, or hybrid? The previous recommendation was Option E: `primary_source_id` FK + provenance JSONB.

**2. Canonical Evidence**

- **06-data-acquisition.md**: "Every entity in the canonical store carries provenance metadata" via HasProvenance trait with JSON including `source_type, source_url, acquired_at, last_verified_at, trust_level, verification_status, import_batch_id`.
- **03-domain.md**: `cut_off_marks` has `source_id UUID FK nullable, references information_sources` — this is a field-level provenance reference for a specific table.
- **02-decisions.md**: "The provenance model (source_id on entities) already supports import-attributed data."
- **01-business.md**: "Preserve Information Provenance" is capability #9. "Present Educational Knowledge" must include "provenance and references to authoritative sources."
- **06-data-acquisition.md**: "Provenance is immutable once recorded. If a field is updated from a different source, the old provenance is archived (not overwritten) and the new source is recorded." — This explicitly describes field-level provenance with history, but the implementation model (entity-level JSONB) doesn't support it.

**3. Contradictions**

- The data acquisition doc says provenance is per-entity (HasProvenance trait on the whole entity) — this implies all fields of an entity come from the same source or that the source is entity-level.
- BUT different fields come from different sources in practice: JAMB provides admission requirements, NUC provides accreditation status, the institution provides tuition fees, the institution provides application deadlines. A single `primary_source_id` or single provenance JSON cannot correctly represent this field-level source diversity.
- The canonical documents acknowledge field-level conflicts: "Two official sources disagree → Flag as conflict." But if provenance is entity-level, how do you know WHICH field the sources disagree on? Entity-level provenance can detect that "source A and source B disagree about this entity" but cannot specify that "source A and source B disagree about this entity's tuition fee."
- `cut_off_marks.source_id` is field-level provenance for a specific table — this pattern is correct for that table, but it's not generalized to the broader provenance model. The model is inconsistent: field-level for `cut_off_marks`, entity-level for everything else.

**4. Assumptions in Previous Analysis**

- Assumed `primary_source_id` FK is a useful "quick reference" — but it's misleading. For an entity where different fields come from different sources, there IS no "primary" source. Picking one is arbitrary and creates a false abstraction.
- Assumed JSONB provenance can handle field-level tracking by storing per-field sources in the JSON — this is technically possible but makes the JSONB complex, unqueryable, and a maintenance burden.
- Did NOT consider the interaction between the provenance model and the verification engine's conflict detection. The verification engine works at the record level (pending_imports), but once applied to the canonical store, field-level source attribution is lost if provenance is entity-level.

**5. Attack on Option E (primary_source_id FK + provenance JSONB)**

- `primary_source_id` creates a **MISLEADING abstraction** — it implies one source is "primary" for the entire entity. For an Institution entity: name comes from NUC, tuition from the institution, admission dates from JAMB. Which is "primary"? There is no principled answer.
- The provenance JSONB on the entity is entity-level, not field-level — it cannot correctly represent the real information trust problem. You could store per-field sources inside the JSONB (e.g., `{"fields": {"name": {"source_id": 1}, "tuition": {"source_id": 2}}}`), but this is building a relational model inside JSONB — it's unqueryable, has no referential integrity, and is hard to maintain.
- The data acquisition doc says "If a field is updated from a different source, the old provenance is archived (not overwritten) and the new source is recorded." WHERE is it archived? In the same JSONB? Then you're building version tracking inside JSONB, which is complex and unqueryable. In a separate table? Then what's the point of the JSONB?
- The Stage 3 transition (external contributions) **REQUIRES field-level provenance**. When an institution edits its own tuition fee, that field's provenance must change from "JAMB (official)" to "Institution (self-reported)" without affecting other fields' provenance. Entity-level provenance cannot support this.

**6. Hidden Second-Order Consequences**

- If provenance is entity-level only, the "trust signal" display can only say "this entity's data comes from [primary source]" — it CANNOT say "accreditation data is from NUC (verified ✓), tuition data is from the institution (unverified ○)." This is a fundamentally limited trust display.
- The cross-source consistency check in the verification engine works at the RECORD level (pending_imports), but once applied to the canonical store, field-level source attribution is lost. The system cannot answer "which fields were confirmed by both JAMB and NUC, and which fields differ?"
- When an admin manually corrects a field value (e.g., fixing a typo in an institution name), the provenance of that specific field should change to "admin override" — but entity-level provenance would change the provenance of the entire entity, which is incorrect for fields that still come from their original source.
- Analytics on source reliability require field-level provenance. "How often does JAMB's tuition data disagree with the institution's own data?" is a meaningful query that entity-level provenance cannot answer.

**7. Evaluation Across Dimensions**

| Dimension | Assessment |
|-----------|------------|
| **Domain modeling** | The real domain concept is "each factual assertion has a source" — this is field-level, not entity-level. Entities are composites of assertions from multiple sources. |
| **Relational integrity** | A normalized provenance table (entity_type, entity_id, field_name, source_id) would enforce FK integrity to information_sources. JSONB does not. |
| **Laravel/Eloquent** | JSONB is simpler for reads (no joins). Normalized table requires joins but is simpler for queries. |
| **PostgreSQL** | JSONB is fine for storage. Normalized table is better for queries and enforces referential integrity. |
| **Data acquisition** | Field-level provenance is essential for the verification engine's conflict detection ("JAMB and NUC disagree on this specific field"). |
| **Reconciliation** | Field-level provenance is essential for cross-source comparison and conflict resolution. |
| **Trust display** | Field-level provenance enables per-field trust signals ("accreditation: NUC verified ✓, tuition: institution-provided ○"). |
| **Future expansion** | Stage 3 (external contributions) requires field-level provenance. |

**8. Classification**

**FOUNDATIONAL**. The current provenance model is underspecified and cannot correctly represent the actual information trust problem. Entity-level provenance is insufficient for the domain's needs, and `primary_source_id` is a misleading abstraction.

**9. Confidence**

**MEDIUM** — the hybrid model (entity-level JSONB + field_provenance table for conflicts/multi-source fields) is directionally correct, but the exact design of the `field_provenance` table, its trigger conditions, retention policy, and interaction with the verification engine need more specification. The MEDIUM confidence reflects this underspecification, not a weakness in the direction.

**10. Evidence That Would Change Conclusion**

If in practice, entire entities always come from a single source (unlikely but possible for small datasets where each import batch is from one source and entities are never updated from multiple sources), entity-level provenance alone suffices. However, the domain analysis shows that institutions have multi-source data (JAMB for admission, NUC for accreditation, institution for tuition), so this scenario is unrealistic.

---

## PART 2 — SPECIAL SCRUTINY OF BD-1

This section provides exhaustive analysis of the Residual UUID Question across nine specific dimensions (A through I).

---

### 2.A — Is "Cross-Environment Seeding Stability" a Sufficient Reason for UUID on Disciplines?

**No.** Cross-environment seeding stability — the ability to have the same discipline ID in development, staging, and production — does NOT require UUID. There are at least four alternatives that achieve the same goal:

1. **Explicit seeded bigint IDs**: This is the SIMPLEST and MOST LARAVEL-IDIOMATIC approach. The seeder explicitly sets the `id` value:

```php
// database/seeders/DisciplineSeeder.php
public function run(): void
{
    $disciplines = [
        ['id' => 1, 'name' => 'Engineering', 'slug' => 'engineering'],
        ['id' => 2, 'name' => 'Medicine', 'slug' => 'medicine'],
        ['id' => 3, 'name' => 'Law', 'slug' => 'law'],
        // ...
    ];
    
    foreach ($disciplines as $discipline) {
        Discipline::updateOrCreate(
            ['slug' => $discipline['slug']],
            $discipline
        );
    }
}
```

This guarantees the same ID in every environment. It works with auto-increment (the auto-increment counter simply adjusts to be above the maximum explicitly-set ID). It's Laravel's standard pattern for reference data seeders.

2. **Deterministic UUIDs (UUIDv5)**: Generate UUIDs deterministically from a namespace + slug: `UUIDv5(namespace: 'studynexus.disciplines', name: 'engineering')`. This produces the same UUID in every environment. It works but adds complexity (UUIDv5 generation, namespace management) for no benefit over explicit seeded IDs.

3. **Stable slugs/codes**: Disciplines already have unique slugs. All FK references can use `slug` instead of `id` for discipline references. Upsert on slug is sufficient for identity. This is a natural key approach.

4. **Migration-based seeding**: Use database migrations (not seeders) to insert reference data. Migrations run in order and are idempotent with `updateOrCreate`. This guarantees the same data in every environment by design.

**The simplest approach — explicit seeded bigint IDs — is the correct one for StudyNexus.** It achieves cross-environment stability with zero complexity overhead. UUID for disciplines is an over-engineered solution to a simple problem.

---

### 2.B — Stable Seeded Reference IDs: Alternatives

Each alternative in detail:

**Explicit ID values in seeders** (RECOMMENDED):
- Pros: Simple, Laravel-standard, no custom logic, works with auto-increment, human-readable IDs in debugging
- Cons: Must coordinate ID values if multiple seeders reference the same discipline (trivial — just use constants or a shared config)
- Effort: Zero additional effort — this is the standard pattern

**Deterministic UUIDs (UUIDv5)**:
- Pros: Globally unique, deterministic across environments, no coordination needed
- Cons: Requires UUIDv5 library or implementation, IDs are not human-readable, adds 8 bytes per PK+FK vs bigint, requires UUID column type
- Effort: Low but unnecessary — adds complexity with no benefit over explicit IDs

**Stable slugs as natural keys**:
- Pros: Business-meaningful, no ID coordination needed, naturally stable
- Cons: Slugs as FK are strings (slower than bigint for joins), slug changes propagate to all referencing tables, not Laravel's default pattern
- Effort: Moderate — requires rethinking FK design for discipline references

**Migration-based seeding**:
- Pros: Version-controlled, ordered, idempotent, guaranteed to run in every environment
- Cons: Mixes schema changes with data changes (some teams prefer separation), migrations are not designed for data seeding
- Effort: Low — Laravel supports data in migrations natively

**Conclusion**: Explicit seeded bigint IDs are the clear winner. They solve the problem with the least complexity, the most Laravel-idiomatic approach, and the best developer experience.

---

### 2.C — FK Type Heterogeneity: Concrete Harm

If disciplines use UUID PK and all other entities use bigint PK, the following concrete harms occur:

**Eloquent relationship definitions:**
```php
// Normal (homogeneous types):
public function institution(): BelongsTo
{
    return $this->belongsTo(Institution::class);
    // Laravel infers institution_id as bigint — correct
}

// Abnormal (heterogeneous types):
public function discipline(): BelongsTo
{
    return $this->belongsTo(Discipline::class, 'discipline_id');
    // Laravel infers discipline_id as UUID — requires awareness
    // Some Eloquent methods may not work as expected with mixed types
}
```

**Migration definitions:**
```php
// Every migration that references disciplines must remember to use uuid:
$table->foreignUuid('discipline_id')->nullable()->constrained('disciplines');

// While every other FK uses the standard:
$table->foreignId('institution_id')->constrained('institutions');
```

**Query joins:**
```sql
-- Mixed types in a single query:
SELECT p.*, d.name as discipline_name
FROM programmes p
JOIN disciplines d ON d.id = p.discipline_id  -- UUID join
JOIN institutions i ON i.id = p.institution_id  -- bigint join
-- The developer must remember which FK is which type
```

**Developer cognitive load:**
- Every time a developer creates a new table that references disciplines, they must use `foreignUuid` instead of `foreignId`.
- Every time a developer defines an Eloquent relationship to Discipline, they must override the default key type.
- Every time a developer writes a raw SQL query involving disciplines, they must remember to use UUID literals.
- This is a PERMANENT cognitive tax that affects every future developer, not a one-time setup cost.

---

### 2.D — Is UUID Justified for cut_off_marks?

**No.** There is NO legitimate architectural reason for `cut_off_marks` to use UUID PK or UUID FKs.

The current 05-implementation.md specifies:
- `programme_instance_id (BIGINT FK, references programme_instances, ON DELETE CASCADE)`
- `admission_cycle_id (UUID FK, references admission_cycles, ON DELETE CASCADE)`
- `source_id (UUID FK nullable, references information_sources, ON DELETE SET NULL)`

But if `programmes.id` is `bigint` (as it should be under uniform bigint), then `programme_id (UUID FK)` is a **TYPE MISMATCH**. PostgreSQL will reject this FK definition because the FK column type doesn't match the referenced PK type.

This appears to be an **error in the implementation doc** that was not caught during reconciliation. The UUID FK types in `cut_off_marks` were likely copied from a template or assumed without verifying the PK types of the referenced tables.

**Resolution**: All FK types in `cut_off_marks` should be changed to `bigint` to match the PK types of the referenced tables. This is a bug fix, not a design decision.

---

### 2.E — What Do the Canonical Documents Actually Say About PK Types?

**Nothing.** The canonical documents NEVER explicitly state what PK type aggregate roots should use.

- **01-business.md**: Defines business capabilities and MVP scope. No PK type specification.
- **02-decisions.md**: Records architectural decisions. No ADR on PK types.
- **03-domain.md**: Defines entities by their invariants, operations, and consistency boundaries. Defines VOs by their value semantics. No PK type specification.
- **04-architecture.md**: Defines architectural principles and constraints. No PK type specification.
- **05-implementation.md**: Defines table schemas. Uses UUID in some places (disciplines, cut_off_marks FKs) and bigint in others (OrganizationMember). This is the ONLY place PK types appear, and it's internally inconsistent.
- **06-data-acquisition.md**: Defines the import pipeline. Uses UUID for staging tables (import_batches, pending_imports). No PK type specification for domain entities.

**The PK type decision is entirely unconstrained by the canonical documents.** The implementation doc's inconsistency is the only "evidence," and it's contradictory evidence. The decision must be made on architectural merit alone, and on that basis, uniform bigint is clearly superior for StudyNexus's use case.

---

### 2.F — PostgreSQL FK/PK Type Constraint: Accuracy and Implications

The statement "PostgreSQL requires FK and referenced PK to be the same type" is **ACCURATE**. This is not a soft constraint or a best practice — it's a hard PostgreSQL limitation.

PostgreSQL documentation states:
> "The referenced columns must be columns of non-deferrable unique or primary key constraints in the referenced table. [...] The data type of the referencing column must match the data type of the referenced column."

Implications for StudyNexus:
- You CANNOT have `programme_id uuid REFERENCES programmes(id)` if `programmes.id` is `bigint`. PostgreSQL will reject the FK definition with a type mismatch error.
- You CANNOT have `discipline_id uuid REFERENCES disciplines(id)` if you later decide to change `disciplines.id` from UUID to bigint (or vice versa) without also changing all referencing FK columns.
- This means the PK type decision is **sticky** — once chosen, changing it requires changing every FK that references the changed table. This is a strong argument for choosing the right type from the start and keeping it homogeneous.

The current 05-implementation.md appears to **violate this constraint** — it defines UUID FKs in `cut_off_marks` without specifying that the referenced tables have UUID PKs. This is a bug that would cause a migration failure.

---

### 2.G — Storage, Index, and Performance Implications

**bigint (int8):**
- Storage: 8 bytes per value
- Sequential: auto-increment produces ordered values → B-tree inserts append to the rightmost page → minimal page splits
- Index size: smaller (8 bytes per key) → more keys per page → better cache utilization
- Join performance: faster (smaller keys, better cache locality)
- Range queries: efficient (sequential values allow efficient B-tree range scans)
- Comparison operations: faster (integer comparison is CPU-native)

**UUIDv4:**
- Storage: 16 bytes per value
- Random: UUIDv4 produces random values → B-tree inserts hit random pages → frequent page splits → index fragmentation
- Index size: larger (16 bytes per key) → fewer keys per page → worse cache utilization
- Join performance: slower (larger keys, worse cache locality)
- Range queries: meaningless (random values have no ordering)
- Comparison operations: slower (byte-by-byte comparison)

**For StudyNexus scale:**
- Thousands of institutions, tens of thousands of programmes, hundreds of thousands of cut-off marks
- The performance difference between bigint and UUID is **measurable** but unlikely to be the bottleneck in an application where read-heavy paths are served by Typesense and Redis
- The storage difference is more significant: UUID doubles the size of every PK and FK column. For a schema with 56 tables and many FK relationships, this adds up to meaningful storage overhead
- Index fragmentation from UUIDv4 random inserts is the most concerning performance issue — it degrades over time as the table grows and requires index maintenance (REINDEX)

**Net assessment**: For StudyNexus's single-writer PostgreSQL deployment with read-heavy paths offloaded to Typesense/Redis, bigint is clearly better. The performance advantages are modest but consistent, and the storage savings compound over time.

---

### 2.H — ULID/UUIDv7 Analysis

**UUIDv7:**
- Time-ordered: the first 48 bits are a Unix timestamp, the remaining 74 bits are random
- Reduces index fragmentation vs UUIDv4 (time-ordered inserts go to the rightmost page, similar to auto-increment bigint)
- 16 bytes (same as UUIDv4)
- Standardized in RFC 9562 (2024)
- Supported by Laravel via `Illuminate\Support\Str::orderedUuid()`

**ULID:**
- Similar to UUIDv7: time-ordered, 128 bits
- 26-character base32 string representation (vs UUID's 36-character hex representation)
- Compatible with UUID (can be converted to/from UUID)
- Not yet standardized
- Not natively supported in Laravel (requires a package)

**Analysis:**
- UUIDv7 is a significant improvement over UUIDv4 for PostgreSQL performance (time-ordered inserts reduce fragmentation)
- ULID offers similar benefits with a more compact string representation
- **Both are still 16 bytes vs bigint's 8 bytes** — the storage overhead is the same as UUIDv4
- Neither changes the fundamental analysis: StudyNexus is single-writer PostgreSQL and doesn't need globally unique IDs
- If UUID were required for some reason (e.g., future distributed writes), UUIDv7 would be the right choice — but that reason doesn't exist for StudyNexus

**Conclusion**: UUIDv7/ULID are better than UUIDv4 but still worse than bigint for StudyNexus's use case. They solve the index fragmentation problem but don't solve the storage overhead, cognitive load, or FK type heterogeneity problems.

---

### 2.I — Scale Considerations: Millions of Programmes and Records

**Can bigint handle the scale?**
- bigint (int8) can represent values from -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807
- That's 9.2 × 10^18 possible values — more than sufficient for any conceivable StudyNexus scale
- Even with 100 million programmes (far beyond any realistic projection), bigint would use less than 0.001% of its value space

**Does distributed data acquisition require UUID PKs?**
- No. The import pipeline uses business identifiers (JAMB code, NUC code, name, slug) for matching, not PKs
- Import jobs create records through Actions (domain actions that apply business rules), not through distributed direct writes
- Each import job runs on a single application instance, writing to a single PostgreSQL primary
- There is no scenario where two import jobs simultaneously create the same record and need non-colliding PKs — the verification engine detects duplicates before canonical store insertion

**What about concurrent import jobs?**
- Two import jobs from different sources (JAMB + NUC) may run concurrently, but they operate on different import_batches with different pending_imports records
- The matching engine resolves duplicates during verification, before canonical store insertion
- Concurrent writes to the same PostgreSQL primary are handled by PostgreSQL's MVCC — no PK collision risk with auto-increment bigint

**Conclusion**: Even at massive scale, bigint is still the correct choice for StudyNexus. The scale argument for UUID (globally unique IDs for distributed systems) doesn't apply to StudyNexus's architecture.

---

### 2.REVISED — Revised Recommendation for BD-1

**Uniform bigint for ALL domain entity PKs, including disciplines.**

- Use explicit seeded IDs for reference data (disciplines, education authority types, etc.)
- Fix the type mismatch in `cut_off_marks` — change UUID FKs to bigint FKs
- Import/staging tables (`import_batches`, `pending_imports`) can use UUID since they're not domain entities and may receive concurrent writes from import jobs
- OrganizationMember and other Laravel-package tables retain their native bigint PKs (no change)

This recommendation:
- Eliminates FK type heterogeneity
- Aligns with Laravel's defaults
- Reduces storage overhead
- Improves join and index performance
- Reduces developer cognitive load
- Fixes the type mismatch bug in the implementation doc
- Achieves cross-environment seeding stability through explicit seeded IDs

---

## PART 3 — SPECIAL SCRUTINY OF BD-3

This section provides exhaustive analysis of the AdmissionCycle Phase Storage decision.

---

### 3.1 — The Domain Model ≠ Persistence Model Distinction

This is the critical insight that the previous analysis missed. **"Domain model as Value Object" does NOT automatically mean "must be persisted as JSON."**

The domain model and persistence model are SEPARATE concerns. This is codified in P4 (Separate Domain from Application from Presentation) and is a foundational principle of Domain-Driven Design.

PhaseSequence is correctly a Value Object in the domain model because:
- It's part of the AdmissionCycle's consistency boundary — phases cannot be modified independently of their parent cycle
- It has no independent lifecycle — phases don't exist without a cycle
- It has no identity beyond its value — two PhaseSequences with the same phases in the same order are equal
- Its invariants (ordered phases, non-overlapping time windows) are enforced by the AdmissionCycle aggregate root

But the PERSISTENCE of that VO is an independent decision with several valid options:

1. **JSONB column** — stores the full phase sequence as a JSON document. Simple, atomic writes, no JOIN needed to load the cycle with its phases. Domain operations (advancePhase, addPhase) work with the full VO.

2. **Normalized child table** — stores each phase as a row in `admission_cycle_phases`. Standard relational approach, queryable, Filament-friendly. Requires JOIN to load cycle with phases, but this is trivial.

3. **JSONB + generated/indexed columns** — stores JSONB for domain operations, extracts key fields (current_phase, phase_count) as regular columns for queries. Best of both worlds.

The key question is: **does StudyNexus need to QUERY phases independently of their parent cycle?**

---

### 3.2 — Query Analysis: What Does the System Actually Need?

**MVP queries involving phases:**

| Query | Frequency | With JSONB Only | With current_phase Column |
|-------|-----------|-----------------|--------------------------|
| "What phase is this cycle in?" | High (every cycle detail view) | Load JSONB, compute current phase from timestamps | `SELECT current_phase FROM admission_cycles WHERE id = ?` — trivial |
| "Advance to next phase" | Medium (admin action) | Domain method reads JSONB, advances, writes JSONB | Domain method reads JSONB, advances, writes JSONB + updates current_phase |
| "Show cycle timeline" | Medium (cycle detail view) | Read PhaseSequence from JSONB — same for both | Same — JSONB is still the source of truth for the full timeline |
| "All cycles in Examination phase" (dashboard filter) | Low-Medium | `WHERE phases @> '[{"name":"examination","status":"current"}]'` — JSONB containment query | `WHERE current_phase = 'examination'` — simple equality |
| "Phase distribution across all institutions" | Low (analytics) | JSONB aggregation — complex | `SELECT current_phase, COUNT(*) GROUP BY current_phase` — trivial |

**Post-MVP queries:**

| Query | Frequency | With JSONB Only | With current_phase Column |
|-------|-----------|-----------------|--------------------------|
| "Average duration of Registration phase" | Low (analytics) | Extract starts_at/ends_at from JSONB per phase — complex | Still requires JSONB for duration calculation, but current_phase helps filter |
| "Phase transitions in last 30 days" | Low (event log) | Read from event store (AdmissionCyclePhaseAdvanced events) — same for both | Same — events are the source of truth for transition history |
| "Notify applicants when Examination phase begins" | Medium (notification) | Need to detect phase change — either event-driven or polling | Same — notifications are event-driven regardless of storage |

**Conclusion**: The most common and most important query — "what phase is this cycle in?" — is dramatically simpler with a `current_phase` column. The JSONB-only approach requires loading and parsing the PhaseSequence to compute the current phase from timestamps, which is unnecessary work for every cycle detail view and every dashboard filter.

---

### 3.3 — The current_phase Gap in the Canonical Documents

The implementation doc's `admission_cycles` table has **no `current_phase` column**:

```
admission_cycles: id, institution_id FK, name, admission_pathway, academic_year, opens_at, closes_at, results_at, status
```

But the domain model defines `advancePhase()` as a method on AdmissionCycle. This method needs to:
1. Determine the current phase
2. Advance to the next phase
3. Update the cycle's state

Without a `current_phase` column, how does the system know which phase a cycle is currently in? Options:
- Compute from timestamps: the current phase is the one whose `starts_at <= now() <= ends_at`. But this assumes phases are time-bounded (some phases may not have explicit end dates), and it doesn't handle the gap between phases (what if now() falls between two phases?).
- Store in JSONB: the PhaseSequence JSONB could include a `current_index` or `current_phase` field. But this means the "current phase" is embedded in the JSONB and not independently queryable.
- Store as a separate column: `current_phase VARCHAR(50)` on `admission_cycles`. This is the cleanest approach — it's a denormalized projection that's maintained by the `advancePhase()` domain method.

**This gap must be fixed regardless of the PhaseSequence storage decision.** The system cannot function without knowing the current phase of each cycle.

---

### 3.4 — Filament Admin Panel Considerations

**JSONB PhaseSequence editing:**
- Requires a custom Filament form component that understands the PhaseSequence structure
- The component must render a list of phases with name, starts_at, ends_at fields
- It must support adding, removing, and reordering phases
- Custom components add development and maintenance cost
- Estimated effort: 1-2 days for the custom component + ongoing maintenance

**Normalized child table editing:**
- Uses Filament's built-in `RelationManager` or `Repeatable` field
- Standard Filament patterns for editing related records
- No custom component development needed
- Estimated effort: 0.5 days using built-in components

**However**, if we choose JSONB + `current_phase` column:
- The PhaseSequence JSONB is edited with a custom component (or a `Repeatable` field that casts to JSON)
- The `current_phase` column is read-only in Filament (maintained by the domain method)
- This is a one-time development cost, not an ongoing burden
- The custom component is specific to PhaseSequence and wouldn't need frequent changes

**Conclusion**: The Filament development cost is real but manageable. It's not a strong argument for or against either approach.

---

### 3.5 — Notification and Event Dispatch

When `advancePhase()` is called:
1. The AdmissionCycle aggregate emits an `AdmissionCyclePhaseAdvanced` event
2. The event carries: cycle_id, old_phase, new_phase, advanced_at
3. Listeners dispatch notifications (email, SMS, push) to relevant parties
4. Listeners update Typesense documents (denormalize current_phase)

This event-driven notification is the same regardless of whether phases are stored as JSONB or as a child table. The event is a domain event, not a persistence event. The storage strategy doesn't affect notification dispatch.

However, with a `current_phase` column:
- An Eloquent model observer can detect the phase change automatically (comparing the old and new `current_phase` values)
- This provides a simple, reliable trigger for notifications
- With JSONB-only storage, detecting the phase change requires comparing old and new JSONB values, which is more complex

---

### 3.REVISED — Revised Recommendation for BD-3

**JSONB PhaseSequence Value Object + `current_phase` string column on `admission_cycles`.**

The JSONB stores the full phase sequence for domain operations (advancePhase, timeline display, phase validation). The `current_phase` column is a denormalized projection maintained by the `advancePhase()` domain method. This enables:

1. **Efficient filtering**: `WHERE current_phase = 'examination'` instead of JSONB containment queries
2. **Efficient grouping**: `SELECT current_phase, COUNT(*) GROUP BY current_phase` for dashboards
3. **Simple notification triggers**: Eloquent model observer detects `current_phase` changes
4. **Domain VO integrity**: PhaseSequence is still a VO in the domain model; `current_phase` is just a cached projection
5. **Typesense denormalization**: `current_phase` is easily included as a top-level field in the Typesense document

The `advancePhase()` method atomically updates both the PhaseSequence JSONB and the `current_phase` column, maintaining consistency within the AdmissionCycle aggregate's consistency boundary.

---

## PART 4 — SPECIAL SCRUTINY OF BD-5

This section provides exhaustive analysis of the External Identifier Model decision.

---

### 4.A — The "Wait Until Third Source" Trigger Is Arbitrary

The previous recommendation said to use source-specific columns (`jamb_code`, `nuc_code`) for MVP and migrate to a generic table when a "third source" requires a new identifier column. This trigger is arbitrary for several reasons:

1. **JAMB and NUC are already TWO sources.** The "three instances" rule from P11 (No Premature Abstraction) is about abstracting shared BEHAVIOR, not about deferring a clearly-better schema design. Two instances with a third immediately behind is enough to justify the generic table.

2. **WAEC, NBTE, and NCCE are P0/P1 sources right behind JAMB and NUC.** The trigger would fire almost immediately after MVP launch. There's no world where StudyNexus MVP launches with only JAMB and NUC and no other regulatory bodies need to be represented.

3. **The trigger is a migration trigger, not a design trigger.** The question isn't "when should we abstract?" but "when should we pay the migration cost?" If the generic table is the correct design (and it is, per P5), then building it from day one avoids the migration cost entirely.

4. **P11 (No Premature Abstraction) does NOT apply here.** P11 says "do not abstract until three concrete instances with verified shared behaviour exist." But external identifiers from JAMB and NUC already share verified behavior: they're both authoritative codes assigned by an education authority to identify an institution. This IS shared behavior. The generic table models this shared behavior.

---

### 4.B — Migration Cost: Columns → Generic Table

The migration from source-specific columns to a generic `external_identifiers` table is NOT cheap. Here's the full cost analysis:

**Data migration:**
- Create `external_identifiers` table
- For each institution with a `jamb_code`, insert a row: `(institution, institution_id, jamb_authority_id, 'registration_code', jamb_code_value, ...)`
- For each institution with a `nuc_code`, insert a row: `(institution, institution_id, nuc_authority_id, 'accreditation_code', nuc_code_value, ...)`
- Drop `jamb_code` and `nuc_code` columns from `institutions`
- Update all FK references and indexes

**Application code changes:**
- Every reference to `$institution->jamb_code` must change to `$institution->externalIdentifiers()->where('authority_id', $jambAuthorityId)->first()?->value` (or a accessor method)
- Every reference to `$institution->nuc_code` must change similarly
- Institution model's `$fillable` and `$casts` arrays must be updated
- Any validation rules referencing `jamb_code`/`nuc_code` must be rewritten

**Filament resource changes:**
- Form schema: `TextInput::make('jamb_code')` becomes a repeater or relation manager for external identifiers
- Table columns: `TextColumn::make('jamb_code')` becomes a relationship column
- Any filters or actions referencing jamb_code/nuc_code must be rewritten

**Import adapter changes:**
- JAMB import adapter: currently sets `$institution->jamb_code = $value` — must change to create an `external_identifier` record
- NUC import adapter: same change
- Matching engine: currently matches on `$institution->jamb_code` — must change to match on `external_identifiers` table

**Search projection changes:**
- Typesense document building: currently includes `jamb_code` and `nuc_code` as fields — must change to include identifiers from the `external_identifiers` relationship
- Typesense schema: field names change

**Test updates:**
- All feature tests referencing `$institution->jamb_code` must be rewritten
- All factory definitions using `jamb_code`/`nuc_code` must be rewritten
- All integration tests for the import pipeline must be rewritten

**Estimated effort: 2-3 days of focused work + regression risk.**

This is not a "routine migration." It's a significant refactoring that touches every layer of the application. Building the generic table from day one avoids all of this cost.

---

### 4.C — Provenance Fundamentally Favors Generic External Identifiers

Every external identifier IS a source assertion. "JAMB says this institution's code is 12345" is not just a string on the `institutions` table — it's a factual claim from a specific source, with provenance metadata:

- **Who asserted this?** JAMB (the authority)
- **When was it asserted?** The date the JAMB brochure was published
- **When was it acquired?** The date the import was run
- **Is it verified?** Confirmed against the JAMB brochure (yes/no)
- **Is it current?** Some codes are retired when institutions are merged or renamed
- **What type of identifier is it?** Registration code, examination code, accreditation code, institutional code

Column-based identifiers (`jamb_code`, `nuc_code`) cannot carry this provenance metadata. They're just strings. The provenance system cannot answer "who assigned this JAMB code?" or "is this NUC code still valid?" because the information isn't stored.

The generic `external_identifiers` table naturally carries provenance:
- `authority_id` → who assigned the code
- `source_id` → which source document provided the code
- `acquired_at` → when it was imported
- `valid_from` / `valid_to` → validity period
- `is_primary` → whether this is the institution's primary identifier for this authority

This alignment between the identifier model and the provenance model is not coincidental — it's because identifiers ARE provenance assertions. Building them as columns breaks this alignment.

---

### 4.D — External Identifiers as First-Class Source Assertions

An external identifier is not merely a string — it's a first-class domain concept with its own attributes:

| Attribute | Description | Example |
|-----------|-------------|---------|
| **Authority** | Who assigned this identifier | JAMB, NUC, KUCCPS, GTEC |
| **Identifier type** | What kind of identifier | registration_code, accreditation_code, examination_code, institutional_code |
| **Value** | The actual code | "12345", "UNILAG/2024" |
| **Is primary** | Whether this is the primary identifier for this entity+authority | true (JAMB code is primary for JAMB) |
| **Valid from** | When the identifier became effective | 2020-01-01 |
| **Valid to** | When the identifier was retired | null (still current) or 2023-12-31 (retired) |
| **Source** | Which source document provided this identifier | JAMB 2024 brochure |
| **Acquired at** | When the identifier was imported | 2024-06-15 |
| **Verification status** | Whether the identifier has been confirmed | verified, unverified, disputed |

Modeling identifiers as first-class objects supports:
- **Historical values**: When University of Lagos merges with Lagos State University, both institutions' JAMB codes are retired and a new code is assigned. The generic table stores all three: old UNILAG code (retired), old LASU code (retired), new merged code (current).
- **Validity periods**: Some codes are time-bounded. A JAMB code assigned in 2020 may differ from the code assigned in 2024 if the institution was reclassified.
- **Source attribution**: "This JAMB code came from the 2024 JAMB brochure (verified). This NUC code came from the NUC website (unverified)."
- **Verification state**: "This JAMB code is confirmed (verified against brochure). This NUC code is unconfirmed (entered by an admin, not yet verified against the source)."
- **Uniqueness constraints**: Within a (entity, authority, identifier_type) tuple, only one identifier should be primary at a time. This is enforced by a unique constraint.

---

### 4.E — Polymorphism: Well-Supported in Laravel

The generic `external_identifiers` table uses `identifiable_type` / `identifiable_id` morphable columns. This is well-supported in Laravel:

```php
// Institution model:
public function externalIdentifiers(): MorphMany
{
    return $this->morphMany(ExternalIdentifier::class, 'identifiable');
}

// Programme model:
public function externalIdentifiers(): MorphMany
{
    return $this->morphMany(ExternalIdentifier::class, 'identifiable');
}

// Usage:
$jambCode = $institution->externalIdentifiers()
    ->where('authority_id', $jambAuthority->id)
    ->where('identifier_type', 'registration_code')
    ->first()?->value;
```

This is standard Laravel polymorphic relationship syntax. No special packages, no custom logic, no workarounds. The concern about polymorphism being "complex" is unfounded — it's a core Laravel feature used extensively in the framework (tags, comments, notifications, activities all use morphable relationships).

---

### 4.F — Non-Polymorphic Alternative: Worse, Not Better

A non-polymorphic design would use separate tables per entity type:
- `institution_identifiers`
- `programme_identifiers`
- `scholarship_identifiers`

This is MORE complex, not less:
- More tables to manage (one per entity type)
- More migrations to write
- More models to define
- More Filament resources to build
- Duplicate schema, validation, and business logic across tables
- Cannot query across entity types ("all identifiers from JAMB" requires UNION across N tables)

The polymorphic design is simpler: one table, one model, one set of validation rules, one Filament relation manager. The polymorphic type column (`identifiable_type`) provides entity-type discrimination at zero cost.

---

### 4.G — "Option A Is Sufficient for MVP" Is Misleading

The claim that source-specific columns are "sufficient for MVP" is misleading. It's not sufficient — it:
- **Violates P5** (Global-First, Nigeria-First-Dataset) by encoding Nigerian regulatory body names into the schema
- **Creates a known migration** that must be performed when (not if) a third authority's code is needed
- **Doesn't support the provenance model correctly** — column-based identifiers cannot carry provenance metadata
- **Doesn't support identifier history** — retired codes, validity periods, verification status
- **Doesn't support the data acquisition pipeline** — the import pipeline produces identifier records as key-value pairs; flattening them into columns loses information

It's merely EASIER to implement, not sufficient. Ease of implementation is not a sufficient reason to choose a design that violates architectural principles and creates known technical debt.

---

### 4.REVISED — Revised Recommendation for BD-5

**Generic `external_identifiers` table from day one.**

```
external_identifiers
  id                  bigint PK (auto-increment)
  identifiable_type   string (morph type: 'institution', 'programme', 'scholarship', etc.)
  identifiable_id     bigint (morph ID)
  authority_id        bigint FK nullable → education_authorities
  identifier_type     string (enum: 'registration_code', 'examination_code',
                        'accreditation_code', 'institutional_code', 'website_url')
  value               string
  is_primary          boolean default false
  valid_from          date nullable
  valid_to            date nullable
  source_id           bigint FK nullable → information_sources
  acquired_at         timestamp
  created_at          timestamp
  updated_at          timestamp

  Unique constraint: (identifiable_type, identifiable_id, authority_id, identifier_type)
    — one identifier per entity per authority per type
  Index: morphs index on (identifiable_type, identifiable_id)
  Index: value (for lookup — "find institution with JAMB code 12345")
  Index: authority_id
  Index: (identifier_type, value) — for cross-entity identifier lookup
```

This design:
- Is P5-compliant (no Nigeria-specific columns)
- Supports provenance per identifier (authority_id, source_id, acquired_at)
- Supports identifier history (valid_from, valid_to)
- Supports verification state (via source_id → information_sources.verification_status)
- Supports the import pipeline (natural key-value mapping)
- Requires zero schema changes for new authorities
- Uses standard Laravel polymorphic relationships

---

## PART 5 — SPECIAL SCRUTINY OF ND-5

This section provides exhaustive analysis of the InformationSource Classification decision.

---

### 5.1 — Can One InformationSource Type Represent All Source Types?

Let's enumerate every source type StudyNexus will encounter and verify that each can be represented as an InformationSource WITHOUT an `institution_id`:

| Source Type | Example | Covers | institution_id needed? |
|-------------|---------|--------|------------------------|
| Official registry | JAMB brochure | ALL institutions | NO |
| Official registry | JAMB website (jamb.gov.ng) | ALL institutions | NO |
| Accreditation body | NUC accreditation list | MANY institutions | NO |
| Accreditation body | NBTE accreditation list | MANY institutions | NO |
| Institution website | unilag.edu.ng | ONE institution | Could be useful, but provenance handles this |
| Institution admissions page | unilag.edu.ng/admissions | ONE institution | Could be useful, but provenance handles this |
| Document (PDF) | JAMB brochure PDF | ALL institutions | NO |
| API (data partner) | WAEC API endpoint | MANY institutions | NO |
| Government open data | Data portal CSV | MANY institutions | NO |
| Community contribution | User-submitted correction | ONE entity | NO (the entity's provenance tracks this) |
| News article | News about admission dates | ONE or few institutions | NO |
| Archived document | Archived JAMB brochure | ALL institutions | NO |
| Scholarship provider | Scholarship website | MANY institutions | NO |

**Every source type can be represented WITHOUT `institution_id`.** For institution-specific sources (institution websites), the relationship "this source provides information about this institution" is captured by provenance on the institution entity, not by a FK on InformationSource.

---

### 5.2 — The institution_id on InformationSource Conflates Two Concepts

The current implementation doc puts `institution_id` on `information_sources`, conflating two distinct concepts:

**Concept 1: "What IS this source?"**
- A JAMB brochure is an official registry document published by JAMB
- It has a URL, a publication date, a verification status
- It IS a source, regardless of what it provides information about

**Concept 2: "What does this source PROVIDE INFORMATION ABOUT?"**
- A JAMB brochure provides information about ALL institutions
- An institution website provides information about ONE institution
- An NUC accreditation list provides information about MANY institutions

These are different questions with different answers. `institution_id` on InformationSource tries to answer Concept 2, but it's the wrong place for that answer because:
- For JAMB/NUC sources, the answer is "all institutions" — `institution_id` can't represent this
- For institution websites, the answer is "this institution" — but provenance on the Institution entity already captures this ("this institution's data came from its website")
- The answer to Concept 2 is MANY-TO-MANY (one source → many entities, one entity → many sources), not ONE-TO-MANY

**The correct model separates these concepts:**
- InformationSource answers Concept 1 (what IS the source?)
- Provenance on entities answers Concept 2 (what does this source provide information about?)

---

### 5.3 — The Nullable institution_id Half Measure

The previous recommendation (nullable `institution_id`) is a half measure. It allows institution-independent sources (JAMB, NUC) by setting `institution_id` to null, but it doesn't fix the conflation:

- For JAMB/NUC sources: `institution_id` is always null → the FK is meaningless for the most common sources
- For institution websites: `institution_id` is set → the FK provides information that provenance already captures
- The nullable FK creates an asymmetric relationship: sometimes populated, sometimes null, with different semantics in each case

This is worse than removing `institution_id` entirely:
- With nullable `institution_id`, developers must check for null and handle two cases
- Without `institution_id`, the model is clean and consistent: provenance is ALWAYS the authoritative source-to-entity link

---

### 5.4 — The Correct InformationSource Model

```
information_sources
  id                    bigint PK (auto-increment)
  name                  string (e.g., "JAMB 2024 Unified Tertiary Matriculation
                          Brochure", "NUC Accreditation List 2024",
                          "University of Lagos Official Website")
  type                  enum: official_registry, institution_website,
                          accreditation_body, government_open_data,
                          scholarship_provider, community_contribution,
                          data_partner, document, news, archived
  url                   string nullable (e.g., "https://jamb.gov.ng/brochure.pdf")
  contact_name          string nullable (for community contributions)
  contact_email         string nullable (for community contributions)
  verification_status   enum: unverified, verified, unreliable, deprecated
  information_category  enum: official, unofficial, historical, scraped
  verified_at           timestamp nullable
  verified_by           bigint FK nullable → users
  notes                 text nullable
  metadata              jsonb nullable (source-specific metadata, e.g.,
                          {"publication_year": 2024, "edition": "1st"})
  created_at            timestamp
  updated_at            timestamp

  Index: type
  Index: verification_status
  Index: information_category
  Index: (type, verification_status) — for finding unverified official sources
```

**No `institution_id`.** Entity-to-source relationships are through:
1. **HasProvenance trait** on entities: stores the source_id of the most recent import that updated the entity
2. **Import batches**: each import_batch references a source, and each imported entity carries the import_batch_id in its provenance
3. **Field-level provenance** (when needed): the `field_provenance` table references both entity and source

---

### 5.5 — Impact on the Data Acquisition Pipeline

The data acquisition pipeline already implicitly models the source-to-entity relationship correctly:

```
InformationSource (JAMB brochure)
    ↓ referenced by
ImportBatch (batch 1: "JAMB 2024 import, June 15")
    ↓ produces
PendingImport × 500 (one per institution)
    ↓ verified and applied
Institution × 500 (each with provenance.source_id → JAMB brochure)
```

In this pipeline, `institution_id` on InformationSource is redundant — the import batch and provenance already capture the relationship. The JAMB brochure is ONE source; the import batch is ONE batch; the 500 institutions each have provenance pointing back to the source through the import batch.

If `institution_id` were on InformationSource, you'd need to create 500 InformationSource records (one per institution) for a single JAMB brochure, which is semantically wrong and operationally wasteful.

---

### 5.REVISED — Revised Recommendation for ND-5

**InformationSource remains an aggregate root, but with NO `institution_id` column.**

Entity-to-source references are through provenance on entities (HasProvenance trait) and through the import_batches/pending_imports staging tables. This correctly separates "what is the source?" from "what does the source provide information about?"

The InformationSource aggregate root's invariants (INV-IS1, INV-IS2, INV-IS3) are all about source verification lifecycle — they don't require an institutional association. The aggregate root's methods (`register()`, `verify()`, `markUnreliable()`, `deprecate()`) operate on the source itself, not on any entity association.

---

## PART 6 — SPECIAL SCRUTINY OF ND-4

This section provides exhaustive analysis of the Provenance Model decision.

---

### 6.1 — The Multi-Source Entity Problem

Consider Programme X at University of Lagos:

| Field | Source | Trust Level |
|-------|--------|-------------|
| Name | NUC accreditation list | Official, verified |
| Admission requirements | JAMB brochure | Official, verified |
| Accreditation status | NUC accreditation list | Official, verified |
| Tuition fee | Institution website | Self-reported, unverified |
| Application deadline | Institution website | Self-reported, unverified |
| Cut-off marks | JAMB brochure | Official, verified |
| Programme duration | NUC accreditation list | Official, verified |
| Subject combinations | JAMB brochure | Official, verified |

A single `primary_source_id` CANNOT represent this. Which source is "primary"?
- NUC? But NUC doesn't provide tuition or deadlines
- JAMB? But JAMB doesn't provide accreditation or duration
- Institution? But the institution doesn't provide admission requirements or cut-off marks

There IS no primary source. Every source is primary for the fields it provides. The `primary_source_id` abstraction is fundamentally inadequate for this reality.

---

### 6.2 — Comparison of Provenance Approaches

**A. JSONB-only provenance (HasProvenance trait only)**

Stores all provenance in a JSONB column on each entity. Could theoretically store per-field sources:

```json
{
  "source_type": "official",
  "import_batch_id": "abc-123",
  "fields": {
    "name": {"source_id": 1, "acquired_at": "2024-06-15", "is_verified": true},
    "tuition": {"source_id": 2, "acquired_at": "2024-07-01", "is_verified": false}
  }
}
```

Pros: Single column, no joins, flexible schema
Cons:
- **No referential integrity** on source_id values inside JSONB — a deleted InformationSource won't cascade
- **Unqueryable** — "find all fields sourced from JAMB" requires JSONB path queries across all entities
- **Becomes a dumping ground** — over time, the JSONB grows to include version history, conflict records, audit trails
- **Difficult to enforce immutability** — the data acquisition doc says "provenance is immutable once recorded," but JSONB is easily mutated
- **Performance degrades** as the JSONB grows — large JSONB values are stored out-of-line (TOAST), requiring decompression to access

**B. primary_source_id FK + provenance JSONB (Previous recommendation)**

Adds a `primary_source_id` FK to each entity in addition to the JSONB provenance.

Pros: FK provides referential integrity for the "primary" source; JSONB provides flexibility
Cons:
- **`primary_source_id` is misleading** — it implies one source is primary for the entire entity, which is false for multi-source entities
- **Creates confusion** — developers will wonder "should I use primary_source_id or the source_id in provenance JSONB?" Two sources of truth for the same information
- **FK is often null** — for entities where no single source is primary (most entities), the FK is null and therefore useless
- **Still can't represent field-level provenance** — the JSONB could store per-field sources, but then what's the point of the FK?

**C. Normalized entity_provenance table**

A table with one row per (entity, field, source) tuple:

```
entity_provenance
  entity_type    string (morph type)
  entity_id      bigint (morph ID)
  field_name     string
  source_id      bigint FK → information_sources
  value_hash     string (hash of the value at the time of recording)
  acquired_at    timestamp
  is_verified    boolean
  superseded_at  timestamp nullable (when a newer source replaced this)
```

Pros: Normalized, queryable, referential integrity, supports history (superseded_at)
Cons:
- **Potentially expensive** — one row per field per source change. For an entity with 20 fields updated from 3 sources, that's 60 rows. For 10,000 entities, that's 600,000 rows. Not catastrophic, but more than entity-level provenance.
- **Requires joins** — loading an entity with its provenance requires joining with entity_provenance
- **Over-engineered for MVP** — most entities in MVP come from a single source (one import batch), so field-level provenance is rarely needed

**D. Source claims / observations (Theoretical ideal)**

Every piece of data is an "observation" or "claim" from a source. The canonical store is the result of reconciling claims. This is essentially event sourcing for data — every field value is the result of applying a series of source claims in temporal order.

Pros: Theoretically pure — every data point has complete lineage
Cons:
- **Contradicts ADR-02** (event sourcing is not the persistence model)
- **Massive complexity** — every read requires reconstructing the current state from claims
- **Not suitable for MVP** — this is a research-grade architecture, not a startup MVP

**E. Field-level provenance via a dedicated table**

Similar to C but with a more specific design:

```
field_provenance
  id             bigint PK
  entity_type    string
  entity_id      bigint
  field_name     string
  source_id      bigint FK → information_sources
  value_hash     string (SHA-256 hash of the field value)
  acquired_at    timestamp
  is_verified    boolean default false
  superseded_at  timestamp nullable
  created_at     timestamp
```

Populated ONLY when:
- A field has a different source than the entity's overall source (multi-source entity)
- A conflict is detected between sources (JAMB says X, institution says Y)
- A field is manually edited by an admin (override provenance)

Pros: Targeted — only records provenance where it matters; most entities don't need it
Cons: Two-tier provenance model (JSONB for entity-level, table for field-level) adds complexity

**F. Hybrid model (RECOMMENDED)**

Combines entity-level JSONB (HasProvenance trait) with field-level table (field_provenance) only when needed.

Entity-level JSONB (on every entity):
```json
{
  "source_type": "official",
  "source_url": "https://jamb.gov.ng/brochure.pdf",
  "acquired_at": "2024-06-15T10:30:00Z",
  "last_verified_at": "2024-06-15T10:30:00Z",
  "trust_level": "high",
  "verification_status": "verified",
  "import_batch_id": "abc-123"
}
```

Field-level provenance (only for multi-source or conflicted fields):
- Records in `field_provenance` table only when different fields have different authoritative sources
- Records when conflicts are detected between sources
- Records when a field is manually overridden

Pros:
- **80/20 solution** — entity-level JSONB handles 80% of cases (single-source entities) efficiently
- **Correct for multi-source entities** — field_provenance handles the 20% of cases where field-level attribution matters
- **No misleading `primary_source_id`** — the entity-level provenance is "overall" provenance, not "primary source"
- **Incrementally adoptable** — field_provenance table can be created when needed, not from day one

Cons:
- **Two-tier model adds complexity** — developers must understand both tiers
- **Interaction with verification engine** — when the engine detects a conflict, it must create a field_provenance record
- **Trigger conditions need specification** — when exactly should field_provenance records be created?

---

### 6.3 — Why primary_source_id Must Go

The `primary_source_id` FK creates a false abstraction. Consider the consequences:

1. **Display**: If the UI shows "Source: JAMB" for an institution, but the tuition field came from the institution's website, the user is misinformed. They might trust the tuition figure because they think it came from JAMB, when it actually came from an unverified source.

2. **Verification**: If an admin verifies the institution by checking against the JAMB brochure, the `primary_source_id` changes to JAMB. But the tuition field (from the institution) is now implicitly "verified" even though it wasn't checked. This is a verification false positive.

3. **Conflict detection**: If JAMB and the institution disagree on the application deadline, `primary_source_id` cannot represent this. It's either JAMB (ignoring the institution's claim) or the institution (ignoring JAMB's claim). Neither is correct — both claims exist and the conflict must be resolved.

4. **Analytics**: "How many institutions have verified data?" is ambiguous — verified by which source? `primary_source_id` implies a binary (verified/not verified), but the reality is nuanced (some fields verified, some not, by different sources).

Removing `primary_source_id` eliminates these problems. Entity-level provenance JSONB provides the "overall provenance" for display purposes, and field-level provenance (when needed) provides per-field attribution.

---

### 6.4 — Interaction with the Data Acquisition Pipeline

The data acquisition pipeline produces provenance as a natural byproduct of the import process:

```
1. Import job creates an ImportBatch (references InformationSource)
2. Import job creates PendingImports (one per entity, referencing ImportBatch)
3. Verification engine checks PendingImports (duplicate detection, cross-source consistency, schema validation)
4. Verified PendingImports are applied to the canonical store
5. Each applied entity gets provenance metadata (source_type, import_batch_id, acquired_at)
```

In this pipeline, the entity-level provenance JSONB is populated automatically by the import process. No manual intervention is needed.

Field-level provenance is needed when:
- **Cross-source conflicts are detected**: The verification engine finds that JAMB and the institution disagree on a specific field value. A `field_provenance` record is created for each conflicting field, recording both sources.
- **Partial updates occur**: A new import updates some fields but not others. The updated fields' provenance changes to the new source; the unchanged fields retain their original provenance. If the sources differ, `field_provenance` records are created.
- **Manual edits occur**: An admin manually corrects a field value. A `field_provenance` record is created with source = "admin override."

The key insight is: **MOST entities come from ONE source (a single import batch).** For these entities, entity-level provenance is sufficient. Field-level provenance is needed only for the minority of entities where fields come from different sources. The hybrid model reflects this reality.

---

### 6.5 — cut_off_marks.source_id: Correct Pattern for That Table

The `cut_off_marks` table has `source_id FK nullable → information_sources`. This is correct for that specific table because:
- Each cut-off mark record represents a single factual assertion from a single source
- "JAMB says the cut-off mark for Medicine at UNILAG in 2024 is 280" — this is one source, one fact, one record
- The source_id directly attributes the entire record to its source

This is different from the Institution/Programme tables, where each record contains fields from multiple sources. For those tables, a single `source_id` would be misleading (as argued above).

The `cut_off_marks.source_id` pattern should remain. It's a good model for tables where each record is a single-source assertion.

---

### 6.REVISED — Revised Recommendation for ND-4

**Hybrid provenance model:**

1. **HasProvenance trait** (JSONB on every entity): `source_type, source_url, acquired_at, last_verified_at, trust_level, verification_status, import_batch_id`. This is the "overall provenance" for quick reference and display. Populated automatically by the import pipeline.

2. **`field_provenance` table** (for multi-source fields and conflicts):
   ```
   field_provenance
     id             bigint PK
     entity_type    string (morph type)
     entity_id      bigint (morph ID)
     field_name     string
     source_id      bigint FK → information_sources
     value_hash     string (SHA-256 hash of the field value at time of recording)
     acquired_at    timestamp
     is_verified    boolean default false
     superseded_at  timestamp nullable (when a newer source replaced this)
     created_at     timestamp
     updated_at     timestamp

     Index: morphs index on (entity_type, entity_id)
     Index: (entity_type, entity_id, field_name) — find provenance for a specific field
     Index: source_id
     Index: (source_id, is_verified) — find unverified data from a specific source
   ```

   Populated ONLY when:
   - A field has a different source than the entity's overall source
   - A conflict is detected between sources
   - A field is manually edited by an admin

3. **NO `primary_source_id` FK on entities** — it's misleading for multi-source entities.

4. **`cut_off_marks.source_id` remains** — it's correct for that specific table.

---

## PART 7 — CROSS-DECISION ARCHITECTURE

This is the most important part of the review. The five decisions are NOT independent. They form one larger architectural concept that must be understood as a whole.

---

### 7.1 — The Data Lineage Architecture

The five decisions are all aspects of one architectural question: **How does information flow from sources into the canonical store, and how is its origin tracked?**

The information flow is:

```
SOURCE → IDENTIFICATION → OBSERVATION → RECONCILIATION → CANONICAL ASSERTION → PUBLICATION
```

Let's map each decision to this flow:

| Flow Stage | Description | Decisions Involved |
|------------|-------------|-------------------|
| **SOURCE** | What IS the source? (JAMB brochure, institution website, NUC list) | ND-5 (InformationSource Classification) |
| **IDENTIFICATION** | How does the source REFER to entities? (JAMB code, NUC code) | BD-5 (External Identifier Model) |
| **OBSERVATION** | What does the source CLAIM? (staging data in import_batches/pending_imports) | Already modeled in 06-data-acquisition.md |
| **RECONCILIATION** | Do multiple sources agree? (verification engine, conflict detection) | ND-4 (Provenance Model) — needs field-level provenance |
| **CANONICAL ASSERTION** | What is the accepted truth? (domain entities in the canonical store) | BD-1 (PK type), BD-3 (phase storage) — persistence concerns |
| **PUBLICATION** | How is truth presented with trust signals? (search, API, UI) | ND-4 (Provenance Model) — needs field-level trust signals |

**Three of the five decisions (BD-5, ND-5, ND-4) are in the SOURCE → IDENTIFICATION → RECONCILIATION flow.** They are tightly coupled and cannot be resolved independently without risk of inconsistency.

---

### 7.2 — The Missing Domain Concept

The current canonical documents are trying to represent:
- Sources (InformationSource) → ND-5
- Source identifiers (jamb_code, nuc_code — not modeled) → BD-5
- Observations (pending_imports — staging only, not persisted) → already modeled
- Provenance (HasProvenance trait — entity-level JSONB) → ND-4
- Verification (InformationSource verification status) → ND-5
- Canonical facts (domain entities) → all decisions

using **DISCONNECTED columns and JSON blobs.** The five decisions are all SYMPTOMS of one missing domain concept: **the data provenance and reconciliation pipeline is architecturally incomplete.**

The actual domain model should be:

```
InformationSource (what IS the source?)
    ↓ provides
ExternalIdentifier (the source's identifier for an entity — JAMB code, NUC code)
    ↓ feeds into
ImportBatch → PendingImport (staging observations)
    ↓ verified through
VerificationEngine (duplicate detection, cross-source consistency, schema validation)
    ↓ produces
Canonical Entity (Institution, Programme, etc.)
    with
HasProvenance (entity-level: "this entity was last updated from source X at time Y")
    and optionally
FieldProvenance (field-level: "this field's value came from source Z")
```

This is a coherent pipeline where each stage builds on the previous one. The five decisions are really about how to model the connections between these stages.

---

### 7.3 — Why the Decisions Must Be Resolved Together

If we resolve the decisions independently, we risk:

1. **BD-5 resolved without ND-5**: If external identifiers are modeled with `authority_id FK → education_authorities` but InformationSource still has `institution_id`, the identifier's authority and the provenance source are disconnected. The JAMB code on an institution should reference JAMB as an authority AND as a source — but if InformationSource has `institution_id`, the JAMB source can't be linked to the JAMB identifier correctly.

2. **ND-5 resolved without ND-4**: If InformationSource has no `institution_id` but provenance is entity-level only, we lose the ability to trace which source provided which data. The source exists independently, but we can't connect it to specific fields on specific entities.

3. **ND-4 resolved without BD-5**: If provenance is field-level but external identifiers are columns, the provenance system can't attribute identifiers to sources. "This JAMB code came from the 2024 JAMB brochure" is a provenance assertion that requires the identifier to be a first-class object (not a column).

4. **BD-1 resolved without other decisions**: If PK types are changed but the FK references in cut_off_marks, external_identifiers, and field_provenance don't align, the schema has type mismatches.

The correct approach is to design the **Data Lineage Architecture** as a coherent whole, then derive the individual decisions from it.

---

### 7.4 — The Coherent Data Lineage Model

```
─── SOURCE LAYER ───

education_authorities
  id          bigint PK
  name        string (e.g., "Joint Admissions and Matriculation Board")
  short_name  string (e.g., "JAMB")
  country_id  bigint FK → countries
  type        enum: examination_body, accreditation_body, regulatory_body,
                government_agency, international_body
  ... (standard columns)

information_sources
  id                    bigint PK
  name                  string
  type                  enum: official_registry, institution_website, ...
  url                   string nullable
  verification_status   enum: unverified, verified, unreliable, deprecated
  information_category  enum: official, unofficial, historical, scraped
  verified_at           timestamp nullable
  verified_by           bigint FK nullable → users
  notes                 text nullable
  metadata              jsonb nullable
  ... (standard columns)

─── IDENTIFICATION LAYER ───

external_identifiers
  id                  bigint PK
  identifiable_type   string (morph)
  identifiable_id     bigint (morph)
  authority_id        bigint FK nullable → education_authorities
  identifier_type     string enum
  value               string
  is_primary          boolean default false
  valid_from          date nullable
  valid_to            date nullable
  source_id           bigint FK nullable → information_sources
  acquired_at         timestamp
  ... (standard columns)

─── OBSERVATION LAYER ───

import_batches
  id          bigint PK (or UUID for staging)
  source_id   bigint FK → information_sources
  ... (existing schema)

pending_imports
  id              bigint PK (or UUID for staging)
  import_batch_id bigint FK → import_batches
  ... (existing schema)

─── CANONICAL LAYER ───

institutions (and all other domain entities)
  id          bigint PK
  ... (entity fields)
  provenance  jsonb (HasProvenance trait — entity-level)
  ... (standard columns)

─── PROVENANCE LAYER ───

field_provenance
  id             bigint PK
  entity_type    string (morph)
  entity_id      bigint (morph)
  field_name     string
  source_id      bigint FK → information_sources
  value_hash     string
  acquired_at    timestamp
  is_verified    boolean
  superseded_at  timestamp nullable
  ... (standard columns)
```

This model is coherent because:
- Every source is independent of entities (ND-5 resolved)
- Every identifier is a first-class object with provenance (BD-5 resolved)
- Every entity has entity-level provenance (HasProvenance trait)
- Every conflicted/multi-source field has field-level provenance (ND-4 resolved)
- All PKs are bigint (BD-1 resolved)
- All VO storage is consistent (BD-3 resolved)

The five decisions are derived FROM this architecture, not resolved independently.

---

### 7.5 — Implementation Implications

The coherent model implies the following implementation order:

1. **Create `education_authorities` table** — reference data, seeded with JAMB, NUC, WAEC, NBTE, NCCE
2. **Create `information_sources` table** (without `institution_id`) — sources are independent
3. **Create `external_identifiers` table** — polymorphic, links entities to authority codes
4. **Create `field_provenance` table** — for multi-source field attribution
5. **Create domain entity tables with bigint PKs and HasProvenance JSONB** — standard schema
6. **Add `current_phase` column to `admission_cycles`** — alongside PhaseSequence JSONB
7. **Fix `cut_off_marks` FK types** — bigint FKs referencing bigint PKs

This implementation order respects the dependency graph: authorities → sources → identifiers → entities → provenance.

---

## PART 8 — CHALLENGE THE CANONICAL DOCUMENTS

This section identifies bugs, gaps, and inconsistencies in the canonical documents that must be resolved before migrations.

---

### 8.1 — Classification A: Must Resolve Before Migrations

**1. TYPE MISMATCH in cut_off_marks FK types**

- **Location**: 05-implementation.md, `cut_off_marks` table definition
- **Issue**: `programme_instance_id (BIGINT FK, references programme_instances)` and `admission_cycle_id (UUID FK, references admission_cycles)` use UUID FK types, but the PK types of `programme_instances` and `admission_cycles` are never specified. If they are bigint (as recommended), these FK definitions are type-incompatible and would cause a PostgreSQL migration failure.
- **Severity**: CRITICAL — this would cause a migration failure in production
- **Resolution**: Change UUID FKs to bigint FKs in `cut_off_marks` (and all other tables) to match the PK types of the referenced tables

**2. Missing current_phase column on admission_cycles**

- **Location**: 05-implementation.md, `admission_cycles` table definition
- **Issue**: The domain model defines `advancePhase()` on AdmissionCycle, but the implementation schema has no `current_phase` column. Without this, the system cannot query "which cycles are in Examination phase" or trigger notifications on phase transitions.
- **Severity**: HIGH — the domain model requires this column; its absence is a gap
- **Resolution**: Add `current_phase VARCHAR(50) nullable` column to `admission_cycles`, maintained by the `advancePhase()` domain method

**3. institution_id FK on information_sources is incorrect**

- **Location**: 05-implementation.md, `information_sources` table definition
- **Issue**: The `institution_id` hard FK makes it impossible to represent multi-institution sources (JAMB brochure, NUC accreditation list) correctly. A JAMB brochure is ONE source covering ALL institutions; it cannot have a single `institution_id`.
- **Severity**: CRITICAL — this is a modeling error, not a design preference
- **Resolution**: Remove `institution_id` from `information_sources`. Entity-to-source relationships are through provenance on entities.

---

### 8.2 — Classification B: Should Resolve Before Implementation

**4. registrationIdentifier in establish() is unexplained**

- **Location**: 03-domain.md, Institution.establish() method signature
- **Issue**: `establish(name, type, registrationIdentifier, ...)` mentions `registrationIdentifier` as a parameter but never defines what it is or where it's stored. Is this the JAMB code? NUC code? A composite identifier? Something else?
- **Severity**: MEDIUM — the domain model references a concept that isn't modeled in the implementation
- **Resolution**: Map `registrationIdentifier` to the `external_identifiers` table. When `establish()` is called, it creates an Institution and optionally creates an ExternalIdentifier record linking the institution to the authority that assigned the registration identifier.

**5. Provenance model is underspecified**

- **Location**: 06-data-acquisition.md, provenance model section
- **Issue**: The provenance model is defined as entity-level JSONB (HasProvenance trait), but different fields come from different sources — this cannot be represented with entity-level provenance alone. The "archive old provenance" mechanism is specified ("If a field is updated from a different source, the old provenance is archived") but not modeled.
- **Severity**: MEDIUM — the model is sufficient for single-source entities but insufficient for multi-source entities
- **Resolution**: Adopt the hybrid provenance model (entity-level JSONB + field_provenance table). Specify the "archive old provenance" mechanism as creating a `field_provenance` record with `superseded_at` set to the current timestamp.

**6. P5 violation in Nigeria-specific identifier columns**

- **Location**: Implicit in the data acquisition doc's reference to JAMB code and NUC code for fuzzy matching
- **Issue**: If `jamb_code` and `nuc_code` are added as columns on `institutions`, they violate P5 (Global-First, Nigeria-First-Dataset) by encoding Nigerian regulatory body names into the schema.
- **Severity**: MEDIUM — the columns aren't explicitly in the implementation doc yet, but the data acquisition doc assumes they exist
- **Resolution**: Do NOT add `jamb_code`/`nuc_code` columns. Use the `external_identifiers` table instead.

**7. Discipline UUID creates FK type heterogeneity**

- **Location**: 05-implementation.md, `disciplines` table definition
- **Issue**: Using UUID for `disciplines.id` but (presumably) bigint for other entity PKs creates mixed FK types across the schema.
- **Severity**: MEDIUM — not a runtime bug, but a cognitive and maintenance burden
- **Resolution**: Change `disciplines.id` to bigint. Use explicit seeded IDs for cross-environment stability.

---

### 8.3 — Classification C: Can Safely Defer

**8. Missing field_provenance concept**

- **Location**: Gap in all canonical documents
- **Issue**: Field-level provenance is needed for correct trust display and conflict resolution, but it can be deferred until the import pipeline is implemented and real multi-source scenarios emerge.
- **Severity**: LOW — entity-level provenance is sufficient for MVP; field-level provenance can be added incrementally
- **Resolution**: Design the `field_provenance` table schema but defer implementation until conflicts are actually detected in the import pipeline.

**9. PhaseSequence JSONB form component**

- **Location**: Not in canonical documents — an implementation concern
- **Issue**: Editing PhaseSequence in Filament requires a custom form component or a Repeatable field that casts to JSON.
- **Severity**: LOW — this is an implementation detail, not a schema concern
- **Resolution**: Implement when building the Filament admin panel. Use a `Repeatable` field with JSON cast as the simplest approach.

---

### 8.4 — Summary of Canonical Document Issues

| # | Issue | Classification | Resolution |
|---|-------|---------------|------------|
| 1 | Type mismatch in cut_off_marks FK types | A (Must fix) | Change UUID FKs to bigint FKs |
| 2 | Missing current_phase on admission_cycles | A (Must fix) | Add current_phase column |
| 3 | institution_id FK on information_sources incorrect | A (Must fix) | Remove institution_id |
| 4 | registrationIdentifier in establish() unexplained | B (Should fix) | Map to external_identifiers table |
| 5 | Provenance model underspecified | B (Should fix) | Adopt hybrid provenance model |
| 6 | P5 violation in Nigeria-specific columns | B (Should fix) | Use external_identifiers table |
| 7 | Discipline UUID creates FK type heterogeneity | B (Should fix) | Change disciplines.id to bigint |
| 8 | Missing field_provenance concept | C (Can defer) | Design schema, defer implementation |
| 9 | PhaseSequence JSONB form component | C (Can defer) | Implement with Filament admin panel |

---

## PART 9 — REVISED DECISION MATRIX

---

### 9.1 — Decision Comparison Table

| Decision | Previous Recommendation | Revised Recommendation | Confidence | Why Changed | Canonical Conflict? | Migration Impact |
|----------|------------------------|----------------------|------------|-------------|-------------------|------------------|
| **BD-1** | Option D: bigint + UUID for disciplines | Uniform bigint for ALL domain PKs including disciplines. Explicit seeded IDs for reference data. UUID only for import/staging tables. | HIGH | FK type heterogeneity is unnecessary; explicit seeded IDs achieve seeding stability; cut_off_marks UUID FK was a type mismatch bug | Yes — 05-implementation.md is internally inconsistent on PK types | Fix cut_off_marks FK types; change disciplines.id to bigint; update all UUID FK references to bigint |
| **BD-3** | Option A: JSONB only | JSONB PhaseSequence + `current_phase` string column on admission_cycles | HIGH | Missing `current_phase` column is a gap; JSONB alone cannot support phase-based filtering/notifications | Yes — 05-implementation.md missing current_phase column | Add current_phase column; maintain it in advancePhase() |
| **BD-5** | Option A: source-specific columns for MVP | Generic `external_identifiers` table from day one | HIGH | Nigeria-specific columns violate P5; JAMB+NUC are already 2 sources; migration is not cheap; provenance favors generic model | Yes — P5 (Global-First) violated by jamb_code/nuc_code columns | Create external_identifiers table; no jamb_code/nuc_code columns on institutions |
| **ND-5** | InformationSource aggregate root with nullable institution_id | InformationSource aggregate root with NO institution_id | HIGH | institution_id conflates "what is the source?" with "what does it concern?"; JAMB/NUC sources cover all institutions | Yes — 05-implementation.md has hard institution_id FK that's incorrect | Remove institution_id from information_sources; provenance links on entities instead |
| **ND-4** | primary_source_id FK + provenance JSONB | HasProvenance JSONB (entity-level) + field_provenance table (for conflicts/multi-source fields only). NO primary_source_id. | MEDIUM | primary_source_id is misleading for multi-source entities; field-level provenance is needed for correct trust display | Yes — 06-data-acquisition.md provenance model is entity-level only, insufficient for field-level trust | Add field_provenance table; enhance HasProvenance JSONB; no primary_source_id FK |

---

### 9.2 — Decisions I Should Approve Now

**1. BD-1: Uniform bigint PKs**

Sufficiently justified. No domain invariant requires UUID identity. Single-writer PostgreSQL doesn't need globally unique IDs. Explicit seeded IDs solve the reference data problem. The FK type mismatch in cut_off_marks must be fixed. The cognitive burden of mixed PK types has no offsetting benefit.

**2. BD-3: JSONB + current_phase column**

Sufficiently justified. The gap in the implementation doc (missing `current_phase`) must be fixed regardless of the PhaseSequence storage decision. JSONB preserves domain VO integrity. `current_phase` enables efficient filtering, notification triggers, and Typesense denormalization. The hybrid approach (JSONB + column) is the best of both worlds.

**3. BD-5: Generic external_identifiers table**

Sufficiently justified. P5 compliance requires it — Nigerian regulatory body codes cannot be hard-coded into the schema. JAMB+NUC are already 2 instances, and WAEC/NBTE/NCCE are immediately behind. The migration cost from columns → generic is real and should be avoided by doing it correctly from day one. The provenance model naturally aligns with first-class identifier objects.

**4. ND-5: InformationSource without institution_id**

Sufficiently justified. The JAMB brochure example proves that sources can be institution-agnostic. The current implementation doc's hard FK is a modeling error, not a design preference. Removing `institution_id` cleanly separates "what is the source?" from "what does the source provide information about?" — a separation that provenance handles correctly.

---

### 9.3 — Decisions That Should NOT Be Approved Yet

**1. ND-4: Provenance model**

The hybrid model (entity-level JSONB + `field_provenance` table) is directionally correct, but:

- **The `field_provenance` table design needs more specificity.** What are the exact trigger conditions for creating a record? When a field is updated from a different source? When a conflict is detected? When an admin manually edits a field? These rules must be codified.
- **The interaction with the data acquisition pipeline's verification engine needs more design.** When the verification engine detects a conflict between JAMB and the institution on a specific field, how does it create the `field_provenance` record? What happens to the conflicting values? Are both stored, or is one marked as superseded?
- **The retention policy needs specification.** How long are `field_provenance` records retained? Forever? Until the entity is deleted? Until the source is deprecated? This affects storage growth and query performance.
- **The query patterns need specification.** What questions will the UI ask of field-level provenance? "Show me the source for each field on this institution"? "Show me all fields where sources conflict"? "Show me all data from unverified sources"? These queries determine the required indexes and access patterns.

**Recommendation**: APPROVE the direction (no `primary_source_id`, hybrid model) but DEFER the exact `field_provenance` schema until the import pipeline is implemented and real multi-source scenarios emerge. The `field_provenance` table can be added in a later migration without affecting the initial schema.

---

### 9.4 — Decisions That Should Be Merged

**BD-5 (External Identifiers) + ND-5 (InformationSource) + ND-4 (Provenance) should be merged into one architectural decision: THE DATA LINEAGE ARCHITECTURE.**

These three decisions are not independent:
- **External identifiers** are how sources REFER to entities (BD-5)
- **InformationSource** is what a source IS (ND-5)
- **Provenance** is how we TRACK which source provided which data (ND-4)

Resolving them independently risks creating inconsistencies. They should be designed as one coherent data lineage architecture, as described in Part 7.

The merged decision should be named **"ADR-DL1: Data Lineage Architecture"** and should specify:
1. InformationSource model (without `institution_id`)
2. ExternalIdentifier model (generic, polymorphic)
3. Provenance model (hybrid: entity-level JSONB + field_provenance table)
4. The relationships between these three models
5. The interaction with the import pipeline

---

## PART 10 — GO/NO-GO FOR MIGRATION DECISION

---

### 10.1 — GO Conditions (Resolved)

✅ **BD-1: Uniform bigint PKs** — direction is clear and justified. No domain invariant requires UUID. Explicit seeded IDs solve the reference data problem. FK type mismatch must be fixed.

✅ **BD-3: JSONB + current_phase** — gap identified, solution clear. JSONB preserves domain VO integrity. `current_phase` enables queries and notifications. The hybrid approach is optimal.

✅ **BD-5: Generic external_identifiers** — direction is clear and P5-compliant. The generic table aligns with provenance, supports future expansion, and avoids the migration from columns → generic.

✅ **ND-5: InformationSource without institution_id** — the JAMB brochure case proves the need. The current implementation doc's hard FK is a modeling error. Removing it cleanly separates source identity from entity association.

---

### 10.2 — NO-GO Blockers (Unresolved)

❌ **ND-4: Exact provenance model needs further specification.** The direction (hybrid, no `primary_source_id`) is correct, but the `field_provenance` table design, trigger conditions, retention policy, and interaction with the verification engine need more work. APPROVE the direction, DEFER the exact schema.

❌ **The five decisions should be reconceived as ONE Data Lineage Architecture decision (BD-5 + ND-5 + ND-4).** Resolving them independently risks inconsistencies. The merged decision (ADR-DL1) should be designed as a coherent whole before any migrations are written.

❌ **Three bugs in 05-implementation.md must be fixed before migrations:**
1. **cut_off_marks FK type mismatch** — UUID FKs referencing presumably bigint PKs. PostgreSQL will reject this.
2. **Missing current_phase column on admission_cycles** — the domain model requires it, the implementation schema doesn't have it.
3. **Hard institution_id FK on information_sources** — can't represent multi-institution sources (JAMB, NUC).

---

### 10.3 — Required Actions Before GO

1. **Fix 05-implementation.md**:
   - Change `cut_off_marks` FK types from UUID to bigint
   - Add `current_phase` column to `admission_cycles`
   - Remove `institution_id` from `information_sources`
   - Change `disciplines.id` from UUID to bigint
   - Remove any UUID FK references that don't match the referenced table's PK type

2. **Create ADR-DL1: Data Lineage Architecture**:
   - Merge BD-5, ND-5, and ND-4 into one coherent architectural decision
   - Specify InformationSource model (without `institution_id`)
   - Specify ExternalIdentifier model (generic, polymorphic)
   - Specify Provenance model (hybrid: entity-level JSONB + deferred `field_provenance` table)
   - Specify relationships between the three models
   - Specify interaction with the import pipeline

3. **Defer `field_provenance` table implementation**:
   - Design the schema but don't create the migration
   - Implement after the import pipeline is working and real multi-source scenarios emerge
   - Entity-level JSONB (HasProvenance trait) is sufficient for MVP

4. **Update 03-domain.md**:
   - Map `registrationIdentifier` in `establish()` to the `external_identifiers` table
   - Clarify that PhaseSequence VO persistence includes a `current_phase` denormalized projection

---

### 10.4 — VERDICT

## **NO-GO FOR MIGRATION**

Three implementation doc bugs must be corrected, ND-4 provenance needs more design, and the three provenance-related decisions should be merged into one Data Lineage Architecture decision before any migrations are written.

The direction on all five decisions is clearer than before:
- **BD-1**: Uniform bigint ✅
- **BD-3**: JSONB + current_phase ✅
- **BD-5**: Generic external_identifiers ✅
- **ND-5**: InformationSource without institution_id ✅
- **ND-4**: Hybrid provenance (direction correct, details deferred) ⚠️

But the work is not complete. Writing migrations now would encode bugs and underspecified concepts into schema. The canonical documents must be corrected first, and the Data Lineage Architecture must be designed as a coherent whole.

---

### 10.5 — Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| Migrations written with type mismatch bugs | HIGH if migrations proceed now | CRITICAL (migration failure in production) | Fix canonical docs first; enforce homogeneous bigint PKs |
| InformationSource can't represent JAMB/NUC sources | CERTAIN if institution_id FK remains | HIGH (data integrity violation — must create 500+ duplicate source records) | Remove institution_id; use provenance for entity association |
| External identifiers require schema migration for each new authority | HIGH if columns are used | MEDIUM (deployment cost + regression risk per new authority) | Use generic external_identifiers table from day one |
| Trust signals are misleading | CERTAIN if primary_source_id is used | MEDIUM (users trust data from wrong source) | Use hybrid provenance; no primary_source_id |
| Field-level provenance is needed but not modeled | MEDIUM in MVP, HIGH in Stage 3 | MEDIUM (cannot display per-field trust signals) | Design field_provenance table; defer implementation until needed |
| Phase-based queries are slow/complex | CERTAIN if JSONB-only without current_phase | LOW-MEDIUM (poor UX on dashboards) | Add current_phase column |

---

### 10.6 — Timeline Recommendation

| Phase | Duration | Deliverables |
|-------|----------|-------------|
| **Phase 1: Fix canonical docs** | 1-2 days | Corrected 05-implementation.md (FK types, current_phase, institution_id, disciplines PK) |
| **Phase 2: Design ADR-DL1** | 2-3 days | Data Lineage Architecture ADR covering BD-5, ND-5, ND-4 as a coherent whole |
| **Phase 3: Write migrations** | 3-5 days | Initial schema migrations based on corrected canonical docs + ADR-DL1 |
| **Phase 4: Implement import pipeline** | 5-10 days | Import pipeline with entity-level provenance; real multi-source scenarios emerge |
| **Phase 5: Implement field_provenance** | 2-3 days | Field-level provenance table + trigger logic based on real conflict patterns |

**Total estimated time before field-level provenance is complete: 13-23 days.**

**Minimum time before migrations can be written: 3-5 days (Phase 1 + Phase 2).**

---

### 10.7 — Final Statement

This adversarial review has reopened five foundational decisions, identified three critical bugs in the canonical implementation document, revealed that three of the five decisions are aspects of a single Data Lineage Architecture, and determined that migrations cannot proceed until the canonical documents are corrected and the Data Lineage Architecture is designed as a coherent whole.

The review has changed four of the five previous recommendations:

- **BD-1**: Changed from "bigint + UUID for disciplines" to "uniform bigint for all domain PKs" — FK type heterogeneity has no offsetting benefit
- **BD-3**: Changed from "JSONB only" to "JSONB + current_phase column" — the missing current_phase column is a gap that must be fixed
- **BD-5**: Changed from "source-specific columns for MVP" to "generic external_identifiers table from day one" — P5 compliance requires it, and the migration cost is not cheap
- **ND-5**: Changed from "nullable institution_id" to "no institution_id" — the JAMB brochure example proves that institution_id on InformationSource is a modeling error
- **ND-4**: Changed from "primary_source_id FK + provenance JSONB" to "hybrid provenance (entity-level JSONB + deferred field_provenance table, no primary_source_id)" — primary_source_id is misleading for multi-source entities

**The verdict is NO-GO FOR MIGRATION.** The path forward is clear but the work is not complete. Proceed with Phase 1 (fix canonical docs) and Phase 2 (design ADR-DL1) before writing any migrations.

---

*End of Adversarial Decision Review*
