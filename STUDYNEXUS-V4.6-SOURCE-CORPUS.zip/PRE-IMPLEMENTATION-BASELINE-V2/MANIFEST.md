# StudyNexus — Pre-Implementation Baseline v2 Manifest

**Date:** 2026-08-19 (V4.6 final remediation pass: 2026-08-19)
**Version:** 4.6
**Status:** V4.6 FINAL — Final global tuition domain decision pass complete. The tuition/fee representation ambiguity is RESOLVED: V1/FVS ProgrammeInstance has ONE canonical `MonetaryAmount` tuition value (`{amount, currency}`); differentiated fee categories (indigene/non-indigene, home/international, resident/non-resident, etc.) are EXPLICITLY DEFERRED to post-V1 alongside T-16 (tuition versioning, Phase 2). The previous audit's hallucinated `{tier_label, amount, currency}` JSON schema has been retracted. No global `FeeCategory` enum has been introduced. The Nigerian `indigene`/`non-indigene` concept is explicitly classified as a Nigerian institution-specific fee classification, NOT a global StudyNexus domain primitive, NOT synonymous with domestic/international. The canonical `MonetaryAmount` VO definition (`{amount, currency}`) is unchanged. ProgrammeInstance identity (INV-PI1) is unchanged. All C-01 through C-10 findings remain resolved. Documentation baseline: FROZEN — DOCUMENTATION READY. Executable implementation status: NOT YET EXECUTED. 57 markdown files (file count unchanged).

---

## V4.6 Final Remediation Pass Summary (2026-08-19)

This pass applied targeted fixes for the four remaining verified findings (N-1 through N-4) plus two genuine domain ambiguities (tuition tier representation; mixed-currency tuition aggregation). It did NOT introduce new architecture, new entities, new identity dimensions, new exchange-rate infrastructure, or new search architecture. The V4.6 architecture remains substantially settled.

**N-1 (HIGH, fixed):** canonical/06-data-acquisition.md §3 Architecture Overview rewritten as the authoritative V4.6 trust-boundary diagram (separate ACQUISITION and PRODUCTION environments, single crossing point via ingestion API). §7 Import Workflow, §9 Scheduling, §10 Required Packages, §12 Integration annotated with environment tags. New §13 (Ingestion API Endpoint) and §14 (Code-Sharing Does Not Equal Trust-Sharing) added. The previous continuous-pipeline diagram (External Sources → Adapter Layer → Staging Layer → Domain Layer with no trust boundary) is removed.

**N-2 (HIGH, fixed):** governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md V4.6 supersession note added at top of document with V2-era vs V4.6-authoritative count comparison table. Historical review content preserved per audit prompt §5 Option B. (Previous audit claimed this was remediated under M-COUNT-01 but it was not — verified by direct file inspection.)

**N-3 (MEDIUM, fixed):** README.md and GLOSSARY.md residual V4.2 references corrected. README.md line 54 "(this file — V4.2 developer quick-start)" → "V4.6"; line 57 "(domain glossary for V4.2)" → "V4.6"; line 125 "(V4.2 addition)" → "(added in V4.2; retained in V4.6)". GLOSSARY.md line 15 "(V4.2 change)" → "(canonical since V4.6; historically a V4.2 change)"; line 38 "## V4.2-Specific Concepts" → "## V4.6-Specific Concepts" with note "Historically introduced in V4.2 and retained through V4.6"; line 109 "(V4.2), not Programme" → "(canonical since V4.6; historically a V4.2 change)". Legitimate historical references (V4.2-REMEDIATION-REPORT.md filename references, V4.1→V4.2 narrative) preserved.

**N-4 (MEDIUM, fixed):** product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md line 582 future-feature wording rewritten. Old: "Institution self-service (institution-owner, institution-admin, etc.) is NOT in the MVP." New: "Institution self-service administration (organization-scoped owner/admin capabilities, etc.) is NOT in the MVP. ... The V4.6 RBAC model already defines the bare role strings (owner, admin, admissions, editor, viewer) that will be used by the future Organization Portal; the future feature will reuse these role strings — it does not introduce new roles."

**Tuition tier ambiguity (resolved conservatively):** Per INV-PI1, ProgrammeInstance identity is (programme, campus, delivery_mode, academic_year) — fee category is NOT an identity dimension. The previous audit's claim that "each tier is a separate ProgrammeInstance" is FALSE and has been retracted. Indigene/non-indigene tuition tiers are a property of the MonetaryAmount VO's JSON serialization (an optional list of {tier_label, amount, currency} tuples), not a separate ProgrammeInstance. The tuition_amount denormalized column is the representative single value (minimum tier amount) used for search projection. Documented in canonical/03-domain.md §10 "Identity scope note (V4.6)" and canonical/05-implementation.md §8.4 "Tuition tiers (indigene / non-indigene)" subsection.

**Mixed-currency tuition aggregation (resolved conservatively):** No currency conversion is performed in V1 (no exchange-rate source, no FX business rule, no MonetaryAmount conversion infrastructure in the canonical package). tuition_min/tuition_max MUST NOT be computed across different currencies. If all published instances share the same currency_code, compute min/max normally. If published instances have mixed currency_code values, the projection sets tuition_min and tuition_max to null for that Programme (the Programme remains searchable by other facets; only the tuition range facet and tuition sort are unavailable). Documented in canonical/05-implementation.md §8.4 "Mixed-currency aggregation (V4.6 rule)" subsection.

**Additional governance fix:** governance/CANONICAL-UPDATE-REPORT.md §4 "Final Canonical Counts" annotated with V4.6 supersession note (previously missed in earlier remediation passes; this section showed V2-era counts including 56 tables without a supersession note).

**MANIFEST integrity:** All 57 file SHA-256 hashes recomputed via iterative self-hash procedure. Self-hash verified via zeroed-field method.

---

## V4.6 Audit-Amendment Summary (2026-08-19)

The following changes were applied during the V4.6 independent audit-amendment pass:

**BLOCKER remediations (canonical/05-implementation.md §8.3.1, §8.4):**
- Typesense filter syntax corrected from the forbidden `instances.campus:=Abuja && instances.delivery_mode:=OnCampus` (which does NOT enforce same-element semantics) to the required grouped form `instances.{campus:=Abuja && delivery_mode:=OnCampus}` (which DOES enforce same-element semantics). The full explanation, the FORBIDDEN vs CORRECT forms, and a Level-A implementation contract (concrete `ProgrammeSearchQuery` class with raw `filter_by` via Scout `options()`) are now documented in §8.3.1.
- `enable_nested_fields: true` added to the programmes Typesense collection schema (it was previously missing; without this collection-level flag, Typesense does not index nested-field attributes and any `instances.<field>` predicate fails or returns zero matches).
- Required Case A / B / C tests are now specified as the contract for the nested-filter invariant.
- Tuition projection ownership in §8.4 corrected from "MonetaryAmount VO on Programme" (wrong — Programme has no tuition field per canonical/03-domain.md §3 §10) to "derived from published ProgrammeInstances of the Programme" (with explicit treatment of indigene/non-indigene, mixed currencies, and zero-published-instance edge cases).

**HIGH remediations (canonical/02-decisions.md, 04-architecture.md, 05-implementation.md):**
- RBAC role strings in §5.2 of canonical/05-implementation.md propagated to bare `owner`/`admin`/`admissions`/`editor`/`viewer` (previously still using `institution-*` prefixed strings despite the MANIFEST V4.6 change claim).
- RBAC role strings in §5.5 Policy Pattern and §5.6 Administrative UI also updated; §6 admin-route middleware description corrected from `super_admin, content_manager, data_analyst, support_agent` (stale) to `platform-admin, platform-moderator, content-admin, content-editor` (current).
- RBAC role strings in canonical/04-architecture.md §4 (The 11-Role Model) and §10 (Admin Panel Architecture) similarly propagated.
- RBAC role strings in canonical/02-decisions.md §5.1 (Role Inventory) propagated; rationale text in §7 (Rejected options) updated to use V4.6 strings.

**HIGH remediations (governance/CANONICAL-CONSISTENCY-AUDIT.md):**
- Audit-integrity defect corrected: the ownership table previously claimed `CutOffMark belongsTo Programme + AdmissionCycle` was CONSISTENT (it should be `ProgrammeInstance + AdmissionCycle`). The row now correctly states the V4.6 canonical relationship.
- §3.2 Child Entities table corrected from 3 to 4 (added ProgrammeInstance).
- §3.3 Supporting Entities table corrected from 3 to 4 (added Campus).
- §7 Enum Consistency text corrected from "16 enums" to "17 enums".
- §8 Value Object Consistency text corrected from "13 VOs" to "29 VOs".
- V4.6 corrective note added to §0 explaining the previous audit-integrity defect.

**HIGH remediations (acquisition trust boundary — canonical/06-data-acquisition.md §0):**
- New §0 (V4.6 Trust-Boundary Amendment) added with §0.1 (the trust boundary diagram separating external acquisition from production ingestion), §0.2 (credential boundary: scrapers MUST NOT receive production DB credentials), §0.3 (reconciliation state vs workflow state distinction), §0.4 (MISSING ≠ DELETE rule), §0.5 (read-only production snapshot for reconciliation), §0.6 (pending_imports vs pending_revisions distinction). The rest of the document remains valid; this section clarifies where the architecture is allowed to run and what credentials each side has.

**MEDIUM remediations (V4.2→V4.6 label propagation):**
- README.md title and §"V4.6 Canonical Counts" labels updated from V4.2 to V4.6; "Typesense post-MVP" claim in §Package Directory Structure corrected to "Typesense V1 — PostgreSQL FTS fallback".
- GLOSSARY.md title updated from V4.2 to V4.6.
- 00-ORIENTATION/AUTHORITY-HIERARCHY.md title, version field, and §"V4.6 Key Decisions That Must Propagate" updated from V4.2 to V4.6; "Typesense scoped post-MVP" description of DISCOVERY-CLOSURE.md corrected to "Typesense established as V1 search engine".
- governance/DISCOVERY-CLOSURE.md status updated from "CLOSURE — awaiting human approval for canonical updates" to "APPROVED — V4.6 declared FINAL in MANIFEST.md". Programme-level `cut_off_marks` references corrected to ProgrammeInstance-level.

**MEDIUM remediations (stale counts in governance tier):**
- PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md annotated with V4.6 supersession note; §3 count table now shows both V2-era and V4.6-authoritative counts side-by-side; "All 16 enums aligned" corrected to "All 17 enums aligned (V4.6)".
- governance/CANONICAL-AMENDMENT-REPORT.md §5 count table annotated with V4.6 supersession note showing both V2-era and V4.6-authoritative counts; "58 tables" and "16 enums" references updated to "61 tables" and "17 enums".
- governance/CANONICAL-UPDATE-REPORT.md tuition row corrected from "Programme (MonetaryAmount VO)" to "ProgrammeInstance (MonetaryAmount VO)"; enum count corrected from 16 to 17.
- governance/FOUNDATIONAL-DECISIONS-BRIEF.md, ADVERSARIAL-DECISION-REVIEW.md, FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md annotated with V4.6 supersession notes for V2-era counts (historical review content preserved, with note that V4.6 counts are authoritative).

**MEDIUM remediations (product-experience tier):**
- product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md "Programme.tuition" reference corrected to "ProgrammeInstance.tuition (aggregated as tuition_min/tuition_max on the Programme search document per canonical/05-implementation.md §8.4)".
- product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md `tuition_min`/`tuition_max` source columns corrected from "Programme.tuition (computed)" to "ProgrammeInstance.tuition aggregated to Programme search document"; `delivery_mode` source column corrected from "Programme.delivery_mode" to "ProgrammeInstance.delivery_mode (nested `instances[]`)".
- product-experience/FIRST-VERTICAL-SLICE-UX.md delivery_mode and tuition sort rows corrected to reference ProgrammeInstance ownership and the nested instances[] design.

**Files NOT modified (no findings or findings are acceptable historical context):**
- canonical/01-business.md, canonical/03-domain.md: no findings; canonical truth already correct.
- canonical/02-decisions.md ADR-19 context line referencing cut_off_marks.programme_id: historical context describing the pre-fix state; preserved as-is.
- canonical/02-decisions.md ADR-18 line referencing "originally deferred but has since been Resolved": correct historical narrative; preserved as-is.
- archive/* (all 31 archive files): Tier 6 Historical; stale claims in archive are acceptable as historical record per AUTHORITY-HIERARCHY.md. The archive is explicitly non-authoritative; no remediation needed.

---


## File Inventory

| # | Path | SHA-256 | Size (bytes) | Category |
|---|------|---------|-------------|----------|
| 1 | `00-ORIENTATION/AUTHORITY-HIERARCHY.md` | `61d4f6212b8e1d5221e074a76acb5a7854da9fd7757fb6b7cfa90ab88f373595` | 6533 | Orientation |
| 2 | `GLOSSARY.md` | `b748543350d18a794a6914cd5d4e4e2db0b3837886d47284d7f53a71ec290454` | 11982 | Baseline |
| 3 | `MANIFEST.md` | `865ffe219d89d99e20548238dd128d5aff80e2859b13f80fc443afb0caf31abb` | 22692 | Baseline |
| 4 | `PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md` | `6535c01b26c390462e170e11b1a5997d6718445c6c560fdae7c10e54fcf3fd7b` | 9992 | Baseline |
| 5 | `README.md` | `16821501e9ea1d8b852f191f822184eecacdde68b9d44f30eb7f4ba395abf765` | 10261 | Baseline |
| 6 | `V4.2-REMEDIATION-REPORT.md` | `303d3f8bfe0b64feac23566100ba0c4ec029963042f23c06c6808fdd71ba88a1` | 16160 | Baseline |
| 7 | `archive/00-documentation-audit-report.md` | `5de4bd505d046ac30d4344cf9d99b8249c1f0debd8047e3d4659526bf0a4a21e` | 39641 | Historical |
| 8 | `archive/00-reconciliation-proposal.md` | `d3945637546b8b69a4e11e8623719ff34c8314dce3f9cc9605603d3aa675eae3` | 30005 | Historical |
| 9 | `archive/01-business-overview.md` | `70a5bd289c8b2945350cc3dfe27a6f727db770e84a5f60740f529db457c5fde4` | 12843 | Historical |
| 10 | `archive/02-glossary.md` | `a64bc423478e4c75cc5459bd69f0961c61f6c9d0155a163db003f1e9178b20bc` | 8538 | Historical |
| 11 | `archive/03-approved-decisions.md` | `2cea05b2ef3eca41cd7ea37c6b5f9a3246d462eab178a2a4b385ea30335ee620` | 16118 | Historical |
| 12 | `archive/04-open-questions.md` | `11962f984e517c02f753b9b25030e2c1257e98d4169f4be2d5790903792055f4` | 7981 | Historical |
| 13 | `archive/06-business-workflows.md` | `717c602d5b612f3193ab87f473b026b69872a298f7294d71cf1d3f4ddea57f3d` | 20707 | Historical |
| 14 | `archive/07-business-discovery-closure.md` | `6ed21ab4b355541e3a5c8a4cd860a7b06b8f438ea6ea7a162bd4d7f841b64129` | 11123 | Historical |
| 15 | `archive/08-traceability-matrix.md` | `fbbb93de3459a14257b4a82286e6f71d5c42a2f50765e6da0a4d594e795d5530` | 12765 | Historical |
| 16 | `archive/09-business-discovery-freeze.md` | `c1dfad3462d93eaf6070bc556eb819183316c2fa44e110ad57f9c0a1fdfc428c` | 4487 | Historical |
| 17 | `archive/11-domain-discovery-topic2.md` | `b30bcbe451451ab34c823d5257b0050b5dd9917acd788264577a2023766aa0dd` | 92266 | Historical |
| 18 | `archive/12-domain-discovery-topic2-revision.md` | `0ed1e8597ec733b16ca8f0951550125cac027815fda817bf2671b8e3626ac3c3` | 62702 | Historical |
| 19 | `archive/13-domain-discovery-consolidation.md` | `82d25a326e4676a9e83c11279c28c2bfe916eb56e3d605e4df2590b340be4f07` | 75673 | Historical |
| 20 | `archive/14-architectural-review-global-domain.md` | `15eebf8a7845c74a562e971baffc4ca07f66207b0eb75555deb14dc13a1b2279` | 34976 | Historical |
| 21 | `archive/15-domain-discovery-topic4-behaviour.md` | `8be2133dd4302515abd32ae97d4264deda9ae5577a7caf66dd89bc9125ab29cc` | 139882 | Historical |
| 22 | `archive/16-domain-discovery-topic3.md` | `f6ce0caa6457b3b573ea7ef4f245c563eac474958ad2c37dca96d2dcf6d76608` | 98591 | Historical |
| 23 | `archive/17-domain-integrity-review.md` | `208a4a7610ee77bd3ea92175ca7781200b2ca5122b0dcdd95e6e197a5445ba46` | 56794 | Historical |
| 24 | `archive/18-domain-resolution-analysis.md` | `8e9a38de60815f397e77a4631f3d845042dd186e5b018280fb8451dd6b0bab0c` | 67941 | Historical |
| 25 | `archive/19-domain-architecture.md` | `0d9e019903321b227c8d399c14a8aa926e7f78c90361653145dc9a25afd4561b` | 114709 | Historical |
| 26 | `archive/20-domain-architecture-validation.md` | `333f179e116447071bec460a6704ed5576d8e6238060b4fec5f91310df8b66be` | 95160 | Historical |
| 27 | `archive/21-domain-architecture-frozen-baseline.md` | `5714e0c76d2cc9c87b61af4eea0a267ffbaf815376332f9b84d5e1c97de1ba9c` | 108803 | Historical |
| 28 | `archive/22-post-freeze-platform-architecture-review.md` | `886716950b7b3ba5a9dfcef3fedcfb467eb66b1c3860b80323d43b856f308da3` | 79823 | Historical |
| 29 | `archive/23-laravel-ecosystem-build-vs-buy-review.md` | `c09fa4f087aca72d3921e8525450afef3d9edd9c719fd211c77268743be52c29` | 116374 | Historical |
| 30 | `archive/24-final-platform-and-capability-architecture.md` | `217973d4b8416b598b5f2bcca737799bed40d08d73756fabbc524549ad91b9fa` | 117115 | Historical |
| 31 | `archive/26-pre-implementation-reconciliation.md` | `fd8691af9a925206dd726cbf32983d1873304fe2f9a387ab51c558a6b0d711ad` | 57858 | Historical |
| 32 | `archive/27-final-corrected-pre-implementation-blueprint.md` | `c9a0bdaf8cc2c3e8fd18ee1440e025737e821477605e34cb57f68d57cf55a8b9` | 85973 | Historical |
| 33 | `archive/28-package-verification-audit.md` | `bcd2c53ee3004be3d6f16e80bbe72d442122502d69526a63cdc7f780cd3ebbac` | 57038 | Historical |
| 34 | `archive/29-rbac-decision.md` | `992b84c7d063f6b4a9d7db3209d98030705a650c76ad81397f1cd23e391910f7` | 4203 | Historical |
| 35 | `archive/30-data-acquisition-pipeline.md` | `18c7c1d07abf6b1f66eb4a5a234f462335bc293f2356bc00e410b1a670e28c69` | 19684 | Historical |
| 36 | `archive/HISTORICAL-README.md` | `5a6114b1f966f3da4b8c240b479451451d1f3b1f9594885966d2f8a1285e1f20` | 5602 | Historical |
| 37 | `archive/VERIFICATION-REPORT.md` | `eae4fc33ca1158b08948e1fe4a6936607d4cf09917e53a4ac95cb97aa15c7b98` | 39637 | Historical |
| 38 | `canonical/01-business.md` | `c0248291bdda23d03f2a592dd036864f15f9c7cdb47bce869fad5dd8198e7e01` | 48139 | Canonical |
| 39 | `canonical/02-decisions.md` | `4d5de0b686f3ec3c26813900553e292044f4693f2b7a376dd35aef7bd528e6a9` | 73766 | Canonical |
| 40 | `canonical/03-domain.md` | `94bbfd8c5cc2af4e77ad4fdbfcc095de56f4295870a9fc5210edee898c40622e` | 84240 | Canonical |
| 41 | `canonical/04-architecture.md` | `c58eda96b628e4a8442cefd339e1ebf59c05faaafb7b44b3cbf1e041d66fb8e7` | 70911 | Canonical |
| 42 | `canonical/05-implementation.md` | `124e46a6f0a348d48a7841917c693e726eb6a2e300ce23e30b9682dba9ec9e79` | 123658 | Canonical |
| 43 | `canonical/06-data-acquisition.md` | `5da8df5d28dbdf02c066b113de037856e4f5274531b9ee45f5e96045d3c10cb0` | 51216 | Canonical |
| 44 | `governance/ADVERSARIAL-DECISION-REVIEW.md` | `3cc4fc3264b786c37b2c4825da0d84f1aea1f2f551d6b31d4582254a5725fa09` | 132922 | Governance |
| 45 | `governance/CANONICAL-AMENDMENT-REPORT.md` | `4a3a53be6828a54fe90b606464001764e47e4e1903750cf4d2aa0fa99880b71a` | 13286 | Governance |
| 46 | `governance/CANONICAL-CONSISTENCY-AUDIT.md` | `c651b051635582e0006d8d4f0b39f25a115311d357fa96a73462451c6f3e4fbb` | 26657 | Governance |
| 47 | `governance/CANONICAL-UPDATE-REPORT.md` | `22925df4c766bd8975775346abaad638ed5a729b225301261a616eb6184d30f7` | 17141 | Governance |
| 48 | `governance/DISCOVERY-CLOSURE.md` | `8acd5756b60be03b9a02c644de402a8a03423a9a75ef2f0ee4847777b95bad34` | 37914 | Governance |
| 49 | `governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` | `aa4f2cded2f1b917dd23098df63c8db649fa6cfb760f1fb075550706b1b0b45a` | 38186 | Governance |
| 50 | `governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` | `dd548b4e4c14b53d17c6c0f32bd75200429e6abbf8ad4a387f2ed2ca02076bfa` | 45223 | Governance |
| 51 | `governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` | `b5dc4c2b36a9024f90d6e8478cdbac48c1b2372a17e657d91c48e5161ecfe77f` | 67627 | Governance |
| 52 | `governance/FOUNDATIONAL-DECISIONS-BRIEF.md` | `30d620813f307d76dcb1363c540a74b0f30f30b964bb4bb0603bb722234b7a10` | 69472 | Governance |
| 53 | `governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md` | `dc2e37f8cdc76a14a61bece90eb68f67e65637af0c9befdbb45d111d6176a6cc` | 75337 | Governance |
| 54 | `product-experience/FIRST-VERTICAL-SLICE-UI.md` | `2c66d139ce0bff533a1d7f8ca6c81d9e660569af588662259e39455abbcc8167` | 56099 | Product Experience |
| 55 | `product-experience/FIRST-VERTICAL-SLICE-UX.md` | `9747623996b802eb4e368e3c99d7a0f687887a6d9f268fce7dea4ea68bef81ec` | 52782 | Product Experience |
| 56 | `product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md` | `ff219379f7e9adf5ae7ea10c2c214080884ff263e8c8532bf33023e555a9fd6a` | 95145 | Product Experience |
| 57 | `product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md` | `3a29c765bf52fc7a7058010094c85956efe3e9f9a3b97d2b093fb32db2d927ea` | 66902 | Product Experience |

---

## Verification

All SHA-256 hashes recomputed on 2026-08-19 for V4.6 final package.

**V4.6 changes from V4.5 MANIFEST:**

- **canonical/06-data-acquisition.md** — §11.1: cut_off_marks ON CONFLICT target corrected from `(programme_instance_id, admission_cycle_id, admission_pathway)` to `(programme_instance_id, admission_cycle_id, pathway)` matching physical schema column name; accreditation_records ON CONFLICT target corrected from `(programme_id, accreditation_body)` to `(accreditable_type, accreditable_id, authority_id)` matching polymorphic table structure; §11: RBAC role strings corrected from `institution-owner`/`institution-admin` to `owner`/`admin` matching organization_members.role bare strings
- **canonical/05-implementation.md** — §8.0: idempotent upsert paragraph corrected with same column name fixes for cut_off_marks and accreditation_records
- **MANIFEST.md** — This file; all 57 file hashes recomputed for V4.6

**Unchanged files (55):** All other files retain their V4.5 content.

**Self-hash note:** The SHA-256 for MANIFEST.md (entry #3 in the table above) was computed using the zeroed-field method: the hash and size fields for entry #3 are replaced with 64 zero hex digits and 00000 respectively, then SHA-256 is computed on the resulting file content. To verify: zero the hash/size fields for entry #3 and recompute SHA-256; it should match the recorded value. The recorded hash is the stable fixed-point of the iterative procedure (write hash to field → zero field → recompute → write → repeat until stable); the iterative procedure converges because the manifest's own row's recorded hash is determined by the content of all OTHER rows, which is fixed at any given snapshot.
