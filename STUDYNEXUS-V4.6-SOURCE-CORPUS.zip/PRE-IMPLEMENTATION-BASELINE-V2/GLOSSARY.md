# StudyNexus V4.6 — Domain Glossary

**Date:** 2026-08-19
**Version:** 4.6
**Purpose:** Define key domain terms for the implementation team. This glossary is derived from the V4.6 Canonical documents (Tier 1) and supersedes the historical glossary in `archive/02-glossary.md`.

---

## Core Domain Entities

| Term | Definition | Canonical Source |
|------|-----------|-----------------|
| **Educational Institution** | An aggregate root representing a university, polytechnic, college of education, or Innovation Enterprise Institution (IEI). Has its own lifecycle (Provisional → Operational → Suspended → Closed), accreditation records, and admission policies. | 03-domain.md |
| **Programme** | An aggregate root representing a specific course of study (e.g., "Computer Science"). Belongs to an Institution. Owns its ProgrammeInstances. Admission policies are delegated to instances, not held at this level. | 03-domain.md |
| **ProgrammeInstance** | A child entity of Programme representing one concrete offering at a specific Campus, in a specific Academic Year, with a specific DeliveryMode. **Owns AdmissionPolicy and cut_off_marks** (canonical since V4.6; historically a V4.2 change). Each instance can have different admission criteria (e.g., Online vs OnCampus may require different cut-off marks). | 03-domain.md |
| **Campus** | A supporting entity belonging to Institution. Enables multi-campus institutions (e.g., University of Lagos main campus at Akoka, satellite at Idi-Araba). Each Campus carries its own Location VO and an `is_primary` flag. Exactly one Campus per Institution must be `is_primary=true` (INV-CAMP1). This ensures Institution.location is deterministic. | 03-domain.md |
| **AdmissionPolicy** | A child entity whose polymorphic parent is **ProgrammeInstance or Institution** (not Programme). Contains AdmissionRules, SubjectCombinations, and QualificationThresholds. Lifecycle: Draft → Published → Superseded → Withdrawn. Scoped to the specific offering (Instance), not the abstract degree (Programme). | 03-domain.md |
| **Scholarship** | An aggregate root representing a financial award from a ScholarshipProvider. Owns EligibilityPolicy. Lifecycle: Draft → Announced → Open → Closed → Expired/Withdrawn. | 03-domain.md |
| **AdmissionCycle** | An aggregate root representing a periodic admission period governed by an EducationAuthority. Phase transitions managed via PhaseSequence VO with lockForUpdate() concurrency control. | 03-domain.md |
| **InformationSource** | An aggregate root representing where educational data originates. No institution_id; nullable authority_id. Reliability tracked via SourceReliability enum. | 03-domain.md |
| **EducationAuthority** | A supporting entity (renamed from "Government Education Agency"). Covers JAMB, NUC, WAEC (Nigeria), ABET, UCAS (global), and non-governmental professional accrediting bodies. | 03-domain.md |
| **Qualification** | A supporting entity for reference data used by AdmissionRules and EligibilityRules. Defined by external authorities; StudyNexus records, does not manage. | 03-domain.md |
| **ScholarshipProvider** | A supporting entity serving as referential integrity guard for Scholarship (INV-S1). Weakest entity; exists for central deprecation. | 03-domain.md |
| **AccreditationRecord** | A child entity of Programme or Institution. Immutable after creation; each record is a historical fact. Current accreditation status is derived from the sequence of records. | 03-domain.md |
| **EligibilityPolicy** | A child entity of Scholarship. Contains EligibilityRules. Lifecycle: Draft → Published → Superseded → Withdrawn. | 03-domain.md |

---

## Infrastructure Entities

| Term | Definition | Canonical Source |
|------|-----------|-----------------|
| **ExternalIdentifier** | Infrastructure entity linking a domain entity to its external identity in a source system. Used for idempotent import upsert (ON CONFLICT DO UPDATE keyed on INV-EI1 composite unique index). | 05-implementation.md |
| **FieldProvenance** | Infrastructure entity recording the origin and custody history of individual field values. Hybrid provenance model: entity-level JSONB for 80% of fields, field_provenance for 20% needing granular audit. | 05-implementation.md |

---

## V4.6-Specific Concepts

> Historically introduced in V4.2 and retained through V4.6. The labels below refer to the current V4.6 canonical state.

| Term | Definition | Canonical Source |
|------|-----------|-----------------|
| **PendingRevision** | A record in the `pending_revisions` table representing an edit submitted by an Organization Portal user that awaits admin approval. Schema: id, entity_type, entity_id, submitted_by, proposed_payload (JSONB), status, reviewed_by, review_notes, created_at, updated_at. Upon approval, data is written to canonical tables and activitylog records the audit trail. | 05-implementation.md |
| **Publication Predicate** | The rule determining search visibility: A Programme is visible iff `programmes.is_published = TRUE AND EXISTS (SELECT 1 FROM programme_instances WHERE programme_id = programmes.id AND is_published = TRUE)`. One search card per Programme, with aggregated instance data. | 04-architecture.md |
| **URL Contract** | Frozen strategy: URL-readable slugs for all public-facing URLs (SEO-indexable); `public_id` UUID for internal routing, API endpoints, and JSON payloads only — never exposed in public-facing URLs. | 04-architecture.md |
| **Idempotent Import** | Import pipeline using PostgreSQL `ON CONFLICT DO UPDATE` (upsert) keyed deterministically on the `external_identifiers` unique composite index (INV-EI1): (authority_id, identifier_type, identifier) WHERE status = 'active'. Fuzzy matching is restricted to staging/review queue only; never used for canonical identity resolution. | 06-data-acquisition.md |
| **OKLCH Color Space** | Mandated color system for all UI. No HEX or HSL color codes permitted. Use semantic Tailwind classes (bg-surface, border-border, etc.) backed by OKLCH values in the theme configuration. | FIRST-VERTICAL-SLICE-UI.md |

---

## Value Objects

| Term | Definition | Canonical Source |
|------|-----------|-----------------|
| **AdmissionRule** | Encapsulates an admission requirement: qualification reference, threshold, subject combinations, and rule type. Rule type determines which fields are required. | 03-domain.md |
| **EligibilityRule** | Encapsulates an eligibility criterion: criterion type (CGPA, field of study, nationality, financial need), comparator, and value. | 03-domain.md |
| **SubjectCombination** | Ordered set of subjects with combination type (AND/OR). Used within AdmissionRules to specify required subject groups. | 03-domain.md |
| **QualificationThreshold** | Qualification reference + comparator + value + scale. Generalises "cut-off mark" — a cut-off mark is a QualificationThreshold where the qualification is a standardised assessment and comparator is >=. | 03-domain.md |
| **ValidityPeriod** | Start date + end date for policy and accreditation validity periods. Invariant: start <= end. | 03-domain.md |
| **TrustSignal** | Computed reliability indicator for an InformationSource. Derived from source verification status and provenance metadata. Computed on demand, never stored. | 03-domain.md |
| **MonetaryAmount** | Amount + currency (ISO 4217). Used for programme tuition fees (on ProgrammeInstance) and scholarship values. Invariant: amount >= 0 for fees. | 03-domain.md |
| **Duration** | Value + unit (years, months, semesters) for programme length. May differ from Programme default when set on ProgrammeInstance. | 03-domain.md |
| **Location** | Country + region + city for institution/campus geographic location. Nullable for online-only institutions. Country is ISO 3166-1. | 03-domain.md |
| **AuthorityJurisdiction** | Jurisdiction type + criteria defining an EducationAuthority's scope. What defines jurisdiction varies by country. | 03-domain.md |
| **PhaseSequence** | Ordered list of admission cycle phases with timing. Phase names and count are data (Nigeria: Registration → Examination → Results → Admission). | 03-domain.md |
| **AdmissionPathway** | Name + authority reference for an admission route. Demoted from supporting entity to VO. Pathways are discriminators within AdmissionPolicies. | 03-domain.md |

---

## Enums (17)

| Term | Values | Canonical Source |
|------|--------|-----------------|
| **InstitutionType** | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution | 03-domain.md |
| **AwardLevel** | BSc, BA, MSc, PhD (universal); ND, HND, NCE (Nigeria) | 03-domain.md |
| **AdmissionMode** | Cyclic, Rolling, MultipleIntake | 03-domain.md |
| **AccreditationStatus** | Full, Interim, Probationary, Revoked, Expired | 03-domain.md |
| **PolicyStatus** | Draft, Published, Superseded, Withdrawn | 03-domain.md |
| **ProgrammeStatus** | Prospective, Admitting, Suspended, Discontinued | 03-domain.md |
| **ScholarshipStatus** | Draft, Announced, Open, Closed, Expired, Withdrawn | 03-domain.md |
| **InstitutionStatus** | Provisional, Operational, Suspended, Closed | 03-domain.md |
| **SourceReliability** | Registered, Verified, Unreliable, Deprecated | 03-domain.md |
| **InformationCategory** | Official, Unofficial, Historical, Scraped | 03-domain.md |
| **AuthorityType** | Regulatory, Accreditation, Funding, Admissions | 03-domain.md |
| **ProviderType** | Government, Corporate, NGO, Institution | 03-domain.md |
| **OwnershipType** | Public, Private, PPP, Religious | 03-domain.md |
| **DeliveryMode** | OnCampus, Online, Hybrid | 03-domain.md |
| **QualificationStatus** | Active, Deprecated | 03-domain.md |
| **CoverageType** | Full, Partial, TuitionOnly, Stipend | 03-domain.md |
| **CampusStatus** | Active, Inactive, Planned | 03-domain.md |

---

## Nigerian Education Context

| Term | Definition |
|------|-----------|
| **JAMB** | Joint Admissions and Matriculation Board — Nigeria's unified tertiary admission body. |
| **WAEC** | West African Examinations Council. |
| **NECO** | National Examinations Council. |
| **NUC** | National Universities Commission. |
| **NBTE** | National Board for Technical Education. |
| **NCCE** | National Commission for Colleges of Education. |
| **NABTEB** | National Business and Technical Examinations Board. |
| **UTME** | Unified Tertiary Matriculation Examination (administered by JAMB). |
| **Direct Entry** | Admission into tertiary education at an advanced level (typically 200-level) based on prior qualifications. |
| **IJMB** | Interim Joint Matriculation Board — an alternative admission pathway programme. |
| **JUPEB** | Joint Universities Preliminary Examinations Board — an alternative admission pathway programme. |
| **IEI** | Innovation Enterprise Institution — a category of institution distinct from universities, polytechnics, and colleges of education. |
| **Cut-off Mark** | Minimum score required for admission into a programme instance. Scoped to ProgrammeInstance (canonical since V4.6; historically a V4.2 change), not Programme. |

---

## Technology Stack Terms

| Term | Definition |
|------|-----------|
| **TALL Stack** | Tailwind CSS + Alpine.js + Livewire + Laravel — the mandated full-stack framework. |
| **Filament v5** | Laravel admin panel framework. Used on admin domain ONLY; never on public site. |
| **Flux Pro** | UI component library for Livewire. Used with Laravel Fortify for the public auth stack. |
| **OKLCH** | Perceptually uniform color space mandated for all UI theming. Replaces HEX/HSL. |
| **PostgreSQL FTS** | Full-Text Search. Maintained as fallback search capability when Typesense is unavailable, and for admin search. |
| **Typesense** | V1 search engine for full-text search, faceting, typo tolerance, and autocomplete. |
| **spatie/laravel-activitylog ^5.0** | Audit trail package. Records activity post-approval (not used as pending revision storage). |
