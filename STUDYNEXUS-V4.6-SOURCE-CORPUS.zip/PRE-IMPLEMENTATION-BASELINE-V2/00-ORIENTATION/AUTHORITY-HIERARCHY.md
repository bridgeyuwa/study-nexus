# StudyNexus V4.6 — Authority Hierarchy & Document Classification

**Date:** 2026-08-19
**Version:** 4.6
**Purpose:** Define the authority hierarchy governing all documents in the V4.6 handoff package. When documents conflict, higher-tier documents always prevail.

---

## Tier Classification

| Tier | Name | Directory | Authority Level | Description |
|------|------|-----------|----------------|-------------|
| **1** | **Canonical** | `canonical/` | **Highest — Single Source of Truth** | Domain model, architecture, implementation blueprint, data acquisition. These documents define what the system IS. All implementation must conform to these. |
| **2** | **Product Experience** | `product-experience/` | Conforms to Tier 1 | UX flows, UI specifications, product discovery. Defines HOW the system is experienced. Must not contradict Canonical. |
| **3** | **Implementation Plan** | (within `canonical/05-implementation.md`) | Derives from Tier 1 | Migration order, table schemas, seed data, verification steps. Specific code-level guidance derived from Canonical. |
| **4** | **Governance** | `governance/` | Audit & Amendment Records | Decision reviews, consistency audits, amendment reports, lineage semantics. These document WHY decisions were made and WHAT changed, but do not override Canonical. |
| **5** | **Research** | (none in current package) | Supporting | Research documents that informed decisions. Not present in this package. |
| **6** | **Historical** | `archive/` | **Lowest — Evidence Only** | Historical discovery artifacts from the review process. Useful for understanding context but NEVER authoritative for implementation. |

---

## Conflict Resolution Rule

**If any document at Tier N contradicts a document at Tier M where M < N, the Tier M document prevails.**

Practical implications:
- If `product-experience/` says something that contradicts `canonical/`, Canonical wins.
- If `governance/` says something that contradicts `canonical/`, Canonical wins.
- If `archive/` says something that contradicts ANY other tier, the other tier wins.
- When two documents are at the SAME tier and conflict, escalate to the Lead Architect.

---

## Tier 1 — Canonical Documents (Authoritative)

These 6 documents are the single source of truth for implementation:

| Document | File | Content |
|----------|------|---------|
| 01 — Business | `canonical/01-business.md` | Business context, users, capabilities, workflows |
| 02 — Decisions | `canonical/02-decisions.md` | ADRs, approved decisions, change proposal protocol |
| 03 — Domain | `canonical/03-domain.md` | Domain model, entities, VOs, enums, events, invariants |
| 04 — Architecture | `canonical/04-architecture.md` | System architecture, publication predicates, URL contract |
| 05 — Implementation | `canonical/05-implementation.md` | Table schemas, migrations, RBAC, auth stack, search rules |
| 06 — Data Acquisition | `canonical/06-data-acquisition.md` | Import pipeline, upsert mechanism, provenance |

---

## Tier 2 — Product Experience Documents

These 4 documents define the user-facing product. They derive from Canonical and must not contradict it:

| Document | File | Content |
|----------|------|---------|
| Product Discovery | `product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md` | Product discovery findings |
| Product Architecture | `product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md` | Product architecture |
| First Vertical Slice UX | `product-experience/FIRST-VERTICAL-SLICE-UX.md` | UX flows, search (Typesense V1), slug URLs |
| First Vertical Slice UI | `product-experience/FIRST-VERTICAL-SLICE-UI.md` | UI components, OKLCH colors, Flux Pro |

---

## Tier 4 — Governance Documents

These 10 documents are audit and amendment records. They explain decisions but do not override Canonical:

| Document | File | Content |
|----------|------|---------|
| Discovery Closure | `governance/DISCOVERY-CLOSURE.md` | Discovery closure record; Typesense established as V1 search engine (PostgreSQL FTS as fallback/admin) |
| Canonical Amendment Report | `governance/CANONICAL-AMENDMENT-REPORT.md` | V1 → V2 amendment details (historical record; canonical counts may be superseded by V4.6 MANIFEST) |
| Canonical Update Report | `governance/CANONICAL-UPDATE-REPORT.md` | Canonical update records |
| Canonical Consistency Audit | `governance/CANONICAL-CONSISTENCY-AUDIT.md` | Consistency audit results |
| Lineage Semantics | `governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` | Lineage and semantics resolution |
| Schema Provenance Review | `governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` | Hostile schema review |
| Adversarial Decision Review | `governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` | Adversarial review of foundational decisions |
| Decisions Brief | `governance/FOUNDATIONAL-DECISIONS-BRIEF.md` | Foundational decisions summary |
| Adversarial Review | `governance/ADVERSARIAL-DECISION-REVIEW.md` | Decision review outcomes |
| Second-Order Review | `governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md` | Second-order architecture review |

---

## Tier 6 — Historical Archive

The `archive/` directory contains 31 historical documents from the discovery and review process. These are valuable for understanding WHY decisions were made, but are **never authoritative for implementation**. If an archive document contradicts a Canonical document, the Canonical document always wins.

---

## V4.6 Key Decisions That Must Propagate

The following V4.6 decisions are made at Tier 1 (Canonical) and must be respected at all tiers:

1. **AdmissionPolicy** is owned by **ProgrammeInstance**, not Programme (03-domain.md, 05-implementation.md)
2. **Publication predicate**: Programme visible iff `is_published AND EXISTS published Instance` (04-architecture.md)
3. **URL contract**: Slugs for public SEO; UUIDs for internal only (04-architecture.md, 05-implementation.md)
4. **Pending revisions**: Dedicated `pending_revisions` table, not Activitylog (05-implementation.md)
5. **Idempotent import**: PostgreSQL `ON CONFLICT DO UPDATE` keyed on INV-EI1 (06-data-acquisition.md)
6. **Auth stack**: Laravel Fortify + Livewire/Flux Pro, NOT Breeze (05-implementation.md)
7. **Search V1**: Typesense; PostgreSQL FTS fallback (04-architecture.md)
8. **Color system**: OKLCH mandated; no HEX/HSL (product-experience/FIRST-VERTICAL-SLICE-UI.md)
9. **activitylog**: spatie/laravel-activitylog ^5.0 frozen (04-architecture.md)
10. **ADR-18**: Marked Resolved (02-decisions.md)
