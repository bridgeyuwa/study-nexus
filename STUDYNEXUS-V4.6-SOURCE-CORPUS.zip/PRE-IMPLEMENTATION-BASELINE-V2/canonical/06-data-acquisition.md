# Data Acquisition & Ingestion Pipeline

**Date:** 2026-08-08 (V4.6 trust-boundary amendment: 2026-08-19)
**Status:** Canonical design -- addresses audit finding S17.3 (most business-critical capability, least architected)
**Authority:** Derived from Business Capability #1 ("Acquire Educational Information"), OQ2-5 resolution, and domain architecture (`21-domain-architecture-frozen-baseline.md`)
**Platform baseline:** Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4

---

## 0. V4.6 Trust-Boundary Amendment (2026-08-19)

> **This section is normative.** It amends the architecture described in §3 below by adding an explicit trust boundary between the external acquisition environment and the StudyNexus production application. The rest of this document remains valid; this section clarifies *where* the architecture described below is allowed to run, *what credentials each side has*, and *what data crosses the boundary*.

### 0.1 The Trust Boundary

The architecture in §3 is split by a trust boundary that runs **between the approval step (Approved Import Artifact) and the production ingestion step (Laravel Validation)**:

```
                OUTSIDE STUDYNEXUS PRODUCTION TRUST BOUNDARY
                            (External Acquisition Environment)

External Sources (JAMB, NUC, institution websites, ...)
    ↓
Immutable Raw Capture (PDFs, HTML snapshots, CSVs; content-hashed;
                     stored in acquisition-side object storage)
    ↓
Extraction & Normalization (PDF parser, spatie/crawler, CSV parser)
    ↓
Reconciliation (deterministic; LLM-assisted extraction allowed,
                but final reconciliation MUST be deterministic
                per §0.3 below)
    ↓
Diff / Classification (NEW / UPDATED / UNCHANGED / MISSING / CONFLICT / INVALID)
    ↓
Human Review (content admin approves the import artifact)
    ↓
Approved Import Artifact (signed JSON manifest:
                         batch_id, source, acquired_at, content_hash,
                         normalized_records[], reconciliation_diff[])
              │
              │ ════════ TRUST BOUNDARY ════════
              │ (the ONLY thing that crosses the boundary)
              ↓
                INSIDE STUDYNEXUS PRODUCTION TRUST BOUNDARY
                            (StudyNexus Laravel Application)

Approved Artifact Ingestion (laravel-side queue worker)
    ↓
Laravel Validation (domain rules, enum membership, monetary >= 0,
                    ISO country codes, admission-rule structure)
    ↓
Deterministic Identity Resolution (PostgreSQL ON CONFLICT keyed on
                                   external_identifiers INV-EI1 or
                                   domain-level natural keys per §11.1)
    ↓
Canonical Upsert (via domain Actions: CreateInstitution,
                  ImportInstitutionData, RecordAccreditation, ...)
    ↓
Domain Events (InstitutionEstablished, InformationSourceVerified, ...)
    ↓
Search Projections (UpdateSearchIndex listener → queued Scout job →
                    Typesense upsert)
```

### 0.2 Credential Boundary (HARD REQUIREMENT)

The external acquisition environment (the side that runs `spatie/crawler`, PDF parsers, and any agentic tooling such as OpenClaw or similar web-scraping agents) **MUST NOT receive StudyNexus production database credentials**. Concretely:

- The acquisition environment connects to StudyNexus ONLY via an authenticated ingestion API endpoint (typically an HTTPS endpoint protected by Laravel Sanctum or a signed-ingestion token). It does NOT have a PostgreSQL DSN, Redis URL, or any other production credential.
- The acquisition environment writes its raw captures to its OWN object storage (e.g., S3 bucket owned by the acquisition side). The StudyNexus production application reads approved artifacts from this bucket via a read-only role, OR the acquisition side pushes the approved artifact via the ingestion API.
- The StudyNexus production application does NOT perform autonomous internet-facing scraping as part of the canonical ingestion mechanism. The `InstitutionWebsiteCrawlJob` and `ScholarshipProviderCrawlJob` listed in §9 below run **in the acquisition environment**, not in the production Laravel app queue. If they happen to share a codebase for code-reuse reasons, they MUST be deployed as a separate worker with a separate `.env` that has no production DB credentials.

### 0.3 Reconciliation State vs Workflow State (Concept Distinction)

The audit prompt explicitly distinguishes reconciliation state from workflow state. V4.6 adopts both:

**Reconciliation state (deterministic; emitted by the reconciliation engine for each normalized record vs the prior snapshot):**

| State | Meaning | Canonical action |
|-------|---------|------------------|
| `NEW` | Record did not exist in prior snapshot; this is a new entity | Insert via domain Action |
| `UPDATED` | Record existed and one or more canonical fields changed | Update via domain Action (subject to admin approval if material) |
| `UNCHANGED` | Record existed and no canonical field changed | No action |
| `MISSING` | Record existed in prior snapshot but is absent from the new acquisition run | **DO NOT auto-delete or auto-unpublish.** Flag for human review. Source may be temporarily unavailable; canonical data must not be destroyed without an explicit business rule (see §0.4). |
| `CONFLICT` | Two sources disagree on the same canonical field | Apply `information_sources.priority` weighting (per §6.2); if priorities equal, escalate to human review |
| `INVALID` | Record failed schema validation | Reject; record in `import_batches.error_log` |

**Workflow state (tracks the import batch's progress through the pipeline):**

| State | Meaning |
|-------|---------|
| `pending` | Batch created, not yet parsed |
| `parsing` / `parsed` / `verifying` / `verified` / `applying` / `completed` / `failed` | As described in §4.1 below |
| `rejected` | A specific pending_import failed verification (per-record) |

These two state machines are NOT the same concept. A record can be in workflow state `verified` and reconciliation state `UNCHANGED` (in which case no canonical change is required). Conflating them was a V2-era ambiguity; V4.6 separates them explicitly.

### 0.4 MISSING ≠ DELETE (HARD REQUIREMENT)

A source can fail, disappear, change structure, or become temporarily inaccessible. **A `MISSING` reconciliation result MUST NOT automatically trigger a `DELETE` or `UNPUBLISH` of the corresponding canonical record.** Any destructive canonical action requires:

1. An explicit business rule (e.g., "if NUC officially deprecates an accreditation, mark the AccreditationRecord as Expired").
2. Verification that the source's absence is intentional, not transient (e.g., the source is marked `SourceReliability::Deprecated` rather than just temporarily unreachable).
3. Admin approval via the PendingRevision workflow (canonical/05-implementation.md §4.5) for any canonical deletion or unpublication.

The `StaleDataDetectionJob` (§9) only FLAGS entities for human review; it does not delete or unpublish them.

### 0.5 Read-Only Production Snapshot for Reconciliation

If the acquisition environment's reconciliation step needs to know the current StudyNexus canonical state (e.g., to compute the diff between the new acquisition run and the current canonical data), it should use an appropriate **read-only production snapshot** or exported dataset — NOT a live read/write connection to the production database.

The snapshot can be produced by:

- A nightly logical export (pg_dump of the relevant tables) written to a read-only replica or to object storage in a format the acquisition environment can consume.
- A `pg_basebackup`-based read replica if real-time reconciliation is needed (rare for V1; nightly is sufficient for JAMB/NUC cadences).
- A materialized view exported as JSONL.

The acquisition environment reads this snapshot to compute diffs. It does not have credentials to the live production database.

### 0.6 Pending Imports vs Pending Revisions (Concept Distinction)

These are distinct concepts and MUST NOT be conflated:

- **`pending_imports`** (table, §4.2 below) — External approved import intake. Records that have crossed the trust boundary as part of an Approved Import Artifact and are pending the *application* step (canonical write). Staging-only; ephemeral; eventually applied or rejected.
- **`pending_revisions`** (table, canonical/05-implementation.md §4.5) — Canonical-domain revision workflow. Records proposed changes to *already-canonical* entities (typically from institution reps via the Organization Portal) that require admin approval before being applied.

A pending_import becomes a pending_revision only when: (a) the import has been applied to canonical, AND (b) the application triggered a downstream revision workflow that requires separate admin approval (rare for V1). The two tables are NOT a single concept.

---

## 1. Design Principles

1. **Source of truth is the domain model.** Ingestion writes to domain aggregates through their public API (Actions, domain methods). Never bypass aggregate invariants by writing directly to tables.
2. **Ingestion does not modify canonical data without verification.** Every imported record enters a staging workflow. Only verified records update the canonical store.
3. **The system does not depend on active data feeds from agencies.** Per OQ2-5, information is primarily aggregated from public and official sources. Direct feeds are future enhancements.
4. **Idempotency is mandatory.** Re-running the same import must produce the same result. No duplicate entities, no double-counting, no side effects on re-import. The persistence mechanism for idempotency is PostgreSQL ON CONFLICT DO UPDATE (upsert). For canonical entities that have external identifiers (Institutions, Programmes, Campuses), the upsert is keyed deterministically on the external_identifiers table's unique composite index (authority_id, identifier_type, identifier) WHERE status = 'active' (INV-EI1). When an import record's external identifier matches an existing active external_identifier, the corresponding canonical entity is updated; when no match exists, a new canonical entity is inserted. For child records without external identifiers (cut_off_marks, admission_policies, accreditation_records), the upsert is keyed on their natural domain-level unique constraints (see §11.1). This ensures deterministic identity resolution without race conditions across all imported tables.
5. **Provenance follows the 80/20 model.** Entity-level provenance JSONB provides lightweight whole-entity source metadata. Field-level provenance (field_provenance table) is recorded selectively: Category A fields (5 fields: name, type, status, accreditation_status, cut_off_mark) always get provenance; Category B fields (6 fields: founded_year, location, website, admission_requirements, application_deadline, amount) get provenance only on conflict; Category C fields (all others) have no field-level provenance. This 80/20 model focuses effort on the fields that matter most.

---

## 2. Source Taxonomy

| Source Type | Examples | Access Method | Trust Level | Priority |
|-------------|----------|---------------|-------------|----------|
| **Official Registry** | JAMB, WAEC, NECO, NABTEB, NBTE, NUC | Public website, PDF reports, occasional API | High (Official) | P0 -- day one |
| **Institution Website** | University of Lagos, UNIBEN, OAU, etc. | Web scraping (with rate limiting and respect for robots.txt) | Medium (Unverified -> Verified after check) | P0 -- day one |
| **Accreditation Body** | NUC, NBTE, NCCE | Published accreditation lists | High (Official) | P0 -- day one |
| **Government Open Data** | FME, State MOE, UBEC | PDF, CSV, occasional portal | Medium-High (Official, may be stale) | P1 -- post-MVP |
| **Scholarship Provider** | PTDF, Shell, MTN Foundation, State governments | Provider websites, press releases | Medium (Unverified initially) | P1 -- post-MVP |
| **Community Contribution** | User reports, corrections | User submission via reporting workflow (OQ4-2) | Low (Community-Contributed) | P2 -- when user accounts exist |
| **Data Partner (future)** | Direct API from institutions/agencies | Authenticated API, SFTP, webhook | High (Verified) | P3 -- when partnerships exist |

---

## 3. Architecture Overview

> **V4.6 trust-boundary architecture.** This section is the authoritative architecture diagram. It supersedes any earlier continuous-pipeline diagram previously shown here. The trust boundary between external acquisition and StudyNexus production is hard: scraping and acquisition workers do NOT receive StudyNexus production database credentials. See §0 for the normative amendment text and §0.2 for the credential boundary.

```
╔═══════════════════════════════════════════════════════════════════════╗
║              OUTSIDE STUDYNEXUS PRODUCTION TRUST BOUNDARY             ║
║              (External Acquisition Environment)                       ║
║                                                                       ║
║  External Sources                                                     ║
║    JAMB  WAEC  NUC  Institution Sites  Scholarship Sites  ...        ║
║       │                                                               ║
║       v                                                               ║
║  Acquisition / scraping workers                                       ║
║    (PDF Parser, Web Scraper, CSV/JSON Parser)                         ║
║    deployed as a SEPARATE worker with a SEPARATE .env                 ║
║    that has NO production DB credentials                               ║
║       │                                                               ║
║       v                                                               ║
║  Immutable Raw Capture                                                ║
║    (PDFs, HTML snapshots, CSVs; content-hashed;                        ║
║     stored in acquisition-side object storage)                        ║
║       │                                                               ║
║       v                                                               ║
║  Normalization                                                        ║
║    (source-agnostic DTOs; same codebase as production is OK,          ║
║     but separate deployment and separate credentials)                ║
║       │                                                               ║
║       v                                                               ║
║  Deterministic Reconciliation                                         ║
║    (NEW / UPDATED / UNCHANGED / MISSING / CONFLICT / INVALID;         ║
║     LLM-assisted extraction allowed but final reconciliation          ║
║     MUST be deterministic per §0.3)                                   ║
║       │                                                               ║
║       v                                                               ║
║  Human Review                                                         ║
║    (content admin approves the import artifact)                       ║
║       │                                                               ║
║       v                                                               ║
║  Approved Import Artifact                                             ║
║    (signed JSON manifest: batch_id, source, acquired_at,              ║
║     content_hash, normalized_records[], reconciliation_diff[])        ║
╚═══════════════════════════════════════════════════════════════════════╝
                                │
                                │  The Approved Import Artifact is the
                                │  ONLY thing that crosses the boundary.
                                │  It crosses via an authenticated
                                │  ingestion API endpoint (Laravel
                                │  Sanctum or signed-ingestion token).
                                │
═════════════════════════════════════════════════════════════════════════
                         TRUST BOUNDARY
═════════════════════════════════════════════════════════════════════════
                                │
                                v
╔═══════════════════════════════════════════════════════════════════════╗
║              INSIDE STUDYNEXUS PRODUCTION TRUST BOUNDARY              ║
║              (StudyNexus Laravel Application)                         ║
║                                                                       ║
║  Approved Artifact Ingestion                                          ║
║    (laravel-side queue worker; reads artifact from ingestion API)     ║
║       │                                                               ║
║       v                                                               ║
║  Laravel Validation                                                   ║
║    (domain rules, enum membership, monetary >= 0,                     ║
║     ISO country codes, admission-rule structure)                      ║
║       │                                                               ║
║       v                                                               ║
║  Deterministic Identity Resolution                                     ║
║    (PostgreSQL ON CONFLICT keyed on external_identifiers              ║
║     INV-EI1 or domain-level natural keys per §11.1)                   ║
║       │                                                               ║
║       v                                                               ║
║  Canonical Upsert                                                     ║
║    (via domain Actions: CreateInstitution,                            ║
║     ImportInstitutionData, RecordAccreditation,                       ║
║     RegisterInformationSource, VerifyInformationSource)                ║
║       │                                                               ║
║       v                                                               ║
║  Domain Events                                                        ║
║    (InstitutionEstablished, InstitutionAccredited,                    ║
║     InformationSourceVerified, ...)                                   ║
║       │                                                               ║
║       v                                                               ║
║  Search Projections                                                   ║
║    (UpdateSearchIndex listener → queued Scout job →                   ║
║     Typesense upsert)                                                 ║
╚═══════════════════════════════════════════════════════════════════════╝
```

**Key invariants of this architecture:**

1. **Two environments, one codebase is allowed.** The acquisition worker and the StudyNexus Laravel app MAY share a codebase for code-reuse reasons. They MUST be deployed as separate workers with separate `.env` files. The acquisition worker's `.env` MUST NOT contain the production PostgreSQL DSN, Redis URL, or any other production credential. See §14 (Code-Sharing Does Not Equal Trust-Sharing).

2. **The only thing that crosses the trust boundary is the Approved Import Artifact.** It crosses via an authenticated ingestion API endpoint on the production app (Laravel Sanctum or signed-ingestion token). The acquisition worker does NOT have direct write access to the production database.

3. **If the acquisition environment needs to compute reconciliation diffs against current canonical state, it reads from a read-only production snapshot** (nightly `pg_dump` or `pg_basebackup`-based read replica), NOT from a live read/write connection to the production database. See §0.5.

4. **The `InstitutionWebsiteCrawlJob` and `ScholarshipProviderCrawlJob` listed in §9 below run in the acquisition environment, NOT in the production Laravel app queue.** If they share a codebase with the production app, they MUST be deployed with a separate `.env` that has no production DB credentials.

5. **`spatie/crawler`, `smalot/pdfparser`, and `maatwebsite/excel` are acquisition-environment packages.** They are listed in §10 (Required Packages) because the codebase includes them, but they execute in the acquisition worker, not in the production app's request path.

The previous continuous-pipeline diagram (External Sources → Adapter Layer → Staging Layer → Domain Layer, with no visible trust boundary) is **obsolete**. A developer reading this document top-to-bottom MUST encounter this trust-boundary architecture in §3 and MUST NOT find any later section that visually or conceptually reintroduces a "scraper → production DB" data flow.

---

## 4. Staging Schema

### 4.1 `import_batches`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Batch identity |
| `source_type` | string | Source taxonomy entry (e.g., "jamb_official", "institution_website") |
| `source_url` | string, nullable | URL or file path of the source |
| `adapter_class` | string | Fully qualified adapter class name |
| `status` | enum | `pending`, `parsing`, `parsed`, `verifying`, `verified`, `applying`, `completed`, `failed` |
| `total_records` | int | Records found in source |
| `verified_records` | int | Records that passed verification |
| `rejected_records` | int | Records that failed verification |
| `conflict_records` | int | Records that conflict with existing data |
| `applied_records` | int | Records successfully applied to domain |
| `started_at` | timestamp | When processing began |
| `completed_at` | timestamp, nullable | When processing completed |
| `error_log` | json, nullable | Structured error details |
| `metadata` | json | Source-specific metadata (scrape headers, PDF page count, etc.) |
| `created_by` | string | User or system process that initiated the import |
| `created_at` | timestamp | Partition key for monthly partitioning |

**Partitioning:** The `import_batches` table is partitioned by `created_at` using PostgreSQL range partitioning (monthly partitions). This allows instant dropping of old failed batches via `DROP TABLE import_batches_y2026m07` without VACUUM overhead. Each monthly partition is created automatically by a scheduled job (`CreateMonthlyPartitionJob`) that runs on the 1st of each month, creating the partition for the next month. Retention policy: partitions older than 6 months are dropped automatically unless they contain records with `status` in (`completed`, `failed`) that have not been archived. Partitions are named `import_batches_y{year}m{month:02d}`.

### 4.2 `pending_imports`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Record identity |
| `batch_id` | UUID (FK) | Parent batch |
| `entity_type` | string | Target domain entity (Institution, Programme, Scholarship, etc.) |
| `raw_data` | json | Raw data from source (before normalization) |
| `normalized_data` | json | Normalized, source-agnostic DTO |
| `verification_status` | enum | `pending`, `verified`, `rejected`, `conflict`, `duplicate` |
| `verification_notes` | json, nullable | Structured verification results |
| `matching_entity_id` | BIGINT, nullable | If matched to existing entity (for updates/duplicates) |
| `match_confidence` | float, nullable | Fuzzy match confidence score (0.0-1.0) |
| `applied_at` | timestamp, nullable | When record was applied to domain |
| `provenance` | json | Source, acquired_at, trust_level, verification_history |
| `created_at` | timestamp | Partition key for monthly partitioning |

**Partitioning:** The `pending_imports` table is partitioned by `created_at` using PostgreSQL range partitioning (monthly partitions), following the same pattern as `import_batches`. Since `pending_imports` are ephemeral (resolved records are either applied to the domain or rejected), retention is shorter: partitions older than 3 months are dropped automatically. Partitions are named `pending_imports_y{year}m{month:02d}`.

---

## 5. Adapter Pattern

Each source type gets a dedicated adapter that implements a common interface:

```php
interface SourceAdapter
{
    /**
     * Fetch raw data from the external source.
     */
    public function fetch(SourceConfiguration $config): RawSourceData;

    /**
     * Normalize raw data into source-agnostic DTOs.
     */
    public function normalize(RawSourceData $raw): Collection; // Collection<NormalizedInstitutionDTO>

    /**
     * Validate a normalized record against domain rules.
     */
    public function validate(NormalizedDTO $dto): ValidationResult;
}
```

### Adapter Implementations

| Adapter | Source | Fetch Method | Key Challenges |
|---------|--------|-------------|----------------|
| `JambOfficialAdapter` | JAMB brochure/site | PDF download + parse | PDF structure varies by year; programme names differ from institutional names |
| `NucAccreditationAdapter` | NUC accreditation list | PDF/HTML parse | Accreditation status is time-bounded; must match to existing institutions |
| `InstitutionWebsiteAdapter` | Individual institution sites | Web scrape (spatie/crawler) | No standard schema; rate limiting; robots.txt compliance; structure changes |
| `ScholarshipProviderAdapter` | Provider websites | Web scrape | Press releases are unstructured; deadlines change frequently |
| `WaecResultAdapter` | WAEC official data | PDF/CSV parse | Subject code mapping; qualification equivalence |
| `CsvBulkImportAdapter` | Any CSV source | File upload + maatwebsite/excel | Column mapping; encoding; delimiter detection |

---

## 6. Verification Engine

### 6.1 Duplicate Detection

When a normalized record matches an existing entity:

| Match Confidence | Action |
|:---------------:|--------|
| >= 0.95 | **Auto-merge**: Update existing entity with new data (fields that changed only) |
| 0.80-0.94 | **Flag for review**: Present both records to a content admin for manual merge decision |
| 0.50-0.79 | **Likely different**: Create as new entity, but flag for spot-check |
| < 0.50 | **Distinct**: Create as new entity |

**Fuzzy matching strategy** (for institutions):

**Fuzzy matching is restricted to the staging/review queue only.** Fuzzy matching (Levenshtein/TF-IDF similarity) is used exclusively during the verification phase to identify potential duplicates in pending_imports. It is NEVER used as the primary identity mechanism for applying verified records to canonical tables. Canonical identity is always resolved via deterministic external_identifier lookup (ON CONFLICT). Fuzzy matches below the auto-merge threshold (0.95) are flagged for human review before any canonical data is modified.
1. Exact match on JAMB code or NUC code (if available) -> confidence = 1.0
2. Normalized name similarity (Levenshtein/TF-IDF) + same state + same type -> confidence 0.80-0.95
3. Name similarity alone -> confidence 0.50-0.79

### 6.2 Cross-Source Consistency

When two sources disagree on the same fact:

| Scenario | Resolution |
|----------|-----------|
| Official source says X, unofficial says Y | **Official wins.** Record unofficial as `InformationSource(MarkedUnreliable)` if contradiction is material. |
| Two official sources disagree | **Priority-weighted resolution.** The source with the higher `information_sources.priority` value wins. If priorities are equal, flag as conflict and present to content admin. Both sources retain their provenance. |
| New data contradicts verified existing data | **Flag for review.** Do not overwrite verified data without explicit admin approval. |

**Source Authority Weighting:** The `information_sources.priority` integer column (default 0) provides deterministic conflict resolution. When the pipeline detects that two sources are updating the same field, the domain Action automatically defers to the source with the higher priority value. Only when priorities are equal does the conflict escalate to human review. Priority values are assigned by the content admin via Filament and reflect the authoritative weight of each source (e.g., NUC direct accreditation list = priority 100, JAMB brochure = priority 90, institution website = priority 50, community report = priority 10). This eliminates the "two official sources" ambiguity and reduces the volume of records requiring manual conflict resolution.

### 6.3 Schema Validation

Before a record enters the domain, validate it against the aggregate's invariants:
- Required fields present and non-empty
- Enum values are valid members of the target PHP enum
- Monetary amounts >= 0
- Dates are parseable and within reasonable ranges
- Location data has valid ISO 3166-1 country code (NG for Nigeria in MVP)
- Admission rule structure matches the expected rule type

---

## 7. Import Workflow

> **V4.6 trust-boundary clarification.** Each step in the workflow below is annotated with the environment in which it executes (ACQUISITION or PRODUCTION). The trust boundary is crossed exactly once — when the Approved Import Artifact moves from ACQUISITION to PRODUCTION via the ingestion API. No job in the ACQUISITION environment has production database credentials. No job in the PRODUCTION environment performs internet-facing scraping.

### 7.1 Automated Import (scheduled)

```
=== ACQUISITION ENVIRONMENT (separate worker, separate .env, no prod DB credentials) ===

1. Scheduler triggers ImportJob for a configured source
   [ENV: ACQUISITION]
2. ImportJob::handle()
   a. Create import_batches record (status: pending)         [ACQUISITION-side staging DB]
   b. Adapter::fetch() -- retrieve raw data                  [ACQUISITION; spatie/crawler, smalot/pdfparser]
   c. Update batch: status = parsing
   d. Adapter::normalize() -- convert to DTOs               [ACQUISITION]
   e. Write to pending_imports (status: pending)            [ACQUISITION-side staging DB]
   f. Update batch: status = parsed, total_records = count
3. VerificationJob::handle()                                [ACQUISITION]
   a. Update batch: status = verifying
   b. For each pending_import:
      - Duplicate detection (fuzzy; vs read-only prod snapshot, NOT vs live prod DB)
      - Cross-source consistency check
      - Schema validation
      - Set verification_status (verified/rejected/conflict/duplicate)
      - Compute reconciliation_diff (NEW/UPDATED/UNCHANGED/MISSING/CONFLICT/INVALID per §0.3)
   c. Update batch counters
4. Human Review                                              [ACQUISITION admin UI; OR production Filament
                                                             admin UI reads the batch via ingestion API
                                                             (read-only) and returns approval decision]
   a. Content admin reviews reconciliation_diff
   b. Approves or rejects each record
   c. If approved: produces Approved Import Artifact (signed JSON manifest)

=== TRUST BOUNDARY (crossed via authenticated ingestion API; signed token required) ===

5. Approved Artifact Ingestion                              [PRODUCTION queue worker]
   a. Ingestion API endpoint receives signed artifact
   b. Validates signature and token
   c. Enqueues ApplicationJob
6. ApplicationJob::handle()                                 [PRODUCTION]
   a. Update batch: status = applying
   b. For each verified record in the artifact:
      - Laravel Validation (domain rules, enum membership, monetary >= 0, ISO codes)
      - Dispatch domain Action (ImportInstitutionData, etc.)
      - Action invokes aggregate method -> emits domain event
      - Domain event -> UpdateSearchIndex listener -> queued Scout job -> Typesense upsert
   c. Update batch: status = completed, applied_records
```

### 7.2 Manual Import (admin-initiated)

Manual imports follow the same trust boundary. The admin uploads a CSV/PDF via the Filament admin panel (which lives in PRODUCTION); the uploaded file is handed to the ACQUISITION worker for parsing and normalization; the resulting Approved Import Artifact is ingested back into PRODUCTION via the ingestion API. The admin never directly writes to canonical tables — the same ApplicationJob / domain Action path is used as in automated imports.

1. Admin uploads a CSV/PDF via Filament admin panel             [PRODUCTION; file is staged to acquisition-side storage]
2. ACQUISITION worker picks up the file and runs the standard parse/normalize/verify pipeline   [ACQUISITION]
3. Admin reviews the batch in Filament: sees total records, can preview normalized data           [PRODUCTION admin UI reads via ingestion API]
4. Admin triggers verification -> same VerificationJob                                            [ACQUISITION]
5. Admin reviews flagged records (conflicts, low-confidence matches)                              [PRODUCTION admin UI]
6. Admin resolves conflicts manually (merge, reject, create new)                                  [PRODUCTION admin UI; produces approved artifact]
7. Admin approves and applies -> ApplicationJob runs in PRODUCTION via ingestion API              [PRODUCTION]

---

## 8. Provenance Model

Every entity in the canonical store carries entity-level provenance metadata (JSONB), and selective field-level provenance is recorded in the `field_provenance` table per the 80/20 model (ND-4/ADR-23):

```php
// On every domain entity (via HasProvenance trait) - entity-level JSONB:
[
    'provenance' => [
        'source_type'       => 'jamb_official',
        'source_url'        => 'https://jamb.gov.ng/2026-brochure.pdf',
        'acquired_at'       => '2026-08-08T10:00:00Z',
        'last_verified_at'  => '2026-08-08T10:00:00Z',
        'trust_level'       => InformationCategory::Official,  // Official, Verified, Historical, CommunityContributed
        'verification_status' => SourceReliability::Verified,
    ]
]
// NOTE: import_batch_id is NOT included in provenance JSONB — staging is ephemeral by design.
```

**Field-level provenance** (field_provenance table) is recorded selectively:
- **Category A (5 fields)**: Always provenance — name, type, status, accreditation_status, cut_off_mark
- **Category B (6 fields)**: Provenance on conflict — founded_year, location, website, admission_requirements, application_deadline, amount
- **Category C (all others)**: No field-level provenance

**Source field mapping:** `admission_requirements` is a source data field received from external systems (JAMB, institution websites). It is NOT a column on the `programmes` table. During import transformation, `admission_requirements` source data is mapped to `AdmissionPolicy` on `ProgrammeInstance` — the import pipeline creates/updates AdmissionPolicy records with the appropriate AdmissionRules derived from the source admission_requirements data. The mapping is: source.admission_requirements → ProgrammeInstance.AdmissionPolicy.admission_rules (JSONB).

**External identifiers** (external_identifiers table per BD-5/ADR-21) store authority-assigned codes (JAMB codes, NUC codes, etc.) generically — no per-entity code columns on canonical entities.

**Provenance is immutable once recorded.** If a field is updated from a different source, the old provenance is archived (not overwritten) and the new source is recorded. This provides a full audit trail of where every data point originated. Entity-level provenance JSONB does NOT include import_batch_id (staging is ephemeral by design). Field-level provenance (field_provenance) uses superseded_at/superseded_by_id for archival — no is_active column; derive active from superseded_at IS NULL. verification_status enum (not is_verified boolean). No value_hash. No primary_source_id on entities.

---

## 9. Scheduling & Operations

> **V4.6 trust-boundary clarification.** Each job is annotated with the environment in which it executes. Acquisition-environment jobs have NO production DB credentials. Production-environment jobs have NO internet-facing scraping capability.

| Job | Schedule | Source | Queue | Environment |
|-----|----------|--------|-------|------------|
| `JambBrochureImportJob` | Monthly (or on-demand when new brochure detected) | JAMB | `imports` | **ACQUISITION** (downloads PDFs from jamb.gov.ng; runs in acquisition worker with separate .env) |
| `NucAccreditationImportJob` | Quarterly (accreditation updates are periodic) | NUC | `imports` | **ACQUISITION** (downloads PDFs from nuc.edu.ng; runs in acquisition worker) |
| `InstitutionWebsiteCrawlJob` | Weekly (detect changes to programme listings) | Institution sites | `imports` (rate-limited) | **ACQUISITION** (spatie/crawler; runs in acquisition worker with NO production DB credentials) |
| `ScholarshipProviderCrawlJob` | Weekly (detect new/changed scholarships) | Provider sites | `imports` (rate-limited) | **ACQUISITION** (spatie/crawler; runs in acquisition worker with NO production DB credentials) |
| `ApprovedArtifactIngestionJob` | On-demand (triggered by ingestion API) | Internal | `imports` | **PRODUCTION** (Laravel-side queue worker; receives signed Approved Import Artifacts via ingestion API) |
| `StaleDataDetectionJob` | Daily (flag entities not updated within threshold) | Internal | `maintenance` | **PRODUCTION** (flags entities for human review; does NOT delete or unpublish per §0.4) |
| `SearchIndexRebuildJob` | After each successful batch | Internal | `search` | **PRODUCTION** (Scout job; writes to Typesense collection) |
| `CreateMonthlyPartitionJob` | Monthly (1st of month, creates next month's partitions) | Internal | `maintenance` | **PRODUCTION** (manages import_batches / pending_imports partitions in production DB) |
| `DropExpiredPartitionsJob` | Monthly (1st of month, drops partitions past retention) | Internal | `maintenance` | **PRODUCTION** (drops old partitions per retention policy) |
| `ProductionSnapshotExportJob` | Nightly (1am) | Internal | `maintenance` | **PRODUCTION** (pg_dump of relevant tables; writes to read-only snapshot consumed by acquisition worker for reconciliation) |

**Rate limiting:** All web-scraping jobs (ACQUISITION environment) respect per-domain rate limits (configurable, default: 1 request/second per domain). Uses `spatie/laravel-rate-limited-job-middleware` for queue job rate limiting and Laravel's `RateLimiter` facade for HTTP-level throttling. Respects `robots.txt`. Production-environment jobs do NOT perform any internet-facing HTTP requests.

**Failure handling:** If a source becomes unavailable or returns unexpected data, the batch fails gracefully. The error is logged in `import_batches.error_log` (in the ACQUISITION-side staging DB; mirrored to production via the Approved Import Artifact's error summary if the batch is partially applied). No partial data is applied to canonical tables -- a batch is atomic from the production side: either all verified records in the Approved Import Artifact are applied, or none are (with manual override available for partial application after admin review).

---

## 10. Required Packages

> **V4.6 trust-boundary clarification.** Packages marked **ACQUISITION** are required only by the acquisition worker (separate deployment, separate .env, no production DB credentials). Packages marked **PRODUCTION** are required by the StudyNexus Laravel application. Packages marked **BOTH** are required by both deployments and may share code for code-reuse reasons.

| Package | Version | Purpose | Environment |
|---------|---------|---------|:-----------:|
| `spatie/crawler` | ^1.0 | Web scraping with rate limiting and robots.txt support | **ACQUISITION** |
| `smalot/pdfparser` | ^2.0 | PDF parsing for official brochures/lists | **ACQUISITION** |
| `maatwebsite/excel` | ^3.1 | CSV/Excel import for bulk data | **ACQUISITION** (parsing source CSVs) + **PRODUCTION** (admin-uploaded CSVs) |
| `laravel/scout` | ^4.0 | Search index management after imports | **PRODUCTION** |
| `spatie/laravel-activitylog` | ^5.0 | Backend audit trail for all import operations | **PRODUCTION** |
| `pxlrbt/filament-activity-log` | ^2.0 | Filament v5 UI integration for activity log display | **PRODUCTION** |
| `spatie/laravel-rate-limited-job-middleware` | ^1.0 | Queue job rate limiting for crawl jobs | **ACQUISITION** |
| `laravel/sanctum` | ^4.0 | Ingestion API authentication (signed-token ingestion endpoint) | **PRODUCTION** |

**No fabricated packages.** All new additions are verified real packages from established vendors (Spatie, Smalot, pxlrbt). The `spatie/laravel-activitylog` version is pinned to ^5.0 for Laravel 13 compatibility. The `pxlrbt/filament-activity-log` package provides the Filament v5 admin panel integration for viewing activity log entries generated by the Spatie backend. `laravel/sanctum` is added for the V4.6 ingestion API endpoint that receives Approved Import Artifacts from the acquisition worker.

---

## 11. Admin UI (Filament v5)

| Resource | Purpose |
|----------|---------|
| `ImportBatchResource` | View all import batches, status, counts, error logs. Trigger re-runs. |
| `PendingImportResource` | View/resolve individual pending records. Manual merge/reject/approve. |
| `InformationSourceResource` | Manage source registry (add/edit/disable sources, configure adapters). |

**Authorization:** Import authorization is handled by the two-layer RBAC model (see canonical/05-implementation.md §5): Platform-level admins (via Spatie `spatie/laravel-permission` roles) can authorize global imports (e.g., JAMB, NUC). Only `platform-admin` and `content-admin` Spatie roles can initiate imports. `content-editor` can view batches and resolve conflicts but not apply changes. Institution-scoped imports (e.g., institution website crawls for a specific institution) are authorized via the `organization_members` pivot table string `role` column — only `owner` and `admin` roles can request an import crawl for their institution (matching the bare role strings stored in the `organization_members.role` column per 05-implementation.md §5.4). Institution-scoped users cannot modify or approve platform-level imports. RBAC is enforced via `bezhansalleh/filament-shield` with the 11-role model.

### 11.1 Non-External-ID Idempotent Upsert Keys

While canonical entity resolution (Institutions, Programmes, Campuses) uses `external_identifiers` (INV-EI1), child records without external IDs utilize their natural domain-level unique constraints for idempotent upserting. The JAMB and NUC import adapters write to these tables and must use the following ON CONFLICT targets:

| Table | ON CONFLICT Target (Unique Composite Index) | Rationale |
|-------|---------------------------------------------|-----------|
| `cut_off_marks` | `(programme_instance_id, admission_cycle_id, pathway)` | A cut-off mark is uniquely identified by which instance, which cycle, and which pathway. Re-importing JAMB cut-offs for the same instance/cycle/pathway must update the existing record, not create a duplicate. Column names align with the physical schema in 05-implementation.md §4.3. |
| `admission_policies` | `(governable_type, governable_id, admission_cycle_id)` | An admission policy is uniquely identified by its governing entity (ProgrammeInstance or Institution) and cycle. A polymorphic composite key ensures one policy per governable per cycle. Re-importing admission data for the same governable/cycle must update, not duplicate. |
| `accreditation_records` | `(accreditable_type, accreditable_id, authority_id)` | An accreditation record is uniquely identified by its polymorphic parent (Programme or Institution) and the accrediting authority. The table uses a polymorphic structure (`accreditable_type`, `accreditable_id`) rather than a direct `programme_id` FK. Re-importing NUC accreditation for the same accreditable/authority must update the existing record (e.g., extending validity or changing status), not create a duplicate. Column names align with the physical schema in 05-implementation.md §4.3. |

These unique composite indexes must be defined in the corresponding migrations and are the ON CONFLICT targets for all upsert operations on these tables.

---

## 12. Integration with Existing Domain Architecture

This pipeline integrates with the existing domain through the **already-defined Actions**. All Actions listed below execute in the PRODUCTION environment (inside the StudyNexus Laravel application). The acquisition environment does NOT call these Actions directly; it produces Approved Import Artifacts that the production-side ApplicationJob consumes.

| Pipeline Step (PRODUCTION) | Domain Action Invoked | Aggregate Method |
|---------------|----------------------|-----------------|
| New institution from import | `CreateInstitution` | `Institution::establish()` |
| Accreditation from import | `RecordAccreditation` | `Institution::recordAccreditation()` or `Programme::recordAccreditation()` |
| New programme from import | `CreateProgramme` | `Programme::introduce()` |
| Source verification | `VerifyInformationSource` | `InformationSource::verify()` |
| Source flagged unreliable | `MarkSourceUnreliable` | `InformationSource::markUnreliable()` |
| Batch data import | `ImportInstitutionData` | Orchestrates multiple creates/updates |

**No new domain Actions are introduced.** The ingestion pipeline is an application-layer orchestration that feeds data through the existing domain API. The acquisition environment's role is purely to produce Approved Import Artifacts; canonical persistence happens exclusively in PRODUCTION via these existing Actions.

---

## 13. Ingestion API Endpoint (V4.6)

The PRODUCTION application exposes a single authenticated ingestion API endpoint that receives Approved Import Artifacts from the acquisition worker. This is the only legitimate crossing point of the trust boundary.

**Endpoint:** `POST /api/imports/ingest` (authenticated)

**Authentication:** Laravel Sanctum token with `import:ingest` scope. The token is issued to a dedicated service account representing the acquisition worker. The acquisition worker's `.env` contains ONLY this token; it does NOT contain production DB credentials.

**Request body:** The signed Approved Import Artifact JSON manifest:

```json
{
  "batch_id": "uuid",
  "source": {
    "type": "jamb_official",
    "url": "https://jamb.gov.ng/2026-brochure.pdf",
    "acquired_at": "2026-08-19T10:00:00Z"
  },
  "content_hash": "sha256-of-raw-capture",
  "normalized_records": [
    { "entity_type": "Institution", "normalized_data": { ... }, "reconciliation_state": "NEW" },
    { "entity_type": "Programme", "normalized_data": { ... }, "reconciliation_state": "UPDATED" }
  ],
  "reconciliation_diff": { ... },
  "approved_by": "admin-user-id",
  "approved_at": "2026-08-19T11:00:00Z",
  "signature": "hmac-sha256-of-above-fields"
}
```

**Server-side processing:**
1. Verify HMAC signature using shared secret.
2. Verify Sanctum token scope.
3. Enqueue `ApprovedArtifactIngestionJob` on the `imports` queue.
4. Return 202 Accepted with the batch_id.
5. The `ApprovedArtifactIngestionJob` runs `ApplicationJob::handle()` as described in §7.1.

**Rate limiting:** 1 request per second per source IP. Sanity cap: 1000 records per artifact. Larger imports must be split into multiple artifacts.

**Failure modes:**
- Invalid signature → 401 Unauthorized; acquisition worker must re-sign.
- Invalid token → 403 Forbidden; acquisition worker's `.env` must be updated.
- Validation failure of individual records → records are rejected with structured error in the response; other records in the same artifact are still applied (atomicity is per-record, not per-artifact, unless a transaction is explicitly requested).

---

## 14. Code-Sharing Does Not Equal Trust-Sharing

**Critical principle.** The acquisition worker and the StudyNexus Laravel production application MAY share a codebase for code-reuse reasons. They MAY share Eloquent models, domain Actions, Value Object classes, and adapter interfaces. But code-sharing does NOT imply:

```text
same codebase
    ≠
same deployment
    ≠
same credentials
    ≠
same trust boundary
```

Concretely:

1. **Same codebase is allowed.** The acquisition worker MAY import the same `App\Domain\*` and `App\Actions\*` classes as the production app. This is preferable to maintaining a parallel set of model classes.
2. **Different deployment is required.** The acquisition worker runs as a separate queue worker process (`php artisan queue:work --queue=imports`), with a separate `.env` file that contains ONLY:
   - The ingestion API token (for pushing Approved Import Artifacts to production).
   - The acquisition-side staging database DSN (separate from production DB).
   - The acquisition-side object storage credentials (for raw captures).
   - HTTP/HTTPS egress for scraping (jamb.gov.ng, nuc.edu.ng, institution sites).
3. **Different credentials are required.** The acquisition worker's `.env` MUST NOT contain:
   - The production PostgreSQL DSN.
   - The production Redis URL.
   - Any production service credentials (Typesense API key, mailgun key, etc.).
   - Any Laravel Sanctum admin token (only the limited `import:ingest` scope token).
4. **Different trust boundary.** The acquisition worker is treated as untrusted from the production perspective. It can only push Approved Import Artifacts via the ingestion API; it cannot read from or write to production tables directly.

This principle is restated here because it is easy for a developer to assume that shared code implies shared trust. It does not. The trust boundary is enforced by deployment configuration and credential scoping, not by code organization.

---

*This document resolves audit finding S17.3. The data-acquisition pipeline is now architected to the same depth as the domain core and search/SEO layers. The V4.6 trust-boundary amendment (§0) and the §3 architecture diagram are the authoritative architecture; §7, §9, §10, §12, §13, and §14 are consistent with it.*
