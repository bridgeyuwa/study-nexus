# StudyNexus — Pre-Implementation Baseline v2 Manifest

**Date:** 2026-08-19
**Version:** 4.4
**Status:** V4.4 FINAL — Two-layer RBAC import authorization aligned, non-external-ID idempotent upsert keys defined (cut_off_marks, admission_policies, accreditation_records), all V4.3 + conditional-GO second-pass findings resolved, 57 markdown files, unconditional GO

---

## File Inventory

| # | Path | SHA-256 | Size (bytes) | Category |
|---|------|---------|-------------|----------|
| 1 | `00-ORIENTATION/AUTHORITY-HIERARCHY.md` | `39b65737044882254a46fca3d919e2d5c4d850f1281220fe98e396709becf58e` | 6402 | Orientation |
| 2 | `GLOSSARY.md` | `b6ebaf6e6501965ab219d2f3ceb3de7d3d51c9ebb6b0e1454b02e1226d54e680` | 11779 | Baseline |
| 3 | `MANIFEST.md` | `a4fc38be2589ab2aee1d9cdefab1d6182186ff3cef82f46018e4a3c09be4d70d` | 9707 | Baseline |
| 4 | `PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md` | `2153a8aa834de3cc41e0fd645a23130470617ff0cee9472dd8ea59960c220c2c` | 8615 | Baseline |
| 5 | `README.md` | `6453a7dbeb042318228381acbec6b124d92844350585c418180b2f9c3985a7f6` | 9244 | Baseline |
| 6 | `V4.2-REMEDIATION-REPORT.md` | `303d3f8bfe0b64feac23566100ba0c4ec029963042f23c06c6808fdd71ba88a1` | 16160 | Baseline |
| 7 | `archive/00-documentation-audit-report.md` | `5de4bd505d046ac30d4344cf9d99b8249c1f0debd8047e3d4659526bf0a4a21e` | 39641 | Historical |
| 8 | `archive/00-reconciliation-proposal.md` | `d3945637546b8b69a4e11e8623719ff34c8314dce3f9cc9605603d3aa675eae3` | 30005 | Historical |
| 9 | `archive/01-business-overview.md` | `70a5bd289c8b2945350cc3dfe27a6f727db770e84a5f60740f529db457c5fde4` | 12843 | Historical |
| 10 | `archive/02-glossary.md` | `a64bc423478e4c75cc5459bd69f0961c61f6c9d0155a163db003f1e9178b20bc` | 8538 | Historical |
| 11 | `archive/03-approved-decisions.md` | `2cea05b2ef3eca41cd7ea37c6b5f9a3246d462eab178a2a4b385ea30335ee620` | 16118 | Historical |
| 12 | `archive/04-open-questions.md` | `11962f984e517c02f753b9b25030e2c1257e98d4169f4be2d5790903792055f4` | 7981 | Historical |
| 13 | `archive/06-business-workflows.md` | `717c602d5b612f3193ab87f473b026b69872a298f7294d71cf1d3f4ddea57f3d` | 20707 | Historical |
| 14 | `archive/07-business-discovery-closure.md` | `6ed21ab4b355541e3a5c8a4cd860a7b06b8f438ea6ea7a162bd4d7f841b64129` | 11123 | Historical |
| 15 | `archive/08-traceability-matrix.md` | `fbbb93de3459a14257b4a82286e6f71d5c42a2f50765e6da0a4d594e795d5530` | 12765 | Historical |
| 16 | `archive/09-business-discovery-freeze.md` | `c1dfad3462d93eaf6070bc556eb819183316c2fa44e110ad57f9c0a1fdfc428c` | 4487 | Historical |
| 17 | `archive/11-domain-discovery-topic2.md` | `b30bcbe451451ab34c823d5257b0050b5dd9917acd788264577a2023766aa0dd` | 92266 | Historical |
| 18 | `archive/12-domain-discovery-topic2-revision.md` | `0ed1e8597ec733b16ca8f0951550125cac027815fda817bf2671b8e3626ac3c3` | 62702 | Historical |
| 19 | `archive/13-domain-discovery-consolidation.md` | `82d25a326e4676a9e83c11279c28c2bfe916eb56e3d605e4df2590b340be4f07` | 75673 | Historical |
| 20 | `archive/14-architectural-review-global-domain.md` | `15eebf8a7845c74a562e971baffc4ca07f66207b0eb75555deb14dc13a1b2279` | 34976 | Historical |
| 21 | `archive/15-domain-discovery-topic4-behaviour.md` | `8be2133dd4302515abd32ae97d4264deda9ae5577a7caf66dd89bc9125ab29cc` | 139882 | Historical |
| 22 | `archive/16-domain-discovery-topic3.md` | `f6ce0caa6457b3b573ea7ef4f245c563eac474958ad2c37dca96d2dcf6d76608` | 98591 | Historical |
| 23 | `archive/17-domain-integrity-review.md` | `208a4a7610ee77bd3ea92175ca7781200b2ca5122b0dcdd95e6e197a5445ba46` | 56794 | Historical |
| 24 | `archive/18-domain-resolution-analysis.md` | `8e9a38de60815f397e77a4631f3d845042dd186e5b018280fb8451dd6b0bab0c` | 67941 | Historical |
| 25 | `archive/19-domain-architecture.md` | `0d9e019903321b227c8d399c14a8aa926e7f78c90361653145dc9a25afd4561b` | 114709 | Historical |
| 26 | `archive/20-domain-architecture-validation.md` | `333f179e116447071bec460a6704ed5576d8e6238060b4fec5f91310df8b66be` | 95160 | Historical |
| 27 | `archive/21-domain-architecture-frozen-baseline.md` | `5714e0c76d2cc9c87b61af4eea0a267ffbaf815376332f9b84d5e1c97de1ba9c` | 108803 | Historical |
| 28 | `archive/22-post-freeze-platform-architecture-review.md` | `886716950b7b3ba5a9dfcef3fedcfb467eb66b1c3860b80323d43b856f308da3` | 79823 | Historical |
| 29 | `archive/23-laravel-ecosystem-build-vs-buy-review.md` | `c09fa4f087aca72d3921e8525450afef3d9edd9c719fd211c77268743be52c29` | 116374 | Historical |
| 30 | `archive/24-final-platform-and-capability-architecture.md` | `217973d4b8416b598b5f2bcca737799bed40d08d73756fabbc524549ad91b9fa` | 117115 | Historical |
| 31 | `archive/26-pre-implementation-reconciliation.md` | `fd8691af9a925206dd726cbf32983d1873304fe2f9a387ab51c558a6b0d711ad` | 57858 | Historical |
| 32 | `archive/27-final-corrected-pre-implementation-blueprint.md` | `c9a0bdaf8cc2c3e8fd18ee1440e025737e821477605e34cb57f68d57cf55a8b9` | 85973 | Historical |
| 33 | `archive/28-package-verification-audit.md` | `bcd2c53ee3004be3d6f16e80bbe72d442122502d69526a63cdc7f780cd3ebbac` | 57038 | Historical |
| 34 | `archive/29-rbac-decision.md` | `992b84c7d063f6b4a9d7db3209d98030705a650c76ad81397f1cd23e391910f7` | 4203 | Historical |
| 35 | `archive/30-data-acquisition-pipeline.md` | `18c7c1d07abf6b1f66eb4a5a234f462335bc293f2356bc00e410b1a670e28c69` | 19684 | Historical |
| 36 | `archive/HISTORICAL-README.md` | `5a6114b1f966f3da4b8c240b479451451d1f3b1f9594885966d2f8a1285e1f20` | 5602 | Historical |
| 37 | `archive/VERIFICATION-REPORT.md` | `eae4fc33ca1158b08948e1fe4a6936607d4cf09917e53a4ac95cb97aa15c7b98` | 39637 | Historical |
| 38 | `canonical/01-business.md` | `c0248291bdda23d03f2a592dd036864f15f9c7cdb47bce869fad5dd8198e7e01` | 48139 | Canonical |
| 39 | `canonical/02-decisions.md` | `09d61d48aa048c4b7c6ab9f733ef1b767935cfde024f9d62711d3e91245222da` | 72903 | Canonical |
| 40 | `canonical/03-domain.md` | `ae3884330189a44797690b28c25d4893fc724f612edcf244c33b649bf86d58de` | 79119 | Canonical |
| 41 | `canonical/04-architecture.md` | `2e4de7f0386af59074116d114a600969352d1c246af05385bdfba7ac9b88cc24` | 70473 | Canonical |
| 42 | `canonical/05-implementation.md` | `d8922de90048557b427c2f35457fea1ee4afde926b20b32ff185050f11589acb` | 110867 | Canonical |
| 43 | `canonical/06-data-acquisition.md` | `76536eafd60713e17a90b1d1a9dff9a068fed4d40d95c94c7e61514386381eac` | 25979 | Canonical |
| 44 | `governance/ADVERSARIAL-DECISION-REVIEW.md` | `b73286d559ef25d3c76adc091092b4e1fec24f4ef8352a391c91acd73db45021` | 132385 | Governance |
| 45 | `governance/CANONICAL-AMENDMENT-REPORT.md` | `95c8a3fc49a889cf83fada2239bf2cb4c7165775924312a07c928dc6fccb8401` | 12695 | Governance |
| 46 | `governance/CANONICAL-CONSISTENCY-AUDIT.md` | `b244f0578243c27193a583d884806b6a001a2f47a692b160cfc7a07c7f35d482` | 23503 | Governance |
| 47 | `governance/CANONICAL-UPDATE-REPORT.md` | `969405471e70428a343fa87c94f939130e87ed983b62ab893b94e8b321ac063c` | 15571 | Governance |
| 48 | `governance/DISCOVERY-CLOSURE.md` | `16ce463b7c9c047d0215a24f96ce70b1762e50e4369128e45d5e6cf878a2c18b` | 37021 | Governance |
| 49 | `governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` | `aa4f2cded2f1b917dd23098df63c8db649fa6cfb760f1fb075550706b1b0b45a` | 38186 | Governance |
| 50 | `governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` | `128459465c6a84bdd92f5d660d22788a40b2b2aef05f0084038278a44b35de97` | 43174 | Governance |
| 51 | `governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` | `0f625e66d9f6b35a0569854a71ac482de28d0cc2686f5e9676dd1b93d1fc91ce` | 67039 | Governance |
| 52 | `governance/FOUNDATIONAL-DECISIONS-BRIEF.md` | `780280921a57f5f094584c80852f510fbaafb3da3deaa9462cdfb7e592fe5abd` | 68567 | Governance |
| 53 | `governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md` | `dc2e37f8cdc76a14a61bece90eb68f67e65637af0c9befdbb45d111d6176a6cc` | 75337 | Governance |
| 54 | `product-experience/FIRST-VERTICAL-SLICE-UI.md` | `2c66d139ce0bff533a1d7f8ca6c81d9e660569af588662259e39455abbcc8167` | 56099 | Product Experience |
| 55 | `product-experience/FIRST-VERTICAL-SLICE-UX.md` | `74fc59c6ccf6b08a7ea9265d7f845395fc78f3d8ac47d9b89a3a5a7a129bff46` | 52552 | Product Experience |
| 56 | `product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md` | `829ae23a3ae3589a04952068b99fdb223ebc6d1bfdc3f1c33214bbdbd79e6184` | 93691 | Product Experience |
| 57 | `product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md` | `cff3b2ea4409afa97af6c4f7778f49e8c13ce6a50eddde4b32d423ec6dc091e6` | 63740 | Product Experience |

---

## Verification

All SHA-256 hashes recomputed on 2026-08-19 for V4.4 final package.

**V4.4 changes from V4.3 MANIFEST:**

- **canonical/06-data-acquisition.md** — §1 idempotency principle updated: dual-key model (external_identifiers for canonical entities, natural domain constraints for child records); §11 RBAC authorization corrected to two-layer model (Spatie + organization_members pivot); §11.1 added: non-external-ID idempotent upsert keys for cut_off_marks, admission_policies, accreditation_records
- **canonical/05-implementation.md** — §8.0 idempotent import upsert paragraph updated: dual-key model (INV-EI1 for entities with external IDs, natural composite constraints for child records without external IDs)
- **MANIFEST.md** — This file; all 57 file hashes recomputed for V4.4

**Unchanged files (55):** All other files retain their V4.3 content.

**Self-hash note:** The SHA-256 for MANIFEST.md (entry #1) was computed using the zeroed-field method: the hash and size fields for entry #1 are replaced with 64 zero hex digits and 00000 respectively, then SHA-256 is computed on the resulting file. To verify: zero the hash/size fields for entry #1 and recompute SHA-256; it should match the recorded value.
