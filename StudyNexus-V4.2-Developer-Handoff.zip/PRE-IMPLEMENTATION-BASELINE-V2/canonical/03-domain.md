# StudyNexus -- Domain Model

**Status:** Canonical
**Sources:** 13-domain-discovery-consolidation.md, 15-domain-discovery-topic4-behaviour.md, 16-domain-discovery-topic3.md, 12-domain-discovery-topic2-revision.md, 14-architectural-review-global-domain.md, 21-domain-architecture-frozen-baseline.md
**Architecture:** Laravel Beyond CRUD (Brent Roose & Freek Van der Herten) -- Pragmatic Domain-Driven Design

---

## 1. Domain Principles

The StudyNexus domain model follows the pragmatic Domain-Driven Design philosophy of Laravel Beyond CRUD. This is not theoretical DDD with heavy ceremony -- it is a practical approach that places the domain at the centre of the codebase while keeping implementation patterns simple and Laravel-idiomatic.

**Laravel Beyond CRUD pragmatic DDD.** Eloquent models serve as both domain entities and persistence representations. There are no separate domain entity classes alongside Eloquent models; the model IS the aggregate's persistence representation with domain operations as named methods (ADR-1). This eliminates the mapping overhead of traditional DDD while preserving domain behaviour on the models themselves. Value objects are implemented as immutable PHP objects with custom Eloquent casts, or as PHP Backed Enums where the concept is a closed set of domain values.

**Domain First.** Domain concepts are discovered from the educational domain itself, not from implementation frameworks. When multiple equally valid domain models exist, the one that best aligns with pragmatic DDD is preferred. The domain model is expressed in universal educational terms; Nigerian instances (JAMB, NUC, WAEC) illustrate concepts rather than define them. This ensures the model is genuinely "education-type agnostic" -- it models institutions, programmes, admissions, and scholarships as universal domain concepts, not as Nigeria-specific or tertiary-specific concepts.

**Global Domain.** StudyNexus is an educational opportunity discovery and decision-support platform whose initial operating context is Nigeria. Nigeria is data, not domain structure. The domain model avoids Nigerian-specific abstractions and models concepts that exist across educational systems worldwide. What is specific to a country is expressed as configuration data and reference data, not as domain structure. For example, institution type values (University, Polytechnic, College of Education, IEI) are data that vary by country; the domain concept of "an institution has a type that categorises it within its regulatory framework" is universal.

**Avoid Premature Generalization.** A broader concept is introduced only when it genuinely exists in the educational domain and accurately represents multiple country-specific implementations. Genericity without semantic value is not an improvement. No generic `EducationalThing`, `Policy`, `Opportunity`, `Authority`, `Requirement`, `Provider`, or `Offering` abstractions exist. Each entity earns its place through domain language, behaviour, invariants, and lifecycle.

**Aggregate root justification: invariants, business operations, consistency boundary.** Having identity does not make something an aggregate root. Being independently searchable does not make something an aggregate root. Anemic aggregates are a warning sign. Every aggregate root must answer three questions: What invariants does it protect? What business operations does it perform? What consistency boundary does it define? Aggregate boundaries exist to protect business invariants and consistency boundaries -- practical over theoretical.

---

## 2. Entity Register (13)

The domain contains exactly 13 entities: 5 Aggregate Roots, 4 Child Entities, and 4 Supporting Entities. Admission Pathway has been demoted from supporting entity to Value Object (see Section 3). "Government Education Agency" has been renamed to "Education Authority" per architectural review finding F1. ProgrammeInstance is a child entity of Programme (concrete offering per campus/mode/year). Campus is a supporting entity belonging to Institution (multi-campus support).

### Aggregate Roots (5)

| # | Entity | Invariants | Business Operations | Consistency Boundary |
|---|--------|-----------|---------------------|---------------------|
| 1 | Educational Institution | INV-I1 through INV-I5 (5 invariants) | establish, rename, suspend, reactivate, close, publishAdmissionPolicy, recordAccreditation | Name, status, active policies, accreditation records -- all must be consistent within the aggregate boundary |
| 2 | Programme | INV-P1 through INV-P6 (6 invariants) | introduce, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, reassignTo (internal) | Status, ownership, accreditation records -- all must be consistent. Admission policies delegated to ProgrammeInstance |
| 3 | Scholarship | INV-S1 through INV-S5 (5 invariants) | announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, expire, targetProgrammes | Status, eligibility policy, targeted programmes/institutions, application deadline |
| 4 | Admission Cycle | INV-C1 through INV-C3 (3 invariants) | announce, activate, advancePhase, close, archive | Status, current phase, phase dates |
| 5 | Information Source | INV-IS1 through INV-IS3 (3 invariants) | register, verify, markUnreliable, deprecate | Reliability status, attribution records |

**Aggregate root justifications.** Each aggregate root was evaluated against five criteria: protects business invariants, has independent lifecycle, is independently manipulable by the business, is a standalone concept to domain experts, and defines its own consistency boundary. None were promoted based on identity alone. Each has 3-6 protected invariants, domain operations with precondition checks, and consistency boundaries that would be violated by demotion.

### Child Entities (4)

| # | Entity | Parent Aggregate | Invariants Enforced By Parent | Lifecycle |
|---|--------|-----------------|------------------------------|-----------|
| 6 | Admission Policy | ProgrammeInstance or Institution | INV-I3 / INV-PI3 (one active per cycle) | Draft -> Published -> Superseded -> Withdrawn. Driven by parent operations; no independent public API. Admission criteria are scoped to the specific offering (Instance), not the abstract degree (Programme). |
| 7 | Eligibility Policy | Scholarship | INV-S2 (one active per period) | Draft -> Published -> Superseded -> Withdrawn. Driven by parent; no independent operations. |
| 8 | Accreditation Record | Programme or Institution | INV-I2 / INV-P5 / INV-10 (jurisdiction), INV-I4 (uniqueness) | Immutable after creation. Each record is a historical fact. Current status is derived from the sequence of records. |
| 9 | Programme Instance | Programme | INV-PI1 (unique offering per campus/mode/year), INV-PI2 (status within programme boundary) | Status transitions (Prospective -> Admitting -> Suspended -> Discontinued) driven by programme lifecycle; published/unpublished as application-level concern. |

**Child entity rationale.** Child entities have identity (distinguishing multiple policies per cycle, multiple accreditation records per authority) but lack autonomous behaviour. Their lifecycle transitions are driven by parent operations. Admission Policy is published by its parent; it does not decide to publish itself. Accreditation Record is created by the parent's `recordAccreditation` operation and never independently modified. ProgrammeInstance represents one concrete offering of a Programme at a Campus in an Academic Year with a DeliveryMode — its lifecycle is bounded by the Programme's lifecycle (if the Programme is discontinued, all instances are discontinued). Embedding these within their parent aggregate protects the critical one-active-per-cycle invariant that would be violated if they were separate aggregates.

### Supporting Entities (4)

| # | Entity | Identity | Behaviour | Rationale |
|---|--------|----------|-----------|-----------|
| 10 | Qualification | Name + Defining Authority (auto-increment PK) | `deprecate` only; all other operations are reference data CRUD | Reference data used by Admission Rules and Eligibility Rules. Defined by external authorities; StudyNexus records, does not manage. Identity required for central deprecation and reference from policies. |
| 11 | Scholarship Provider | Name (auto-increment PK) | `deprecate` only (marginal); no domain behaviour otherwise | Weakest entity in the model. Exists as referential integrity guard -- Scholarship references a provider (INV-S1). Demoting to VO would lose deprecation capability. |
| 12 | Education Authority | Name + Type (auto-increment PK) | `deprecate` only (marginal); jurisdiction check is application-layer validation | Reference data referenced by Accreditation Records, Qualifications, Admission Cycles, and Admission Pathways. Renamed from "Government Education Agency" per F1 -- governmental nature is an attribute, not the defining characteristic. Covers JAMB, NUC, WAEC (Nigeria), ABET, UCAS, QAA (global), and non-governmental professional accrediting bodies. |
| 13 | Campus | Name + Institution (auto-increment PK) | `activate`, `deactivate`, `plan` (marginal); status transitions via CampusStatus enum | Supporting entity belonging to Institution. Enables multi-campus institutions (e.g., University of Lagos with main campus at Akoka and satellite campus at Idi-Araba). Each Campus carries its own Location VO and an is_primary flag. At least one Campus per Institution must be is_primary=true (INV-CAMP1). A Campus in Active status is required before ProgrammeInstances can reference it. |

**Supporting entity rationale.** Supporting entities have identity but no protected invariants and no autonomous domain behaviour beyond `deprecate` (or marginal status transitions for Campus). They are reference data managed via Filament CRUD, not aggregate roots. Their value over value objects is: (1) they can be deprecated centrally, (2) they are referenced by multiple entities via FK, and (3) changing their display representation is a single update, not N string updates. Campus has slightly more behaviour than typical supporting entities (status transitions: Active/Inactive/Planned) but lacks protected invariants and autonomous domain operations -- it exists to support ProgrammeInstance references and multi-campus institution modelling.

---

## 3. Value Objects (29)

The domain contains exactly 29 Value Objects: 12 genuine domain VOs (immutable PHP objects) and 17 PHP Backed Enums. This count is authoritative per the frozen baseline (21-domain-architecture-frozen-baseline.md, Section 4). The earlier arithmetic error (claiming 13 enums in slots 13-28) is corrected: the range 13-28 spans 16 slots.

### Genuine Domain Value Objects (12)

| # | Value Object | Description | Invariants | Owning Entity | Equality Semantics | Implementation |
|---|-------------|-------------|-----------|---------------|-------------------|---------------|
| 1 | Admission Rule | Encapsulates an admission requirement: qualification reference, threshold, subject combinations, and rule type. Rule type determines which fields are required. | Rule type determines required fields | AdmissionPolicy | Value equality (all fields match) | Immutable PHP Object + JSON Cast |
| 2 | Eligibility Rule | Encapsulates an eligibility criterion: criterion type (CGPA, field of study, nationality, financial need), comparator, and value. | Criterion type determines required fields | EligibilityPolicy | Value equality | Immutable PHP Object + JSON Cast |
| 3 | Subject Combination | Ordered set of subjects with combination type (AND/OR). Used within Admission Rules to specify required subject groups. | At least one subject required | AdmissionRule (nested) | Value equality | Immutable PHP Object + JSON Cast |
| 4 | Qualification Threshold | Qualification reference + comparator + value + scale. Generalises "cut-off mark" (F11) -- a cut-off mark is a Qualification Threshold where the qualification is a standardised assessment and the comparator is >=. | Comparator must be valid | AdmissionRule (nested) | Value equality | Immutable PHP Object + JSON Cast |
| 5 | Validity Period | Start date + end date for policy and accreditation validity periods. | Start <= end | AdmissionPolicy, EligibilityPolicy, AccreditationRecord | Date range equality | Immutable PHP Object + Custom Cast |
| 6 | Trust Signal | Computed reliability indicator for an Information Source. Derived from source verification status and provenance metadata. Not stored -- computed on demand. | N/A (computed, read-only) | InformationSource (via Query) | Value equality | Computed (never stored) |
| 7 | Monetary Amount | Amount + currency (ISO 4217). Used for programme tuition fees and scholarship values. | Amount >= 0 for fees; currency is ISO 4217 | ProgrammeInstance (tuition), Scholarship (value) | Amount + currency equality | Immutable PHP Object + Custom Cast |
| 8 | Duration | Value + unit (years, months, semesters) for programme length. Norms vary by country (US: credit hours; UK/Nigeria: years). May differ from Programme default when set on ProgrammeInstance. | Value > 0 | Programme, ProgrammeInstance | Value + unit equality | Immutable PHP Object + Custom Cast |
| 9 | Location | Country + region + city for institution/campus geographic location. Nullable for online-only institutions. | Country is ISO 3166-1 | Institution, Campus | All fields equality | Immutable PHP Object + Custom Cast (nullable) |
| 10 | Authority Jurisdiction | Jurisdiction type + criteria defining an Education Authority's scope. What defines jurisdiction varies by country (institution type in Nigeria, geographic region in US, subject area for professional bodies). | None (purely structural) | EducationAuthority | Value equality | Immutable PHP Object + JSON Cast |
| 11 | Phase Sequence | Ordered list of admission cycle phases with timing. Phase names and count are data (Nigeria: Registration -> Examination -> Results -> Admission; UK UCAS: Application -> Decisions -> Reply -> Clearing). | Phases ordered chronologically | AdmissionCycle | Sequence equality | Immutable PHP Object + JSON Cast |
| 12 | Admission Pathway | Name + authority reference for an admission route. Demoted from supporting entity to Value Object per behaviour discovery (15-domain-discovery-topic4-behaviour.md, Section 13). Pathways are discriminators within Admission Policies, not autonomous entities. Valid pathway values are reference data managed by the application layer. | None (purely structural) | AdmissionPolicy | Value equality | Immutable PHP Object |

### PHP Backed Enums (17)

The 17 enums split into 3 behavioural enums (with domain methods that affect business logic) and 14 pure enums (closed sets of domain values with no behaviour beyond case equality).

#### Behavioural Enums (3)

| # | Enum | Values | Behaviour | Owning Entity |
|---|------|--------|-----------|---------------|
| 13 | Institution Type | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution (MVP); extensible per country per F6 | `isDegreeGranting()`, `isTertiary()` -- determines which authorities have jurisdiction, which award levels are valid | Educational Institution |
| 14 | Award Level | BSc, BA, MSc, PhD (universal); ND, HND, NCE (Nigeria); extensible per country per F7 | `isPostgraduate()`, `isUndergraduate()` -- affects admission pathways and programme classification | Programme |
| 15 | Admission Mode | Cyclic, Rolling, MultipleIntake | Affects `isAdmitting` query logic: Cyclic checks cycle phase + policy; Rolling checks status only; MultipleIntake checks intake dates | Programme |

#### Pure Enums (14)

| # | Enum | Values | Owning Entity |
|---|------|--------|---------------|
| 16 | Accreditation Status | Full, Interim, Probationary, Revoked, Expired | Accreditation Record |
| 17 | Policy Status | Draft, Published, Superseded, Withdrawn | Admission Policy, Eligibility Policy |
| 18 | Programme Status | Prospective, Admitting, Suspended, Discontinued | Programme, Programme Instance |
| 19 | Scholarship Status | Draft, Announced, Open, Closed, Expired, Withdrawn | Scholarship |
| 20 | Institution Status | Provisional, Operational, Suspended, Closed | Educational Institution |
| 21 | Source Reliability | Registered, Verified, Unreliable, Deprecated | Information Source |
| 22 | Information Category | Official, Unofficial, Historical, Scraped | Information Source |
| 23 | Authority Type | Regulatory, Accreditation, Funding, Admissions | Education Authority |
| 24 | Provider Type | Government, Corporate, NGO, Institution | Scholarship Provider |
| 25 | Ownership Type | Public, Private, PPP, Religious | Educational Institution |
| 26 | Delivery Mode | OnCampus, Online, Hybrid | Programme Instance |
| 27 | Qualification Status | Active, Deprecated | Qualification |
| 28 | Coverage Type | Full, Partial, TuitionOnly, Stipend | Scholarship |
| 29 | Campus Status | Active, Inactive, Planned | Campus |

---

## 4. Domain Events (29)

Domain events represent business facts that other parts of the system react to. An event is emitted only when: (1) the state change represents a business fact that downstream consumers might need, (2) at least one concrete downstream reaction exists, and (3) the event carries sufficient information for the reaction without requiring the consumer to reload the aggregate. Events are plain PHP classes with constructor-injected payload; no shared interface or trait (ADR-3, ADR-16).

| # | Event | Emitting Entity | Trigger | Payload | Consumers |
|---|-------|----------------|---------|---------|-----------|
| 1 | InstitutionEstablished | Institution | `establish()` | institutionId, name, type, occurredAt | UpdateSearchIndex, LogActivity |
| 2 | InstitutionRenamed | Institution | `rename()` | institutionId, oldName, newName, occurredAt | UpdateSearchIndex, LogActivity |
| 3 | InstitutionSuspended | Institution | `suspend()` | institutionId, occurredAt | UpdateSearchIndex, ProgrammeStatusCascade |
| 4 | InstitutionReactivated | Institution | `reactivate()` | institutionId, occurredAt | UpdateSearchIndex, ProgrammeStatusRestore |
| 5 | InstitutionClosed | Institution | `close()` | institutionId, occurredAt | UpdateSearchIndex, ProgrammeDiscontinueCascade, ScholarshipFlag |
| 6 | InstitutionsMerged | InstitutionMerger | `merge()` | initiatingId, targetId, occurredAt | SearchRebuild, ProgrammeReassignment |
| 7 | InstitutionAccredited | Institution | `recordAccreditation()` | institutionId, authorityId, status, occurredAt | TrustSignal, UpdateSearchIndex |
| 8 | InstitutionalAdmissionPolicyPublished | Institution | `publishAdmissionPolicy()` | institutionId, cycleId, policyId, occurredAt | UpdateSearchIndex, OpportunityFeed |
| 9 | ProgrammeIntroduced | Programme | `introduce()` | programmeId, institutionId, name, awardLevel, occurredAt | UpdateSearchIndex, LogActivity |
| 10 | ProgrammeInstanceAdmissionPolicyPublished | ProgrammeInstance | `publishAdmissionPolicy()` | programmeInstanceId, cycleId, policyId, occurredAt | UpdateSearchIndex, OpportunityFeed |
| 11 | ProgrammeAdmissionSuspended | Programme | `suspendAdmission()` | programmeId, occurredAt | UpdateSearchIndex |
| 12 | ProgrammeAdmissionResumed | Programme | `resumeAdmission()` | programmeId, occurredAt | UpdateSearchIndex |
| 13 | ProgrammeDiscontinued | Programme | `discontinue()` | programmeId, occurredAt | UpdateSearchIndex, ScholarshipFlag |
| 14 | ProgrammeAccredited | Programme | `recordAccreditation()` | programmeId, authorityId, status, occurredAt | TrustSignal, UpdateSearchIndex |
| 15 | ScholarshipAnnounced | Scholarship | `announce()` | scholarshipId, providerId, occurredAt | UpdateSearchIndex, CandidateNotification |
| 16 | ScholarshipEligibilityPolicyPublished | Scholarship | `publishEligibilityPolicy()` | scholarshipId, policyId, occurredAt | EligibleCandidateRecalc |
| 17 | ScholarshipApplicationsOpened | Scholarship | `openApplications()` | scholarshipId, occurredAt | UpdateSearchIndex, CandidateNotification |
| 18 | ScholarshipApplicationsClosed | Scholarship | `closeApplications()` | scholarshipId, occurredAt | UpdateSearchIndex |
| 19 | ScholarshipWithdrawn | Scholarship | `withdraw()` | scholarshipId, occurredAt | UpdateSearchIndex, ApplicantNotification |
| 20 | ScholarshipExpired | Scholarship | `expire()` | scholarshipId, occurredAt | UpdateSearchIndex |
| 21 | ScholarshipTargetsUpdated | Scholarship | `targetProgrammes()` | scholarshipId, addedProgrammeIds, removedProgrammeIds, occurredAt | UpdateSearchIndex |
| 22 | AdmissionCycleAnnounced | Admission Cycle | `announce()` | cycleId, authorityId, period, occurredAt | UpdateSearchIndex |
| 23 | AdmissionCycleActivated | Admission Cycle | `activate()` | cycleId, occurredAt | ReadModelUpdate |
| 24 | AdmissionCyclePhaseAdvanced | Admission Cycle | `advancePhase()` | cycleId, previousPhase, currentPhase, occurredAt | ReadModelUpdate, NotificationDispatch |
| 25 | AdmissionCycleClosed | Admission Cycle | `close()` | cycleId, occurredAt | ReadModelUpdate |
| 26 | InformationSourceVerified | Information Source | `verify()` | sourceId, occurredAt | TrustSignalRecalc |
| 27 | InformationSourceMarkedUnreliable | Information Source | `markUnreliable()` | sourceId, occurredAt | TrustSignalRecalc |
| 28 | InformationSourceDeprecated | Information Source | `deprecate()` | sourceId, occurredAt | TrustSignalCascade, DataProvenanceFlag |
| 29 | QualificationDeprecated | Qualification | `deprecate()` | qualificationId, occurredAt | PolicyCreationGuard |

**Rejected events.** `InstitutionLocationChanged`, `ProgrammeDescriptionUpdated`, and `ScholarshipCoverageUpdated` are rejected -- they are CRUD with no domain significance beyond search index projection. Events for Scholarship Provider and Education Authority are rejected -- their changes have no direct domain consequences beyond reference integrity, which is an application-layer concern handled by FK constraints.

---

## 5. Actions (20)

Actions represent application use cases -- orchestrated operations that coordinate domain operations, validation, authorization, and cross-cutting concerns. An operation becomes an Action when at least one of these conditions is true: (1) multi-step orchestration, (2) multi-entry-point reuse (HTTP + Filament + Import), (3) significant cascade across aggregates, or (4) authorization + complex validation beyond Form Request. Search index updates are NOT sufficient justification (handled by event listeners). Authorization alone is NOT sufficient (handled by Laravel Policies).

| # | Action | Target Entity | Description | Justification |
|---|--------|-------------|-------------|---------------|
| 1 | CreateInstitution | Institution | Create a new educational institution with type, name, location, and provenance | Multi-entry-point (HTTP + Filament + Import); jurisdiction validation + domain + event dispatch |
| 2 | SuspendInstitution | Institution | Suspend an operational institution, cascading to programme status | Significant cascade (programme status cascade via event + notification coordination) |
| 3 | CloseInstitution | Institution | Permanently close an institution, cascading to programmes and scholarships | Significant cascade (programme discontinuation + scholarship flag + search exclusion) |
| 4 | MergeInstitutions | Institution | Merge two institutions into one, reassigning all programmes and transferring accreditation | Multi-step cross-aggregate orchestration via InstitutionMerger; most complex operation |
| 5 | PublishAdmissionPolicy | ProgrammeInstance or Institution | Publish admission requirements for a specific admission cycle | Multi-step: cycle validation + rule validation + domain operation + event |
| 6 | RecordAccreditation | Programme or Institution | Record an accreditation event with jurisdiction validation | Authorization + jurisdiction guard + trust signal cascade trigger |
| 7 | CreateProgramme | Programme | Create a new programme within an institution | Multi-entry-point (HTTP + Filament + Import); institution validation + award level guard |
| 8 | DiscontinueProgramme | Programme | Permanently discontinue a programme, flagging affected scholarships | Cascade coordination (scholarship flag cascade) |
| 9 | AnnounceScholarship | Scholarship | Announce a new scholarship with provider validation | Authorization + provider validation |
| 10 | OpenScholarshipApplications | Scholarship | Open the application window, verifying eligibility policy exists | Authorization + policy check + notification trigger |
| 11 | ExpireScholarship | Scholarship | Expire a single scholarship whose deadline has passed (time-based) | Scheduler trigger; batch coordination |
| 12 | TargetScholarshipProgrammes | Scholarship | Set or update which programmes/institutions the scholarship targets | Authorization + programme existence validation + transactional relationship coordination |
| 13 | AnnounceAdmissionCycle | Admission Cycle | Announce a new admission cycle with authority validation | Authorization + authority validation (non-trivial jurisdiction check) |
| 14 | ActivateAdmissionCycle | Admission Cycle | Activate an announced cycle when its start date arrives | Multi-entry-point (HTTP + Filament + Scheduler); read model update trigger |
| 15 | AdvanceAdmissionCyclePhase | Admission Cycle | Advance the cycle to its next sequential phase | Authorization + notification dispatch |
| 16 | RegisterInformationSource | Information Source | Register a new information source with verification metadata | Multi-entry-point (Filament + Import); reference validation |
| 17 | VerifyInformationSource | Information Source | Mark a source as verified after reliability assessment | Authorization + trust cascade trigger |
| 18 | MarkSourceUnreliable | Information Source | Mark a verified source as unreliable | Authorization + trust cascade coordination |
| 19 | ImportInstitutionData | Multiple | Import institution data from external sources (CSV/JSON/API) | Significant orchestration: parsing + validation + deduplication + batch + event dispatch |
| 20 | ExpireScholarships | Scholarship (batch) | Batch-expire all overdue scholarships (scheduled) | Time-based batch operation from scheduler |

**Removed Actions (with rationale).** ReassignProgramme removed -- it is a domain method (`Programme::reassignTo()`) invoked internally by InstitutionMerger, with no independent entry point. RenameInstitution removed -- single domain call + auth; search index handled by `InstitutionRenamed` event listener. ReactivateInstitution removed -- single domain call + auth; search inclusion handled by `InstitutionReactivated` event listener.

---

## 6. Enums (17)

The domain contains exactly 17 enums: 3 behavioural (with domain methods that affect business logic) and 14 pure (closed sets of domain values with equality semantics only). All are PHP Backed Enums. InstitutionType and AwardLevel are retained as enums for the MVP per ADR-15; the migration trigger is "when the 4th+ country requires types not in the existing enum, evaluate migration to reference data table."

### Behavioural Enums (3)

| # | Enum | Values | Behaviour | Owning Entity |
|---|------|--------|-----------|---------------|
| 1 | InstitutionType | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution | `isDegreeGranting(): bool`, `isTertiary(): bool` -- determines which authorities have jurisdiction, which award levels are valid, accreditation eligibility | Educational Institution |
| 2 | AwardLevel | BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma | `isPostgraduate(): bool`, `isUndergraduate(): bool` -- affects admission pathways, programme classification, and eligibility rule evaluation | Programme |
| 3 | AdmissionMode | Cyclic, Rolling, MultipleIntake | Affects `isAdmitting` query: Cyclic checks cycle phase + policy existence; Rolling returns true if status is Admitting; MultipleIntake checks explicit intake dates | Programme |

### Pure Enums (14)

| # | Enum | Values | Owning Entity |
|---|------|--------|---------------|
| 4 | AccreditationStatus | Full, Interim, Probationary, Revoked, Expired | Accreditation Record |
| 5 | PolicyStatus | Draft, Published, Superseded, Withdrawn | Admission Policy, Eligibility Policy |
| 6 | ProgrammeStatus | Prospective, Admitting, Suspended, Discontinued | Programme, Programme Instance |
| 7 | ScholarshipStatus | Draft, Announced, Open, Closed, Expired, Withdrawn | Scholarship |
| 8 | InstitutionStatus | Provisional, Operational, Suspended, Closed | Educational Institution |
| 9 | SourceReliability | Registered, Verified, Unreliable, Deprecated | Information Source |
| 10 | InformationCategory | Official, Unofficial, Historical, Scraped | Information Source |
| 11 | AuthorityType | Regulatory, Accreditation, Funding, Admissions | Education Authority |
| 12 | ProviderType | Government, Corporate, NGO, Institution | Scholarship Provider |
| 13 | OwnershipType | Public, Private, PPP, Religious | Educational Institution |
| 14 | DeliveryMode | OnCampus, Online, Hybrid | Programme Instance |
| 15 | QualificationStatus | Active, Deprecated | Qualification |
| 16 | CoverageType | Full, Partial, TuitionOnly, Stipend | Scholarship |
| 17 | CampusStatus | Active, Inactive, Planned | Campus |

---

## 7. Invariants

Every domain invariant is expressed in universal terms. Nigerian instances illustrate concepts rather than define them. Invariants are classified by severity (CRITICAL, HIGH, MEDIUM, LOW) and enforcement location (domain method, read model, application layer, reference data constraint).

| ID | Entity | Invariant | Enforcement | Severity | Universal? |
|----|--------|-----------|-------------|----------|-----------|
| INV-I1 | Institution | An Institution has a valid type within its regulatory framework | `establish()` | CRITICAL | Yes |
| INV-I2 | Institution | An Institution can only be accredited by an Education Authority with jurisdiction over its type | `recordAccreditation()` | HIGH | Yes |
| INV-I3 | Institution | Only one active institutional Admission Policy per Admission Cycle | `publishAdmissionPolicy()` | HIGH | Yes |
| INV-I4 | Institution | An Institution always has a current official name | `establish()`, `rename()` | MEDIUM | Yes |
| INV-I5 | Institution | A closed institution cannot perform business operations | `close()`, all operations | CRITICAL | Yes |
| INV-P1 | Programme | A Programme belongs to exactly one Institution | `introduce()` | CRITICAL | Yes |
| INV-PI3 | Programme Instance | Only one active Admission Policy per Admission Cycle per ProgrammeInstance | `publishAdmissionPolicy()` | HIGH | Yes |
| INV-P3 | Programme | A Programme's admission status = (lifecycle is Admitting) AND (cycle is in Admission Period) | Read model query | HIGH | Yes (query invariant) |
| INV-P4 | Programme | A Programme's award level is valid for its Institution's type | `introduce()` | HIGH | Jurisdiction-dependent |
| INV-P5 | Programme | A Programme's accreditation can only be from an Education Authority with jurisdiction over it | `recordAccreditation()` | HIGH | Yes |
| INV-P6 | Programme | A discontinued programme cannot perform business operations | `discontinue()`, all operations | CRITICAL | Yes |
| INV-S1 | Scholarship | A Scholarship has exactly one Provider | `announce()` | CRITICAL | Yes |
| INV-S2 | Scholarship | Only one active Eligibility Policy per period | `publishEligibilityPolicy()` | HIGH | Yes |
| INV-S3 | Scholarship | Applications opened only when Scholarship in "announced" state | `openApplications()` | HIGH | Yes |
| INV-S4 | Scholarship | Applications closed only when Scholarship in "open" state | `closeApplications()` | HIGH | Yes |
| INV-S5 | Scholarship | Applications cannot open without a published Eligibility Policy | `openApplications()` | HIGH | Yes |
| INV-C1 | Admission Cycle | A cycle has defined start and end dates | `announce()` | MEDIUM | Yes |
| INV-C2 | Admission Cycle | Phase transitions follow the defined sequence (no backwards, no skipping) | `advancePhase()` | HIGH | Yes |
| INV-C3 | Admission Cycle | A cycle is time-bounded | `close()` | MEDIUM | Yes |
| INV-IS1 | Information Source | Source cannot be simultaneously verified and unreliable | `verify()`, `markUnreliable()` | HIGH | Yes |
| INV-IS2 | Information Source | A deprecated source cannot be verified | `deprecate()` | HIGH | Yes |
| INV-IS3 | Information Source | Every registered source has a retrievable reference | `register()` | MEDIUM | Yes |
| INV-PI1 | Programme Instance | A ProgrammeInstance is unique per (programme, campus, delivery_mode, academic_year) | `addInstance()` | HIGH | Yes |
| INV-PI2 | Programme Instance | A ProgrammeInstance's status cannot exceed its Programme's status (discontinued programme forces discontinued instances) | Programme `discontinue()` cascade | CRITICAL | Yes |
| INV-CAMP1 | Campus | At least one Campus per Institution must be is_primary=true | Application layer (Filament CRUD guard) | HIGH | Yes |
| INV-2 | Accreditation Record | Granted by exactly one Education Authority | `recordAccreditation()` (on parent) | HIGH | Yes |
| INV-9 | Qualification | Recognized by at least one Education Authority | Application service (reference data) | LOW | Yes (reference data constraint) |
| INV-10 | Accreditation Record | Subject within granting authority's jurisdiction | `recordAccreditation()` (on parent) | HIGH | Yes |

**Invariant notes.** INV-P3 is a query invariant enforced by the read model, not by any single aggregate at write time. This is correct -- the derived property "isAdmitting" is computed from Programme lifecycle + Admission Cycle phase + Policy existence, and eventual consistency is acceptable. INV-9 is a reference data constraint rather than a domain invariant; no aggregate operation depends on it. INV-I2 and INV-P5 express the same jurisdiction invariant from different perspectives (the authority must have jurisdiction, and the subject must be within that jurisdiction). What defines jurisdiction is data that varies by country (institution type in Nigeria, geographic region in the US, subject area for professional accrediting bodies), but the invariant -- accreditation requires jurisdiction -- is universal. INV-PI1 ensures each ProgrammeInstance is a unique concrete offering (one programme, one campus, one delivery mode, one academic year). INV-PI2 ensures ProgrammeInstance status is bounded by Programme status -- discontinuing a Programme cascades to all instances. INV-CAMP1 ensures every Institution has at least one primary Campus; this is enforced at the application layer because Campus is a supporting entity managed via Filament CRUD.

---

## 8. Entity Behaviours

Domain behaviour was discovered through a ten-question filter (15-domain-discovery-topic4-behaviour.md, Section 1) that eliminates CRUD disguised as domain operations, operations that belong to application orchestration, and behaviours with no invariant to protect. Every candidate behaviour must pass all ten questions before acceptance.

### Educational Institution

**Domain methods:**

- `establish(name, type, registrationIdentifier, establishmentYear, ownershipType): void` -- Creates the institution in Operational status. Enforces INV-I1 (valid type), INV-I4 (non-empty name). Dispatches `InstitutionEstablished`.
- `rename(newName): void` -- Changes the official name, recording the previous name in Name History. Enforces INV-I4. Dispatches `InstitutionRenamed`.
- `suspend(): void` -- Transitions from Operational to Suspended. Enforces INV-I2 (must be Operational). Dispatches `InstitutionSuspended`.
- `reactivate(): void` -- Transitions from Suspended to Operational. Dispatches `InstitutionReactivated`.
- `close(): void` -- Transitions to Closed (terminal). Enforces INV-I5. Dispatches `InstitutionClosed`.
- `publishAdmissionPolicy(cycleId, rules): AdmissionPolicy` -- Creates a new Admission Policy for the cycle, superseding any existing active policy. Enforces INV-I3. Dispatches `InstitutionalAdmissionPolicyPublished`.
- `recordAccreditation(authorityId, status, period): AccreditationRecord` -- Records an accreditation event. Enforces INV-I2 (authority jurisdiction), INV-I4 (uniqueness). Dispatches `InstitutionAccredited`.

**State machine:** Operational -> Suspended -> Operational (via reactivate); Operational -> Closed (terminal); Suspended -> Closed. Closed is terminal -- no transitions from Closed.

**Cross-aggregate interactions:** Suspend cascades to Programme status via event. Close cascades to Programme discontinuation and Scholarship flagging via events. Merge requires InstitutionMerger domain service.

**Publication attributes (application-level):** `is_published` boolean (default false), `published_at` nullable timestamp. Publication is orthogonal to domain lifecycle — visibility on the public site is controlled by `is_published` AND lifecycle status allowing public display. `published_at` records the first publication date and is not rewritten on subsequent publication cycles. Publication history is available through the existing activity/audit mechanism (spatie/laravel-activitylog). No publication_status enum. No publication state machine.

**Campuses:** An Institution has one or more Campuses (hasMany). Location is moved from Institution to Campus — each Campus carries its own Location VO. The Institution itself no longer has a location column; its location is derived from its primary Campus. At least one Campus must be is_primary=true per Institution (INV-CAMP1). A primary campus is created automatically when an Institution is established.

### Programme

**Domain methods:**

- `introduce(name, institutionId, awardLevel, duration): void` -- Creates the programme in Prospective status (template status; concrete status lives on ProgrammeInstance). Enforces INV-P1 (institution exists), INV-P2 (award level valid for institution type), INV-P4 (award level immutability). Dispatches `ProgrammeIntroduced`.
- `suspendAdmission(): void` -- Transitions from Admitting to Suspended. Dispatches `ProgrammeAdmissionSuspended`.
- `resumeAdmission(): void` -- Transitions from Suspended to Admitting. Enforces INV-P6 (not Discontinued). Dispatches `ProgrammeAdmissionResumed`.
- `discontinue(): void` -- Transitions to Discontinued (terminal). Enforces INV-P6. Dispatches `ProgrammeDiscontinued`.
- `recordAccreditation(authorityId, status, period): AccreditationRecord` -- Records accreditation. Enforces INV-P5. Dispatches `ProgrammeAccredited`.
- `reassignTo(newInstitutionId): void` -- Internal method called by InstitutionMerger. Enforces INV-P1.

**Admission policy delegation.** AdmissionPolicy and cut_off_marks now belong to ProgrammeInstance, not Programme. This is because admission criteria (cut-off marks, admission rules, eligibility thresholds) differ per offering: the same programme may have different cut-offs for its Online offering vs. its OnCampus offering at a different campus. The Programme entity retains accreditation (which is a property of the abstract degree) but delegates admission to its instances. Publishing admission policy is performed on ProgrammeInstance, not Programme.

**State machine:** Prospective -> Admitting -> Suspended -> Admitting (via resumeAdmission); Admitting/Suspended -> Discontinued (terminal). Prospective is the default for a newly introduced programme template; concrete admission status (Admitting/Suspended/Discontinued) lives on ProgrammeInstance. When the Programme itself is discontinued, all ProgrammeInstances cascade to Discontinued.

**Cross-aggregate interactions:** References Institution (ownership FK), Admission Cycle (policy FK). Scholarship targets Programme (unidirectional -- Programme does not know which scholarships target it). Discontinuation flags scholarships via event.

**Publication attributes (application-level):** `is_published` boolean (default false), `published_at` nullable timestamp. Publication is orthogonal to domain lifecycle — visibility on the public site is controlled by `is_published` AND lifecycle status allowing public display. `published_at` records the first publication date and is not rewritten on subsequent publication cycles. Publication history is available through the existing activity/audit mechanism.

**Classification attribute:** `discipline_id` BIGINT FK nullable referencing `disciplines` reference table (single discipline per programme in MVP). Discipline is a search/product classification, not a domain entity with lifecycle. disciplines.id is BIGINT per ADR-19 (BD-1). See Section 12.

**ProgrammeInstance (child entity):** Each Programme has zero or more ProgrammeInstances. A ProgrammeInstance represents one concrete offering at a Campus in an Academic Year with a DeliveryMode. Fields: campus_id (FK → campuses), delivery_mode (DeliveryMode enum), academic_year (string, e.g., "2025/2026"), capacity (nullable int), status (ProgrammeStatus enum — the concrete admission status lives here, not on Programme), tuition (nullable MonetaryAmount VO — same programme may have different tuition per campus/mode), duration (nullable Duration VO — may override Programme default), is_published (boolean, default false), published_at (nullable timestamp). Unique constraint: (programme_id, campus_id, delivery_mode, academic_year) — INV-PI1. Programme.status defaults to Prospective (the abstract template is always "available"); ProgrammeInstance.status carries the concrete lifecycle (Admitting, Suspended, Discontinued). When Programme is discontinued, all instances cascade to Discontinued.

### Scholarship

**Domain methods:**

- `announce(name, providerId, applicationPeriod, value, coverageType): void` -- Creates the scholarship in Announced status. Enforces INV-S1 (provider required). Dispatches `ScholarshipAnnounced`.
- `publishEligibilityPolicy(period, rules): EligibilityPolicy` -- Creates/supersedes eligibility policy. Enforces INV-S2 (one active per period). Dispatches `ScholarshipEligibilityPolicyPublished`.
- `openApplications(): void` -- Transitions from Announced to Open. Enforces INV-S3 (must be Announced), INV-S5 (eligibility policy must exist), INV-S4 (deadline must be set). Dispatches `ScholarshipApplicationsOpened`.
- `closeApplications(): void` -- Transitions from Open to Closed. Enforces INV-S4 (must be Open). Dispatches `ScholarshipApplicationsClosed`.
- `withdraw(): void` -- Transitions to Withdrawn (terminal). Dispatches `ScholarshipWithdrawn`.
- `expire(): void` -- Transitions to Expired (terminal). Triggered by application service when deadline has passed. Dispatches `ScholarshipExpired`.
- `targetProgrammes(programmeIds): void` -- Sets targeting. Dispatches `ScholarshipTargetsUpdated`.

**State machine:** Announced -> Open -> Closed -> Expired; Announced/Open -> Withdrawn. Expired and Withdrawn are terminal. Forbidden: Open -> Announced, Closed -> Open (MVP).

**Cross-aggregate interactions:** References Scholarship Provider (FK), targets Programme/Institution IDs (unidirectional). Targeting is eventual consistency -- read model updates when targets change.

**Publication attributes (application-level):** `is_published` boolean (default false), `published_at` nullable timestamp. Publication is orthogonal to domain lifecycle — visibility on the public site is controlled by `is_published` AND lifecycle status allowing public display. `published_at` records the first publication date and is not rewritten on subsequent publication cycles. Publication history is available through the existing activity/audit mechanism. Although scholarship public discovery pages are Phase 2, the publication model is consistent across all user-facing entities.

### Admission Cycle

**Domain methods:**

- `announce(period, authorityId, phaseSequence, startDate, endDate): void` -- Creates the cycle in Upcoming status. Enforces INV-C1 (dates defined), INV-C2 (valid phase sequence). Dispatches `AdmissionCycleAnnounced`.
- `activate(): void` -- Transitions from Upcoming to Active. Enforces INV-C2 (current date >= startDate). Sets current phase to first in sequence. Dispatches `AdmissionCycleActivated`.
- `advancePhase(): void` -- Advances to next phase in sequence. Enforces INV-C2 (no backwards, no skipping). Dispatches `AdmissionCyclePhaseAdvanced`.
- `close(): void` -- Transitions to Closed. Enforces INV-C3 (must be Active, final phase complete). Dispatches `AdmissionCycleClosed`.
- `archive(): void` -- Transitions to Archived (terminal).

**State machine:** Upcoming -> Active -> Closed -> Archived. Within Active, phase advances sequentially through the configured PhaseSequence. Archived is terminal.

**PhaseSequence (BD-3/ADR-20):** phase_sequence is a JSONB Value Object containing ordered phases, each with a stable immutable phase ID and a mutable phase label. current_phase is the authoritative domain state, referencing a stable phase ID (never a mutable label). Phase IDs and ordering are immutable after cycle activation. Invariant: current_phase must be a member of phase_sequence. Phase transitions are atomic (concurrency mechanism specified in architecture document, 04-architecture.md). No hardcoded timestamp-based phase schema.

**Cross-aggregate interactions:** References Education Authority (FK). When phase advances, read model updates derived `isAdmitting` property for associated programmes (eventual consistency). Programme/Institution policies reference the cycle by ID but the cycle does not load them.

### Information Source

**Domain methods:**

- `register(name, type, reference, category, authorityId?): void` -- Creates the source in Registered status. Enforces INV-IS3 (reference must be retrievable). Optional authorityId links to the publishing EducationAuthority. Dispatches `InformationSourceRegistered`.
- `verify(): void` -- Transitions to Verified. Enforces INV-IS1 (cannot be simultaneously verified and unreliable). Dispatches `InformationSourceVerified`.
- `markUnreliable(): void` -- Transitions from Verified to Unreliable. Enforces INV-IS1. Dispatches `InformationSourceMarkedUnreliable`.
- `deprecate(): void` -- Transitions to Deprecated (terminal). Enforces INV-IS2. Dispatches `InformationSourceDeprecated`.

**State machine:** Registered -> Verified <-> Unreliable; any non-deprecated -> Deprecated (terminal). Deprecated is terminal. A source can oscillate between Verified and Unreliable (a source having technical problems may be fixed), but once Deprecated it cannot return.

**Cross-aggregate interactions:** Independent aggregate root (ND-5/ADR-22). No institution_id FK. authority_id BIGINT NULL FK → education_authorities — nullable; NULL means the source is not published by an EducationAuthority. InformationSource belongsTo EducationAuthority (nullable). Trust cascade -- when a source is marked unreliable or deprecated, all information derived from it must have its trust signal recalculated. This is eventual consistency via event listener.

### Child Entities -- No Independent Behaviour

**Admission Policy** has no domain operations independent of its parent. All state transitions (Draft -> Published, Published -> Superseded, Published -> Withdrawn) are driven by parent operations (`publishAdmissionPolicy`). Published policies are immutable -- if requirements change, a new policy is published for the same cycle, which supersedes the previous one. This is a critical domain rule: admission requirements must be stable once published because candidates make decisions based on them. **AdmissionPolicy's polymorphic parent is ProgrammeInstance or Institution** (not Programme). This ensures admission criteria are scoped to the specific offering -- the same programme's Online instance and OnCampus instance can have different admission rules and cut-off marks.

**Eligibility Policy** follows the same pattern as Admission Policy but within the Scholarship aggregate. Driven by `publishEligibilityPolicy`. No shared abstraction with Admission Policy -- the rules are semantically different (admission requirements vs eligibility criteria), they gate different operations (programme admission vs scholarship application), and they live on different aggregates.

**Accreditation Record** is an immutable child entity. Each call to `recordAccreditation` creates a new record; no record is ever modified. The parent entity derives its current accreditation status from its collection of records: the most recent record from each relevant authority determines the current status. This is the event-sourcing pattern applied to accreditation -- we append, we never mutate.

**ProgrammeInstance** is a child entity of Programme. Its status transitions (Admitting -> Suspended -> Admitting, Admitting/Suspended -> Discontinued) are driven by parent operations or application-level Actions. When the parent Programme is discontinued, all ProgrammeInstances cascade to Discontinued (INV-PI2). ProgrammeInstance carries the concrete offering data that varies per instance: campus, delivery mode, academic year, capacity, tuition, and duration (if different from Programme default). The Programme itself retains only template-level attributes (name, award level, admission mode, default duration).

**ProgrammeInstance domain methods:**
- `publishAdmissionPolicy(cycleId, rules): AdmissionPolicy` -- Creates/supersedes admission policy for this instance for the given cycle. Enforces INV-PI3 (one active policy per cycle per instance). Dispatches `ProgrammeInstanceAdmissionPolicyPublished`.
- `addCutOffMark(cycleId, pathway, value, sourceId): CutOffMark` -- Records a cut-off mark for this instance for the given cycle and pathway. Cut-off marks are scoped to the instance (different for Online vs. OnCampus).

### Supporting Entities -- Minimal Behaviour

**Qualification** has one domain behaviour: `deprecate()` -- marking a qualification as no longer actively used, which prevents it from being referenced in new admission/eligibility policies. All other operations are reference data CRUD (application services). Dispatches `QualificationDeprecated`.

**Scholarship Provider** has one marginal behaviour: `deprecate()` -- preventing new scholarships from referencing this provider. The entity is the weakest in the model; it exists primarily as a referential integrity guard for Scholarship's provider reference.

**Education Authority** has one marginal behaviour: `deprecate()` -- preventing new references from entities that require an active authority. The jurisdiction validation (INV-I2, INV-P5, INV-10) is an application-layer query on reference data, not a domain operation on the Authority.

**Campus** has marginal behaviour: `activate()`, `deactivate()`, `plan()` -- status transitions via the CampusStatus enum (Active, Inactive, Planned). A Campus in Active status is required before ProgrammeInstances can reference it. When a Campus is deactivated, existing ProgrammeInstances remain but new ones cannot be created referencing the inactive campus. Campus is managed via Filament CRUD as a supporting entity belonging to Institution. The is_primary flag and INV-CAMP1 (at least one primary campus per institution) are enforced by the application layer.

---

## 9. Aggregate Boundaries

Each aggregate boundary is justified by the invariants it protects, the business operations it owns, and the consistency it must maintain. The boundaries were determined through pragmatic DDD evaluation (12-domain-discovery-topic2-revision.md) and confirmed by the frozen baseline audit (21-domain-architecture-frozen-baseline.md, Section 3).

### Aggregate 1: Educational Institution

**Contains:** Educational Institution (root), Admission Policy (child -- institutional-level), Accreditation Record (child -- institutional-level)

**Consistency boundary:** The institution's name, operational status, active policies, and accreditation records must be internally consistent. Changing an institution's type has cascading effects on which authorities can accredit it and which award levels are valid for its programmes. The one-active-policy-per-cycle invariant (INV-I3) requires atomic supersession -- the Programme never has zero or two active policies for a cycle during the operation. Campus entities (supporting) belong to the Institution but are managed as reference data via Filament CRUD; the INV-CAMP1 invariant (at least one primary campus) is enforced at the application layer.

**Justification:** Five invariants (INV-I1 through INV-I5), seven domain operations, strong consistency boundary. Demotion to non-aggregate would violate INV-I3 (one active policy per cycle). An institution is discussed as a standalone entity by domain experts. Its lifecycle transitions (Operational -> Suspended -> Closed) are significant business events with cascading effects on programmes and scholarships.

**What it must NOT know:** Programme details (beyond ownership FK), Scholarship details, Search index state, Read model state, Which Information Sources reference it.

### Aggregate 2: Programme

**Contains:** Programme (root), Accreditation Record (child -- programme-level), Programme Instance (child -- concrete offering; Admission Policy is a child of ProgrammeInstance)

**Consistency boundary:** A programme's accreditation records, programme instances, and lifecycle state must be internally consistent. Admission policies are now scoped to ProgrammeInstance (not Programme) — each instance's admission policies must be internally consistent (one active policy per cycle, INV-PI3). Publishing a new admission policy for a cycle on an instance must supersede the previous one atomically. The programme's admission status is derived from its lifecycle state combined with the cycle's current phase and the existence of an active policy on at least one instance (INV-P3), but this derivation is a read-model concern, not a consistency boundary of the write model. ProgrammeInstance status transitions are bounded by the Programme's own status -- if the Programme is discontinued, all instances cascade to Discontinued (INV-PI2).

**Why not a child entity of Institution?** A university may offer 50-100+ programmes. Embedding all programmes within the Institution aggregate would create an unbounded aggregate that cannot enforce meaningful consistency. More importantly, the Programme has its own invariants (one active policy per cycle, admission status derivation) that the Institution does not protect. The Institution ensures programmes belong to it; the Programme ensures its own admission consistency.

**What it must NOT know:** Scholarship targeting, Search index state, Student eligibility, Institution's other programmes.

### Aggregate 3: Scholarship

**Contains:** Scholarship (root), Eligibility Policy (child)

**Consistency boundary:** The scholarship's eligibility policy, application period, and lifecycle state must be internally consistent. Applications cannot be opened without a published eligibility policy (INV-S5). The application deadline must be set before opening applications. The one-active-policy-per-period invariant (INV-S2) requires atomic supersession.

**What it must NOT know:** Programme details (beyond targeting FK), Student applications, Search index state.

### Aggregate 4: Admission Cycle

**Contains:** Admission Cycle (root) -- no child entities

**Consistency boundary:** The cycle's phases must follow the correct sequence (INV-C2). The cycle's dates must be temporally consistent. Phase advance is irreversible -- once a cycle has moved to the Examination phase, it cannot return to Registration. The phase sequence itself is data (configurable per authority and country), but the sequential ordering invariant is the domain concept.

**What it must NOT know:** Which policies reference it, Programme admission status, Search index state.

### Aggregate 5: Information Source

**Contains:** Information Source (root) -- no child entities

**Consistency boundary:** A source's verification status must be internally consistent. A source cannot be simultaneously verified and unreliable (INV-IS1). Once deprecated, a source cannot be re-verified (INV-IS2). Marking a source unreliable affects trust for all entities whose data was derived from that source -- this cascading effect requires the source to be its own consistency boundary so that its status change is atomic.

**What it must NOT know:** Which entities reference it, Trust signal computation, Search index state.

### Cross-Aggregate Interaction Summary

Only one interaction requires a domain service: **Institution Merge** (InstitutionMerger), which coordinates across two Institution aggregates and all their Programme aggregates within a single transaction. All other cross-aggregate interactions are handled through: reference IDs (Programme holds cycle ID, Scholarship holds programme IDs), application-layer validation (jurisdiction check before `recordAccreditation`), and eventual consistency via domain events (trust signal recalculation, read model updates, search index updates).

---

## 10. Entity Relationships

The following relationships define how entities reference each other. All cross-aggregate references use IDs (not aggregate loading) to maintain boundary integrity. Relationships are classified by domain significance and cascade behaviour.

| Relationship | Cardinality | Domain Significance | Cascade Rules |
|-------------|-------------|---------------------|---------------|
| Institution hasMany Programme | 1:N | Ownership -- programme identity is institution-scoped (INV-P1) | Institution close cascades to programme discontinuation (via event). Institution merge reassigns programmes (via InstitutionMerger). |
| Institution hasMany Campus | 1:N | Multi-campus support -- each institution has one or more campuses | At least one Campus must be is_primary=true (INV-CAMP1). Campus status managed independently. |
| Institution hasMany AdmissionPolicy | 1:N | Institutional-level admission policies | Policies are child entities; superseded when new policy published for same cycle |
| Institution hasMany AccreditationRecord | 1:N | Institutional accreditation history | Records are immutable child entities; never deleted |
| Programme belongsTo Institution | N:1 | Ownership FK -- programme cannot exist without institution | FK constraint; reassignTo for merge |
| ProgrammeInstance hasMany AdmissionPolicy | 1:N | Instance-level admission policies — admission criteria scoped to offering | Same supersession pattern as institutional policies |
| Programme hasMany AccreditationRecord | 1:N | Programme-level accreditation | Same immutability pattern as institutional records |
| Programme hasMany ProgrammeInstance | 1:N | Concrete offerings of the programme | Programme discontinuation cascades to all instances (INV-PI2). Instance status bounded by Programme status. |
| ProgrammeInstance belongsTo Campus | N:1 | FK to the campus where the offering is located | Campus deactivation prevents new instances; existing unaffected |
| Campus belongsTo Institution | N:1 | FK to the owning institution | Institution close cascades to campus deactivation |
| Scholarship belongsTo ScholarshipProvider | N:1 | Provider is part of scholarship identity (INV-S1) | Provider deprecation prevents new scholarships; existing unaffected |
| Scholarship hasMany EligibilityPolicy | 1:N | Eligibility criteria for the scholarship | Same supersession pattern as admission policies |
| Scholarship targets Programme | M:N (unidirectional) | Applicability scoping -- which programmes the scholarship applies to | Programme discontinuation flags scholarship targeting (via event); targeting is eventual consistency |
| Scholarship targets Institution | M:N (unidirectional) | Applicability scoping at institution level | Same pattern as programme targeting |
| AdmissionPolicy belongsTo AdmissionCycle | N:1 | Policy applies to a specific cycle | Cycle closure does not delete policies; policies become historical |
| ProgrammeInstance hasMany CutOffMark | 1:N | Cut-off marks per instance per cycle per pathway | Cut-off marks are scoped to the instance (different for Online vs. OnCampus) |
| AdmissionCycle belongsTo EducationAuthority | N:1 | Authority defines the cycle and its scope | Authority deprecation prevents new cycles; existing unaffected |
| AccreditationRecord belongsTo EducationAuthority | N:1 | Authority granted the accreditation | Authority deprecation flags accreditation (via trust cascade) |
| Qualification belongsTo EducationAuthority | N:1 | Authority defines/awards the qualification | Authority deprecation flags qualification (via reference constraint) |
| Institution/ProgrammeInstance/AdmissionPolicy references InformationSource | N:1 | Provenance -- where the information came from | Source deprecation triggers trust signal cascade (eventual consistency) |
| InformationSource belongsTo EducationAuthority (nullable) | N:1 | Authority that published the source | NULL authority_id = source not published by an EducationAuthority (ND-5/ADR-22) |
| Programme belongsTo Discipline | N:1 | Search/product classification -- discipline is a primary facet and SEO dimension | Discipline is reference data, not a domain entity; FK is nullable to support unclassified programmes during data import |

**Polymorphic relationships.** Admission Policy uses a polymorphic `belongsTo` (Governable: ProgrammeInstance or Institution). This is because admission criteria are scoped to the specific offering (instance) — the same programme's Online instance and OnCampus instance can have different admission rules and cut-off marks. Accreditation Record uses a polymorphic `belongsTo` (Accreditable: Programme or Institution). These are modelled per ADR-11 -- polymorphic relationships for policies and accreditation because the parent entity type varies, while separate relationships for all other entities where the target type is fixed.

**Key domain rule:** All cross-aggregate references are ID-based. No aggregate loads another aggregate to perform a write operation (except InstitutionMerger, which is the single domain service that coordinates across aggregates). Downstream effects propagate via domain events with eventual consistency.

---

## 11. Architectural Normalizations

The following normalizations from the architectural review (14-architectural-review-global-domain.md) have been applied throughout the domain model. Each finding is identified by its F-number from the review.

| Finding | Original | Normalized | Type |
|---------|----------|-----------|------|
| F1 | "Government Education Agency" | **Education Authority** | Entity rename |
| F2 | INV-I2, INV-P5: agency determined by institution type (Nigerian regulatory structure) | **Granting authority must have jurisdiction over the accredited entity** | Invariant generalization |
| F3 | INV-2: "granted by exactly one Government Education Agency" | **"granted by exactly one Education Authority"** | Invariant rename + generalization |
| F4 | INV-9: "recognized by at least one authority in the Nigerian education system" | **"recognized by at least one Education Authority"** | Remove Nigeria-scoping |
| F5 | INV-10: "appropriate type for granting Agency" | **"subject within granting authority's jurisdiction"** | Invariant generalization |
| F6 | Institution Type with hard-coded Nigerian values | **Keep value object; specific values are data, not domain structure** | Clarify scope |
| F7 | Award Level with Nigerian-specific values (ND, HND, NCE) | **Keep value object; specific values are data** | Clarify scope |
| F8 | Qualification identity scoped as "national" | **Qualification identity is authority-scoped** | Identity scope generalization |
| F9 | Admission Cycle phases modeled on JAMB UTME process | **Phase names and count are configuration data; sequential ordering invariant is universal** | Lifecycle generalization |
| F10 | Cycle scope "national/institutional/programme" hard-coded | **Cycle scope determined by defining authority** | Identity scope generalization |
| F11 | "Cut-off Mark" as separate value object | **Absorbed into Qualification Threshold**; "cut-off mark" is Nigerian terminology for one type of threshold | Value object consolidation |
| F12 | Nigerian instances used as definitions | **Express concepts universally; use Nigerian instances as examples** | Documentation correction |
| F13 | "Educational Authority" shared abstraction previously rejected | **Renaming is not shared abstraction; no contradiction with prior rejection** | Clarify |
| F14 | Pragmatic DDD drove classifications | **Classifications are domain-justified; DDD was tiebreaker** | Methodology confirmation |

**Impact of F1 (Education Authority rename).** The rename from "Government Education Agency" to "Education Authority" reflects that the entity covers all authoritative bodies in education -- governmental (JAMB, NUC), non-governmental (ABET, AACSB), and hybrid (QAA). Whether a specific authority is governmental becomes an attribute (`ProviderType::Government` for Scholarship Provider, `AuthorityType` for Education Authority), not the defining characteristic. Examples: Nigeria -- JAMB (admissions), NUC (university accreditation), WAEC (examination); Global -- ABET (US engineering accreditation), UCAS (UK admissions), QAA (UK quality assurance), GTEC (Ghana tertiary education), KUCCPS (Kenya admissions).

**Impact of Admission Pathway demotion.** Admission Pathway was provisionally a supporting entity but was demoted to Value Object (within AdmissionPolicy) during behaviour discovery (15-domain-discovery-topic4-behaviour.md, Section 13). The pathway is a discriminator that identifies which set of admission rules applies -- it has identity within the context of a policy (pathway name + defining authority) but no autonomous lifecycle, no invariants, and no behaviour. This reduces the entity count from 12 to 11 and increases the genuine VO count from 11 to 12 (total VOs are 29 as the enum count was concurrently corrected to 17 including CampusStatus).

**Impact of ProgrammeInstance + Campus addition.** ProgrammeInstance was introduced to separate the abstract programme template (Programme) from its concrete offerings (ProgrammeInstance), which vary by campus, delivery mode, academic year, and tuition. This resolves the conflation where a single Programme entity tried to represent both the template and the offering. Campus was introduced to enable multi-campus institutions; previously an Institution had a single Location VO, which could not represent institutions with multiple campuses (e.g., University of Lagos at Akoka and Idi-Araba). These additions increase the entity count from 11 to 13 (4 child entities, 4 supporting entities), enum count from 16 to 17 (add CampusStatus), and table count from 58 to 61 (add campuses + programme_instances + pending_revisions).

---

## 12. Reference Data: Disciplines

The `disciplines` table is a managed reference table for programme classification. It is not a domain entity -- it has no lifecycle, no invariants, and no domain operations beyond CRUD. However, once established it becomes de facto canonical because it drives faceted search (the most important browse dimension), SEO landing pages (`/programmes?discipline={slug}`), programme organisation in admin, and external source mapping during data import.

**Structure:**

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Primary key |
| `name` | VARCHAR(100) | Display name (e.g., "Engineering", "Medical Sciences") |
| `slug` | VARCHAR(100) | URL-safe identifier, unique |
| `description` | TEXT, nullable | Optional description |
| `sort_order` | INTEGER | Display ordering |
| `created_at` | TIMESTAMP | Creation timestamp |
| `updated_at` | TIMESTAMP | Last update timestamp |

**Design decisions:**

- **Flat for MVP.** No `parent_id` column. Hierarchy adds complexity without proportional user value for MVP. Nigerian students search for "Engineering", not "Engineering → Civil Engineering". Programme names provide specificity. `parent_id` can be added in Phase 2 without breaking changes.
- **Single discipline per programme.** One `discipline_id` FK on `programmes`, not a M:N pivot. Nigerian programmes have one primary classification. Interdisciplinary programmes pick their primary discipline. Secondary classifications can use Spatie tags (Phase 2).
- **Not an enum.** Discipline values are data that will grow and be reorganised by the content team. An enum would require code deployment for every change.
- **Managed via Filament CRUD.** The content team manages discipline values through the admin panel. Initial seed values are established during implementation when the first programme data is imported and classification decisions are made against real data.
- **External source mapping** (e.g., JAMB's "Engineering & Technology" → StudyNexus's "Engineering") lives in import adapter code/config for MVP. A `source_discipline_mappings` table can be added in Phase 2 if the number of sources grows.

---

## 13. Cut-Off Mark History

The `cut_off_marks` table stores admission cut-off marks per programme per admission cycle per pathway. This is a structured query model for cross-cycle cut-off data, not a domain entity -- it has no lifecycle, no invariants, and no domain operations. It exists to serve a core user need: students use previous years' cut-offs to estimate their chances for the upcoming admission cycle.

**Structure:**

| Column | Type | Purpose |
|--------|------|---------|
| `id` | BIGINT | Primary key (BIGINT per ADR-19/BD-1) |
| `programme_instance_id` | BIGINT, FK | References `programme_instances(id)`, ON DELETE CASCADE |
| `admission_cycle_id` | BIGINT, FK | References `admission_cycles(id)`, ON DELETE CASCADE |
| `pathway` | VARCHAR(50) | Admission pathway value (e.g., 'utme', 'direct_entry', 'ijmb', 'jupeb') |
| `value` | INTEGER | The cut-off score |
| `source_id` | BIGINT, FK nullable | References `information_sources(id)`, ON DELETE SET NULL — attribution only, not provenance chain (see source_id ON DELETE distinction below) |
| `created_at` | TIMESTAMP | Creation timestamp |
| `updated_at` | TIMESTAMP | Last update timestamp |

**Unique constraint:** `(programme_instance_id, admission_cycle_id, pathway)` — one cut-off per programme instance per cycle per pathway.

**Cross-cycle history (Scenario A):** Multiple rows per programme instance, one per cycle. A programme instance with cut-offs of 150 (2024/2025), 180 (2025/2026), and 200 (2026/2027) has three rows. The programme detail page shows the current cycle's cut-off prominently and previous cycles' values collapsed below.

**Intra-cycle corrections (Scenario B):** If a cut-off changes within a cycle (e.g., institution adjusts from 150 to 200), the row is UPDATED (not inserted). The old value is captured by `spatie/laravel-activitylog`. Intra-cycle changes are corrections, not historical facts. Users need one answer per cycle, not a revision history within that cycle. MVP audit history (via activity log) is not the same as a user-facing timeline of historical values. If future product requirements require users to see effective historical values within a cycle, explicit domain-specific versioning can be introduced later.

**No generic versioning framework.** No event sourcing. No polymorphic history infrastructure. The `cut_off_marks` table is the smallest correct model for this specific need.

**source_id ON DELETE behavior distinction:** The three tables referencing `information_sources` via `source_id` have intentionally different ON DELETE behaviors:

- **field_provenance.source_id** → ON DELETE RESTRICT: The source IS the reason for the provenance record. Deleting the source destroys the audit chain's integrity.
- **external_identifiers.source_id** → ON DELETE RESTRICT: The source validates the identifier's origin. Losing it prevents verification.
- **cut_off_marks.source_id** → ON DELETE SET NULL: The source is attribution metadata only. cut_off_marks is a query model, not a domain entity. If the source is deprecated, the cut-off value (integer) remains valid and useful to students.
- **cut_off_marks.programme_instance_id** → ON DELETE CASCADE: When a ProgrammeInstance is deleted, its cut-off marks are no longer meaningful and should be removed. This is consistent with the query model nature of cut_off_marks.

---

## 14. External Identifiers (BD-5/ADR-21)

No jamb_code, nuc_code, nbte_code, ncce_code columns exist on canonical entities. Instead, a generic `ExternalIdentifier` infrastructure entity stores external codes assigned by education authorities:

| Column | Type | Purpose |
|--------|------|---------|
| `id` | BIGINT PK | Primary key |
| `entity_type` | VARCHAR(255) NOT NULL | Polymorphic entity type (e.g., 'institution', 'programme') |
| `entity_id` | BIGINT NOT NULL | Polymorphic entity ID |
| `authority_id` | BIGINT NOT NULL FK | References `education_authorities(id)` — the assigning authority |
| `identifier_type` | VARCHAR(100) NOT NULL | Type of identifier (e.g., 'jamb_code', 'nuc_code') |
| `identifier` | VARCHAR(255) NOT NULL | The external identifier value |
| `status` | VARCHAR(50) NOT NULL DEFAULT 'active' | Lifecycle: active, retired, superseded |
| `valid_from` | TIMESTAMP NOT NULL DEFAULT NOW() | When identifier became valid |
| `valid_until` | TIMESTAMP NULL | Temporal validity end (NOT an active-state mechanism) |
| `source_id` | BIGINT NULL FK | References `information_sources(id)` — the observing source; NULL = editorial entry |
| `replaced_by_id` | BIGINT NULL FK | Self-referencing → `external_identifiers(id)` for supersession chains |
| `retirement_reason` | TEXT NULL | Why the identifier was retired |
| `metadata` | JSONB NULL | Additional structured metadata |
| `created_at` | TIMESTAMP | Creation timestamp |
| `updated_at` | TIMESTAMP | Last update timestamp |

**Design decisions:**
- authority_id is NOT NULL — every external identifier is assigned by an authority.
- source_id is nullable — NULL means the identifier was entered editorially (not observed from a source).
- No is_primary flag — primacy is derived from status and valid_from/valid_until.
- Active uniqueness enforced via partial unique indexes:
  - INV-EI1 (global): UNIQUE (authority_id, identifier_type, identifier) WHERE status = 'active' — no two active identifiers from the same authority share the same type+value combination across all entities.
  - INV-EI2 (per-entity): UNIQUE (entity_type, entity_id, authority_id, identifier_type) WHERE status = 'active' — a given entity has at most one active identifier of a given type from a given authority.
- Historical identifiers preserved — superseded identifiers remain for audit trail.
- status controls lifecycle (active/retired/superseded), valid_until is for temporal validity.

**Self-referencing FK handling (replaced_by_id, superseded_by_id):**
- replaced_by_id and superseded_by_id are NULL for the first (current) record in any chain.
- ON DELETE RESTRICT for both — cannot delete a row that is referenced by another row's replaced_by_id/superseded_by_id.
- No circular chains — application logic ensures A → B → C (never A → B → A).

---

## 15. Hybrid Provenance Model (ND-4/ADR-23)

### 15.1 Entity-Level Provenance JSONB

Every domain entity carries a `provenance` JSONB column for lightweight whole-entity source metadata. This column does NOT include import_batch_id (staging is ephemeral by design). Typical structure:

```json
{
    "source_type": "jamb_official",
    "source_url": "https://jamb.gov.ng/2026-brochure.pdf",
    "acquired_at": "2026-08-08T10:00:00Z",
    "last_verified_at": "2026-08-08T10:00:00Z",
    "trust_level": "Official"
}
```

### 15.2 Field-Level Provenance (field_provenance table)

The `field_provenance` table provides selective source attribution, conflict tracking, and value history for individual fields:

| Column | Type | Purpose |
|--------|------|---------|
| `id` | BIGINT PK | Primary key |
| `entity_type` | VARCHAR(255) NOT NULL | Polymorphic entity type |
| `entity_id` | BIGINT NOT NULL | Polymorphic entity ID |
| `field_name` | VARCHAR(255) NOT NULL | The field being attributed |
| `source_id` | BIGINT NULL FK | References `information_sources(id)`; NULL = editorial assertion |
| `observed_value` | TEXT | The value as observed from this source |
| `confidence` | SMALLINT NULL | Confidence score (nullable for retroactive records) |
| `verification_status` | VARCHAR(50) NOT NULL DEFAULT 'unverified' | Enum: unverified, verified, disputed, superseded, stale |
| `observed_at` | TIMESTAMP NOT NULL | When the value was observed |
| `superseded_at` | TIMESTAMP NULL | When this observation was superseded |
| `superseded_by_id` | BIGINT NULL FK | Self-referencing → `field_provenance(id)` |
| `retroactive` | BOOLEAN NOT NULL DEFAULT FALSE | Whether this is a retroactive record |
| `created_at` | TIMESTAMP | Creation timestamp |
| `updated_at` | TIMESTAMP | Last update timestamp |

**Design decisions:**
- No is_active — derive active observations from `superseded_at IS NULL`.
- No value_hash — observed_value is stored directly.
- No is_verified boolean — use verification_status enum.
- No primary_source_id on entities — provenance is captured via entity-level JSONB + field_provenance rows.
- source_id is nullable — NULL means editorial assertion (no external source).
- ON DELETE RESTRICT for source_id references — provenance records must not silently lose their source link.
- field_provenance is NOT a complete observation log — it captures only provenance-whitelisted fields.

### 15.3 80/20 Provenance Field Model

Provenance is NOT recorded for every data point. The 80/20 model focuses effort on fields that matter most:

| Category | Field Count | Provenance Policy | Examples |
|----------|-------------|-------------------|----------|
| **Category A** | 5 fields | Always provenance — every observation recorded | name, type, status, accreditation_status, cut_off_mark |
| **Category B** | 6 fields | Provenance on conflict — record when sources disagree | founded_year, location, website, admission_requirements, application_deadline, amount |
| **Category C** | All others | No provenance — not tracked in field_provenance | description, slug, is_published, sort_order |

**Total provenance-whitelisted fields: 11 (Category A: 5 + Category B: 6).**

Category A fields always have field_provenance records because they are high-stakes — incorrect values directly affect user decisions. Category B fields only get field_provenance records when a conflict is detected between sources. Category C fields are lower-stakes or editorial in nature and do not warrant field-level provenance tracking.
