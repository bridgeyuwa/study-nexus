# StudyNexus V4.2 — Developer Handoff

**Version:** 4.2
**Date:** 2026-08-19
**Status:** REMEDIATED — All 5 BLOCKERs and 11 HIGH findings resolved; ready for implementation
**Supersedes:** V4.1 (adversarial audit NO-GO), V2.0 (initial frozen baseline)

---

## Quick Start for the Implementation Team

1. **Read this README** to understand the V4.2 state and how to navigate the package.
2. **Read `00-ORIENTATION/AUTHORITY-HIERARCHY.md`** to understand which documents are authoritative and which are historical.
3. **Read the canonical documents in order** (01 through 06) — they are the single source of truth.
4. **Read `V4.2-REMEDIATION-REPORT.md`** to understand exactly what changed from V4.1 and why.
5. **Do NOT treat `archive/` as authoritative** — those are historical discovery artifacts, not current specifications.
6. **Write migrations** using canonical documents as your guide. All schema-level decisions are resolved.

---

## Mandated Technology Stack

| Component | Version | Notes |
|-----------|---------|-------|
| PHP | 8.5+ | |
| Laravel | ^13.0 | |
| PostgreSQL | 16+ | Primary database; FTS sole V1 search engine |
| Redis | 7+ | Cache, queues, sessions |
| Filament | v5 | Admin panel ONLY — never on public site |
| Livewire | v4 | Full-stack framework for public site |
| Laravel Fortify | ^1.x | Auth backend (NOT Breeze) |
| Flux Pro | ^1.x | UI component library for Livewire |
| Tailwind CSS | v4 | Utility-first CSS; OKLCH color space mandated |
| Alpine.js | ^3.x | Lightweight client-side interactivity |
| spatie/laravel-activitylog | ^5.0 | Frozen; audit trail post-approval |
| spatie/laravel-permission | ^6.x | RBAC (11 roles) |

### Hard Constraints

- **Auth stack**: Laravel Fortify + Livewire + Flux Pro. **Laravel Breeze is NOT used.**
- **Admin panel**: Filament v5 on admin domain ONLY. **Filament NEVER on public site.**
- **Search V1**: PostgreSQL Full-Text Search. **Typesense is post-MVP only.**
- **Color system**: OKLCH color space. **No HEX or HSL color codes.** Use semantic Tailwind classes (bg-surface, border-border, etc.).
- **Idempotent import**: PostgreSQL `ON CONFLICT DO UPDATE` keyed on `external_identifiers(source_id, external_code, entity_type)`. Fuzzy matching restricted to staging only.
- **URL contract**: Slugs for all public-facing URLs (SEO); `public_id` UUID for internal routing/API/JSON payloads only — never in public-facing URLs.
- **Pending revisions**: Dedicated `pending_revisions` table. Organization Portal saves edits as PendingRevisions → Admin approves via Filament → data written to canonical tables → activitylog records audit trail.

---

## Package Directory Structure

```
PRE-IMPLEMENTATION-BASELINE-V2/
├── README.md                                  (this file — V4.2 developer quick-start)
├── MANIFEST.md                                (SHA-256 file inventory)
├── V4.2-REMEDIATION-REPORT.md                 (executive summary of all 16 findings resolved)
├── GLOSSARY.md                                (domain glossary for V4.2)
├── PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md   (original V2 baseline creation report)
│
├── 00-ORIENTATION/                            (navigation & authority metadata)
│   └── AUTHORITY-HIERARCHY.md                 (Tier classification & document authority)
│
├── canonical/                                 (Tier 1 — CANONICAL, AUTHORITATIVE)
│   ├── 01-business.md                         Business context, users, capabilities
│   ├── 02-decisions.md                        ADRs, approved decisions (ADR-18 Resolved)
│   ├── 03-domain.md                           Domain model (ProgrammeInstance owns admission)
│   ├── 04-architecture.md                     Architecture (publication predicates, URL contract)
│   ├── 05-implementation.md                   Implementation blueprint (61 tables, migrations)
│   └── 06-data-acquisition.md                 Import pipeline (ON CONFLICT DO UPDATE)
│
├── product-experience/                        (Tier 2 — Product Experience)
│   ├── PRODUCT-EXPERIENCE-DISCOVERY.md        Product discovery findings
│   ├── PRODUCT-EXPERIENCE-ARCHITECTURE.md     Product architecture
│   ├── FIRST-VERTICAL-SLICE-UX.md             UX spec (PostgreSQL FTS, slug URLs)
│   └── FIRST-VERTICAL-SLICE-UI.md             UI spec (OKLCH colors, Flux Pro components)
│
├── governance/                                (Tier 4 — Governance & Audit)
│   ├── DISCOVERY-CLOSURE.md                   Discovery closure (Typesense post-MVP)
│   ├── CANONICAL-AMENDMENT-REPORT.md          V1→V2 amendment report
│   ├── CANONICAL-UPDATE-REPORT.md             Canonical update records
│   ├── CANONICAL-CONSISTENCY-AUDIT.md         Consistency audit (Typesense scoped)
│   ├── FINAL-LINEAGE-SEMANTICS-RESOLUTION.md  Lineage semantics
│   ├── FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md  Schema review
│   ├── FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md  Adversarial review
│   ├── FOUNDATIONAL-DECISIONS-BRIEF.md        Decisions brief
│   ├── ADVERSARIAL-DECISION-REVIEW.md         Decision review
│   └── SECOND-ORDER-ARCHITECTURE-REVIEW.md    Second-order review
│
└── archive/                                   (Tier 6 — HISTORICAL, NON-AUTHORITATIVE)
    └── ... (30 historical discovery/review documents)
```

---

## Authority Hierarchy

When documents conflict, **higher-tier documents always prevail**:

| Tier | Name | Directory | Authority |
|------|------|-----------|-----------|
| 1 | Canonical | `canonical/` | **Highest** — single source of truth for domain, architecture, implementation |
| 2 | Product Experience | `product-experience/` | Conforms to Canonical; defines UX/UI/product details |
| 3 | Implementation Plan | (within `canonical/05-implementation.md`) | Derives from Canonical; specific migration/code guidance |
| 4 | Governance | `governance/` | Audit, review, and amendment records |
| 5 | Research | (none in current package) | Supporting research |
| 6 | Historical | `archive/` | **Lowest** — historical evidence only, never authoritative |

**Rule:** If any document contradicts a Canonical document, the Canonical document wins.

---

## V4.2 Canonical Counts

| Concept | Count | Notes |
|---------|-------|-------|
| Domain Entities | 13 | 5 AR + 4 child + 4 supporting |
| Infrastructure Entities | 2 | ExternalIdentifier, FieldProvenance |
| Value Objects | 29 | 12 genuine VOs + 17 PHP Backed Enums |
| Enums | 17 | 3 behavioural + 14 pure |
| Domain Events | 29 | |
| Actions | 20 | |
| RBAC Roles | 11 | |
| Database Tables | 61 | 60 + pending_revisions (V4.2 addition) |
| Staging Entities | 2 | ImportBatch, PendingImport (ephemeral, not counted) |

---

## Key Domain Model Decisions (V4.2)

These are the critical decisions that changed from V4.1 and must be reflected in all implementation:

1. **AdmissionPolicy belongs to ProgrammeInstance**, not Programme. Cut-off marks are per-instance (Online vs OnCampus can have different requirements). The `admission_requirements` column is removed from the `programmes` table.
2. **Publication predicate**: A Programme is visible in search iff `programmes.is_published = TRUE AND EXISTS ProgrammeInstance.is_published = TRUE`. One card per Programme, with aggregated instances.
3. **URL contract frozen**: Slugs for public SEO URLs; `public_id` UUID for internal routing/API only.
4. **Pending revisions**: Dedicated `pending_revisions` table (not Activitylog). Activitylog records audit trail post-approval.
5. **Idempotent import**: PostgreSQL `ON CONFLICT DO UPDATE` keyed on `external_identifiers` unique composite index (INV-EI1). Fuzzy matching restricted to staging only.

---

## What Changed From V4.1

The V4.1 package received a NO-GO verdict from an independent adversarial audit due to change-propagation failures and incomplete domain modeling. V4.2 surgically remediated all 5 BLOCKERs and 11 HIGH findings without redesigning the system. See `V4.2-REMEDIATION-REPORT.md` for full details.

**Modified files (10):** canonical/02-decisions.md, canonical/03-domain.md, canonical/04-architecture.md, canonical/05-implementation.md, canonical/06-data-acquisition.md, governance/CANONICAL-CONSISTENCY-AUDIT.md, governance/DISCOVERY-CLOSURE.md, product-experience/FIRST-VERTICAL-SLICE-UI.md, product-experience/FIRST-VERTICAL-SLICE-UX.md, MANIFEST.md

**Unchanged files (44):** All archive/ files, canonical/01-business.md, and unchanged governance/product-experience files.
