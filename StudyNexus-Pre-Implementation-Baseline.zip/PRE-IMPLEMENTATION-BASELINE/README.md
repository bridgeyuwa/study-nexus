# StudyNexus — Pre-Implementation Baseline

## Purpose

This directory is the **frozen, immutable pre-implementation baseline** for the StudyNexus project. It captures the complete state of all authoritative documentation **immediately before any implementation work begins**.

## Snapshot Date

**2026-08-10T00:45:00+01:00** (Africa/Lagos)

## Status

- **Discovery:** Closed. All business, domain, architecture, and data acquisition discovery is complete.
- **Domain & Architecture:** Frozen. Canonical documents are the authoritative source of truth.
- **Product Experience, UX, and UI:** Specified. The first vertical slice UX and visual UI designs are included.
- **Implementation:** Has **not** yet begun. No Laravel application, migrations, models, or components exist.

## Directory Structure

```
PRE-IMPLEMENTATION-BASELINE/
├── canonical/                    # 6 canonical specification documents
│   ├── 01-business.md            # Business vision, personas, workflows
│   ├── 02-decisions.md           # ADRs, resolved open questions, decisions
│   ├── 03-domain.md              # Domain model: entities, VOs, events, actions, enums
│   ├── 04-architecture.md        # Platform architecture, TALL stack, search, SEO
│   ├── 05-implementation.md      # Implementation blueprint, tables, packages, order
│   └── 06-data-acquisition.md    # Data acquisition pipeline, staging, ingestion
│
├── product-experience/           # 3 product/UX/UI specification documents
│   ├── PRODUCT-EXPERIENCE-ARCHITECTURE.md   # Experience domains, journeys, information architecture
│   ├── FIRST-VERTICAL-SLICE-UX.md           # UX specification for the first vertical slice
│   └── FIRST-VERTICAL-SLICE-UI.md           # Visual UI specification (design tokens, components, screens)
│
├── governance/                   # 2 governance/provenance documents
│   ├── DISCOVERY-CLOSURE.md      # Final discovery closure — all decisions resolved
│   └── CANONICAL-UPDATE-REPORT.md # Report of canonical updates during reconciliation
│
└── archive/                      # 31 historical (non-authoritative) documents
    └── ...                       # Superseded discovery drafts, reviews, and analyses
```

## Authority

### Canonical Documents — Authoritative

The 6 documents in `canonical/` are the **authoritative source of truth** for implementation. Any implementation that contradicts these documents must be escalated, not silently resolved.

### Product Experience Documents — Authoritative for UX/UI

The 3 documents in `product-experience/` define the approved user experience and visual design for the first vertical slice.

### Governance Documents — Authoritative for Provenance

The 2 documents in `governance/` record the formal closure of discovery and any canonical updates that were applied.

### Archive — Historical, Non-Authoritative

The documents in `archive/` are **historical only**. They represent earlier discovery drafts, reviews, and analyses that have been superseded by the canonical documents. They are preserved for reference and auditability but must **not** be treated as current authority.

**Canonical documents always override archived documents** where any conflict exists.

## Immutability

This baseline is **frozen**. Future implementation must not silently rewrite or modify these documents.

Any future architectural change must:

1. Be explicitly proposed through a change proposal protocol
2. Be recorded with rationale and impact analysis
3. Reference the specific canonical document and section being changed
4. Not retroactively modify this baseline snapshot

## Key Architectural Commitments (from canonical documents)

These commitments are preserved here as a quick reference. The canonical documents themselves are the authoritative source.

| Commitment | Value |
|---|---|
| Entities | 11 (5 aggregate roots + 3 child + 3 supporting) |
| Value Objects | 28 (12 domain + 16 PHP Backed Enums) |
| Domain Events | 29 |
| Actions | 20 |
| Enums | 16 |
| RBAC Roles | 11 |
| Framework | Laravel ^13.0 |
| PHP | 8.5 |
| Admin Panel | Filament v5 |
| Reactive UI | Livewire v4 |
| CSS | Tailwind CSS ^4.0 |
| UI Components | Flux |
| Search Engine | Typesense |
| Primary Database | PostgreSQL (canonical source of truth) |
| Search Projection | Typesense (read/search projection) |
| Publication Model | `is_published` + `published_at` (orthogonal to lifecycle) |
| Admission Pathway | Value Object (NOT an entity) |
| Discipline | Reference data (not enum, not hierarchy) |
| Cut-off History | `cut_off_marks` table with cross-cycle rows |
| Data Acquisition | External system, separated from application ingestion |
