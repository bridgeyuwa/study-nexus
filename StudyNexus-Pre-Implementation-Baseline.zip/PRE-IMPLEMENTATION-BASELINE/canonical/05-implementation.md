# StudyNexus -- Implementation Blueprint

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | CANONICAL IMPLEMENTATION BLUEPRINT |
| Hard Baseline | Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4 |
| Purpose | Single coherent implementation blueprint consolidating the pre-implementation blueprint, package audit, and reconciliation into one canonical document with all corrections applied |

> This document is the canonical implementation reference. It consolidates and corrects all prior documents. Where earlier documents conflict with this document, this document prevails. All canonical corrections -- entity count, VO count, enum count, package names, version constraints, and architectural decisions -- are applied throughout. No Laravel 12, Filament v3, or Livewire v3 instructions remain.

---

## 1. Platform Baseline

The platform baseline is non-negotiable. Every package, every migration, every code decision is evaluated against this baseline. There is no Laravel 12 fallback, no PHP 8.3 fallback, no Filament v3 fallback, and no Livewire v3 fallback. The implementation targets Laravel 13 because starting a new project on the current framework major avoids an upgrade cycle within the first year, PHP 8.5 provides performance and language improvements (readonly promoted constructors, fiber improvements, attribute enhancements), and Laravel 13's release cadence means it will receive security patches longer than Laravel 12.

### 1.1 Core Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| PHP | -- | 8.5+ | Required baseline; no fallback |
| Laravel | `laravel/framework` | ^13.0 | Current stable; all packages must be compatible |
| PostgreSQL | -- | 16+ | Primary data store (ADR-01) |
| Redis | -- | 7+ | Cache + queue driver |
| Typesense | -- | 29.x+ | Search engine (ADR-06); server v30.x latest stable |
| Node.js | -- | 22 LTS | Asset compilation (Vite) |

### 1.2 Frontend Stack (TALL)

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Tailwind CSS | `tailwindcss` | ^4.0 | Utility-first styling; v4.3.3 current |
| Alpine.js | `alpinejs` | ^3.x | Lightweight client-side interactivity; v3.15.12 current |
| Livewire | `livewire/livewire` | ^4.0 | Server-driven reactive UI; v4 is required for Laravel 13 |
| Flux | `livewire/flux` | ^1.0 | UI component library; supports Livewire v4 |

### 1.3 Admin Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Filament | `filament/filament` | ^5.0 | Admin panel framework; v5 designed for Livewire v4 + Laravel 13 + PHP 8.5 |
| Rich Editor | Filament native RichEditor | Built-in | Replaces deprecated `filament/tiptap-editor` |

### 1.4 Auth and Testing

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Laravel Breeze | `laravel/breeze` | ^2.0 | Auth scaffolding; works on Laravel 13 (legacy positioning; Laravel 13 Livewire starter kit is alternative) |
| Laravel Sanctum | `laravel/sanctum` | ^4.0 | API token authentication for future API/mobile |
| Laravel Scout | `laravel/scout` | ^11.0 | Search driver abstraction; native Typesense driver confirmed |
| Pest | `pestphp/pest` | ^4.0 | Test framework |

### 1.5 Version Rationale

Livewire v4 (not v3) is required because Livewire v3 does not support Laravel 13. Filament v5 (not v3) is required because Filament v3 requires `illuminate/support ^10.45|^11.0|^12.0`, which is incompatible with Laravel 13. Filament v5 is designed specifically for Livewire v4 + Laravel 13 + PHP 8.5 and is the natural choice. The deprecated `filament/tiptap-editor` package is replaced by Filament v5's native Rich Editor component, which provides equivalent rich text editing capability without the external dependency. All code samples or instructions referencing Filament v3, Livewire v3, or Laravel 12 APIs are historical and must not be used in implementation.

---

## 2. Project Structure

The project follows the Laravel Beyond CRUD (LBC) architectural philosophy. This is not ceremonial DDD -- it is pragmatic domain-driven design that organizes code by domain concern rather than by technical layer, while avoiding unnecessary abstractions. There are no repository interfaces (ADR-04), no event sourcing (ADR-02), no SPA patterns (ADR-11), and no generic manager classes. Eloquent IS the repository. Domain events are plain PHP classes. Actions earn their complexity by meeting the explicit Action Criterion (multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization plus complex validation).

### 2.1 Namespace Architecture

```
app/
  Domain/
    Models/          (11 Eloquent models: 5 aggregates + 3 child entities + 3 supporting + 2 reference/query: Discipline, CutOffMark)
    Enums/           (16 PHP enums)
    ValueObjects/    (12 non-enum VOs)
    Events/          (29 domain events, plain PHP)
    Exceptions/      (domain exceptions)
    Services/        (InstitutionMerger only)
  Application/
    Actions/         (20 domain Actions + content/community actions)
    Queries/         (read-side query classes)
    DTOs/            (spatie/laravel-data request/response objects)
    Policies/        (Laravel authorization Policies)
    Listeners/       (event listeners for side effects)
  Content/
    Models/          (Article, Guide, EducationalResource, ExamPreparation)
    Concerns/        (HasSlug, IsPublishable, HasSeoMeta, HasMedia, etc.)
    Enums/           (ResourceType, PrepType, ContentStatus)
    Actions/         (content-specific actions)
    Queries/         (content-specific queries)
  Community/
    Models/          (Question, Answer, Comment, Vote, Report)
    Actions/         (community actions)
    Queries/         (community queries)
  StudyAbroad/
    Livewire/        (CountryPage, CompareDestinations, ScholarshipListing)
    Queries/         (study abroad queries)
  Reference/
    Models/          (Qualification, Country, Currency, etc.)
    Seeders/         (reference data seeders)
  Admin/
    Filament/        (admin panel resources, pages, widgets)
  Public/
    Livewire/        (interactive components for public site)
    Blade/           (Blade components & views)
    Controllers/     (thin controllers invoking Queries)
  Infrastructure/
    Search/          (Typesense/Scout config, UpdateSearchIndex listener)
    Integrations/    (third-party API clients)
    Persistence/     (Eloquent scopes, custom query builders)
```

### 2.2 Key Namespace Rules

Domain never imports Content. Domain never imports Community. Content may import Domain. Community may import Domain. StudyAbroad composes existing Domain and Content entities without introducing new aggregate roots or invariants. Reference models (Qualification, Country, Currency, etc.) are managed via Filament CRUD, not through domain Actions. The `App\Models\*` Laravel default namespace is NOT used for domain models; canonical location is `App\Domain\Models\*` (ADR from frozen baseline F1). Application-layer DTOs from `spatie/laravel-data` must not leak into the Domain layer -- they serve request/response mapping only.

### 2.3 Controllers (12)

| Controller | Routes |
|---|---|
| HomeController | / |
| InstitutionController | /institutions/{slug} |
| InstitutionProgrammeController | /institutions/{inst}/programmes |
| ProgrammeController | /institutions/{inst}/programmes/{prog} |
| ProgrammeDiscoveryController | /programmes, /programmes/{discipline} |
| ScholarshipController | /scholarships/{slug} |
| ArticleController | /news/{slug} |
| GuideController | /guides/{slug} |
| ResourceController | /resources/{slug} |
| ExamPrepController | /exam-prep/{slug} |
| StudyAbroadController | /study-abroad/* |
| CommunityQuestionController | /community/questions/* |

All controllers are thin: they invoke Query classes, pass results to Blade views, and return responses. Business logic lives in Actions (write) and Queries (read), never in controllers.

---

## 3. Domain Implementation

The frozen domain model from the canonical baseline is preserved intact. No frozen decision has been changed. The domain comprises 5 aggregate roots, 3 child entities, and 3 supporting entities (total: 11 entities). AdmissionPathway is a Value Object (no table, no separate entity), not a standalone entity with its own persistence. This section details each entity's implementation, migration schema, Eloquent relationships, and Action class signatures.

### 3.1 Aggregate Roots (5)

**Institution** -- The core entity. Name uniqueness within country; accreditation validity enforced as invariant. Migration: `institutions` table with columns for name, slug, type (InstitutionType enum), country (Country VO as ISO 3166-1 alpha-2), state_province, city, address (Address VO as JSON), contact_info (ContactInfo VO as JSON), coordinates (GeographicCoordinates VO as JSON), website, founded_year, description, logo media collection, gallery media collection, status (InstitutionStatus: Provisional, Operational, Suspended, Closed), is_published (boolean, default false), published_at (timestamp, nullable), created_at, updated_at. Relationships: hasMany Programmes, hasMany AccreditationRecords, hasMany InformationSources, morphMany via OrganizationMember, morphMany Saves/Follows/Likes. Actions: CreateInstitution, UpdateInstitution, PublishInstitution, VerifyInstitutionSource.

**Programme** -- Unique within institution; award type consistency enforced. Migration: `programmes` table with institution_id FK, name, slug, level (ProgrammeLevel enum), discipline_id (UUID FK nullable, references disciplines), award_type, mode_of_study (ModeOfStudy enum), duration (Duration VO as JSON), description, admission_requirements, career_prospects, brochure media collection, status (ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued), is_published (boolean, default false), published_at (timestamp, nullable). Relationships: belongsTo Institution, belongsTo Discipline (nullable), hasMany through AdmissionPolicies, morphMany Saves/Follows/Likes. Actions: CreateProgramme, UpdateProgramme, PublishProgramme.

**Scholarship** -- Application window validity; eligibility criteria non-empty. Migration: `scholarships` table with name, slug, provider_id FK, provider_type (morph), amount (ScholarshipAmount VO as JSON), coverage_type (CoverageType enum), eligibility_criteria (EligibilityCriterion VO as JSON), application_start, application_deadline, description, status, is_published (boolean, default false), published_at (timestamp, nullable), images media collection. Relationships: morphTo provider (ScholarshipProvider or Institution), morphMany Saves/Follows/Likes. Actions: CreateScholarship, UpdateScholarship, PublishScholarship.

**AdmissionCycle** -- Date ordering invariant (open less than or equal to close less than or equal to results); at least one policy required. Migration: `admission_cycles` table with institution_id FK, name, admission_pathway (AdmissionPathway VO -- string value, no separate table), academic_year, opens_at, closes_at, results_at, status. Relationships: belongsTo Institution, hasMany AdmissionPolicies. Actions: OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults.

**InformationSource** -- URL or contact required; verification status tracked. Migration: `information_sources` table with institution_id FK, source_type, url, contact_name, contact_email, verification_status, verified_at, verified_by, notes. Relationships: belongsTo Institution. Actions: VerifyInformationSource, RejectInformationSource.

### 3.2 Child Entities (3)

**AdmissionPolicy** -- belongsTo AdmissionCycle. Migration: `admission_policies` table with admission_cycle_id FK, title, description, policy_rules (AdmissionRule VO as JSON), qualification_requirements, status (PolicyStatus enum). Actions: CreateAdmissionPolicy, UpdateAdmissionPolicy, PublishAdmissionPolicy.

**EligibilityPolicy** -- belongsTo AdmissionCycle. Migration: `eligibility_policies` table with admission_cycle_id FK, title, criteria (EligibilityCriterion VO as JSON), minimum_score, status (PolicyStatus enum). Actions: CreateEligibilityPolicy, UpdateEligibilityPolicy.

**AccreditationRecord** -- belongsTo Institution. Migration: `accreditation_records` table with institution_id FK, authority_id FK, authority_type (morph), accreditation_type, status, valid_from, valid_to (ValidityPeriod VO as JSON), certificate_url. Actions: RecordAccreditation, UpdateAccreditationStatus.

### 3.3 Supporting Entities (3)

**ScholarshipProvider** -- Migration: `scholarship_providers` table with name, slug, type (ProviderType enum), description, website, contact_info (ContactInfo VO as JSON), logo media collection. Relationships: morphMany Scholarships. This is a supporting entity, not an aggregate root; it exists to normalize scholarship provider data.

**EducationAuthority** -- Migration: `education_authorities` table with name, slug, type (AuthorityType enum), country (Country VO), jurisdiction (AuthorityJurisdiction VO as JSON), description, website, contact_info (ContactInfo VO as JSON). Relationships: morphMany AccreditationRecords. Supporting entity for accreditation and regulatory data.

**Qualification** -- Moved from Domain to Reference namespace (per reconciliation R5). Migration: `qualifications` table in Reference layer with name, level, country (Country VO), status (Active/Deprecated). Managed via Filament CRUD, not domain Actions. This move eliminates the Reference-to-Domain FK violation in `qualification_equivalencies`.

### 3.4 Value Objects (28 total = 12 non-enum + 16 enums)

**Non-enum Value Objects (12):**

| # | Value Object | Cast | Persisted? |
|---|---|---|---|
| 1 | Address | LocationCast | Yes (JSON) |
| 2 | AdmissionRule | AdmissionRuleCast | Yes (JSON) |
| 3 | AdmissionStatus | None | No (computed) |
| 4 | ContactInfo | array | Yes (JSON) |
| 5 | Country | string (ISO 3166-1) | Yes |
| 6 | Currency | string (ISO 4217) | Yes |
| 7 | Duration | array | Yes (JSON) |
| 8 | EligibilityCriterion | array | Yes (JSON) |
| 9 | GeographicCoordinates | array | Yes (JSON) |
| 10 | Money | MonetaryAmountCast | Yes (JSON) |
| 11 | ScholarshipAmount | MonetaryAmountCast | Yes (JSON) |
| 12 | ValidityPeriod | ValidityPeriodCast | Yes (JSON) |

**Domain Enums (16):**

| # | Enum | Key Values |
|---|---|---|
| 1 | InstitutionType | University, Polytechnic, CollegeOfEducation, Vocational, SecondarySchool, Professional, Other |
| 2 | ProgrammeLevel | Undergraduate, Postgraduate, Doctorate, Diploma, Certificate, Foundation |
| 3 | ModeOfStudy | FullTime, PartTime, Online, Distance, Hybrid |
| 4 | AwardType | Degree, Diploma, Certificate, PhD, Masters, Bachelors |
| 5 | AdmissionPathway | UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel, UCAS, CommonApp, Other |
| 6 | ScholarshipStatus | Active, Closed, Upcoming |
| 7 | CoverageType | Full, Partial, TuitionOnly, Stipend |
| 8 | ProviderType | Government, Corporate, NGO, Institution, Other |
| 9 | InstitutionStatus | Provisional, Operational, Suspended, Closed |
| 10 | ProgrammeStatus | Prospective, Admitting, Suspended, Discontinued |
| 11 | VerificationStatus | Pending, Verified, Rejected |
| 12 | AuthorityType | Regulatory, Accreditation, Funding, Admissions, Other |
| 13 | PolicyStatus | Draft, Published, Superseded |
| 14 | ContentType | Article, Guide, EducationalResource, ExamPreparation |
| 15 | ResourceType | ProjectTopic, SeminarTopic, ResearchMaterial, StudyResource |
| 16 | PrepType | PastQuestions, ExamTips, SubjectReview, StudyPack |

**AdmissionPathway is a Value Object** -- it is stored as a string enum value on the `admission_cycles` table, not as a separate entity with its own table. Nigerian pathways (UTME, PostUTME) are enum values, not separate domain concepts. International pathways (UCAS, CommonApp) are additional enum values added during expansion. No schema change is required to add new pathways.

### 3.5 Domain Events (29)

Plain PHP classes dispatched via Laravel's event dispatcher. No shared `DomainEvent` interface. No event store. No event sourcing. Events include: InstitutionCreated, InstitutionUpdated, InstitutionPublished, ProgrammeCreated, ProgrammePublished, ScholarshipCreated, ScholarshipDeadlineApproaching, AdmissionCycleOpened, AdmissionCycleClosed, AdmissionResultsPublished, InformationSourceVerified, and others covering all aggregate state transitions. Events trigger side effects: search index updates (via UpdateSearchIndex listener), notification dispatches, and activity logging.

### 3.6 Domain Actions (20)

Each Action meets the explicit Action Criterion (4 conditions from frozen baseline F4): multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization plus complex validation. Actions include: CreateInstitution, UpdateInstitution, PublishInstitution, VerifyInformationSource, RejectInformationSource, CreateProgramme, UpdateProgramme, PublishProgramme, CreateScholarship, UpdateScholarship, PublishScholarship, OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults, CreateAdmissionPolicy, UpdateAdmissionPolicy, PublishAdmissionPolicy, CreateEligibilityPolicy, UpdateEligibilityPolicy, RecordAccreditation. Actions are invoked by Filament resources (admin) and Livewire components (public), never containing business logic in Resource hooks or component methods.

---

## 4. Database Schema

The complete database schema encompasses 56 tables organized across 10 layers. The corrected entity count is 11 (5 aggregate roots + 3 child entities + 3 supporting entities including Qualification in the Reference namespace). The corrected VO count is 28 (12 non-enum VOs + 16 enums). The corrected enum count is 16 (not 20 -- CoverageType, PolicyStatus, ProviderType, and AuthorityType are included in the 16, not additional). AdmissionPathway is a Value Object stored as an enum column on the `admission_cycles` table -- there is no `admission_pathways` table.

### 4.1 Table Inventory by Layer (56 tables)

| Layer | Tables | Count |
|---|---|---|
| Domain | institutions, programmes, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, information_sources, scholarship_providers, education_authorities, disciplines, cut_off_marks | 12 |
| Reference | qualifications, countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries | 7 |
| Content | articles, guides, guide_sections, educational_resources, exam_preparations | 5 |
| Auth/RBAC | users, roles, permissions, model_has_roles, model_has_permissions, role_has_permissions, organization_members, password_reset_tokens, personal_access_tokens | 9 |
| Engagement | saves, follows, likes, comparison_sets | 4 |
| Community | community_questions, community_answers, community_comments, community_votes, community_reports | 5 |
| Notification | notification_preferences | 1 |
| Settings | platform_settings, institution_settings, user_preferences | 3 |
| SEO | url_redirects | 1 |
| Infrastructure | media, tags, taggables, activities, notifications, jobs, failed_jobs, cache, sessions | 9 |
| **Total** | | **56** |

### 4.2 Key Schema Decisions

**Qualification in Reference** (R5): `qualifications` table lives in `App\Reference\Models`, FKs from `qualification_equivalencies` point within Reference namespace, eliminating the Reference-to-Domain FK violation.

**OrganizationMember.role is string** (NOT role_id): The org-scoped role is a string concept stored on the pivot (e.g., 'owner', 'admin', 'admissions', 'editor', 'viewer'), NOT a FK to the Spatie `roles` table. Spatie roles are for global platform permissions. Org-scoped roles are for entity-level privileges. These are two separate concepts that must not be conflated.

**user_id indexes on engagement tables**: `saves`, `follows`, `likes` each have standalone `user_id` index for the common "get all items for user X" query pattern.

**Explicit FK on articles.institution_id**: `->constrained()->nullOnDelete()` for data integrity. The performance cost of an FK constraint is negligible; the data integrity benefit is significant.

**Morph index on community_questions.subject**: `$table->morphsIndex('subject')` for polymorphic query performance.

**AdmissionPathway as VO column**: Stored as a string enum on `admission_cycles.admission_pathway`, not as a separate table. This is consistent with the domain model where AdmissionPathway was demoted from entity to VO.

### 4.3 Domain Table Schemas

**institutions**: id, name, slug, type (InstitutionType), country (ISO 3166-1), state_province, city, address (JSON), contact_info (JSON), coordinates (JSON), website, founded_year, description, status (InstitutionStatus: Provisional, Operational, Suspended, Closed), is_published (boolean, default false), published_at (timestamp, nullable), created_at, updated_at. Index: slug (unique within country), country, type, status, is_published. Publication is orthogonal to domain lifecycle — `is_published` controls visibility on the public site, `status` is the domain lifecycle. `published_at` records the first publication date and is not rewritten on subsequent publication cycles.

**programmes**: id, institution_id FK, name, slug, level (ProgrammeLevel), discipline_id (UUID FK nullable, references disciplines), award_type (AwardType), mode_of_study (ModeOfStudy), duration (JSON), description, admission_requirements, career_prospects, status (ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued), is_published (boolean, default false), published_at (timestamp, nullable), created_at, updated_at. Index: institution_id, slug (unique within institution), level, discipline_id, status, is_published. Publication is orthogonal to domain lifecycle. The `discipline` string column is replaced by `discipline_id` FK referencing the `disciplines` reference table.

**scholarships**: id, provider_type, provider_id (morph), name, slug, amount (JSON), coverage_type (CoverageType), eligibility_criteria (JSON), application_start, application_deadline, description, status (ScholarshipStatus), is_published (boolean, default false), published_at (timestamp, nullable), created_at, updated_at. Index: provider morph, slug, coverage_type, status, is_published, deadline. Publication is orthogonal to domain lifecycle. Scholarship public discovery pages are Phase 2; the publication model is consistent across all user-facing entities.

**admission_cycles**: id, institution_id FK, name, admission_pathway (string -- AdmissionPathway VO), academic_year, opens_at, closes_at, results_at, status, created_at, updated_at. Index: institution_id, status.

**admission_policies**: id, admission_cycle_id FK, title, description, policy_rules (JSON), qualification_requirements, status (PolicyStatus), created_at, updated_at. Index: admission_cycle_id.

**eligibility_policies**: id, admission_cycle_id FK, title, criteria (JSON), minimum_score, status (PolicyStatus), created_at, updated_at. Index: admission_cycle_id.

**accreditation_records**: id, institution_id FK, authority_type, authority_id (morph), accreditation_type, status, valid_from, valid_to (JSON), certificate_url, created_at, updated_at. Index: institution_id, authority morph.

**information_sources**: id, institution_id FK, source_type, url, contact_name, contact_email, verification_status (VerificationStatus), verified_at, verified_by, notes, created_at, updated_at. Index: institution_id, verification_status.

**scholarship_providers**: id, name, slug, type (ProviderType), description, website, contact_info (JSON), created_at, updated_at. Index: slug, type.

**education_authorities**: id, name, slug, type (AuthorityType), country (ISO 3166-1), jurisdiction (JSON), description, website, contact_info (JSON), created_at, updated_at. Index: slug, type, country.

**disciplines**: id, name, slug (unique), description (nullable), sort_order, created_at, updated_at. Index: slug. Managed reference table for programme classification — not a domain entity. Flat for MVP (no parent_id). Values seeded during implementation. See 03-domain.md Section 12.

**cut_off_marks**: id, programme_id (UUID FK, references programmes, ON DELETE CASCADE), admission_cycle_id (UUID FK, references admission_cycles, ON DELETE CASCADE), pathway (VARCHAR(50)), value (INTEGER), source_id (UUID FK nullable, references information_sources, ON DELETE SET NULL), created_at, updated_at. Unique: (programme_id, admission_cycle_id, pathway). Index: programme_id, admission_cycle_id. One row per programme per cycle per admission pathway. Cross-cycle history: multiple rows. Intra-cycle corrections: UPDATE the row; activity log captures the change. See 03-domain.md Section 13.

### 4.4 OrganizationMember Pivot Schema

```
organization_members
    id                  bigint PK
    user_id             bigint FK -> users (cascade delete)
    organization_type   string (morph: 'institution', 'scholarship_provider', 'education_authority')
    organization_id     bigint (morph ID)
    role                string (e.g., 'owner', 'admin', 'admissions', 'editor', 'viewer')
    created_at / updated_at

    Unique: (organization_type, organization_id, user_id, role)
    Index: morphsIndex('organization')
```

The `role` column is a **string**, not `role_id` FK. This allows institution roles to evolve without code changes -- new roles can be added, existing role capabilities adjusted, and the role hierarchy reconfigured without migrations.

### 4.5 Content Table Schemas

**articles**: id, title, slug, body, excerpt, category, institution_id FK (nullable, constrained, nullOnDelete), source_url, is_breaking, published_at, status, seo_title, seo_description, canonical_url, noindex, og_title, og_description, og_image, created_at, updated_at. Traits: HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags.

**guides**: id, title, slug, body, excerpt, category, reading_time, published_at, status, (SEO columns as above), created_at, updated_at. Traits: HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections.

**guide_sections**: id, guide_id FK, title, body, sort_order, created_at, updated_at.

**educational_resources**: id, title, slug, body, excerpt, resource_type (ResourceType), discipline, academic_level, download_count, published_at, status, (SEO columns), created_at, updated_at.

**exam_preparations**: id, title, slug, body, excerpt, prep_type (PrepType), exam_body, year, subject, download_count, published_at, status, (SEO columns), created_at, updated_at.

### 4.6 Migration Dependencies

Migrations must execute in dependency order: (1) users + auth tables, (2) roles + permissions (Spatie), (3) reference data (countries, currencies, qualifications, disciplines), (4) domain tables (institutions -> programmes -> scholarships -> admission_cycles -> admission_policies -> eligibility_policies -> accreditation_records -> information_sources -> scholarship_providers -> education_authorities -> cut_off_marks), (5) organization_members (depends on users + domain), (6) content tables (articles, guides, educational_resources, exam_preparations), (7) engagement tables (saves, follows, likes, comparison_sets), (8) community tables (community_questions -> community_answers -> community_comments -> community_votes -> community_reports), (9) notification_preferences, (10) settings tables, (11) SEO/infrastructure tables.

---

## 5. RBAC Implementation

StudyNexus uses a two-layer authorization model: `spatie/laravel-permission` for global platform roles and permissions, and the `OrganizationMember` pivot for institution/organization-scoped membership. This is BookStack-inspired: the same user can have different privileges per organization, and roles are strings that can evolve without code changes. The total role count is 11: 4 global platform roles + 5 institution-scoped roles + 2 user roles.

### 5.1 Global Platform Roles (Spatie Permission)

| Role | Spatie Role Name | Key Permissions |
|---|---|---|
| Platform Admin | `platform-admin` | All permissions |
| Platform Moderator | `platform-moderator` | Verify sources, moderate content, review community |
| Content Admin | `content-admin` | CRUD all domain entities + content |
| Content Editor | `content-editor` | Create/edit/publish content |

The role name is `platform-admin` (not `super-admin`). This naming convention is deliberate and consistent with the BookStack-inspired model where the platform administrator has global reach but the naming emphasizes platform scope rather than implying unlimited authority.

### 5.2 Institution-Scoped Roles (via OrganizationMember)

| Role | Key Capabilities | Notes |
|---|---|---|
| `institution-owner` | Full control + manage members + transfer ownership | At least one owner must exist per institution |
| `institution-admin` | Manage institution data, programmes, admissions, scholarships, publish articles | Cannot manage members or transfer ownership |
| `institution-admissions` | Manage admission policies, cycles, deadlines | Read-only on other institution data |
| `institution-editor` | Edit descriptions, media, programme details | Cannot change status, manage admissions, or manage members |
| `institution-viewer` | View internal data and reports | Read-only access |

These roles are initial defaults, not a rigid hierarchy. The architecture allows institution roles and permissions to evolve. New roles can be added, existing role capabilities adjusted, and the role hierarchy reconfigured without code changes -- the `OrganizationMember.role` is a string, not an enum, specifically to allow this flexibility.

### 5.3 User Roles

| Role | Key Capabilities |
|---|---|
| `registered-user` | Save, follow, like, compare, community participation |
| `guest` | Browse only |

### 5.4 OrganizationMember Pivot Implementation

The pivot uses a string `role` column (NOT `role_id` FK to Spatie roles). Spatie roles handle global platform permissions. Org-scoped roles handle entity-level privileges. These are two separate concepts. The OrganizationMember morphable pivot supports `institution`, `scholarship_provider`, and `education_authority` as organization types, allowing the same membership model to serve multiple entity types. The key invariant is that the same user can be `owner` of Institution A and `viewer` of Institution B -- roles are scoped to the organization, not global. There is no `owner_id` or `admin_user_id` on the Institution aggregate; ownership is membership, not a domain property.

### 5.5 Policy Pattern

```php
class InstitutionPolicy
{
    public function update(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->hasRole('content-admin')
            || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
    }
}
```

Every domain model Policy checks both global permission (Spatie) and scoped membership (OrganizationMember). This pattern is consistent across all domain entities.

### 5.6 Administrative UI

Filament resources provide the administrative UI for managing: global roles and permissions (via `bezhansalleh/filament-shield` -- note the correct spelling with double 'l' in 'salleh'), organization memberships (custom Filament resource), and self-protection against administrators accidentally removing their own critical access. The UI must prevent the last `platform-admin` from demoting themselves and the last `institution-owner` from removing their ownership.

---

## 6. Admin Panel Implementation

The admin panel is built with Filament v5 and is exclusively admin-facing. Filament is never exposed to public users (ADR-12). All admin operations -- CRUD for domain entities, content management, reference data, user management, RBAC, settings, and reporting -- are handled through Filament resources, pages, and widgets. Business logic is never placed in Filament Resource hooks; Resources invoke domain Actions for write operations and Query classes for read operations.

### 6.1 Filament Panel Setup

The admin panel is configured as a separate Filament panel accessible at `/admin` (or a configurable path). Authentication uses the same Laravel guard as the public site but requires a platform or institution-scoped role for access. The panel uses the default Filament v5 theme with Tailwind CSS customization for StudyNexus branding. Navigation is organized by domain concern: Institutions, Programmes, Scholarships, Admissions, Content, Community, Reference Data, Settings, and Users.

### 6.2 Resource Definitions

**Domain Resources**: InstitutionResource, ProgrammeResource, ScholarshipResource, AdmissionCycleResource, AdmissionPolicyResource, EligibilityPolicyResource, AccreditationRecordResource, InformationSourceResource, ScholarshipProviderResource, EducationAuthorityResource. Each resource defines form schemas, table columns, filters, actions, and authorization gates. Form schemas use Filament native RichEditor for rich text fields (not the deprecated tiptap-editor), Select fields for enum values, and MediaLibrary picker for file uploads.

**Content Resources**: ArticleResource, GuideResource, EducationalResourceResource, ExamPreparationResource. These resources leverage the shared content traits (HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags) to provide consistent publishing workflows, SEO metadata editing, media management, and tag assignment.

**Reference Resources**: QualificationResource, CountryResource, CurrencyResource, QualificationEquivalencyResource, TuitionFeeRangeResource, CostOfLivingIndexResource, VisaRequirementSummaryResource. Simple CRUD resources with no domain Actions -- managed directly through Filament.

**Engagement Resources**: OrganizationMemberResource for managing institution memberships and roles. SaveResource, FollowResource, LikeResource for administrative oversight (read-only with filters).

**Community Resources**: QuestionResource, AnswerResource, CommentResource, VoteResource, ReportResource. Report resource provides moderation workflow (pending -> resolved -> dismissed).

### 6.3 Navigation Structure

```
Dashboard
Institutions
  - All Institutions
  - Accreditation Records
  - Information Sources
Programmes
  - All Programmes
  - Admission Cycles
  - Admission Policies
  - Eligibility Policies
Scholarships
  - All Scholarships
  - Scholarship Providers
Content
  - Articles
  - Guides
  - Educational Resources
  - Exam Preparation
Community (feature-flagged)
  - Questions
  - Answers
  - Reports (moderation)
Reference Data
  - Qualifications
  - Countries
  - Currencies
  - Qualification Equivalencies
  - Tuition Fee Ranges
  - Cost of Living Indices
  - Visa Requirement Summaries
Settings
  - Platform Settings
  - Institution Settings
Users & Roles
  - Users
  - Roles & Permissions (via filament-shield)
  - Organization Members
```

### 6.4 Authorization Integration

Every Filament resource checks authorization through Laravel Policies, which in turn check both Spatie global permissions and OrganizationMember scoped membership. `bezhansalleh/filament-shield` provides the bridge between Filament and Spatie Permission, generating permission-based access gates for each resource. Custom authorization logic for institution-scoped operations (e.g., "can this user edit this specific institution?") is handled through Policy methods that query the OrganizationMember pivot. Activity logging in the admin panel is provided by `pxlrbt/filament-activity-log` v3.1.1, which integrates with `spatie/laravel-activitylog` to display an activity timeline on each resource view page.

---

## 7. Frontend Implementation

The public-facing application uses the TALL stack: Tailwind CSS + Alpine.js + Livewire v4 + Laravel. This is non-negotiable. There is no React, no Next.js, no Vue, no Inertia, no SPA, and no client-side routing. The server owns the page; JavaScript enhances it. Filament is admin-facing only and never appears in the public site.

### 7.1 TALL Stack Roles

| Technology | Role | Boundary |
|---|---|---|
| Laravel | Application framework, routing, middleware, DI container | Backend only |
| Blade | Server-rendered templates for SEO-critical content and layouts | SEO-critical pages, static content, page shells |
| Livewire v4 | Server-driven reactive UI for interactive pages and forms | Filter pages, dashboards, forms, lazy-loaded sections |
| Flux | UI component library providing consistent design system for Livewire | Form inputs, buttons, cards, modals, tables |
| Alpine.js | Lightweight client-side interactivity for presentation-only behaviour | Share buttons, dropdowns, accordions, tooltips, mobile menu |
| Tailwind CSS | Utility-first CSS framework | All styling |

### 7.2 Livewire Usage Boundary

| Context | Use Livewire? | Use Blade? | Use Alpine.js? | Rationale |
|---|---|---|---|---|
| SEO-critical detail pages (institution, programme, scholarship, article, guide) | No (except lazy-loaded sections) | Yes (server-rendered) | Yes (UI toggles) | SEO requires fully rendered HTML on first load |
| Search/filter/listing pages | Yes (wire:navigate for SPA-like transitions) | Yes (initial server render) | No | Livewire handles filter state, pagination, URL sync |
| Lazy-loaded sections (related content, community Q&A) | Yes (lazy component) | No | No | Loaded on demand, not SEO-critical |
| Authenticated dashboards | Yes | Yes (layout) | Yes (minor UI) | SEO irrelevant; interactivity primary |
| Forms (save, follow, report, ask question) | Yes | No | No | Livewire handles validation, submission, state |
| Static content (about, privacy, terms) | No | Yes | No | No interactivity needed |
| Share buttons, UI toggles | No | No | Yes | Pure client-side, no server round-trip |

Rule of thumb: Blade for SEO-critical first-load content. Livewire for interactivity. Alpine.js for presentation-only client-side behaviour. Never use Livewire where Blade suffices.

### 7.3 Public Site Structure

The public site is organized around canonical entity detail pages (server-rendered Blade), interactive listing/filter pages (Livewire + Typesense), and feature-flagged modules (Community, Study Abroad). The homepage is a Blade template with Livewire lazy-loaded sections for personalized content (if authenticated) and Typesense-powered search. All SEO-critical pages render complete HTML on first load with structured data, meta tags, and Open Graph tags via the HasSeoMeta trait.

### 7.4 Key Livewire Components

- **ProgrammeSearch** -- Filter/search component for `/programmes` using Typesense; handles discipline, level, country, institution type facets with wire:navigate for SPA-like transitions
- **InstitutionSearch** -- Filter/search for `/institutions` listing
- **ScholarshipSearch** -- Filter/search for `/scholarships` listing
- **SaveButton** -- Toggle save on entities (morphToMany); Livewire form component
- **FollowButton** -- Toggle follow on entities; Livewire form component
- **CompareWidget** -- Add/remove items from comparison set; session for anonymous, DB for authenticated
- **CommunityQuestionForm** -- Ask a question with validation; Livewire form component
- **CommunityAnswerForm** -- Submit an answer; Livewire form component
- **NotificationPreferences** -- Per-category, per-channel toggle settings; Livewire form component

### 7.5 Anti-Patterns

- Making every page a Livewire component (degrades SEO, adds unnecessary server round-trips)
- Using Filament for public-facing UI
- Introducing React, Next.js, Vue, or Inertia anywhere in the codebase
- Client-side routing (the server owns the URL)
- Client-rendered SEO pages (search engines must see fully rendered HTML)

---

## 8. Search Implementation

Typesense is the search, discovery, and faceting engine. It is a projection of PostgreSQL data, not a replacement for it. Laravel/PostgreSQL remains authoritative for canonical entities, SEO pages, and structured data rendering. Typesense never renders a public page; it only provides the search/discovery API that Livewire or Blade consumes.

### 8.1 The Separation

| Concern | Owned By | Rationale |
|---|---|---|
| Canonical entity data | PostgreSQL | Source of truth (ADR-01, P9) |
| SEO page rendering | Blade + Laravel | Server-rendered HTML for crawlers |
| Canonical URLs | Laravel routes | Stable, deliberate, controlled |
| Structured data | Blade templates | JSON-LD in server-rendered pages |
| Full-text search | Typesense | Optimized for search, not rendering |
| Faceted navigation | Typesense | Real-time faceting, filtering, sorting |
| Autocomplete | Typesense | Instant search API |
| Discovery/hub pages | Blade (initial) + Typesense (results) | SEO entry point + interactive results |

### 8.2 Typesense Collections (7)

| Collection | Source Model | Key Fields | Facet Fields | Sort Fields |
|---|---|---|---|---|
| institutions | Institution | name, slug, type, country, city, description | type, country, state_province | created_at, name |
| programmes | Programme | name, slug, level, discipline, discipline_slug, institution_name, institution_slug, institution_type, mode_of_study, is_published, tuition_min, tuition_max, is_admission_open | level, discipline, institution_type, country, mode_of_study | created_at, name |
| scholarships | Scholarship | name, slug, amount, provider_name, coverage_type | coverage_type, provider_type, level, country | deadline, amount |
| articles | Article | title, slug, category, institution_name | category, resource_type | published_at |
| guides | Guide | title, slug, category | category | published_at |
| educational_resources | EducationalResource | title, slug, resource_type, discipline, academic_level | resource_type, discipline, academic_level | published_at |
| exam_preparations | ExamPreparation | title, slug, prep_type, exam_body, subject, year | prep_type, exam_body, subject, year | published_at |

### 8.3 Sync Mechanism

Domain events -> `UpdateSearchIndex` listener -> queued Scout job -> Typesense upsert. Eventual consistency with a stale tolerance of 5 seconds or less. On failure, the queued job retries with exponential backoff. Full reindex is available via `php artisan scout:import-all`. If the Typesense index is corrupted, it can be fully rebuilt from PostgreSQL. Programme documents denormalize `institution_name`, `institution_slug`, `institution_type`, and `country` from the parent Institution to avoid join queries in Typesense. These denormalized fields are updated when the parent Institution changes via the `InstitutionRenamed` or `InstitutionUpdated` events, which trigger re-indexing of all child Programmes.

**Search projection fields** exist only in Typesense and are computed by `toSearchableArray()`:
- `discipline` and `discipline_slug`: denormalized from the `disciplines` reference table via the `discipline_id` FK on Programme.
- `is_published`: boolean filter field. Only published programmes (`is_published = true` AND lifecycle status allows public display) are indexed in the public-facing Typesense collection. Admin search includes all programmes regardless of publication status.
- `tuition_min` and `tuition_max`: int32 fields computed from the MonetaryAmount VO on Programme. If the programme has indigene and non-indigene tuition, `tuition_min` is the lower value and `tuition_max` is the higher. These enable tuition range faceting without storing the VO structure in Typesense.
- `is_admission_open`: boolean field computed from Programme lifecycle status + current Admission Cycle phase + existence of an active AdmissionPolicy. This is a read-model derivation, not a stored domain property.

### 8.4 Scout Configuration

Laravel Scout v11 with the native Typesense driver. Each searchable model implements the `Searchable` interface via the `IsSearchable` trait. The `toSearchableArray()` method maps model attributes to Typesense document fields, including denormalized parent data where applicable. Scout queue is enabled for all models to prevent synchronous index updates from blocking request/response cycles. The Typesense client (`typesense/typesense-php` v4.x) is configured via `config/scout.php` with connection details, collection-specific schema definitions, and facet/sort configuration.

### 8.5 Controlled Indexation

Not every URL combination is indexable. The SEO architecture deliberately controls which pages search engines can crawl: canonical entity pages are indexable, curated discovery pages are indexable, deep filter combinations (more than 3 query parameters) are noindex, paginated pages beyond page 1 are noindex, user profiles and search results pages are noindex. This prevents exponential URL explosion and conserves crawl budget.

---

## 9. Package Matrix

Every package is evaluated against Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4. Packages that have been verified by the package audit are marked VERIFIED. Packages with known issues or pending verification are noted. No fabricated package names appear in this matrix.

### 9.1 Adopt Now (20 packages)

| # | Package | Version | Purpose | Status |
|---|---|---|---|---|
| 1 | `spatie/laravel-permission` | ^6.0 | RBAC engine | VERIFIED |
| 2 | `spatie/laravel-medialibrary` | ^11.0 | File/media management | VERIFIED |
| 3 | `spatie/laravel-tags` | ^4.0 | Taxonomy/tagging | VERIFIED |
| 4 | `spatie/laravel-activitylog` | ^4.0 | Audit trail | VERIFIED |
| 5 | `spatie/laravel-sitemap` | ^7.0 | XML sitemaps | VERIFIED |
| 6 | `spatie/laravel-honeypot` | ^4.0 | Spam protection | VERIFIED |
| 7 | `spatie/laravel-backup` | ^9.0 | Database/file backup | VERIFIED |
| 8 | `spatie/laravel-webhook-client` | ^3.0 | Incoming webhooks | VERIFIED |
| 9 | `spatie/laravel-personal-data-export` | ^4.0 | GDPR data export | VERIFIED |
| 10 | `spatie/laravel-data` | ^4.0 | Data transfer objects | VERIFIED |
| 11 | `spatie/laravel-sluggable` | ^4.0 | Slug generation | VERIFIED |
| 12 | `spatie/laravel-searchable` | ^3.0 | Search abstraction | VERIFIED |
| 13 | `spatie/laravel-query-builder` | ^3.0 | API filtering/sorting | VERIFIED |
| 14 | `maatwebsite/excel` | ^3.1 | Import/export | VERIFIED |
| 15 | `laravel-notification-channels/webpush` | ^8.0 | Web Push notifications | VERIFIED |
| 16 | `laravel/socialite` | ^5.0 | Social OAuth login | VERIFIED |
| 17 | `laravel/sanctum` | ^4.0 | API token auth | VERIFIED |
| 18 | `laravel/pulse` | ^1.0 | Application monitoring | VERIFIED |
| 19 | `bezhansalleh/filament-shield` | ^5.0 | Filament + Permission integration | VERIFIED (name corrected from `bezhansalam`; version must match Filament v5) |
| 20 | `pxlrbt/filament-activity-log` | ^3.1.1 | Activity log in admin panel | VERIFIED (Filament v4/v5-compatible community standard) |

### 9.2 Core Stack Packages

| # | Package | Version | Purpose | Status |
|---|---|---|---|---|
| 21 | `laravel/framework` | ^13.0 | Application framework | VERIFIED |
| 22 | `laravel/breeze` | ^2.0 | Auth scaffolding | VERIFIED WITH CAVEAT (works on L13 but is legacy; L13 Livewire starter kit is alternative) |
| 23 | `laravel/scout` | ^11.0 | Search driver abstraction (Typesense) | VERIFIED |
| 24 | `livewire/livewire` | ^4.0 | Server-driven reactive UI | VERIFIED (v4 required for Laravel 13) |
| 25 | `livewire/flux` | ^1.0 | UI component library | VERIFIED |
| 26 | `filament/filament` | ^5.0 | Admin panel framework | VERIFIED (v5 designed for Livewire v4 + Laravel 13 + PHP 8.5) |
| 27 | `typesense/typesense-php` | ^4.0 | Typesense PHP client | VERIFIED |
| 28 | `pestphp/pest` | ^4.0 | Test framework | VERIFIED |

### 9.3 Adopt When Needed (9 packages)

| # | Package | Version | Trigger | Status |
|---|---|---|---|---|
| 29 | `spatie/laravel-settings` | ^3.0 | When admin-configurable settings needed | VERIFIED |
| 30 | `spatie/laravel-responsecache` | ^7.0 | When traffic volume justifies | VERIFIED |
| 31 | `spatie/laravel-markdown` | ^3.0 | When community feature begins | VERIFIED |
| 32 | `spatie/eloquent-sortable` | ^4.0 | When display ordering needed | VERIFIED |
| 33 | `laravel/horizon` | ^5.0 | When queue monitoring needed | VERIFIED |
| 34 | `spatie/laravel-webhook-server` | ^3.0 | When outbound webhooks needed | VERIFIED |
| 35 | `spatie/browsershot` | ^5.0 | When PDF export needed | VERIFIED |
| 36 | `spatie/laravel-translation-loader` | ^5.0 | When Africa expansion begins | VERIFIED |
| 37 | `spatie/laravel-welcome-notification` | ^3.0 | When onboarding implemented | VERIFIED |

### 9.4 Evaluate Later (3 packages)

| Package | Concern | Status |
|---|---|---|
| `spatie/laravel-csp` | Content Security Policy -- not launch-blocking | VERIFIED |
| `laravel/passkeys` | WebAuthn -- evaluate in 12 months | VERIFIED |
| `spatie/laravel-health` | May be redundant with K8s probes | VERIFIED |

**Rate limiting**: Use Laravel's built-in `RateLimiter` facade or `spatie/laravel-rate-limited-job-middleware` for queue job rate limiting. The package `spatie/laravel-rate-limits` does not exist under that name and must not be used.

### 9.5 Rejected Packages (12)

| Package | Reason |
|---|---|
| `spatie/laravel-event-sourcing` | Contradicts ADR-02 |
| `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| `spatie/laravel-model-states` | Guard clauses + PHP enums are LBC-idiomatic |
| `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| `spatie/laravel-fractal` | Superseded by laravel-data |
| `spatie/valuestore` | Superseded by laravel-settings |
| `spatie/laravel-view-models` | Superseded by laravel-data |
| `spatie/laravel-geocoder` | Typesense geo filter handles location |
| `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| `spatie/laravel-feeds` | Near-zero relevance |
| `wireui/wireui` | Unnecessary when using Flux |
| `spatie/laravel-ray` | Dev-only, never in production dependencies |

### 9.6 Fabricated/Invalid Packages (Must Not Appear)

| Package | Reality | Replacement |
|---|---|---|
| `minimolabs/laravel-webpush` | FABRICATED -- does not exist on Packagist | `laravel-notification-channels/webpush` |
| `bezhansalam/filament-shield` | MISSPELLED -- correct name has double 'l' | `bezhansalleh/filament-shield` |
| `filament/tiptap-editor` | DEPRECATED for Filament v4/v5 | Use Filament native RichEditor |
| `spatie/laravel-rate-limits` | DOES NOT EXIST under this name | Laravel `RateLimiter` facade or `spatie/laravel-rate-limited-job-middleware` |

### 9.7 Dev Dependencies

- `pestphp/pest` ^4.0 -- test framework
- `laravel/pint` -- code style fixer
- `laravel/telescope` -- dev debugging (dev-only, never in production)

---

## 10. Implementation Order

Implementation follows a dependency-correct phase sequence. Auth and RBAC come first because domain model tests need authenticated users to verify Policies, OrganizationMember is referenced by domain Policies, reference data is needed by seeders, and Spatie Permission roles must exist before Filament resources can check authorization. The total Phase 1 duration is approximately 17 weeks.

### 10.1 Phase Sequence

| Phase | Name | Duration | Dependencies | Done When |
|---|---|---|---|---|
| **1a** | Laravel foundation + Auth + RBAC + Reference Data | 3 weeks | None | Users can register/login; roles/permissions seeded; reference data importable |
| **1b** | Domain Layer | 3 weeks | 1a | All 12 domain tables migrated; 20 Actions tested; Policies enforce RBAC |
| **1c** | Content Layer | 2 weeks | 1b | 4 content models + 8 traits + Filament CRUD for content |
| **1d** | Public Site -- Domain Pages | 3 weeks | 1b | Institution/programme/scholarship detail pages; programme discovery hubs |
| **1e** | Public Site -- Content Pages | 2 weeks | 1c | Article/guide/resource/exam-prep pages; content listing pages |
| **1f** | Search (Typesense) | 1 week | 1b, 1c | 7 Typesense collections; Scout sync; autocomplete; search results page |
| **1g** | SEO | 1 week | 1d, 1e | Canonical URLs; sitemaps; structured data; robots meta; Open Graph |
| **1h** | Engagement | 1 week | 1d, 1e | Save, Follow, Like, Share; notification_preferences seeded |
| **1i** | Notifications | 1 week | 1h | 5 notification classes; DB + Email channels; WebPush flag |
| **2a** | Community Module | 3 weeks | 1d, 1i | Question + Answer + Comment + Vote + Report; feature flag |
| **2b** | Study Abroad Module | 2 weeks | 1d, 1c | Reference data for international; Livewire components; feature flag |
| **2c** | Comparison | 1 week | 1h | comparison_sets; Livewire compare UI |
| **2d** | Exam Preparation | 1 week | 1c | ExamPrep model + UI + download tracking |
| **3** | Advanced Features | TBD | All above | Posts/Channels, Reputation, Badges, AI, API, SMS notifications |

### 10.2 Phase Dependencies

```
1a (Foundation + Auth + RBAC + Reference Data)
  |-- 1b (Domain Layer)
  |     |-- 1c (Content Layer)
  |     |     |-- 1e (Content Pages)
  |     |     |-- 2d (Exam Preparation)
  |     |-- 1d (Domain Pages)
  |     |-- 1f (Search - depends on 1b + 1c)
  |-- 1g (SEO - depends on 1d + 1e)
  |-- 1h (Engagement - depends on 1d + 1e)
        |-- 1i (Notifications)
        |     |-- 2a (Community)
        |-- 2c (Comparison)
2b (Study Abroad - depends on 1d + 1c)
```

### 10.3 Phase 1a Detail (Foundation)

This phase establishes the entire application skeleton. Step by step: (1) `composer create-project laravel/laravel studynexus "13.*"`, (2) configure PostgreSQL, Redis, environment variables, (3) install and configure Livewire v4 + Flux, (4) install and configure Filament v5 admin panel, (5) install Laravel Breeze (Blade stack) and run auth scaffolding, (6) install `spatie/laravel-permission` and publish migrations, (7) create the 11 roles and seed base permissions, (8) create the OrganizationMember pivot migration and model, (9) install all Spatie Adopt Now packages (medialibrary, tags, activitylog, sitemap, honeypot, backup, etc.), (10) create reference data migrations (countries, currencies, qualifications) and seeders, (11) install and configure `bezhansalleh/filament-shield` for Filament + Permission integration, (12) install `pxlrbt/filament-activity-log` for admin activity logging, (13) configure Pest test framework, (14) write initial auth/RBAC feature tests verifying all 11 roles and OrganizationMember scoping.

### 10.4 Feature Flags

| Flag | Default | Module |
|---|---|---|
| `features.community` | false | Community module (Phase 2a) |
| `features.study_abroad` | false | Study Abroad module (Phase 2b) |
| `features.web_push` | false | Web Push notifications (Phase 1i) |
| `features.sms` | false | SMS notifications (Phase 3) |
| `features.exam_preparation` | false | Exam Preparation module (Phase 2d) |

Feature flags are stored in config/environment, not in the database. They gate entire modules, not individual features within modules. Removing a feature flag disables the module without affecting any other part of the system.

### 10.5 Remaining Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| 1 | Package incompatibility with Laravel 13 + PHP 8.5 | High | Package audit complete; all Adopt Now packages VERIFIED |
| 2 | Content scope creep | High | Behaviour Test: model justified by distinct behaviour, not distinct data |
| 3 | Livewire-overuse | Medium | Explicit boundary rule (Section 7.2); code review checklist |
| 4 | RBAC complexity growth | Medium | Start with 5 institution roles; add only when user research demands |
| 5 | Settings architecture over-engineering | Medium | Start simple; add tiers as needed |
| 6 | Polymorphic relationship performance at scale | Low | Explicit indexes; hot paths use explicit FKs |
| 7 | Typesense + PostgreSQL consistency | Low | 5s or less stale tolerance; Scout queue + retry |
| 8 | Feature flag drift | Low | Feature flags in .env; documented defaults |

### 10.6 Architectural Drift Guards

Any future coding agent working on StudyNexus must NOT: add a new entity without behavioural justification (Behaviour Test); add a new package without verifying its existence, maintenance, and Laravel 13 compatibility; add a repository without justification that overrides ADR-04; introduce React, Next.js, Vue, or Inertia anywhere; bypass scoped authorization (always check both global permission AND org membership); hard-code role assumptions (roles are strings, not enums; they evolve); create Nigeria-specific domain abstractions where a universal concept exists; make domain depend on presentation or content; use Typesense as the source of truth (PostgreSQL is authoritative); create indexable URL combinations without SEO analysis; put every piece of data into a generic JSON settings table; make Livewire the default for every page (Blade first, Livewire when needed).

---

*End of StudyNexus Implementation Blueprint. All canonical corrections applied. Entity count: 11. VO count: 28. Enum count: 16. Platform: Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4. RBAC: 11 roles with string role column on OrganizationMember pivot. Table count: 56. Publication: is_published boolean + published_at nullable timestamp on Institution, Programme, Scholarship (orthogonal to domain lifecycle). Discipline: disciplines reference table + discipline_id FK on programmes. Cut-off history: cut_off_marks table. No fabricated packages. No deprecated packages. No Laravel 12/Filament v3/Livewire v3 instructions.*
