# StudyNexus — Business (Canonical)

**Technology baseline:** Laravel ^13.0, PHP 8.5, Filament 5, Livewire 4.
**Business Discovery Status:** FROZEN (2026-08-07).
**Source documents:** 01-business-overview.md, 02-glossary.md, 04-open-questions.md, 06-business-workflows.md, 07-business-discovery-closure.md.

---

## 1. Vision and Identity

**Identity.** StudyNexus is a comprehensive education knowledge platform that aggregates, verifies, organizes, and makes educational information across Nigeria searchable, comparable, and trustworthy. It serves as the single authoritative source that replaces the fragmented, inconsistent, and difficult-to-verify information landscape that users currently navigate manually across JAMB, WAEC, institution websites, scholarship sites, PDFs, blogs, social media, WhatsApp groups, and friends.

**Vision.** Become the education infrastructure for Africa.

**Core Interaction.** Users search, discover, compare, and verify educational opportunities and information. The platform enables both direct search (when the user knows what they are looking for) and structured exploration (when the user does not yet know what matches their interests, qualifications, or aspirations). This dual mode of interaction is fundamental to the platform's value proposition and distinguishes it from simple search tools.

**Naming and scope.** The name StudyNexus reflects the platform's role as a connection point (nexus) for educational knowledge (study). The initial bounded domain is strictly Nigerian institutions and Nigerian education data. Foreign institutions are future scope. The long-term direction is African education infrastructure, but Nigeria is the initial market and the model must mature there before geographic expansion is considered. Geographic expansion is anticipated in the data model but not optimized for prematurely.

---

## 2. Problem Space

StudyNexus addresses five interconnected problem dimensions that have been established as the complete set for the current business-discovery model. New dimensions require an explicit change proposal with evidence. Fragmentation, Discoverability, and Trust are foundational; Comparison is especially important during decision-making; Accessibility cuts across all personas.

### 2.1 Fragmentation

Information is scattered across many independent sources (JAMB, institution websites, faculty/departmental pages, government agencies, scholarship sites, blogs, forums, YouTube, WhatsApp, social media), each covering only part of the picture. Sources are disconnected, structurally inconsistent, and vary in quality. Users spend significant time collecting, organizing, and reconciling information before they can decide. There is no single source that presents a complete, connected view of educational information for a given decision context.

**Core pain:** No trusted source presents a complete, connected view.

### 2.2 Trust

Users cannot determine whether information is accurate, current, or authoritative. Official websites are outdated or incomplete. Third-party sites copy without citation. Figures contradict across sources. Information changes without indication. No way to distinguish official, verified, historical, and community-contributed information. Users are forced to cross-reference multiple sources and still cannot be confident in the reliability of what they find.

**Core pain:** Inability to confidently assess reliability.

### 2.3 Discoverability

Users are unaware of opportunities that match their goals -- institutions, programmes, scholarships, alternative admission pathways, vocational/technical/specialized options, opportunities outside their geographic region. Information is available only if the user already knows exactly what to search for. Users cannot discover educational opportunities through structured exploration; they must already possess the names or identifiers of the opportunities they seek.

**Core pain:** Information requires known-target search. Users should be able to discover educational opportunities through structured exploration as well as direct search.

### 2.4 Comparison

Information lacks consistent structure across institutions. Tuition is presented differently. Terminology varies for similar programmes. Admission requirements use inconsistent formats. Accreditation is non-uniform. Important characteristics are omitted entirely by some sources. Users resort to manual notes and spreadsheets and still cannot compare objectively. Without standardized, comparable information, side-by-side evaluation is impractical and error-prone.

**Core pain:** Absence of standardized, comparable information across educational opportunities.

### 2.5 Accessibility

Users may know exactly what they are looking for but still struggle to access it. Official websites are slow, unavailable, or difficult to navigate. Information is buried inside PDFs or scanned documents. Sites are not optimized for mobile devices. High data usage and poor connectivity make access difficult. Information is not presented in a consistent, user-friendly format. Accessibility is a problem dimension distinct from Discoverability: the information exists but is practically inaccessible to many users due to format, connectivity, device, or usability barriers.

**Core pain:** Educational information exists but is practically inaccessible to many users due to format, connectivity, device, or usability barriers.

---

## 3. Primary Personas

StudyNexus serves four primary user personas on day one, all sharing the core need to discover, understand, compare, and verify educational information. The core interaction is shared across personas; workflows and interfaces adapt to persona goals. The platform does not build four separate products. Shared capabilities underpin goal-oriented workflows.

**Priority ranking (from OQ1-1):**

1. **Secondary School Student and Graduate.** A student currently in secondary school (e.g., SS3) or a recent graduate preparing to pursue tertiary education who needs to discover institutions, programmes, admission requirements, cut-off marks, tuition, scholarships, and career pathways. This persona is the primary usage persona and the primary beneficiary of the MVP.

2. **Undergraduate Student.** A student already in tertiary education looking for scholarships, transfers, postgraduate opportunities, internships, or accurate information about their institution and programme. This persona is the second primary usage persona and uniquely requires the Understand Current Educational Journey workflow (WF7).

3. **Parent or Guardian.** A decision-maker helping a child choose institutions, compare costs, evaluate quality, and understand admission requirements. Parents are high-impact decision influencers who may weight different information priorities (e.g., cost, safety) and act as proxy decision-makers for their children.

4. **Guidance Counsellor or Teacher.** An educator helping students make informed educational decisions using accurate and up-to-date information. Counsellors and teachers are lower-volume but strategically valuable professional users who may execute workflows proactively to maintain professional awareness and advise multiple students.

**Current behavior without StudyNexus:** All four personas manually piece together information from JAMB, WAEC, institution websites, scholarship sites, PDFs, blogs, social media, WhatsApp groups, and friends. The process is fragmented, inconsistent, and difficult to verify. StudyNexus replaces this fragmented discovery with a single trusted source.

**Persona priority rationale:** The first two personas are primary usage personas who directly consume educational information for their own decisions. Parents are high-impact decision influencers who guide or share decisions. Guidance counsellors and teachers are strategically valuable professional users whose endorsement drives adoption but who represent lower individual volume. This ranking informs design and feature prioritization but does not constrain shared capability development.

---

## 4. Secondary Users

Secondary users benefit from the platform's data but are not required for the initial value proposition. Dedicated features for them may be introduced as the platform evolves. The architecture should accommodate secondary-user influence on flexibility without compromising day-one simplicity (P17).

| Persona | Day-One Role | Trajectory to Primary |
|---------|-------------|----------------------|
| **Educational Institutions** | Ensure accurate representation; increase visibility to prospective students; review programme, admission, accreditation, and contact information. | Potential future primary users if institution management/verification/profile features are introduced. Not guaranteed. |
| **Scholarship Providers** | Publish scholarship opportunities; maintain eligibility requirements and deadlines; reach qualified applicants. | Potential future primary users if direct scholarship creation/management is supported. Not guaranteed. |
| **Government Education Agencies** (JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies) | Benefit from increased discoverability/accessibility of official information; platform links back to authoritative sources. | Strategic partners (data providers), not on a path to becoming primary users. |
| **Educational Researchers and Analysts** | Explore structured educational data; analyze trends; compare institutions and programmes; access historical information. | No planned promotion to primary. |
| **Employers** | Not in initial scope. | Future possibility if career-related capabilities are introduced. |
| **Developers** | Not in initial scope. | May become primary if platform evolves into infrastructure with public APIs (long-term vision). |

**Institution management features** are post-MVP; they come after the public discovery/information layer is established. **Scholarship provider management features** are also post-MVP, following the public scholarship discovery/data layer. **Government agencies** are authoritative sources, but the system should not depend on agencies actively providing data; information is primarily aggregated from public and official sources. Direct data partnerships and feeds are future enhancements.

---

## 5. Strategic Evolution

StudyNexus evolves strategically through four stages, each building on the previous. These stages describe business evolution, not a fixed chronological product roadmap. Some capabilities may arrive earlier or later depending on business priorities (P18).

| Stage | Name | Core Capability |
|-------|------|----------------|
| **1** | **Trusted Education Knowledge Base** (MVP) | Aggregate, organize, verify, and present educational knowledge in searchable, comparable form. Help users make informed decisions. |
| **2** | **Personalized Education Companion** | Build on the knowledge base with personalization, saved preferences, notifications, and decision support. Knowledge remains the foundation. |
| **3** | **Education Ecosystem** | Verified organizations (institutions, scholarship providers) participate directly in maintaining and publishing information. StudyNexus becomes the central platform connecting stakeholders, maintaining editorial standards and verification. |
| **4** | **Education Infrastructure** | Provide trusted educational data and services through well-defined interfaces for third-party consumption. Foundational infrastructure while continuing to serve end users directly. |

### 5.1 MVP Scope (Stage 1)

The MVP solves the five approved business problems: Fragmentation, Trust, Discoverability, Comparison, and Accessibility. It enables users to discover, understand, compare, and verify educational opportunities using trusted, structured information. No user account is required for core MVP discovery, search, comparison, and information access. Accounts should only be introduced when persistent or personal capabilities justify them. Decision support in the MVP means structured consolidation, discovery, comparison, and verification. As reliable structured data and rules mature, recommendation and eligibility assessment may be added progressively. StudyNexus supports informed decision-making rather than making opaque decisions on behalf of users.

**Explicitly excluded from MVP:** Institution self-service, scholarship provider self-service, public APIs, developer platform, multi-country support, marketplace/transactional features. StudyNexus does not perform applications in the MVP.

### 5.2 Critical Transition

The most concerning transition is Stage 1 to Stage 3 (internally curated information to externally contributed information). This introduces questions around verification, ownership, provenance, moderation, and trust. The business should support information originating from different authorities and contributors while preserving trust and provenance.

### 5.3 Geographic Expansion

Beyond Nigeria only after the Nigerian model has matured and proven successful. Anticipated in the data model but not optimized for prematurely.

---

## 6. Business Capabilities

Business capabilities describe what the business must be able to do, independent of software, implementation, or organizational structure. The 10 MVP capabilities constitute the current capability baseline, not an immutable statement of every future capability. Changes should follow the established business-discovery change-proposal process.

### 6.1 Core MVP Capabilities (8)

| # | Capability | Purpose |
|---|-----------|---------|
| 1 | Acquire Educational Information | Obtain information from authoritative and publicly available sources. |
| 2 | Organize Educational Knowledge | Transform acquired information into consistent, structured, understandable knowledge. |
| 3 | Verify Educational Information | Evaluate reliability, authority, and currency of information. |
| 4 | Maintain Educational Knowledge | Keep information accurate, current, and historically traceable as it changes. |
| 5 | Discover Educational Opportunities | Enable users to find relevant opportunities without knowing exactly what they are looking for. |
| 6 | Search Educational Knowledge | Allow users to efficiently locate known information. |
| 7 | Compare Educational Opportunities | Enable objective comparison using standardized information. |
| 8 | Present Educational Knowledge | Communicate information clearly, understandably, and accessibly, including its provenance and references to authoritative sources where appropriate. |

### 6.2 Supporting MVP Capabilities (2)

| # | Capability | Purpose |
|---|-----------|---------|
| 9 | Preserve Information Provenance | Maintain traceability between information and its supporting sources. |
| 10 | Manage Information Quality | Continuously improve completeness, consistency, and quality. |

Users can report information as incorrect, outdated, missing, or conflicting. Reports enter an information-quality workflow and do not directly modify canonical data.

### 6.3 Future Capabilities (5)

| # | Capability | Stage |
|---|-----------|-------|
| 11 | Personalize educational guidance | Stage 2 |
| 12 | Support verified organization participation | Stage 3 |
| 13 | Notify users of important changes | Stage 2 |
| 14 | Provide trusted education data to third parties | Stage 4 |
| 15 | Enable ecosystem collaboration | Stage 3/4 |

### 6.4 Capability Relationships

Capabilities describe what the business is able to do. These relationships indicate which capabilities require or benefit from others -- they are not a fixed business process or execution order. Workflows that compose these capabilities will be discovered later.

| Capability | Relationship | Related Capability |
|-----------|-------------|-------------------|
| Compare Educational Opportunities | depends on | Organized Educational Knowledge |
| Search Educational Knowledge | depends on | Organized Educational Knowledge |
| Discover Educational Opportunities | depends on | Organized Educational Knowledge |
| Present Educational Knowledge | consumes outputs from | Search, Discover, Compare |
| Verify Educational Information | improves | Information Quality (via Manage Information Quality) |
| Preserve Information Provenance | supports | Verify, Maintain, Present |
| Acquire Educational Information | feeds | Organize Educational Knowledge |

---

## 7. Business Workflows

Workflows describe how users achieve business goals by exercising business capabilities. They are derived from approved business discovery, not invented independently. Workflows are defined by business goals, not by search activities (P9). Variations within a workflow remain within the same workflow unless they introduce fundamentally different business goals (P10). Workflows may be executed in any order; there is no mandatory sequence.

The 6 canonical workflows (WF1-WF6) represent the recurring business goals exercised by all four primary personas. Their emergence across multiple personas indicates they are properties of the domain rather than of individual users (P14). WF7 is persona-specific, addressing a goal unique to the Undergraduate Student's relationship with the domain.

### 7.1 WF1: Explore Educational Opportunities

**Business Goal:** Understand what educational opportunities exist based on interests, qualifications, or aspirations.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Exploring tertiary institutions, programmes, scholarships, alternative admission pathways. |
| Undergraduate Student | Exploring postgraduate programmes, transfer options, scholarships, internships. |
| Parent or Guardian | Exploring opportunities on behalf of their child -- same goal, acting as proxy decision-maker. |
| Guidance Counsellor or Teacher | Exploring opportunities on behalf of students -- same goal, multi-student advisory context, may execute proactively to maintain professional awareness. |

**Trigger:** User wants to know what educational options are available -- a broad intent, not a specific target.

**Preconditions:** User has some educational context (interests, current qualifications, or aspirations) but may not know exact names or identifiers of matching opportunities.

**Success Outcome:** User is aware of relevant educational opportunities they did not previously know about, and can identify at least one opportunity worth further evaluation.

**High-Level Business Steps:**

1. Express interests, qualifications, or aspirations (may be broad or vague).
2. Discover educational opportunities that match or relate.
3. Review discovered opportunities at a high level.
4. Identify opportunities worth further evaluation.

**Business Capabilities Exercised:** Discover Educational Opportunities, Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF1-1: Exploration must support users who do not know exact names or identifiers (structured exploration principle).
- BR-WF1-2: Exploration results must be presented in a way that allows high-level assessment without requiring full evaluation.

### 7.2 WF2: Evaluate Educational Opportunities

**Business Goal:** Gather sufficient information about an educational opportunity to make an informed decision.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Evaluating institutions, programmes, scholarship terms, admission prospects. |
| Undergraduate Student | Evaluating postgraduate institutions, scholarship conditions, transfer requirements. |
| Parent or Guardian | Evaluating opportunities on behalf of their child -- may weight different information priorities (e.g., cost, safety). |
| Guidance Counsellor or Teacher | Evaluating opportunities on behalf of students -- multi-student advisory, may need to evaluate across multiple student profiles. |

**Trigger:** User has identified one or more opportunities of interest (from Explore or from prior knowledge).

**Preconditions:** User has identified at least one educational opportunity to evaluate.

**Success Outcome:** User has sufficient information about the opportunity to compare it, assess eligibility, assess reliability, or make a decision.

**High-Level Business Steps:**

1. Select an educational opportunity to evaluate.
2. Review available information about the opportunity.
3. Identify information gaps -- information the user needs but is not available or not sufficient.
4. Assess whether available information is sufficient for the user's decision needs.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF2-1: What constitutes "sufficient" information is user-dependent and context-dependent. An evaluation is sufficient when the information required for the specific decision is available, sufficiently trustworthy, current for the relevant period, and comparable across alternatives.
- BR-WF2-2: The specific information types required (e.g., tuition, accreditation, scholarships, career pathways) belong to business rules and future domain discovery, not the workflow definition (P11).

### 7.3 WF3: Compare Educational Opportunities

**Business Goal:** Objectively compare multiple opportunities using standardized information before making a decision.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Comparing institutions, programmes, scholarship packages. |
| Undergraduate Student | Comparing postgraduate programmes, scholarship packages, transfer destinations. |
| Parent or Guardian | Comparing opportunities on behalf of their child -- may prioritize cost and quality dimensions. |
| Guidance Counsellor or Teacher | Comparing opportunities on behalf of students -- same goal, may compare across multiple student contexts. |

**Trigger:** User has evaluated or is evaluating multiple opportunities and wants to compare them.

**Preconditions:** User has identified two or more educational opportunities to compare.

**Success Outcome:** User can see opportunities compared on standardized criteria relevant to their decision, and can identify meaningful differences and trade-offs.

**High-Level Business Steps:**

1. Select educational opportunities to compare.
2. Review available comparison criteria relevant to the decision.
3. Compare opportunities across selected criteria.
4. Identify meaningful differences and trade-offs.

**Business Capabilities Exercised:** Compare Educational Opportunities, Present Educational Knowledge.

**Business Rules:**

- BR-WF3-1: Comparison uses standardized information (Standardized Information concept).
- BR-WF3-2: The user reviews available comparison criteria; the workflow does not assume the user defines the comparison model.
- BR-WF3-3: Available comparison criteria are determined by what standardized information exists for the selected opportunities.

**Standard comparison dimensions (from OQ6-2):** Common foundation is identity, location, eligibility/requirements, cost/benefit, timing, availability, authority/provenance, and status -- with category-specific dimensions for institutions, programmes, scholarships, and other opportunity types.

### 7.4 WF4: Assess Eligibility

**Business Goal:** Determine whether the user's qualifications satisfy the published admission requirements.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Assessing eligibility for tertiary admission (UTME, Direct Entry, IJMB, JUPEB pathways). Note: Admission Pathway is a Value Object, not an entity. |
| Undergraduate Student | Assessing eligibility for postgraduate admission, scholarship qualification, transfer requirements. |
| Parent or Guardian | Assessing eligibility on behalf of their child, using the child's qualifications. |
| Guidance Counsellor or Teacher | Assessing eligibility on behalf of students, using each student's qualifications. |

**Trigger:** User wants to know if they qualify for a specific educational opportunity.

**Preconditions:** User has identified an educational opportunity and has (or can provide) their qualifications.

**Success Outcome:** User understands the degree to which their qualifications meet the published admission requirements.

**High-Level Business Steps:**

1. Identify the educational opportunity and its published admission requirements.
2. Review or provide own qualifications.
3. Assess the match between qualifications and requirements.
4. Understand the result -- which requirements are met, partially met, or unmet.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge.

**Business Rules:**

- BR-WF4-1: Assessment is based on published admission requirements as recorded by StudyNexus.
- BR-WF4-2: The method of eligibility assessment (performed by StudyNexus, self-assisted by user, or presented for manual review) is deferred to Product Discovery. Initially: provide authoritative requirements for self-assessment. Progressively: structured eligibility assessment where underlying requirements and rules are sufficiently reliable and machine-actionable.

**Candidate Business Concept:** Eligibility Status (the degree to which a user's qualifications match published admission requirements: meet, partially meet, or do not meet).

### 7.5 WF5: Assess Information Reliability

**Business Goal:** Determine whether educational information is trustworthy, current, and supported by authoritative sources.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Assessing reliability of admission information, cut-off marks, scholarship details. |
| Undergraduate Student | Assessing reliability of postgraduate information, scholarship details, institutional claims. |
| Parent or Guardian | Assessing reliability of information on behalf of their child -- may have lower trust threshold for decisions affecting others. |
| Guidance Counsellor or Teacher | Assessing reliability of information before advising students -- professional obligation to verify before recommending. |

**Trigger:** User encounters information and needs to assess its reliability before relying on it for a decision.

**Preconditions:** User is viewing educational information and has doubt or need for confidence about its accuracy or currency.

**Success Outcome:** User can make a judgment about whether to trust the information based on available trust signals.

**High-Level Business Steps:**

1. Encounter educational information of interest.
2. Review available trust signals for the information.
3. Form a judgment about the reliability of the information.

**Business Capabilities Exercised:** Verify Educational Information, Present Educational Knowledge, Preserve Information Provenance.

**Business Rules:**

- BR-WF5-1: Trust signals are implementation-neutral. They may include provenance, verification status, publication dates, official sources, editorial review, or other mechanisms (P12).
- BR-WF5-2: The specific trust signals presented are a Product Discovery decision.

**Trust signals by Information Category (from OQ6-8):** Official = directly attributable to an authoritative institution/agency. Verified = independently checked by StudyNexus. Historical = valid for a previous period/version. Community-Contributed = user-supplied information not established as authoritative.

**Candidate Business Concept:** Trust Signal (an implementation-neutral signal that helps users assess the reliability of information).

### 7.6 WF6: Make an Educational Decision

**Business Goal:** Reach a decision about whether and how to proceed with an educational opportunity.

**Which Personas Use This Workflow:**

| Persona | Variation Context |
|---------|-------------------|
| Secondary School Student and Graduate | Deciding whether to apply to an institution/programme, pursue a scholarship. |
| Undergraduate Student | Deciding whether to pursue postgraduate study, accept a scholarship, transfer. |
| Parent or Guardian | Deciding on behalf of or with their child -- shared decision-making context. |
| Guidance Counsellor or Teacher | Supporting a student's decision -- the counsellor advises, the student decides. Same workflow goal. |

**Trigger:** User has gathered, compared, and verified sufficient information to decide.

**Preconditions:** User has evaluated one or more educational opportunities and assessed relevant eligibility and reliability.

**Success Outcome:** User reaches a decision -- whether to pursue, defer, or reject the opportunity.

**High-Level Business Steps:**

1. Consolidate information gathered about the opportunity or opportunities.
2. Weigh the relevant factors.
3. Reach a decision about the opportunity.

**Business Capabilities Exercised:** Present Educational Knowledge.

**Business Rules:**

- BR-WF6-1: The workflow ends with the user deciding. Whether the user applies, researches further, postpones, or rejects the opportunity is outside the scope of this workflow.
- BR-WF6-2: StudyNexus supports informed decision-making but does not perform applications in the MVP.
- BR-WF6-3: This workflow is reusable for scholarships, programmes, institutions, and future educational opportunities.

**Decision support scope (from OQ4-3 and OQ6-5):** Initially: structured consolidation, discovery, comparison, and verification. Progressively: recommendation and eligibility assessment where reliable structured data and rules support them. StudyNexus should support decisions rather than make opaque decisions on behalf of users.

**Candidate Business Concept:** Educational Decision (a user's decision about whether and how to proceed with an educational opportunity; the outcome may be to pursue, defer, or reject).

### 7.7 WF7: Understand Current Educational Journey

**Business Goal:** Understand information relevant to the educational opportunity the user is already pursuing in order to make informed decisions throughout that journey.

**Which Personas Use This Workflow:**

| Persona | Status |
|---------|--------|
| Undergraduate Student | Confirmed -- managing an existing educational commitment (programme, institution, academic progress). |
| Secondary School Student and Graduate | Not applicable -- not yet enrolled in tertiary education. |
| Parent or Guardian | Not confirmed -- a parent may need to understand their child's current programme, but this is an open question. |
| Guidance Counsellor or Teacher | Not confirmed -- a counsellor may need to understand a student's current programme to advise effectively, but this is an open question. |

**Trigger:** User needs clarity about their current programme, institution, or academic situation -- not to evaluate a new opportunity, but to manage an existing commitment.

**Preconditions:** User is currently enrolled in an educational programme.

**Success Outcome:** User has accurate, current understanding of information relevant to their ongoing educational journey, sufficient to make informed decisions.

**High-Level Business Steps:**

1. Identify the aspect of the current educational journey requiring clarity.
2. Access current, accurate information about that aspect.
3. Understand the implications for ongoing decisions.

**Business Capabilities Exercised:** Search Educational Knowledge, Present Educational Knowledge, Maintain Educational Knowledge (ensures information is current).

**Business Rules:**

- BR-WF7-1: This workflow is distinct from evaluation workflows because the user is not considering whether to pursue the opportunity -- they are managing an existing educational commitment.
- BR-WF7-2: The workflow is defined by its business goal, not by the specific information it may present. Examples of relevant information (programme requirements, academic regulations, curriculum, graduation requirements, accreditation changes, tuition and fee updates, available scholarships, transfer opportunities, progression opportunities, postgraduate pathways) are examples only and do not become part of the workflow definition (P11).
- BR-WF7-3: The specific information types relevant to this workflow belong to business rules and future domain discovery (consistent with BR-WF2-2).

**Critical information types for undergraduates (from OQ7-1):** Current institution, programme, academic level/year, academic calendar, academic requirements/status, courses, assessments, fees, deadlines, institutional policies/procedures, scholarships/opportunities, and progression/transfer information.

**Candidate Business Concept:** Current Educational Journey (the educational opportunity a user is already pursuing; distinct from prospective opportunities -- the user is managing an existing commitment, not evaluating a new one).

### 7.8 Workflow Relationships

These workflows are not executed in a mandatory sequence. Users may enter any workflow at any point based on their current need. However, typical patterns emerge:

- **Exploration then Evaluation then Comparison then Decision** is a common but not required pattern.
- **Assess Eligibility** and **Assess Information Reliability** may occur at any point after an opportunity is identified.
- **Make an Educational Decision** typically follows some combination of the other workflows but does not require all of them.
- **Understand Current Educational Journey** is independent -- it does not require or feed into the other workflows, though information gained may inform them.

### 7.9 Persona Workflow Summary

| Workflow | SS Student/Grad | Undergrad | Parent/Guardian | Guidance Counsellor/Teacher |
|----------|:---:|:---:|:---:|:---:|
| WF1: Explore Educational Opportunities | Y | Y | Y | Y |
| WF2: Evaluate Educational Opportunities | Y | Y | Y | Y |
| WF3: Compare Educational Opportunities | Y | Y | Y | Y |
| WF4: Assess Eligibility | Y | Y | Y | Y |
| WF5: Assess Information Reliability | Y | Y | Y | Y |
| WF6: Make an Educational Decision | Y | Y | Y | Y |
| WF7: Understand Current Educational Journey | -- | Y | ? | ? |

**Total canonical workflows:** 6 (exercised by all 4 primary personas).
**Total persona-specific workflows:** 1 (Undergraduate Student).
**Total workflows:** 7.

---

## 8. Candidate Business Concepts

These concepts were introduced during workflow discovery. They become canonical (promoted to the main glossary) only when they recur across multiple workflows or personas and receive explicit approval (P13). Per OQ7-3, do not automatically promote candidate concepts. Their status should depend on identity, lifecycle, ownership, persistence, and independent business behavior. They may instead be domain concepts, value objects, or attributes of other domain objects.

| Concept | Definition | Introduced In | Recurs Across Personas | Promotion Status |
|---------|-----------|---------------|----------------------|-----------------|
| Eligibility Status | The degree to which a user's qualifications match published admission requirements: meet, partially meet, or do not meet. | WF4 (Topic 6) | Yes -- all 4 primary personas | Eligible for promotion (OQ7-3) |
| Comparison Dimension | A standardized attribute on which educational opportunities can be evaluated and compared (e.g., tuition, admission requirements, accreditation status). | WF3 (Topic 6) | Yes -- all 4 primary personas | Eligible for promotion (OQ7-3) |
| Trust Signal | An implementation-neutral signal that helps users assess the reliability of information. May include provenance, verification status, publication dates, official sources, editorial review, or other mechanisms. | WF5 (Topic 6) | Yes -- all 4 primary personas | Eligible for promotion (OQ7-3) |
| Educational Decision | A user's decision about whether and how to proceed with an educational opportunity. The outcome may be to pursue, defer, or reject the opportunity. StudyNexus supports informed decision-making but does not perform applications. | WF6 (Topic 6) | Yes -- all 4 primary personas | Eligible for promotion (OQ7-3) |
| Current Educational Journey | The educational opportunity a user is already pursuing. Distinct from prospective opportunities -- the user is managing an existing commitment, not evaluating a new one. | WF7 (Topic 7) | No -- Undergraduate Student only | Not yet eligible |

The first four concepts now recur across all four primary personas via the canonical workflows and are eligible for promotion pending explicit approval.

---

## 9. Glossary

### 9.1 Canonical Terms

| Term | Definition |
|------|-----------|
| StudyNexus | Comprehensive education knowledge platform for Nigeria, with a vision to become Africa's education infrastructure. |
| Aggregate | Collect educational information from disparate sources into a unified system. |
| Verify | Confirm the accuracy and authenticity of educational information. |
| Organize | Structure educational information so it is navigable and comparable. |
| Searchable | Users can find information through query-based discovery. |
| Comparable | Users can evaluate options side-by-side on meaningful dimensions. |
| Trustworthy | Information has been verified or sourced credibly enough for users to rely on it. |
| Primary User | A user the platform must serve on day one to justify its existence. |
| Secondary School Student and Graduate | A student currently in secondary school (e.g., SS3) or a recent graduate preparing to pursue tertiary education. |
| Undergraduate Student | A student already enrolled in tertiary education. |
| Parent or Guardian | A decision-maker helping a child navigate educational choices. |
| Guidance Counsellor / Teacher | An educator helping students make informed educational decisions. |
| JAMB | Joint Admissions and Matriculation Board -- Nigeria's unified tertiary admission body. |
| WAEC | West African Examinations Council. |
| NECO | National Examinations Council. |
| NABTEB | National Business and Technical Examinations Board. |
| NUC | National Universities Commission. |
| NBTE | National Board for Technical Education. |
| NCCE | National Commission for Colleges of Education. |
| Cut-off Mark | Minimum score required for admission into a programme or institution. |
| Programme | A specific course of study offered by an institution (e.g., "Computer Science" at University of Lagos). |
| Secondary User | A user who benefits from the platform's data but is not required for the initial value proposition. |
| Educational Institution | A university, polytechnic, college of education, Innovation Enterprise Institution (IEI), or other institution offering educational programmes. |
| Scholarship Provider | A government agency, NGO, foundation, corporation, or educational organization that provides scholarships. |
| Government Education Agency | An official body that regulates, examines, or coordinates education in Nigeria (e.g., JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies). |
| Strategic Partner | A secondary user who provides or publishes authoritative information rather than actively using the platform as a primary workflow. |
| Innovation Enterprise Institution (IEI) | A category of institution recognized within the Nigerian tertiary education system, distinct from universities, polytechnics, and colleges of education. |
| Structured Exploration | The ability for users to discover relevant educational opportunities without already knowing their exact names or identifiers. Implementation determined during Product Design and Architecture. |
| Information Category | A classification of information provenance: Official (from authoritative source), Verified (confirmed by StudyNexus), Historical (accurate as of a past date), Community-Contributed (user-submitted, unverified). Day-one support scope is a Product Roadmap decision. |
| Alternative Admission Pathway | A route into tertiary education beyond the standard UTME route, including Direct Entry, IJMB, JUPEB, diploma pathways, and other recognized admission routes. Admission Pathway is a Value Object, not an entity. |
| Standardized Information | Educational information presented in a consistent structure and format that enables side-by-side comparison across institutions and programmes. |
| Accessibility | A problem dimension distinct from Discoverability: information exists but is practically inaccessible due to format, connectivity, device, or usability barriers. |
| IJMB | Interim Joint Matriculation Board -- an alternative admission pathway programme in Nigeria. |
| JUPEB | Joint Universities Preliminary Examinations Board -- an alternative admission pathway programme in Nigeria. |
| Direct Entry | Admission into tertiary education at an advanced level (typically 200-level) based on prior qualifications such as A-levels, IJMB, JUPEB, ND, or NCE. |
| MVP | Minimum Viable Product -- Stage 1 of StudyNexus evolution: Trusted Education Knowledge Base. |
| Stage 1 | Trusted Education Knowledge Base -- aggregate, organize, verify, present educational knowledge in searchable, comparable form. Strategic business stage, not a fixed implementation phase. |
| Stage 2 | Personalized Education Companion -- personalization, saved preferences, notifications, decision support built on the knowledge base. Strategic business stage, not a fixed implementation phase. |
| Stage 3 | Education Ecosystem -- verified organizations participate directly in maintaining and publishing information. Strategic business stage, not a fixed implementation phase. |
| Stage 4 | Education Infrastructure -- trusted educational data and services exposed through well-defined interfaces for third-party consumption. Strategic business stage, not a fixed implementation phase. |
| Provenance | The origin and custody history of a piece of information -- who created it, who modified it, and when. Critical for the Stage 3 transition. |
| Business Capability | A description of what the business must be able to do, independent of software, implementation, or organizational structure. |
| Core Capability | A business capability that directly delivers value to primary users and is required for the MVP. |
| Supporting Capability | A business capability that enables or sustains core capabilities but is not directly user-facing. |
| Future Capability | A business capability that is not required for the MVP but is expected to be needed in later stages. |
| Capability Relationship | A relationship between capabilities indicating that one requires, benefits from, feeds, consumes, or supports another. Not a fixed execution order. |
| Business Workflow | A description of how a user achieves a business goal by exercising one or more business capabilities. Defined by business goal, not by search activity. |
| Canonical Workflow | A business workflow whose goal recurs independently across multiple primary personas. Defined by the domain, not by any individual persona. Currently: WF1-WF6. |
| Persona-Specific Workflow | A business workflow that addresses a goal unique to a particular persona's relationship with the domain. Currently: WF7 (Undergraduate Student only). |

---

## 10. Deferred Items

Items that have been resolved during business discovery but require future action at the appropriate time. Deferral is intentional and principled: each item has been acknowledged, its strategic direction set, but its precise resolution requires data or context that does not yet exist. Deferral avoids premature commitment that would constrain the information architecture or produce unjustified persona prioritisation.

### 10.1 Monetisation Mechanics (OQ4-4)

The exact monetisation mechanics are deferred. The strategic model is established: free core discovery, search, and information access, with future monetisation through institution/provider services, premium capabilities, and relevant education-related commercial services. Critically, monetisation should not drive the core information architecture. The free-access commitment for core discovery ensures that the platform's primary value proposition remains unconstrained by commercial considerations during the MVP and early growth stages. Monetisation design will be tested against real usage data when the platform has sufficient traffic and behavioural evidence to inform viable commercial models without compromising the trust and accessibility that underpin the platform's identity.

**When to act:** When the business model is tested against real usage data.

### 10.2 Persona Severity Scoring (OQ3-4)

Detailed persona-by-persona severity scoring for the five problem dimensions is deferred. The current understanding establishes that Fragmentation, Discoverability, and Trust are foundational problem dimensions affecting all personas; Comparison is especially important during decision-making phases; Accessibility cuts across all personas regardless of their specific educational context. However, the relative severity of each dimension for each persona (e.g., whether Trust is more acute for Guidance Counsellors than for Secondary School Students) requires empirical user research data that is not yet available. Premature scoring would be speculative and could distort design prioritisation.

**When to act:** When user research data is available to support evidence-based persona severity profiles.

---

## 11. Discovery Principles

These 18 principles were established during business discovery and should guide all subsequent discovery phases.

| ID | Principle | Origin |
|----|-----------|--------|
| P1 | **Never guess missing information** -- ask focused questions. | Session protocol |
| P2 | **Never silently rename concepts** -- respect established domain terminology. | Session protocol |
| P3 | **Never redesign previously approved decisions** -- build incrementally. | Session protocol |
| P4 | **Never introduce unjustified architectural patterns** -- defer to architecture phase. | Session protocol |
| P5 | **No implementation talk during Business Discovery** -- stay at business level. | Session protocol |
| P6 | **Discover one business topic at a time** -- don't combine unrelated topics. | Session protocol |
| P7 | **Maintain incremental canonical documents** -- never regenerate from scratch. | Session protocol |
| P8 | **Separate Approved Decisions, Proposed Ideas, and Open Questions** -- never conflate. | Session protocol |
| P9 | **Workflows are defined by business goals, not search activities.** | Topic 6 (A6-2) |
| P10 | **Variations remain within the same workflow unless fundamentally different goals.** | Topic 6 (A6-3) |
| P11 | **Workflow definitions should remain stable** -- specific information types belong to business rules and domain discovery. | Topic 6 (A6-5) |
| P12 | **Keep business language implementation-neutral** -- e.g., "trust signals" not "provenance indicators". | Topic 6 (A6-8) |
| P13 | **Candidate concepts require recurrence + explicit approval to become canonical.** | Topic 6 (A6-10) |
| P14 | **Canonical workflows emerge from the domain, not from individual personas.** | Topic 8 (A8-1) |
| P15 | **Execution context is not business goal** -- different personas may execute workflows differently without introducing new goals. | Topic 9 (A9-2) |
| P16 | **New workflows require 4 conditions:** different goal, different trigger, different success outcome, would exist independently of existing workflows. | Topic 9 |
| P17 | **Architecture flexibility principle** -- secondary users influence flexibility without compromising day-one simplicity. | Topic 2 (A2-10) |
| P18 | **Business evolution is not product roadmap** -- stages are strategic, not chronological. | Topic 4 (A4-1) |
