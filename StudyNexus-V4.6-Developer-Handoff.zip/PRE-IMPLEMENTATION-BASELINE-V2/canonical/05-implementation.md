# StudyNexus -- Implementation Blueprint

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | CANONICAL IMPLEMENTATION BLUEPRINT |
| Hard Baseline | Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4 |
| Purpose | Single coherent implementation blueprint consolidating the pre-implementation blueprint, package audit, and reconciliation into one canonical document with all corrections applied |

> This document is the canonical implementation reference. It consolidates and corrects all prior documents. Where earlier documents conflict with this document, this document prevails. All canonical corrections -- entity count, VO count, enum count, package names, version constraints, and architectural decisions -- are applied throughout. No Laravel 12, Filament v3, or Livewire v3 instructions remain.

---

## 1. Platform Baseline

The platform baseline is non-negotiable. Every package, every migration, every code decision is evaluated against this baseline. There is no Laravel 12 fallback, no PHP 8.3 fallback, no Filament v3 fallback, and no Livewire v3 fallback. The implementation targets Laravel 13 because starting a new project on the current framework major avoids an upgrade cycle within the first year, PHP 8.5 provides performance and language improvements (readonly promoted constructors, fiber improvements, attribute enhancements), and Laravel 13's release cadence means it will receive security patches longer than Laravel 12.

### 1.1 Core Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| PHP | -- | 8.5+ | Required baseline; no fallback |
| Laravel | `laravel/framework` | ^13.0 | Current stable; all packages must be compatible |
| PostgreSQL | -- | 16+ | Primary data store (ADR-01) |
| Redis | -- | 7+ | Cache + queue driver |
| Typesense | -- | 29.x+ | V1 search engine; server v30.x latest stable |
| Node.js | -- | 22 LTS | Asset compilation (Vite) |

### 1.2 Frontend Stack (TALL)

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Tailwind CSS | `tailwindcss` | ^4.0 | Utility-first styling; v4.3.3 current |
| Alpine.js | `alpinejs` | ^3.x | Lightweight client-side interactivity; v3.15.12 current |
| Livewire | `livewire/livewire` | ^4.0 | Server-driven reactive UI; v4 is required for Laravel 13 |
| Flux | `livewire/flux` | ^1.0 | UI component library; supports Livewire v4 |

### 1.3 Admin Stack

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Filament | `filament/filament` | ^5.0 | Admin panel framework; v5 designed for Livewire v4 + Laravel 13 + PHP 8.5 |
| Rich Editor | Filament native RichEditor | Built-in | Replaces deprecated `filament/tiptap-editor` |

### 1.4 Auth and Testing

| Component | Package | Version Constraint | Notes |
|---|---|---|---|
| Laravel Fortify | `laravel/fortify` | ^1.0 | Backend auth scaffolding (rate-limited login, registration, password reset, email verification) — paired with Livewire/Flux Pro for UI |
| Laravel Sanctum | `laravel/sanctum` | ^4.0 | API token authentication for future API/mobile |
| Laravel Scout | `laravel/scout` | ^11.0 | Search driver abstraction; Typesense driver for V1; `database` driver (PostgreSQL FTS) available as fallback |
| Pest | `pestphp/pest` | ^4.0 | Test framework |

### 1.5 Version Rationale

Livewire v4 (not v3) is required because Livewire v3 does not support Laravel 13. Filament v5 (not v3) is required because Filament v3 requires `illuminate/support ^10.45|^11.0|^12.0`, which is incompatible with Laravel 13. Filament v5 is designed specifically for Livewire v4 + Laravel 13 + PHP 8.5 and is the natural choice. The deprecated `filament/tiptap-editor` package is replaced by Filament v5's native Rich Editor component, which provides equivalent rich text editing capability without the external dependency. All code samples or instructions referencing Filament v3, Livewire v3, or Laravel 12 APIs are historical and must not be used in implementation.

---

## 2. Project Structure

The project follows the Laravel Beyond CRUD (LBC) architectural philosophy. This is not ceremonial DDD -- it is pragmatic domain-driven design that organizes code by domain concern rather than by technical layer, while avoiding unnecessary abstractions. There are no repository interfaces (ADR-04), no event sourcing (ADR-02), no SPA patterns (ADR-11), and no generic manager classes. Eloquent IS the repository. Domain events are plain PHP classes. Actions earn their complexity by meeting the explicit Action Criterion (multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization plus complex validation).

### 2.1 Namespace Architecture

```
app/
  Domain/
    Models/          (13 Eloquent models: 5 aggregates + 4 child entities + 4 supporting + 2 reference/query: Discipline, CutOffMark)
    Enums/           (17 PHP enums)
    ValueObjects/    (12 non-enum VOs)
    Events/          (29 domain events, plain PHP)
    Exceptions/      (domain exceptions)
    Services/        (InstitutionMerger only)
  Application/
    Actions/         (20 domain Actions + content/community actions)
    Queries/         (read-side query classes)
    DTOs/            (spatie/laravel-data request/response objects)
    Policies/        (Laravel authorization Policies)
    Listeners/       (event listeners for side effects)
  Content/
    Models/          (Article, Guide, EducationalResource, ExamPreparation)
    Concerns/        (HasSlug, IsPublishable, HasSeoMeta, HasMedia, etc.)
    Enums/           (ResourceType, PrepType, ContentStatus)
    Actions/         (content-specific actions)
    Queries/         (content-specific queries)
  Community/
    Models/          (Question, Answer, Comment, Vote, Report)
    Actions/         (community actions)
    Queries/         (community queries)
  StudyAbroad/
    Livewire/        (CountryPage, CompareDestinations, ScholarshipListing)
    Queries/         (study abroad queries)
  Reference/
    Models/          (Qualification, Country, Currency, etc.)
    Seeders/         (reference data seeders)
  Admin/
    Filament/        (admin panel resources, pages, widgets)
  Public/
    Livewire/        (interactive components for public site)
    Blade/           (Blade components & views)
    Controllers/     (thin controllers invoking Queries)
  Infrastructure/
    Search/          (Scout config, UpdateSearchIndex listener; Typesense V1, PostgreSQL FTS fallback)
    Integrations/    (third-party API clients)
    Persistence/     (Eloquent scopes, custom query builders)
```

### 2.2 Key Namespace Rules

Domain never imports Content. Domain never imports Community. Content may import Domain. Community may import Domain. StudyAbroad composes existing Domain and Content entities without introducing new aggregate roots or invariants. Reference models (Qualification, Country, Currency, etc.) are managed via Filament CRUD, not through domain Actions. The `App\Models\*` Laravel default namespace is NOT used for domain models; canonical location is `App\Domain\Models\*` (ADR from frozen baseline F1). Application-layer DTOs from `spatie/laravel-data` must not leak into the Domain layer -- they serve request/response mapping only.

### 2.3 Controllers (12)

| Controller | Routes |
|---|---|
| HomeController | / |
| InstitutionController | /institutions/{slug} |
| InstitutionProgrammeController | /institutions/{inst}/programmes |
| ProgrammeController | /institutions/{inst}/programmes/{prog} |
| ProgrammeDiscoveryController | /programmes, /programmes/{discipline} |
| ScholarshipController | /scholarships/{slug} |
| ArticleController | /news/{slug} |
| GuideController | /guides/{slug} |
| ResourceController | /resources/{slug} |
| ExamPrepController | /exam-prep/{slug} |
| StudyAbroadController | /study-abroad/* |
| CommunityQuestionController | /community/questions/* |

All controllers are thin: they invoke Query classes, pass results to Blade views, and return responses. Business logic lives in Actions (write) and Queries (read), never in controllers.

---

## 3. Domain Implementation

The frozen domain model from the canonical baseline is preserved intact. No frozen decision has been changed. The domain comprises 5 aggregate roots, 4 child entities, and 4 supporting entities (total: 13 entities). AdmissionPathway is a Value Object (no table, no separate entity), not a standalone entity with its own persistence. This section details each entity's implementation, migration schema, Eloquent relationships, and Action class signatures.

### 3.1 Aggregate Roots (5)

**Institution** -- The core entity. Name uniqueness within country; accreditation validity enforced as invariant. Migration: `institutions` table with columns for name, slug, type (InstitutionType enum), ownership_type (OwnershipType enum), registration_identifier (VARCHAR), website, founded_year, description, logo media collection, gallery media collection, status (InstitutionStatus: Provisional, Operational, Suspended, Closed), is_published (boolean, default false), published_at (timestamp, nullable), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Location is now on Campus (not Institution directly); Institution location is derived from its primary Campus. Relationships: hasMany Programmes, hasMany Campuses, hasMany AccreditationRecords, morphMany via OrganizationMember, morphMany Saves/Follows/Likes. Actions: CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, RecordAccreditation.

**Programme** -- Unique within institution; award level consistency enforced. Migration: `programmes` table with institution_id FK, name, slug, award_level (AwardLevel enum), discipline_id (BIGINT FK nullable, references disciplines per ADR-19), admission_mode (AdmissionMode enum), duration (Duration VO as JSON -- default/template duration), description, career_prospects, brochure media collection, status (ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued -- default Prospective, the abstract template is always 'available'; concrete status lives on ProgrammeInstance), is_published (boolean, default false), published_at (timestamp, nullable), provenance (JSONB, entity-level provenance per ND-4/ADR-23). delivery_mode and tuition REMOVED from Programme (moved to ProgrammeInstance). Relationships: belongsTo Institution, belongsTo Discipline (nullable), hasMany ProgrammeInstances, morphMany Saves/Follows/Likes. Actions: CreateProgramme, DiscontinueProgramme, RecordAccreditation.

**Scholarship** -- Application window validity; eligibility criteria non-empty. Migration: `scholarships` table with name, slug, provider_id FK, provider_type (morph), value (MonetaryAmount VO as JSON), coverage_type (CoverageType enum), eligibility_criteria (EligibilityRule VO as JSON), application_start, application_deadline, description, status (ScholarshipStatus: Draft, Announced, Open, Closed, Expired, Withdrawn), is_published (boolean, default false), published_at (timestamp, nullable), images media collection. Relationships: morphTo provider (ScholarshipProvider or Institution), morphMany Saves/Follows/Likes. Actions: AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes.

**AdmissionCycle** -- Date ordering invariant (start less than or equal to end); phase transitions follow defined sequence. Migration: `admission_cycles` table with authority_id (BIGINT FK, references education_authorities), name, admission_pathway (AdmissionPathway VO -- string value, no separate table), academic_year, phase_sequence (JSONB, PhaseSequence VO per ADR-20), current_phase (VARCHAR, stable phase ID per ADR-20), starts_at, ends_at, status (AdmissionCycleStatus: Upcoming, Active, Closed, Archived). Relationships: belongsTo EducationAuthority, hasMany AdmissionPolicies. Actions: AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase. Phase transitions use lockForUpdate() inside transaction (BD-3/ADR-20). Domain events dispatched after commit. **Stable phase IDs:** application-generated string slugs (e.g., "registration", "examination", "result_release") defined at AdmissionCycle creation time, immutable after activation. NOT UUIDs, NOT auto-increment integers, NOT hashes — meaningful string identifiers chosen by the content team.

**InformationSource** -- Independent aggregate root (ND-5/ADR-22). URL or contact required; reliability status tracked. Migration: `information_sources` table with authority_id (BIGINT FK nullable, references education_authorities per ND-5/ADR-22 — NULL means not published by an EducationAuthority), source_type, url, contact_name, contact_email, reliability (SourceReliability enum: Registered, Verified, Unreliable, Deprecated), category (InformationCategory enum: Official, Unofficial, Historical, Scraped), verified_at, verified_by, notes, provenance (JSONB, entity-level provenance per ND-4/ADR-23). Relationships: belongsTo EducationAuthority (nullable). No institution_id FK. Actions: RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable.

### 3.2 Child Entities (4)

**AdmissionPolicy** -- belongsTo AdmissionCycle (polymorphic: ProgrammeInstance or Institution). Migration: `admission_policies` table with governable_type, governable_id (morph), admission_cycle_id FK, title, description, policy_rules (AdmissionRule VO as JSON), qualification_requirements, valid_from, valid_until (ValidityPeriod VO as JSON), status (PolicyStatus enum). No independent Actions -- published by parent's PublishAdmissionPolicy Action.

**EligibilityPolicy** -- belongsTo Scholarship. Migration: `eligibility_policies` table with scholarship_id FK, title, criteria (EligibilityRule VO as JSON), minimum_score, valid_from, valid_until (ValidityPeriod VO as JSON), status (PolicyStatus enum). No independent Actions -- published by parent's domain method.

**AccreditationRecord** -- Polymorphic belongsTo (Programme or Institution). Migration: `accreditation_records` table with accreditable_type, accreditable_id (morph), authority_id FK, accreditation_type, status (AccreditationStatus enum: Full, Interim, Probationary, Revoked, Expired), valid_from, valid_until (ValidityPeriod VO as JSON), certificate_url, created_at. Immutable after creation. Action: RecordAccreditation (on parent).

**ProgrammeInstance** -- Child entity of Programme. Represents one concrete offering at a Campus in an Academic Year with a DeliveryMode. Migration: `programme_instances` table with programme_id FK, campus_id FK (references campuses), delivery_mode (DeliveryMode enum), academic_year (VARCHAR, e.g., "2025/2026"), capacity (INTEGER nullable), status (ProgrammeStatus enum: Prospective, Admitting, Suspended, Discontinued -- concrete admission status lives here), tuition (JSON -- MonetaryAmount VO, nullable -- same programme may have different tuition per campus/mode), duration (JSON -- Duration VO, nullable -- may override Programme default), is_published (BOOLEAN, default false), published_at (TIMESTAMP nullable), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Unique constraint: (programme_id, campus_id, delivery_mode, academic_year) -- INV-PI1. No independent Actions -- lifecycle bounded by parent Programme. When Programme is discontinued, all instances cascade to Discontinued. Domain methods: publishAdmissionPolicy(cycleId, rules), addCutOffMark(cycleId, pathway, value, sourceId). Admission criteria are scoped to the specific offering (instance), not the abstract programme.

### 3.3 Supporting Entities (4)

**ScholarshipProvider** -- Migration: `scholarship_providers` table with name, slug, type (ProviderType enum), description, website, logo media collection. Relationships: morphMany Scholarships. This is a supporting entity, not an aggregate root; it exists to normalize scholarship provider data.

**EducationAuthority** -- Migration: `education_authorities` table with name, slug, type (AuthorityType enum), jurisdiction (AuthorityJurisdiction VO as JSON), description, website. Relationships: morphMany AccreditationRecords, hasMany InformationSources (nullable FK), hasMany AdmissionCycles. Supporting entity for accreditation and regulatory data.

**Qualification** -- Moved from Domain to Reference namespace (per reconciliation R5). Migration: `qualifications` table in Reference layer with name, level, authority_id (BIGINT FK, references education_authorities), status (QualificationStatus enum: Active, Deprecated). Managed via Filament CRUD, not domain Actions. This move eliminates the Reference-to-Domain FK violation in `qualification_equivalencies`.

**Campus** -- Supporting entity belonging to Institution. Enables multi-campus institutions. Migration: `campuses` table with institution_id FK, name, slug, location (JSON -- Location VO: country, region, city; nullable for online-only), is_primary (BOOLEAN, default false), established_year (INTEGER nullable), status (CampusStatus enum: Active, Inactive, Planned), created_at, updated_at. Invariant: exactly one Campus per Institution must be is_primary=true (INV-CAMP1). Index: institution_id, slug (unique within institution), is_primary, status.

### 3.5 Infrastructure Entities (2)

**ExternalIdentifier** -- Generic external identifiers (BD-5/ADR-21). No per-entity code columns on canonical entities. Migration: `external_identifiers` table with entity_type (VARCHAR(255)), entity_id (BIGINT), authority_id (BIGINT FK NOT NULL, references education_authorities), identifier_type (VARCHAR(100)), identifier (VARCHAR(255)), status (VARCHAR(50) DEFAULT 'active'), valid_from (TIMESTAMP DEFAULT NOW()), valid_until (TIMESTAMP NULL), source_id (BIGINT FK NULL, references information_sources), replaced_by_id (BIGINT FK NULL, self-referencing), retirement_reason (TEXT NULL), metadata (JSONB NULL), timestamps. Partial unique indexes: INV-EI1 (global): UNIQUE (authority_id, identifier_type, identifier) WHERE status = 'active'; INV-EI2 (per-entity): UNIQUE (entity_type, entity_id, authority_id, identifier_type) WHERE status = 'active'.

**FieldProvenance** -- Field-level provenance (ND-4/ADR-23). Migration: `field_provenance` table with entity_type (VARCHAR(255)), entity_id (BIGINT), field_name (VARCHAR(255)), source_id (BIGINT FK NULL, references information_sources, ON DELETE RESTRICT), observed_value (TEXT), confidence (SMALLINT NULL), verification_status (VARCHAR(50) DEFAULT 'unverified'), observed_at (TIMESTAMP), superseded_at (TIMESTAMP NULL), superseded_by_id (BIGINT FK NULL, self-referencing), retroactive (BOOLEAN DEFAULT FALSE), timestamps. Index: (entity_type, entity_id, field_name). No is_active column — derive active from superseded_at IS NULL.

**Self-referencing FK handling (replaced_by_id, superseded_by_id):**
- replaced_by_id (external_identifiers) and superseded_by_id (field_provenance) are NULL for the first (current) record in any chain.
- ON DELETE RESTRICT for both — cannot delete a row that is referenced by another row's replaced_by_id/superseded_by_id.
- No circular chains — application logic ensures A → B → C (never A → B → A).

### 3.6 Value Objects (29 total = 12 non-enum + 17 enums)

**Non-enum Value Objects (12):**

| # | Value Object | Description | Cast | Persisted? |
|---|---|---|---|---|
| 1 | AdmissionRule | Admission requirement: qualification reference, threshold, subject combinations, rule type | AdmissionRuleCast | Yes (JSON) |
| 2 | EligibilityRule | Eligibility criterion: criterion type, comparator, value | array | Yes (JSON) |
| 3 | SubjectCombination | Ordered set of subjects with combination type (AND/OR) | array | Yes (JSON) |
| 4 | QualificationThreshold | Qualification reference + comparator + value + scale | array | Yes (JSON) |
| 5 | ValidityPeriod | Start date + end date for policy/accreditation validity | ValidityPeriodCast | Yes (JSON) |
| 6 | TrustSignal | Computed reliability indicator for an Information Source | None | No (computed) |
| 7 | MonetaryAmount | Amount + currency (ISO 4217) for fees and scholarship values | MonetaryAmountCast | Yes (JSON) |
| 8 | Duration | Value + unit (years, months, semesters) for programme length | array | Yes (JSON) |
| 9 | Location | Country + region + city for institution geographic location (nullable for online-only) | LocationCast | Yes (JSON) |
| 10 | AuthorityJurisdiction | Jurisdiction type + criteria defining an Education Authority's scope | array | Yes (JSON) |
| 11 | PhaseSequence | Ordered list of admission cycle phases with timing | array | Yes (JSONB) |
| 12 | AdmissionPathway | Name + authority reference for an admission route (demoted from entity to VO) | string | Yes (VARCHAR) |

**Domain Enums (17):** 3 behavioural (with domain methods) + 14 pure (closed sets of domain values).

#### Behavioural Enums (3)

| # | Enum | Key Values | Behaviour |
|---|---|---|---|
| 1 | InstitutionType | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution (MVP; expansion to 7+ values triggers ADR-15) | `isDegreeGranting()`, `isTertiary()` -- determines jurisdiction and valid award levels |
| 2 | AwardLevel | BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma | `isPostgraduate()`, `isUndergraduate()` -- affects admission pathways and programme classification |
| 3 | AdmissionMode | Cyclic, Rolling, MultipleIntake | Affects `isAdmitting` query logic: Cyclic checks cycle phase + policy; Rolling checks status only; MultipleIntake checks intake dates |

#### Pure Enums (14)

| # | Enum | Key Values | Owning Entity |
|---|---|---|---|
| 4 | AccreditationStatus | Full, Interim, Probationary, Revoked, Expired | Accreditation Record |
| 5 | PolicyStatus | Draft, Published, Superseded, Withdrawn | Admission Policy, Eligibility Policy |
| 6 | ProgrammeStatus | Prospective, Admitting, Suspended, Discontinued | Programme, Programme Instance |
| 7 | ScholarshipStatus | Draft, Announced, Open, Closed, Expired, Withdrawn | Scholarship |
| 8 | InstitutionStatus | Provisional, Operational, Suspended, Closed | Educational Institution |
| 9 | SourceReliability | Registered, Verified, Unreliable, Deprecated | Information Source |
| 10 | InformationCategory | Official, Unofficial, Historical, Scraped | Information Source |
| 11 | AuthorityType | Regulatory, Accreditation, Funding, Admissions | Education Authority |
| 12 | ProviderType | Government, Corporate, NGO, Institution | Scholarship Provider |
| 13 | OwnershipType | Public, Private, PPP, Religious | Educational Institution |
| 14 | DeliveryMode | OnCampus, Online, Hybrid | Programme Instance |
| 15 | QualificationStatus | Active, Deprecated | Qualification |
| 16 | CoverageType | Full, Partial, TuitionOnly, Stipend | Scholarship |
| 17 | CampusStatus | Active, Inactive, Planned | Campus |

**AdmissionPathway is a Value Object** (VO #12 above), not an enum. It is stored as a string value on the `admission_cycles` table, not as a separate entity with its own table. Pathway values are reference data managed by the application layer; Nigerian pathways (UTME, PostUTME) and international pathways (UCAS, CommonApp) are data, not domain structure. No AdmissionPathway enum exists in the Domain layer.

### 3.5 Domain Events (29)

Domain events represent business facts that other parts of the system react to. Plain PHP classes dispatched via Laravel's event dispatcher. No shared `DomainEvent` interface. No event store. No event sourcing. Events are plain PHP classes with constructor-injected payload (ADR-3, ADR-16). An event is emitted only when the state change represents a business fact that downstream consumers might need, at least one concrete downstream reaction exists, and the event carries sufficient information for the reaction without requiring the consumer to reload the aggregate.

| # | Event | Emitting Entity | Trigger | Payload |
|---|-------|----------------|---------|---------|
| 1 | InstitutionEstablished | Institution | `establish()` | institutionId, name, type, occurredAt |
| 2 | InstitutionRenamed | Institution | `rename()` | institutionId, oldName, newName, occurredAt |
| 3 | InstitutionSuspended | Institution | `suspend()` | institutionId, occurredAt |
| 4 | InstitutionReactivated | Institution | `reactivate()` | institutionId, occurredAt |
| 5 | InstitutionClosed | Institution | `close()` | institutionId, occurredAt |
| 6 | InstitutionsMerged | InstitutionMerger | `merge()` | initiatingId, targetId, occurredAt |
| 7 | InstitutionAccredited | Institution | `recordAccreditation()` | institutionId, authorityId, status, occurredAt |
| 8 | InstitutionalAdmissionPolicyPublished | Institution | `publishAdmissionPolicy()` | institutionId, cycleId, policyId, occurredAt |
| 9 | ProgrammeIntroduced | Programme | `introduce()` | programmeId, institutionId, name, awardLevel, occurredAt |
| 10 | ProgrammeAdmissionPolicyPublished | Programme | `publishAdmissionPolicy()` | programmeId, cycleId, policyId, occurredAt |
| 11 | ProgrammeAdmissionSuspended | Programme | `suspendAdmission()` | programmeId, occurredAt |
| 12 | ProgrammeAdmissionResumed | Programme | `resumeAdmission()` | programmeId, occurredAt |
| 13 | ProgrammeDiscontinued | Programme | `discontinue()` | programmeId, occurredAt |
| 14 | ProgrammeAccredited | Programme | `recordAccreditation()` | programmeId, authorityId, status, occurredAt |
| 15 | ScholarshipAnnounced | Scholarship | `announce()` | scholarshipId, providerId, occurredAt |
| 16 | ScholarshipEligibilityPolicyPublished | Scholarship | `publishEligibilityPolicy()` | scholarshipId, policyId, occurredAt |
| 17 | ScholarshipApplicationsOpened | Scholarship | `openApplications()` | scholarshipId, occurredAt |
| 18 | ScholarshipApplicationsClosed | Scholarship | `closeApplications()` | scholarshipId, occurredAt |
| 19 | ScholarshipWithdrawn | Scholarship | `withdraw()` | scholarshipId, occurredAt |
| 20 | ScholarshipExpired | Scholarship | `expire()` | scholarshipId, occurredAt |
| 21 | ScholarshipTargetsUpdated | Scholarship | `targetProgrammes()` | scholarshipId, addedProgrammeIds, removedProgrammeIds, occurredAt |
| 22 | AdmissionCycleAnnounced | Admission Cycle | `announce()` | cycleId, authorityId, period, occurredAt |
| 23 | AdmissionCycleActivated | Admission Cycle | `activate()` | cycleId, occurredAt |
| 24 | AdmissionCyclePhaseAdvanced | Admission Cycle | `advancePhase()` | cycleId, previousPhase, currentPhase, occurredAt |
| 25 | AdmissionCycleClosed | Admission Cycle | `close()` | cycleId, occurredAt |
| 26 | InformationSourceVerified | Information Source | `verify()` | sourceId, occurredAt |
| 27 | InformationSourceMarkedUnreliable | Information Source | `markUnreliable()` | sourceId, occurredAt |
| 28 | InformationSourceDeprecated | Information Source | `deprecate()` | sourceId, occurredAt |
| 29 | QualificationDeprecated | Qualification | `deprecate()` | qualificationId, occurredAt |

**Rejected events:** `InstitutionLocationChanged`, `ProgrammeDescriptionUpdated`, `ScholarshipCoverageUpdated` -- CRUD with no domain significance beyond search index projection. Events for Scholarship Provider and Education Authority -- no direct domain consequences beyond reference integrity (application-layer concern via FK constraints).

Events trigger side effects: search index updates (via UpdateSearchIndex listener), notification dispatches, read model updates, and activity logging.

### 3.6 Domain Actions (20)

Each Action meets the explicit Action Criterion (4 conditions from frozen baseline F4): multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization plus complex validation. Search index updates are NOT sufficient justification (handled by event listeners). Authorization alone is NOT sufficient (handled by Laravel Policies).

| # | Action | Target Entity | Description | Justification |
|---|--------|-------------|-------------|---------------|
| 1 | CreateInstitution | Institution | Create a new educational institution with type, name, location, and provenance | Multi-entry-point (HTTP + Filament + Import); jurisdiction validation + domain + event dispatch |
| 2 | SuspendInstitution | Institution | Suspend an operational institution, cascading to programme status | Significant cascade (programme status cascade via event + notification coordination) |
| 3 | CloseInstitution | Institution | Permanently close an institution, cascading to programmes and scholarships | Significant cascade (programme discontinuation + scholarship flag + search exclusion) |
| 4 | MergeInstitutions | Institution | Merge two institutions into one, reassigning all programmes and transferring accreditation | Multi-step cross-aggregate orchestration via InstitutionMerger; most complex operation |
| 5 | PublishAdmissionPolicy | ProgrammeInstance (via ProgrammeResource) or Institution | Publish admission requirements for a specific programme instance within an admission cycle. Scoped to programmeInstanceId parameter on ProgrammeResource. | Multi-step: cycle validation + rule validation + domain operation + event |
| 6 | RecordAccreditation | Programme or Institution | Record an accreditation event with jurisdiction validation | Authorization + jurisdiction guard + trust signal cascade trigger |
| 7 | CreateProgramme | Programme | Create a new programme within an institution | Multi-entry-point (HTTP + Filament + Import); institution validation + award level guard |
| 8 | DiscontinueProgramme | Programme | Permanently discontinue a programme, flagging affected scholarships | Cascade coordination (scholarship flag cascade) |
| 9 | AnnounceScholarship | Scholarship | Announce a new scholarship with provider validation | Authorization + provider validation |
| 10 | OpenScholarshipApplications | Scholarship | Open the application window, verifying eligibility policy exists | Authorization + policy check + notification trigger |
| 11 | ExpireScholarship | Scholarship | Expire a single scholarship whose deadline has passed (time-based) | Scheduler trigger; batch coordination |
| 12 | TargetScholarshipProgrammes | Scholarship | Set or update which programmes/institutions the scholarship targets | Authorization + programme existence validation + transactional relationship coordination |
| 13 | AnnounceAdmissionCycle | Admission Cycle | Announce a new admission cycle with authority validation | Authorization + authority validation (non-trivial jurisdiction check) |
| 14 | ActivateAdmissionCycle | Admission Cycle | Activate an announced cycle when its start date arrives | Multi-entry-point (HTTP + Filament + Scheduler); read model update trigger |
| 15 | AdvanceAdmissionCyclePhase | Admission Cycle | Advance the cycle to its next sequential phase | Authorization + notification dispatch |
| 16 | RegisterInformationSource | Information Source | Register a new information source with verification metadata | Multi-entry-point (Filament + Import); reference validation |
| 17 | VerifyInformationSource | Information Source | Mark a source as verified after reliability assessment | Authorization + trust cascade trigger |
| 18 | MarkSourceUnreliable | Information Source | Mark a verified source as unreliable | Authorization + trust cascade coordination |
| 19 | ImportInstitutionData | Multiple | Import institution data from external sources (CSV/JSON/API) | Significant orchestration: parsing + validation + deduplication + batch + event dispatch |
| 20 | ExpireScholarships | Scholarship (batch) | Batch-expire all overdue scholarships (scheduled) | Time-based batch operation from scheduler |

**Removed Actions (with rationale):** UpdateInstitution, PublishInstitution -- CRUD/publishing does not meet Action Criterion. UpdateProgramme, PublishProgramme -- same. UpdateScholarship, PublishScholarship -- same. UpdateAdmissionPolicy, UpdateEligibilityPolicy -- child entity operations driven by parent Actions. CreateAdmissionPolicy, CreateEligibilityPolicy -- driven by PublishAdmissionPolicy. RejectInformationSource -- no domain operation; application-layer status change. OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults -- replaced by AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase.

Actions are invoked by Filament resources (admin) and Livewire components (public), never containing business logic in Resource hooks or component methods.

---

## 4. Database Schema

The complete database schema encompasses 61 tables organized across 10 layers. The corrected entity count is 13 (5 aggregate roots + 4 child entities + 4 supporting entities including Qualification in the Reference namespace) + 2 infrastructure entities (ExternalIdentifier, FieldProvenance). The corrected VO count is 29 (12 non-enum VOs + 17 enums). The corrected enum count is 17 (3 behavioural + 14 pure, per 03-domain.md Section 6). AdmissionPathway is a Value Object (VO #12), not an enum -- it is stored as a VARCHAR column on the `admission_cycles` table; there is no `admission_pathways` table and no AdmissionPathway enum in the Domain layer.

### 4.1 Table Inventory by Layer (61 tables)

| Layer | Tables | Count |
|---|---|---|
| Domain | institutions, programmes, programme_instances, campuses, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, education_authorities, information_sources, scholarship_providers, disciplines, cut_off_marks, external_identifiers, field_provenance | 16 |
| Reference | qualifications, countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries | 7 |
| Content | articles, guides, guide_sections, educational_resources, exam_preparations | 5 |
| Auth/RBAC | users, roles, permissions, model_has_roles, model_has_permissions, role_has_permissions, organization_members, password_reset_tokens, personal_access_tokens | 9 |
| Engagement | saves, follows, likes, comparison_sets | 4 |
| Community | community_questions, community_answers, community_comments, community_votes, community_reports | 5 |
| Notification | notification_preferences | 1 |
| Settings | platform_settings, institution_settings, user_preferences | 3 |
| SEO | url_redirects | 1 |
| Infrastructure | media, tags, taggables, activities, notifications, jobs, failed_jobs, cache, sessions, pending_revisions | 10 |
| **Total** | | **61** |

### 4.2 Key Schema Decisions

**Qualification in Reference** (R5): `qualifications` table lives in `App\Reference\Models`, FKs from `qualification_equivalencies` point within Reference namespace, eliminating the Reference-to-Domain FK violation.

**OrganizationMember.role is string** (NOT role_id): The org-scoped role is a string concept stored on the pivot (e.g., 'owner', 'admin', 'admissions', 'editor', 'viewer'), NOT a FK to the Spatie `roles` table. Spatie roles are for global platform permissions. Org-scoped roles are for entity-level privileges. These are two separate concepts that must not be conflated.

**user_id indexes on engagement tables**: `saves`, `follows`, `likes` each have standalone `user_id` index for the common "get all items for user X" query pattern.

**Explicit FK on articles.institution_id**: `->constrained()->nullOnDelete()` for data integrity. The performance cost of an FK constraint is negligible; the data integrity benefit is significant.

**Morph index on community_questions.subject**: `$table->morphsIndex('subject')` for polymorphic query performance.

**AdmissionPathway as VO column**: Stored as a string enum on `admission_cycles.admission_pathway`, not as a separate table. This is consistent with the domain model where AdmissionPathway was demoted from entity to VO.

**Public IDs (UUID) on user-facing entities**: `public_id` (UUID, unique) columns on institutions, programmes, programme_instances, campuses, and scholarships. Used strictly for internal routing logic, API endpoints, and preventing ID scraping in JSON payloads — NOT in public-facing URLs. Public URLs use slugs (e.g., /institutions/{institution-slug}, /institutions/{inst-slug}/programmes/{prog-slug}) for SEO. The internal `id` (BIGINT per ADR-19) is never exposed in URLs or API responses — it is used only for internal FK references and joins. `public_id` is generated via `Str::uuid7()` on model creation and is immutable.

**JSONB deconstruction for query performance**: JSONB columns provide structured domain access but cannot be efficiently used for ORDER BY, range queries, or indexed filtering without sequence scans. The following fields are extracted as physical columns alongside their JSONB VO sources:
- `programme_instances.tuition_amount` (DECIMAL(12,2)) and `programme_instances.currency_code` (CHAR(3)) — extracted from the MonetaryAmount VO (`tuition` JSONB). Enables `ORDER BY tuition_amount` using a B-tree index and `WHERE currency_code = 'NGN'` filtering without JSONB traversal.
- `campuses.city` (VARCHAR), `campuses.state` (VARCHAR), `campuses.country` (CHAR(2), ISO 3166-1) — extracted from the Location VO (`location` JSONB). Enables indexed geographic filtering (`WHERE country = 'NG' AND state = 'Lagos'`) and faceted search without JSONB traversal.
All extracted columns are set by Eloquent mutator when their parent VO is assigned and are read-only for query optimization. The JSONB VO is retained for structured access (e.g., MonetaryAmount's indigene/non-indigene tiers, Location's full address structure).

**Generated tsvector column on programmes**: `search_vector` is a PostgreSQL GENERATED ALWAYS STORED column computed as `to_tsvector('english', coalesce(name,'') || ' ' || coalesce(description,''))`. This eliminates the need for application-level tsvector synchronization — the column is always consistent with the row data. A GIN index on `search_vector` provides sub-millisecond full-text search. Similar generated columns exist on `institutions` and `scholarships` for their FTS requirements. Maintained as fallback for admin search and degraded-mode search when Typesense is unavailable.

**pg_trgm GIN indexes for autocomplete fallback**: The `pg_trgm` PostgreSQL extension is enabled and GIN trigram indexes are created on `institutions.name` and `programmes.name` for prefix and fuzzy matching as a fallback autocomplete when Typesense is unavailable. Typesense provides primary autocomplete in V1.

### 4.3 Domain Table Schemas

**institutions**: id, public_id (UUID, unique — URL-safe identifier preventing sequential ID scraping), name, slug, type (InstitutionType), ownership_type (OwnershipType), registration_identifier (VARCHAR), website, founded_year, description, status (InstitutionStatus: Provisional, Operational, Suspended, Closed), is_published (boolean, default false), published_at (timestamp, nullable), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Index: public_id (unique), slug (unique), type, ownership_type, status, is_published. pg_trgm GIN index on name for prefix/fuzzy autocomplete. Location is now on Campus (not Institution directly); Institution location is derived from its primary Campus. Publication is orthogonal to domain lifecycle — `is_published` controls visibility on the public site, `status` is the domain lifecycle. `published_at` records the first publication date and is not rewritten on subsequent publication cycles.

**programmes**: id, public_id (UUID, unique — URL-safe identifier preventing sequential ID scraping), institution_id FK, name, slug, award_level (AwardLevel), discipline_id (BIGINT FK nullable, references disciplines per ADR-19), admission_mode (AdmissionMode), duration (JSON -- Duration VO, default/template duration), description, career_prospects, status (ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued -- default Prospective), is_published (boolean, default false), published_at (timestamp, nullable), search_vector (GENERATED ALWAYS AS (to_tsvector('english', coalesce(name,'') || ' ' || coalesce(description,''))) STORED — Generated tsvector column for PostgreSQL FTS), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Index: public_id (unique), institution_id, slug (unique within institution), award_level, discipline_id, status, is_published. GIN index on search_vector for sub-millisecond full-text search. pg_trgm GIN index on name for prefix/fuzzy autocomplete. delivery_mode and tuition REMOVED from programmes (moved to programme_instances). Publication is orthogonal to domain lifecycle. Programme.status defaults to Prospective (the abstract template); concrete admission status lives on ProgrammeInstance.

**programme_instances**: id, public_id (UUID, unique — URL-safe identifier preventing sequential ID scraping), programme_id FK (references programmes), campus_id FK (references campuses), delivery_mode (DeliveryMode: OnCampus, Online, Hybrid), academic_year (VARCHAR, e.g., "2025/2026"), capacity (INTEGER nullable), status (ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued -- concrete admission status lives here), tuition (JSON -- MonetaryAmount VO, nullable, retained for structured access to indigene/non-indigene tiers), tuition_amount (DECIMAL(12,2) nullable — extracted from MonetaryAmount VO for ORDER BY without JSONB sequence scan), currency_code (CHAR(3) nullable, ISO 4217 — extracted from MonetaryAmount VO for index-sorted currency filtering), duration (JSON -- Duration VO, nullable -- may override Programme default), is_published (BOOLEAN, default false), published_at (TIMESTAMP nullable), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Unique: (programme_id, campus_id, delivery_mode, academic_year) -- INV-PI1. Index: public_id (unique), programme_id, campus_id, delivery_mode, academic_year, status, is_published, tuition_amount, currency_code. tuition_amount and currency_code are denormalized extracts from the MonetaryAmount VO; they are set by Eloquent mutator when tuition is assigned and are read-only for query optimization. Each ProgrammeInstance represents one concrete offering of a Programme at a Campus in an Academic Year with a DeliveryMode.

**campuses**: id, public_id (UUID, unique — URL-safe identifier preventing sequential ID scraping), institution_id FK (references institutions), name, slug, city (VARCHAR nullable — extracted from Location VO for indexed geographic filtering), state (VARCHAR nullable — extracted from Location VO for indexed geographic filtering), country (CHAR(2) nullable, ISO 3166-1 — extracted from Location VO for indexed geographic filtering), location (JSON -- Location VO: country, region, city; nullable for online-only — retained for structured access and future geo queries), is_primary (BOOLEAN, default false), established_year (INTEGER nullable), status (CampusStatus: Active, Inactive, Planned), created_at, updated_at. Index: public_id (unique), institution_id, slug (unique within institution), is_primary, status, city, state, country. city, state, and country are denormalized extracts from the Location VO; they are set by Eloquent mutator when location is assigned and are read-only for query optimization. Invariant: exactly one Campus per Institution must be is_primary=true (INV-CAMP1). INV-CAMP1 enforcement: Partial unique index `CREATE UNIQUE INDEX campuses_one_primary_per_institution ON campuses (institution_id) WHERE is_primary = true` ensures exactly one primary campus per institution. Application layer (Filament) prevents the last primary from being unset. Location was moved from institutions to campuses to support multi-campus institutions.

**scholarships**: id, public_id (UUID, unique — URL-safe identifier preventing sequential ID scraping), provider_type, provider_id (morph), name, slug, value (JSON -- MonetaryAmount VO), coverage_type (CoverageType), eligibility_criteria (JSON -- EligibilityRule VO), application_start, application_deadline, description, status (ScholarshipStatus: Draft, Announced, Open, Closed, Expired, Withdrawn), is_published (boolean, default false), published_at (timestamp, nullable), created_at, updated_at. Index: public_id (unique), provider morph, slug, coverage_type, status, is_published, deadline. Publication is orthogonal to domain lifecycle. Scholarship public discovery pages are Phase 2; the publication model is consistent across all user-facing entities.

**admission_cycles**: id, authority_id (BIGINT FK, references education_authorities), name, admission_pathway (VARCHAR -- AdmissionPathway VO), phase_sequence (JSONB -- PhaseSequence VO per ADR-20), current_phase (VARCHAR -- stable phase ID per ADR-20), academic_year, starts_at, ends_at, status (VARCHAR -- Upcoming, Active, Closed, Archived per 03-domain.md state machine), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Index: authority_id, status.

**admission_policies**: id, governable_type, governable_id (morph -- ProgrammeInstance or Institution), admission_cycle_id FK, title, description, policy_rules (JSON -- AdmissionRule VO), qualification_requirements, valid_from, valid_until (JSON -- ValidityPeriod VO), status (PolicyStatus), created_at, updated_at. Index: governable morph, admission_cycle_id.

**eligibility_policies**: id, scholarship_id FK, title, criteria (JSON -- EligibilityRule VO), minimum_score, valid_from, valid_until (JSON -- ValidityPeriod VO), status (PolicyStatus), created_at, updated_at. Index: scholarship_id.

**accreditation_records**: id, accreditable_type, accreditable_id (morph -- Programme or Institution), authority_id FK, accreditation_type, status (AccreditationStatus: Full, Interim, Probationary, Revoked, Expired), valid_from, valid_until (JSON -- ValidityPeriod VO), certificate_url, created_at, updated_at. Index: accreditable morph, authority_id. Immutable after creation — each record is a historical fact.

**information_sources**: id, authority_id (BIGINT FK nullable, references education_authorities per ND-5/ADR-22), source_type, url, contact_name, contact_email, reliability (SourceReliability: Registered, Verified, Unreliable, Deprecated), category (InformationCategory: Official, Unofficial, Historical, Scraped), priority (INTEGER, default 0 — source authority weighting for conflict resolution; higher priority wins; equal priorities escalate to human review), verified_at, verified_by, notes, provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Index: authority_id, reliability, priority. No institution_id FK (ND-5/ADR-22).

**scholarship_providers**: id, name, slug, type (ProviderType), description, website, created_at, updated_at. Index: slug, type.

**education_authorities**: id, name, slug, type (AuthorityType), jurisdiction (JSON -- AuthorityJurisdiction VO), description, website, created_at, updated_at. Index: slug, type.

**disciplines**: id (BIGINT PK per ADR-19), name, slug (unique), description (nullable), sort_order, created_at, updated_at. Index: slug. Managed reference table for programme classification — not a domain entity. Flat for MVP (no parent_id). Values seeded during implementation. See 03-domain.md Section 12.

**cut_off_marks**: id (BIGINT PK per ADR-19), programme_instance_id (BIGINT FK, references programme_instances, ON DELETE CASCADE), admission_cycle_id (BIGINT FK, references admission_cycles, ON DELETE CASCADE), pathway (VARCHAR(50)), value (INTEGER), source_id (BIGINT FK nullable, references information_sources, ON DELETE SET NULL), provenance (JSONB, entity-level provenance per ND-4/ADR-23), created_at, updated_at. Unique: (programme_instance_id, admission_cycle_id, pathway). Index: programme_instance_id, admission_cycle_id. One row per programme instance per cycle per admission pathway. Cross-cycle history: multiple rows. Intra-cycle corrections: UPDATE the row; activity log captures the change. See 03-domain.md Section 13.

### 4.4 OrganizationMember Pivot Schema

```
organization_members
    id                  bigint PK
    user_id             bigint FK -> users (cascade delete)
    organization_type   string (morph: 'institution', 'scholarship_provider', 'education_authority')
    organization_id     bigint (morph ID)
    role                string (e.g., 'owner', 'admin', 'admissions', 'editor', 'viewer')
    created_at / updated_at

    Unique: (organization_type, organization_id, user_id, role)
    Index: morphsIndex('organization')
```

The `role` column is a **string**, not `role_id` FK. This allows institution roles to evolve without code changes -- new roles can be added, existing role capabilities adjusted, and the role hierarchy reconfigured without migrations.

### 4.5 Pending Revisions Schema

**Purpose:** The Organization Portal saves edits as PendingRevisions. Admins approve via Filament. Upon approval, data is written to canonical tables and spatie/laravel-activitylog records the audit trail.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| id | BIGINT PK | No | Auto-increment primary key |
| entity_type | VARCHAR(255) | No | Allowed values: 'programme_instance', 'programme', 'campus' (constrained in V1) |
| entity_id | BIGINT UNSIGNED | No | FK to the entity's id column |
| submitted_by | BIGINT UNSIGNED | No | FK to users.id (Organization Portal user) |
| proposed_payload | JSONB | No | JSON object containing only the fields being changed, keyed by allowed field names per entity_type |
| status | pending_revision_status ENUM | No | Values: Pending, Approved, Rejected. Default: Pending |
| reviewed_by | BIGINT UNSIGNED | Yes | FK to users.id (Admin who reviewed). Nullable until review |
| review_notes | TEXT | Yes | Admin's notes on the review decision |
| created_at | TIMESTAMP | No | Submission timestamp |
| updated_at | TIMESTAMP | No | Last update timestamp |

**Allowed entity types and fields (V1):**
| Entity Type | Allowed Fields | Authorization |
|-------------|---------------|--------------|
| programme_instance | tuition, duration, admission_policy_id, is_published | Organization member for owning institution |
| programme | name, description, career_prospects | Organization member for owning institution |
| campus | name, location, is_primary | Organization member for owning institution (with exactly-one invariant check) |

**Constraints:**
- CHECK constraint: entity_type IN ('programme_instance', 'programme', 'campus')
- FK: entity_id references the appropriate table based on entity_type (polymorphic)
- FK: submitted_by references users.id ON DELETE CASCADE
- FK: reviewed_by references users.id ON DELETE SET NULL
- Index: (entity_type, entity_id, status) for efficient pending review queries
- Index: (status, created_at) for admin review queue

**Workflow:**
1. Organization Portal user edits a field → system creates PendingRevision with status=Pending
2. PendingRevision appears in Filament admin review queue
3. Admin reviews → sets status=Approved/Rejected, reviewed_by, review_notes
4. If Approved: proposed_payload fields are written to the canonical entity within a DB transaction; activitylog records the change with causer=reviewed_by, properties={original, proposed}
5. If Rejected: no canonical change; activitylog records the rejection

### 4.6 Content Table Schemas

**articles**: id, title, slug, body, excerpt, category, institution_id FK (nullable, constrained, nullOnDelete), source_url, is_breaking, published_at, status, seo_title, seo_description, canonical_url, noindex, og_title, og_description, og_image, created_at, updated_at. Traits: HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags.

**guides**: id, title, slug, body, excerpt, category, reading_time, published_at, status, (SEO columns as above), created_at, updated_at. Traits: HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections.

**guide_sections**: id, guide_id FK, title, body, sort_order, created_at, updated_at.

**educational_resources**: id, title, slug, body, excerpt, resource_type (ResourceType), discipline, academic_level, download_count, published_at, status, (SEO columns), created_at, updated_at.

**exam_preparations**: id, title, slug, body, excerpt, prep_type (PrepType), exam_body, year, subject, download_count, published_at, status, (SEO columns), created_at, updated_at.

### 4.6a Programme/ProgrammeInstance Publication & Search Aggregation

**Programme/ProgrammeInstance publication interaction:**
A Programme is visible in search if `programmes.is_published = TRUE` AND at least one related `ProgrammeInstance.is_published = TRUE`. This ensures that a published programme with no published instances is not surfaced to users — the abstract template is not independently searchable.

**Search result card aggregation:**
Search results return one card per Programme (not per ProgrammeInstance). The search query applies user facet filters against the `instances[]` nested object array (§8.3.1) so that only ProgrammeInstances matching ALL filter conditions are considered. This means a filter for Campus=Abuja AND DeliveryMode=Online will only match Programme documents where a SINGLE instance element satisfies both conditions — it will NOT match a programme that has Abuja/OnCampus and Remote/Online as separate instances.

If multiple instances of a Programme match the user's combined filters (e.g., both Abuja/OnCampus and Abuja/Online are published at the Abuja campus), the card surfaces an aggregation derived from the matching instance subset:
- **Delivery modes:** "Available Online & On-Campus" (concatenation of DeliveryMode values from matching instances)
- **Tuition:** "From ₦X" (minimum tuition_amount across matching instances)
- **Campus count:** Number of distinct campuses across matching instances (shown as badge if > 1)
- **Admission status:** "Open" if any matching instance has an active AdmissionPolicy for the current cycle; "Closed" otherwise

The programme detail page lists all published instances as separate tabs/sections so users can compare offerings.

### 4.7 Migration Dependencies

Migrations must execute in dependency order: (1) users + auth tables, (2) roles + permissions (Spatie), (3) reference data (countries, currencies, qualifications, disciplines), (4) domain tables (institutions -> campuses -> programmes -> programme_instances -> scholarships -> admission_cycles -> admission_policies -> eligibility_policies -> accreditation_records -> education_authorities -> information_sources -> scholarship_providers -> cut_off_marks -> external_identifiers -> field_provenance), (5) pending_revisions, (6) organization_members (depends on users + domain), (7) content tables (articles, guides, educational_resources, exam_preparations), (8) engagement tables (saves, follows, likes, comparison_sets), (9) community tables (community_questions -> community_answers -> community_comments -> community_votes -> community_reports), (10) notification_preferences, (11) settings tables, (12) SEO/infrastructure tables.

### 4.8 ON DELETE Behaviors

All foreign keys have explicit ON DELETE behaviors. There are no implicit (database-default) behaviors.

**ON DELETE RESTRICT** (business rule — cannot delete referenced entity):
- information_sources.authority_id → education_authorities (nullable FK, but when set, must be valid)
- external_identifiers.authority_id → education_authorities
- external_identifiers.source_id → information_sources (when not NULL)
- field_provenance.source_id → information_sources (when not NULL)
- external_identifiers.replaced_by_id → external_identifiers (when not NULL)
- field_provenance.superseded_by_id → field_provenance (when not NULL)
- programmes.institution_id → institutions
- programme_instances.programme_id → programmes
- programme_instances.campus_id → campuses
- campuses.institution_id → institutions
- admission_cycles.authority_id → education_authorities
- accreditation_records.authority_id → education_authorities

**ON DELETE CASCADE** (child entity lifecycle tied to parent):
- cut_off_marks.programme_instance_id → programme_instances
- cut_off_marks.admission_cycle_id → admission_cycles
- admission_policies.* → parent aggregate (Institution or Programme)
- eligibility_policies.* → parent aggregate (Scholarship)
- programme_instances.* → parent aggregate (Programme)
- organization_members → parent organization (cascade delete when organization is deleted)

**ON DELETE SET NULL** (attribution can be nullified without losing the record):
- cut_off_marks.source_id → information_sources

**Semantic distinction for source_id ON DELETE behavior:** The three tables that reference `information_sources` via `source_id` have intentionally different ON DELETE behaviors reflecting the strength of the source-record relationship:

| Table | source_id ON DELETE | Relationship to Source | Rationale |
|-------|---------------------|----------------------|-----------|
| `field_provenance` | RESTRICT | Source IS the reason for the record | Provenance records exist to attribute a value to a source. Deleting the source destroys the provenance chain's integrity and audit trail. |
| `external_identifiers` | RESTRICT | Source validates the identifier | An external identifier was observed from a specific source. Losing the source link prevents verification of the identifier's origin. |
| `cut_off_marks` | SET NULL | Source is attribution metadata | cut_off_marks is a query model (not a domain entity). The source_id is attribution ("we got this cut-off from JAMB"), not an audit chain. If the source is deprecated, the cut-off value (the integer) remains valid and useful. SET NULL preserves the data while acknowledging the source is gone. |

### 4.9 Additional Index Specifications

**external_identifiers indexes:**
- (entity_type, entity_id) — polymorphic lookup: find all external identifiers for a given entity
- (source_id) — reverse lookup: find all identifiers attributed to a given source
- (authority_id, identifier_type, identifier) WHERE status = 'active' — INV-EI1 partial unique index (global identifier uniqueness per authority)

**field_provenance indexes:**
- (entity_type, entity_id, field_name) — find all provenance records for a specific field on an entity
- (source_id) — reverse lookup: find all provenance records from a given source
- (superseded_at) — efficient query for active observations (WHERE superseded_at IS NULL)
- (verification_status) — filter by verification status for review workflows

### 4.10 CHECK Constraints

**external_identifiers:**
- CHECK (valid_until IS NULL OR valid_until > valid_from) — temporal validity end must be after start
- CHECK (status IN ('active', 'retired', 'superseded')) — status enum enforcement

**field_provenance:**
- CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 100)) — confidence is 0-100 or null
- CHECK (verification_status IN ('unverified', 'verified', 'disputed', 'superseded', 'stale')) — verification_status enum enforcement
- CHECK (superseded_at IS NULL OR superseded_at >= observed_at) — cannot be superseded before observation

---

## 5. RBAC Implementation

StudyNexus uses a two-layer authorization model: `spatie/laravel-permission` for global platform roles and permissions, and the `OrganizationMember` pivot for institution/organization-scoped membership. This is BookStack-inspired: the same user can have different privileges per organization, and roles are strings that can evolve without code changes. The total role count is 11: 4 global platform roles + 5 institution-scoped roles + 2 user roles.

### 5.1 Global Platform Roles (Spatie Permission)

| Role | Spatie Role Name | Key Permissions |
|---|---|---|
| Platform Admin | `platform-admin` | All permissions |
| Platform Moderator | `platform-moderator` | Verify sources, moderate content, review community |
| Content Admin | `content-admin` | CRUD all domain entities + content |
| Content Editor | `content-editor` | Create/edit/publish content |

The role name is `platform-admin` (not `super-admin`). This naming convention is deliberate and consistent with the BookStack-inspired model where the platform administrator has global reach but the naming emphasizes platform scope rather than implying unlimited authority.

### 5.2 Institution-Scoped Roles (via OrganizationMember)

| Role | Key Capabilities | Notes |
|---|---|---|
| `institution-owner` | Full control + manage members + transfer ownership | At least one owner must exist per institution |
| `institution-admin` | Manage institution data, programmes, admissions, scholarships, publish articles | Cannot manage members or transfer ownership |
| `institution-admissions` | Manage admission policies, cycles, deadlines | Read-only on other institution data |
| `institution-editor` | Edit descriptions, media, programme details | Cannot change status, manage admissions, or manage members |
| `institution-viewer` | View internal data and reports | Read-only access |

These roles are initial defaults, not a rigid hierarchy. The architecture allows institution roles and permissions to evolve. New roles can be added, existing role capabilities adjusted, and the role hierarchy reconfigured without code changes -- the `OrganizationMember.role` is a string, not an enum, specifically to allow this flexibility.

### 5.3 User Roles

| Role | Key Capabilities |
|---|---|
| `registered-user` | Save, follow, like, compare, community participation |
| `guest` | Browse only |

### 5.4 OrganizationMember Pivot Implementation

The pivot uses a string `role` column (NOT `role_id` FK to Spatie roles). Spatie roles handle global platform permissions. Org-scoped roles handle entity-level privileges. These are two separate concepts. The OrganizationMember morphable pivot supports `institution`, `scholarship_provider`, and `education_authority` as organization types, allowing the same membership model to serve multiple entity types. The key invariant is that the same user can be `owner` of Institution A and `viewer` of Institution B -- roles are scoped to the organization, not global. There is no `owner_id` or `admin_user_id` on the Institution aggregate; ownership is membership, not a domain property.

### 5.5 Policy Pattern

```php
class InstitutionPolicy
{
    public function update(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->hasRole('content-admin')
            || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
    }
}
```

Every domain model Policy checks both global permission (Spatie) and scoped membership (OrganizationMember). This pattern is consistent across all domain entities.

### 5.6 Administrative UI

Filament resources provide the administrative UI for managing: global roles and permissions (via `bezhansalleh/filament-shield` -- note the correct spelling with double 'l' in 'salleh'), organization memberships (custom Filament resource), and self-protection against administrators accidentally removing their own critical access. The UI must prevent the last `platform-admin` from demoting themselves and the last `institution-owner` from removing their ownership.

---

## 6. Admin Panel Implementation

The admin panel is built with Filament v5 and is exclusively admin-facing. Filament is never exposed to public users (ADR-12). All admin operations -- CRUD for domain entities, content management, reference data, user management, RBAC, settings, and reporting -- are handled through Filament resources, pages, and widgets. Business logic is never placed in Filament Resource hooks; Resources invoke domain Actions for write operations and Query classes for read operations.

### 6.1 Filament Panel Setup

The admin panel is configured as a separate Filament panel accessible at `/admin` (or a configurable path). Authentication uses the same Laravel guard as the public site but requires a platform or institution-scoped role for access. The panel uses the default Filament v5 theme with Tailwind CSS customization for StudyNexus branding. Navigation is organized by domain concern: Institutions, Programmes, Scholarships, Admissions, Content, Community, Reference Data, Settings, and Users.

### 6.2 Resource Definitions

**Domain Resources**: InstitutionResource, ProgrammeResource, ScholarshipResource, AdmissionCycleResource, AdmissionPolicyResource, EligibilityPolicyResource, AccreditationRecordResource, InformationSourceResource, ScholarshipProviderResource, EducationAuthorityResource. Each resource defines form schemas, table columns, filters, actions, and authorization gates. Form schemas use Filament native RichEditor for rich text fields (not the deprecated tiptap-editor), Select fields for enum values, and MediaLibrary picker for file uploads.

**Content Resources**: ArticleResource, GuideResource, EducationalResourceResource, ExamPreparationResource. These resources leverage the shared content traits (HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags) to provide consistent publishing workflows, SEO metadata editing, media management, and tag assignment.

**Reference Resources**: QualificationResource, CountryResource, CurrencyResource, QualificationEquivalencyResource, TuitionFeeRangeResource, CostOfLivingIndexResource, VisaRequirementSummaryResource. Simple CRUD resources with no domain Actions -- managed directly through Filament.

**Engagement Resources**: OrganizationMemberResource for managing institution memberships and roles. SaveResource, FollowResource, LikeResource for administrative oversight (read-only with filters).

**Community Resources**: QuestionResource, AnswerResource, CommentResource, VoteResource, ReportResource. Report resource provides moderation workflow (pending -> resolved -> dismissed).

### 6.3 Navigation Structure

```
Dashboard
Institutions
  - All Institutions
  - Accreditation Records
  - Information Sources
Programmes
  - All Programmes
  - Admission Cycles
  - Admission Policies
  - Eligibility Policies
Scholarships
  - All Scholarships
  - Scholarship Providers
Content
  - Articles
  - Guides
  - Educational Resources
  - Exam Preparation
Community (feature-flagged)
  - Questions
  - Answers
  - Reports (moderation)
Reference Data
  - Qualifications
  - Countries
  - Currencies
  - Qualification Equivalencies
  - Tuition Fee Ranges
  - Cost of Living Indices
  - Visa Requirement Summaries
Settings
  - Platform Settings
  - Institution Settings
Users & Roles
  - Users
  - Roles & Permissions (via filament-shield)
  - Organization Members
```

### 6.4 Authorization Integration

Every Filament resource checks authorization through Laravel Policies, which in turn check both Spatie global permissions and OrganizationMember scoped membership. `bezhansalleh/filament-shield` provides the bridge between Filament and Spatie Permission, generating permission-based access gates for each resource. Custom authorization logic for institution-scoped operations (e.g., "can this user edit this specific institution?") is handled through Policy methods that query the OrganizationMember pivot. Activity logging in the admin panel is provided by `pxlrbt/filament-activity-log` v3.1.1, which integrates with `spatie/laravel-activitylog` to display an activity timeline on each resource view page.

---

## 7. Frontend Implementation

The public-facing application uses the TALL stack: Tailwind CSS + Alpine.js + Livewire v4 + Laravel. This is non-negotiable. There is no React, no Next.js, no Vue, no Inertia, no SPA, and no client-side routing. The server owns the page; JavaScript enhances it. Filament is admin-facing only and never appears in the public site.

### 7.1 TALL Stack Roles

| Technology | Role | Boundary |
|---|---|---|
| Laravel | Application framework, routing, middleware, DI container | Backend only |
| Blade | Server-rendered templates for SEO-critical content and layouts | SEO-critical pages, static content, page shells |
| Livewire v4 | Server-driven reactive UI for interactive pages and forms | Filter pages, dashboards, forms, lazy-loaded sections |
| Flux | UI component library providing consistent design system for Livewire | Form inputs, buttons, cards, modals, tables |
| Alpine.js | Lightweight client-side interactivity for presentation-only behaviour | Share buttons, dropdowns, accordions, tooltips, mobile menu |
| Tailwind CSS | Utility-first CSS framework | All styling |

### 7.2 Livewire Usage Boundary

| Context | Use Livewire? | Use Blade? | Use Alpine.js? | Rationale |
|---|---|---|---|---|
| SEO-critical detail pages (institution, programme, scholarship, article, guide) | No (except lazy-loaded sections) | Yes (server-rendered) | Yes (UI toggles) | SEO requires fully rendered HTML on first load |
| Search/filter/listing pages | Yes (wire:navigate for SPA-like transitions) | Yes (initial server render) | No | Livewire handles filter state, pagination, URL sync |
| Lazy-loaded sections (related content, community Q&A) | Yes (lazy component) | No | No | Loaded on demand, not SEO-critical |
| Authenticated dashboards | Yes | Yes (layout) | Yes (minor UI) | SEO irrelevant; interactivity primary |
| Forms (save, follow, report, ask question) | Yes | No | No | Livewire handles validation, submission, state |
| Static content (about, privacy, terms) | No | Yes | No | No interactivity needed |
| Share buttons, UI toggles | No | No | Yes | Pure client-side, no server round-trip |

Rule of thumb: Blade for SEO-critical first-load content. Livewire for interactivity. Alpine.js for presentation-only client-side behaviour. Never use Livewire where Blade suffices.

### 7.3 Public Site Structure

The public site is organized around canonical entity detail pages (server-rendered Blade), interactive listing/filter pages (Livewire + Scout search via Typesense (V1)), and feature-flagged modules (Community, Study Abroad). The homepage is a Blade template with Livewire lazy-loaded sections for personalized content (if authenticated) and search-powered discovery. All SEO-critical pages render complete HTML on first load with structured data, meta tags, and Open Graph tags via the HasSeoMeta trait.

### 7.4 Key Livewire Components

- **ProgrammeSearch** -- Filter/search component for `/programmes` using Scout (Typesense V1); handles discipline, award_level, country, institution type, delivery_mode, campus facets with wire:navigate for SPA-like transitions
- **InstitutionSearch** -- Filter/search for `/institutions` listing
- **ScholarshipSearch** -- Filter/search for `/scholarships` listing
- **SaveButton** -- Toggle save on entities (morphToMany); Livewire form component
- **FollowButton** -- Toggle follow on entities; Livewire form component
- **CompareWidget** -- Add/remove items from comparison set; session for anonymous, DB for authenticated
- **CommunityQuestionForm** -- Ask a question with validation; Livewire form component
- **CommunityAnswerForm** -- Submit an answer; Livewire form component
- **NotificationPreferences** -- Per-category, per-channel toggle settings; Livewire form component

### 7.5 Anti-Patterns

- Making every page a Livewire component (degrades SEO, adds unnecessary server round-trips)
- Using Filament for public-facing UI
- Introducing React, Next.js, Vue, or Inertia anywhere in the codebase
- Client-side routing (the server owns the URL)
- Client-rendered SEO pages (search engines must see fully rendered HTML)

### 7.6 UI Theme & Design System

StudyNexus uses an **OKLCH color space, CSS custom property-driven theming layer** for the TALL stack and Filament v5 admin panel. All colors are defined in OKLCH for perceptual uniformity. Brand colors can be switched instantly by changing `:root` / `.dark` CSS variables — no Blade component, Livewire component, or Filament resource requires modification. Dark mode is supported from V1 via Tailwind `darkMode: 'class'`.

**Color space — OKLCH (mandatory):** All brand and semantic colors MUST be defined in OKLCH, not HEX or HSL. OKLCH provides perceptual uniformity — fixed lightness steps produce equally noticeable brightness changes across all hues. HEX and HSL are prohibited because they produce inconsistent perceived lightness across hues.

**Color hierarchy — Sky/Cyan/Teal/Emerald palette:**
- **Primary — Sky/Cyan (hue 230):** Primary actions, active states, CTAs, links. Anchor: `oklch(0.55 0.15 230)`.
- **Secondary/Accent — Teal (hue 170):** Highlights, secondary links, badges. Anchor: `oklch(0.52 0.12 170)`.
- **Accent — Emerald (hue 160):** Achievement indicators, callout borders. Anchor: `oklch(0.62 0.18 160)`.
- **Semantic:** Danger `oklch(0.55 0.22 25)`, Warning `oklch(0.75 0.15 85)`, Success `oklch(0.62 0.18 155)`.
- **Discarded:** No Navy, no Gold, no Nigeria Green — rejected per "Limit your choices" (Refactoring UI) and poor HSL perceptual uniformity.

**Tailwind OKLCH semantic palette mapping:**
```javascript
// tailwind.config.js
export default {
  theme: {
    extend: {
      colors: {
        primary:   'oklch(var(--color-primary) / <alpha-value>)',
        secondary: 'oklch(var(--color-secondary) / <alpha-value>)',
        accent:    'oklch(var(--color-accent) / <alpha-value>)',
        success:   'oklch(var(--color-success) / <alpha-value>)',
        warning:   'oklch(var(--color-warning) / <alpha-value>)',
        danger:    'oklch(var(--color-danger) / <alpha-value>)',
      },
    },
  },
  darkMode: 'class',  // .dark class on <html> toggles dark palette
}
```

**CSS root OKLCH brand tokens** (defined in `resources/css/app.css`):
```css
:root {
  /* Primary — Sky/Cyan (hue 230) */
  --color-primary-50:  0.97 0.02 230;
  --color-primary-100: 0.93 0.04 230;
  --color-primary-200: 0.85 0.07 230;
  --color-primary-300: 0.75 0.10 230;
  --color-primary-400: 0.65 0.13 230;
  --color-primary-500: 0.60 0.15 230;
  --color-primary-600: 0.55 0.15 230;   /* anchor — Sky Blue */
  --color-primary-700: 0.48 0.14 230;
  --color-primary-800: 0.40 0.12 230;
  --color-primary-900: 0.33 0.10 230;
  --color-primary-950: 0.25 0.08 230;

  /* Secondary/Accent — Teal (hue 170) */
  --color-secondary-50:  0.97 0.02 170;
  --color-secondary-100: 0.93 0.04 170;
  --color-secondary-200: 0.85 0.07 170;
  --color-secondary-300: 0.75 0.09 170;
  --color-secondary-400: 0.65 0.11 170;
  --color-secondary-500: 0.58 0.12 170;
  --color-secondary-600: 0.52 0.12 170;   /* anchor — Teal */
  --color-secondary-700: 0.45 0.11 170;
  --color-secondary-800: 0.38 0.09 170;
  --color-secondary-900: 0.31 0.07 170;
  --color-secondary-950: 0.24 0.05 170;

  /* Accent — Emerald (hue 160) */
  --color-accent-600: 0.62 0.18 160;

  /* Semantic */
  --color-danger-600:  0.55 0.22 25;
  --color-warning-600: 0.75 0.15 85;
  --color-success-600: 0.62 0.18 155;
}

.dark {
  /* Primary — Sky/Cyan: lightened for dark backgrounds */
  --color-primary-50:  0.25 0.08 230;
  --color-primary-100: 0.33 0.10 230;
  --color-primary-200: 0.40 0.12 230;
  --color-primary-300: 0.48 0.14 230;
  --color-primary-400: 0.55 0.15 230;
  --color-primary-500: 0.60 0.15 230;
  --color-primary-600: 0.65 0.13 230;   /* dark mode anchor */
  --color-primary-700: 0.75 0.10 230;
  --color-primary-800: 0.85 0.07 230;
  --color-primary-900: 0.93 0.04 230;
  --color-primary-950: 0.97 0.02 230;

  /* Secondary — Teal: lightened for dark backgrounds */
  --color-secondary-50:  0.24 0.05 170;
  --color-secondary-100: 0.31 0.07 170;
  --color-secondary-200: 0.38 0.09 170;
  --color-secondary-300: 0.45 0.11 170;
  --color-secondary-400: 0.52 0.12 170;
  --color-secondary-500: 0.58 0.12 170;
  --color-secondary-600: 0.65 0.11 170;   /* dark mode anchor */
  --color-secondary-700: 0.75 0.09 170;
  --color-secondary-800: 0.85 0.07 170;
  --color-secondary-900: 0.93 0.04 170;
  --color-secondary-950: 0.97 0.02 170;

  --color-accent-600: 0.70 0.15 160;
  --color-danger-600:  0.65 0.20 25;
  --color-warning-600: 0.80 0.13 85;
  --color-success-600: 0.70 0.15 155;
}
```

**Dark mode:** Toggled via `.dark` class on `<html>` (Alpine.js: `x-data="{ dark: localStorage.getItem('theme') === 'dark' }" x-bind:class="{ dark }"`). System preference respected via `prefers-color-scheme` media query on first visit. Both `:root` and `.dark` variable sets are imported by the Filament admin CSS.

**Filament v5 alignment:** The Filament admin panel's theme CSS (`resources/css/filament/admin.css`) imports the shared `:root` and `.dark` variables so both public site and admin panel share a unified brand identity and dark mode. The panel is configured via `->viteTheme('resources/css/filament/admin.css')`.

**Refactoring UI — mandatory rules:**
1. **Emphasize by de-emphasizing:** Use font weight + soft grey `oklch(0.55 0 0)` for secondary text. Never grey text on colored backgrounds — use a hand-picked lower-contrast OKLCH color from the background hue (e.g., `text-primary-200` on `bg-primary-600`).
2. **Limit your choices:** Constrained spacing scale (4, 8, 12, 16, 24, 32, 48, 64px), sizing scale (24, 32, 40, 48, 64px), type scale (12–48px on major second ratio), border radius (4, 8, 12, 16px, full), font weights (400, 500, 600, 700). Arbitrary Tailwind values (`mt-[13px]`) are forbidden.
3. **Elevation via box shadows:** 5-level shadow system (0–4) using `oklch(0 0 0 / alpha)` not HEX `#000`. Dark mode: shadow opacity reduced ~50%.
4. **Fewer borders:** Use background contrast + shadows for separation. Borders only where unavoidable (1px, `border-grey-200` light / `border-grey-700` dark).
5. **Consistent component language:** Primary = `bg-primary-600 text-white`, Secondary = `bg-secondary-600 text-white`, Destructive = `bg-danger-600 text-white`, Ghost = `text-primary-600 hover:bg-primary-50`. No exceptions.

**Component rule — no hardcoded colors:** All Blade components, Livewire components, and Filament resource views must use semantic Tailwind classes (e.g., `bg-primary-600`, `text-danger-500`). Hardcoded color classes (e.g., `bg-blue-600`, `text-red-500`, `bg-teal-500`, `text-cyan-600`) are **forbidden**. Enforcement: (1) Tailwind config generates only semantic color names — direct color scales (`blue`, `red`, `green`, `sky`, `cyan`, `teal`, `emerald`) produce no output CSS, making them a build error; (2) code review checklist flags any violation; (3) optional ESLint/Stylelint custom rule for automated detection.

### 7.7 Auth Stack & UI Boundary Mandates

These mandates define the strict boundaries between the three UI surfaces of StudyNexus. Violating any boundary is an architectural error equivalent to bypassing authorization.

**Auth Stack:** Laravel Fortify is the backend authentication service (rate-limited login, password reset, email verification, two-factor authentication). All auth-facing UI routes (Login, Registration, 2FA, Password Reset, Email Verification) are rendered using Livewire + Flux Pro components — not Filament, not custom Blade forms. Fortify handles the backend logic; Livewire + Flux Pro handles the frontend interaction. This combination provides server-driven, SEO-compatible auth flows with zero JavaScript framework dependencies.

**Strict UI Boundary Mandate — Three Surfaces:**

| Surface | Auth Required | Technology | Purpose | Filament? |
|---|---|---|---|---|
| **Public Site** | No (guest browse) | Livewire v4 + Flux Pro + Blade + Tailwind | Homepage, Search, Programme/Institution/Scholarship detail pages. SEO-optimized, server-side rendered. | **NEVER** |
| **User Portals** | Yes | Livewire v4 + Flux Pro + Blade + Tailwind | Student Panel (saved programmes, preferences, comparison sets, alerts) and Organization Panel (institution rep dashboards, programme editing, data submission). | **NEVER** |
| **Internal Admin** | Yes (platform staff only) | Filament v5 + filament-shield | Global user management, data ingestion queues, review/approval workflows, system settings, content management. | **Exclusively** |

**Boundary enforcement:**
1. **Public Site routes** (`routes/web.php`) use `web` middleware only. No `auth` middleware on browse/search/detail routes. Guest users can access all discovery surfaces.
2. **User Portal routes** (`routes/web.php`, `auth` middleware group) use Livewire components + Flux Pro for all interactive UI. Filament resources are NOT accessible to institution reps or students. The Organization Panel and Student Panel are Livewire + Flux Pro applications, not Filament panels.
3. **Admin routes** (auto-generated by Filament) use `web`, `auth`, `verified`, `filament` middleware. Only platform staff with admin-assigned roles (super_admin, content_manager, data_analyst, support_agent) can access. Institution reps and students are NEVER granted Filament access.
4. **No shared layouts** between Filament admin and Livewire public/portals. Each surface has its own layout system, navigation, and component library. The only shared code is domain models, Actions, Query classes, and validation rules.

**Organization Portal Workflow — Pending Revision Gate:**

Institution representatives may edit their institution's programmes and data via the Organization Portal (Livewire + Flux Pro), but they **MUST NOT** be able to directly publish their edits to the live site. This is a hard trust boundary:

1. **Rep edits programme** → saves as **"Pending Revision"** state (not published). The programme record's `is_published` flag remains unchanged. The pending revision is stored in a dedicated `pending_revisions` table (see schema below). spatie/laravel-activitylog records the audit trail of the approval/rejection, but the revision payload itself is stored in pending_revisions for queryability and admin workflow support.
2. **Pending revision appears** in a **Filament v5 Review Queue** accessible only to Internal Admin staff (content_manager, super_admin roles). The queue shows: institution name, programme name, revision timestamp, diff summary, rep who submitted.
3. **Admin reviews** the revision: Approve → pending revision is applied to the canonical record, `is_published` is updated, and the change goes live. Reject → revision is marked rejected with a reason, rep is notified.
4. **All actions tracked** by `spatie/laravel-activitylog`: revision submitted, revision approved, revision rejected. Activity log entries include the rep's user ID, the admin's user ID, timestamps, and the before/after state.

**Rationale for Pending Revision Gate:** StudyNexus is a trust-grounded education discovery platform. Institution reps have a financial incentive to present their programmes favorably (inflating cut-off marks, omitting admission requirements, misrepresenting accreditation status). Direct self-publishing would undermine the platform's trust model. The review gate ensures every data change from an institution rep is verified by platform staff before it affects the public site, while `spatie/laravel-activitylog` provides a complete audit trail for accountability and regulatory compliance.

---

## 8. Search Implementation

### 8.0 V1 Search: Typesense

Typesense is the V1 search engine providing full-text search, faceted navigation, typo tolerance, and autocomplete. PostgreSQL FTS is maintained as a secondary search capability for admin search and as a fallback when Typesense is unavailable.

**Idempotent import upsert:** The ApplicationJob uses PostgreSQL ON CONFLICT DO UPDATE for all canonical entity writes. For entities with external identifiers (Institutions, Programmes, Campuses), the upsert key is the external_identifiers unique composite index (INV-EI1). For child records without external identifiers, the upsert key is their natural domain-level unique constraint matching the physical schema: `cut_off_marks` on `(programme_instance_id, admission_cycle_id, pathway)`, `admission_policies` on `(governable_type, governable_id, admission_cycle_id)`, and `accreditation_records` on `(accreditable_type, accreditable_id, authority_id)`. Fuzzy matching is restricted to the staging/review queue; canonical identity resolution is always deterministic.

**V1 Implementation:**

- **Typesense server:** Deployed as a managed or self-hosted instance; 7 collections (see Section 8.3); Scout Typesense driver configured in `config/scout.php`
- **Denormalized sync:** Domain events → `UpdateSearchIndex` listener → queued Scout job → Typesense upsert (see Section 8.4)
- **Faceted search:** Native Typesense faceting across all configured facet fields with real-time counts. Geographic facets via Typesense geo filter. Tuition range filtering via `tuition_min`/`tuition_max` int32 fields
- **Search queries:** Typesense multi-field search with typo tolerance, ranking, and sort configuration
- **Autocomplete:** Typesense instant search API for prefix/fuzzy matching
- **Scout abstraction:** Laravel Scout with Typesense driver for V1. `toSearchableArray()` maps model attributes uniformly. `database` driver available as fallback when Typesense is unavailable
- **Performance monitoring:** Search latency and error rates tracked via `laravel/pulse`
- **PostgreSQL FTS fallback:** tsvector columns + GIN indexes maintained on `programmes`, `institutions`, `scholarships` tables. When Typesense is unavailable, Scout falls back to `database` driver. Admin search always uses PostgreSQL FTS directly

### 8.1 PostgreSQL FTS Fallback

PostgreSQL FTS provides a degraded search capability when Typesense is unavailable. It supports basic full-text search and trigram autocomplete but lacks faceting, typo tolerance, and real-time sort. PostgreSQL/Eloquent remains authoritative for canonical entities, SEO pages, and structured data rendering.

### 8.2 The Separation

| Concern | Owned By | Rationale |
|---|---|---|
| Canonical entity data | PostgreSQL | Source of truth (ADR-01, P9) |
| SEO page rendering | Blade + Laravel | Server-rendered HTML for crawlers |
| Canonical URLs | Laravel routes | Stable, deliberate, controlled |
| Structured data | Blade templates | JSON-LD in server-rendered pages |
| Full-text search | Typesense (V1) | Optimized for search, not rendering; PostgreSQL FTS fallback |
| Faceted navigation | Typesense (V1) | Real-time faceting, filtering, sorting; PostgreSQL FTS fallback with query-builder + aggregate counts |
| Autocomplete | Typesense (V1) | Instant search API; pg_trgm fallback when Typesense unavailable |
| Discovery/hub pages | Blade (initial) + search engine (results) | SEO entry point + interactive results |

### 8.3 Typesense Collections (7) — V1 Design

| Collection | Source Model | Key Fields | Facet Fields | Sort Fields |
|---|---|---|---|---|
| institutions | Institution | name, slug, type, ownership_type, description | type, ownership_type, country | created_at, name |
| programmes | Programme | name, slug, award_level, discipline, discipline_slug, institution_name, institution_slug, institution_type, admission_mode, is_published, tuition_min, tuition_max, is_admission_open, **instances[]** (nested object array) | award_level, discipline, institution_type, country, instances.campus, instances.delivery_mode | created_at, name |
| scholarships | Scholarship | name, slug, value, provider_name, coverage_type | coverage_type, provider_type, award_level, country | deadline, value |
| articles | Article | title, slug, category, institution_name | category, resource_type | published_at |
| guides | Guide | title, slug, category | category | published_at |
| educational_resources | EducationalResource | title, slug, resource_type, discipline, academic_level | resource_type, discipline, academic_level | published_at |
| exam_preparations | ExamPreparation | title, slug, prep_type, exam_body, subject, year | prep_type, exam_body, subject, year | published_at |

**§8.3.1 Programme `instances` Nested Object Array — Mandatory Design**

The Programme Typesense document MUST index delivery_mode and campus as a nested object array (`instances[]`), NOT as flat multi-value arrays. This is a hard architectural rule to prevent cross-field facet filter corruption.

**Why flat arrays are forbidden:** If `campus: ["Abuja", "Remote"]` and `delivery_mode: ["OnCampus", "Online"]` are indexed as separate flat arrays, a filter for `campus=Abuja AND delivery_mode=Online` would incorrectly match a Programme that only offers Abuja OnCampus and Remote Online — because Typesense evaluates each array independently and returns the union of matches. This violates the ProgrammeInstance boundary: each instance is a cohesive `(campus, delivery_mode)` pair.

**Correct nested schema:**
```json
{
  "name": "programmes",
  "fields": [
    { "name": "name", "type": "string" },
    { "name": "slug", "type": "string" },
    { "name": "award_level", "type": "string", "facet": true },
    { "name": "discipline", "type": "string", "facet": true },
    { "name": "discipline_slug", "type": "string" },
    { "name": "institution_name", "type": "string" },
    { "name": "institution_slug", "type": "string" },
    { "name": "institution_type", "type": "string", "facet": true },
    { "name": "country", "type": "string", "facet": true },
    { "name": "admission_mode", "type": "string" },
    { "name": "is_published", "type": "bool" },
    { "name": "tuition_min", "type": "int32" },
    { "name": "tuition_max", "type": "int32" },
    { "name": "is_admission_open", "type": "bool" },
    {
      "name": "instances",
      "type": "object[]",
      "optional": false,
      "fields": [
        { "name": "campus", "type": "string", "facet": true, "index": true },
        { "name": "delivery_mode", "type": "string", "facet": true, "index": true },
        { "name": "is_published", "type": "bool", "index": true },
        { "name": "tuition_amount", "type": "int32", "index": true }
      ]
    }
  ]
}
```

**Example document:**
```json
{
  "name": "B.Sc. Computer Science",
  "slug": "bsc-computer-science",
  "instances": [
    { "campus": "Abuja", "delivery_mode": "OnCampus", "is_published": true, "tuition_amount": 150000 },
    { "campus": "Remote", "delivery_mode": "Online", "is_published": true, "tuition_amount": 120000 }
  ]
}
```

**Query rule — Cross-field facet filters MUST use nested object filtering:**
All faceted search queries that combine `campus` and `delivery_mode` filters MUST use Typesense's nested object filtering syntax to ensure both conditions apply to the SAME array element (i.e., the same ProgrammeInstance). This prevents cross-instance contamination.

Typesense filter syntax: `instances.campus:=Abuja && instances.delivery_mode:=OnCampus`

In Laravel Scout, this is expressed via the `where()` clause chain on the search query builder, which Typesense's driver translates to the `&&` conjunction on the same nested object. Implementation MUST verify that the generated filter string uses `&&` (same-element conjunction) and not `&&` across separate filter groups, which would revert to independent evaluation.

The `toSearchableArray()` method on the Programme model builds the `instances` array from all published ProgrammeInstance records: `instances: $this->instances()->where('is_published', true)->map(fn($i) => ['campus' => $i->campus->name, 'delivery_mode' => $i->delivery_mode->value, 'is_published' => $i->is_published, 'tuition_amount' => $i->tuition_amount->amount])->values()->toArray()`.

### 8.4 Sync Mechanism

Domain events -> `UpdateSearchIndex` listener -> queued Scout job -> Typesense upsert. Eventual consistency with a stale tolerance of 5 seconds or less. On failure, the queued job retries with exponential backoff. Full reindex is available via `php artisan scout:import-all`. If the Typesense collection is corrupted, it can be fully rebuilt from PostgreSQL. Programme documents denormalize `institution_name`, `institution_slug`, `institution_type`, and `country` from the parent Institution to avoid join queries in Typesense. These denormalized fields are updated when the parent Institution changes via the `InstitutionRenamed` or `InstitutionEstablished` events, which trigger re-indexing of all child Programmes.

**Search projection fields** exist in Typesense and are computed by `toSearchableArray()`:
- `discipline` and `discipline_slug`: denormalized from the `disciplines` reference table via the `discipline_id` FK on Programme.
- `is_published`: boolean filter field. Only published programmes (`is_published = true` AND lifecycle status allows public display) are indexed in the public-facing Typesense collection. Admin search uses PostgreSQL FTS directly and includes all programmes regardless of publication status.
- `tuition_min` and `tuition_max`: int32 fields computed from the MonetaryAmount VO on Programme. If the programme has indigene and non-indigene tuition, `tuition_min` is the lower value and `tuition_max` is the higher. These enable tuition range faceting without storing the VO structure in Typesense.
- `is_admission_open`: boolean field computed from Programme lifecycle status + current Admission Cycle phase + existence of an active AdmissionPolicy. This is a read-model derivation, not a stored domain property.

### 8.5 Scout Configuration

Laravel Scout v11. V1: Typesense driver. Fallback: `database` driver with PostgreSQL FTS. Each searchable model implements the `Searchable` interface via the `IsSearchable` trait. The `toSearchableArray()` method maps model attributes to search document fields, including denormalized parent data where applicable. Scout queue is enabled for all models to prevent synchronous index updates from blocking request/response cycles. The Typesense client (`typesense/typesense-php` v4.x) is configured via `config/scout.php` with connection details, collection-specific schema definitions, and facet/sort configuration.

### 8.6 Controlled Indexation

Not every URL combination is indexable. The SEO architecture deliberately controls which pages search engines can crawl: canonical entity pages are indexable, curated discovery pages are indexable, deep filter combinations (more than 3 query parameters) are noindex, paginated pages beyond page 1 are noindex, user profiles and search results pages are noindex. This prevents exponential URL explosion and conserves crawl budget.

---

## 9. Package Matrix

Every package is evaluated against Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4. Packages that have been verified by the package audit are marked VERIFIED. Packages with known issues or pending verification are noted. No fabricated package names appear in this matrix.

### 9.1 Adopt Now (20 packages)

| # | Package | Version | Purpose | Status |
|---|---|---|---|---|
| 1 | `spatie/laravel-permission` | ^6.0 | RBAC engine | VERIFIED |
| 2 | `spatie/laravel-medialibrary` | ^11.0 | File/media management | VERIFIED |
| 3 | `spatie/laravel-tags` | ^4.0 | Taxonomy/tagging | VERIFIED |
| 4 | `spatie/laravel-activitylog` | ^5.0 | Audit trail | VERIFIED |
| 5 | `spatie/laravel-sitemap` | ^7.0 | XML sitemaps | VERIFIED |
| 6 | `spatie/laravel-honeypot` | ^4.0 | Spam protection | VERIFIED |
| 7 | `spatie/laravel-backup` | ^9.0 | Database/file backup | VERIFIED |
| 8 | `spatie/laravel-webhook-client` | ^3.0 | Incoming webhooks | VERIFIED |
| 9 | `spatie/laravel-personal-data-export` | ^4.0 | GDPR data export | VERIFIED |
| 10 | `spatie/laravel-data` | ^4.0 | Data transfer objects | VERIFIED |
| 11 | `spatie/laravel-sluggable` | ^4.0 | Slug generation | VERIFIED |
| 12 | `spatie/laravel-searchable` | ^3.0 | Search abstraction | VERIFIED |
| 13 | `spatie/laravel-query-builder` | ^3.0 | API filtering/sorting | VERIFIED |
| 14 | `maatwebsite/excel` | ^3.1 | Import/export | VERIFIED |
| 15 | `laravel-notification-channels/webpush` | ^8.0 | Web Push notifications | VERIFIED |
| 16 | `laravel/socialite` | ^5.0 | Social OAuth login | VERIFIED |
| 17 | `laravel/sanctum` | ^4.0 | API token auth | VERIFIED |
| 18 | `laravel/pulse` | ^1.0 | Application monitoring | VERIFIED |
| 19 | `bezhansalleh/filament-shield` | ^5.0 | Filament + Permission integration | VERIFIED (name corrected from `bezhansalam`; version must match Filament v5) |
| 20 | `pxlrbt/filament-activity-log` | ^3.1.1 | Activity log in admin panel | VERIFIED (Filament v4/v5-compatible community standard) |

### 9.2 Core Stack Packages

| # | Package | Version | Purpose | Status |
|---|---|---|---|---|
| 21 | `laravel/framework` | ^13.0 | Application framework | VERIFIED |
| 22 | `laravel/fortify` | ^1.0 | Backend auth scaffolding | VERIFIED (rate-limited login, registration, password reset, email verification; paired with Livewire/Flux Pro for UI) |
| 23 | `laravel/scout` | ^11.0 | Search driver abstraction (Typesense driver for V1; `database` fallback) | VERIFIED |
| 24 | `livewire/livewire` | ^4.0 | Server-driven reactive UI | VERIFIED (v4 required for Laravel 13) |
| 25 | `livewire/flux` | ^1.0 | UI component library | VERIFIED |
| 26 | `filament/filament` | ^5.0 | Admin panel framework | VERIFIED (v5 designed for Livewire v4 + Laravel 13 + PHP 8.5) |
| 27 | `typesense/typesense-php` | ^4.0 | Typesense PHP client (V1 requirement) | VERIFIED |
| 28 | `pestphp/pest` | ^4.0 | Test framework | VERIFIED |

### 9.3 Adopt When Needed (9 packages)

| # | Package | Version | Trigger | Status |
|---|---|---|---|---|
| 29 | `spatie/laravel-settings` | ^3.0 | When admin-configurable settings needed | VERIFIED |
| 30 | `spatie/laravel-responsecache` | ^7.0 | When traffic volume justifies | VERIFIED |
| 31 | `spatie/laravel-markdown` | ^3.0 | When community feature begins | VERIFIED |
| 32 | `spatie/eloquent-sortable` | ^4.0 | When display ordering needed | VERIFIED |
| 33 | `laravel/horizon` | ^5.0 | When queue monitoring needed | VERIFIED |
| 34 | `spatie/laravel-webhook-server` | ^3.0 | When outbound webhooks needed | VERIFIED |
| 35 | `spatie/browsershot` | ^5.0 | When PDF export needed | VERIFIED |
| 36 | `spatie/laravel-translation-loader` | ^5.0 | When Africa expansion begins | VERIFIED |
| 37 | `spatie/laravel-welcome-notification` | ^3.0 | When onboarding implemented | VERIFIED |

### 9.4 Evaluate Later (3 packages)

| Package | Concern | Status |
|---|---|---|
| `spatie/laravel-csp` | Content Security Policy -- not launch-blocking | VERIFIED |
| `laravel/passkeys` | WebAuthn -- evaluate in 12 months | VERIFIED |
| `spatie/laravel-health` | May be redundant with K8s probes | VERIFIED |

**Rate limiting**: Use Laravel's built-in `RateLimiter` facade or `spatie/laravel-rate-limited-job-middleware` for queue job rate limiting. The package `spatie/laravel-rate-limits` does not exist under that name and must not be used.

### 9.5 Rejected Packages (12)

| Package | Reason |
|---|---|
| `spatie/laravel-event-sourcing` | Contradicts ADR-02 |
| `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| `spatie/laravel-model-states` | Guard clauses + PHP enums are LBC-idiomatic |
| `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| `spatie/laravel-fractal` | Superseded by laravel-data |
| `spatie/valuestore` | Superseded by laravel-settings |
| `spatie/laravel-view-models` | Superseded by laravel-data |
| `spatie/laravel-geocoder` | Typesense geo filter (V1) / PostgreSQL FTS geo filter (fallback) handles location |
| `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| `spatie/laravel-feeds` | Near-zero relevance |
| `wireui/wireui` | Unnecessary when using Flux |
| `spatie/laravel-ray` | Dev-only, never in production dependencies |

### 9.6 Fabricated/Invalid Packages (Must Not Appear)

| Package | Reality | Replacement |
|---|---|---|
| `minimolabs/laravel-webpush` | FABRICATED -- does not exist on Packagist | `laravel-notification-channels/webpush` |
| `bezhansalam/filament-shield` | MISSPELLED -- correct name has double 'l' | `bezhansalleh/filament-shield` |
| `filament/tiptap-editor` | DEPRECATED for Filament v4/v5 | Use Filament native RichEditor |
| `spatie/laravel-rate-limits` | DOES NOT EXIST under this name | Laravel `RateLimiter` facade or `spatie/laravel-rate-limited-job-middleware` |

### 9.7 Dev Dependencies

- `pestphp/pest` ^4.0 -- test framework
- `laravel/pint` -- code style fixer
- `laravel/telescope` -- dev debugging (dev-only, never in production)

### 9.8 Infrastructure Package Mandates

The following infrastructure concerns have mandated packages. **Custom solutions for these areas are forbidden.**

| Concern | Mandated Package | Rationale |
|---------|-----------------|-----------|
| Admin panel & CRUD | `filament/filament` ^5.0 | Full admin panel with zero custom infrastructure. 11-role RBAC via filament-shield. Custom admin solutions are forbidden. |
| RBAC (11 roles) | `spatie/laravel-permission` ^6.0 | 4 platform-global + 5 institution-scoped + 2 user-level roles. Custom RBAC solutions are forbidden. |
| Data provenance & audit trail | `spatie/laravel-activitylog` ^5.0 | **Event Sourcing is explicitly rejected; audit trails and data provenance are handled via Spatie Activitylog.** Provides old/new value tracking on every model change without CQRS, event stores, or projection rebuilds. Custom audit trail implementations are forbidden. |
| Value Objects & DTOs | `spatie/laravel-data` ^4.0 | Type-safe DTOs, VO casting, form objects, API resources. Custom DTO/VO wrapper classes are forbidden. |
| Media & assets | `spatie/laravel-medialibrary` ^11.0 | Institution logos, campus photos, programme brochures, content images. Custom file management solutions are forbidden. |

**Event Sourcing rejection:** Domain events (29 events, plain PHP per ADR-3/ADR-16) are integration events, not stored events. Source of truth is PostgreSQL via Eloquent. Event sourcing would force CQRS (contradicts Laravel Beyond CRUD), require an event store, and add projection rebuild complexity. Activitylog fulfills the audit requirement without these costs. The `spatie/laravel-event-sourcing` package is rejected per ADR-02. This decision is immutable.

---

## 10. Implementation Order

Implementation follows a dependency-correct phase sequence. Auth and RBAC come first because domain model tests need authenticated users to verify Policies, OrganizationMember is referenced by domain Policies, reference data is needed by seeders, and Spatie Permission roles must exist before Filament resources can check authorization. The total Phase 1 duration is approximately 17 weeks.

### 10.1 Phase Sequence

| Phase | Name | Duration | Dependencies | Done When |
|---|---|---|---|---|
| **1a** | Laravel foundation + Auth + RBAC + Reference Data | 3 weeks | None | Users can register/login; roles/permissions seeded; reference data importable |
| **1b** | Domain Layer | 3 weeks | 1a | All 16 domain tables migrated (including campuses, programme_instances); 20 Actions tested; Policies enforce RBAC |
| **1c** | Content Layer | 2 weeks | 1b | 4 content models + 8 traits + Filament CRUD for content |
| **1d** | Public Site -- Domain Pages | 3 weeks | 1b | Institution/programme/scholarship detail pages; programme discovery hubs |
| **1e** | Public Site -- Content Pages | 2 weeks | 1c | Article/guide/resource/exam-prep pages; content listing pages |
| **1f** | Search (Typesense V1 + PostgreSQL FTS fallback) | 1 week | 1b, 1c | Deploy Typesense server; 7 collections; Scout Typesense driver; denormalized sync; autocomplete; tsvector columns + GIN indexes maintained for fallback; admin search via PostgreSQL FTS; search results page |
| **1g** | SEO | 1 week | 1d, 1e | Canonical URLs; sitemaps; structured data; robots meta; Open Graph |
| **1h** | Engagement | 1 week | 1d, 1e | Save, Follow, Like, Share; notification_preferences seeded |
| **1i** | Notifications | 1 week | 1h | 5 notification classes; DB + Email channels; WebPush flag |
| **2a** | Community Module | 3 weeks | 1d, 1i | Question + Answer + Comment + Vote + Report; feature flag |
| **2b** | Study Abroad Module | 2 weeks | 1d, 1c | Reference data for international; Livewire components; feature flag |
| **2c** | Comparison | 1 week | 1h | comparison_sets; Livewire compare UI |
| **2d** | Exam Preparation | 1 week | 1c | ExamPrep model + UI + download tracking |
| **3** | Advanced Features | TBD | All above | Posts/Channels, Reputation, Badges, AI, API, SMS notifications |
| **4a** | Typesense Optimization | 2 weeks | 1f, 3 | Tune Typesense ranking/sorting; optimize collection schemas; add geo search; refine typo-tolerance settings; performance benchmarking |

### 10.2 Phase Dependencies

```
1a (Foundation + Auth + RBAC + Reference Data)
  |-- 1b (Domain Layer)
  |     |-- 1c (Content Layer)
  |     |     |-- 1e (Content Pages)
  |     |     |-- 2d (Exam Preparation)
  |     |-- 1d (Domain Pages)
  |     |-- 1f (Search - Typesense V1 + PostgreSQL FTS fallback, depends on 1b + 1c)
  |-- 1g (SEO - depends on 1d + 1e)
  |-- 1h (Engagement - depends on 1d + 1e)
        |-- 1i (Notifications)
        |     |-- 2a (Community)
        |-- 2c (Comparison)
2b (Study Abroad - depends on 1d + 1c)
4a (Typesense Optimization - depends on 1f + 3)
```

### 10.3 Phase 1a Detail (Foundation)

This phase establishes the entire application skeleton. Step by step: (1) `composer create-project laravel/laravel studynexus "13.*"`, (2) configure PostgreSQL, Redis, environment variables, (3) install and configure Livewire v4 + Flux, (4) install and configure Filament v5 admin panel, (5) install Laravel Fortify + Livewire/Flux Pro auth stack and run auth scaffolding, (6) install `spatie/laravel-permission` and publish migrations, (7) create the 11 roles and seed base permissions, (8) create the OrganizationMember pivot migration and model, (9) install all Spatie Adopt Now packages (medialibrary, tags, activitylog, sitemap, honeypot, backup, etc.), (10) create reference data migrations (countries, currencies, qualifications) and seeders, (11) install and configure `bezhansalleh/filament-shield` for Filament + Permission integration, (12) install `pxlrbt/filament-activity-log` for admin activity logging, (13) configure Pest test framework, (14) write initial auth/RBAC feature tests verifying all 11 roles and OrganizationMember scoping.

### 10.4 Feature Flags

| Flag | Default | Module |
|---|---|---|
| `features.community` | false | Community module (Phase 2a) |
| `features.study_abroad` | false | Study Abroad module (Phase 2b) |
| `features.web_push` | false | Web Push notifications (Phase 1i) |
| `features.sms` | false | SMS notifications (Phase 3) |
| `features.exam_preparation` | false | Exam Preparation module (Phase 2d) |

Feature flags are stored in config/environment, not in the database. They gate entire modules, not individual features within modules. Removing a feature flag disables the module without affecting any other part of the system.

### 10.5 Remaining Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| 1 | Package incompatibility with Laravel 13 + PHP 8.5 | High | Package audit complete; all Adopt Now packages VERIFIED |
| 2 | Content scope creep | High | Behaviour Test: model justified by distinct behaviour, not distinct data |
| 3 | Livewire-overuse | Medium | Explicit boundary rule (Section 7.2); code review checklist |
| 4 | RBAC complexity growth | Medium | Start with 5 institution roles; add only when user research demands |
| 5 | Settings architecture over-engineering | Medium | Start simple; add tiers as needed |
| 6 | Polymorphic relationship performance at scale | Low | Explicit indexes; hot paths use explicit FKs |
| 7 | Typesense availability | Medium | PostgreSQL FTS fallback provides degraded search; Typesense restart recovers |
| 8 | Feature flag drift | Low | Feature flags in .env; documented defaults |

### 10.6 Architectural Drift Guards

Any future coding agent working on StudyNexus must NOT: add a new entity without behavioural justification (Behaviour Test); add a new package without verifying its existence, maintenance, and Laravel 13 compatibility; add a repository without justification that overrides ADR-04; introduce React, Next.js, Vue, or Inertia anywhere; bypass scoped authorization (always check both global permission AND org membership); hard-code role assumptions (roles are strings, not enums; they evolve); create Nigeria-specific domain abstractions where a universal concept exists; make domain depend on presentation or content; use any search engine as the source of truth (PostgreSQL is authoritative; Typesense is a projection); bypass Typesense for public search (Typesense is the V1 search engine; PostgreSQL FTS is fallback only); create indexable URL combinations without SEO analysis; put every piece of data into a generic JSON settings table; make Livewire the default for every page (Blade first, Livewire when needed).

---

*End of StudyNexus Implementation Blueprint. All canonical corrections applied. Entity count: 13 domain + 2 infrastructure (ExternalIdentifier, FieldProvenance). VO count: 29. Enum count: 17. Platform: Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4. RBAC: 11 roles with string role column on OrganizationMember pivot. Table count: 61. Publication: is_published boolean + published_at nullable timestamp on Institution, Programme, Scholarship (orthogonal to domain lifecycle). Discipline: disciplines reference table + discipline_id BIGINT FK on programmes (ADR-19). Cut-off history: cut_off_marks table with BIGINT PKs (ADR-19), scoped to ProgrammeInstance. InformationSource: independent aggregate root with authority_id nullable FK (ND-5/ADR-22), no institution_id. Provenance: entity-level JSONB + field_provenance table (ND-4/ADR-23) with 80/20 field model. External identifiers: external_identifiers table (BD-5/ADR-21). valid_until (not valid_to) on accreditation_records and external_identifiers. ProgrammeInstance: child entity of Programme (concrete offering per campus/mode/year); delivery_mode and tuition moved from Programme to ProgrammeInstance. Campus: supporting entity of Institution (multi-campus support); Location moved from Institution to Campus. CampusStatus enum added (Active, Inactive, Planned). Public IDs: UUID public_id on institutions, programmes, programme_instances, campuses, scholarships (URL-safe, prevents sequential ID scraping). JSONB deconstruction: tuition_amount/currency_code on programme_instances; city/state/country on campuses — extracted for indexed sorting/filtering without JSONB sequence scans. Generated columns: search_vector (tsvector) on programmes, institutions, scholarships with GIN indexes. pg_trgm GIN indexes on institutions.name and programmes.name for autocomplete. Source authority weighting: priority column on information_sources for conflict resolution. No fabricated packages. No deprecated packages. No Laravel 12/Filament v3/Livewire v3 instructions.*
