# StudyNexus — Current State Map

**Snapshot date:** 2026-08-19 | **V2 Baseline version:** V4.1 (remediated)

## Area Status

| Area | Current Authority | Status | Notes |
|------|-------------------|--------|-------|
| Business/Product | `01-business.md` | Frozen | 48K — product vision, users, market, competitors |
| Decisions | `02-decisions.md` | Frozen | 73K — ADRs, foundational decisions, canonical counts |
| Domain | `03-domain.md` | Frozen | 75K — entities, VOs, enums, invariants, aggregates |
| Architecture | `04-architecture.md` | Frozen | 69K — stack, app arch, auth, admin, search, SEO, RBAC, UI boundaries |
| Implementation | `05-implementation.md` | Frozen | 102K — migrations, phases, packages, schema, search, theming |
| Data Acquisition | `06-data-acquisition.md` | Frozen | 22K — sources, staging, provenance, import pipeline |
| Product Experience | 4 UX/UI documents | Current | Discovery, Architecture, First Vertical Slice (UX + UI) |
| Implementation Audits | 7 documents | Current | Final audit, cleanup, correction, reconciliation |
| Governance | 25+ documents | Current | Adversarial reviews, hostile reviews, decision evidence |
| Product Strategy | PRODUCT-DISCOVERY-CHALLENGE | Non-authoritative | Competitive research, feature synthesis |
| Historical | 12 key documents | Superseded | Original decisions, frozen baseline, reconciliation |
| Code | None | **Not started** | No Laravel project scaffolded |
| Migrations | None | **Not started** | No migration files written |
| Phase 0 | None | **Not started** | Implementation has not begun |

## Canonical Counts (V4.1)

| Metric | Value |
|--------|-------|
| Domain entities | 13 |
| Value Objects | 29 (12 non-enum + 17 PHP Backed Enums) |
| Enums | 17 |
| Domain events | 29 |
| Application Actions | 20 |
| Database tables | 60 |
| RBAC roles | 11 (4 platform-global + 5 institution-scoped + 2 user-level) |
| Aggregate roots | 5 |

## Key Architectural Decisions

| Decision | Choice | ADR |
|----------|--------|-----|
| PK strategy | BIGINT canonical PKs (no UUID PKs) | BD-1 / ADR-19 |
| Public identity | UUID `public_id` on 5 user-facing entities | BD-1 |
| Search (MVP) | PostgreSQL FTS only | ADR-6 |
| Search (post-MVP) | Typesense when FTS latency > 200ms | ADR-6 |
| Auth stack | Laravel Fortify + Livewire + Flux Pro | Canonical |
| Admin panel | Filament v5 (Internal Admin only) | Canonical |
| UI theming | OKLCH, Sky/Cyan/Teal/Emerald, dark mode V1 | Canonical |
| Event Sourcing | **Explicitly rejected** | ADR (spatie/laravel-activitylog instead) |
| Color space | OKLCH (not HEX/HSL) | Refactoring UI |
| Organization edits | Pending Revision Gate (no direct publish) | Canonical |
