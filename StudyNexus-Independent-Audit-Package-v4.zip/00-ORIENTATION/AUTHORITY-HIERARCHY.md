# StudyNexus — Authority Hierarchy

This document defines the strict override order for all documents in this package.

## Tier 1 — Canonical Authority (HIGHEST)

**Source:** `01-CANONICAL/`

These six documents are the frozen V2 baseline. They have been through multiple waves of independent audit, adversarial review, hostile review, and surgical remediation. They are the final word on what StudyNexus is, how it is architected, and how it will be implemented.

- `01-business.md` — Business context, product vision
- `02-decisions.md` — All architectural decisions
- `03-domain.md` — Domain model (entities, VOs, enums, invariants)
- `04-architecture.md` — Technology stack, application architecture, auth, UI boundaries
- `05-implementation.md` — Implementation blueprint (this IS the implementation plan)
- `06-data-acquisition.md` — Data acquisition pipeline

**Override rule:** Tier 1 overrides ALL other tiers. No exception.

## Tier 2 — Product Experience Authority

**Source:** `02-PRODUCT-EXPERIENCE/`

Current UX/UI/product-experience documents governing the first vertical slice. These define what the user sees and how they interact. They are constrained by Tier 1 — the UX must be implementable within the architecture.

- `PRODUCT-EXPERIENCE-DISCOVERY.md` — Product experience discovery
- `PRODUCT-EXPERIENCE-ARCHITECTURE.md` — UX architecture, OKLCH theming, Refactoring UI
- `FIRST-VERTICAL-SLICE-UX.md` — First vertical slice UX specification
- `FIRST-VERTICAL-SLICE-UI.md` — First vertical slice UI specification

**Override rule:** Tier 2 overrides Tiers 3–6. Overridden by Tier 1.

## Tier 3 — Implementation Plan Authority

**Source:** `03-IMPLEMENTATION/`

The implementation plan and its validation artifacts. Note that `05-implementation.md` in Tier 1 IS the canonical implementation plan. The documents here are additional audit/correction reports that explain WHY the implementation plan is considered ready.

- `IMPLEMENTATION-PLAN.md` — Standalone implementation plan (should match Tier 1)
- `IMPLEMENTATION-PLAN-FINAL-AUDIT.md` — Final audit of the plan
- `IMPLEMENTATION-PLAN-FINAL-CLEANUP-REPORT.md` — Final cleanup corrections
- `IMPLEMENTATION-PLAN-CORRECTION-REPORT.md` — Correction report
- `IMPLEMENTATION-PLAN-AUDIT.md` — Detailed audit
- `IMPLEMENTATION-MODEL-RECONCILIATION.md` — Implementation model reconciliation
- `05-implementation-RECONCILIATION-PROPOSAL.md` — Reconciliation proposal
- `STUDYNEXUS-CANONICAL-REMEDIATION-REPORT.md` — Canonical remediation report

**Override rule:** Tier 3 is explanatory. It does not override Tier 1 or Tier 2.

## Tier 4 — Governance / Decision Evidence

**Source:** `04-GOVERNANCE/`

Documents that explain HOW the architecture reached its current state. These provide traceability for decisions, capture rejected alternatives, and record the audit history. They are evidence, not authority.

Key documents:
- `ADVERSARIAL-DECISION-REVIEW.md` (130K) — Comprehensive adversarial review of all decisions
- `FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` — Adversarial review of foundational decisions
- `SECOND-ORDER-ARCHITECTURE-REVIEW.md` — Second-order architecture review
- `FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` — Lineage and semantics resolution
- `FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` — Hostile provenance review
- `FIELD-PROVENANCE-HOSTILE-REVIEW.md` — Hostile field provenance review
- `DISCOVERY-CLOSURE.md` — Discovery closure declaration
- Multiple consistency/amendment/update reports

**Override rule:** Tier 4 is evidence only. It never overrides Tiers 1–3.

## Tier 5 — Product Strategy / Competitive Research

**Source:** `05-PRODUCT-STRATEGY/`

Non-authoritative product research that informed the broader StudyNexus product vision. This includes competitive analysis, feature synthesis across global and African competitors, and the product discovery challenge.

**⚠️ NON-AUTHORITATIVE PRODUCT RESEARCH**
Competitor features are NOT StudyNexus requirements. This material exists so an independent reviewer can evaluate whether the current architecture sufficiently supports strategically relevant long-term product capabilities.

- `PRODUCT-DISCOVERY-CHALLENGE.md` (60K) — Competitive research, feature synthesis, product challenge

**Override rule:** Tier 5 informs but NEVER constrains. It is research, not specification.

## Tier 6 — Historical / Superseded

**Source:** `07-HISTORICAL/` and `06-DATA-ACQUISITION/`

Superseded material preserved for traceability. These documents show how the architecture evolved, what was tried and rejected, and what the original thinking was. They are valuable for understanding the "why" but must not be treated as current.

**Override rule:** Tier 6 is never authoritative. It can explain but never override.
