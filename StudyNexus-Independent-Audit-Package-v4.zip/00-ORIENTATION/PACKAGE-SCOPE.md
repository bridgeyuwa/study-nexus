# StudyNexus — Package Scope & Discovery Log

**Date:** 2026-08-19

## Source Directories Inspected

| Directory | Files Found | Included | Excluded | Reason for Exclusion |
|-----------|-------------|----------|----------|---------------------|
| `PRE-IMPLEMENTATION-BASELINE-V2/canonical/` | 6 | 6 | 0 | All canonical files included (Tier 1) |
| `PRE-IMPLEMENTATION-BASELINE-V2/governance/` | 10 | 10 | 0 | All governance files included (Tier 4) |
| `PRE-IMPLEMENTATION-BASELINE-V2/product-experience/` | 4 | 4 | 0 | All product experience files included (Tier 2) |
| `PRE-IMPLEMENTATION-BASELINE-V2/archive/` | 22 | 12 | 10 | 12 most important historical; 10 redundant/duplicate excluded |
| `download/` (top-level .md) | 15 | 13 | 2 | 2 duplicates of V2 governance already copied |
| `download/HOSTILE-REVIEWS/` | 1 | 1 | 0 | Important hostile review on external identifiers |
| `studynexus-reconciled/` | 15 + 22 archive | 1 | 36 | PRODUCT-DISCOVERY-CHALLENGE.md included; rest superseded by V2 |
| `upload/` | 1 | 1 | 0 | Merged audit included (144K) |
| `/home/z/my-project/` (root .md) | 2 | 1 | 1 | FIELD_PROVENANCE_HOSTILE_REVIEW included; worklog excluded (internal) |
| `PRE-IMPLEMENTATION-BASELINE/` (V1) | 0 | 0 | all | Superseded by V2; V2 includes all V1 content plus corrections |
| `STUDYNEXUS-INDEPENDENT-AUDIT-PACKAGE-V3/` (previous) | 0 | 0 | all | This IS the rebuild; previous package superseded |

## Included by Category

| Category | Files | Total Size |
|----------|-------|------------|
| Canonical (Tier 1) | 6 + README | ~387K |
| Product Experience (Tier 2) | 4 | ~260K |
| Implementation (Tier 3) | 8 | ~293K |
| Governance (Tier 4) | 25+ | ~800K+ |
| Product Strategy (Tier 5) | 2 | ~204K |
| Data Acquisition (Tier 6) | 1 | ~20K |
| Historical (Tier 6) | 12 + 3 V2 meta | ~750K |
| Orientation (Meta) | 4 | ~15K |
| Audit Guide (Meta) | 2 | ~15K |

## Files Deliberately Excluded

| File | Reason |
|------|--------|
| `worklog.md` | Internal agent work log; not relevant to architecture |
| `scripts/adr-dl1-extracted.txt` | Raw extraction; ADR-DL1 resolution captured in governance |
| `scripts/prev-audit-extracted.txt` | Raw extraction; superseded by final audit documents |
| `*.pdf` files (4) | PDF versions duplicate .md content; .md is the authoritative format |
| `*.zip` files (4) | Archives are the source material, not the package content |
| V2 archive: `02-glossary.md`, `06-business-workflows.md`, `00-documentation-audit-report.md`, `00-reconciliation-proposal.md`, `07-business-discovery-closure.md`, `08-traceability-matrix.md`, `11-domain-discovery-topic2.md`, `12-domain-discovery-topic2-revision.md`, `13-domain-discovery-consolidation.md`, `15-domain-discovery-topic4-behaviour.md` | Lower historical value; domain evolution captured by included documents |
| V1 baseline (`PRE-IMPLEMENTATION-BASELINE/`) | Entirely superseded by V2 |
| `studynexus-reconciled/` (all except PRODUCT-DISCOVERY-CHALLENGE) | Superseded by V2 |
| `STUDYNEXUS-INDEPENDENT-AUDIT-PACKAGE-V3/` (previous) | This IS the rebuild |

## Additional Artifacts Discovered and Included

1. **PRODUCT-DISCOVERY-CHALLENGE.md** (60K) — Critical competitive research document NOT in V2 baseline but essential for independent audit. Found in `studynexus-reconciled/`.
2. **FIELD-PROVENANCE-HOSTILE-REVIEW.md** (27K) — Important hostile review of field provenance architecture. Found in project root.
3. **MERGED-AUDIT-OF-STUDYNEXUS-PLAN.md** (144K) — Large merged audit document from earlier review cycle. Found in `upload/`.
4. **STUDYNEXUS-CANONICAL-REMEDIATION-REPORT.md** (15K) — Remediation report from canonical correction waves.
5. **external-identifiers-status-vs-validity.md** (23K) — Hostile review of external identifiers status vs validity semantics.

## Duplicate Handling

Where the same document exists in multiple locations (e.g., ADVERSARIAL-DECISION-REVIEW.md exists in both V2/governance/ and download/), the V2 governance version is used as the authoritative copy. Top-level download/ versions are only included if they provide unique content not in V2.
