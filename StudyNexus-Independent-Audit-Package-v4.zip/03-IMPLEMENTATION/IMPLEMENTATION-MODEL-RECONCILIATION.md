# Implementation Model Reconciliation

**Date:** 2026-03-04  
**Purpose:** Define the canonical implementation model after reconciliation — the single source of truth for what must be built.  
**Authority:** 03-domain.md governs domain concepts; 04-architecture.md governs architecture; 05-implementation.md governs implementation details not contradicting domain/architecture.

---

## 1. Entities (11) — Reconciled

### 1.1 Aggregate Roots (5)

#### Educational Institution
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | InstitutionStatus: Provisional, Operational, Suspended, Closed | 03-domain.md | Confirmed across all documents |
| **Lifecycle** | Provisional → Operational → Suspended → Closed | 03-domain.md | Confirmed |
| **Publication** | is_published (bool) + published_at (nullable timestamp) | 03-domain.md | Confirmed |
| **Children** | hasMany Programme, hasMany AdmissionPolicy, hasMany AccreditationRecord | 03-domain.md | AccreditationRecord is polymorphic (see 1.2.3) |
| **Provenance** | information_source_id (nullable FK → InformationSource) | 03-domain.md | 05 had Institution hasMany InformationSources — REVERSED |
| **Relationships** | hasMany Programme, hasMany AdmissionPolicy, hasMany AccreditationRecord, references InformationSource | 03-domain.md | Confirmed |
| **Type** | InstitutionType: University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution | 03-domain.md | 05 had 7 values with Vocational/SecondarySchool/Professional/Other — REMOVED (requires ADR if needed) |

#### Programme
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued | 03-domain.md | Confirmed |
| **Lifecycle** | Prospective → Admitting → Suspended → Discontinued | 03-domain.md | Confirmed |
| **Publication** | is_published + published_at | 03-domain.md | Confirmed |
| **Ownership** | belongsTo Institution, belongsTo Discipline (nullable) | 03-domain.md | Confirmed |
| **Children** | hasMany AdmissionPolicy, hasMany AccreditationRecord | 03-domain.md | AccreditationRecord is polymorphic (see 1.2.3) |
| **Provenance** | information_source_id (nullable FK → InformationSource) | 03-domain.md | 05 missing — ADDED |
| **Award Level** | AwardLevel enum (single column) | 03-domain.md | 05 had ProgrammeLevel + AwardType — MERGED to AwardLevel |
| **Delivery Mode** | DeliveryMode: OnCampus, Online, Hybrid | 03-domain.md | 05 had ModeOfStudy — RENAMED |

#### Scholarship
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | ScholarshipStatus: Draft, Announced, Open, Closed, Expired, Withdrawn | 03-domain.md | 05 had Active/Closed/Upcoming — REPLACED |
| **Lifecycle** | Draft → Announced → Open → Closed → Expired; Announced/Open → Withdrawn | 03-domain.md | Full lifecycle with Withdrawn side transition |
| **Publication** | is_published + published_at | 03-domain.md | Confirmed |
| **Ownership** | belongsTo ScholarshipProvider (FK: scholarship_provider_id) | 03-domain.md | 05 had polymorphic morphTo provider — SIMPLIFIED to direct FK |
| **Targets** | targets Programme (M:N), targets Institution (M:N) | 03-domain.md | Junction tables: scholarship_programme, scholarship_institution |
| **Children** | hasMany EligibilityPolicy | 03-domain.md | Confirmed |

#### Admission Cycle
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | AdmissionCycleStatus: Upcoming, Active, Closed, Archived | 03-domain.md | 05 didn't name the enum — NAMED |
| **Lifecycle** | Upcoming → Active → Closed → Archived | 03-domain.md | Confirmed |
| **Ownership** | belongsTo EducationAuthority (FK: education_authority_id) | 03-domain.md | 05 had belongsTo Institution — CHANGED |
| **Publication** | None (admission cycles are not published) | 03-domain.md | Confirmed |
| **Children** | None (AdmissionPolicy belongsTo AdmissionCycle, but is not a child in the aggregate sense) | 03-domain.md | Confirmed |

#### Information Source
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | SourceReliability: Unverified, Verified, Unreliable, Deprecated | 03-domain.md | 05 had VerificationStatus: Pending/Verified/Rejected — REPLACED |
| **Lifecycle** | Registered → Verified ↔ Unreliable; any → Deprecated (terminal) | 03-domain.md | Bidirectional Verified↔Unreliable, terminal Deprecated |
| **Ownership** | Standalone aggregate root | 03-domain.md | 05 had belongsTo Institution — ELEVATED to aggregate root |
| **Referenced by** | Institution, Programme, AdmissionPolicy (via information_source_id nullable FK) | 03-domain.md | Entities reference source, not vice versa |
| **Publication** | None | 03-domain.md | Confirmed |

### 1.2 Child Entities (3)

#### Admission Policy
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | PolicyStatus: Draft, Published, Superseded, Withdrawn | 03-domain.md | 05 missing Withdrawn — ADDED |
| **Lifecycle** | Draft → Published → Superseded → Withdrawn | 03-domain.md | Confirmed |
| **Ownership** | Polymorphic belongsTo Governable (Programme or Institution) | 03-domain.md | Confirmed |
| **Cycle** | belongsTo AdmissionCycle | 03-domain.md | Confirmed |
| **Content** | Contains AdmissionRule VOs (including SubjectCombination, QualificationThreshold) | 03-domain.md | Confirmed |
| **Provenance** | information_source_id (nullable FK → InformationSource) | 03-domain.md | 05 missing — ADDED |

#### Eligibility Policy
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Status** | PolicyStatus: Draft, Published, Superseded, Withdrawn | 03-domain.md | Same as AdmissionPolicy |
| **Lifecycle** | Draft → Published → Superseded → Withdrawn | 03-domain.md | Confirmed |
| **Ownership** | belongsTo Scholarship (FK: scholarship_id) | 03-domain.md | 05 had belongsTo AdmissionCycle — CHANGED |
| **Content** | Contains EligibilityRule VOs (including QualificationThreshold) | 03-domain.md | Confirmed |

#### Accreditation Record
| Aspect | Reconciled Position | Authority | Resolution Note |
|--------|-------------------|-----------|-----------------|
| **Nature** | Immutable after creation | 03-domain.md | Confirmed |
| **Accreditable** | Polymorphic morphTo Accreditable (Programme or Institution) via accreditable_type + accreditable_id | 03-domain.md | 05 had belongsTo Institution only — CHANGED to polymorphic |
| **Authority** | belongsTo EducationAuthority (FK: education_authority_id) | 03-domain.md | 05 had morphTo authority — SIMPLIFIED to direct FK |
| **Status** | AccreditationStatus enum: Full, Interim, Probationary, Revoked, Expired | 03-domain.md | Confirmed |

### 1.3 Supporting Entities (3)

#### Qualification
| Aspect | Reconciled Position | Authority |
|--------|-------------------|-----------|
| **Status** | QualificationStatus: Active, Deprecated | 03-domain.md |
| **Ownership** | belongsTo EducationAuthority | 03-domain.md |

#### Scholarship Provider
| Aspect | Reconciled Position | Authority |
|--------|-------------------|-----------|
| **Status** | Active/Deprecated (inherited pattern) | 03-domain.md |
| **Type** | ProviderType: Government, Corporate, NGO, Institution (no Other) | 03-domain.md |
| **Relationships** | Scholarship belongsTo ScholarshipProvider | 03-domain.md |

#### Education Authority
| Aspect | Reconciled Position | Authority |
|--------|-------------------|-----------|
| **Status** | Active/Deprecated (inherited pattern) | 03-domain.md |
| **Type** | AuthorityType: Regulatory, Accreditation, Funding, Admissions (no Other) | 03-domain.md |
| **Relationships** | hasMany AccreditationRecord, hasMany Qualification, hasMany AdmissionCycle | 03-domain.md |

---

## 2. Value Objects (28 = 12 genuine + 16 enums) — Reconciled

### 2.1 Genuine Value Objects (12)

| # | Value Object | Description | Reconciliation Note |
|---|-------------|-------------|---------------------|
| 1 | **AdmissionRule** | Structured rule within AdmissionPolicy (contains SubjectCombination, QualificationThreshold) | 05 had AdmissionRule — confirmed |
| 2 | **EligibilityRule** | Structured rule within EligibilityPolicy (contains QualificationThreshold) | 05 had EligibilityCriterion — RENAMED |
| 3 | **SubjectCombination** | Required subject groupings for admission (e.g., "Math + Physics + Chemistry") | 05 missing — ADDED |
| 4 | **QualificationThreshold** | Minimum qualification level required | 05 missing — ADDED |
| 5 | **ValidityPeriod** | Start/end date range with validation | Both documents have — confirmed |
| 6 | **TrustSignal** | Computed from SourceReliability, never stored | 05 missing — ADDED |
| 7 | **MonetaryAmount** | Amount + currency (replaces Money + ScholarshipAmount + Currency) | 05 had Money/ScholarshipAmount/Currency — MERGED |
| 8 | **Duration** | Time period (months/years/semesters) | Both documents have — confirmed |
| 9 | **Location** | Geographic location (may contain address fields, coordinates, country) | 05 had Address/Country/GeographicCoordinates — MERGED into Location |
| 10 | **AuthorityJurisdiction** | Scope of education authority's regulatory power | 05 missing — ADDED |
| 11 | **PhaseSequence** | Ordered sequence of phases within an AdmissionCycle | 05 missing — ADDED |
| 12 | **AdmissionPathway** | Pathway type + structure (VO, not bare enum) | 05 had as enum — ELEVATED to VO |

### 2.2 VOs Removed from 05 (Rejected as Standalone)

| 05 VO | Resolution | Reason |
|-------|-----------|--------|
| Address | Absorbed into Location VO | Location subsumes address fields |
| ContactInfo | Absorbed into Location VO | Contact fields are part of entity, not a standalone VO |
| Country | Absorbed into Location VO | Country is a field within Location |
| Currency | Absorbed into MonetaryAmount VO | Currency is a field within MonetaryAmount |
| GeographicCoordinates | Absorbed into Location VO | Coordinates are a field within Location |
| Money | Replaced by MonetaryAmount | Canonical name is MonetaryAmount |
| ScholarshipAmount | Replaced by MonetaryAmount | All monetary values use MonetaryAmount |
| AdmissionStatus | Computed, not a VO | 03 says admission status is computed, not a stored VO |
| EligibilityCriterion | Renamed to EligibilityRule | Canonical name is EligibilityRule |

---

## 3. Enums (16) — Reconciled with Canonical Values

| # | Enum | Canonical Values | Reconciliation Note |
|---|------|-----------------|---------------------|
| 1 | **InstitutionType** | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution | 05 had 7 values — REDUCED to canonical 4 |
| 2 | **AwardLevel** | BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma | 05 had ProgrammeLevel + AwardType — REPLACED with single AwardLevel |
| 3 | **AdmissionMode** | Cyclic, Rolling, MultipleIntake | Confirmed |
| 4 | **AccreditationStatus** | Full, Interim, Probationary, Revoked, Expired | Confirmed |
| 5 | **PolicyStatus** | Draft, Published, Superseded, Withdrawn | 05 missing Withdrawn — ADDED |
| 6 | **ProgrammeStatus** | Prospective, Admitting, Suspended, Discontinued | Confirmed |
| 7 | **ScholarshipStatus** | Draft, Announced, Open, Closed, Expired, Withdrawn | 05 had Active/Closed/Upcoming — REPLACED |
| 8 | **InstitutionStatus** | Provisional, Operational, Suspended, Closed | Confirmed |
| 9 | **SourceReliability** | Unverified, Verified, Unreliable, Deprecated | 05 had VerificationStatus: Pending/Verified/Rejected — REPLACED |
| 10 | **InformationCategory** | Official, Unofficial, Historical, Scraped | Confirmed |
| 11 | **AuthorityType** | Regulatory, Accreditation, Funding, Admissions | 05 had Other — REMOVED |
| 12 | **ProviderType** | Government, Corporate, NGO, Institution | 05 had Other — REMOVED |
| 13 | **OwnershipType** | Public, Private, PPP, Religious | Confirmed |
| 14 | **DeliveryMode** | OnCampus, Online, Hybrid | 05 had ModeOfStudy with different values — REPLACED |
| 15 | **QualificationStatus** | Active, Deprecated | Confirmed |
| 16 | **CoverageType** | Full, Partial, TuitionOnly, Stipend | Confirmed |

### Enums Added for Completeness (Derived from Lifecycle)

| # | Enum | Values | Source |
|---|------|--------|--------|
| 17 | **AdmissionCycleStatus** | Upcoming, Active, Closed, Archived | Derived from 03-domain.md AdmissionCycle lifecycle |

### Content-Layer Enums (Implementation Scope, Not Domain)

| # | Enum | Values | Scope |
|---|------|--------|-------|
| — | ContentType | Article, Guide, EducationalResource, ExamPreparation | Content model |
| — | ResourceType | ProjectTopic, SeminarTopic, ResearchMaterial, StudyResource | Content model |
| — | PrepType | PastQuestions, ExamTips, SubjectReview, StudyPack | Content model |

These content enums are valid in 05-implementation.md but are NOT part of the domain model and should be clearly labeled as content-layer concerns.

---

## 4. Domain Events (29) — Reconciled with Canonical Names

| # | Event Name | Domain Meaning | Reconciliation Note |
|---|-----------|---------------|---------------------|
| 1 | **InstitutionEstablished** | New institution created | 05 had InstitutionCreated — RENAMED |
| 2 | **InstitutionRenamed** | Institution name changed | Confirmed |
| 3 | **InstitutionSuspended** | Institution suspended from operation | 05 missing — ADDED |
| 4 | **InstitutionReactivated** | Suspended institution reactivated | 05 missing — ADDED |
| 5 | **InstitutionClosed** | Institution permanently closed | 05 missing — ADDED |
| 6 | **InstitutionsMerged** | Two or more institutions merged | 05 missing — ADDED |
| 7 | **InstitutionAccredited** | Institution received accreditation | 05 missing — ADDED |
| 8 | **InstitutionalAdmissionPolicyPublished** | Institution-level admission policy published | 05 had partial — COMPLETED |
| 9 | **ProgrammeIntroduced** | New programme created | 05 had ProgrammeCreated — RENAMED |
| 10 | **ProgrammeAdmissionPolicyPublished** | Programme-level admission policy published | 05 missing — ADDED |
| 11 | **ProgrammeAdmissionSuspended** | Programme admissions suspended | 05 missing — ADDED |
| 12 | **ProgrammeAdmissionResumed** | Programme admissions resumed | 05 missing — ADDED |
| 13 | **ProgrammeDiscontinued** | Programme discontinued | 05 missing — ADDED |
| 14 | **ProgrammeAccredited** | Programme received accreditation | 05 missing — ADDED |
| 15 | **ScholarshipAnnounced** | Scholarship announced to public | 05 had ScholarshipCreated — RENAMED |
| 16 | **ScholarshipEligibilityPolicyPublished** | Scholarship eligibility published | 05 missing — ADDED |
| 17 | **ScholarshipApplicationsOpened** | Scholarship applications opened | 05 missing — ADDED |
| 18 | **ScholarshipApplicationsClosed** | Scholarship applications closed | 05 missing — ADDED |
| 19 | **ScholarshipWithdrawn** | Scholarship withdrawn | 05 missing — ADDED |
| 20 | **ScholarshipExpired** | Scholarship expired | 05 missing — ADDED |
| 21 | **ScholarshipTargetsUpdated** | Scholarship target programmes/institutions changed | 05 missing — ADDED |
| 22 | **AdmissionCycleAnnounced** | New admission cycle announced | 05 had AdmissionCycleOpened — RENAMED |
| 23 | **AdmissionCycleActivated** | Cycle transitions from Upcoming to Active | 05 missing — ADDED |
| 24 | **AdmissionCyclePhaseAdvanced** | Cycle advances to next phase | 05 missing — ADDED |
| 25 | **AdmissionCycleClosed** | Cycle transitions to Closed | Confirmed name (05 had same) |
| 26 | **InformationSourceVerified** | Source verified as reliable | Confirmed |
| 27 | **InformationSourceMarkedUnreliable** | Source marked unreliable | 05 missing — ADDED |
| 28 | **InformationSourceDeprecated** | Source deprecated (terminal) | 05 missing — ADDED |
| 29 | **QualificationDeprecated** | Qualification deprecated | 05 missing — ADDED |

---

## 5. Actions (20) — Reconciled with Canonical Names

| # | Action | Responsibility | Reconciliation Note |
|---|--------|---------------|---------------------|
| 1 | **CreateInstitution** | Provisional institution establishment | Confirmed |
| 2 | **SuspendInstitution** | Suspend operational institution | 05 missing — ADDED |
| 3 | **CloseInstitution** | Permanently close institution | 05 missing — ADDED |
| 4 | **MergeInstitutions** | Merge two+ institutions | 05 missing — ADDED |
| 5 | **PublishAdmissionPolicy** | Publish draft admission policy | Confirmed |
| 6 | **RecordAccreditation** | Record accreditation for programme/institution | Confirmed |
| 7 | **CreateProgramme** | Introduce new programme | Confirmed |
| 8 | **DiscontinueProgramme** | Discontinue a programme | 05 missing — ADDED |
| 9 | **AnnounceScholarship** | Announce scholarship (Draft → Announced) | 05 had CreateScholarship — RENAMED |
| 10 | **OpenScholarshipApplications** | Open scholarship applications (Announced → Open) | 05 missing — ADDED |
| 11 | **ExpireScholarship** | Expire scholarship past deadline | 05 missing — ADDED |
| 12 | **TargetScholarshipProgrammes** | Update scholarship target programmes/institutions | 05 missing — ADDED |
| 13 | **AnnounceAdmissionCycle** | Announce upcoming admission cycle | 05 had OpenAdmissionCycle — RENAMED |
| 14 | **ActivateAdmissionCycle** | Activate announced cycle (Upcoming → Active) | 05 missing — ADDED |
| 15 | **AdvanceAdmissionCyclePhase** | Advance cycle to next phase | 05 missing — ADDED |
| 16 | **RegisterInformationSource** | Register new information source | 05 missing — ADDED |
| 17 | **VerifyInformationSource** | Verify source reliability | Confirmed |
| 18 | **MarkSourceUnreliable** | Mark verified source as unreliable | 05 missing — ADDED |
| 19 | **ImportInstitutionData** | Import institution data from external source | 05 missing — ADDED |
| 20 | **ExpireScholarships** | Bulk expire scholarships past deadline | 05 missing — ADDED |

### Actions Removed from 05 (Non-Canonical)

| 05 Action | Resolution | Reason |
|-----------|-----------|--------|
| UpdateInstitution | Subsumed by domain actions (SuspendInstitution, CloseInstitution, etc.) | Domain uses lifecycle transitions, not generic updates |
| PublishInstitution | Institution publication is via is_published flag, not a domain action | Implementation detail, not domain action |
| RejectInformationSource | No "Rejected" state in SourceReliability | Replaced by MarkSourceUnreliable (Verified → Unreliable) |
| UpdateProgramme | Subsumed by domain actions | Domain uses lifecycle transitions |
| PublishProgramme | Programme publication is via is_published flag | Implementation detail |
| UpdateScholarship | Subsumed by domain actions | Domain uses lifecycle transitions |
| PublishScholarship | Scholarship publication is via is_published flag | Implementation detail |
| OpenAdmissionCycle | Renamed to AnnounceAdmissionCycle | Domain-specific naming |
| CloseAdmissionCycle | Subsumed by AdvanceAdmissionCyclePhase | Cycle closure is a phase advancement |
| PublishAdmissionResults | Not in canonical model | May be infrastructure event, not domain action |
| CreateAdmissionPolicy | Subsumed by PublishAdmissionPolicy (draft→publish) | Policy creation is implicit in draft |
| UpdateAdmissionPolicy | Subsumed by PublishAdmissionPolicy | Policy updates go through draft→publish cycle |
| CreateEligibilityPolicy | Part of AnnounceScholarship flow | Eligibility policy creation is implicit |
| UpdateEligibilityPolicy | Subsumed by scholarship lifecycle | Eligibility updates go through draft→publish cycle |

---

## 6. Persistence — Reconciled Table Schemas

### 6.1 Domain Tables (12 entity tables + 3 junction tables = 15)

#### educational_institutions
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string | |
| type | InstitutionType enum | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution |
| status | InstitutionStatus enum | Provisional, Operational, Suspended, Closed |
| ownership_type | OwnershipType enum | Public, Private, PPP, Religious |
| location | json (Location VO) | Contains address, coordinates, country |
| admission_mode | AdmissionMode enum | Cyclic, Rolling, MultipleIntake |
| delivery_modes | json (array of DeliveryMode) | OnCampus, Online, Hybrid |
| is_published | boolean | |
| published_at | nullable timestamp | |
| information_source_id | nullable bigint FK → information_sources | Provenance reference |
| created_at | timestamp | |
| updated_at | timestamp | |

#### programmes
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| institution_id | bigint FK → educational_institutions | |
| discipline_id | nullable bigint FK → disciplines | |
| name | string | |
| award_level | AwardLevel enum | BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma |
| delivery_mode | DeliveryMode enum | OnCampus, Online, Hybrid |
| status | ProgrammeStatus enum | Prospective, Admitting, Suspended, Discontinued |
| duration | json (Duration VO) | |
| is_published | boolean | |
| published_at | nullable timestamp | |
| information_source_id | nullable bigint FK → information_sources | Provenance reference |
| created_at | timestamp | |
| updated_at | timestamp | |

#### scholarships
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| scholarship_provider_id | bigint FK → scholarship_providers | Direct FK, not polymorphic |
| name | string | |
| description | text | |
| amount | json (MonetaryAmount VO) | Contains amount + currency |
| coverage_type | CoverageType enum | Full, Partial, TuitionOnly, Stipend |
| status | ScholarshipStatus enum | Draft, Announced, Open, Closed, Expired, Withdrawn |
| validity_period | json (ValidityPeriod VO) | |
| is_published | boolean | |
| published_at | nullable timestamp | |
| created_at | timestamp | |
| updated_at | timestamp | |

#### admission_cycles
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| education_authority_id | bigint FK → education_authorities | NOT institution_id |
| name | string | |
| status | AdmissionCycleStatus enum | Upcoming, Active, Closed, Archived |
| phases | json (PhaseSequence VO) | Ordered phases |
| created_at | timestamp | |
| updated_at | timestamp | |

#### information_sources
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string | |
| url | nullable string | |
| category | InformationCategory enum | Official, Unofficial, Historical, Scraped |
| reliability | SourceReliability enum | Unverified, Verified, Unreliable, Deprecated |
| last_verified_at | nullable timestamp | |
| created_at | timestamp | |
| updated_at | timestamp | |

**Note:** No institution_id FK. InformationSource is standalone aggregate root.

#### admission_policies
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| governable_type | string (morph) | 'Programme' or 'EducationalInstitution' |
| governable_id | bigint (morph) | |
| admission_cycle_id | bigint FK → admission_cycles | |
| status | PolicyStatus enum | Draft, Published, Superseded, Withdrawn |
| rules | json (array of AdmissionRule VO) | Contains SubjectCombination, QualificationThreshold |
| information_source_id | nullable bigint FK → information_sources | Provenance reference |
| created_at | timestamp | |
| updated_at | timestamp | |

#### eligibility_policies
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| scholarship_id | bigint FK → scholarships | NOT admission_cycle_id |
| status | PolicyStatus enum | Draft, Published, Superseded, Withdrawn |
| rules | json (array of EligibilityRule VO) | Contains QualificationThreshold |
| created_at | timestamp | |
| updated_at | timestamp | |

#### accreditation_records
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| accreditable_type | string (morph) | 'Programme' or 'EducationalInstitution' |
| accreditable_id | bigint (morph) | |
| education_authority_id | bigint FK → education_authorities | Direct FK, not polymorphic |
| status | AccreditationStatus enum | Full, Interim, Probationary, Revoked, Expired |
| valid_from | date | |
| valid_until | date | |
| created_at | timestamp | |

#### qualifications
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| education_authority_id | bigint FK → education_authorities | |
| name | string | |
| level | string | |
| status | QualificationStatus enum | Active, Deprecated |
| created_at | timestamp | |
| updated_at | timestamp | |

#### scholarship_providers
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string | |
| type | ProviderType enum | Government, Corporate, NGO, Institution |
| status | string | Active/Deprecated |
| created_at | timestamp | |
| updated_at | timestamp | |

#### education_authorities
| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string | |
| type | AuthorityType enum | Regulatory, Accreditation, Funding, Admissions |
| jurisdiction | json (AuthorityJurisdiction VO) | |
| status | string | Active/Deprecated |
| created_at | timestamp | |
| updated_at | timestamp | |

### 6.2 Junction Tables

| Table | Columns | Purpose |
|-------|---------|---------|
| scholarship_programme | scholarship_id, programme_id | Scholarship ↔ Programme M:N |
| scholarship_institution | scholarship_id, institution_id | Scholarship ↔ Institution M:N |
| institution_information_source | institution_id, information_source_id | Institution ↔ InformationSource M:N (if multiple sources per entity needed) |

### 6.3 Non-Domain Tables (05 Scope)

The following table categories are 05-implementation.md's legitimate scope and are NOT reconciled against 03-domain.md:

- **Content tables (5):** articles, guides, educational_resources, exam_preparations, study_resources
- **Auth tables (9):** users, roles, permissions, model_has_roles, etc.
- **Engagement tables (4):** bookmarks, follows, comparisons, reviews
- **Community tables (5):** forum_threads, forum_posts, etc.
- **Notification tables (1):** notifications
- **Settings tables (3):** user_settings, institution_settings, system_settings
- **SEO tables (1):** seo_metadata
- **Infrastructure tables (9):** jobs, job_batches, failed_jobs, etc.

---

## 7. Provenance — Reconciled Model

| Aspect | Reconciled Position | Authority |
|--------|-------------------|-----------|
| **Model** | Domain entities (Institution, Programme, AdmissionPolicy) reference InformationSource via information_source_id (nullable FK) | 03-domain.md |
| **InformationSource** | Standalone aggregate root, not owned by any entity | 03-domain.md |
| **Lifecycle** | Registered → Verified ↔ Unreliable → Deprecated (terminal) | 03-domain.md |
| **TrustSignal** | Computed VO derived from SourceReliability, never stored | 03-domain.md |
| **HasProvenance trait** | May be used on content models (Article, Guide) as ADDITIONAL content-level provenance, but MUST NOT replace domain-level provenance | 05-implementation.md (subordinate) |
| **DataProvenanceFlag** | Triggered by InformationSourceDeprecated event | 03-domain.md |

---

## 8. RBAC — Confirmed 11-Role Model

| Role Type | Roles | Source |
|-----------|-------|--------|
| Platform (4) | PlatformAdmin, PlatformEditor, PlatformViewer, PlatformModerator | 02-decisions.md / 04-architecture.md / 05-implementation.md |
| Institution-scoped (5) | InstitutionAdmin, InstitutionEditor, InstitutionViewer, InstitutionModerator, InstitutionContributor | Same across all |
| User (2) | Student, Guest | Same across all |

**Implementation:** Spatie laravel-permission for global roles. OrganizationMember model for institution-scoped roles with string role column. **Consistent — no reconciliation needed.**

---

## 9. Search — Confirmed Architecture

| Aspect | Position | Source |
|--------|----------|--------|
| **Authoritative store** | PostgreSQL | 04-architecture.md |
| **Search projection** | Typesense (7 collections) | 04-architecture.md / 05-implementation.md |
| **Detail pages** | Rendered from PostgreSQL | 04-architecture.md |
| **Search results** | Served from Typesense | 04-architecture.md |
| **Index updates** | UpdateSearchIndex event listener | 03-domain.md (event) / 04-architecture.md (infrastructure) |
| **Degradation** | PostgreSQL FTS fallback | 02-decisions.md |

**Consistent — no reconciliation needed.**

---

## 10. Versioning — Confirmed Model

| Aspect | Position | Source |
|--------|----------|--------|
| **Publication** | is_published (bool) + published_at (nullable timestamp) on publishable entities | 02-decisions.md / 03-domain.md |
| **Activity log** | spatie/laravel-activitylog for change history | 04-architecture.md |
| **Policy supersession** | PolicyStatus Superseded + FK to superseding policy | 03-domain.md |

**Consistent — no reconciliation needed.**

---

## 11. Data Acquisition — Confirmed Boundary

| Aspect | Position | Source |
|--------|----------|--------|
| **Tables** | import_batches, pending_imports | 06-data-acquisition.md |
| **Pattern** | Adapter pattern for different data sources | 06-data-acquisition.md |
| **Verification** | Verification engine reviews imported data | 06-data-acquisition.md |
| **Integration** | Uses existing domain Actions (CreateInstitution, RecordAccreditation, RegisterInformationSource, VerifyInformationSource) | 06-data-acquisition.md |
| **New domain actions** | None — data acquisition does not extend the domain model | 06-data-acquisition.md |

**Consistent — no reconciliation needed.**
