# 05-implementation.md Reconciliation Proposal

**Date:** 2026-03-04  
**Purpose:** Complete change set for 05-implementation.md to achieve consistency with the canonical domain model (03-domain.md), architecture (04-architecture.md), and decisions (02-decisions.md).  
**Principle:** Every change is traced to an authority. Every classification is justified.

---

## Change Classification Legend

| Class | Meaning | Process |
|-------|---------|---------|
| **A** | Pure sync correction | Update 05 to match 03. No judgment needed. |
| **B** | Clarification | Resolve ambiguity. No fundamental disagreement. |
| **C** | Architectural decision required | Neither position clearly wrong. Needs human judgment. |
| **D** | New scope | 05 added concepts not in 03. Needs acceptance or rejection via ADR. |

---

## CRITICAL Changes (7)

### Change 1: ScholarshipStatus Enum Values

| Field | Detail |
|-------|--------|
| **Finding** | F-C01 |
| **Current in 05** | ScholarshipStatus: Active, Closed, Upcoming (3 values) |
| **Proposed Change** | ScholarshipStatus: Draft, Announced, Open, Closed, Expired, Withdrawn (6 values) |
| **Authority** | 03-domain.md |
| **Reason** | Domain model defines a 6-state lifecycle for scholarships with specific business meaning: Draft (internal), Announced (public awareness), Open (accepting applications), Closed (no longer accepting), Expired (past deadline), Withdrawn (retracted). The 3-value set in 05 collapses semantically distinct states and loses the ability to represent scholarship announcements, expiry, and withdrawal. |
| **Classification** | A |
| **Implementation Steps** | 1. Update ScholarshipStatus enum definition to 6 values. 2. Add lifecycle transition guards: Draft→Announced→Open→Closed→Expired, Announced/Open→Withdrawn. 3. Update scholarships table status column check constraint. 4. Update Scholarship model state machine methods. 5. Update any seed data or factory definitions. |

---

### Change 2: InformationSource Status — Rename and Replace Values

| Field | Detail |
|-------|--------|
| **Finding** | F-C02 |
| **Current in 05** | VerificationStatus enum: Pending, Verified, Rejected (3 values) |
| **Proposed Change** | SourceReliability enum: Unverified, Verified, Unreliable, Deprecated (4 values) |
| **Authority** | 03-domain.md |
| **Reason** | The domain model uses SourceReliability with 4 states that support the full provenance lifecycle: Unverified (initial), Verified (confirmed reliable), Unreliable (found unreliable — can transition back to Verified), Deprecated (terminal — source no longer exists or is no longer usable). The 3-value set in 05 loses the Unreliable↔Verified bidirectional transition and the Deprecated terminal state. "Rejected" conflates verification failure with source unreliability. |
| **Classification** | A |
| **Implementation Steps** | 1. Rename enum from VerificationStatus to SourceReliability. 2. Replace Pending → Unverified. 3. Replace Rejected → Unreliable (and add bidirectional transition Verified↔Unreliable). 4. Add Deprecated as terminal state (transition from any state). 5. Update information_sources table reliability column. 6. Update InformationSource model. 7. Add MarkSourceUnreliable action. 8. Add InformationSourceMarkedUnreliable and InformationSourceDeprecated events. |

---

### Change 3: EligibilityPolicy Ownership — Change belongsTo Target

| Field | Detail |
|-------|--------|
| **Finding** | F-C03 |
| **Current in 05** | EligibilityPolicy belongsTo AdmissionCycle (FK: admission_cycle_id) |
| **Proposed Change** | EligibilityPolicy belongsTo Scholarship (FK: scholarship_id) |
| **Authority** | 03-domain.md |
| **Reason** | Eligibility policies define who is eligible for a specific scholarship, not who can apply in a general admission cycle. An admission cycle has admission policies (governing who can apply to programmes); a scholarship has eligibility policies (governing who qualifies for funding). These are distinct domain concepts. |
| **Classification** | A |
| **Implementation Steps** | 1. Change EligibilityPolicy model: remove `belongsTo AdmissionCycle`, add `belongsTo Scholarship`. 2. In eligibility_policies table: drop `admission_cycle_id` column, add `scholarship_id` column. 3. Create migration for FK change. 4. Update all relationship definitions. 5. Update API routes and controllers. 6. Update factory and seeder. |

---

### Change 4: AdmissionCycle Ownership — Change belongsTo Target

| Field | Detail |
|-------|--------|
| **Finding** | F-C04 |
| **Current in 05** | AdmissionCycle belongsTo Institution (FK: institution_id) |
| **Proposed Change** | AdmissionCycle belongsTo EducationAuthority (FK: education_authority_id) |
| **Authority** | 03-domain.md |
| **Reason** | In the Nigerian education system, admission cycles are regulatory instruments issued by education authorities (e.g., JAMB announces the UTME cycle). Individual institutions then participate in these authority-governed cycles. Making cycles institution-scoped loses the regulatory relationship and the ability to model centralized admission processes. |
| **Classification** | C (significant structural change with UI implications) |
| **Implementation Steps** | 1. Change AdmissionCycle model: remove `belongsTo Institution`, add `belongsTo EducationAuthority`. 2. In admission_cycles table: drop `institution_id` column, add `education_authority_id` column. 3. Create migration. 4. Update Institution relationship: remove `hasMany AdmissionCycle` (institutions participate in cycles via admission policies, not by owning them). 5. Update EducationAuthority: add `hasMany AdmissionCycle`. 6. Update API routes, controllers, policies. 7. Update UI: admission cycles are managed by education authority admins, not institution admins. |

---

### Change 5: AccreditationRecord Ownership — Change to Polymorphic Accreditable

| Field | Detail |
|-------|--------|
| **Finding** | F-C05 |
| **Current in 05** | AccreditationRecord belongsTo Institution (FK: institution_id), morphTo authority |
| **Proposed Change** | AccreditationRecord morphTo Accreditable (Programme or Institution) via accreditable_type + accreditable_id, belongsTo EducationAuthority (FK: education_authority_id) |
| **Authority** | 03-domain.md |
| **Reason** | In the Nigerian system, both institutions and individual programmes can be accredited. Programme-level accreditation (e.g., NBTE accrediting an HND programme) is a core domain concept. Restricting accreditation to institution-level only loses programme-level accreditation tracking. |
| **Classification** | A |
| **Implementation Steps** | 1. In accreditation_records table: drop `institution_id` column, add `accreditable_type` (string) and `accreditable_id` (bigint) columns. 2. Change `morphTo authority` to `belongsTo EducationAuthority` with `education_authority_id` FK. 3. Update AccreditationRecord model: add `morphTo Accreditable`, remove `belongsTo Institution`, add `belongsTo EducationAuthority`. 4. Update Institution model: change `hasMany AccreditationRecord` to `morphMany AccreditationRecord` (as Accreditable). 5. Update Programme model: add `morphMany AccreditationRecord` (as Accreditable). 6. Update EducationAuthority model: add `hasMany AccreditationRecord`. 7. Create migration. |

---

### Change 6: InformationSource — Elevate to Standalone Aggregate Root

| Field | Detail |
|-------|--------|
| **Finding** | F-C06 |
| **Current in 05** | InformationSource belongsTo Institution (FK: institution_id on information_sources table). Institution hasMany InformationSources. |
| **Proposed Change** | InformationSource is a standalone aggregate root with no parent FK. Institution, Programme, AdmissionPolicy reference InformationSource via information_source_id (nullable FK). |
| **Authority** | 03-domain.md |
| **Reason** | A single information source (e.g., JAMB's official website) can provide data for multiple institutions and programmes. Scoping sources to institutions means the same source must be duplicated per institution, losing the ability to assess source reliability globally and creating data integrity risks. The domain model's provenance architecture depends on shared, independently-managed sources. |
| **Classification** | C (significant structural change affecting provenance architecture) |
| **Implementation Steps** | 1. In information_sources table: drop `institution_id` column. 2. In educational_institutions table: add `information_source_id` nullable FK. 3. In programmes table: add `information_source_id` nullable FK. 4. In admission_policies table: add `information_source_id` nullable FK. 4. Update InformationSource model: remove `belongsTo Institution`, make it standalone. 5. Update Institution model: remove `hasMany InformationSources`, add `belongsTo InformationSource` (or `belongsToMany` for multiple sources). 6. Add `information_source_id` to Institution, Programme, AdmissionPolicy models. 7. Create migration. 8. Update HasProvenance trait or remove it if only used for content models. 9. Ensure domain entities have provenance FK even if content models also use HasProvenance. |

---

### Change 7: Action Inventory — Replace with Canonical 20 Actions

| Field | Detail |
|-------|--------|
| **Finding** | F-C07 |
| **Current in 05** | 20 Actions: CreateInstitution, UpdateInstitution, PublishInstitution, VerifyInformationSource, RejectInformationSource, CreateProgramme, UpdateProgramme, PublishProgramme, CreateScholarship, UpdateScholarship, PublishScholarship, OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults, CreateAdmissionPolicy, UpdateAdmissionPolicy, PublishAdmissionPolicy, CreateEligibilityPolicy, UpdateEligibilityPolicy, RecordAccreditation |
| **Proposed Change** | 20 Canonical Actions: CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, PublishAdmissionPolicy, RecordAccreditation, CreateProgramme, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships |
| **Authority** | 03-domain.md |
| **Reason** | The domain model defines domain-significant actions that reflect business operations (suspend, close, merge, announce, expire, withdraw). The 05 actions use generic CRUD-style operations (Update, Publish) that don't enforce lifecycle constraints and don't capture domain intent. For example, "UpdateInstitution" could violate invariants that "SuspendInstitution" explicitly guards. |
| **Classification** | A |
| **Implementation Steps** | 1. Remove 14 non-canonical actions from 05. 2. Add 15 missing canonical actions. 3. Keep 6 overlapping actions (CreateInstitution, CreateProgramme, VerifyInformationSource, PublishAdmissionPolicy, RecordAccreditation — with name adjustments). 4. Rename: CreateScholarship → AnnounceScholarship, OpenAdmissionCycle → AnnounceAdmissionCycle. 5. For each new action, implement: command class, handler, preconditions, effects, domain event emission. 6. Update route definitions. 7. Update controller methods. 8. Update policy classes. |

---

## HIGH Changes (14)

### Change 8: InstitutionType Enum — Restore Canonical 4 Values

| Field | Detail |
|-------|--------|
| **Finding** | F-H01 |
| **Current in 05** | InstitutionType: University, Polytechnic, CollegeOfEducation, Vocational, SecondarySchool, Professional, Other (7 values) |
| **Proposed Change** | InstitutionType: University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution (4 values) |
| **Authority** | 03-domain.md |
| **Reason** | The 4-value set is Nigeria-specific and domain-correct. InnovationEnterpriseInstitution (IEI) is a recognized Nigerian institution type. Vocational, SecondarySchool, Professional are outside the current domain scope. "Other" is an anti-pattern that prevents type-safe handling. |
| **Classification** | A + D (A for removing Other and restoring InnovationEnterpriseInstitution; D for removing Vocational/SecondarySchool/Professional — if these are needed, propose via ADR) |
| **Implementation Steps** | 1. Update InstitutionType enum to 4 canonical values. 2. Restore InnovationEnterpriseInstitution. 3. Remove Vocational, SecondarySchool, Professional, Other. 4. Update institutions table type column constraint. 5. If Vocational/SecondarySchool/Professional are business-required, create ADR-019 to add them to 03-domain.md first. |

---

### Change 9: Replace ProgrammeLevel + AwardType with AwardLevel

| Field | Detail |
|-------|--------|
| **Finding** | F-H02 |
| **Current in 05** | ProgrammeLevel: Undergraduate, Postgraduate, Doctorate, Diploma, Certificate, Foundation. AwardType: Degree, Diploma, Certificate, PhD, Masters, Bachelors. |
| **Proposed Change** | AwardLevel: BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma (single enum, 10 values) |
| **Authority** | 03-domain.md |
| **Reason** | The Nigeria-specific nomenclature (ND = National Diploma, HND = Higher National Diploma, NCE = Nigeria Certificate in Education) is domain-correct and intentional. Generic terms like "Undergraduate" and "Bachelors" lose this specificity. A single enum is simpler and matches the domain model. |
| **Classification** | A |
| **Implementation Steps** | 1. Remove ProgrammeLevel enum. 2. Remove AwardType enum. 3. Create AwardLevel enum with 10 canonical values. 4. In programmes table: drop `programme_level` and `award_type` columns, add `award_level` column. 5. Update Programme model. 6. Create migration. 7. Update factories, seeders, API resources. |

---

### Change 10: Replace ModeOfStudy with DeliveryMode

| Field | Detail |
|-------|--------|
| **Finding** | F-H03 |
| **Current in 05** | ModeOfStudy: FullTime, PartTime, Online, Distance, Hybrid (5 values) |
| **Proposed Change** | DeliveryMode: OnCampus, Online, Hybrid (3 values) |
| **Authority** | 03-domain.md |
| **Reason** | DeliveryMode is the canonical name. FullTime/PartTime are scheduling concepts orthogonal to delivery mode (a programme can be OnCampus+FullTime or OnCampus+PartTime). If scheduling mode is needed, it should be a separate enum proposed via ADR. |
| **Classification** | A + D (A for naming; D for FullTime/PartTime/Distance — if needed, propose as separate StudySchedule enum via ADR) |
| **Implementation Steps** | 1. Rename ModeOfStudy → DeliveryMode. 2. Replace values with OnCampus, Online, Hybrid. 3. Update programmes table column. 4. If FullTime/PartTime scheduling is needed, create ADR-020 for a separate StudySchedule enum. |

---

### Change 11: Add Withdrawn to PolicyStatus

| Field | Detail |
|-------|--------|
| **Finding** | F-H04 |
| **Current in 05** | PolicyStatus: Draft, Published, Superseded (3 values) |
| **Proposed Change** | PolicyStatus: Draft, Published, Superseded, Withdrawn (4 values) |
| **Authority** | 03-domain.md |
| **Reason** | Withdrawn is a distinct domain state — a policy can be withdrawn after publication (e.g., due to regulatory change), which is different from being superseded by a new version. Without Withdrawn, there's no way to represent a policy that's been retracted without replacement. |
| **Classification** | A |
| **Implementation Steps** | 1. Add Withdrawn to PolicyStatus enum. 2. Add Published→Withdrawn transition. 3. Update admission_policies and eligibility_policies tables status column constraint. 4. Add WithdrawAdmissionPolicy action (if needed as separate from PublishAdmissionPolicy). |

---

### Change 12: Elevate AdmissionPathway from Enum to Value Object

| Field | Detail |
|-------|--------|
| **Finding** | F-H05 |
| **Current in 05** | AdmissionPathway as bare enum: UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel, UCAS, CommonApp, Other |
| **Proposed Change** | AdmissionPathway as Value Object containing pathway type (enum field) plus optional structure (requirements, authority). Pathway type values: UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel. |
| **Authority** | 03-domain.md |
| **Reason** | 03 explicitly demoted AdmissionPathway from entity to VO (not to bare enum), meaning it should carry structure beyond a label. The enum values UTME/PostUTME/DirectEntry/JUPEB/CambridgeALevel are Nigeria-specific and acceptable. UCAS and CommonApp are international and require ADR. "Other" is an anti-pattern. |
| **Classification** | B |
| **Implementation Steps** | 1. Convert AdmissionPathway from enum to VO class. 2. Add internal enum field for pathway type with canonical values. 3. Add optional fields: requirements (array), authority (string), description (string). 4. Remove UCAS, CommonApp from canonical values (propose via ADR if needed). 5. Remove Other. 6. Update admission_rules JSON structure to use AdmissionPathway VO. |

---

### Change 13: Remove Other from ProviderType

| Field | Detail |
|-------|--------|
| **Finding** | F-H06 |
| **Current in 05** | ProviderType: Government, Corporate, NGO, Institution, Other |
| **Proposed Change** | ProviderType: Government, Corporate, NGO, Institution |
| **Authority** | 03-domain.md |
| **Reason** | "Other" prevents type-safe handling and should be replaced by explicit values if new provider types emerge. |
| **Classification** | A |
| **Implementation Steps** | 1. Remove Other from ProviderType enum. 2. Update scholarship_providers table type column constraint. 3. Migrate any existing "Other" records to the most appropriate explicit type. |

---

### Change 14: Remove Other from AuthorityType

| Field | Detail |
|-------|--------|
| **Finding** | F-H07 |
| **Current in 05** | AuthorityType: Regulatory, Accreditation, Funding, Admissions, Other |
| **Proposed Change** | AuthorityType: Regulatory, Accreditation, Funding, Admissions |
| **Authority** | 03-domain.md |
| **Reason** | Same as Change 13 — "Other" is an anti-pattern. |
| **Classification** | A |
| **Implementation Steps** | 1. Remove Other from AuthorityType enum. 2. Update education_authorities table type column constraint. 3. Migrate any existing "Other" records. |

---

### Change 15: Replace 05 VO Inventory with Canonical 12 VOs

| Field | Detail |
|-------|--------|
| **Finding** | F-H08 |
| **Current in 05** | 12 VOs: Address, AdmissionRule, AdmissionStatus, ContactInfo, Country, Currency, Duration, EligibilityCriterion, GeographicCoordinates, Money, ScholarshipAmount, ValidityPeriod |
| **Proposed Change** | 12 VOs: AdmissionRule, EligibilityRule, SubjectCombination, QualificationThreshold, ValidityPeriod, TrustSignal, MonetaryAmount, Duration, Location, AuthorityJurisdiction, PhaseSequence, AdmissionPathway |
| **Authority** | 03-domain.md |
| **Reason** | The canonical VO inventory is domain-correct. 05's inventory has naming mismatches (EligibilityCriterion→EligibilityRule, Address→Location, Money→MonetaryAmount), missing domain VOs (SubjectCombination, QualificationThreshold, TrustSignal, AuthorityJurisdiction, PhaseSequence), and extra VOs that should be absorbed (ContactInfo→Location, Country→Location, GeographicCoordinates→Location, Currency→MonetaryAmount, ScholarshipAmount→MonetaryAmount, AdmissionStatus→computed, not VO). |
| **Classification** | A |
| **Implementation Steps** | See Changes 16-22 for individual VO changes. |

---

### Change 16: Replace 05 Event Inventory with Canonical 29 Events

| Field | Detail |
|-------|--------|
| **Finding** | F-H09 |
| **Current in 05** | 12 named events + ~17 "others" |
| **Proposed Change** | 29 specifically named events per 03-domain.md |
| **Authority** | 03-domain.md |
| **Reason** | Domain events must have specific names that capture domain intent. "Others" is insufficient for event-driven architecture where consumers subscribe to specific events. |
| **Classification** | A |
| **Implementation Steps** | 1. List all 29 canonical events in 05. 2. Create event classes for each. 3. Map each event to the action that emits it. 4. Remove non-canonical events or move to infrastructure namespace. |

---

### Change 17: Change Scholarship Provider to Direct FK

| Field | Detail |
|-------|--------|
| **Finding** | F-H10 |
| **Current in 05** | Scholarship morphTo provider (polymorphic: ScholarshipProvider or Institution) |
| **Proposed Change** | Scholarship belongsTo ScholarshipProvider (FK: scholarship_provider_id) |
| **Authority** | 03-domain.md |
| **Reason** | ScholarshipProvider is a dedicated entity. If institutions can offer scholarships, they are represented as ScholarshipProvider records with provider_type = Institution. Polymorphic adds complexity without domain benefit. |
| **Classification** | C (if polymorphic was a deliberate design choice, it must be proposed via ADR) |
| **Implementation Steps** | 1. In scholarships table: drop `provider_type` and `provider_id` columns, add `scholarship_provider_id` FK. 2. Update Scholarship model: remove `morphTo provider`, add `belongsTo ScholarshipProvider`. 3. When an institution offers a scholarship directly, create a ScholarshipProvider record with type = Institution and link to the institution. 4. Create migration. |

---

### Change 18: Rename Address VO to Location

| Field | Detail |
|-------|--------|
| **Finding** | F-H11 |
| **Current in 05** | Address VO (with ContactInfo, Country, GeographicCoordinates as separate VOs) |
| **Proposed Change** | Location VO (absorbing address fields, contact info, country, geographic coordinates) |
| **Authority** | 03-domain.md |
| **Reason** | Location is the canonical name. Address/ContactInfo/Country/GeographicCoordinates are all aspects of location and should be composed within a single VO rather than scattered as separate VOs. |
| **Classification** | A |
| **Implementation Steps** | 1. Create Location VO class. 2. Include fields: street_address, city, state, country, postal_code, latitude, longitude, phone, email, website. 3. Replace Address, ContactInfo, Country, GeographicCoordinates VOs with Location. 4. Update institutions table location column to use Location VO JSON structure. 5. Remove Address, ContactInfo, Country, GeographicCoordinates VO classes. |

---

### Change 19: Replace Money + ScholarshipAmount + Currency with MonetaryAmount

| Field | Detail |
|-------|--------|
| **Finding** | F-H12 |
| **Current in 05** | Money VO, ScholarshipAmount VO, Currency VO |
| **Proposed Change** | MonetaryAmount VO (containing amount + currency_code) |
| **Authority** | 03-domain.md |
| **Reason** | MonetaryAmount is the canonical name for all monetary values. Currency is a field within MonetaryAmount, not a standalone VO. ScholarshipAmount is redundant — all scholarship amounts are MonetaryAmount. |
| **Classification** | A |
| **Implementation Steps** | 1. Create MonetaryAmount VO class with fields: amount (decimal), currency_code (string, ISO 4217). 2. Replace Money and ScholarshipAmount with MonetaryAmount. 3. Update scholarships.amount column to MonetaryAmount JSON. 4. Remove Money, ScholarshipAmount, Currency VO classes. |

---

### Change 20: Add 5 Missing VOs

| Field | Detail |
|-------|--------|
| **Finding** | F-H13 |
| **Current in 05** | SubjectCombination, QualificationThreshold, TrustSignal, AuthorityJurisdiction, PhaseSequence missing |
| **Proposed Change** | Add all 5 VOs |
| **Authority** | 03-domain.md |
| **Reason** | Each is a distinct domain concept: SubjectCombination (Nigerian UTME subject groupings), QualificationThreshold (minimum entry requirements), TrustSignal (computed source reliability score), AuthorityJurisdiction (authority's regulatory scope), PhaseSequence (ordered admission cycle phases). |
| **Classification** | A |
| **Implementation Steps** | 1. Create SubjectCombination VO: subjects (array of subject codes), combination_name (string). 2. Create QualificationThreshold VO: minimum_score (decimal), qualification_id (FK), description (string). 3. Create TrustSignal VO: score (computed decimal 0-1), source_reliability (SourceReliability), last_verified (timestamp). Add compute method on InformationSource. 4. Create AuthorityJurisdiction VO: scope (string), regions (array), programme_types (array). 5. Create PhaseSequence VO: phases (ordered array of Phase VOs with name, start_date, end_date). 6. Update admission_rules, eligibility_rules JSON to use SubjectCombination and QualificationThreshold. 7. Update admission_cycles.phases to use PhaseSequence. 8. Update education_authorities.jurisdiction to use AuthorityJurisdiction. |

---

### Change 21: Resolve 5 New VOs in 05

| Field | Detail |
|-------|--------|
| **Finding** | F-H14 |
| **Current in 05** | ContactInfo, Country, GeographicCoordinates, AdmissionStatus, EligibilityCriterion |
| **Proposed Change** | Absorb into canonical VOs or remove |
| **Authority** | 03-domain.md |
| **Reason** | ContactInfo → absorbed into Location. Country → absorbed into Location. GeographicCoordinates → absorbed into Location. AdmissionStatus → computed, not a VO. EligibilityCriterion → renamed to EligibilityRule. |
| **Classification** | D |
| **Implementation Steps** | See Change 18 for Location absorption. See Change 15 for EligibilityCriterion→EligibilityRule. Remove AdmissionStatus as standalone VO; implement as computed method on Admission model. |

---

## MEDIUM Changes (18)

### Change 22: Rename EligibilityCriterion to EligibilityRule

| Field | Detail |
|-------|--------|
| **Finding** | F-M01 |
| **Current in 05** | EligibilityCriterion VO |
| **Proposed Change** | EligibilityRule VO |
| **Authority** | 03-domain.md |
| **Reason** | Canonical name is EligibilityRule. "Rule" is more domain-expressive than "Criterion" (a rule can contain multiple criteria). |
| **Classification** | A |
| **Implementation Steps** | 1. Rename EligibilityCriterion class to EligibilityRule. 2. Update all references. 3. Update eligibility_policies.rules JSON structure. |

---

### Change 23: (Duplicate of Change 11 — PolicyStatus Withdrawn at entity level)
*Resolved by Change 11.*

---

### Change 24: Document Content Enums as Non-Domain

| Field | Detail |
|-------|--------|
| **Finding** | F-M03 |
| **Current in 05** | ContentType, ResourceType, PrepType enums mixed with domain enums |
| **Proposed Change** | Clearly separate content-layer enums from domain enums in 05 documentation and code |
| **Authority** | 05-implementation.md (implementation scope) |
| **Reason** | These are valid content model concepts but are NOT part of the domain model. They should be documented as such to prevent confusion. |
| **Classification** | D |
| **Implementation Steps** | 1. In 05-implementation.md, add a "Content-Layer Enums" section separate from "Domain Enums". 2. In code, place content enums in `App\Enums\Content` namespace, domain enums in `App\Enums\Domain` namespace. |

---

### Change 25: Replace ProgrammeLevel + AwardType Columns with AwardLevel Column

| Field | Detail |
|-------|--------|
| **Finding** | F-M04 |
| **Current in 05** | programmes table has programme_level and award_type columns |
| **Proposed Change** | programmes table has award_level column (single AwardLevel enum) |
| **Authority** | 03-domain.md |
| **Reason** | Follows from Change 9. |
| **Classification** | A |
| **Implementation Steps** | See Change 9. |

---

### Change 26: Validate cut_off_marks.source_id FK Semantics

| Field | Detail |
|-------|--------|
| **Finding** | F-M05 |
| **Current in 05** | cut_off_marks.source_id FK exists, pointing to information_sources |
| **Proposed Change** | Keep as-is (valid once F-C06 is resolved) |
| **Authority** | 03-domain.md |
| **Reason** | cut_off_marks referencing InformationSource is correct domain provenance. Once InformationSource is standalone (Change 6), this FK works correctly. |
| **Classification** | B |
| **Implementation Steps** | No immediate change. Validate after Change 6 is applied. |

---

### Change 27: Add Domain Provenance (information_source_id FKs)

| Field | Detail |
|-------|--------|
| **Finding** | F-M06 |
| **Current in 05** | HasProvenance trait on content models (Article, Guide) only. Domain entities lack provenance. |
| **Proposed Change** | Add information_source_id (nullable FK) to institutions, programmes, admission_policies tables. Keep HasProvenance on content models as additional feature. |
| **Authority** | 03-domain.md |
| **Reason** | Domain provenance is a core architectural requirement — every piece of institution/programme/policy data must be traceable to its source. |
| **Classification** | A |
| **Implementation Steps** | 1. Add information_source_id column to educational_institutions table. 2. Add information_source_id column to programmes table. 3. Add information_source_id column to admission_policies table. 4. Create migration. 5. Update Eloquent models with belongsTo InformationSource relationship. 6. Keep HasProvenance on content models as-is. |

---

### Change 28: Reverse InformationSource FK Direction

| Field | Detail |
|-------|--------|
| **Finding** | F-M07 |
| **Current in 05** | information_sources table has institution_id FK |
| **Proposed Change** | Remove institution_id from information_sources. Add information_source_id to institutions, programmes, admission_policies. |
| **Authority** | 03-domain.md |
| **Reason** | Follows from Change 6. |
| **Classification** | A |
| **Implementation Steps** | See Change 6 and Change 27. |

---

### Change 29: Document Table Scope Separation

| Field | Detail |
|-------|--------|
| **Finding** | F-M08 |
| **Current in 05** | 56 tables without clear domain vs. implementation separation |
| **Proposed Change** | In 05 documentation, clearly separate domain tables (15) from implementation tables (41) |
| **Authority** | 05-implementation.md |
| **Reason** | Makes it clear which tables must match 03-domain.md and which are implementation-only. |
| **Classification** | B |
| **Implementation Steps** | 1. In 05-implementation.md, restructure table listing: "Domain Tables" (must match 03), "Auth Tables" (must match 04 RBAC), "Content Tables" (implementation scope), "Infrastructure Tables" (implementation scope). 2. Add note: "Domain tables are governed by 03-domain.md. Implementation tables are governed by this document." |

---

### Change 30: Verify Domain Table-Entity Correspondence

| Field | Detail |
|-------|--------|
| **Finding** | F-M09 |
| **Current in 05** | 12 domain tables for 11 entities |
| **Proposed Change** | Document the 12th table as a junction table and verify all 11 entity tables exist |
| **Authority** | Both |
| **Reason** | Need to confirm 1:1 mapping for entities and identify junction tables. |
| **Classification** | B |
| **Implementation Steps** | 1. List all 12 domain tables. 2. Map each to a canonical entity or M:N relationship. 3. Document any missing entity tables or extra tables. |

---

### Change 31: Replace Polymorphic Provider with FK

| Field | Detail |
|-------|--------|
| **Finding** | F-M10 |
| **Current in 05** | scholarships table has provider_type + provider_id |
| **Proposed Change** | scholarships table has scholarship_provider_id FK |
| **Authority** | 03-domain.md |
| **Reason** | Follows from Change 17. |
| **Classification** | A |
| **Implementation Steps** | See Change 17. |

---

### Change 32: Replace AccreditationRecord morphTo authority with belongsTo EducationAuthority

| Field | Detail |
|-------|--------|
| **Finding** | F-M11 |
| **Current in 05** | AccreditationRecord morphTo authority (polymorphic) |
| **Proposed Change** | AccreditationRecord belongsTo EducationAuthority (FK: education_authority_id) |
| **Authority** | 03-domain.md |
| **Reason** | EducationAuthority is the only authority type in the domain. Polymorphic adds unnecessary complexity. If future authority types are needed, this can be revisited via ADR. |
| **Classification** | C |
| **Implementation Steps** | 1. In accreditation_records table: drop `authority_type` and `authority_id` columns, add `education_authority_id` FK. 2. Update AccreditationRecord model: remove `morphTo authority`, add `belongsTo EducationAuthority`. 3. Create migration. |

---

### Change 33: Remove Institution hasMany InformationSources

| Field | Detail |
|-------|--------|
| **Finding** | F-M12 |
| **Current in 05** | Institution hasMany InformationSources |
| **Proposed Change** | Institution references InformationSource via information_source_id |
| **Authority** | 03-domain.md |
| **Reason** | Follows from Change 6. |
| **Classification** | A |
| **Implementation Steps** | See Change 6. |

---

### Change 34: Document OrganizationMember as Infrastructure

| Field | Detail |
|-------|--------|
| **Finding** | F-M13 |
| **Current in 05** | Institution morphMany OrganizationMember (relationship exists but scope unclear) |
| **Proposed Change** | Document OrganizationMember as infrastructure/RBAC concern, not domain entity |
| **Authority** | 04-architecture.md |
| **Reason** | OrganizationMember is part of the RBAC implementation, not the domain model. It's valid but should be clearly scoped. |
| **Classification** | D |
| **Implementation Steps** | 1. In 05-implementation.md, list OrganizationMember under "Auth/RBAC Tables" not "Domain Tables". 2. Add note: "OrganizationMember is an infrastructure model for institution-scoped roles per 04-architecture.md RBAC model." |

---

### Change 35: Adopt Canonical Event Naming Convention

| Field | Detail |
|-------|--------|
| **Finding** | F-M14 |
| **Current in 05** | Mixed naming: InstitutionCreated, ScholarshipCreated, AdmissionCycleOpened |
| **Proposed Change** | Domain-specific past-tense: InstitutionEstablished, ScholarshipAnnounced, AdmissionCycleAnnounced |
| **Authority** | 03-domain.md |
| **Reason** | Domain events should use domain-specific language, not generic CRUD terms. "Established" captures the domain meaning of creating an institution better than "Created". |
| **Classification** | A |
| **Implementation Steps** | See Change 16. |

---

### Changes 36-39: Add Missing VOs (TrustSignal, PhaseSequence, SubjectCombination, QualificationThreshold)

These are subsumed by Change 20. No separate implementation steps needed.

---

## Change Summary

| Severity | Changes | Class A | Class B | Class C | Class D |
|----------|---------|---------|---------|---------|---------|
| CRITICAL | 7 | 5 | 0 | 2 | 0 |
| HIGH | 14 | 8 | 1 | 1 | 4 |
| MEDIUM | 18 | 7 | 3 | 1 | 2 |
| LOW | 6 | 2 | 1 | 0 | 2 |
| **Total** | **45** | **22** | **5** | **4** | **8** |

## Execution Priority

Changes must be applied in dependency order:

### Phase 1: Foundational Entity Changes (must be first)
1. **Change 6** (InformationSource standalone) — unblocks Changes 27, 28, 33
2. **Change 4** (AdmissionCycle → EducationAuthority) — unblocks related schema
3. **Change 5** (AccreditationRecord polymorphic) — unblocks related schema
4. **Change 3** (EligibilityPolicy → Scholarship) — unblocks related schema
5. **Change 17** (Scholarship direct FK provider) — unblocks Change 31

### Phase 2: Enum and VO Changes (depend on Phase 1)
6. **Change 1** (ScholarshipStatus)
7. **Change 2** (SourceReliability)
8. **Change 8** (InstitutionType)
9. **Change 9** (AwardLevel)
10. **Change 10** (DeliveryMode)
11. **Change 11** (PolicyStatus + Withdrawn)
12. **Change 12** (AdmissionPathway VO)
13. **Change 13** (ProviderType - Other)
14. **Change 14** (AuthorityType - Other)
15. **Change 18** (Location VO)
16. **Change 19** (MonetaryAmount VO)
17. **Change 20** (Missing VOs)
18. **Change 21** (Resolve new VOs)
19. **Change 22** (EligibilityRule naming)

### Phase 3: Action and Event Changes (depend on Phase 2)
20. **Change 7** (Canonical 20 Actions)
21. **Change 16** (Canonical 29 Events)

### Phase 4: Schema and Documentation Changes (depend on Phase 3)
22. **Change 27** (Domain provenance FKs)
23. **Change 28** (Reverse InformationSource FK)
24. **Change 29** (Table scope separation)
25. **Change 30** (Table-entity correspondence)
26. **Change 32** (AccreditationRecord authority FK)
27. **Change 34** (OrganizationMember documentation)
28. **Change 35** (Event naming)
29. **Change 24** (Content enum separation)
30. **Change 26** (cut_off_marks validation)
