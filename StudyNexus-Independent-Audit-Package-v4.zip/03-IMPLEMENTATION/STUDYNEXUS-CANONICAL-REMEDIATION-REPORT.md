# StudyNexus Canonical Remediation Report

**Date:** 2026-08-18
**Trigger:** Two independent adversarial audits of V3 Audit Package identified critical internal inconsistencies
**Verdict:** REMEDIATED — All BLOCKER and HIGH issues resolved

---

## Executive Summary

Two independent audits (initial + deep-dive) identified 5 categories of critical issues in the StudyNexus canonical documentation. After independent verification of each claim against the actual source documents, surgical remediation was performed on the canonical files.

**Result:** All verified BLOCKER contradictions have been resolved. The canonical documents are now internally consistent. The V2 baseline has been updated (not merely the audit package).

---

## Claim Verification Matrix

| Claim | Source | Verified? | Actual Finding | Action Taken |
|-------|--------|-----------|----------------|--------------|
| 05-impl contradicts 03-domain on enums/VOs/events/Actions | Both audits | ✅ VERIFIED SEVERE | 7 missing enums, 10/12 mismatched VOs, completely different Actions | Surgical alignment of 05-implementation.md |
| ADR-6 vs Typesense contradiction | Both audits | ✅ VERIFIED REAL | ADR-6 says PostgreSQL FTS for MVP; arch+impl have Typesense as core | Aligned architecture+implementation with ADR-6 |
| Programme vs ProgrammeInstance gap | Both audits | ✅ VERIFIED (design gap) | Single Programme entity conflates template with offering | Added ProgrammeInstance + Campus entities |
| Campus entity missing | Both audits | ✅ VERIFIED (design gap) | No Campus entity; Institution has single Location | Added Campus entity with Location VO |
| External Identifiers need polymorphic table | Deep-dive audit | ❌ NOT VERIFIED | Already implemented as BD-5/ADR-21 polymorphic table | No change needed |
| Consistency audit falsely claims CONSISTENT | Deep-dive audit | ✅ VERIFIED | Original audit marked all rows CONSISTENT despite mismatches | Updated to show remediation status |
| Discovery Closure claims "12 B-class" | Deep-dive audit | ❌ NOT VERIFIED | No such claim exists; actual is 6A+9B+3C=18 | No change needed |
| Visibility contradiction (discontinued programmes) | Deep-dive audit | ✅ VERIFIED | Architecture says never visible; UX says accessible via URL | Resolved: search-invisible + URL-accessible |
| Package arithmetic wrong | Deep-dive audit | ✅ VERIFIED | 6+4+10+21+3≠54; archive is 31 not 21 | Fixed PACKAGE-SCOPE.md |
| "all 31 archive included" false | Deep-dive audit | ✅ VERIFIED | 2 missing: 08-traceability-matrix.md, VERIFICATION-REPORT.md | Fixed claim to "29 of 31" |
| IBASS undefined | Deep-dive audit | ✅ VERIFIED | Only appears once in README; canonical doc uses WAEC/NECO/NABTEB | Fixed to match canonical |
| "20/20" misleading | Deep-dive audit | ✅ VERIFIED | Only 20 of 54 V2 files verified; 34 archive/meta unchecked | Clarified to "20/20 non-historical" |

---

## Remediation Details

### FIX 1: Align 05-implementation.md with 03-domain.md (BLOCKER)

**Problem:** The implementation blueprint (05-implementation.md) directly contradicted the canonical domain model (03-domain.md) on enums, Value Objects, domain events, and Actions. A developer reading only 05-implementation.md would build the wrong system.

**Changes to 05-implementation.md:**

| Area | Before | After | Edits |
|------|--------|-------|-------|
| Enums | 17 listed (claimed 16), 8 non-canonical | 16 canonical from 03-domain.md | Enum table replaced |
| Value Objects | 12 VOs, only 2 matched 03-domain | 12 canonical VOs from 03-domain.md | VO table replaced |
| Domain Events | Inline examples with non-canonical naming | Full 29-event table with canonical naming | Event section replaced |
| Actions | 20 Actions, only 2 matched 03-domain | 20 canonical Actions from 03-domain.md | Actions table replaced |
| Programme schema | level/award_type/mode_of_study | award_level/delivery_mode/admission_mode | Schema aligned |
| Institution schema | Missing ownership_type, registration_identifier | Both added | Schema aligned |
| InformationSource | verification_status (VerificationStatus) | reliability (SourceReliability) + category (InformationCategory) | Schema aligned |
| AccreditationRecord | Unnamed status enum | AccreditationStatus enum | Schema aligned |
| Qualification | Inline Active/Deprecated | QualificationStatus enum | Schema aligned |
| AdmissionCycle | Open/Closed status | Upcoming/Active/Closed/Archived | Schema aligned |

**Source authority:** 03-domain.md (TIER 1 canonical)

### FIX 2: Resolve ADR-6 Search Architecture Violation (BLOCKER)

**Problem:** ADR-6 (02-decisions.md) mandates PostgreSQL FTS for MVP with Typesense deferred until latency threshold. 04-architecture.md and 05-implementation.md had Typesense as core MVP — a direct contradiction of a formally Accepted ADR.

**Resolution direction:** Aligned architecture and implementation with ADR-6 (per user instruction).

**Changes to 04-architecture.md (14 edits):**
- Stack summary: Typesense → PostgreSQL FTS (MVP) → Typesense (post-MVP per ADR-6)
- P9 principle: Expanded with ADR-6 deferral conditions
- MVP lock: Changed from "Typesense is the serving layer" to "PostgreSQL FTS is the sole MVP search engine"
- Added new PostgreSQL FTS Implementation section (tsvector, GIN, pg_trgm, Scout database driver)
- Typesense collections: Marked as "Post-MVP Design per ADR-6"
- All search references updated to PostgreSQL FTS for MVP

**Changes to 05-implementation.md (13 edits):**
- Phase 1f: Search (Typesense) → Search (PostgreSQL FTS)
- Added Phase 4a: Typesense Migration (ADR-6) triggered by latency threshold
- Section 8 restructured: 8.0 MVP Search (PostgreSQL FTS), 8.1 Post-MVP (Typesense)
- Core stack: Typesense marked "deferred per ADR-06; post-MVP only"
- Scout: database driver for MVP, Typesense driver post-MVP

**No changes to 02-decisions.md** — ADR-6 is already correct and authoritative.

**Source authority:** ADR-6 in 02-decisions.md (TIER 1 canonical)

### FIX 3: Add ProgrammeInstance + Campus Entities (BLOCKER — Design Addition)

**Problem:** The domain model conflates the abstract programme template (e.g., "BSc Computer Science") with the concrete offering (specific campus, delivery mode, academic year). There's no Campus entity for multi-campus institutions.

**Resolution:** Added ProgrammeInstance (child entity of Programme) and Campus (supporting entity of Institution).

**Changes to 03-domain.md (26 edits):**
- Entity Register: 11 → 13 entities
- Added ProgrammeInstance as child entity #4 (INV-PI1, INV-PI2)
- Added Campus as supporting entity #4 (CampusStatus, is_primary, INV-CAMP1)
- Added CampusStatus enum (Active, Inactive, Planned) — enum count 16 → 17
- Programme: Removed deliveryMode (moved to ProgrammeInstance), default status → Prospective
- Institution: Added hasMany Campuses, Location moved to Campus
- Added entity relationships, invariants, and behaviour descriptions

**Changes to 05-implementation.md (22 edits):**
- Added programme_instances and campuses table schemas
- Updated all entity/enum/table counts throughout
- Institutions: Location columns moved to campuses
- Programmes: delivery_mode removed, hasMany ProgrammeInstances added
- Added CampusStatus to enum list
- Migration dependencies updated

**Changes to 04-architecture.md (9 edits):**
- Entity counts: 11 → 13, Enums 16 → 17, Tables 58 → 60
- Added ProgrammeInstance.php and Campus.php to domain models
- Added "campus" to faceted search
- Added ProgrammeInstanceResource + CampusResource to Filament

**Count impact:**

| Metric | Before | After |
|--------|--------|-------|
| Entities | 11 | 13 |
| Child entities | 3 | 4 |
| Supporting entities | 3 | 4 |
| Enums | 16 | 17 |
| Tables | 58 | 60 |

**Source authority:** Verified domain model gap; user-specified design addition

### FIX 4: Fix Governance + Visibility Contradiction (HIGH)

**4a. CANONICAL-CONSISTENCY-AUDIT.md:**
- Status: CONSISTENT → REMEDIATED — consistency restored via canonical alignment
- Added §0 Remediation Note documenting the false claim
- §7 Enum table: Added Original Status (INCONSISTENT) + Post-Remediation Status (CONSISTENT)
- §8 VO table: Same treatment
- Verdict: ALL CLEAR → REMEDIATED — CONSISTENCY RESTORED

**4b. Visibility Contradiction (04-architecture.md vs PRODUCT-EXPERIENCE-ARCHITECTURE.md):**
- 04-architecture.md: Renamed `$isVisible` → `$isSearchVisible`; added new `$isUrlAccessible` rule
- Discontinued programmes: search-invisible (excluded from index) + URL-accessible (canonical URL renders with notice)
- Added SEO/trust rationale with cross-reference to PRODUCT-EXPERIENCE-ARCHITECTURE.md
- PRODUCT-EXPERIENCE-ARCHITECTURE.md: Added cross-reference back to 04-architecture.md §5.5

**4c. DISCOVERY-CLOSURE.md:**
- No changes needed — the "12 B-class" claim does not exist in the document
- Actual counts (6A + 9B + 3C = 18) are correct arithmetic
- The upstream audit's flag was a false positive

**Source authority:** Cross-document consistency analysis

### FIX 5: Fix Package Integrity Claims (MEDIUM)

**PACKAGE-SCOPE.md:**
- Arithmetic: "21 archive" → "31 archive" (6+4+10+31+3=54 ✓)
- Archive claim: "all 31 included" → "29 of 31 included (2 excluded as lower-priority)"

**06-DATA-ACQUISITION/README.md:**
- Source taxonomy: "JAMB, IBASS, NUC, NBTE, NCCE" → "JAMB, WAEC, NECO, NABTEB, NBTE, NUC" (matching canonical)

**STUDYNEXUS-INDEPENDENT-AUDIT-PACKAGE-V3-REPORT.md:**
- "20/20 V2 files byte-identical" → "20/20 non-historical V2 files byte-identical; 34 archive/meta files not verified"
- Updated in 4 locations throughout the report

**Source authority:** Factual accuracy verification

---

## Files Modified

| File | Category | Edits | Nature |
|------|----------|-------|--------|
| canonical/05-implementation.md | TIER 1 | ~30 | Alignment with 03-domain.md + ADR-6 + ProgrammeInstance/Campus |
| canonical/04-architecture.md | TIER 1 | ~24 | ADR-6 alignment + ProgrammeInstance/Campus + visibility rule |
| canonical/03-domain.md | TIER 1 | ~26 | ProgrammeInstance/Campus + CampusStatus enum |
| governance/CANONICAL-CONSISTENCY-AUDIT.md | TIER 4 | 5 | Remediation status update |
| product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md | TIER 2 | 1 | Cross-reference for visibility rule |
| 00-ORIENTATION/PACKAGE-SCOPE.md | Meta | 2 | Arithmetic + archive count fixes |
| 06-DATA-ACQUISITION/README.md | Meta | 1 | IBASS → canonical source list |
| STUDYNEXUS-INDEPENDENT-AUDIT-PACKAGE-V3-REPORT.md | Meta | 4 | "20/20" clarification |

**Files NOT modified (confirmed correct or no changes needed):**
- canonical/01-business.md — No contradictions found
- canonical/02-decisions.md — ADR-6 is correct and authoritative
- canonical/06-data-acquisition.md — External identifiers already correct (BD-5/ADR-21)
- governance/DISCOVERY-CLOSURE.md — No "12 B-class" claim exists (false positive)
- governance/CANONICAL-AMENDMENT-REPORT.md — Correct as-is
- All other governance documents — Correct as-is

---

## Items the External Audit Got Wrong

1. **External Identifiers:** The audit claimed "Replace the single external_id string field with an external_identifiers polymorphic table." This is already implemented. Both 03-domain.md and 05-implementation.md already have the full BD-5/ADR-21 generic external_identifiers table with polymorphic entity_type/entity_id, lifecycle management, supersession chains, and partial unique indexes. **No fix needed.**

2. **"12 B-class" claim:** The audit claimed DISCOVERY-CLOSURE.md asserts "12 B-class" decisions. It does not. The document contains no such claim. The actual triage counts (6A + 9B + 3C = 18) are correct. **False positive.**

---

## Architectural Decisions Not Changed

No foundational decisions were altered:
- BD-1 (BIGINT PKs) — unchanged
- BD-3 (PhaseSequence JSONB) — unchanged
- BD-5 (generic external_identifiers) — unchanged (was already correct)
- ND-5 (InformationSource independent AR) — unchanged
- ND-4 (hybrid provenance 80/20) — unchanged
- ADR-6 (PostgreSQL FTS for MVP) — unchanged (was already correct; architecture/implementation aligned TO it)

The only new decision is the addition of ProgrammeInstance and Campus entities, which is a domain model enhancement, not a decision reversal.

---

## Post-Remediation Canonical Counts

| Concept | Before | After | Reason |
|---------|--------|-------|--------|
| Domain Entities | 11 | 13 | +Campus, +ProgrammeInstance |
| Child Entities | 3 | 4 | +ProgrammeInstance |
| Supporting Entities | 3 | 4 | +Campus |
| Value Objects | 28 | 28 | Unchanged (VO names aligned, not added) |
| Enums | 16 | 17 | +CampusStatus |
| Domain Events | 29 | 29 | Unchanged (naming aligned, not added) |
| Actions | 20 | 20 | Unchanged (aligned to canonical, not added) |
| Database Tables | 58 | 60 | +campuses, +programme_instances |

---

## Remaining Gaps (Known, Not Remediated)

1. **No competitive teardown documents** — No detailed competitor feature inventories exist in the workspace. The canonical 01-business.md has high-level competitor identification only.

2. **No UX research data** — No user research, interview transcripts, or usability test results exist. The UX documents are design specifications, not research evidence.

3. **No performance requirements** — No explicit SLA, query latency, or scale requirements are quantified beyond ADR-6's 200ms threshold.

4. **V2 baseline hashes changed** — The canonical documents (03-domain.md, 04-architecture.md, 05-implementation.md) have been modified, so their SHA-256 hashes no longer match the original V2 MANIFEST.md. The V2 MANIFEST.md should be updated to reflect the new hashes.

5. **IMPLEMENTATION-PLAN.md may need re-verification** — The implementation plan was corrected in a previous session to align with the canonical documents. Now that the canonical documents have been further modified (ProgrammeInstance, Campus, ADR-6 alignment, enum changes), the implementation plan may need additional updates to reflect:
   - ProgrammeInstance and Campus tables/phases
   - PostgreSQL FTS instead of Typesense in Phase 1
   - Updated enum counts (17 not 16)
   - Updated table counts (60 not 58)

---

*Report generated: 2026-08-18*
*This report does NOT claim the architecture is correct. It claims only that the identified canonical contradictions have been surgically remediated.*
