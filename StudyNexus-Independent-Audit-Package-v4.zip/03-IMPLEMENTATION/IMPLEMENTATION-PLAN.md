# StudyNexus — Implementation Plan (Corrected)

**Date:** 2026-08-10
**Status:** CORRECTED CANONICAL IMPLEMENTATION PLAN
**Authority:** Derived from V2 frozen baseline: 02-decisions.md, 03-domain.md, 04-architecture.md, 05-implementation.md, 06-data-acquisition.md
**Constraint:** No new domain concepts. No reopened foundational decisions. No premature optimization. This document converts the frozen architecture into an executable sequence. All corrections applied per canonical audit — lifecycle, enums, actions, events, tables, and UX/UI conformance verified against canonical sources.

---

# Conventions Used Throughout

| Marker | Meaning |
|--------|---------|
| **ARCHITECTURAL DECISION** | Frozen per ADR — not negotiable during implementation |
| **IMPLEMENTATION CONVENTION** | Developer team choice — changeable without a change proposal |
| **Per XX-doc.md §N** | Reference to canonical document section |
| Prerequisite | What must be complete before this step |
| Affected tables | Database tables created or modified |
| Affected models | Eloquent models created or modified |
| Tests required | Minimum test coverage for this step |
| Parallelizable | Whether this step can run concurrently with others |
| Next blocker | What cannot start until this step completes |

---

# Section 1 — Project Bootstrap

**Source authority:** Per 05-implementation.md §1, 04-architecture.md §2

## 1.1 Laravel Project Creation

| Step | Action | Detail |
|------|--------|--------|
| 1.1.1 | Create Laravel project | `composer create-project laravel/laravel studynexus "^\13.0"` |
| 1.1.2 | Verify PHP version | `php -v` must show 8.5+. Abort if < 8.5. |
| 1.1.3 | Verify Laravel version | `php artisan --version` must show Laravel Framework 13.x. Abort if 12.x or lower. |
| 1.1.4 | Configure default timezone | Set `APP_TIMEZONE=Africa/Lagos` in `.env` and `config/app.php` |
| 1.1.5 | Configure locale | Set `APP_LOCALE=en` (Nigeria primary; future: ha, yo, ig) |

**ARCHITECTURAL DECISION:** Laravel ^13.0 + PHP 8.5 baseline is non-negotiable (Per 02-decisions.md §2).
**IMPLEMENTATION CONVENTION:** Project root directory is `studynexus/`.

## 1.2 Directory Structure (Laravel Beyond CRUD)

Per 04-architecture.md §2, the project follows the Laravel Beyond CRUD convention:

```
studynexus/
├── app/
│   ├── Actions/                     # 20 canonical domain Actions
│   │   ├── Institution/
│   │   │   ├── CreateInstitution.php
│   │   │   ├── SuspendInstitution.php
│   │   │   ├── CloseInstitution.php
│   │   │   └── MergeInstitutions.php
│   │   ├── Programme/
│   │   │   ├── CreateProgramme.php
│   │   │   └── DiscontinueProgramme.php
│   │   ├── Scholarship/
│   │   │   ├── AnnounceScholarship.php
│   │   │   ├── OpenScholarshipApplications.php
│   │   │   ├── ExpireScholarship.php
│   │   │   └── TargetScholarshipProgrammes.php
│   │   ├── AdmissionCycle/
│   │   │   ├── AnnounceAdmissionCycle.php
│   │   │   ├── ActivateAdmissionCycle.php
│   │   │   └── AdvanceAdmissionCyclePhase.php
│   │   ├── InformationSource/
│   │   │   ├── RegisterInformationSource.php
│   │   │   ├── VerifyInformationSource.php
│   │   │   └── MarkSourceUnreliable.php
│   │   ├── Accreditation/
│   │   │   └── RecordAccreditation.php
│   │   ├── AdmissionPolicy/
│   │   │   └── PublishAdmissionPolicy.php
│   │   └── Import/
│   │       ├── ImportInstitutionData.php
│   │       └── ExpireScholarships.php
│   ├── Casts/                       # Custom Eloquent casts for VOs
│   │   ├── AdmissionRuleCast.php
│   │   ├── EligibilityRuleCast.php
│   │   ├── SubjectCombinationCast.php
│   │   ├── QualificationThresholdCast.php
│   │   ├── ValidityPeriodCast.php
│   │   ├── MonetaryAmountCast.php
│   │   ├── DurationCast.php
│   │   ├── LocationCast.php
│   │   ├── AuthorityJurisdictionCast.php
│   │   └── PhaseSequenceCast.php
│   ├── Console/                     # Artisan commands
│   ├── Domain/                      # Domain events, enums, VOs
│   │   ├── Enums/
│   │   │   ├── InstitutionType.php
│   │   │   ├── AwardLevel.php
│   │   │   ├── AdmissionMode.php
│   │   │   ├── AccreditationStatus.php
│   │   │   ├── PolicyStatus.php
│   │   │   ├── ProgrammeStatus.php
│   │   │   ├── ScholarshipStatus.php
│   │   │   ├── InstitutionStatus.php
│   │   │   ├── SourceReliability.php
│   │   │   ├── InformationCategory.php
│   │   │   ├── AuthorityType.php
│   │   │   ├── ProviderType.php
│   │   │   ├── OwnershipType.php
│   │   │   ├── DeliveryMode.php
│   │   │   ├── QualificationStatus.php
│   │   │   └── CoverageType.php
│   │   ├── Events/                  # 29 domain events
│   │   ├── ValueObjects/            # 12 non-enum VOs
│   │   └── StateMachines/          # AdmissionCycle phase machine
│   ├── Events/                      # Laravel event listeners
│   ├── Filament/                    # Admin panel resources
│   │   ├── Resources/              # Filament resource classes
│   │   └── Pages/                  # Filament custom pages
│   ├── Http/                        # Controllers, Middleware
│   │   └── Controllers/
│   ├── Jobs/                        # Queue jobs (import, search index)
│   ├── Listeners/                   # Domain event listeners
│   ├── Livewire/                    # Livewire v4 components
│   │   ├── Search/
│   │   ├── Programme/
│   │   └── Institution/
│   ├── Models/                      # Eloquent models (aggregate roots first)
│   │   ├── Institution.php
│   │   ├── Programme.php
│   │   ├── Scholarship.php
│   │   ├── AdmissionCycle.php
│   │   ├── InformationSource.php
│   │   ├── AdmissionPolicy.php
│   │   ├── EligibilityPolicy.php
│   │   ├── AccreditationRecord.php
│   │   ├── Qualification.php
│   │   ├── ScholarshipProvider.php
│   │   ├── EducationAuthority.php
│   │   ├── ExternalIdentifier.php
│   │   ├── FieldProvenance.php
│   │   ├── CutOffMark.php
│   │   ├── ImportBatch.php
│   │   ├── PendingImport.php
│   │   └── OrganizationMember.php
│   ├── Observers/                   # Eloquent model observers
│   ├── Policies/                    # Laravel authorization Policies
│   ├── QueryFilters/                # Search/filter query builders
│   ├── Scout/                       # Typesense collection definitions
│   ├── Stubs/                       # Source adapter implementations
│   │   └── Adapters/
│   ├── Traits/                      # HasProvenance, HasExternalIdentifiers
│   └── Notifications/
├── database/
│   ├── migrations/                  # Numbered migrations (§5)
│   ├── seeders/                     # Reference + development seeders
│   └── factories/                   # Model factories
├── resources/
│   ├── views/
│   │   ├── livewire/               # Livewire Blade views
│   │   ├── pages/                  # Front-end page templates
│   │   └── components/             # Blade components
│   └── css/
│       └── app.css                  # Tailwind v4 @theme config (not JS)
├── routes/
│   ├── web.php
│   └── api.php
├── tests/
│   ├── Unit/
│   │   ├── Domain/
│   │   ├── Actions/
│   │   ├── ValueObjects/
│   │   └── Enums/
│   ├── Feature/
│   │   ├── Actions/
│   │   ├── Search/
│   │   ├── Import/
│   │   └── Provenance/
│   └── Browser/                    # Dusk tests for vertical slice
└── config/
    ├── typesense.php
    └── studynexus.php
```

**ARCHITECTURAL DECISION:** Actions directory organized by aggregate (Per 03-domain.md §5). Models ARE the aggregate persistence representation — no separate domain entity classes (ADR-1).
**IMPLEMENTATION CONVENTION:** Sub-directory grouping by aggregate root name in Actions/. Enums in `app/Domain/Enums/`. VOs in `app/Domain/ValueObjects/`.

## 1.3 Initial Configuration

| Step | Action | Detail |
|------|--------|--------|
| 1.3.1 | Configure PostgreSQL | Set `DB_CONNECTION=pgsql`, `DB_PORT=5432` in `.env` |
| 1.3.2 | Configure Redis | Set `CACHE_DRIVER=redis`, `QUEUE_CONNECTION=redis`, `SESSION_DRIVER=redis` in `.env` |
| 1.3.3 | Configure Scout | Set `SCOUT_DRIVER=typesense` in `.env` |
| 1.3.4 | Register morphMap | Add `Relation::enforceMorphMap()` in `AppServiceProvider` with all aliases (see §8) |
| 1.3.5 | Configure Filament | Publish Filament config, set panel path to `/admin` |
| 1.3.6 | Create studynexus.php config | Central config for provenance categories, search settings, import thresholds |

**Prerequisite:** Step 1.1 complete.
**Tests required:** Verify `php artisan config:cache` runs without error.
**Parallelizable:** No — all subsequent work depends on this.
**Next blocker:** Nothing can proceed without project creation.

---

# Section 2 — Package Installation and Verification

**Source authority:** Per 05-implementation.md §2, 02-decisions.md §6

## 2.1 Core Framework Packages

| # | Package | Version Constraint | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 1 | `laravel/scout` | ^4.0 | `php artisan scout:status` | `composer require laravel/scout "^4.0"` |
| 2 | `livewire/livewire` | ^4.0 | `php artisan livewire:check` or verify Livewire component renders | `composer require livewire/livewire "^4.0"` |
| 3 | `filament/filament` | ^3.0 | `php artisan filament:install` (v5 ships as ^3.0 composer package) | `composer require filament/filament "^3.0"` |

**ARCHITECTURAL DECISION:** Filament v5 is the admin panel framework. It ships as `filament/filament ^3.0` in Composer but is Filament v5 API (Per 05-implementation.md §1). Livewire v4 is the front-end component framework (not v3).

## 2.2 Domain/Authorization Packages

| # | Package | Version Constraint | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 4 | `spatie/laravel-permission` | ^6.0 | `php artisan permission:show` | `composer require spatie/laravel-permission "^6.0"` |
| 5 | `spatie/laravel-activitylog` | ^5.0 | Verify `activities` table after migration | `composer require spatie/laravel-activitylog "^5.0"` |

## 2.3 Search Packages

| # | Package | Version Constraint | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 6 | `typesense/typesense-php` | ^4.0 | Verify Typesense PHP client instantiates | `composer require typesense/typesense-php "^4.0"` |

**ARCHITECTURAL DECISION:** Typesense is the search engine. Meilisearch is NOT used (Per 02-decisions.md §6, ADR-12).

**IMPLEMENTATION CONVENTION:** Scout Typesense driver is bundled with `laravel/scout ^4.0` — no separate driver package needed.

## 2.4 Data Acquisition Packages

| # | Package | Version Constraint | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 7 | `spatie/crawler` | ^1.0 | Instantiate `Crawler` class in tinker | `composer require spatie/crawler "^1.0"` |
| 8 | `smalot/pdfparser` | ^2.0 | Parse a test PDF in tinker | `composer require smalot/pdfparser "^2.0"` |
| 9 | `maatwebsite/excel` | ^3.1 | `php artisan excel:check` or import test | `composer require maatwebsite/excel "^3.1"` |
| 10 | `spatie/laravel-rate-limited-job-middleware` | ^1.0 | Add middleware to a test job | `composer require spatie/laravel-rate-limited-job-middleware "^1.0"` |

## 2.5 Admin/UI Packages

| # | Package | Version Constraint | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 11 | `bezhansalleh/filament-shield` | latest compatible | `php artisan shield:install` | `composer require bezhansalleh/filament-shield` |
| 12 | `pxlrbt/filament-activity-log` | ^2.0 | Verify activity log resource appears in admin | `composer require pxlrbt/filament-activity-log "^2.0"` |

## 2.6 Media/Utility Packages

| # | Package | Version Constraint& | Verification Step | Install Command |
|---|---------|-------------------|-------------------|-----------------|
| 13 | `spatie/laravel-medialibrary` | ^11.0 | `php artisan media-library:install` | `composer require spatie/laravel-medialibrary "^11.0"` |
| 14 | `spatie/laravel-sluggable` | ^3.0 | Add `HasSlug` trait to a test model | `composer require spatie/laravel-sluggable "^3.0"` |

## 2.7 Compatibility Verification Protocol

After ALL packages are installed, run the following verification sequence:

```bash
# 1. Clear and rebuild caches
php artisan optimize:clear
php artisan config:cache
php artisan route:cache

# 2. Verify no dependency conflicts
composer validate

# 3. Run auto-discovery for all package service providers
php artisan package:discover

# 4. Verify Filament panel renders at /admin
php artisan serve  # then curl http://localhost:8000/admin

# 5. Verify Scout + Typesense connection
php artisan tinker --execute="echo Scout::engine();"

# 6. Verify Spatie Permission tables will be created
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"

# 7. Run full static analysis (if phpstan/pint installed)
./vendor/bin/pint --test
```

**Prerequisite:** Section 1 complete (project exists).
**Tests required:** Each package's verification step passes without error. A single integration test `PackageCompatibilityTest` asserting all service providers are registered.
**Parallelizable:** No — packages must be installed in a single Composer lockfile resolution.
**Next blocker:** Migrations cannot be authored until Spatie permission tables are published.

---

# Section 3 — Environment/Infrastructure Setup

**Source authority:** Per 05-implementation.md §3, 04-architecture.md §5

## 3.1 Docker Compose Configuration

Create `docker-compose.yml` at project root with the following services:

### 3.1.1 PostgreSQL 16+

```yaml
postgres:
  image: postgres:16-alpine
  ports:
    - "5432:5432"
  environment:
    POSTGRES_DB: studynexus
    POSTGRES_USER: studynexus
    POSTGRES_PASSWORD: ${DB_PASSWORD}
  volumes:
    - pgdata:/var/lib/postgresql/data
  healthcheck:
    test: ["CMD-SHELL", "pg_isready -U studynexus"]
    interval: 5s
    timeout: 5s
    retries: 5
```

**ARCHITECTURAL DECISION:** PostgreSQL 16+ is the primary data store (ADR-01, Per 02-decisions.md §2). No MySQL fallback.

### 3.1.2 Redis 7+

```yaml
redis:
  image: redis:7-alpine
  ports:
    - "6379:6379"
  command: redis-server --appendonly yes
  volumes:
    - redisdata:/data
  healthcheck:
    test: ["CMD", "redis-cli", "ping"]
    interval: 5s
    timeout: 5s
    retries: 5
```

### 3.1.3 Typesense

```yaml
typesense:
  image: typesense/typesense:27.1
  ports:
    - "8108:8108"
  environment:
    TYPESENSE_API_KEY: ${TYPESENSE_API_KEY}
    TYPESENSE_DATA_DIR: /data
  volumes:
    - typesensedata:/data
  healthcheck:
    test: ["CMD-SHELL", "curl -f http://localhost:8108/health"]
    interval: 5s
    timeout: 5s
    retries: 5
```

**ARCHITECTURAL DECISION:** Typesense is the search engine (Per 02-decisions.md, ADR-12). Meilisearch is NOT used.

### 3.1.4 App Container

```yaml
app:
  build:
    context: .
    dockerfile: Dockerfile
  ports:
    - "8000:8000"
  depends_on:
    postgres: { condition: service_healthy }
    redis: { condition: service_healthy }
    typesense: { condition: service_healthy }
  environment:
    DB_HOST: postgres
    REDIS_HOST: redis
    TYPESENSE_HOST: typesense
```

## 3.2 Environment File Template

```env
APP_NAME=StudyNexus
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost:8000
APP_TIMEZONE=Africa/Lagos

DB_CONNECTION=pgsql
DB_HOST=postgres
DB_PORT=5432
DB_DATABASE=studynexus
DB_USERNAME=studynexus
DB_PASSWORD=secret

REDIS_HOST=redis
REDIS_PASSWORD=null
REDIS_PORT=6379

CACHE_DRIVER=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis

SCOUT_DRIVER=typesense
TYPESENSE_API_KEY=xyz
TYPESENSE_HOST=typesense
TYPESENSE_PORT=8108
TYPESENSE_PROTOCOL=http
```

## 3.3 Verification Steps

| Step | Command | Expected Result |
|------|---------|-----------------|
| 3.3.1 | `docker compose up -d` | All 4 services healthy |
| 3.3.2 | `php artisan migrate:status` | No pending migrations yet (clean) |
| 3.3.3 | `php artisan tinker --execute="Redis::ping()"` | Returns `PONG` |
| 3.3.4 | `curl http://localhost:8108/health` | Returns `{"ok": true}` |
| 3.3.5 | `php artisan queue:work --once` | Processes one job or exits cleanly |

**Prerequisite:** Section 2 complete (packages installed).
**Parallelizable:** Yes — Docker setup can proceed in parallel with Sections 1-2 if developer has Docker preconfigured.
**Next blocker:** Migrations require PostgreSQL running.

---

# Section 4 — Database Migration Dependency Graph

**Source authority:** Per 03-domain.md §3, 05-implementation.md §4, 02-decisions.md (ADR-19, ADR-20, ADR-21)

## 4.1 Canonical Table Inventory (58 tables)

Per 05-implementation.md §4, the complete schema has 58 tables:

| Layer | Tables | Count | Classification |
|-------|--------|-------|----------------|
| Domain | institutions, programmes, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, education_authorities, information_sources, scholarship_providers, disciplines, cut_off_marks, external_identifiers, field_provenance | 14 | A/B |
| Reference | qualifications, countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries | 7 | A/B |
| Content | articles, guides, guide_sections, educational_resources, exam_preparations | 5 | C |
| Auth/RBAC | users, roles, permissions, model_has_roles, model_has_permissions, role_has_permissions, organization_members, password_reset_tokens, personal_access_tokens | 9 | A |
| Engagement | saves, follows, likes, comparison_sets | 4 | C |
| Community | community_questions, community_answers, community_comments, community_votes, community_reports | 5 | C |
| Notification | notification_preferences | 1 | C |
| Settings | platform_settings, institution_settings, user_preferences | 3 | C |
| SEO | url_redirects | 1 | B |
| Infrastructure | media, tags, taggables, activities, notifications, jobs, failed_jobs, cache, sessions | 9 | A (jobs/failed_jobs/sessions/cache) B (activities/media/tags/taggables) C (notifications) |

**Classification:** A = First Slice Required, B = Platform Foundation, C = Deferred Post-Slice.

### 4.1.1 First Slice Tables (Category A — 22 tables)

users, password_reset_tokens, personal_access_tokens, roles, permissions, model_has_roles, model_has_permissions, organization_members, countries, currencies, qualifications, disciplines, education_authorities, institutions, programmes, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, information_sources, scholarship_providers, cut_off_marks, external_identifiers, field_provenance, jobs, failed_jobs, sessions, cache

### 4.1.2 Platform Foundation Tables (Category B — 15 tables)

qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries, url_redirects, activities, media, tags, taggables

### 4.1.3 Deferred Post-Slice Tables (Category C — 21 tables)

articles, guides, guide_sections, educational_resources, exam_preparations, saves, follows, likes, comparison_sets, community_questions, community_answers, community_comments, community_votes, community_reports, notification_preferences, platform_settings, institution_settings, user_preferences, notifications

## 4.2 ASCII Dependency Graph

```
users
  └── organization_members

roles (Spatie)
  └── permissions (Spatie)
  └── model_has_roles
  └── model_has_permissions
  └── role_has_permissions

countries ──────────────────────┐
currencies ─────────────────────┤
disciplines ────────────────────┤
qualifications ─────────────────┤  (reference data, no FK deps)
                                │
education_authorities ──────────┤
  ├── institutions              │
  │   ├── programmes            │
  │   │   └── cut_off_marks ───┤── admission_cycles
  │   ├── accreditation_records│
  │   └── external_identifiers │
  ├── admission_cycles          │
  │   ├── admission_policies   │
  │   ├── eligibility_policies │
  │   └── cut_off_marks        │
  ├── information_sources       │
  │   └── external_identifiers │
  │   └── field_provenance     │
  └── external_identifiers     │
                                │
scholarship_providers ──────────┤
  └── scholarships              │
                                │
import_batches (UUID PK) ──────┤  (staging, ephemeral)
  └── pending_imports (UUID PK) ┘

articles
guides
  └── guide_sections
educational_resources
exam_preparations

saves
follows
likes
comparison_sets

community_questions
community_answers
community_comments
community_votes
community_reports

notification_preferences
platform_settings
institution_settings
user_preferences
url_redirects
```

## 4.3 FK Dependency Chain (simplified)

```
education_authorities
  → institutions (FK: authority_id → RESTRICT)
  → admission_cycles (FK: authority_id → RESTRICT)
  → information_sources (FK: authority_id → RESTRICT, nullable)
  → external_identifiers (FK: authority_id → RESTRICT)

institutions
  → programmes (FK: institution_id → RESTRICT)
  → accreditation_records (FK: institution_id → RESTRICT)
  → external_identifiers (FK: entity_id, entity_type=institution → RESTRICT)
  → field_provenance (FK: entity_id, entity_type=institution → RESTRICT)

programmes
  → cut_off_marks (FK: programme_id → CASCADE)

admission_cycles
  → cut_off_marks (FK: admission_cycle_id → CASCADE)
  → admission_policies (FK: admission_cycle_id → CASCADE)
  → eligibility_policies (FK: admission_cycle_id → CASCADE)

information_sources
  → external_identifiers (FK: source_id → RESTRICT)
  → field_provenance (FK: source_id → RESTRICT)

external_identifiers
  → external_identifiers (FK: replaced_by_id → RESTRICT, self-ref)

field_provenance
  → field_provenance (FK: superseded_by_id → RESTRICT, self-ref)

scholarship_providers
  → scholarships (FK: provider_id → RESTRICT)

import_batches
  → pending_imports (FK: batch_id → CASCADE)
```

## 4.4 Circular Dependency Analysis

No circular dependencies exist. The graph is a DAG. Self-referencing FKs on `external_identifiers.replaced_by_id` and `field_provenance.superseded_by_id` are nullable and do not create cycles.

**ARCHITECTURAL DECISION:** Uniform BIGINT PKs for all canonical tables; UUID only for staging (import_batches, pending_imports) per BD-1/ADR-19 (Per 02-decisions.md).

**Discipline PK Resolution (ADR-19):** `disciplines.id` is BIGINT. `discipline_id` on `programmes` is BIGINT FK. There is no UUID option for these columns. ADR-19 overrides the earlier 03-domain.md §12 text that showed `id UUID` — that text predates the ADR-19 architectural decision and is superseded. This is not an implementation-time decision; it is resolved by ADR-19.

---

# Section 5 — Exact Migration Order

**Source authority:** Per 05-implementation.md §4, 03-domain.md §3

All migrations use Laravel's timestamp-based naming. The order below reflects dependency resolution.

## 5.1 Layer 1 — Users + Auth (4 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 1 | `0001_01_01_000000_create_users_table` | `users` | BIGINT | Laravel default + add `role` string column |
| 2 | `0001_01_01_000001_create_password_reset_tokens_table` | `password_reset_tokens` | — | Laravel default |
| 3 | `0001_01_01_000002_create_failed_jobs_table` | `failed_jobs` | BIGINT | Laravel default |
| 4 | `0001_01_01_000003_create_personal_access_tokens_table` | `personal_access_tokens` | BIGINT | Laravel Sanctum default |

## 5.2 Layer 2 — Roles + Permissions (Spatie) (5 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 5 | `0002_01_01_000000_create_permissions_table` | `permissions` | BIGINT | Published from spatie/laravel-permission |
| 6 | `0002_01_01_000001_create_roles_table` | `roles` | BIGINT | Published from spatie/laravel-permission |
| 7 | `0002_01_01_000002_create_model_has_permissions_table` | `model_has_permissions` | — | Pivot |
| 8 | `0002_01_01_000003_create_model_has_roles_table` | `model_has_roles` | — | Pivot |
| 9 | `0002_01_01_000004_create_role_has_permissions_table` | `role_has_permissions` | — | Pivot |

## 5.3 Layer 3 — Reference Data (7 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 10 | `0003_01_01_000000_create_countries_table` | `countries` | BIGINT | ISO 3166-1 |
| 11 | `0003_01_01_000001_create_currencies_table` | `currencies` | BIGINT | ISO 4217 |
| 12 | `0003_01_01_000002_create_qualifications_table` | `qualifications` | BIGINT | Reference namespace |
| 13 | `0003_01_01_000003_create_disciplines_table` | `disciplines` | BIGINT | Managed reference, flat for MVP |
| 14 | `0003_01_01_000004_create_qualification_equivalencies_table` | `qualification_equivalencies` | BIGINT | Reference self-FK |
| 15 | `0003_01_01_000005_create_tuition_fee_ranges_table` | `tuition_fee_ranges` | BIGINT | Deferred |
| 16 | `0003_01_01_000006_create_cost_of_living_indices_table` | `cost_of_living_indices` | BIGINT | Deferred |

## 5.4 Layer 4 — Domain Tables (14 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 17 | `0004_01_01_000000_create_education_authorities_table` | `education_authorities` | BIGINT | AuthorityType enum |
| 18 | `0004_01_01_000001_create_institutions_table` | `institutions` | BIGINT | InstitutionStatus + is_published + published_at |
| 19 | `0004_01_01_000002_create_programmes_table` | `programmes` | BIGINT | ProgrammeStatus + is_published + published_at, discipline_id FK |
| 20 | `0004_01_01_000003_create_scholarship_providers_table` | `scholarship_providers` | BIGINT | ProviderType enum |
| 21 | `0004_01_01_000004_create_scholarships_table` | `scholarships` | BIGINT | ScholarshipStatus + is_published + published_at |
| 22 | `0004_01_01_000005_create_admission_cycles_table` | `admission_cycles` | BIGINT | PhaseSequence JSONB + current_phase |
| 23 | `0004_01_01_000006_create_admission_policies_table` | `admission_policies` | BIGINT | Polymorphic governable |
| 24 | `0004_01_01_000007_create_eligibility_policies_table` | `eligibility_policies` | BIGINT | BelongsTo scholarship |
| 25 | `0004_01_01_000008_create_accreditation_records_table` | `accreditation_records` | BIGINT | Polymorphic accreditable |
| 26 | `0004_01_01_000009_create_information_sources_table` | `information_sources` | BIGINT | SourceReliability enum, nullable authority_id |
| 27 | `0004_01_01_000010_create_cut_off_marks_table` | `cut_off_marks` | BIGINT | programme_id + cycle_id + pathway unique |
| 28 | `0004_01_01_000011_create_external_identifiers_table` | `external_identifiers` | BIGINT | Polymorphic, partial unique indexes |
| 29 | `0004_01_01_000012_create_field_provenance_table` | `field_provenance` | BIGINT | 80/20 provenance model |
| 30 | `0004_01_01_000013_create_scholarship_programme_table` | `scholarship_programme` | — | M:N pivot (scholarship targets programmes) |

## 5.5 Layer 5 — Organization (1 migration)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 31 | `0005_01_01_000000_create_organization_members_table` | `organization_members` | BIGINT | Morphable pivot, string role |

## 5.6 Layer 6 — Content (5 migrations, Category C)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 32 | `0006_01_01_000000_create_articles_table` | `articles` | BIGINT | Deferred |
| 33 | `0006_01_01_000001_create_guides_table` | `guides` | BIGINT | Deferred |
| 34 | `0006_01_01_000002_create_guide_sections_table` | `guide_sections` | BIGINT | Deferred |
| 35 | `0006_01_01_000003_create_educational_resources_table` | `, `educational_resources` | BIGINT | Deferred |
| 36 | `0006_01_01_000004_create_exam_preparations_table` | `exam_preparations` | BIGINT | Deferred |

## 5.7 Layer 7 — Engagement (4 migrations, Category C)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 37 | `0007_01_01_000000_create_saves_table` | `saves` | BIGINT | Deferred |
| 38 | `0007_01_01_000001_create_follows_table` | `follows` | BIGINT | Deferred |
| 39 | `0007_01_01_000002_create_likes_table` | `likes` | BIGINT | Deferred |
| 40 | `0007_01_01_000003_create_comparison_sets_table` | `comparison_sets` | BIGINT | Deferred |

## 5.8 Layer 8 — Community (5 migrations, Category C)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 41 | `0008_01_01_000000_create_community_questions_table` | `community_questions` | BIGINT | Deferred |
| 42 | `0008_01_01_000001_create_community_answers_table` | `community_answers` | BIGINT | Deferred |
| 43 | `0008_01_01_000002_create_community_comments_table` | `community_comments` | BIGINT | Deferred |
| 44 | `0008_01_01_000003_create_community_votes_table` | `community_votes` | BIGINT | Deferred |
| 45 | `0008_01_01_000004_create_community_reports_table` | `community_reports` | BIGINT | Deferred |

## 5.9 Layer 9 — Settings/Notification/SEO (5 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 46 | `0009_01_01_000000_create_notification_preferences_table` | `notification_preferences` | BIGINT | Deferred |
| 47 | `0009_01_01_000001_create_platform_settings_table` | `platform_settings` | BIGINT | Deferred |
| 48 | `0009_01_01_000002_create_institution_settings_table` | `institution_settings` | BIGINT | Deferred |
| 49 | `0009_01_01_000003_create_user_preferences_table` | `user_preferences` | BIGINT | Deferred |
| 50 | `0009_01_01_000004_create_url_redirects_table` | `url_redirects` | BIGINT | Category B |

## 5.10 Layer 10 — Infrastructure (6 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 51 | `0010_01_01_000000_create_media_table` | `media` | BIGINT | Spatie medialibrary |
| 52 | `0010_01_01_000001_create_tags_table` | `tags` | BIGINT | Spatie tags |
| 53 | `0010_01_01_000002_create_taggables_table` | `taggables` | — | Pivot |
| 54 | `0010_01_01_000003_create_activities_table` | `activities` | BIGINT | Spatie activitylog (canonical name) |
| 55 | `0010_01_01_000004_create_notifications_table` | `notifications` | — | Laravel notifications |
| 56 | `0010_01_01_000005_create_visa_requirement_summaries_table` | `visa_requirement_summaries` | BIGINT | Deferred |

## 5.11 Layer 11 — Staging (2 migrations)

| # | Migration | Table | PK Type | Notes |
|---|-----------|-------|---------|-------|
| 57 | `0011_01_01_000000_create_import_batches_table` | `import_batches` | UUID | Staging, ephemeral |
| 58 | `0011_01_01_000001_create_pending_imports_table` | `pending_imports` | UUID | Staging, ephemeral |

**Total: 58 migrations across 11 layers. First slice requires Layers 1-5 + staging (32 migrations).**

---

# Section 6 — Reference Data Seeding

**Source authority:** Per 05-implementation.md §5, 03-domain.md §12

## 6.1 Core Reference Data

| Table | Seed Count | Source | Notes |
|-------|-----------|--------|-------|
| `countries` | 250 | ISO 3166-1 | All countries, Nigeria = NG |
| `currencies` | 180 | ISO 4217 | Nigerian Naira = NGN |
| `qualifications` | 15+ | Nigerian education system | WAEC, NECO, NABTEB, JAMB UTME,/IJMB, JUPEB, ND, HND, NCE, BSc, MSc, PhD |
| `disciplines` | 25+ | Education classification | Engineering, Medical Sciences, Law, Business, Arts, Sciences, Education, Agriculture, etc. |
| `education_authorities` | 44 | Nigerian regulators | JAMB, NUC, NBTE, NCCE, WAEC, NECO, FME + 37 state MOEs |

---

# Section 7 — Domain Model Implementation Order

**Source authority:** Per 03-domain.md §2-4, 04-architecture.md §3

## 7.1 Implementation Sequence

Models are implemented in dependency order. Each model includes: properties (`$fillable`, `$casts`, `$appends`), relationships, domain methods, and scopes.

| Order | Model | Type | Key Relationships | Domain Methods | Prerequisite |
|-------|-------|------|-------------------|---------------|-------------|
| 1 | `EducationAuthority` | Supporting | `institutions()`, `admissionCycles()`, `informationSources()`, `externalIdentifiers()` | `deprecate()` | Ref data seeded |
| 2 | `Institution` | Aggregate Root | `authority()`, `programmes()`, `accreditationRecords()`, `externalIdentifiers()`, `fieldProvenance()` | `establish()`, `rename()`, `suspend()`, `reactivate()`, `close()`, `publishAdmissionPolicy()`, `recordAccreditation()` | EducationAuthority |
| 3 | `Programme` | Aggregate Root | `institution()`, `discipline()`, `accreditationRecords()`, `cutOffMarks()`, `fieldProvenance()` | `introduce()`, `suspendAdmission()`, `resumeAdmission()`, `discontinue()`, `publishAdmissionPolicy()`, `recordAccreditation()` | Institution, Discipline |
| 4 | `ScholarshipProvider` | Supporting | `scholarships()` | `deprecate()` | None |
| 5 | `Scholarship` | Aggregate Root | `provider()`, `fieldProvenance()` | `announce()`, `publishEligibilityPolicy()`, `openApplications()`, `closeApplications()`, `withdraw()`, `expire()`, `targetProgrammes()` | ScholarshipProvider |
| 6 | `AdmissionCycle` | Aggregate Root | `authority()`, `admissionPolicies()`, `eligibilityPolicies()`, `cutOffMarks()`, `fieldProvenance()` | `announce()`, `activate()`, `advancePhase()`, `close()`, `archive()` | EducationAuthority |
| 7 | `AdmissionPolicy` | Child Entity | `admissionCycle()`, `governable()` (polymorphic) | Domain methods delegated to parent | AdmissionCycle |
| 8 | `EligibilityPolicy` | Child Entity | `admissionCycle()` | Domain methods delegated to parent | AdmissionCycle |
| 9 | `AccreditationRecord` | Child Entity | `institution()`, `programme()`, `authority()` (polymorphic) | Immutable after creation | Institution, Programme |
| 10 | `InformationSource` | Aggregate Root | `authority()` (nullable), `externalIdentifiers()`, `fieldProvenance()` | `register()`, `verify()`, `markUnreliable()`, `deprecate()` | EducationAuthority (nullable FK) |
| 11 | `CutOffMark` | Supporting | `programme()`, `admissionCycle()`, `source()` | None (query model) | Programme, AdmissionCycle, InformationSource |
| 12 | `ExternalIdentifier` | Infrastructure | `authority()`, `source()`, `replacedBy()` | `assign()`, `retire()`, `supersede()` | EducationAuthority, InformationSource |
| 13 | `FieldProvenance` | Infrastructure | `source()`, `supersededBy()` | `record()`, `supersede()` | InformationSource |
| 14 | `ImportBatch` | Staging | `pendingImports()` | None (ephemeral) | None |
| 15 | `PendingImport` | Staging | `batch()` | None (ephemeral) | ImportBatch |
| 16 | `OrganizationMember` | Supporting | `user()`, `organization()` | None | User, Institution |

## 7.2 Model Template — Institution (Canonical Lifecycle)

```php
class Institution extends Model
{
    use HasSlug;
    use HasProvenance;
    use HasActivity;
    use SoftDeletes;

    protected $fillable = [
        'name',
        'slug',
        'type',               // InstitutionType enum
        'status',             // InstitutionStatus enum
        'authority_id',
        'ownership_type',     // OwnershipType enum
        'country',
        'state_province',
        'city',
        'location',           // Location VO (JSONB)
        'website',
        'founded_year',
        'description',
        'accreditation_status', // AccreditationStatus enum (derived)
        'is_published',       // boolean, default false
        'published_at',       // nullable timestamp
        'provenance',         // JSONB (entity-level provenance)
    ];

    protected $casts = [
        'type'                => InstitutionType::class,
        'status'              => InstitutionStatus::class,
        'ownership_type'      => OwnershipType::class,
        'accreditation_status' => AccreditationStatus::class,
        'location'            => LocationCast::class,
        'is_published'        => 'boolean',
        'published_at'        => 'datetime',
        'provenance'          => 'array',
        'founded_year'        => 'integer',
    ];

    // Relationships
    public function authority(): BelongsTo { ... }
    public function programmes(): HasMany { ... }
    public function accreditationRecords(): MorphMany { ... }

    // Domain methods (Per 03-domain.md §8)
    public function establish(string $name, InstitutionType $type, ...): void
    {
        // Precondition: status is Provisional or null
        // Postcondition: status = Operational, emits InstitutionEstablished
    }

    public function rename(string $newName): void
    {
        // Precondition: status != Closed
        // Postcondition: name updated, emits InstitutionRenamed
    }

    public function suspend(): void
    {
        // Precondition: status = Operational
        // Postcondition: status = Suspended, emits InstitutionSuspended
    }

    public function reactivate(): void
    {
        // Precondition: status = Suspended
        // Postcondition: status = Operational, emits InstitutionReactivated
    }

    public function close(): void
    {
        // Precondition: status = Operational or Suspended
        // Postcondition: status = Closed (terminal), emits InstitutionClosed
    }

    // Scopes
    public function scopeOperational(Builder $query): Builder { ... }
    public function scopeByType(Builder $query, InstitutionType $type): Builder { ... }
    public function scopePublished(Builder $query): Builder { ... }
}
```

**ARCHITECTURAL DECISION:** InstitutionStatus = Provisional, Operational, Suspended, Closed. State machine: Provisional→Operational (via establish), Operational↔Suspended (via suspend/reactivate), Operational/Suspended→Closed (terminal). Publication is orthogonal: `is_published` + `published_at` control public visibility independently of domain lifecycle (Per 03-domain.md §8).

---

# Section 8 — Value Objects and Casts

**Source authority:** Per 03-domain.md §3, 02-decisions.md §4

## 8.1 Non-Enum Value Objects (12)

| # | VO Class | Storage Format | Cast Class | Used By Model(s) | Description |
|---|----------|---------------|------------|-------------------|-------------|
| 1 | `AdmissionRule` | JSONB | `AdmissionRuleCast` | `AdmissionPolicy` | Structured admission rule |
| 2 | `EligibilityRule` | JSONB | `EligibilityRuleCast` | `EligibilityPolicy` | Structured eligibility rule |
| 3 | `SubjectCombination` | JSONB | `SubjectCombinationCast` | `AdmissionPolicy` | Required subject group |
| 4 | `QualificationThreshold` | JSONB | `QualificationThresholdCast` | `AdmissionPolicy` | Min score/grade for qualification |
| 5 | `ValidityPeriod` | JSONB | `ValidityPeriodCast` | `AccreditationRecord`, `AdmissionPolicy` | `valid_from` + `valid_until` date range |
| 6 | `TrustSignal` | Computed | Never stored | None | Derived at read-time from provenance + verification + source reliability |
| 7 | `MonetaryAmount` | JSONB | `MonetaryAmountCast` | `Programme` (tuition), `Scholarship` (value) | `amount` (kobo) + `currency` (ISO 4217) |
| 8 | `Duration` | JSONB | `DurationCast` | `Programme`, `Scholarship` | `value` (int) + `unit` (years/months/semesters) |
| 9 | `Location` | JSONB | `LocationCast` | `Institution` | `country`, `state`, `city`, `address`, `latitude`, `longitude` |
| 10 | `AuthorityJurisdiction` | JSONB | `AuthorityJurisdictionCast` | `EducationAuthority` | Geographic scope |
| 11 | `PhaseSequence` | JSONB | `PhaseSequenceCast` | `AdmissionCycle` | Ordered phases with stable IDs per BD-3/ADR-20 |
| 12 | `AdmissionPathway` | Backed Enum | Native enum cast | `AdmissionPolicy` | `utme`, `direct_entry`, `inter_university_transfer`, `change_of_institution` |

## 8.2 Morph Map Aliases

```php
// AppServiceProvider::boot()
Relation::enforceMorphMap([
    'institution'       => Institution::class,
    'programme'         => Programme::class,
    'scholarship'       => Scholarship::class,
    'admission_cycle'   => AdmissionCycle::class,
    'education_authority' => EducationAuthority::class,
    'information_source' => InformationSource::class,
    'scholarship_provider' => ScholarshipProvider::class,
    'accreditation_record' => AccreditationRecord::class,
    'admission_policy' => AdmissionPolicy::class,
    'eligibility_policy' => EligibilityPolicy::class,
    'cut_off_mark'      => CutOffMark::class,
]);
```

**ARCHITECTURAL DECISION:** `Relation::enforceMorphMap()` is used (not just `morphMap()`) to prevent unregistered polymorphic types (Per 04-architecture.md §4).

---

# Section 9 — Enums

**Source authority:** Per 03-domain.md §6, 02-decisions.md §4

All 16 canonical enums. Backed enums use `string` backing type unless noted.

### Behavioural Enums (3)

| # | Enum | Backing Type | Values | Behaviour | Used By |
|---|------|-------------|--------|-----------|---------|
| 1 | `InstitutionType` | string | `university`, `polytechnic`, `college_of_education`, `innovative_enterprise_institution` | `isDegreeGranting()`, `isTertiary()` | Institution |
| 2 | `AwardLevel` | string | `bsc`, `ba`, `msc`, `phd`, `nd`, `hnd`, `nce`, `foundation`, `certificate`, `diploma` | `isPostgraduate()`, `isUndergraduate()` | Programme |
| 3 | `AdmissionMode` | string | `cyclic`, `rolling`, `multiple_intake` | Affects `isAdmitting` query logic | Programme |

### Pure Enums (13)

| # | Enum | Backing Type | Values | Used By |
|---|------|-------------|--------|---------|
| 4 | `AccreditationStatus` | string | `full`, `interim`, `probationary`, `revoked`, `expired` | AccreditationRecord |
| 5 | `PolicyStatus` | string | `draft`, `published`, `superseded`, `withdrawn` | AdmissionPolicy, EligibilityPolicy |
| 6 | `ProgrammeStatus` | string | `prospective`, `admitting`, `suspended`, `discontinued` | Programme |
| 7 | `ScholarshipStatus` | string | `draft`, `announced`, `open`, `closed`, `expired`, `withdrawn` | Scholarship |
| 8 | `InstitutionStatus` | string | `provisional`, `operational`, `suspended`, `closed` | Institution |
| 9 | `SourceReliability` | string | `registered`, `verified`, `unreliable`, `deprecated` | InformationSource |
| 10 | `InformationCategory` | string | `official`, `unofficial`, `historical`, `scraped` | InformationSource |

**InformationCategory vs Provenance Trust Taxonomy:** The `InformationCategory` enum (above) is the canonical PHP enum defined by 03-domain.md §6 and used on the `InformationSource` model. It is a **domain enum** with exactly four values: `Official`, `Unofficial`, `Historical`, `Scraped`. Separately, the entity-level provenance JSONB `trust_level` field (per 06-data-acquisition.md §8) uses `InformationCategory` enum values to classify the trust tier of the source that provided the data. The comment in 06-data-acquisition.md that lists "Official, Verified, Historical, CommunityContributed" describes the *semantic intent* of the trust taxonomy, not a separate enum. The mapping is: `Official` → official government/agency source; `Unofficial` → verified but non-official source (the "Verified" label in 06-data-acquisition.md); `Historical` → archived/historical source; `Scraped` → community-contributed or web-scraped source (the "CommunityContributed" label in 06-data-acquisition.md). There is no separate `TrustLevel` or `ProvenanceCategory` enum. `InformationCategory` is the only enum.
| 11 | `AuthorityType` | string | `regulatory`, `accreditation`, `funding`, `admissions` | EducationAuthority |
| 12 | `ProviderType` | string | `government`, `corporate`, `ngo`, `institution` | ScholarshipProvider |
| 13 | `OwnershipType` | string | `public`, `private`, `ppp`, `religious` | Institution |
| 14 | `DeliveryMode` | string | `on_campus`, `online`, `hybrid` | Programme |
| 15 | `QualificationStatus` | string | `active`, `deprecated` | Qualification |
| 16 | `CoverageType` | string | `full`, `partial`, `tuition_only`, `stipend` | Scholarship |

**IMPLEMENTATION CONVENTION:** Every enum has a `label()` method returning human-readable text. Enums are stored as their string backing value in the database. Eloquent casts use the native PHP 8.1+ enum casting.

---

# Section 10 — Aggregate Roots and Child Entities

**Source authority:** Per 03-domain.md §3-4

## 10.1 Institution (Aggregate Root)

**State Machine (Canonical — Per 03-domain.md §8):**
```
[Provisional] --establish()--> [Operational]
[Operational] --suspend()--> [Suspended]
[Suspended] --reactivate()--> [Operational]
[Operational] --close()--> [Closed] (terminal)
[Suspended] --close()--> [Closed] (terminal)
```

**Publication (orthogonal to lifecycle):**
- `is_published` boolean (default false)
- `published_at` nullable timestamp
- Public visibility = `is_published` AND status allows public display
- No `ProgrammeStatus::Published` — publication is not a lifecycle state

**Domain Methods:**
```php
public function establish(...): void   // → Operational, InstitutionEstablished
public function rename(string $newName): void  // InstitutionRenamed
public function suspend(): void        // Operational→Suspended, InstitutionSuspended
public function reactivate(): void     // Suspended→Operational, InstitutionReactivated
public function close(): void          // →Closed (terminal), InstitutionClosed
public function publishAdmissionPolicy(...): AdmissionPolicy  // InstitutionalAdmissionPolicyPublished
public function recordAccreditation(...): AccreditationRecord  // InstitutionAccredited
```

## 10.2 Programme (Aggregate Root, child of Institution)

**State Machine (Canonical — Per 03-domain.md §8):**
```
[introduce()→Admitting] --suspendAdmission()--> [Suspended]
[Suspended] --resumeAdmission()--> [Admitting]
[Admitting/Suspended] --discontinue()--> [Discontinued] (terminal)
```

**Publication (orthogonal):** `is_published`, `published_at` on Programme model.

**Domain Methods:**
```php
public function introduce(...): void  // →Admitting, ProgrammeIntroduced
public function suspendAdmission(): void  // Admitting→Suspended, ProgrammeAd:missionSuspended
public function resumeAdmission(): void   // Suspended→Admitting, ProgrammeAdmissionResumed
public function discontinue(): void       // →Discontinued (terminal), ProgrammeDiscontinued
public function publishAdmissionPolicy(...): AdmissionPolicy  // ProgrammeAdmissionPolicyPublished
public function recordAccreditation(...): AccreditationRecord  // ProgrammeAccredited
```

## 10.3 Scholarship (Aggregate Root)

**State Machine (Canonical — Per 03-domain.md §8):**
```
[Draft] --announce()--> [Announced] --openApplications()--> [Open] --closeApplications()--> [Closed] --expire()--> [Expired]
[Announced/Open] --withdraw()--> [Withdrawn] (terminal)
```

**Publication (orthogonal):** `is_published`, `published_at` on Scholarship model.

**Domain Methods:**
```php
public function announce(...): void  // Draft→Announced, ScholarshipAnnounced
public function publishEligibilityPolicy(...): EligibilityPolicy  // ScholarshipEligibilityPolicyPublished
public function openApplications(): void  // Announced→Open, ScholarshipApplicationsOpened
public function closeApplications(): void  // Open→Closed, ScholarshipApplicationsClosed
public function withdraw(): void  // →Withdrawn (terminal), ScholarshipWithdrawn
public function expire(): void    // →Expired (terminal), ScholarshipExpired
public function targetProgrammes(...): void  // ScholarshipTargetsUpdated
```

## 10.4 AdmissionCycle (Aggregate Root)

**State Machine:** Upcoming→Active→Closed→Archived. Phase advances sequentially within Active.

## 10.5 InformationSource (Aggregate Root)

**State Machine:** Registered→Verified↔Unreliable; any non-deprecated→Deprecated (terminal).

---

# Section 11 — Actions (20 Canonical)

**Source authority:** Per 03-domain.md §5, 04-architecture.md §4

All 20 canonical Actions. Each Action follows this contract:

```php
class CreateInstitution
{
    public function execute(CreateInstitutionData $data): Institution
    {
        // 1. Authorization check (Policy)
        // 2. Validate input data
        // 3. DB::transaction()
        //    a. Create Institution model
        //    b. Call domain method
        //    c. Record provenance
        //    d. Dispatch domain event
        // 4. Return created entity
    }
}
```

## 11.1 Institution Actions (4)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `CreateInstitution` | `execute(CreateInstitutionData $data): Institution` | `institution.create` | Yes | `InstitutionEstablished` |
| `SuspendInstitution` | `execute(Institution $institution): Institution` | `institution.suspend` | Yes | `InstitutionSuspended` |
| `CloseInstitution` | `execute(Institution $institution): Institution` | `institution.close` | Yes | `InstitutionClosed` |
| `MergeInstitutions` | `execute(Institution $initiating, Institution $target): Institution` | `institution.merge` | Yes (cross-aggregate) | `InstitutionsMerged` |

## 11.2 Programme Actions (2)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `CreateProgramme` | `execute(CreateProgrammeData $data): Programme` | `programme.create` | Yes | `ProgrammeIntroduced` |
| `DiscontinueProgramme` | `execute(Programme $programme): Programme` | `programme.discontinue` | Yes | `ProgrammeDiscontinued` |

## 11.3 Scholarship Actions (4)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `AnnounceScholarship` | `execute(AnnounceScholarshipData $data): Scholarship` | `scholarship.create` | Yes | `ScholarshipAnnounced` |
| `OpenScholarshipApplications` | `execute(Scholarship $scholarship): Scholarship` | `scholarship.open` | Yes | `ScholarshipApplicationsOpened` |
| `ExpireScholarship` | `execute(Scholarship $scholarship): Scholarship` | `scholarship.expire` | Yes | `ScholarshipExpired` |
| `TargetScholarshipProgrammes` | `execute(Scholarship $scholarship, array $programmeIds): Scholarship` | `scholarship.target` | Yes | `ScholarshipTargetsUpdated` |

## 11.4 AdmissionCycle Actions (3)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|D-----------|---------------|-------------|---------------|
| `AnnounceAdmissionCycle` | `execute(AnnounceAdmissionCycleData $data): AdmissionCycle` | `admission_cycle.create` | Yes | `AdmissionCycleAnnounced` |
| `ActivateAdmissionCycle` | `execute(AdmissionCycle $cycle): AdmissionCycle` | `admission_cycle.activate` | Yes (lockForUpdate) | `AdmissionCycleActivated` |
| `AdvanceAdmissionCyclePhase` | `execute(AdmissionCycle $cycle): AdmissionCycle` | `admission_cycle.advance_phase` | Yes (lockForUpdate) | `AdmissionCyclePhaseAdvanced` |

## 11.5 AdmissionPolicy Actions (1)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `PublishAdmissionPolicy` | `execute(Model $governable, $cycleId, $rules): AdmissionPolicy` | `admission_policy.publish` | Yes | `ProgrammeAdmissionPolicyPublished` / `InstitutionalAdmissionPolicyPublished` |

## 11.6 InformationSource Actions (3)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `RegisterInformationSource` | `execute(RegisterSourceData $data): InformationSource` | `information_source.create` | Yes | `InformationSourceRegistered` |
| `VerifyInformationSource` | `execute(InformationSource $source): InformationSource` | `information_source.verify` | Yes | `InformationSourceVerified` |
| `MarkSourceUnreliable` | `execute(InformationSource $source, string $reason): InformationSource` | `information_source.mark_unreliable` | Yes | `InformationSourceMarkedUnreliable` |

## 11.7 Other Actions (3)

| Action | Signature | Authorization | Transaction | Event Emitted |
|--------|-----------|---------------|-------------|---------------|
| `RecordAccreditation` | `execute(RecordAccreditationData $data): AccreditationRecord` | `accreditation.create` | Yes | `InstitutionAccredited` / `ProgrammeAccredited` |
| `ImportInstitutionData` | `execute(ImportBatch $batch): void` | `import.run` | Yes (per record) | Per-record domain events |
| `ExpireScholarships` | `execute(): int` | `scholarship.expire_batch` | Yes (batch) | `ScholarshipExpired` per scholarship |

**ARCHITECTURAL DECISION:** Actions are the command interface to the domain. No controllers call model methods directly. All mutations go through Actions (Per 03-domain.md §5, ADR-1).

---

# Section 12 — Domain Events (29 Canonical)

**Source authority:** Per 03-domain.md §4, 04-architecture.md §5

## 12.1 Event Definitions

### Institution Events (8)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `InstitutionEstablished` | `institutionId`, `name`, `type` | `UpdateSearchIndexListener`, `RecordEntityProvenanceListener` |
| `InstitutionRenamed` | `institutionId`, `oldName`, `newName` | `UpdateSearchIndexListener` |
| `InstitutionSuspended` | `institutionId` | `UpdateSearchIndexListener`, `ProgrammeStatusCascadeListener` |
| `InstitutionReactivated` | `institutionId` | `UpdateSearchIndexListener`, `ProgrammeStatusRestoreListener` |
| `InstitutionClosed` | `institutionId` | `UpdateSearchIndexListener`, `ProgrammeDiscontinueCascadeListener` |
| `InstitutionsMerged` | `initiatingId`, `targetId` | `SearchRebuildListener`, `ProgrammeReassignmentListener` |
| `InstitutionAccredited` | `institutionId`, `authorityId`, `status` | `TrustSignalListener`, `UpdateSearchIndexListener` |
| `InstitutionalAdmissionPolicyPublished` | `institutionId`, `cycleId`, `policyId` | `UpdateSearchIndexListener` |

### Programme Events (6)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `ProgrammeIntroduced` | `programmeId`, `institutionId`, `name`, `awardLevel` | `UpdateSearchIndexListener` |
| `ProgrammeAdmissionPolicyPublished` | `programmeId`, `cycleId`, `policyId` | `UpdateSearchIndexListener` |
| `ProgrammeAdmissionSuspended` | `programmeId` | `UpdateSearchIndexListener` |
| `ProgrammeAdmissionResumed` | `programmeId` | `UpdateSearchIndexListener` |
| `ProgrammeDiscontinued` | `programmeId` | `UpdateSearchIndexListener`, `ScholarshipFlagListener` |
| `ProgrammeAccredited` | `programmeId`, `authorityId`, `status` | `TrustSignalListener`, `UpdateSearchIndexListener` |

### Scholarship Events (7)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `ScholarshipAnnounced` | `scholarshipId`, `providerId` | `UpdateSearchIndexListener` |
| `ScholarshipEligibilityPolicyPublished` | `scholarshipId`, `policyId` | `EligibleCandidateRecalcListener` |
| `ScholarshipApplicationsOpened` | `scholarshipId` | `UpdateSearchIndexListener` |
| `ScholarshipApplicationsClosed` | `scholarshipId` | `UpdateSearchIndexListener` |
| `ScholarshipWithdrawn` | `scholarshipId` | `UpdateSearchIndexListener` |
| `ScholarshipExpired` | `scholarshipId` | `UpdateSearchIndexListener` |
| `ScholarshipTargetsUpdated` | `scholarshipId`, `addedIds`, `removedIds` | `UpdateSearchIndexListener` |

### AdmissionCycle Events (4)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `AdmissionCycleAnnounced` | `cycleId`, `authorityId` | `UpdateSearchIndexListener` |
| `AdmissionCycleActivated` | `cycleId` | `ReadModelUpdateListener` |
| `AdmissionCyclePhaseAdvanced` | `cycleId`, `previousPhase`, `currentPhase` | `ReadModelUpdateListener`, `NotificationDispatchListener` |
| `AdmissionCycleClosed` | `cycleId` | `ReadModelUpdateListener` |

### InformationSource Events (3)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `InformationSourceVerified` | `sourceId` | `TrustSignalRecalcListener` |
| `InformationSourceMarkedUnreliable` | `sourceId` | `TrustSignalRecalcListener` |
| `InformationSourceDeprecated` | `sourceId` | `TrustSignalCascadeListener`, `DataProvenanceFlagListener` |

### Qualification Event (1)

| Event | Payload | Listener(s) |
|-------|---------|-------------|
| `QualificationDeprecated` | `qualificationId` | `PolicyCreationGuardListener` |

**Total: 8 + 6 + 7 + 4 + 3 + 1 = 29 canonical events.**

---

# Section 13 — Policies/RBAC

**Source authority:** Per 02-decisions.md §5, 04-architecture.md §6

## 13.1 RBAC Roles (11)

| Role | Key | Permissions Scope | Can Access Admin? |
|------|-----|-------------------|-------------------|
| `platform-admin` | `platform_admin` | All resources, all actions | Yes |
| `platform-moderator` | `platform_moderator` | Verify sources, moderate content | Yes |
| `content-admin` | `content_admin` | All domain entities CRUD + publish, import | Yes |
| `content-editor` | `content_editor` | Domain entities create/update (no delete) | Yes |
| `institution-owner` | `institution_owner` | Full CRUD on own institution + programmes | Yes |
| `institution-admin` | `institution_admin` | CRUD on own institution's programmes | Yes |
| `institution-admissions` | `institution_admissions` | Manage admission policies, cycles | Yes |
| `institution-editor` | `institution_editor` | Edit descriptions, programme details | Yes |
| `institution-viewer` | `institution_viewer` | Read-only on own institution | Yes (read-only) |
| `registered-user` | `registered_user` | Save, follow, like, compare, community | No |
| `guest` | `guest` | Browse only | No |

---

# Section 14 — Provenance/Data-Lineage Implementation

**Source authority:** Per 06-data-acquisition.md §8, 02-decisions.md (ND-4/ADR-23)

## 14.1 Provenance Categories

**ARCHITECTURAL DECISION:** 80/20 provenance model (Per 02-decisions.md, ND-4/ADR-23):

| Category | Fields | When Provenance is Recorded | Count |
|----------|--------|----------------------------|-------|
| **A** (always) | `name`, `type`, `status`, `accreditation_status`, `cut_off_mark` | Every write to these fields | 5 |
| **B** (on conflict) | `founded_year`, `location`, `website`, `admission_requirements`, `application_deadline`, `amount` | Only when new value differs from existing | 6 |
| **C** (never) | All other fields | Never (entity-level JSONB only) | — |

## 14.2 Provenance Immutability

**ARCHITECTURAL DECISION:** Provenance records are immutable once created. When a field is updated from a different source, the old provenance is superseded (not overwritten) via `superseded_at` + `superseded_by_id`. Active provenance is derived from `superseded_at IS NULL` — no `is_active` column (Per 06-data-acquisition.md §8).

---

# Section 15 — Acquisition/Import Boundary Implementation

**Source authority:** Per 06-data-acquisition.md §3-7

(Same as original plan §15 — no corrections needed for import pipeline architecture.)

---

# Section 16 — Typesense Projection Architecture

**Source authority:** Per 04-architecture.md §7, 05-implementation.md §7

(Same as original plan §16 — Typesense config, programme/institution collections, sync strategy.)

---

# Section 17 — Search/Faceting Implementation

**Source authority:** Per 04-architecture.md §7, FIRST-VERTICAL-SLICE-UX.md

## 17.1 Facet Configuration

For the Programme Search page (primary vertical slice):

| Facet | Source Field | Type | Display |
|-------|-------------|------|---------|
| Institution Type | `institution_type` | string | Checkbox group: University, Polytechnic, COE, IEI |
| Award Level | `award_level` | string | Checkbox group: BSc, MSc, PhD, ND, HND, NCE |
| Delivery Mode | `delivery_mode` | string | Checkbox group: On Campus, Online, Hybrid |
| Discipline | `discipline` | string | Checkbox group: Engineering, Medicine, Arts, etc. |
| State | `state` | string | Checkbox group: Lagos, FCT, Oyo, etc. |
| Accreditation Status | `accreditation_status` | string | Checkbox group: Full, Interim, etc. |
| Currently Admitting | `is_admitting` | bool | Toggle (default-off per FIRST-VERTICAL-SLICE-UI.md §1) |

---

# Section 18 — Livewire/Blade Page Implementation Order

**Source authority:** Per FIRST-VERTICAL-SLICE-UX.md, FIRST-VERTICAL-SLICE-UI.md

The first vertical slice covers exactly these pages:

| Order | Page | Route | Livewire Component | Key Features |
|-------|------|-------|-------------------|-------------|
| 1 | Homepage | `/` | `Pages\Homepage` | Hero search, discipline browse grid (desktop) / list (mobile), popular programmes |
| 2 | Programme Search | `/programmes` | `Search\ProgrammeSearch` | Text search + 7 facets + "Currently admitting only" toggle (default-off) + result cards |
| 3 | Programme Detail | `/programmes/{slug}` | `Programme\ProgrammeDetail` | Full info, historical cut-offs (current + 2 previous, expandable), all admission pathways, tuition with "per year" label |
| 4 | Institution Detail | `/institutions/{slug}` | `Institution\InstitutionDetail` | Institution profile, programme list, accreditation status, provenance indicators |
| 5 | Admission Information | `/admissions/{cycle:slug}` | `Admission\CycleDetail` | Phase timeline, deadlines, policies, cut-off marks |

## 18.1 UX/UI Conformance (Per FIRST-VERTICAL-SLICE-UX.md, FIRST-VERTICAL-SLICE-UI.md)

| # | UX Requirement | Implementation |
|---|---------------|---------------|
| 1 | "Currently admitting only" toggle | Default-off; always visible; one tap to activate |
| 2 | Historical cut-offs | Current + 2 previous cycles shown, expandable for more |
| 3 | Annual tuition | Display with "per year" label (Nigerian fees are annual) |
| 4 | All admission pathways | All visible with separate cut-offs (UTME, Direct Entry, etc.) |
| 5 | Mobile filter | Bottom sheet / drawer on mobile, sidebar on desktop |
| 6 | Discipline browse | Grid on desktop, list on mobile |
| 7 | Loading states | Skeleton/shimmer states on all async content |
| 8 | Empty states | No-results illustration + search suggestions |
| 9 | Error states | Graceful degradation: Typesense down → "temporarily unavailable" |
| 10 | Breadcrumbs | Home → Search → Programme; Home → Institution |
| 11 | Trust/provenance indicators | Source name + last verified date on detail pages |
| 12 | Accessibility | ARIA labels, keyboard navigation, focus management, 44px tap targets |
| 13 | Responsive | Mobile-first: 375px, 768px, 1280px breakpoints |

---

# Section 19 — UX/UI Implementation Order

**Source authority:** Per PRODUCT-EXPERIENCE-ARCHITECTURE.md, FIRST-VERTICAL-SLICE-UI.md

## 19.1 Tailwind v4 Configuration (CSS-based)

**ARCHITECTURAL DECISION:** Tailwind CSS v4 uses `@theme` in CSS, not `tailwind.config.js`. The JS config file is eliminated.

```css
/* resources/css/app.css */
@import "tailwindcss";

@theme {
    --color-brand-50: #eff6ff;
    --color-brand-100: #dbeafe;
    --color-brand-500: #3b82f6;
    --color-brand-600: #2563eb;
    --color-brand-700: #1d4ed8;
    --color-brand-900: #1e3a5f;
    --color-success-500: #22c55e;
    --color-warning-500: #f59e0b;
    --color-danger-500: #ef4444;
    --font-sans: 'Inter', system-ui, sans-serif;
}
```

**IMPLEMENTATION CONVENTION:** No `tailwind.config.js` file. All theme customization in `resources/css/app.css` using `@theme` directive. Tailwind v4 auto-detects content paths.

## 19.2 Component Library

| Component | Type | Used On | Notes |
|-----------|------|---------|-------|
| `x-search-input` | Blade | Homepage, Search | Debounced, with clear button |
| `x-facet-filter` | Blade | Search | Checkbox group with count badges |
| `x-result-card` | Blade | Search | Programme result card |
| `x-accreditation-badge` | Blade | Detail pages | Color-coded: green/yellow/red/gray |
| `x-phase-timeline` | Blade | Admission page | Visual stepper |
| `x-cut-off-table` | Blade | Programme, Admission | Current + 2 previous, expandable |
| `x-breadcrumbs` | Blade | All detail pages | Links chain |
| `x-empty-state` | Blade | Search (no results) | Illustration + suggestions |
| `x-trust-signal` | Blade | Detail pages | Source + verified date |
| `x-skeleton` | Blade | All pages | Shimmer loading state |
| `x-admitting-toggle` | Blade | Search | "Currently admitting only" toggle |
| `x-tuition-display` | Blade | Programme detail | Amount + "per year" label |

---

# Section 20 — Test Strategy

**Source authority:** Per 05-implementation.md §9, 04-architecture.md §8

## 20.1 Test Categories

| Category | Scope | Framework | Target Coverage | Location |
|----------|-------|-----------|-----------------|----------|
| **Unit** | VOs, Enums, Casts, Domain methods | PHPUnit | 90%+ | `tests/Unit/` |
| **Integration** | Models + DB, Search index, Provenance | PHPUnit | 80%+ | `tests/Feature/` |
| **Feature** | Actions, Livewire components, Policies | PHPUnit | 70%+ | `tests/Feature/` |
| **Browser** | Vertical slice user journeys | Laravel Dusk | Key paths only | `tests/Browser/` |

## 20.2 Provenance/Lineage Tests (Corrected — Per §14 of this plan)

| Test Class | What It Tests |
|------------|--------------|
| `CategoryAProvenanceTest` | All Category A fields always get field_provenance on write |
| `CategoryBProvenanceTest` | Category B fields get provenance only on conflict |
| `SupersessionChainTest` | field_provenance superseded_by_id chain integrity |
| `EditorialProvenanceTest` | source_id NULL = editorial assertion, provenance still recorded |
| `SourceDeprecationTest` | Deprecated source → TrustSignal cascade for affected entities |
| `ExternalIdentifierLifecycleTest` | assign → retire → supersede chain, partial unique indexes |
| `IdentifierReassignmentTest` | ExternalIdentifier retired, new active with same type+authority |
| `ImportIdempotencyTest` | Re-run same import → no duplicate entities, same result |
| `WrongEntityMatchTest` | Fuzzy match confidence < 0.50 → new entity, not merge |
| `TrustSignalCalculationTest` | TrustSignal computed correctly from provenance + verification + source reliability |
| `CanonicalVsObservedBoundaryTest` | Entity-level JSONB provenance vs field_provenance boundary correctness |

---

# Section 21 — Development Seed-Data Strategy

**Source authority:** Per 05-implementation.md §5

## 21.1 Development Seeder Data

### Institutions (20+)

Includes at least one of each InstitutionType value:
- Universities (14+): University of Lagos, University of Ibadan, etc.
- Polytechnics (3): Yaba College of Technology, Kaduna Polytechnic, Federal Polytechnic Bida
- College of Education (2): Alvan Ikoku FCE, FCE Kano
- Innovation Enterprise Institution (1): IIE example

### Edge Case Fixtures (Required)

| Fixture | Purpose |
|---------|---------|
| Programme with no cut-off mark | Test empty cut-off display |
| Conflicting provenance (two sources disagree) | Test Category B provenance recording |
| Superseded provenance chain | Test superseded_at/superseded_by_id |
| Deprecated source | Test TrustSignal cascade |
| Historical admission cycle (closed/archived) | Test historical data display |
| Closed institution | Test Closed terminal state, no operations |
| Multiple admission pathways (UTME + DE) | Test pathway display on detail page |
| Programme with Prospective status | Test non-Admitting status display |
| Scholarship in Draft status | Test Draft→Announced transition |

---

# Section 22 — First Vertical Slice Implementation Sequence

**Source authority:** Per FIRST-VERTICAL-SLICE-UX.md, 04-architecture.md §9

The vertical slice is EXACTLY: **Homepage → Programme Search → Faceted Results → Programme Detail → Institution Detail → Admission Information** — no more.

## 22.1 First Slice Table Dependencies

Each table needed for the first slice and its justification:

| Table | Justification |
|-------|--------------|
| `users` | Auth context for admin operations |
| `institutions` | Core entity: Institution Detail page |
| `programmes` | Core entity: Programme Search + Detail pages |
| `disciplines` | Primary facet and browse dimension |
| `education_authorities` | FK from institutions, admission cycles |
| `admission_cycles` | Admission Information page |
| `admission_policies` | Cut-off marks and admission requirements on detail pages |
| `cut_off_marks` | Cut-off data on Programme Detail and Admission pages |
| `information_sources` | Provenance/trust indicators on detail pages |
| `scholarship_providers` | FK from scholarships |
| `scholarships` | Related scholarship data |
| `accreditation_records` | Accreditation badge on detail pages |
| `external_identifiers` | JAMB/NUC codes display on Institution Detail |
| `field_provenance` | Trust indicators on detail pages |
| `countries` | Reference data for location display |

## 22.2 Route Definitions

```php
// routes/web.php
Route::get('/', Homepage::class);                                    // Homepage
Route::get('/programmes', ProgrammeSearch::class);                    // Search
Route::get('/programmes/{programme:slug}', ProgrammeDetail::class);   // Detail
Route::get('/institutions/{institution:slug}', InstitutionDetail::class); // Institution
Route::get('/admissions/{admissionCycle:slug}', CycleDetail::class);  // Admission (slug-based, public SEO resource)
```

**ARCHITECTURAL DECISION:** Slug-based URLs for all public pages including AdmissionCycle (Per 04-architecture.md §9). AdmissionCycle is a public SEO resource.

---

# Section 23 — Contract-Freeze Checkpoint

**Source authority:** Per 04-architecture.md, 03-domain.md

**This is a hard gate, not a soft checkpoint.** No parallel Phase 2 work may begin until every contract listed below is frozen and verified. Any change to a frozen contract after this gate requires a formal Change Proposal per 02-decisions.md §8.

Before parallel domain implementation begins (PHASE 2), the following contracts must be frozen and cannot be changed without a change proposal:

| Contract | Detail |
|----------|--------|
| `HasProvenance` trait interface | `getProvenance()`, `setProvenance()`, `recordEntityProvenance()`, `fieldProvenance()` relationship |
| `ExternalIdentifier` relationships | Morphable entity, authority, source, replacedBy |
| `FieldProvenance` relationships | Morphable entity, source, supersededBy |
| morphMap aliases | All 12 aliases in `Relation::enforceMorphMap()` |
| VO cast conventions | All 10 cast classes, JSONB roundtrip contract |
| Domain event naming | All 29 event class names and payloads |

---

# Section 24 — Definition of Done for Each Phase

## PHASE 0 — Bootstrap

| Criterion | Verification Method |
|-----------|---------------------|
| Laravel ^13.0 project created and runs | `php artisan serve` responds |
| All 14 packages installed with zero conflicts | `composer validate` passes |
| Docker Compose runs PostgreSQL 16+, Redis 7+, Typesense | `docker compose ps` shows all healthy |
| Tailwind v4 configured (CSS-based, no JS config) | `@theme` in app.css, no tailwind.config.js |
| 11 RBAC roles + permissions seeded | `Role::count() === 11` |
| CI pipeline configured | Pipeline runs green |

## PHASE 1 — Database

| Criterion | Verification Method |
|-----------|---------------------|
| All 58 migrations run without error | `php artisan migrate` exits 0 |
| `php artisan migrate:fresh` works (idempotent) | Run twice, compare schemas |
| All FK constraints enforced | Attempt invalid FK insert → fails |
| All CHECK constraints enforced | Attempt invalid confidence → fails |
| Partial unique indexes INV-EI1, INV-EI2 work | Insert duplicate active identifier → fails |
| All 16 enum columns cast correctly | Create entity with each enum → read back → correct enum instance |
| MorphMap enforced | Attempt polymorphic insert with unregistered type → fails |
| is_published + published_at on Institution, Programme, Scholarship | Columns exist, defaults correct |

## PHASE 2 — Domain

| Criterion | Verification Method |
|-----------|---------------------|
| All 16 models created with relationships | Relationship tests pass |
| All 12 VOs + casts work (JSONB roundtrip) | VO test suite passes |
| All 16 enums have label() method | Enum test suite passes |
| 5 aggregate root state machines enforced | Domain method tests pass (invalid transitions throw) |
| Institution: Provisional→Operational→Suspended→Closed | Lifecycle test suite |
| Programme: introduce()→Admitting→Suspended→Discontinued | Lifecycle test suite |
| Scholarship: Draft→Announced→Open→Closed→Expired | Lifecycle test suite |
| All 20 canonical Actions implemented | Action test suite passes |
| All 29 canonical domain events dispatch correctly | Event test passes |
| Contract-freeze checkpoint met | All contracts in §23 are frozen |
| All Laravel Policies implemented | Policy matrix (role × action) passes |
| HasProvenance trait works on all applicable models | Provenance test suite passes |
| AdmissionCycle lockForUpdate concurrency safe | Concurrent advance test passes |

## PHASE 3 — Data Lineage/Import

| Criterion | Verification Method |
|-----------|---------------------|
| Import pipeline works end-to-end | CSV upload → verify → apply → search indexed |
| Import idempotency: re-run same import → same result | Idempotency test |
| Category A/B/C provenance logic correct | Provenance test suite (§20.2) |
| ExternalIdentifier lifecycle works | assign → retire → supersede test |
| TrustSignal calculation correct | TrustSignal test |
| Source deprecation cascades correctly | Deprecated source → affected entity trust cascade |
| Staging cleanup works | StagingCleanupTest |

## PHASE 4 — Search/Projections

| Criterion | Verification Method |
|-----------|---------------------|
| Typesense collections created | `php artisan scout:index` succeeds |
| Search index syncs on domain events | Create programme → searchable in Typesense |
| Faceted search returns correct facet counts | Feature test |
| "Currently admitting only" toggle works | Feature test |
| Instant search responds in < 200ms | Performance benchmark |
| Development data indexed and searchable | Search for "Computer Engineering" → returns results |

## PHASE 5 — First Vertical Slice

| Criterion | Verification Method |
|-----------|---------------------|
| Homepage renders with hero search + discipline browse | Browser test |
| Programme Search: type "computer" → see results | Browser test |
| All 7 facets work | Feature test per facet |
| "Currently admitting only" toggle (default-off) works | Feature test |
| Programme Detail: all sections render, historical cut-offs (current + 2, expandable) | Browser test |
| All admission pathways visible on detail | Browser test |
| Tuition with "per year" label | Browser test |
| Institution Detail: programme list + provenance indicators | Browser test |
| Admission Information: phase timeline renders | Browser test |
| Mobile filter drawer works | Browser test at 375px |
| Loading/skeleton states on all pages | Visual test |
| Empty states on no-results | Browser test |
| Error states (Typesense down) | Feature test |
| Breadcrumbs on all detail pages | Browser test |
| Trust/provenance indicators visible | Browser test |
| All pages responsive (375px, 768px, 1280px) | Browser test |
| SEO meta tags on all pages | Feature test |
| AdmissionCycle slug-based routing | Feature test |
| End-to-end Dusk smoke test | Full user journey passes |
| Lighthouse Performance >= 80 (mobile) | Lighthouse CI |

## PHASE 6 — Hardening/Testing

| Criterion | Verification Method |
|-----------|---------------------|
| All unit tests pass | `php artisan test --testsuite=Unit` |
| All feature tests pass | `php artisan test --testsuite=Feature` |
| All browser tests pass | `php artisan dusk` |
| Provenance/lineage test suite passes | §20.2 tests all pass |
| Code coverage meets targets | PHPUnit coverage report |
| No Pint violations | `./vendor/bin/pint --test` |
| No PHPStan errors (level 6) | `./vendor/bin/phpstan analyse` |
| Concurrency test: AdmissionCycle phase advance | 10 concurrent requests → no race conditions |
| Performance: Search page < 200ms | Benchmark |
| Security review: mass assignment, authorization | No `$guarded = ['*']`, all Policies tested |
| Graceful degradation: Typesense down | Search page shows "temporarily unavailable" |
| Queue failure handling | Force failure → logged → retry succeeds |
| Edge case seed data passes all tests | Fixtures in §21.1 all render correctly |

---

# 7-Phase Implementation Summary

## PHASE 0 — Bootstrap

**Goal:** Bootstrapped Laravel ^13.0 project with all packages, infrastructure, CI, and Tailwind v4 CSS-based config.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P0-1 | Create Laravel project with PHP 8.5+ | PHP 8.5 installed | `php artisan --version` shows Laravel 13.x |
| P0-2 | Install all 14 packages (§2) | P0-1 | `composer validate` passes |
| P0-3 | Configure Docker Compose (§3) | P0-2 | All 4 services healthy |
| P0-4 | Create directory structure (§1.2) | P0-1 | All directories exist |
| P0-5 | Configure morphMap, timezone, locale (§1.3) | P0-2 | `php artisan config:cache` succeeds |
| P0-6 | Configure Tailwind v4 (CSS @theme, no JS config) + Filament + Livewire | P0-2 | Admin panel renders at `/admin` |
| P0-7 | Set up CI pipeline (PHPUnit, Pint, PHPStan) | P0-1 | CI runs green |
| P0-8 | Create `.env.example` with all required vars | P0-3 | New developer can start |

**Duration estimate:** 1-2 days.

---

## PHASE 1 — Database

**Goal:** All 58 migrations run, all constraints enforced, reference data seeded, is_published/published_at columns on all publishable entities.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P1-1 | Author Layers 1-2 migrations (users, auth, roles, permissions) | P0 complete | `php artisan migrate` succeeds |
| P1-2 | Author Layer 3 migrations (reference data) | P1-1 | Countries, currencies, qualifications, disciplines tables exist |
| P1-3 | Author Layer 4 migrations (domain tables with is_published/published_at) | P1-2 | All 14 domain tables with correct enums and FK constraints |
| P1-4 | Author Layers 5-10 migrations (org, content, engagement, community, settings, SEO, infrastructure) | P1-3 | All supplementary tables exist |
| P1-5 | Author Layer 11 staging migrations (import_batches, pending_imports UUID PKs) | P1-3 | UUID PKs work |
| P1-6 | Author constraint migration (CHECK + partial indexes) | P1-5 | All constraints enforce correctly |
| P1-7 | Seed reference data (§6) | P1-2 | Country count = 250, etc. |
| P1-8 | Seed education authorities | P1-7 | JAMB, NUC, NBTE, NCCE, WAEC + state authorities |
| P1-9 | Seed RBAC roles + permissions | P1-1 | Role count = 11 |
| P1-10 | Write constraint verification tests | P1-6 | All FK, CHECK, partial index tests pass |
| P1-11 | Verify `migrate:fresh` idempotency | P1-10 | Run 3 times → same schema |

**Duration estimate:** 3-5 days.

---

## PHASE 2 — Domain

**Goal:** All models, VOs, enums, Actions, events, policies implemented. Contract-freeze checkpoint met.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P2-1 | Implement all 16 enums with label() | P1 complete | Enum test suite passes |
| P2-2 | Implement all 12 VOs + cast classes | P2-1 | VO roundtrip tests pass |
| P2-3 | Implement EducationAuthority model | P2-1 | Model + relationship tests pass |
| P2-4 | Implement Institution aggregate root (Provisional→Operational→Suspended→Closed lifecycle) | P2-3 | Lifecycle test suite passes |
| P2-5 | Implement Programme aggregate root (introduce→Admitting→Suspended→Discontinued) | P2-4 | State machine tests pass |
| P2-6 | Implement Scholarship + ScholarshipProvider | P2-1 | Draft→Announced→Open→Closed→Expired lifecycle |
| P2-7 | Implement AdmissionCycle + PhaseSequence VO + lockForUpdate | P2-3 | Concurrency test passes |
| P2-8 | Implement child entities (AdmissionPolicy, EligibilityPolicy, AccreditationRecord) | P2-4, P2-5, P2-7 | Relationship + cascade tests pass |
| P2-9 | Implement InformationSource aggregate root | P2-3 | Registered→Verified→Unreliable→Deprecated lifecycle |
| P2-10 | Implement CutOffMark, ExternalIdentifier, FieldProvenance | P2-4, P2-7, P2-9 | Constraint + relationship tests pass |
| P2-11 | Implement ImportBatch + PendingImport (staging) | P1 complete | UUID PK tests pass |
| P2-12 | Implement HasProvenance trait | P2-10 | Category A/B/C logic tests pass |
| **P2-13** | **CONTRACT-FREEZE CHECKPOINT** | P2-12 | All contracts in §23 are frozen; no changes without proposal |
| P2-14 | Implement all 20 canonical Actions | P2-4 through P2-10 | Authorization + transaction + event tests pass |
| P2-15 | Implement all 29 domain events + listeners | P2-14 | Event dispatch tests pass |
| P2-16 | Implement all Laravel Policies | P2-14 | Policy matrix test passes |
| P2-17 | Implement Filament admin resources | P2-14 | Admin CRUD for each aggregate root works |
| P2-18 | Configure Filament Shield | P2-16 | Role-based admin access works |
| P2-19 | Unit test coverage >= 90% for domain + models | P2-1 through P2-16 | PHPUnit coverage report |

**Duration estimate:** 10-15 days.
**Parallelizable:** P2-1 and P2-2 can run in parallel. P2-5, P2-6, P2-9 can run in parallel after P2-4 and P2-3. After contract-freeze (P2-13), domain implementation can proceed in parallel.

---

## PHASE 3 — Data Lineage/Import

**Goal:** Provenance recording, import pipeline, ExternalIdentifier lifecycle, TrustSignal calculation all functional.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P3-1 | Implement provenance recording logic (Category A/B/C) | P2-12 | Provenance test suite passes |
| P3-2 | Implement ExternalIdentifier lifecycle (assign, retire, supersede) | P2-10 | Lifecycle test passes |
| P3-3 | Implement TrustSignal calculation | P3-1 | TrustSignal test passes |
| P3-4 | Implement import adapters (JAMB, NUC, CSV) | P2-14 | Adapter test suite passes |
| P3-5 | Implement verification engine | P3-4 | Threshold tests pass |
| P3-6 | Implement import workflow jobs | P3-5 | Import end-to-end test passes |
| P3-7 | Write provenance/lineage tests (§20.2) | P3-1, P3-2, P3-3 | All lineage tests pass |

**Duration estimate:** 5-7 days.

---

## PHASE 4 — Search/Projections

**Goal:** Typesense collections created, search sync works, faceted search with "5 "Currently admitting" toggle returns correct results.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P4-1 | Configure Typesense Scout driver | P0 complete | Connection verified |
| P4-2 | Define Programme searchable array + collection schema | P2-5 | Schema validates |
| P4-3 | Define Institution searchable array + collection schema | P2-4 | Schema validates |
| P4-4 | Implement UpdateSearchIndexListener | P2-15 | Event → model searchable |
| P4-5 | Seed development data (§21) | P2 complete | All seed data including edge cases |
| P4-6 | Index development data in Typesense | P4-5 | `php artisan scout:import` succeeds |
| P4-7 | Test faceted search queries | P4-6 | Facet counts match |
| P4-8 | Test search index sync on CRUD | P4-4 | Create → searchable |
| P4-9 | Performance benchmark: search < 200ms | P4-7 | Benchmark passes |
| P4-10 | Implement SearchIndexRebuildJob (nightly) | P4-4 | Scheduled job runs |

**Duration estimate:** 3-5 days.

---

## PHASE 5 — First Vertical Slice

**Goal:** All 5 pages working end-to-end, responsive, SEO-optimized, with full UX/UI conformance.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P5-1 | Build Homepage (hero search + discipline browse) | P4 complete | Renders with search + disciplines |
| P5-2 | Build Programme Search (7 facets + "Currently admitting" toggle) | P4-7 | Type query → see results |
| P5-3 | Build facet filter + mobile drawer components | P5-2 | All facets toggle; mobile drawer works |
| P5-4 | Build result card + skeleton/empty/error states | P5-2 | All states render |
| P5-5 | Build Programme Detail (historical cut-offs, all pathways, tuition "per year") | P5-2 | All sections render |
| P5-6 | Build Institution Detail (provenance indicators) | P5-5 | Profile + programme list |
| P5-7 | Build Admission Information (slug-based route, phase timeline) | P5-5 | Timeline + policies render |
| P5-8 | Build shared components (breadcrumbs, badges, trust signals) | P5-5 through P5-7 | Components on all pages |
| P5-9 | Mobile responsive adaptations | P5-8 | Responsive at 375px, 768px, 1280px |
| P5-10 | SEO meta tags on all pages | P5-8 | Tags correct |
| P5-11 | Accessibility: ARIA, keyboard, focus | P5-8 | a11y audit passes |
| P5-12 | End-to-end Dusk smoke test | P5-10 | Full journey passes |
| P5-13 | Lighthouse performance audit | P5-12 | Performance >= 80 mobile |

**Duration estimate:** 8-12 days.

---

## PHASE 6 — Hardening/Testing

**Goal:** Production-ready quality: all tests pass, coverage met, security reviewed, performance verified.

| Step | Action | Prerequisite | Completion Criteria |
|------|--------|-------------|---------------------|
| P6-1 | Run full unit test suite | P5 complete | All pass, coverage >= 90% domain |
| P6-2 | Run full feature test suite | P5 complete | All pass, coverage >= 80% Actions |
| P6-3 | Run provenance/lineage test suite | P3-7 | All §20.2 tests pass |
| P6-4 | Run full browser test suite | P5 complete | All Dusk tests pass |
| P6-5 | Pint + PHPStan (level 6) | P5 complete | Zero violations, zero errors |
| P6-6 | Concurrency test: AdmissionCycle | P2-7 | 10 concurrent → no race conditions |
| P6-7 | Performance: all pages < 200ms | P5 complete | Benchmark passes |
| P6-8 | Security review: mass assignment, authorization | P2-16 | All Policies tested |
| P6-9 | Graceful degradation: Typesense down | P4 complete | Search shows "temporarily unavailable" |
| P6-10 | Queue failure handling | P2-15 | Force failure → logged → retry |
| P6-11 | Edge case seed data verification | P5 complete | All fixtures render correctly |
| P6-12 | Documentation: README, onboarding | P6-1 through P6-11 | New dev starts in < 30 min |

**Duration estimate:** 5-7 days.

---

## Total Estimated Timeline

| Phase | Duration | Cumulative |
|-------|----------|------------|
| PHASE 0 — Bootstrap | 1-2 days | 1-2 days |
| PHASE 1 — Database | 3-5 days | 4-7 days |
| PHASE 2 — Domain | 10-15 days | 14-22 days |
| PHASE 3 — Data Lineage/Import | 5-7 days | 19-29 days |
| PHASE 4 — Search/Projections | 3-5 days | 22-34 days |
| PHASE 5 — First Vertical Slice | 8-12 days | 30-46 days |
| PHASE 6 — Hardening/Testing | 5-7 days | 35-53 days |

**Total: 35-53 working days (7-11 weeks for a team of 2-3 developers).**

---

## Decision Marker Count

| Marker Type | Count | Notes |
|-------------|-------|-------|
| **ARCHITECTURAL DECISION** | 12 | Frozen ADRs: Laravel 13, PostgreSQL, Typesense, morphMap, Actions, Tailwind v4 CSS, slug routing, publication orthogonality, 80/20 provenance, provenance immutability, uniform BIGINT PKs, search-first |
| **IMPLEMENTATION CONVENTION** | 15+ | Developer choices: directory grouping, Tailwind @theme, enum label(), VO immutability, etc. |

---

## Appendix A — Canonical Document Cross-Reference

| Short Name | Full Path | Referenced In |
|------------|-----------|---------------|
| 01-business.md | `canonical/01-business.md` | §1 (vision), §22 (vertical slice user) |
| 02-decisions.md | `canonical/02-decisions.md` | §1 (ADR-1), §2 (stack), §4 (BD-1, BD-3, BD-5, ND-4, ND-5), §5 (RBAC), §6 (search) |
| 03-domain.md | `canonical/03-domain.md` | §7 (models), §8 (VOs), §9 (enums), §10 (aggregates), §11 (Actions), §12 (events) |
| 04-architecture.md | `canonical/04-architecture.md` | §1 (principles), §7 (search), §9 (SEO), §13 (policies) |
| 05-implementation.md | `canonical/05-implementation.md` | §1 (baseline), §2 (packages), §4 (migrations), §9 (testing) |
| 06-data-acquisition.md | `canonical/06-data-acquisition.md` | §14 (provenance), §15 (import pipeline) |

---

*End of IMPLEMENTATION-PLAN.md (Corrected). All lifecycle states, enums, actions, events, and table names conform to canonical documents. Publication is orthogonal to domain lifecycle. Contract-freeze checkpoint added before parallel domain implementation. 7-phase structure with dedicated Data Lineage/Import phase. Tailwind v4 CSS-based configuration. UX/UI conformance verified against FIRST-VERTICAL-SLICE-UX.md and FIRST-VERTICAL-SLICE-UI.md.*
