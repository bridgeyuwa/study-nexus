# StudyNexus — Implementation Plan Correction Report

**Date:** 2026-08-10
**Status:** COMPLETE
**Scope:** 20 correction areas applied to IMPLEMENTATION-PLAN.md
**Authority:** Canonical documents (01-business.md through 06-data-acquisition.md) + product-experience docs

---

## Methodology

Each finding was identified by comparing the original IMPLEMENTATION-PLAN.md against the canonical frozen baseline documents. Every discrepancy is classified with:

- **Finding**: What was wrong in the original plan
- **Action**: corrected / retained / deferred / rejected
- **Reason**: Why the action was taken
- **Source Authority**: Which canonical document section mandates the correction
- **Impact**: What changes in the plan as a result

---

## Finding 1 — Institution Lifecycle States

| Field | Value |
|-------|-------|
| **Finding** | Plan used `draft`, `active`, `deprecated` as InstitutionStatus values with `establish()`→active and `deprecate()`→deprecated operations |
| **Canonical** | InstitutionStatus = `Provisional`, `Operational`, `Suspended`, `Closed`. Operations: `establish()`→Operational, `suspend()`, `reactivate()`, `close()`, `rename()` |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §8 explicitly defines the Institution state machine: Provisional→Operational (via establish), Operational↔Suspended (via suspend/reactivate), Operational/Suspended→Closed (terminal). No `draft` or `active` or `deprecated` states exist. `deprecate()` does not exist on Institution. |
| **Source Authority** | 03-domain.md §8 (Entity Behaviours — Educational Institution) |
| **Impact** | InstitutionStatus enum changed from 3 values to 4. `establish()` now transitions to Operational (not active). `deprecate()` removed. `suspend()`, `reactivate()`, `close()`, `rename()` added. State machine diagram rewritten. Model template rewritten. All Institution-related Actions, events, and tests updated. |

---

## Finding 2 — Institution Type Values

| Field | Value |
|-------|-------|
| **Finding** | Plan had 6 InstitutionType values: `university`, `polytechnic`, `monotechnic`, `college_of_education`, `innovative_enterprise_institution`, `specialized_institution` |
| **Canonical** | 4 values only: `University`, `Polytechnic`, `CollegeOfEducation`, `InnovationEnterpriseInstitution` |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §6 explicitly lists 4 values. `Monotechnic` and `SpecializedInstitution` do not exist in the canonical enum. Per ADR-15, expansion beyond 4 values triggers evaluation of migration to reference data table. |
| **Source Authority** | 03-domain.md §6 (Enums — InstitutionType) |
| **Impact** | InstitutionType enum reduced from 6 to 4 values. Seed data updated. Search facets updated. Enum implementation template updated. |

---

## Finding 3 — Publication vs Domain Lifecycle

| Field | Value |
|-------|-------|
| **Finding** | Plan used `published` as a ProgrammeStatus value (draft/published/suspended/discontinued) and had `PublishInstitution`, `PublishProgramme`, `PublishScholarship` Actions |
| **Canonical** | `is_published` (boolean) + `published_at` (nullable timestamp) are separate from domain lifecycle. Publication ≠ status. No `ProgrammeStatus::Published`. |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §8 explicitly states: "Publication is orthogonal to domain lifecycle — visibility on the public site is controlled by `is_published` AND lifecycle status allowing public display. `published_at` records the first publication date and is not rewritten on subsequent publication cycles. No publication_status enum. No publication state machine." |
| **Source Authority** | 03-domain.md §8 (Publication attributes) |
| **Impact** | `is_published` + `published_at` columns added to Institution, Programme, Scholarship migrations. `published` removed from ProgrammeStatus. `PublishInstitution`, `PublishProgramme`, `PublishScholarship` Actions removed (publication is application-level, not a domain Action). Scopes added: `scopePublished()`. |

---

## Finding 4 — Programme Lifecycle States

| Field | Value |
|-------|-------|
| **Finding** | Plan had ProgrammeStatus = `draft`, `published`, `suspended`, `discontinued` with `introduce()`, `publish()`, `suspend()`, `discontinue()` |
| **Canonical** | ProgrammeStatus = `Prospective`, `Admitting`, `Suspended`, `Discontinued`. Operations: `introduce()`→Admitting, `suspendAdmission()`, `resumeAdmission()`, `discontinue()` |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §8 explicitly defines Programme state machine. `introduce()` creates the programme in Admitting status (not draft→published). `suspendAdmission()` and `resumeAdmission()` are the correct domain method names. No `publish()` method exists on Programme. |
| **Source Authority** | 03-domain.md §8 (Entity Behaviours — Programme) |
| **Impact** | ProgrammeStatus enum values changed. Domain methods renamed. State machine diagram rewritten. Programme model template updated. Actions and events updated. |

---

## Finding 5 — Scholarship Status Missing Draft

| Field | Value |
|-------|-------|
| **Finding** | Plan had ScholarshipStatus = `announced`, `open`, `closed`, `expired`, `withdrawn` (5 values) |
| **Canonical** | ScholarshipStatus = `Draft`, `Announced`, `Open`, `Closed`, `Expired`, `Withdrawn` (6 values) |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §6 explicitly lists 6 values including `Draft`. The Draft→Announced transition via `announce()` is a core lifecycle step. |
| **Source Authority** | 03-domain.md §6 (Enums — ScholarshipStatus) |
| **Impact** | ScholarshipStatus enum expanded from 5 to 6 values. `announce()` transitions Draft→Announced. Seed data updated. |

---

## Finding 6 — Non-Canonical Actions

| Field | Value |
|-------|-------|
| **Finding** | Plan had non-canonical Actions: `UpdateInstitution`, `DeprecateInstitution`, `PublishInstitution`, `UpdateProgramme`, `PublishProgramme`, `UpdateScholarship`, `PublishScholarship`, `RecordCutOffMark`, `CloseAdmissionCycle` |
| **Canonical** | Exactly 20 Actions: CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, PublishAdmissionPolicy, RecordAccreditation, CreateProgramme, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §5 defines exactly 20 Actions with explicit justification for each. Non-canonical Actions were CRUD operations that don't meet the Action Criterion (4 conditions from frozen baseline F4). Updates are application-layer (Filament/observer). Publication is not a domain Action. |
| **Source Authority** | 03-domain.md §5 (Actions) |
| **Impact** | Action directory structure rewritten. 9 non-canonical Actions removed. Correct 20 Actions implemented. Event mappings updated. |

---

## Finding 7 — Table Count and Names

| Field | Value |
|-------|-------|
| **Finding** | Plan had ~41 tables with non-canonical names: `bookmarks` (should be `saves`), `comparisons` (should be `comparison_sets`), `settings` (should be `platform_settings`), `activity_log` (should be `activities`), `community_posts` (should be `community_questions`), `community_likes` (should be `community_votes`), `content_pages` (should be `articles`), `content_sections` (should be `guide_sections`), `seo_meta` (should be `url_redirects`), `alerts` (no canonical match) |
| **Canonical** | 58 tables per 05-implementation.md §4 with canonical names |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 05-implementation.md §4.1 provides the authoritative 58-table inventory with canonical names. Table classification (A/B/C) added to indicate first-slice requirement. |
| **Source Authority** | 05-implementation.md §4 (Database Schema) |
| **Impact** | Table inventory expanded from ~41 to 58. All table names corrected to canonical. Table classification (A=First Slice, B=Platform Foundation, C=Deferred) added. Migration count recalculated. Dependency graph updated. |

---

## Finding 8 — Enum Names and Values

| Field | Value |
|-------|-------|
| **Finding** | Plan had wrong enum names: `ProgrammeLevel` (should be `AwardLevel`), `AwardType` (should be separate), `ModeOfStudy` (should be `DeliveryMode` + `AdmissionMode`), `AdmissionCycleStatus` (canonical uses Upcoming/Active/Closed/Archived, not Announced/Activated/Closed/Archived), `VerificationStatus` (should be field_provenance-only, not a top-level domain enum), `ContentType`, `ResourceType` (not canonical domain enums). Missing: `OwnershipType`, `QualificationStatus`, `CoverageType`, `AdmissionMode` |
| **Canonical** | 16 enums: InstitutionType, AwardLevel, AdmissionMode, AccreditationStatus, PolicyStatus, ProgrammeStatus, ScholarshipStatus, InstitutionStatus, SourceReliability, InformationCategory, AuthorityType, ProviderType, OwnershipType, DeliveryMode, QualificationStatus, CoverageType |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §6 defines exactly 16 enums with correct names and values. Wrong enum names create wrong domain semantics. |
| **Source Authority** | 03-domain.md §6 (Enums) |
| **Impact** | All 16 enums rewritten with canonical names and values. Enum directory structure updated. Model casts updated. Search projections updated. |

---

## Finding 9 — Domain Event Names

| Field | Value |
|-------|-------|
| **Finding** | Plan had non-canonical event names: `InstitutionDeprecated`, `ProgrammePublished`, `ScholarshipOpened`, `AccreditationGranted`, `AccreditationRevoked`, `CutOffMarkRecorded`, `CutOffMarkCorrected`, `ExternalIdentifierAssigned`, `ExternalIdentifierRetired`, `ProvenanceRecorded`, `AdmissionCycleArchived`, `InformationSourceRegistered` |
| **Canonical** | 29 events per 03-domain.md §4 with exact names including: `InstitutionSuspended`, `InstitutionReactivated`, `InstitutionClosed`, `InstitutionsMerged`, `InstitutionRenamed`, `InstitutionalAdmissionPolicyPublished`, `ProgrammeAdmissionSuspended`, `ProgrammeAdmissionResumed`, `ProgrammeAdmissionPolicyPublished`, `ProgrammeAccredited`, `ScholarshipEligibilityPolicyPublished`, `ScholarshipApplicationsOpened`, `ScholarshipApplicationsClosed`, `ScholarshipTargetsUpdated`, `InformationSourceDeprecated`, `QualificationDeprecated` |
| **Action** | **CORRECTED** |
| **Reason** | Canonical 03-domain.md §4 defines exactly 29 events with exact names and payloads. Non-canonical events either don't exist or have wrong names. |
| **Source Authority** | 03-domain.md §4 (Domain Events) |
| **Impact** | All 29 event class names rewritten. Event/listener registration updated. Action event dispatch updated. |

---

## Finding 10 — Migration Count

| Field | Value |
|-------|-------|
| **Finding** | Plan had ~42 migrations for ~41 tables |
| **Canonical** | 58 tables require 58+ migrations (greenfield) |
| **Action** | **CORRECTED** |
| **Reason** | Greenfield project with 58 canonical tables. Each table gets its own migration. Staging tables use UUID PKs. Constraint migration is separate. |
| **Source Authority** | 05-implementation.md §4 |
| **Impact** | Migration count recalculated to 58 across 11 layers. First slice requires 32 migrations (Layers 1-5 + staging). |

---

## Finding 11 — First Slice Dependencies

| Field | Value |
|-------|-------|
| **Finding** | Plan did not justify each table needed for the first vertical slice |
| **Canonical** | Slice: Homepage→Programme Search→Faceted Results→Programme Detail→Institution Detail→Admission Information |
| **Action** | **CORRECTED** |
| **Reason** | Each table in the first slice must be justified by the user journey it supports. Without justification, unnecessary tables may be included or necessary tables omitted. |
| **Source Authority** | FIRST-VERTICAL-SLICE-UX.md |
| **Impact** | §22.1 added with table-by-table justification for the first slice. |

---

## Finding 12 — UX/UI Conformance

| Field | Value |
|-------|-------|
| **Finding** | Plan had minimal UX/UI coverage — no mention of "Currently admitting only" toggle, historical cut-offs display, tuition "per year" label, all admission pathways visible, mobile filter drawer, discipline browse, loading/empty/error states, breadcrumbs, trust indicators, accessibility, responsive behavior |
| **Canonical** | FIRST-VERTICAL-SLICE-UX.md and FIRST-VERTICAL-SLICE-UI.md specify these requirements |
| **Action** | **CORRECTED** |
| **Reason** | Product experience documents are canonical requirements for the first vertical slice. The implementation plan must conformance. |
| **Source Authority** | FIRST-VERTICAL-SLICE-UX.md, FIRST-VERTICAL-SLICE-UI.md |
| **Impact** | §18.1 added with 13 UX/UI conformance requirements. Phase 5 definition of done expanded. Component library expanded. |

---

## Finding 13 — Seed Data

| Field | Value |
|-------|-------|
| **Finding** | Plan had basic seed data but missing edge cases: no programme with no cut-off, no conflicting provenance, no superseded provenance, no deprecated source, no historical cycle, no closed institution, no multiple pathways, no InnovationEnterpriseInstitution type, no historical cut-offs |
| **Canonical** | Edge cases are required for testing provenance, lifecycle boundaries, and UX display |
| **Action** | **CORRECTED** |
| **Reason** | Without edge case seed data, developers cannot test boundary conditions during development. Each edge case exercises a specific code path that would otherwise go untested until production. |
| **Source Authority** | Derived from 03-domain.md §8 (lifecycle boundaries) + 06-data-acquisition.md §8 (provenance) |
| **Impact** | §21.1 expanded with 9 required edge case fixtures. |

---

## Finding 14 — Provenance/Lineage Tests

| Field | Value |
|-------|-------|
| **Finding** | Plan had no dedicated provenance/lineage test suite |
| **Canonical** | Provenance is a core architectural concern (ND-4/ADR-23) requiring dedicated tests |
| **Action** | **CORRECTED** |
| **Reason** | The 80/20 provenance model, ExternalIdentifier lifecycle, supersession chains, import idempotency, and TrustSignal calculation are all critical correctness properties that require explicit test coverage. |
| **Source Authority** | 06-data-acquisition.md §8, 03-domain.md §15 |
| **Impact** | §20.2 added with 11 dedicated provenance/lineage test classes. Phase 6 definition of done expanded. |

---

## Finding 15 — Queues/Infrastructure Tables

| Field | Value |
|-------|-------|
| **Finding** | Plan included `jobs`, `failed_jobs`, `notifications`, `activity_log`, `media` tables without justification |
| **Canonical** | These are infrastructure tables that are only needed when their packages are actually used |
| **Action** | **RETAINED** (with classification) |
| **Reason** | All five packages are installed in §2 (spatie/laravel-activitylog, spatie/laravel-medialibrary, Laravel notifications, Laravel queue). The tables are therefore required. However, they are classified: `jobs`/`failed_jobs`/`sessions`/`cache` = Category A (needed for app to function), `activities`/`media`/`tags`/`taggables` = Category B (platform foundation), `notifications` = Category C (deferred until notification feature). |
| **Source Authority** | 05-implementation.md §4 |
| **Impact** | Tables retained but classified. `activity_log` renamed to canonical `activities`. |

---

## Finding 16 — Routes

| Field | Value |
|-------|-------|
| **Finding** | Plan used `{admissionCycle}` (ID-based) for admission cycle route |
| **Canonical** | AdmissionCycle is a public SEO resource that should use slug-based routing |
| **Action** | **CORRECTED** |
| **Reason** | Per 04-architecture.md §9, slug-based URLs are used for all public pages. AdmissionCycle pages are public-facing and SEO-critical. |
| **Source Authority** | 04-architecture.md §9, FIRST-VERTICAL-SLICE-UI.md |
| **Impact** | Route changed from `/admissions/{admissionCycle}` to `/admissions/{admissionCycle:slug}`. AdmissionCycle model requires `HasSlug` trait. |

---

## Finding 17 — Decision Marker Counts

| Field | Value |
|-------|-------|
| **Finding** | Plan did not count actual AD and IC markers |
| **Canonical** | Required for traceability |
| **Action** | **CORRECTED** |
| **Reason** | Accurate marker counts ensure all architectural decisions are tracked and all implementation conventions are identified as changeable. |
| **Source Authority** | Implementation plan convention |
| **Impact** | Decision marker count added: 12 ARCHITECTURAL DECISION markers, 15+ IMPLEMENTATION CONVENTION markers. |

---

## Finding 18 — Tailwind v4 Configuration

| Field | Value |
|-------|-------|
| **Finding** | Plan had `tailwind.config.js` with JS-based theme configuration |
| **Canonical** | Tailwind CSS v4 uses `@theme` in CSS, not JS config |
| **Action** | **CORRECTED** |
| **Reason** | Tailwind v4 eliminated the JS config file. Theme customization is done via `@theme` directive in CSS. The `tailwind.config.js` approach is the v3 API, not v4. |
| **Source Authority** | Tailwind CSS v4 documentation |
| **Impact** | `tailwind.config.js` removed. `resources/css/app.css` rewritten with `@theme` directive. All theme values (colors, fonts) moved to CSS custom properties. |

---

## Finding 19 — Parallel Work / Contract-Freeze

| Field | Value |
|-------|-------|
| **Finding** | Plan noted some steps as "parallelizable" but had no checkpoint to freeze contracts before parallel domain implementation |
| **Canonical** | Parallel work requires a contract-freeze checkpoint to prevent divergent implementations |
| **Action** | **CORRECTED** |
| **Reason** | When multiple developers implement domain aggregates in parallel, they must agree on shared interfaces. Without a checkpoint, one developer's HasProvenance trait change breaks another's ExternalIdentifier implementation. |
| **Source Authority** | Derived from 04-architecture.md §4 |
| **Impact** | §23 added with contract-freeze checkpoint. P2-13 step added to Phase 2. Frozen contracts: HasProvenance interface, ExternalIdentifier relationships, FieldProvenance relationships, morphMap aliases, VO cast conventions, domain event naming. |

---

## Finding 20 — Phase Structure

| Field | Value |
|-------|-------|
| **Finding** | Plan had 5 phases (P0-P5) with Search/Projections and Data/Import merged |
| **Canonical** | 7 phases are needed: PHASE 0 (Bootstrap), PHASE 1 (Database), PHASE 2 (Domain), PHASE 3 (Data Lineage/Import), PHASE 4 (Search/Projections), PHASE 5 (First Vertical Slice), PHASE 6 (Hardening/Testing) |
| **Action** | **CORRECTED** |
| **Reason** | Data lineage/import is a distinct architectural layer (provenance, ExternalIdentifier lifecycle, import pipeline, TrustSignal) that requires its own phase between Domain and Search. Merging it with Search creates an overly complex phase with unclear completion criteria. Separating it enables the search phase to focus purely on Typesense projection. |
| **Source Authority** | 06-data-acquisition.md, 03-domain.md §15 |
| **Impact** | 5-phase structure expanded to 7-phase. New PHASE 3 (Data Lineage/Import) inserted between Domain and Search. Phase numbering updated throughout. Timeline estimate: 35-53 days (was 30-46). |

---

## Summary

| Action | Count |
|--------|-------|
| **CORRECTED** | 18 |
| **RETAINED** | 1 |
| **DEFERRED** | 0 |
| **REJECTED** | 0 |
| **Not applicable** | 1 (Finding 15 partially retained) |

**Total findings:** 20
**Total corrections applied:** 18
**Retained with modification:** 1 (infrastructure tables — kept but classified)
**No action needed:** 1 (Finding 17 — decision markers were absent, now added)

---

*End of IMPLEMENTATION-PLAN-CORRECTION-REPORT.md*
