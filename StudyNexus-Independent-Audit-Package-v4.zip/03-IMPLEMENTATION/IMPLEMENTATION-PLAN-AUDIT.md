# StudyNexus — Implementation Plan Hostile Audit

**Date:** 2026-08-18
**Auditor:** Hostile review per audit specification
**Subject:** IMPLEMENTATION-PLAN.md (2026-08-10, 2454 lines)
**Baseline:** PRE-IMPLEMENTATION-BASELINE-V2 (54 files, SHA-256 verified)
**Constraint:** No code written. No migrations written. No canonical documents modified. Audit only.

---

# 1. Executive Verdict

**CONDITIONAL GO** — The implementation plan is structurally sound in its phasing, ordering, and separation of architectural decisions from implementation conventions. However, it contains **7 critical baseline conformance violations** that must be corrected before any implementation begins. The most severe are: Institution lifecycle states contradict the canonical domain model; InstitutionType enum contains 2 invented values; and 17 canonical tables are missing from the migration plan. The plan's overall architecture is faithful — no invented domain concepts, no reopened foundational decisions, no unnecessary abstraction layers. But the details of several aggregate root state machines and the table inventory diverge from the frozen baseline in ways that would produce a system that does not implement the canonical domain model.

**Severity breakdown:**
- 7 CRITICAL contradictions (must fix before GO)
- 8 SIGNIFICANT issues (should fix; some may be defensible with explicit justification)
- 6 MINOR issues (improvements; not blockers)

---

# 2. Baseline Conformance

## 2.1 Critical Contradictions

### C1: Institution Lifecycle States Contradict Canonical

**Implementation Plan §10.1:**
- States: `draft → active → deprecated`
- Methods: `establish()`, `deprecate()`

**Canonical 03-domain.md §3 (line 271):**
- States: `Operational → Suspended → Operational (via reactivate); Operational → Closed (terminal)`
- Methods: `establish()`, `suspend()`, `reactivate()`, `close()`, `rename()`

**Verdict:** CRITICAL. The plan replaces the canonical's 4-state lifecycle (Provisional/Operational/Suspended/Closed) with a 3-state model (draft/active/deprecated). This eliminates `SuspendInstitution`, `ReactivateInstitution`, and `CloseInstitution` as domain operations, and introduces `DeprecateInstitution` which does not exist in the canonical for Institution. "Deprecate" in the canonical applies only to supporting/reference entities (Qualification, ScholarshipProvider, EducationAuthority), not to the Institution aggregate root. The canonical explicitly states (line 372): "Its lifecycle transitions (Operational → Suspended → Closed) are significant business events with cascading effects on programmes and scholarships."

### C2: InstitutionType Enum Has 6 Values; Canonical Has 4

**Implementation Plan §9:**
- Values: `university, polytechnic, monotechnic, college_of_education, innovative_enterprise_institution, specialized_institution`

**Canonical 03-domain.md §5 (line 195):**
- Values: `University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution`
- Note: "(MVP; expansion to 7+ values triggers ADR-15)"

**Verdict:** CRITICAL. The plan adds `monotechnic` and `specialized_institution` which are not in the canonical MVP set. While these are real Nigerian institution types, the canonical explicitly chose a 4-value MVP with ADR-15 as the expansion trigger. Adding them preemptively violates the frozen decision.

### C3: Missing InstitutionStatus Enum

**Implementation Plan §9:** Lists 16 enums. `InstitutionStatus` is not among them.

**Canonical 03-domain.md §5 (line 207):**
- Enum #8: `InstitutionStatus | Provisional, Operational, Suspended, Closed | Educational Institution`
- Enum #20 (line 104): `Institution Status | Provisional, Operational, Suspended, Closed`

**Verdict:** CRITICAL. The canonical defines InstitutionStatus as a behavioural enum with 4 values. Its absence from the plan means the Institution lifecycle cannot be correctly implemented.

### C4: Missing is_published and published_at on Institution

**Implementation Plan §10.1 / §7.2:** Institution model's `$fillable` includes `status` and `accreditation_status` but not `is_published` or `published_at`.

**Canonical 03-domain.md §3 (lines 275, 293):**
- "Publication attributes (application-level): `is_published` boolean (default false), `published_at` nullable timestamp. Publication is orthogonal to domain lifecycle."
- Same pattern applies to Programme and Scholarship.

**Verdict:** CRITICAL. The canonical explicitly separates publication from domain lifecycle. The plan conflates them by using `published` as a Programme status value, and omits the publication attributes entirely from Institution.

### C5: Programme Lifecycle States Don't Match Canonical

**Implementation Plan §10.2:**
- States: `draft → published → suspended → discontinued`
- Methods: `introduce()`, `publish()`, `suspend()`, `discontinue()`

**Canonical 03-domain.md §3 (line 281):**
- Initial status: "Admitting"
- Methods: `introduce()`, plus domain lifecycle operations
- The canonical uses "Admitting" as the initial Programme status, not "draft"

**Verdict:** CRITICAL. The plan's Programme state machine diverges from the canonical's domain model. The term "published" is a publication concern (orthogonal to domain lifecycle per canonical), not a domain status. The canonical's Programme status values differ from what the plan implements.

### C6: Table Count Discrepancy — 58 vs 41

**Implementation Plan §5:** 42 migrations creating 41 tables.

**Canonical 05-implementation.md §4.1:** 58 tables across 10 layers.

**Verdict:** CRITICAL. 17 canonical tables are missing from the implementation plan. While some deferral is reasonable for tables not needed in the first vertical slice, the plan does not acknowledge or document which tables are deferred and why. Key missing tables include: `qualification_equivalencies`, `tuition_fee_ranges`, `url_redirects`, `institution_settings`, `user_preferences`, `media` (from spatie/laravel-medialibrary which the plan installs), and several others.

### C7: Table Naming Inconsistencies

| Canonical Name | Plan Name | Issue |
|----------------|-----------|-------|
| `saves` | `bookmarks` | Different concept name |
| `comparison_sets` | `comparisons` | Simplified name |
| `platform_settings` | `settings` | Generic name loses "platform" scope |
| `activities` (Spatie) | `activity_log` | Different from Spatie default |
| `community_questions` | `community_posts` | Different domain concept |
| `community_votes` | `community_likes` | Different interaction model |

**Verdict:** CRITICAL. Renaming canonical tables without documenting the rationale creates a conformance gap. Future developers cross-referencing the canonical documents will not find these tables.

## 2.2 Significant Issues

### S1: Missing Canonical Actions

The canonical 03-domain.md §4 lists these Institution actions that are absent from the plan:
- `SuspendInstitution` (canonical action #7, line 163)
- `ReactivateInstitution`
- `CloseInstitution`
- `RenameInstitution`

The plan substitutes `DeprecateInstitution` and `PublishInstitution` which are not canonical Institution operations.

### S2: Layer Migration Count Headers Are Wrong

- §5.1 header says "6 migrations" but table has 4 rows
- §5.2 header says "3 migrations" but table has 5 rows
- Total remains 42 (correct) but individual layer counts are wrong

### S3: Decision Marker Counts Are Wrong

- Plan introduction claims: 22 ARCHITECTURAL DECISION, 18 IMPLEMENTATION CONVENTION
- Actual count: 21 ARCHITECTURAL DECISION, 17 IMPLEMENTATION CONVENTION
- Each is off by 1

### S4: Seed Data Lacks Conflicting/Missing Data Scenarios

The development seeder (§21) includes 20 institutions with good type/region/accreditation variation, but lacks:
- Conflicting data from multiple InformationSources (same field, different values)
- Missing optional data (institution without website, programme without cut-off marks)
- Superseded provenance records (old source superseded by new)
- Historical admission cycle data with completed phases
- `monotechnic` or `innovative_enterprise_institution` type institutions (only university, polytechnic, college_of_education represented)

Without these scenarios, provenance conflict handling and TrustSignal computation cannot be meaningfully tested.

### S5: Missing qualification_equivalencies and tuition_fee_ranges Tables

These reference tables are in the canonical 05-implementation.md §4.1 and support cross-qualification comparison and tuition display — both mentioned in FIRST-VERTICAL-SLICE-UX.md. Their absence means the programme detail page cannot display tuition ranges or qualification equivalences.

### S6: No Explicit Laravel Queue Job/Batch Tables

The canonical lists `jobs` and `notifications` as infrastructure tables. The plan includes `failed_jobs` but not `jobs` (Laravel's queue jobs table). While Laravel can create this automatically, the plan should explicitly account for it since it relies on queued jobs for search indexing and imports.

### S7: Canonical Community Model Differs

The canonical has a Q&A model: `community_questions`, `community_answers`, `community_comments`, `community_votes`, `community_reports`. The plan implements a forum model: `community_posts`, `community_comments`, `community_likes`. These are different interaction patterns.

### S8: ProgrammeStatus Includes "published" — A Publication Concern, Not Domain Status

Per canonical 03-domain.md §3 (line 275), publication is orthogonal to domain lifecycle. Having `published` as a ProgrammeStatus enum value conflates two separate concerns. The canonical uses `is_published` boolean + `published_at` timestamp separately.

## 2.3 Minor Issues

### M1: Tailwind v4 Configuration Uses JavaScript Format

The plan's §19.1 uses `tailwind.config.js` (JavaScript format). Tailwind CSS v4 uses CSS-based configuration by default (`@config` directive in CSS). This is an implementation convention but could cause confusion during setup.

### M2: No Explicit Loading States

FIRST-VERTICAL-SLICE-UX.md specifies loading states (skeleton screens, spinners) for all data-fetching pages. The plan mentions empty states and error states but does not specify loading/skeleton states for Livewire components.

### M3: Supplementary Tables Created Before Needed

Tables for community, engagement, content, and notification features are created in Phase 1 but have no UI or code in the first vertical slice. These could be deferred to a later phase.

### M4: Filament v5 Version Reference

The plan says `filament/filament ^3.0` is "Filament v5 API." While this is technically correct (Filament v5 ships as composer package ^3.0), this is a known source of confusion. The plan documents it (trap T8) but the package table could be clearer.

### M5: No Explicit Scout Typesense Driver Package

The plan states (§2.3) that "Scout Typesense driver is bundled with `laravel/scout ^4.0`." This should be verified — in Laravel Scout ^4.0, the Typesense driver may require separate configuration or a standalone package.

### M6: Admission Cycle Route Uses ID, Not Slug

§22.2 defines `/admissions/{admissionCycle}` which uses route model binding by ID. Other public pages use slug-based URLs (`{programme:slug}`, `{institution:slug}`). Admission cycles should also use slugs for SEO consistency, per ADR and the search-first architecture principle.

---

# 3. 42-Migration Audit

## 3.1 Migration-by-Migration Analysis

| # | Migration | Purpose | Depends On | Clean? | Necessary? | Combine? | Risk |
|---|-----------|---------|------------|--------|------------|----------|------|
| 1 | create_users_table | User accounts | None | ✓ | ✓ | ✓ (with 2-4) | Low |
| 2 | create_password_reset_tokens | Password resets | None | ✓ | ✓ | ✓ (with 1,3,4) | Low |
| 3 | create_failed_jobs | Failed queue jobs | None | ✓ | ✓ | ✓ (with 1,2,4) | Low |
| 4 | create_personal_access_tokens | API tokens | None | ✓ | ✓ | ✓ (with 1-3) | Low |
| 5 | create_permissions_table | Spatie permissions | None | ✓ | ✓ | No (vendor) | Low |
| 6 | create_roles_table | Spatie roles | None | ✓ | ✓ | No (vendor) | Low |
| 7 | create_model_has_permissions | Permission pivot | 5, users | ✓ | ✓ | No (vendor) | Low |
| 8 | create_model_has_roles | Role pivot | 6, users | ✓ | ✓ | No (vendor) | Low |
| 9 | create_role_has_permissions | Role-perm pivot | 5, 6 | ✓ | ✓ | No (vendor) | Low |
| 10 | create_countries_table | ISO 3166-1 | None | ✓ | ✓ | ✓ (with 11-13) | Low |
| 11 | create_currencies_table | ISO 4217 | None | ✓ | ✓ | ✓ (with 10,12,13) | Low |
| 12 | create_qualifications_table | Exam bodies | None | ✓ | ✓ | ✓ (with 10,11,13) | Low |
| 13 | create_disciplines_table | Faculty taxonomy | None | ✓ | ✓ | ✓ (with 10-12) | Low |
| 14 | create_education_authorities_table | JAMB, NUC, etc. | None | ✓ | ✓ | No | Low |
| 15 | create_institutions_table | Core entity | 14 | ✓ | ✓ | No | Medium |
| 16 | create_programmes_table | Core entity | 15, 13 | ✓ | ✓ | No | Medium |
| 17 | create_scholarship_providers_table | Reference | None | ✓ | ✓ | No | Low |
| 18 | create_scholarships_table | Core entity | 17 | ✓ | ✓ | No | Low |
| 19 | create_admission_cycles_table | Core entity | 14 | ✓ | ✓ | No | Medium |
| 20 | create_admission_policies_table | Child of 19 | 19 | ✓ | ✓ | No | Low |
| 21 | create_eligibility_policies_table | Child of 19 | 19 | ✓ | ✓ | No | Low |
| 22 | create_accreditation_records_table | Child of 15 | 15, 16 | ✓ | ✓ | No | Low |
| 23 | create_information_sources_table | AR, nullable auth | 14 | ✓ | ✓ | No | Medium |
| 24 | create_cut_off_marks_table | Supporting | 16, 19, 23 | ✓ | ✓ | No | Medium |
| 25 | create_external_identifiers_table | Infrastructure | 14, 23, morph | ✓ | ✓ | No | High |
| 26 | create_field_provenance_table | Infrastructure | 23, morph | ✓ | ✓ | No | High |
| 27 | create_organization_members_table | Org pivot | users, 15 | ✓ | ✓ | No | Low |
| 28 | create_content_pages_table | CMS | None | ✓ | Defer | ✓ (with 29) | Low |
| 29 | create_content_sections_table | CMS blocks | 28 | ✓ | Defer | ✓ (with 28) | Low |
| 30 | create_bookmarks_table | Engagement | users, morph | ✓ | Defer | ✓ (with 31,32) | Low |
| 31 | create_comparisons_table | Engagement | users, morph | ✓ | Defer | ✓ (with 30,32) | Low |
| 32 | create_alerts_table | Engagement | users, morph | ✓ | Defer | ✓ (with 30,31) | Low |
| 33 | create_community_posts_table | Community | users | ✓ | Defer | ✓ (with 34,35) | Low |
| 34 | create_community_comments_table | Community | 33 | ✓ | Defer | ✓ (with 33,35) | Low |
| 35 | create_community_likes_table | Community | users, morph | ✓ | Defer | ✓ (with 33,34) | Low |
| 36 | create_notification_preferences | Notifications | users | ✓ | Defer | No | Low |
| 37 | create_settings_table | Platform settings | None | ✓ | Defer | ✓ (with 38,39) | Low |
| 38 | create_seo_meta_table | SEO metadata | morph | ✓ | Defer | ✓ (with 37,39) | Low |
| 39 | create_activity_log_table | Spatie activity | None | ✓ | ✓ | No (vendor) | Low |
| 40 | create_import_batches_table | Staging (UUID) | None | ✓ | ✓ | No | Medium |
| 41 | create_pending_imports_table | Staging (UUID) | 40 | ✓ | ✓ | No | Medium |
| 42 | add_check_constraints | CHECK + indexes | 25, 26 | ✓ | ✓ | No | High |

## 3.2 Why Are There 42 Migrations?

**Answer:** The 42 migrations represent the complete database schema creation for a greenfield project. There are **zero** historical amendment/data-transition migrations — every migration is a `CREATE TABLE` or `ALTER TABLE ADD CONSTRAINT` that builds the initial schema from scratch.

The count is not unreasonable for a project with 41 tables, but it is **unnecessarily granular**. The plan creates one migration per table, which maximizes clarity but creates churn. For a greenfield project, related tables should be grouped.

**Recommended consolidation:** ~22-25 migrations by combining:
- Laravel defaults (1-4) → 1 migration
- Reference data (10-13) → 1 migration
- Content (28-29) → 1 migration
- Engagement (30-32) → 1 migration
- Community (33-35) → 1 migration
- Settings/SEO/Infra (37-39) → 1 or 2 migrations
- Keep vendor migrations (5-9, 39) as-is
- Keep domain migrations (14-27) one-per-table for FK clarity
- Keep staging (40-41) as-is
- Keep constraints (42) as-is

## 3.3 Tables Deferrable to Post-MVP

Migrations 28-38 (content, engagement, community, notifications, settings, SEO) create tables with **no corresponding UI or code in the first vertical slice**. These 11 migrations can be deferred to a later phase without affecting the vertical slice.

**Recommendation:** Move migrations 28-38 to Phase 5 or a post-MVP phase. This reduces Phase 1 from 42 to 31 migrations, simplifying the initial database setup.

---

# 4. Clean-Install Validation

## 4.1 Mental Execution of Migration Dependency Graph

Starting from an empty PostgreSQL database with a fresh Laravel installation:

| Step | Migration | All Prerequisites Exist? | FK Targets Exist? | Result |
|------|-----------|-------------------------|-------------------|--------|
| 1 | users | ✓ (none) | N/A | PASS |
| 2 | password_reset_tokens | ✓ | N/A | PASS |
| 3 | failed_jobs | ✓ | N/A | PASS |
| 4 | personal_access_tokens | ✓ | N/A | PASS |
| 5 | permissions | ✓ | N/A | PASS |
| 6 | roles | ✓ | N/A | PASS |
| 7 | model_has_permissions | ✓ | permissions, users exist | PASS |
| 8 | model_has_roles | ✓ | roles, users exist | PASS |
| 9 | role_has_permissions | ✓ | roles, permissions exist | PASS |
| 10 | countries | ✓ | N/A | PASS |
| 11 | currencies | ✓ | N/A | PASS |
| 12 | qualifications | ✓ | N/A | PASS |
| 13 | disciplines | ✓ | N/A | PASS |
| 14 | education_authorities | ✓ | N/A | PASS |
| 15 | institutions | ✓ | education_authorities exists | PASS |
| 16 | programmes | ✓ | institutions, disciplines exist | PASS |
| 17 | scholarship_providers | ✓ | N/A | PASS |
| 18 | scholarships | ✓ | scholarship_providers exists | PASS |
| 19 | admission_cycles | ✓ | education_authorities exists | PASS |
| 20 | admission_policies | ✓ | admission_cycles exists | PASS |
| 21 | eligibility_policies | ✓ | admission_cycles exists | PASS |
| 22 | accreditation_records | ✓ | institutions, programmes exist | PASS |
| 23 | information_sources | ✓ | education_authorities exists (nullable FK) | PASS |
| 24 | cut_off_marks | ✓ | programmes, admission_cycles, information_sources exist | PASS |
| 25 | external_identifiers | ✓ | education_authorities, information_sources exist; morph uses entity_id (no FK to specific table) | PASS |
| 26 | field_provenance | ✓ | information_sources exists; morph uses entity_id | PASS |
| 27 | organization_members | ✓ | users, institutions exist | PASS |
| 28-38 | Supplementary tables | ✓ | users + morph targets exist | PASS |
| 40 | import_batches | ✓ | N/A (UUID PK) | PASS |
| 41 | pending_imports | ✓ | import_batches exists | PASS |
| 42 | constraints + indexes | ✓ | external_identifiers, field_provenance exist | PASS |

## 4.2 Circular Dependency Check

**No circular dependencies detected.** The dependency graph is a DAG. Self-referencing FKs on `external_identifiers.replaced_by_id` and `field_provenance.superseded_by_id` are nullable and do not create cycles.

## 4.3 PK Type Verification

| Category | PK Type | Correct per BD-1/ADR-19? |
|----------|---------|-------------------------|
| All canonical tables | BIGINT | ✓ |
| import_batches | UUID | ✓ |
| pending_imports | UUID | ✓ |
| Spatie pivots | BIGINT (composite) | ✓ |

## 4.4 Enum Column Verification

All 16 enum columns in the plan use string backing type, consistent with the canonical. However, `InstitutionStatus` enum is missing (see C3).

## 4.5 Clean-Install Verdict

**PASS** — All 42 migrations can execute cleanly on an empty database in the specified order. No missing prerequisites, no circular dependencies, correct PK types.

---

# 5. Domain Implementation Order

## 5.1 Proposed Order Audit

The plan's order (§7): EducationAuthority → Institution → Programme → ScholarshipProvider → Scholarship → AdmissionCycle → AdmissionPolicy → EligibilityPolicy → AccreditationRecord → InformationSource → CutOffMark → ExternalIdentifier → FieldProvenance → ImportBatch → PendingImport → OrganizationMember

**Dependency analysis:** Each model's prerequisites are satisfied by the time it is implemented. ✓

**Concern: InformationSource position.** The plan places InformationSource at position 10, after AccreditationRecord (position 9). However, InformationSource is an aggregate root with a nullable FK to EducationAuthority. It could be implemented earlier (after EducationAuthority, before Institution) since ExternalIdentifier and FieldProvenance both reference it. The current order is not wrong — it works — but implementing InformationSource earlier would allow more parallel work on the provenance infrastructure.

## 5.2 Abstraction Audit

The plan follows Laravel Beyond CRUD principles:
- ✅ No repositories
- ✅ No service classes
- ✅ Actions as command interface (20 Actions)
- ✅ Models ARE aggregate persistence representations (ADR-1)
- ✅ VOs as immutable PHP objects with custom casts
- ✅ Enums as PHP Backed Enums
- ✅ Domain events dispatched from Actions

**No unnecessary abstractions detected.** The plan does not introduce:
- Generic repository architecture ❌ (not present)
- Service-class soup ❌ (not present)
- CRUD-heavy architecture ❌ (Actions enforce invariants)
- Generic EAV ❌ (not present)
- Unnecessary interfaces ❌ (SourceAdapter interface is justified for the import pipeline)
- Unnecessary factories ❌ (not present beyond model factories for testing)

The `SourceAdapter` interface is the only interface in the plan. It is justified — the import pipeline has 6+ concrete adapters that must conform to a common contract. This is not over-abstracting; it is polymorphism for a genuine variation.

---

# 6. Typesense Validation

## 6.1 Introduction Timing

Typesense is introduced in Phase 3 (Search/Projections), after Phase 2 (Domain Foundation) is complete. ✓ This ensures domain models are functional before any search infrastructure depends on them.

## 6.2 Source of Truth

- PostgreSQL remains canonical source of truth ✓
- Typesense is a projection/read model ✓
- `toSearchableArray()` builds search documents FROM canonical data ✓
- No domain logic depends on Typesense ✓
- No write operations go through Typesense ✓

## 6.3 Index Synchronization

- Domain events → `UpdateSearchIndexListener` → queued Scout job → Typesense upsert ✓
- Nightly `SearchIndexRebuildJob` as reconciliation ✓
- Manual `scout:import` available via Filament action ✓
- Failed updates retried 3 times before logging ✓

## 6.4 Field Placement Audit

| Field | PostgreSQL | Typesense | Neither | Correct? |
|-------|-----------|-----------|---------|----------|
| Entity attributes (name, type, status) | ✓ (canonical) | ✓ (denormalized) | | ✓ |
| Relationship data (institution_name, discipline) | ✓ (FK) | ✓ (denormalized) | | ✓ |
| Facet fields (level, state, mode_of_study) | ✓ (enum columns) | ✓ (facet: true) | | ✓ |
| Provenance metadata | ✓ (JSONB + FP table) | | ✓ | ✓ |
| Import batch data | ✓ (staging tables) | | ✓ | ✓ |
| Cut-off mark value | ✓ (cut_off_marks) | ✓ (for sort/facet) | | ✓ |
| Slug | ✓ (column) | ✓ (for URL construction) | | ✓ |

**Typesense field placement is correct.** No domain-only data leaks into Typesense, and no search-required data is missing from Typesense.

## 6.5 Reindexing Determinism

`scout:import` rebuilds from PostgreSQL. With the same data, the same index is produced. ✓

Initial indexing with seed data: Phase 3 step P3-6 explicitly indexes development data. ✓

## 6.6 Typesense Verdict

**PASS** — Typesense architecture is faithful to the canonical and correctly positioned as a read-side projection.

---

# 7. Data-Lineage Implementation Validation

## 7.1 Pipeline Conformance

The provenance pipeline follows the canonical 06-data-acquisition.md §3 architecture:

```
SOURCE (InformationSource)
  → OBSERVATION (pending_imports raw_data)
  → RECONCILIATION (VerificationEngine: duplicate detection, cross-source check)
  → CANONICAL ASSERTION (domain Actions: CreateInstitution, etc.)
  → PUBLICATION (search index sync)
```

Each step is present and correctly ordered. ✓

## 7.2 Staging Is Not Canonical

- `import_batch_id` is NOT included in provenance JSONB ✓ (line 1421)
- Staging entities use UUID PKs and are ephemeral ✓
- Only verified records are applied to domain ✓
- Application goes through domain Actions (not direct DB writes) ✓

## 7.3 Provenance Immutability

- FieldProvenance records are superseded, never overwritten ✓
- `superseded_at` + `superseded_by_id` for archival ✓
- No `is_active` column — active provenance derived from `superseded_at IS NULL` ✓
- No `value_hash` ✓
- No `primary_source_id` ✓

## 7.4 80/20 Model

| Category | Fields | Plan | Canonical | Match? |
|----------|--------|------|-----------|--------|
| A (always) | name, type, status, accreditation_status, cut_off_mark | 5 | 5 | ✓ |
| B (on conflict) | founded_year, location, website, admission_requirements, application_deadline, amount | 6 | 6 | ✓ |
| C (never) | all others | — | — | ✓ |
| Total A+B | | 11 | 11 | ✓ |

## 7.5 Source ON DELETE Semantics

| Table | Column | ON DELETE | Canonical | Plan | Match? |
|-------|--------|-----------|-----------|------|--------|
| external_identifiers | source_id | RESTRICT | RESTRICT | RESTRICT | ✓ |
| field_provenance | source_id | RESTRICT | RESTRICT | RESTRICT | ✓ |
| cut_off_marks | source_id | SET NULL | SET NULL | SET NULL | ✓ |

The intentionally different ON DELETE behaviors are correctly preserved. ✓

## 7.6 Data-Lineage Verdict

**PASS** — Data lineage implementation is faithful to the canonical. The SOURCE → OBSERVATION → RECONCILIATION → CANONICAL ASSERTION → PUBLICATION pipeline is correctly implemented, staging data does not become canonical, and provenance immutability is preserved.

---

# 8. First Vertical-Slice Scope Validation

## 8.1 Declared Scope

The plan explicitly states (§22): "The vertical slice is EXACTLY: Homepage → Programme Search → Faceted Results → Programme Detail → Institution Detail → Admission Information — no more."

## 8.2 Scope Audit

| Feature | In Vertical Slice? | Present in Plan? | Verdict |
|---------|-------------------|------------------|---------|
| Homepage with search | ✓ | ✓ (VS-1) | ✓ |
| Programme Search + facets | ✓ | ✓ (VS-2, VS-3) | ✓ |
| Programme Detail | ✓ | ✓ (VS-5) | ✓ |
| Institution Detail | ✓ | ✓ (VS-6) | ✓ |
| Admission Information | ✓ | ✓ (VS-7) | ✓ |
| Recommendation ML | ✗ | Not present | ✓ |
| Rankings | ✗ | Not present | ✓ |
| Full scholarship platform | ✗ | Not present in UI (table exists but no public page) | ✓ |
| Examination platform | ✗ | Not present | ✓ |
| Career platform | ✗ | Not present | ✓ |
| B2B features | ✗ | Not present | ✓ |
| Application flow | ✗ | Not present | ✓ |
| Social features | ✗ | Table exists (community_*) but no UI | ⚠️ |
| User accounts/auth | ✗ | Users table + auth exists but no public registration/login UI | ⚠️ |

**⚠️ Items:** The community and user account tables are created in the schema but have no UI or code in the vertical slice. This is acceptable — the tables exist for future use but don't introduce scope creep. However, they add unnecessary migration complexity in Phase 1.

## 8.3 Scope Verdict

**PASS** — The vertical slice stays within its declared boundary. No accidental features have been added to the UI. The schema-only tables for out-of-slice features are a minor concern but not a scope violation.

---

# 9. UX/UI Conformance

## 9.1 Cross-Check Against FIRST-VERTICAL-SLICE-UX.md

| UX Requirement | In Plan? | Location | Verdict |
|----------------|----------|----------|---------|
| Homepage discovery (hero search) | ✓ | §18.1 Homepage | ✓ |
| Faceted search (7 facets) | ✓ | §17.1, §18.1 Programme Search | ✓ |
| Mobile filter bottom sheet/drawer | ✓ | §19.4, §18.1 "filters in a slide-out drawer" | ✓ |
| Admission-first programme detail | ✓ | §18.1 Programme Detail | ✓ |
| Historical cut-offs | Partially | §18.1 "Cut-off marks table (latest cycle first)" | ⚠️ No explicit mention of historical/previous years |
| Result-card information | ✓ | §17.3 Result Card Design | ✓ |
| Institution detail page | ✓ | §18.1 Institution Detail | ✓ |
| Loading states | ✗ | Not specified | **MISSING** |
| Empty states | ✓ | §18.1 "Zero-results state with search suggestions" | ✓ |
| Error states | ✓ | §24.3 CC3 Typesense graceful degradation | ✓ |
| Accessibility (44px tap targets) | ✓ | §19.4 | ✓ |
| Responsive behavior | ✓ | §19.3, §19.4 | ✓ |
| Breadcrumbs | ✓ | §18.1 on all detail pages | ✓ |
| Trust signals | ✓ | §22.1 VS-9 | ✓ |

## 9.2 Cross-Check Against FIRST-VERTICAL-SLICE-UI.md

| UI Specification | In Plan? | Verdict |
|------------------|----------|---------|
| "Currently admitting only" toggle (default-off) | ✗ | Not mentioned in Programme Search or Detail |
| Historical cut-off: current + 2 previous, expandable | ✗ | Not specified |
| Tuition display: annual with "per year" label | ✗ | Not mentioned (no tuition_fee_ranges table) |
| Discipline browse: grid (desktop), list (mobile) | Partially | §19.3 breakpoints but no discipline browse page |
| All admission pathways visible with separate cut-offs | ✗ | Not mentioned |
| No scholarships on result cards | ✓ | §17.3 result card has no scholarship info | ✓ |

## 9.3 UX/UI Verdict

**PARTIAL PASS** — The plan captures the major UX flows but omits several specific UI decisions resolved in FIRST-VERTICAL-SLICE-UI.md: the "currently admitting" toggle, historical cut-off display format, annual tuition labeling, and all-pathways-visible design. Loading states are entirely absent. These are not architectural issues but they are conformance gaps that would produce a UI different from the UX specification.

---

# 10. Seed-Data Audit

## 10.1 Current Seed Data Assessment

The plan provides (§21):
- 20 institutions across 3 types (university, polytechnic, college_of_education) and 12+ states ✓
- 60+ programmes (~3 per institution) ✓
- 2 admission cycles ✓
- 40+ cut-off marks ✓
- 20+ external identifiers ✓
- 5 information sources ✓
- 3 scholarship providers + scholarships ✓

## 10.2 Missing Scenarios

| Scenario | Why Important | Present? |
|----------|---------------|----------|
| Institution without website | Tests missing optional data rendering | ✗ |
| Programme without cut-off marks | Tests empty cut-off table state | ✗ |
| Same field from 2+ sources (conflict) | Tests Category B provenance recording | ✗ |
| Superseded provenance record | Tests superseded_at/superseded_by_id logic | ✗ |
| Deprecated InformationSource | Tests deprecation cascade on provenance | ✗ |
| Monotechnic or IEI type institution | Tests all InstitutionType values | ✗ |
| Closed/deprecated institution | Tests non-active institution display | ✗ |
| Programme with multiple admission pathways | Tests pathway-specific cut-offs | ✗ |
| Historical admission cycle (archived) | Tests cycle archive display | ✗ |

## 10.3 "3 Identical Fake Institutions" Check

The 20 institutions have genuine diversity: different types, states, accreditation statuses, and real Nigerian institution names. **PASS** — no cookie-cutter test data.

## 10.4 Seed-Data Verdict

**PARTIAL PASS** — Good baseline coverage but insufficient for testing provenance conflict handling, missing data states, and the full enum value range. The development seeder should be enhanced with the 9 missing scenarios before Phase 3.

---

# 11. Test Strategy Audit

## 11.1 Test Coverage by Phase

| Phase | Unit Tests | Domain Tests | Feature Tests | DB Tests | Search Tests | Livewire Tests | E2E Tests |
|-------|-----------|-------------|---------------|----------|-------------|----------------|-----------|
| P0 (Setup) | ✓ (PackageCompatibility) | — | — | — | — | — | — |
| P1 (Database) | — | — | — | ✓ (constraints) | — | — | — |
| P2 (Domain) | ✓ (90%+ coverage target) | ✓ (state machines) | ✓ (Actions) | ✓ (model relationships) | — | — | — |
| P3 (Search) | — | — | ✓ (search sync) | — | ✓ (Typesense) | — | — |
| P4 (Slice) | — | — | ✓ (Livewire) | — | — | ✓ (components) | ✓ (Dusk) |
| P5 (Hardening) | ✓ (full suite) | ✓ (full suite) | ✓ (full suite) | ✓ | ✓ | ✓ | ✓ |

## 11.2 Critical Test Gaps

| Missing Test | Why Critical |
|-------------|--------------|
| Provenance Category B conflict recording | Core invariant of ND-4/ADR-23 |
| Provenance supersession chain | Audit trail correctness |
| ExternalIdentifier lifecycle (assign → retire → supersede) | INV-EI1/INV-EI2 enforcement |
| InformationSource deprecation → provenance cascade | Cross-entity effect |
| TrustSignal computation from provenance + verification + reliability | Display correctness |
| Concurrent AdmissionCycle phase advance (already listed) | Race condition detection |
| Import pipeline idempotency (re-run same batch) | 06-data-acquisition.md §1 principle 4 |
| SoftDeletes + unique constraint interaction | Slug uniqueness with soft deletes |

## 11.3 Test Strategy Verdict

**PARTIAL PASS** — The test strategy covers the major layers but has 8 critical test gaps, particularly in provenance and data lineage. The coverage targets (90% domain, 80% Actions, 95% VOs) are appropriate if achieved.

---

# 12. Architectural Decision Marker Audit

## 12.1 Count Verification

| Marker Type | Claimed Count | Actual Count | Discrepancy |
|-------------|---------------|--------------|-------------|
| ARCHITECTURAL DECISION | 22 | 21 | -1 |
| IMPLEMENTATION CONVENTION | 18 | 17 | -1 |

## 12.2 Classification Audit

All 21 ARCHITECTURAL DECISION markers trace to the frozen baseline:

| # | Decision | ADR/Source | Correctly Classified? |
|---|----------|------------|----------------------|
| 1 | Laravel ^13.0 + PHP 8.5 baseline | 02-decisions §2 | ✓ |
| 2 | Actions by aggregate, models ARE aggregate (ADR-1) | 03-domain §1, ADR-1 | ✓ |
| 3 | Filament v5 admin panel | 05-implementation §1 | ✓ |
| 4 | Typesense as search engine | ADR-12 | ✓ |
| 5 | PostgreSQL 16+ primary store | ADR-01 | ✓ |
| 6 | Uniform BIGINT PKs; UUID for staging | ADR-19 | ✓ |
| 7 | Partial unique indexes INV-EI1, INV-EI2 | ADR-21 | ✓ |
| 8 | PhaseSequence JSONB + stable IDs | ADR-20 | ✓ |
| 9 | InformationSource independent AR | ADR-22 | ✓ |
| 10 | enforceMorphMap | 04-architecture §4 | ✓ |
| 11 | Actions as command interface | ADR-1 | ✓ |
| 12 | 80/20 provenance model | ADR-23 | ✓ |
| 13 | Provenance immutability (supersede, not overwrite) | 06-data-acquisition §8 | ✓ |
| 14 | Staging UUID PKs | ADR-19 | ✓ |
| 15 | Search-first architecture | 04-architecture §7 | ✓ |
| 16 | Slug-based URLs | 04-architecture §9 | ✓ |
| 17 | RBAC with Spatie + Filament Shield | 02-decisions §5 | ✓ |
| 18 | lockForUpdate for AdmissionCycle phases | ADR-20 | ✓ |
| 19 | Domain events from Actions (not observers) | 04-architecture §5 | ✓ |
| 20 | Livewire queries Typesense directly | 04-architecture §7 | ✓ |
| 21 | Programme Search as primary vertical slice | PRODUCT-EXPERIENCE-DISCOVERY | ✓ |

**No misclassification detected.** All architectural decisions genuinely come from the frozen baseline. No implementation convention has become an accidental domain decision.

## 12.3 Marker Verdict

**PASS with minor correction** — Classification is correct but count claims are off by 1 each.

---

# 13. Package/Technology Audit

## 13.1 Package Verification

| # | Package | In Canonical? | Version Correct? | Unnecessary? | Verdict |
|---|---------|---------------|------------------|-------------|---------|
| 1 | laravel/scout ^4.0 | ✓ (05-impl §2) | ✓ | — | ✓ |
| 2 | livewire/livewire ^4.0 | ✓ (05-impl §1) | ✓ | — | ✓ |
| 3 | filament/filament ^3.0 | ✓ (05-impl §1) | ✓ (v5 API) | — | ✓ |
| 4 | spatie/laravel-permission ^6.0 | ✓ (05-impl §2) | ✓ | — | ✓ |
| 5 | spatie/laravel-activitylog ^5.0 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 6 | typesense/typesense-php ^4.0 | ✓ (05-impl §2) | ✓ | — | ✓ |
| 7 | spatie/crawler ^1.0 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 8 | smalot/pdfparser ^2.0 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 9 | maatwebsite/excel ^3.1 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 10 | spatie/laravel-rate-limited-job-middleware ^1.0 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 11 | bezhansalleh/filament-shield | ✓ (05-impl §2) | ✓ | — | ✓ |
| 12 | pxlrbt/filament-activity-log ^2.0 | ✓ (06-data-acq §10) | ✓ | — | ✓ |
| 13 | spatie/laravel-medialibrary ^11.0 | ✓ (05-impl §2) | ✓ | — | ✓ |
| 14 | spatie/laravel-sluggable ^3.0 | ✓ (05-impl §2) | ✓ | — | ✓ |

**All 14 packages are approved in the canonical.** No unapproved packages. No duplicated functionality. No unnecessary dependencies.

## 13.2 Missing Package Consideration

The canonical 05-implementation.md §2 also references `spatie/laravel-tags` which is not in the plan. However, the plan does not create a `tags`/`taggables` table either, so this is consistent — tags are deferred.

## 13.3 Package Verdict

**PASS** — All packages are canonical-approved. No invented dependencies.

---

# 14. Parallelization Audit

| Phase | Marked As | Actual | Explanation |
|-------|-----------|--------|-------------|
| P0 (Setup) | Sequential | **Sequential** | All steps depend on the project existing. ✓ |
| P1 (Database) | Sequential | **Sequential** | Migrations must run in dependency order. ✓ |
| P2 (Domain) | Partially parallel | **Partially parallel** | P2-1 (enums) and P2-2 (VOs) can run in parallel. P2-5 (Programme), P2-6 (Scholarship), P2-9 (InformationSource) can run in parallel after their prerequisites. However, these share the morphMap contract and provenance trait, so developers must agree on these contracts first. **Partially parallel with coordination.** |
| P3 (Search) | Sequential | **Sequential** | Typesense depends on domain models. Scout configuration depends on Typesense running. Development data depends on domain models. **Sequential.** |
| P4 (Slice) | Partially parallel | **Partially parallel** | Homepage and Search can begin together. Detail pages (VS-5, VS-6, VS-7) can run in parallel once search is working. **Partially parallel.** |
| P5 (Hardening) | Sequential | **Sequential** | All tests depend on complete implementation. **Sequential.** |

**Concern:** The plan marks P2 as "partially parallel" but doesn't highlight the coordination risk. When two developers implement Programme and Scholarship in parallel, they share the `HasProvenance` trait and morphMap aliases. If one developer changes the trait contract, the other's work breaks. This needs a brief "contract freeze" checkpoint.

## 14.1 Parallelization Verdict

**PASS with note** — Parallelization markings are correct but Phase 2 needs an explicit contract-freeze checkpoint before parallel work begins.

---

# 15. Risk Audit

## 15.1 Top 15 Implementation Risks

| # | Risk | Why Risky | Likely Failure | Mitigation | Test Strategy | Early/Late |
|---|------|-----------|----------------|------------|---------------|------------|
| R1 | PhaseSequence concurrency | Two concurrent advancePhase() calls | Skipped phase or double-advance | lockForUpdate() + DB::transaction() | Spawn 2 concurrent HTTP requests | Early (P2) |
| R2 | Typesense index drift | Event fires, index update fails silently | Stale search results | 3 retries + nightly rebuild + count monitoring | Index count vs DB count test | Late (P3+) |
| R3 | Partial unique index correctness | Non-obvious PostgreSQL feature | Developer adds wrong unique index | Code comments + specific tests | Insert same active ID → fail; different status → succeed | Early (P1) |
| R4 | Provenance immutability violation | Direct update instead of supersede | Broken audit trail | Override save() on FieldProvenance | Test that update throws | Early (P2) |
| R5 | ON DELETE RESTRICT surprises | Admin tries to delete institution with programmes | Unexpected QueryException | Filament delete override + deprecation workflow | Test delete* → user-friendly error | Late (P4) |
| R6 | MorphMap enforcement | Unregistered polymorphic type | Stores FQCN in DB | enforceMorphMap() on day one | Test unregistered type → throws | Early (P2) |
| R7 | VO JSON roundtrip | Null handling or type coercion in casts | VO != cast(get(cast(set(VO)))) | Roundtrip test for every VO cast | Per-VO roundtrip test | Early (P2) |
| R8 | Action authorization bypass | Developer calls model method directly | Bypasses Policy check | Code review rule + PHPStan custom rule | Test unauthorized action → 403 | Ongoing |
| R9 | Scout stale eager loads | toSearchableArray() references unloaded relation | N+1 or null in search doc | Always eager-load in toSearchableArray() | Test fresh model → no N+1 | Middle (P3) |
| R10 | PhaseSequence JSONB mutation | Developer mutates JSONB in place | Violates VO immutability | PhaseSequence has only withAdvancedPhase() | Test that VO is immutable | Early (P2) |
| R11 | Import batch atomicity | Partial application on record N failure | Inconsistent applied_records count | Each record in own transaction | Test partial failure scenario | Middle (P2) |
| R12 | SoftDeletes + unique conflict | Slug unique includes soft-deleted rows | Cannot re-create entity with same slug | Partial unique index WHERE deleted_at IS NULL | Test soft-delete + re-create | Early (P1) |
| R13 | Livewire memory leak | Large result set stored in public property | Excessive wire payload | Never store collections in public properties; use #[Computed] | Profile wire payload size | Late (P4) |
| R14 | Filament v5 API confusion | Composer ^3.0 vs product v5 | Wrong API calls | Prominent README documentation | Verify filament:about shows v5 | Early (P0) |
| R15 | Institution lifecycle mismatch with canonical | Plan implements wrong states | System doesn't match domain model | **Fix plan to match canonical before implementation** | Verify all states match 03-domain.md | **Before P2** |

Risk R15 is added as the highest-priority risk discovered by this audit. The Institution lifecycle in the plan does not match the canonical,B and implementing it as-is would produce a system that violates the frozen domain model.

---

# 16. Timeline Audit

## 16.1 Estimate Assessment

| Phase | Plan Estimate | Assessment | Reasoning |
|-------|---------------|------------|-----------|
| P0 | 1-2 days | **Realistic** | Standard Laravel project setup with Docker |
| P1 | 3-5 days | **Realistic** | 42 migrations + seed data + constraint tests |
| P2 | 10-15 days | **Optimistic** | 16 models + 12 VOs + 16 enums + 20 Actions + 29 events + 11 policies + Filament resources. The VO cast implementation alone could take 3-4 days. AdmissionCycle concurrency handling is non-trivial. 10 days is optimistic; 15 days is realistic for 2 developers. |
| P3 | 3-5 days | **Realistic** | Typesense setup + indexing + facet tests |
| P4 | 8-12 days | **Optimistic** | 5 responsive pages with Livewire, mobile drawer, SEO, accessibility, plus Dusk tests. 8 days is very tight; 12 days is more realistic for 2 developers new to Livewire v4. |
| P5 | 5-7 days | **Realistic** | Test hardening, security review, performance |
| **Total** | **30-46 days** | **Optimistic** | More likely 35-50 working days |

## 16.2 Uncertainty Dominators

| Source of Uncertainty | Impact on Timeline |
|----------------------|-------------------|
| Team familiarity with Livewire v4 + Flux | ±5 days on P4 |
| Team familiarity with Typesense + Scout | ±3 days on P3 |
| AdmissionCycle lockForUpdate() correctness | ±2 days on P2 |
| Import pipeline adapter implementation | ±5 days (if included in first slice) |
| Filament v5 API quirks | ±2 days on P2 |

The largest uncertainty is Livewire v4 familiarity. If the team has not built Livewire v4 components before, Phase 4 could easily take 15+ days instead of 8-12.

## 16.3 Timeline Verdict

**Slightly optimistic** — The 30-46 day range is achievable for an experienced team but tight for a team learning Livewire v4. A more conservative estimate is 35-50 working days (7-10 weeks).

---

# 17. Corrected Implementation Sequence

## A. Keep Unchanged

These steps are already correct and faithful to the frozen baseline:

- Section 1: Project Bootstrap (directory structure, configuration)
- Section 2: Package Installation (all 14 packages verified)
- Section 3: Environment/Infrastructure Setup (Docker Compose)
- Section 4: Migration Dependency Graph (DAG is correct)
- Section 8: Value Objects and Casts (PhaseSequence VO, morphMap)
- Section 9: Enums (except InstitutionType — see B)
- Section 11: Actions (structure correct; specific Actions need updating — see B)
- Section 12: Domain Events (structure correct)
- Section 13: Policies/RBAC (11 roles, permission naming)
- Section 14: Provenance/Data-Lineage (80/20 model, immutability)
- Section 15: Acquisition/Import Boundary (adapter pattern, staging)
- Section 16: Typesense Projection Architecture
- Section 17: Search/Faceting Implementation
- Section 20: Test Strategy (coverage targets, categories)

## B. Modify

| Step | What to Change | Why |
|------|---------------|-----|
| §5 migration headers | Fix layer counts: §5.1 = 4 (not 6), §5.2 = 5 (not 3) | Arithmetic error |
| §5 table inventory | Add 17 missing canonical tables or explicitly document deferral | 58 vs 41 discrepancy |
| §5 table names | Align with canonical: saves (not bookmarks), comparison_sets (not comparisons), platform_settings (not settings), community_questions (not community_posts), community_votes (not community_likes) | Naming conformance |
| §9 InstitutionType | Reduce to 4 values: university, polytechnic, college_of_education, innovative_enterprise_institution | Canonical alignment |
| §9 Add InstitutionStatus | Add enum: Provisional, Operational, Suspended, Closed | Canonical enum #8/#20 |
| §10.1 Institution lifecycle | Replace draft/active/deprecated with Provisional/Operational/Suspended/Closed; add suspend(), reactivate(), close(), rename(); remove deprecate() | Canonical 03-domain.md §3 |
| §10.1 Institution model | Add is_published (boolean), published_at (nullable timestamp) | Canonical 03-domain.md §3 |
| §10.2 Programme lifecycle | Align with canonical states; separate publication (is_published) from domain status | Canonical 03-domain.md §3 |
| §11 Actions | Add SuspendInstitution, ReactivateInstitution, CloseInstitution, RenameInstitution; remove DeprecateInstitution from Institution; adjust total count | Canonical 03-domain.md §4 |
| §14 provenance trait | Apply HasProvenance to Institution, Programme, Scholarship, AdmissionCycle, CutOffMark (verify list matches canonical) | Canonical specifies which entities get provenance |
| §18/§22 loading states | Add explicit loading/skeleton state specifications for all Livewire components | FIRST-VERTICAL-SLICE-UX.md |
| §21 seed data | Add 9 missing scenarios (conflicting data, missing data, deprecated sources, all enum values, etc.) | Test coverage |
| §22.2 routes | Change `/admissions/{admissionCycle}` to `/admissions/{admissionCycle:slug}` | SEO consistency |
| Decision marker counts | Change to 21 AD / 17 IC | Actual count |

## C. Remove

| Step | What to Remove | Why |
|------|---------------|-----|
| §5 migrations 28-38 | Defer content, engagement, community, notification, settings, SEO tables to post-MVP phase | Not needed for first vertical slice; reduces Phase 1 complexity |
| §5.12 constraint migration | Remove `ei_status_valid` CHECK constraint — the status column should use an Eloquent enum cast, and the DB-level CHECK duplicates application validation unnecessarily | Application-level validation is sufficient for enum columns; DB CHECK for range/temporal constraints is appropriate but not for enum membership |

## D. Add

| Step | What to Add | Why |
|------|------------|-----|
| §5 canonical tables | Add qualification_equivalencies, tuition_fee_ranges (at minimum for first slice) | Referenced in FIRST-VERTICAL-SLICE-UX.md for tuition display and qualification comparison |
| §5 media/notifications infrastructure | Add migrations for spatie/laravel-medialibrary (media table) and Laravel notifications table | Plan installs these packages but doesn't create their tables |
| §5 jobs table | Add Laravel queue jobs table | Required for queued search index and import jobs |
| §2 Phase 2 contract checkpoint | Add explicit "contract freeze" step before parallel work begins in P2 | Shared trait/morphMap contracts must be stable before parallel model implementation |
| §20 test gaps | Add 8 missing test cases (provenance conflict, supersession chain,FExternalIdentifier lifecycle, TrustSignal, import idempotency, SoftDeletes+unique) | Critical invariant coverage |
| §18 Programme Detail | Add "currently admitting" toggle, historical cut-off format (current + 2 previous), annual tuition display, all admission pathways | FIRST-VERTICAL-SLICE-UI.md resolved decisions |
| §18 all pages | Add loading state specifications (skeleton screens during Livewire hydration, search loading indicator) | FIRST-VERTICAL-SLICE-UX.md |
| §5 url_redirects | Add url_redirects table for SEO | Canonical SEO layer |

---

# 18. Final Recommendation

## Corrected High-Level Sequence

### PHASE 0 — Project Bootstrap (1-2 days)

Unchanged from plan. Laravel ^13.0 creation, all 14 packages, Docker Compose, CI pipeline, morphMap registration, Tailwind + Filament + Livewire configuration.

### PHASE 1 — Database Foundation (3-5 days)

**CORRECTED:** Author migrations for all canonical tables needed for the first vertical slice:

| Layer | Tables | Count |
|-------|--------|-------|
| Laravel defaults | users, password_reset_tokens, failed_jobs, personal_access_tokens | 4 |
| Spatie RBAC | permissions, roles, model_has_permissions, model_has_roles, role_has_permissions | 5 |
| Reference | countries, currencies, qualifications, qualification_equivalencies, disciplines | 5 |
| Domain | education_authorities, institutions, programmes, scholarship_providers, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, information_sources, cut_off_marks, external_identifiers, field_provenance | 13 |
| Organization | organization_members | 1 |
| Infrastructure | media, jobs, activity_log, notifications | 4 |
| Staging | import_batches, pending_imports | 2 |
| Constraints | CHECK constraints + partial indexes | 1 |
| **Total** | | **35** |

Deferred to post-MVP: tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries, content pages, engagement (saves, follows, likes, comparison_sets), community, notification_preferences, settings, SEO, url_redirects.

### PHASE 2 — Domain Foundation (10-15 days)

**CORRECTED:**
- Implement **InstitutionStatus** enum (Provisional, Operational, Suspended, Closed) — added
- Reduce **InstitutionType** to 4 values (remove monotechnic, specialized_institution)
- Fix Institution aggregate root lifecycle to match canonical: establish(), suspend(), reactivate(), close(), rename()
- Add is_published/published_at to Institution, Programme, Scholarship
- Add SuspendInstitution, ReactivateInstitution, CloseInstitution, RenameInstitution actions
- **Contract freeze checkpoint** before parallel work begins
- All other steps unchanged

### PHASE 3 — Data Lineage / Import Boundary (3-5 days)

Renamed from plan's Phase 3 (Search/Projections). Import boundary implementation runs in parallel with search setup since adapters are independent of Typesense.

- Adapter implementations (6 adapters)
- Verification engine (duplicate detection, cross-source consistency, schema validation)
- Import workflow jobs
- Staging cleanup logic

### PHASE 4 — Search / Projections (3-5 days)

- Typesense collection schemas
- Scout configuration + toSearchableArray()
- UpdateSearchIndexListener
- Development data seeding (ENHANCED with 9 missing scenarios)
- Search index initial population
- Facet configuration + testing
- SearchIndexRebuildJob

### PHASE 5 — First Vertical Slice (10-15 days)

**CORRECTED estimate** (was 8-12; adjusted for UX gaps):
- Homepage with hero search + loading states
- Programme Search with all 7 facets + mobile filter drawer + loading states
- Facet filter + result card components
- Programme Detail with: "currently admitting" toggle, historical cut-offs (current + 2 previous), annual tuition display, all admission pathways, loading states
- Institution Detail with programme list, external identifiers, loading states
- Admission Information with phase timeline, loading states
- All pages: responsive, accessible, SEO-optimized, loading/empty/error states
- End-to-end Dusk smoke test

### PHASE 6 — Hardening / Testing (5-7 days)

- Full test suite execution
- Code style + static analysis
- Concurrency tests
- Import pipeline end-to-end test
- Performance benchmark
- Security review
- Graceful degradation tests
- Documentation

## Corrected Timeline

| Phase | Duration | Cumulative |
|-------|----------|------------|
| PHASE 0 — Project Bootstrap | 1-2 days | 1-2 days |
| PHASE 1 — Database Foundation | 3-5 days | 4-7 days |
| PHASE 2 — Domain Foundation | 10-15 days | 14-22 days |
| PHASE 3 — Data Lineage / Import | 3-5 days | 17-27 days |
| PHASE 4 — Search / Projections | 3-5 days | 20-32 days |
| PHASE 5 — First Vertical Slice | 10-15 days | 30-47 days |
| PHASE 6 — Hardening / Testing | 5-7 days | 35-54 days |

**Corrected total: 35-54 working days (7-11 weeks for 2-3 developers).**

---

### IMPLEMENTATION READY?

**CONDITIONAL GO** — The implementation plan must correct these exact items before implementation begins:

1. Fix Institution lifecycle: Provisional/Operational/Suspended/Closed (not draft/active/deprecated)
2. Fix Institution domain methods: establish/suspend/reactivate/close/rename (not establish/deprecate)
3. Add InstitutionStatus enum (Provisional, Operational, Suspended, Closed)
4. Reduce InstitutionType to 4 values (remove monotechnic, specialized_institution)
5. Add is_published + published_at to Institution, Programme, Scholarship
6. Align Programme lifecycle with canonical (separate publication from domain status)
7. Fix table inventory: add 17 missing canonical tables or explicitly document deferral with rationale
8. Fix table naming: align with canonical (saves, comparison_sets, platform_settings, community_questions, community_votes)
9. Fix layer migration count headers (§5.1 = 4, §5.2 = 5)
10. Fix decision marker counts (21 AD, 17 IC)
11. Add 8 missing test cases for provenance/lineage invariants
12. Add explicit loading state specifications for all Livewire components
13. Add missing UX decisions from FIRST-VERTICAL-SLICE-UI.md (currently admitting toggle, historical cut-offs, annual tuition, all pathways)
14. Add contract freeze checkpoint in Phase 2 before parallel work
15. Enhance seed data with 9 missing scenarios
16. Add media/jobs/notifications infrastructure tables
17. Use slug-based route for admission cycles

Once these 17 corrections are applied, the plan is GO for implementation. The architecture is sound, the phasing is correct, and no foundational decisions need to be reopened.
