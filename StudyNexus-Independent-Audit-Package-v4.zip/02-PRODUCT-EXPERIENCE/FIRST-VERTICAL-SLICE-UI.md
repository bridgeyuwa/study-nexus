# StudyNexus — First Vertical Slice Visual UI Specification

**Date:** 2026-08-10
**Status:** VISUAL UI DESIGN — awaiting human approval
**Phase:** Visual UI specification (not implementation code)
**UX Baseline:** FIRST-VERTICAL-SLICE-UX.md (behavioral constraint — not replaced)
**Implementation Stack:** TALL — Tailwind CSS ^4.0 + Alpine.js ^3.0 + Livewire ^4.0 + Flux + Blade
**Constraint:** No code written. No canonical documents modified.

---

# 1. Resolved UX Decisions

Before visual design, the open UX questions from `FIRST-VERTICAL-SLICE-UX.md` Section 26 are resolved:

| # | Question | Decision | Rationale | Status |
|---|----------|----------|-----------|--------|
| 1 | "Currently admitting only" default | **Default-off** | Showing all programmes avoids hiding Prospective programmes that may interest users. The toggle is always visible and one tap away. | APPROVE |
| 2 | Historical cut-off count | **Current + 2 previous**, expandable | Two previous years provide trend without clutter. Expandable for users who need more depth. | APPROVE |
| 3 | Tuition display | **Annual** with "per year" label | Nigerian institutions publish annual fees. Total (e.g., ₦600,000 for 4 years) is misleading because fees change. | APPROVE |
| 4 | Discipline browse layout | **Grid (desktop), List (mobile)** | Grid allows scanning many disciplines at once on desktop. List is more touch-friendly on mobile. | APPROVE |
| 5 | Admission pathways on detail | **All pathways visible** with separate cut-offs | Nigerian students need to see UTME and Direct Entry options. Collapsing would hide the very information they came for. | APPROVE |
| 6 | Related scholarships on result cards | **No** — detail page only | Keeps cards scannable. Scholarship relevance is low during initial scan. | APPROVE |
| 7 | Stale-data warning placement | **Inline below header** | Top of page ensures visibility. Not in footer (missed). Not a banner (too intrusive). A subtle but noticeable inline block. | APPROVE |

---

# 2. Visual Design Direction

## 2.1 Visual Personality

**Purposeful clarity.** StudyNexus feels like a serious, trustworthy reference tool — not a marketing site, not a social platform, not a generic dashboard. Think: the visual confidence of a well-designed reference atlas or public records site, adapted for education discovery.

**Analogies for feel (not copy):**
- The focused utility of Google Search results (information-first, minimal decoration)
- The trust signaling of a government information portal (restrained, authoritative)
- The information density of a well-structured reference page (dense but organized)

**What StudyNexus is NOT:**
- A flashy EdTech startup landing page (hero images, gradients, animated illustrations)
- A generic SaaS dashboard (sidebar nav, metric cards, charts)
- A social platform (feeds, reactions, avatars)

## 2.2 Design Principles

| Principle | Meaning | Anti-pattern |
|-----------|---------|-------------|
| **Clarity over decoration** | Every visual element serves an informational purpose | Decorative illustrations, gradients, hero banners on every page |
| **Trust through restraint** | Conservative, professional appearance signals reliability | Playful colors, informal language, excessive animation |
| **Information hierarchy is visual hierarchy** | The most important information is visually dominant | Flat hierarchy where everything looks equally important |
| **Density with structure** | Substantial information presented with clear grouping and spacing | Sparse pages that hide useful information below the fold |
| **Mobile is primary** | Design mobile-first; desktop gets density, not complexity | Desktop layouts shrunk for mobile |
| **Consistency breeds trust** | Same concept = same visual treatment everywhere | Status badges that look different on different screens |
| **Progressive disclosure** | Show essentials first; expand for depth | Everything expanded by default on information-dense pages |

---

# 3. Design Tokens

## 3.1 Color

### Semantic Color Roles

| Role | Purpose | Tailwind Token | Value |
|------|---------|---------------|-------|
| **primary** | Primary actions, links, active states | `--color-primary` | `#1B4332` (deep forest green) |
| **primary-hover** | Primary hover state | `--color-primary-hover` | `#14532D` |
| **primary-light** | Primary backgrounds, subtle highlights | `--color-primary-light` | `#DCFCE7` |
| **secondary** | Secondary actions, supporting elements | `--color-secondary` | `#374151` (cool gray-700) |
| **background** | Page background | `--color-background` | `#FAFAFA` (near-white) |
| **surface** | Card/panel background | `--color-surface` | `#FFFFFF` (white) |
| **surface-elevated** | Elevated elements (dropdowns, sheets) | `--color-surface-elevated` | `#FFFFFF` with shadow |
| **text** | Primary text | `--color-text` | `#111827` (gray-900) |
| **text-muted** | Secondary/metadata text | `--color-text-muted` | `#6B7280` (gray-500) |
| **text-on-primary** | Text on primary backgrounds | `--color-text-on-primary` | `#FFFFFF` |
| **border** | Default borders | `--color-border` | `#E5E7EB` (gray-200) |
| **border-strong** | Emphasized borders | `--color-border-strong` | `#D1D5DB` (gray-300) |

### Status / Lifecycle Colors

| Role | Meaning | Value | Must Also Show |
|------|---------|-------|---------------|
| **status-admitting** | Programme is admitting | `#059669` (emerald-600) | Text label: "Open" |
| **status-prospective** | Not yet admitting | `#D97706` (amber-600) | Text label: "Not yet admitting" |
| **status-suspended** | Admission suspended | `#EA580C` (orange-600) | Text label: "Suspended" |
| **status-discontinued** | Programme discontinued | `#DC2626` (red-600) | Text label: "Discontinued" |
| **status-operational** | Institution operational | `#059669` (emerald-600) | Text label: "Operational" |
| **status-provisional** | Institution provisional | `#D97706` (amber-600) | Text label: "Provisional" |
| **status-closed** | Institution closed | `#DC2626` (red-600) | Text label: "Closed" |

### Semantic Colors

| Role | Purpose | Value |
|------|---------|-------|
| **success** | Positive outcomes, verified info | `#059669` (emerald-600) |
| **warning** | Caution, stale data | `#D97706` (amber-600) |
| **error** | Errors, critical alerts | `#DC2626` (red-600) |
| **info** | Informational notes | `#2563EB` (blue-600) |

**Color rationale:** Deep forest green as primary conveys education, growth, and trust without the coldness of blue or the intensity of red. It is distinct from generic SaaS blue. Status colors use standard semantic mapping (green=positive, amber=caution, orange=warning, red=negative) with **mandatory text labels** — never color alone.

## 3.2 Typography

**Font families:**
- **Headings & body:** Inter (or system sans-serif fallback: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif)
- **Numbers & statistics:** Inter (same family, tabular-nums feature)
- **Naira symbol:** ₦ rendered in Inter with tabular-nums

**Scale (mobile base: 16px / desktop base: 16px):**

| Level | Tailwind Class | Size | Weight | Line Height | Usage |
|-------|---------------|------|--------|-------------|-------|
| **display** | `text-2xl` | 24px | 700 | 1.3 | Homepage hero text only |
| **h1** | `text-xl` | 20px | 700 | 1.3 | Page title (programme name, institution name) |
| **h2** | `text-lg` | 18px | 600 | 1.4 | Section headings (Admission, Tuition, Institution) |
| **h3** | `text-base` | 16px | 600 | 1.5 | Sub-section headings, card titles |
| **body** | `text-base` | 16px | 400 | 1.6 | Body text, descriptions |
| **body-sm** | `text-sm` | 14px | 400 | 1.5 | Supporting text, secondary info |
| **label** | `text-sm` | 14px | 500 | 1.4 | Form labels, section labels, metadata keys |
| **caption** | `text-xs` | 12px | 400 | 1.5 | Metadata values, provenance, timestamps |
| **stat** | `text-2xl` tabular-nums | 24px | 700 | 1.2 | Cut-off mark number, tuition amount |

**Typography rationale:** Inter is highly readable at small sizes (critical for information-dense pages), has excellent tabular-nums for numbers (cut-offs, tuition), and is a Tailwind default. No display/fancy font — StudyNexus is a utility, not a brand showcase.

## 3.3 Spacing

**Base unit:** 4px (Tailwind default). Spacing scale:

| Token | Value | Usage |
|-------|-------|-------|
| **xs** | 4px | Inline spacing, badge padding |
| **sm** | 8px | Compact spacing, metadata gaps |
| **md** | 16px | Default padding, section gaps |
| **lg** | 24px | Section padding, card padding |
| **xl** | 32px | Page section separation |
| **2xl** | 48px | Major section breaks |

**Page margins:** 16px mobile / 24px tablet / 32px desktop (max-content-width: 1280px).

## 3.4 Radius

| Element | Radius | Tailwind |
|---------|--------|----------|
| **Cards** | 8px | `rounded-lg` |
| **Inputs** | 6px | `rounded-md` |
| **Buttons** | 6px | `rounded-md` |
| **Badges** | 4px | `rounded` |
| **Bottom sheet** | 16px top-left + top-right | `rounded-t-2xl` |
| **Chips** | 9999px | `rounded-full` |

**Philosophy:** Subtle rounding (not fully rounded) for cards and inputs. Slightly softer for bottom sheets (friendly on mobile). Pills/chips are fully rounded.

## 3.5 Elevation

| Level | Shadow | Usage |
|-------|--------|-------|
| **none** | No shadow | Page surface, in-page sections |
| **sm** | `shadow-sm` | Result cards (subtle lift from background) |
| **md** | `shadow-md` | Dropdowns, autocomplete, sticky headers |
| **lg** | `shadow-lg` | Bottom sheet, modals |

**Philosophy:** Minimal elevation. Cards use the lightest shadow. Most content sits flat on the surface. Elevation communicates interaction layer, not importance.

## 3.6 Iconography

**Library:** Heroicons (outline style for navigation/secondary, solid for status/badges). Rationale: Heroicons are the default for Livewire/Flux, visually consistent with Tailwind, and include all needed icons.

| Usage | Style | Size |
|-------|-------|------|
| Navigation | outline | 20px |
| Status badges | solid (color-filled) | 16px |
| Actions (search, filter) | outline | 20px |
| Inline indicators | mini (16px) | 16px |

## 3.7 Imagery Strategy

**MVP: No decorative imagery.** No hero photos, no stock university photos, no campus images. Rationale:
- Images are the largest data cost on mobile — StudyNexus prioritizes < 2 MB per page
- Images add visual noise to information-dense pages
- Institution logos (small, < 50 KB) are acceptable if available
- Future Phase 2: institution photos, campus images — but not in the first slice

## 3.8 Interaction Feedback

| Interaction | Feedback |
|------------|----------|
| **Button press** | Scale 0.98 + opacity 0.9 (150ms transition) |
| **Link hover** | Underline + primary color |
| **Card hover** | Subtle border-color change (border → border-strong) |
| **Filter change** | Results fade-out (100ms) → update → fade-in (100ms) |
| **Loading** | Skeleton placeholders (gray-100 pulsing) |
| **Admission status badge** | Static — no animation |
| **Stale-data warning** | Static — no animation (animation implies urgency; staleness is informational) |

---

# 4. Component Inventory

| Component | Purpose | Hierarchy | When Used | When NOT Used |
|-----------|---------|-----------|-----------|---------------|
| **SearchInput** | Text search entry | Primary interaction | Homepage, Results page header | Not on detail pages |
| **AutocompleteDropdown** | Query suggestions | Appears below SearchInput | When SearchInput has ≥ 2 characters | When < 2 chars or search not focused |
| **ResultCard** | Programme summary in search results | Primary content | Search results page | Detail pages, admin |
| **InstitutionCard** | Institution summary in search results | Primary content | Institution search results | Programme results, detail pages |
| **StatusBadge** | Admission/lifecycle status | High prominence | Result cards, detail headers, programme listings | Body text, metadata |
| **FilterSidebar** | Desktop facet controls | Navigation | Desktop results page | Mobile, detail pages |
| **FilterSheet** | Mobile facet controls | Overlay | Mobile results page | Desktop, detail pages |
| **FilterChip** | Active filter representation | Navigation | Above results | Inside filter sidebar/sheet |
| **SectionHeading** | Detail page section header | Content structure | Programme/Institution detail | Search results, cards |
| **MetadataRow** | Key-value pair display | Supporting information | Provenance, source info | Primary content |
| **CutOffDisplay** | Cut-off mark with cycle label | High prominence | Programme detail admission section | Search results (use simpler inline version) |
| **HistoricalCutOffs** | Previous cycle cut-offs | Secondary content | Programme detail, expandable | Search results |
| **TuitionDisplay** | Tuition with currency | Decision-relevant | Programme detail, result cards | Non-programme contexts |
| **Breadcrumbs** | Navigation context | Navigation | All detail pages | Homepage, search results |
| **ProvenanceFooter** | Source/freshness info | Low prominence | Detail page footer | Search results, cards |
| **EmptyState** | No results / no data | Full content area | Zero results, missing sections | Loading, error |
| **SkeletonLoader** | Loading placeholder | Full content area | During data fetch | When data available |
| **AlertBlock** | Warnings, stale data, notices | Contextual | Stale data, discontinued notice | Normal content |
| **Pagination** | Result navigation | Navigation | Search results, programme listings | Detail pages |

---

# 5. Homepage Design

## 5.1 Purpose

Get the user from a question to discovery in one action.

## 5.2 Visual Layout — Desktop

```text
┌─────────────────────────────────────────────────────────────────┐
│  StudyNexus                                    [Programmes] [Institutions] │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│                  Find the right programme for you                │  ← display (24px, 700)
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  🔍  Search programmes and institutions...               │    │  ← SearchInput (full width, max 640px)
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│           Search by programme, institution, or field             │  ← text-muted
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Explore by field of study                                       │  ← h2 (18px, 600)
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │Engineering│  │ Sciences │  │  Arts    │  │ Medicine │       │  ← Discipline grid
│  │    (142)  │  │   (98)   │  │   (76)   │  │   (54)   │       │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │   ICT    │  │ Education│  │  Law     │  │ Social   │       │
│  │   (41)   │  │   (39)   │  │   (28)   │  │  Sci(25) │       │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**Elements:**
- **Header:** Brand name (left) + navigation links (right). Minimal. No hero image.
- **Search section:** Centered. Display text establishes purpose. SearchInput is the primary action. Supporting text below.
- **Discipline grid:** 4 columns desktop / 3 tablet / 2 mobile. Each item is a tappable card with discipline name + programme count. Uses surface color + border. Hover: border-strong.

## 5.3 Visual Layout — Mobile

```text
┌───────────────────────────────┐
│  StudyNexus          [🔍]    │  ← Brand + search icon
├───────────────────────────────┤
│                               │
│  Find the right programme     │  ← display (24px)
│  for you                     │
│                               │
│  ┌──────────────────────────┐│
│  │ 🔍 Search programmes...  ││  ← SearchInput (full width)
│  └──────────────────────────┘│
│                               │
├───────────────────────────────┤
│  Explore by field of study    │
│                               │
│  ┌─────────┐  ┌─────────┐   │  ← 2-column grid
│  │Engineering│  │Sciences │   │
│  │  (142)   │  │  (98)   │   │
│  └─────────┘  └─────────┘   │
│  ┌─────────┐  ┌─────────┐   │
│  │  Arts   │  │Medicine │   │
│  │  (76)   │  │  (54)   │   │
│  └─────────┘  └─────────┘   │
│  ...                          │
└───────────────────────────────┘
```

On mobile, the search icon in the header expands to full-width SearchInput when tapped (Alpine.js toggle). The discipline grid is 2 columns.

---

# 6. Search Design

## 6.1 SearchInput

```text
┌──────────────────────────────────────────────────┐
│  🔍   Search programmes and institutions...       │  ← placeholder in text-muted
└──────────────────────────────────────────────────┘
```

- Height: 48px (touch-friendly)
- Border: 2px border (focus: border-primary)
- Icon: Heroicons magnifying-glass (outline, 20px, text-muted)
- Clear button: X icon appears when text entered (right side, text-muted)
- Focus: border-primary + ring-2 ring-primary-light

## 6.2 AutocompleteDropdown

```text
┌──────────────────────────────────────────────────┐
│  Programmes                                       │  ← group heading (label, text-muted)
│  ─────────────────────────────────────────────── │
│  Computer Science (BSc) — University of Lagos     │  ← programme item
│  Computer Engineering (BSc) — University of Ibadan│
│                                                   │
│  Institutions                                     │  ← group heading
│  ─────────────────────────────────────────────── │
│  University of Lagos — Federal University, Lagos  │  ← institution item
└──────────────────────────────────────────────────┘
```

- Elevation: shadow-md
- Max height: 50vh (scrollable)
- Each item: 48px min height (touch target)
- Hover/active: background primary-light
- Keyboard: up/down to navigate, Enter to select, Esc to close

---

# 7. Results Page Design

## 7.1 Desktop Layout

```text
┌─────────────────────────────────────────────────────────────────────────┐
│  StudyNexus                                    [Programmes] [Institutions] │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │  🔍  Computer Science                                      ✕    │ │  ← SearchInput with query
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ┌─────────────┐                                    ┌──────────────────┐│
│  │  DISCIPLINE  │  Engineering ×  BSc ×  Lagos ×    │  Sort: Relevant ▼││
│  │   ● Eng (142)│  ──────────────────────────────   └──────────────────┘│
│  │   ○ Sci (98) │  142 programmes                                     │
│  │   ○ Arts(76) │                                                     │
│  │              │  ┌─────────────────────────────────────────────────┐  │
│  │  AWARD LEVEL │  │ Computer Science                         [Open] │  │
│  │   ☑ BSc      │  │ BSc · 4 years · On-campus                       │  │
│  │   ☐ MSc      │  │ University of Lagos · Federal · Lagos           │  │
│  │   ☐ HND      │  │ Cut-off: 200  ·  Tuition: ₦150,000/yr          │  │
│  │              │  └─────────────────────────────────────────────────┘  │
│  │  INST TYPE   │                                                     │
│  │   ☑ Univ     │  ┌─────────────────────────────────────────────────┐  │
│  │   ☐ Poly     │  │ Computer Engineering                    [Open]  │  │
│  │              │  │ BSc · 5 years                                    │  │
│  │  STATE       │  │ University of Ibadan · Federal · Oyo            │  │
│  │   ● Lagos    │  │ Cut-off: 195  ·  Tuition: ₦120,000/yr          │  │
│  │   ○ Oyo      │  └─────────────────────────────────────────────────┘  │
│  │              │                                                     │
│  │  ADMISSION   │  ... more results ...                              │
│  │  [☐ Open only]│                                                    │
│  └─────────────┘  ┌──────────────────────────────────────────────────┐ │
│                    │  ← 1  2  3  4  5 ... 8 →                        │ │
│                    └──────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

**Layout:** Filter sidebar (240px fixed width) + Results area (flex-grow). Max content width 1280px.

**Filter sidebar:**
- Each facet is a section with a label (label text, uppercase, tracking-wide)
- Single-select facets: radio buttons (styled as list items)
- Multi-select facets: checkboxes
- Admission toggle: styled as a switch/toggle
- Value counts shown in text-muted
- Scrollable if content exceeds viewport

**Active filter chips:** Between filters and results. Each chip: pill shape (rounded-full), surface color, border, text + × icon. "Clear all" link (primary color) after last chip.

**Result count:** "142 programmes" in body text, text-muted.

## 7.2 Mobile Layout

```text
┌───────────────────────────────┐
│  ←  StudyNexus        [🔍]  │  ← Back + brand + search
├───────────────────────────────┤
│  Computer Science        ✕   │  ← Search query (editable)
│                               │
│  Engineering ×  Lagos ×      │  ← Active filter chips (h-scroll)
│                               │
│  142 programmes  [Filter][Sort]│  ← Count + action buttons
│                               │
│  ┌───────────────────────────┐│
│  │ Computer Science    [Open]││  ← ResultCard
│  │ BSc · 4 years             ││
│  │ UNILAG · Federal · Lagos  ││
│  │ Cut-off: 200 · ₦150,000  ││
│  └───────────────────────────┘│
│                               │
│  ┌───────────────────────────┐│
│  │ Computer Eng.      [Open] ││
│  │ BSc · 5 years             ││
│  │ UI · Federal · Oyo        ││
│  │ Cut-off: 195 · ₦120,000  ││
│  └───────────────────────────┘│
│                               │
│  ... more results ...        │
│                               │
│  [Load more]                  │  ← Infinite scroll trigger
└───────────────────────────────┘
```

**Mobile specifics:**
- No sidebar. "Filter" button opens bottom sheet.
- "Sort" button opens a simple bottom sheet with sort options.
- Result cards are full-width, single column.
- Infinite scroll (not pagination) for mobile — "Load more" button at bottom.
- Active filter chips: horizontal scroll with momentum.

## 7.3 Result Card Design

### Full Data Card

```text
┌───────────────────────────────────────────────────┐
│  Computer Science (BSc)                    [Open]  │  ← h3 + StatusBadge
│                                                    │
│  University of Lagos · Federal University · Lagos  │  ← body-sm, text-muted
│                                                    │
│  Cut-off: 200           Tuition: ₦150,000/yr      │  ← label keys, stat values
│  2025/2026 cycle                                    │  ← caption, text-muted (cycle context)
└───────────────────────────────────────────────────┘
```

**Visual hierarchy within card:**
1. Programme name (h3, 16px, 600, text-primary) — dominant
2. StatusBadge — high prominence, right-aligned
3. Institution + type + location (body-sm, text-muted) — supporting
4. Cut-off + tuition (label key + stat value) — decision-relevant but secondary to name
5. Cycle context (caption, text-muted) — contextual

### Partial Data Card

```text
┌───────────────────────────────────────────────────┐
│  Philosophy (BA)                    [Not yet admitting]│
│                                                    │
│  University of Benin · Federal · Edo State         │
│                                                    │
│  Cut-off: Not available    Tuition: Not available  │  ← text-muted italic
└───────────────────────────────────────────────────┘
```

Missing values shown in text-muted italic: "Not available". Never "—" or blank.

---

# 8. Filter Design

## 8.1 StatusBadge Component

```text
┌──────────┐
│ ●  Open   │   ← solid dot (status-admitting) + text label
└──────────┘
```

| Status | Dot Color | Label | Background |
|--------|-----------|-------|------------|
| Admitting | emerald-600 | "Open" | emerald-50 |
| Prospective | amber-600 | "Not yet admitting" | amber-50 |
| Suspended | orange-600 | "Suspended" | orange-50 |
| Discontinued | red-600 | "Discontinued" | red-50 |
| Operational | emerald-600 | "Operational" | emerald-50 |
| Provisional | amber-600 | "Provisional" | amber-50 |
| Closed | red-600 | "Closed" | red-50 |

**Consistency rule:** This exact badge style is used everywhere — result cards, detail headers, programme listings within institution pages. Never varies.

## 8.2 FilterChip

```text
┌─────────────────┐
│  Engineering  ✕  │   ← pill shape, surface bg, border, text + ×
└─────────────────┘
```

- Height: 32px
- Text: body-sm
- × icon: 16px, text-muted
- Tap ×: removes filter, updates results

## 8.3 Bottom Sheet (Mobile Filter)

```text
┌───────────────────────────────┐
│         ═══                    │  ← drag handle
│  Filter programmes             │  ← sheet title (h2)
│                                │
│  [☐] Currently admitting only  │  ← toggle, always visible
│                                │
│  ▸ Discipline                  │  ← accordion header (chevron-right)
│  ▸ Award level                 │
│  ▸ Institution type            │
│  ▸ State                       │
│  ▸ Ownership type              │
│  ▸ Delivery mode               │
│                                │
│  ┌──────────┐  ┌──────────┐   │
│  │  Clear   │  │  Show 142 │   │  ← Clear (secondary) + Apply (primary)
│  └──────────┘  └──────────┘   │
└───────────────────────────────┘
```

**Expanded accordion (e.g., Discipline):**

```text
│  ▾ Discipline                  │
│    ● Engineering (142)         │  ← radio list
│    ○ Sciences (98)             │
│    ○ Arts & Humanities (76)    │
│    ○ Medicine & Health (54)    │
│    ○ ...                       │
```

- Sheet takes ~70% of viewport height
- Drag handle for dismiss
- Backdrop tap: dismiss without applying
- "Show N" button updates count as filters are selected (Typesense facet counts)

---

# 9. Programme Detail Design

## 9.1 Page Layout — Desktop

```text
┌─────────────────────────────────────────────────────────────────────┐
│  StudyNexus                                    [Programmes] [Institutions]│
├─────────────────────────────────────────────────────────────────────┤
│  Home > Programmes > Engineering > Computer Science (UNILAG)        │  ← Breadcrumbs
│                                                                      │
│  Computer Science (BSc)                                     [Open]   │  ← h1 + StatusBadge
│  University of Lagos · Federal University                            │  ← h3 link (primary)
│  Lagos, Lagos State · 4 years · On-campus                           │  ← body-sm, text-muted
│                                                                      │
│  ── Admission ─────────────────────────────────────────────────────  │  ← SectionHeading
│                                                                      │
│  Status: Currently admitting                                         │  ← label + value
│                                                                      │
│  Cut-off mark                                                        │  ← h3
│    2025/2026:  200                                                   │  ← stat (current, primary color)
│    2024/2025:  190                                                   │  ← body (historical, text-muted)
│    2023/2024:  185                                                   │  ← body (historical, text-muted)
│                                                                      │
│  Requirements                                                        │  ← h3
│    JAMB subjects: English, Mathematics, Physics, Chemistry           │
│    Post-UTME: Required                                               │
│    O-level: 5 credits including English, Mathematics                 │
│                                                                      │
│  Admission cycle                                                     │  ← h3
│    2026/2027 cycle · Registration open                               │
│    Deadline: 15 May 2026                                             │
│                                                                      │
│  ── Tuition ──────────────────────────────────────────────────────   │
│                                                                      │
│  ₦150,000 per year                                                   │  ← stat
│  Source: Institution website · Updated: Mar 2026                     │  ← caption, text-muted
│                                                                      │
│  ── Institution ──────────────────────────────────────────────────   │
│                                                                      │
│  University of Lagos                                    → View       │  ← h3 link + arrow
│  Federal University · Public                                         │
│  Akoka, Lagos, Lagos State                                           │
│  Accreditation: NUC — Full (valid until 2028)                       │  ← with success color indicator
│                                                                      │
│  ── About this programme ─────────────────────────────────────────   │
│                                                                      │
│  Discipline: Engineering                                             │
│  [Description text if available]                                     │
│                                                                      │
│  ── Related programmes ───────────────────────────────────────────   │
│                                                                      │
│  At University of Lagos:                                             │
│    Computer Engineering (BSc)    [Open]   Cut-off: 195              │
│    Electrical Engineering (BSc)  [Open]   Cut-off: 210              │
│                                                                      │
│  Computer Science at other institutions:                             │
│    Computer Science — UNIBEN     [Open]   Cut-off: 180              │
│    Computer Science — OAU        [Open]   Cut-off: 175              │
│                                                                      │
│  ─────────────────────────────────────────────────────────────────   │
│  Last updated: 20 Jul 2026                                          │
│  Source: JAMB Official Brochure 2026 · Institution website           │
│  Report incorrect information →                                      │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

**Content width:** max 720px (readable line length). Centered.

**Section separation:** SectionHeading component — h2 text with a thin top border (border color) and lg spacing above. Creates clear visual grouping without card-in-card nesting.

## 9.2 Historical Cut-Off Visual Treatment

```text
  Cut-off mark
    2025/2026:  200        ← 24px, 700, primary color
    2024/2025:  190        ← 16px, 400, text-muted
    2023/2024:  185        ← 16px, 400, text-muted
```

**Visual distinction between current and historical:**
- **Current cycle** cut-off: stat size (24px, 700 weight, primary color). This is the number the student compares against their score — it must be impossible to miss.
- **Historical cut-offs:** body size (16px, 400 weight, text-muted color). Indented 16px from the current value. Clearly secondary.
- **Cycle labels** are always shown (e.g., "2025/2026:"). Never show a number without its cycle.
- **Expandable:** If > 3 historical values, show first 2 + "Show earlier years" link (Alpine.js toggle).

**Missing current-year cut-off:**

```text
  Cut-off mark
    2025/2026:  Not yet published        ← body, text-muted, italic
    2024/2025:  190                      ← body, text-muted (last known)
    2023/2024:  185
```

The most recent historical value becomes the visual anchor. "Not yet published" is explicit about why current data is missing.

## 9.3 Mobile Layout

Same content, stacked vertically. Key differences:
- Breadcrumbs collapse to: `← Engineering` (back link + parent context)
- Admission section: always fully expanded (never accordion on mobile)
- Historical cut-offs: if > 2, current + 1 visible, "Show earlier" expandable
- Related programmes: horizontal scrollable cards instead of vertical list
- Provenance footer: same content, smaller text

---

# 10. Institution Detail Design

## 10.1 Page Layout

```text
┌─────────────────────────────────────────────────────────────────────┐
│  Home > Institutions > University of Lagos                          │  ← Breadcrumbs
│                                                                      │
│  University of Lagos                                         [Operational]│
│  Federal University · Public                                        │
│  Akoka, Lagos, Lagos State                                          │
│                                                                      │
│  ── Accreditation ──────────────────────────────────────────────     │
│                                                                      │
│  NUC: Full accreditation                                            │
│  Valid until: 2028                                                   │
│  Source: NUC accreditation list · Verified: Jan 2026                 │
│                                                                      │
│  ── Programmes (87) ────────────────────────────────────────────    │
│                                                                      │
│  [All]  [Admitting]                  Filter: [Discipline ▼]        │
│                                                                      │
│  Computer Science (BSc)           [Open]   Cut-off: 200             │
│  Computer Engineering (BSc)       [Open]   Cut-off: 195             │
│  Medicine (MBBS)                  [Open]   Cut-off: 280             │
│  Law (LLB)                        [Open]   Cut-off: 250             │
│  ... (paginated, 20 per page)                                       │
│                                                                      │
│  ── About ──────────────────────────────────────────────────────    │
│                                                                      │
│  Year established: 1962                                             │
│  Website: unilag.edu.ng →                                          │
│                                                                      │
│  ─────────────────────────────────────────────────────────────────   │
│  Last updated: 20 Jul 2026                                          │
│  Source: NUC accreditation list · Institution website               │
│  Report incorrect information →                                      │
└─────────────────────────────────────────────────────────────────────┘
```

**Programme listing within institution:**
- "All" / "Admitting" tabs: horizontal toggle buttons (not full tab component)
- Discipline filter: native select dropdown (populated with disciplines at this institution)
- Each programme row: programme name (link, primary color) + award level + StatusBadge + cut-off (if available)
- Compact layout: no card wrapper, just rows with border-b separators
- Pagination at bottom (20 per page)

---

# 11. Incomplete-Data Design

## 11.1 Missing Critical Fields

| Missing Field | Visual Treatment | Example |
|---------------|-----------------|---------|
| Cut-off mark | Label in text-muted + "Not available" in text-muted italic | `Cut-off: Not available` |
| Tuition | Same | `Tuition: Not available` |
| Admission requirements | Section present with message in body, text-muted | `Admission requirements not yet published` |
| Accreditation | Label + "Not yet verified" in text-muted italic | `Accreditation: Not yet verified` |

**Rule:** Missing critical information is explicitly stated. The user never wonders if the field is loading or missing.

## 11.2 Missing Non-Critical Fields

| Missing Field | Visual Treatment |
|---------------|-----------------|
| Description | Section omitted entirely |
| Year established | Metadata row omitted |
| Duration | Omitted from header metadata line |
| Delivery mode | Omitted (assumed OnCampus) |

**Rule:** Missing non-critical information is silently omitted. No "No description available" placeholders.

## 11.3 Stale Data Warning

When data was last verified > 180 days ago:

```text
┌───────────────────────────────────────────────────────────────┐
│  ⚠  Information may be outdated — verify with the institution │
└───────────────────────────────────────────────────────────────┘
```

- Appears below the page header, above admission section
- Background: amber-50, border-left: 3px amber-600, text: amber-800
- Icon: Heroicons exclamation-triangle (solid, 16px)
- Dismissible: No — stale data is a genuine warning, not a preference

---

# 12. Trust / Freshness Design

## 12.1 Provenance Footer

```text
─────────────────────────────────────────────────
Last updated: 20 Jul 2026
Source: JAMB Official Brochure 2026 · Institution website
Report incorrect information →
```

- Separator: thin top border (border color)
- "Last updated": caption, text-muted
- "Source": caption, text-muted. Two sources max, separated by "·"
- "Report incorrect information": link, primary color, caption size

## 12.2 Freshness in Detail Page Footer

| Time Since Update | Display |
|-------------------|---------|
| < 7 days | "Updated X days ago" (subtle, not shown — information is fresh) |
| 7–90 days | "Updated X days ago" in footer |
| 90–180 days | "Last updated X months ago" in footer |
| > 180 days | Stale-data warning (Section 11.3) + footer timestamp |

---

# 13. Lifecycle-State Design

All lifecycle states use the StatusBadge component (Section 8.1). The visual treatment is **consistent across all contexts**:

| Context | Badge Style |
|---------|------------|
| Result card | Same StatusBadge |
| Programme detail header | Same StatusBadge |
| Institution programme listing row | Same StatusBadge (compact: dot + label only, no background) |

**Compact variant** (for programme listing rows within institution detail):
```text
● Open    ← dot + text only, no background pill, body-sm
```

---

# 14. Screen-State Matrix

| Screen | Default | Loading | Empty | Error | Partial Data | Discontinued/Closed |
|--------|---------|---------|-------|-------|-------------|---------------------|
| **Homepage** | Search + discipline grid | Skeleton disciplines | "No disciplines available" | "Something went wrong" | N/A | N/A |
| **Search Results** | Results + filters | Skeleton cards | "No programmes match" + suggestions | "Search unavailable" | N/A | N/A |
| **Programme Detail** | Full page | Skeleton sections | N/A (404 if not found) | "Something went wrong" | Sections with "Not available" | Notice + historical info |
| **Institution Detail** | Full page | Skeleton sections | N/A (404 if not found) | "Something went wrong" | Sections with "Not verified" | Notice + historical info |

### Skeleton Loader Design

```text
┌───────────────────────────────────────────┐
│  ████████████████           ████████      │  ← gray-100, pulse animation
│  █████████████████████████████            │
│  ███████████████████                      │
│  ████████          ██████████             │
└───────────────────────────────────────────┘
```

Gray-100 rectangles with `animate-pulse`. Roughly matches the shape of the content that will load. 3–5 skeleton cards for results, 3 skeleton sections for detail.

---

# 15. Mobile Design Summary

| Element | Desktop | Mobile |
|---------|---------|--------|
| **Navigation** | Top bar with links | Top bar with search icon; bottom tab bar (Programmes, Institutions) on results pages |
| **Search** | Full-width SearchInput in page | Search icon → expandable full-width input |
| **Filters** | Left sidebar (240px) | "Filter" button → bottom sheet |
| **Sort** | Dropdown above results | "Sort" button → bottom sheet |
| **Result cards** | 2-column grid on wide screens | Single column, full width |
| **Active filters** | Chips above results | Horizontal scrollable chips |
| **Pagination** | Numbered pages | Infinite scroll with "Load more" |
| **Programme detail** | Max 720px, centered | Full width, 16px margins |
| **Historical cut-offs** | Inline, all visible | Expandable accordion if > 2 |
| **Related programmes** | Vertical list | Horizontal scroll cards |
| **Breadcrumbs** | Full path | Collapsed: back arrow + parent |
| **Institution programme list** | Table-like rows | Card list |
| **Status badges** | Pill with background | Same (consistent) |

---

# 16. Accessibility Considerations

| Area | Specification |
|------|--------------|
| **Contrast** | All text meets WCAG 2.2 AA 4.5:1 ratio. StatusBadge text on colored background meets 4.5:1. Stat values on white background meet 4.5:1. |
| **Focus states** | All interactive elements have visible focus ring (ring-2, ring-primary-light, ring-offset-2). Focus order: logical (search → results → pagination → detail). |
| **Keyboard** | SearchInput: Enter to submit, Esc to close autocomplete, Arrow keys in autocomplete. Filters: Tab through controls, Space to select. Cards: Enter to navigate. |
| **Semantics** | h1 = page title (1 per page). h2 = sections. h3 = sub-sections. Lists use ul/li. StatusBadge uses aria-label. |
| **Color independence** | StatusBadge always has text label. Stale warning has icon + text. Cut-off current vs historical distinguished by size + weight + color (3 cues). |
| **Touch targets** | Minimum 44×44px for all interactive elements. Filter checkboxes: 24px hit area + 8px gap. Result cards: full card is tappable. |
| **Screen reader** | Autocomplete: aria-expanded, aria-activedescendant. Filter changes: aria-live="polite" for result count. Loading: aria-busy="true". |
| **Reduced motion** | Skeleton pulse respects prefers-reduced-motion (no animation). Card hover respects (no transition). |

---

# 17. Backend/UI Reconciliation

| UI Requirement | Data Required | Existing Source | Change Required? |
|---------------|---------------|-----------------|:----------------:|
| Discipline grid on homepage | Discipline name + slug + programme count | `disciplines` table (T-04) + Typesense facet count | No |
| Search autocomplete | Programme name + institution name | Typesense multi-search | No |
| Result card (full) | name, award_level, institution_name, institution_type, location, cut_off_latest, tuition, is_admission_open | All in Typesense programme document | No |
| Result card (partial) | Same fields, null handling | Same — nulls handled in Blade template | No |
| StatusBadge | ProgrammeStatus / InstitutionStatus | Stored in `status` column | No |
| Programme detail admission | AdmissionPolicy + CutOffMark + AdmissionCycle | PostgreSQL/Eloquent eager load | No |
| Historical cut-offs | cut_off_marks rows ordered by cycle | `cut_off_marks` table (T-03) | No |
| Institution programme listing | Programmes scoped to institution | Eloquent eager load | No |
| Accreditation display | AccreditationRecord | Child entity, eager load | No |
| Related programmes | Same discipline, same institution | Eloquent queries | No |
| Related scholarships | Scholarship targeting programme/institution | Pivot queries | No |
| Provenance footer | provenance JSON + updated_at | On all domain entities | No |
| Breadcrumbs | Route model binding | Laravel routing | No |
| Structured data | Schema.org JSON-LD | Blade templates | No |
| Filter facet counts | Typesense facet_counts | Typesense response | No |
| Sort by cut-off/tuition | cut_off_latest, tuition_min/max | Typesense sort fields | No |

**No backend changes required.** The visual design is fully supported by the existing canonical architecture and approved changes.

---

# 18. Remaining Decisions

| # | Decision | Recommendation | Who Must Decide |
|---|----------|---------------|-----------------|
| 1 | **Primary color** — forest green (#1B4332) or different? | Forest green communicates education + trust. Distinct from generic SaaS blue. | Human approval |
| 2 | **Font choice** — Inter (system fallback) or web font? | Inter via CDN with system fallback. Fast, readable, Tailwind-compatible. | Human approval |
| 3 | **Content width** — 720px for detail pages? | 720px provides readable line length (65–75 characters per line). | Human approval (can adjust) |
| 4 | **Skeleton vs spinner** for loading states? | Skeleton (matches content shape, reduces layout shift) | Low risk — can change in implementation |

All other visual decisions are specified above and ready for implementation review.

---

*This document is a visual UI specification, not implementation code. No canonical documents were modified. No Laravel code was written. The UX behavioral specification (FIRST-VERTICAL-SLICE-UX.md) remains authoritative.*
