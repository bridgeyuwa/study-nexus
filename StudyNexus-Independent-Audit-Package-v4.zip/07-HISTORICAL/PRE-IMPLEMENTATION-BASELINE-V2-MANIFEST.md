# StudyNexus — Pre-Implementation Baseline v2 Manifest

**Date:** 2026-08-19
**Version:** 4.1
**Status:** REMEDIATED V4.1 (OKLCH theming, Sky/Cyan/Teal/Emerald palette, dark mode, Refactoring UI rules, auth stack & UI boundaries, organization portal workflow, hash updates)

---

## File Inventory

| # | Path | SHA-256 | Size (bytes) | Category |
|---|------|---------|-------------|----------|
| 1 | `MANIFEST.md` | `4011b806dc65c8031c137ef740bece8cd90ebb0ffe470f7bbae2ffcb9ba5ce75` | 237 | Baseline |
| 2 | `PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md` | `2153a8aa834de3cc41e0fd645a23130470617ff0cee9472dd8ea59960c220c2c` | 8615 | Baseline |
| 3 | `README.md` | `bc1cd7d984976e2f17c0dc0d47dcd12951f0b832045ec4e8b44edd529649d0e5` | 4722 | Baseline |
| 4 | `archive/00-documentation-audit-report.md` | `5de4bd505d046ac30d4344cf9d99b8249c1f0debd8047e3d4659526bf0a4a21e` | 39641 | Historical |
| 5 | `archive/00-reconciliation-proposal.md` | `d3945637546b8b69a4e11e8623719ff34c8314dce3f9cc9605603d3aa675eae3` | 30005 | Historical |
| 6 | `archive/01-business-overview.md` | `70a5bd289c8b2945350cc3dfe27a6f727db770e84a5f60740f529db457c5fde4` | 12843 | Historical |
| 7 | `archive/02-glossary.md` | `a64bc423478e4c75cc5459bd69f0961c61f6c9d0155a163db003f1e9178b20bc` | 8538 | Historical |
| 8 | `archive/03-approved-decisions.md` | `2cea05b2ef3eca41cd7ea37c6b5f9a3246d462eab178a2a4b385ea30335ee620` | 16118 | Historical |
| 9 | `archive/04-open-questions.md` | `11962f984e517c02f753b9b25030e2c1257e98d4169f4be2d5790903792055f4` | 7981 | Historical |
| 10 | `archive/06-business-workflows.md` | `717c602d5b612f3193ab87f473b026b69872a298f7294d71cf1d3f4ddea57f3d` | 20707 | Historical |
| 11 | `archive/07-business-discovery-closure.md` | `6ed21ab4b355541e3a5c8a4cd860a7b06b8f438ea6ea7a162bd4d7f841b64129` | 11123 | Historical |
| 12 | `archive/08-traceability-matrix.md` | `fbbb93de3459a14257b4a82286e6f71d5c42a2f50765e6da0a4d594e795d5530` | 12765 | Historical |
| 13 | `archive/09-business-discovery-freeze.md` | `c1dfad3462d93eaf6070bc556eb819183316c2fa44e110ad57f9c0a1fdfc428c` | 4487 | Historical |
| 14 | `archive/11-domain-discovery-topic2.md` | `b30bcbe451451ab34c823d5257b0050b5dd9917acd788264577a2023766aa0dd` | 92266 | Historical |
| 15 | `archive/12-domain-discovery-topic2-revision.md` | `0ed1e8597ec733b16ca8f0951550125cac027815fda817bf2671b8e3626ac3c3` | 62702 | Historical |
| 16 | `archive/13-domain-discovery-consolidation.md` | `82d25a326e4676a9e83c11279c28c2bfe916eb56e3d605e4df2590b340be4f07` | 75673 | Historical |
| 17 | `archive/14-architectural-review-global-domain.md` | `15eebf8a7845c74a562e971baffc4ca07f66207b0eb75555deb14dc13a1b2279` | 34976 | Historical |
| 18 | `archive/15-domain-discovery-topic4-behaviour.md` | `8be2133dd4302515abd32ae97d4264deda9ae5577a7caf66dd89bc9125ab29cc` | 139882 | Historical |
| 19 | `archive/16-domain-discovery-topic3.md` | `f6ce0caa6457b3b573ea7ef4f245c563eac474958ad2c37dca96d2dcf6d76608` | 98591 | Historical |
| 20 | `archive/17-domain-integrity-review.md` | `208a4a7610ee77bd3ea92175ca7781200b2ca5122b0dcdd95e6e197a5445ba46` | 56794 | Historical |
| 21 | `archive/18-domain-resolution-analysis.md` | `8e9a38de60815f397e77a4631f3d845042dd186e5b018280fb8451dd6b0bab0c` | 67941 | Historical |
| 22 | `archive/19-domain-architecture.md` | `0d9e019903321b227c8d399c14a8aa926e7f78c90361653145dc9a25afd4561b` | 114709 | Historical |
| 23 | `archive/20-domain-architecture-validation.md` | `333f179e116447071bec460a6704ed5576d8e6238060b4fec5f91310df8b66be` | 95160 | Historical |
| 24 | `archive/21-domain-architecture-frozen-baseline.md` | `5714e0c76d2cc9c87b61af4eea0a267ffbaf815376332f9b84d5e1c97de1ba9c` | 108803 | Historical |
| 25 | `archive/22-post-freeze-platform-architecture-review.md` | `886716950b7b3ba5a9dfcef3fedcfb467eb66b1c3860b80323d43b856f308da3` | 79823 | Historical |
| 26 | `archive/23-laravel-ecosystem-build-vs-buy-review.md` | `c09fa4f087aca72d3921e8525450afef3d9edd9c719fd211c77268743be52c29` | 116374 | Historical |
| 27 | `archive/24-final-platform-and-capability-architecture.md` | `217973d4b8416b598b5f2bcca737799bed40d08d73756fabbc524549ad91b9fa` | 117115 | Historical |
| 28 | `archive/26-pre-implementation-reconciliation.md` | `fd8691af9a925206dd726cbf32983d1873304fe2f9a387ab51c558a6b0d711ad` | 57858 | Historical |
| 29 | `archive/27-final-corrected-pre-implementation-blueprint.md` | `c9a0bdaf8cc2c3e8fd18ee1440e025737e821477605e34cb57f68d57cf55a8b9` | 85973 | Historical |
| 30 | `archive/28-package-verification-audit.md` | `bcd2c53ee3004be3d6f16e80bbe72d442122502d69526a63cdc7f780cd3ebbac` | 57038 | Historical |
| 31 | `archive/29-rbac-decision.md` | `992b84c7d063f6b4a9d7db3209d98030705a650c76ad81397f1cd23e391910f7` | 4203 | Historical |
| 32 | `archive/30-data-acquisition-pipeline.md` | `18c7c1d07abf6b1f66eb4a5a234f462335bc293f2356bc00e410b1a670e28c69` | 19684 | Historical |
| 33 | `archive/HISTORICAL-README.md` | `5a6114b1f966f3da4b8c240b479451451d1f3b1f9594885966d2f8a1285e1f20` | 5602 | Historical |
| 34 | `archive/VERIFICATION-REPORT.md` | `eae4fc33ca1158b08948e1fe4a6936607d4cf09917e53a4ac95cb97aa15c7b98` | 39637 | Historical |
| 35 | `canonical/01-business.md` | `c0248291bdda23d03f2a592dd036864f15f9c7cdb47bce869fad5dd8198e7e01` | 48139 | Canonical |
| 36 | `canonical/02-decisions.md` | `b20f567391416ae3be450b10014418c61a794ca1e42e9a1556d802578f2e9535` | 73761 | Canonical |
| 37 | `canonical/03-domain.md` | `e6f73f2f4f1d02893cc4f30c9ab3fe58d37d5b32620d1a9f94476616031d2e8b` | 76682 | Canonical |
| 38 | `canonical/04-architecture.md` | `6d3e3cac4ce081f68f15886bf57441ab250ba8f563f1e16a9443d1fe8d1565ed` | 69218 | Canonical |
| 39 | `canonical/05-implementation.md` | `4dc1c0ce740e3ccf8c15762a5a353bff3072bf1b5df6116a0dda2469c2ad4f69` | 101964 | Canonical |
| 40 | `canonical/06-data-acquisition.md` | `7269a2e9020715297493b443fa1b9a8a4b8efce7df87848d80021984551a7b31` | 21942 | Canonical |
| 41 | `governance/ADVERSARIAL-DECISION-REVIEW.md` | `5a62bf40af2041a22ac3f5169e34455dc005ff032aed66ad0b5195fdd304431c` | 132336 | Governance |
| 42 | `governance/CANONICAL-AMENDMENT-REPORT.md` | `95c8a3fc49a889cf83fada2239bf2cb4c7165775924312a07c928dc6fccb8401` | 12695 | Governance |
| 43 | `governance/CANONICAL-CONSISTENCY-AUDIT.md` | `0939f0c1a439373453ff4cb26ceecbaf53f3fe65efda48820973acdc758c97a2` | 20262 | Governance |
| 44 | `governance/CANONICAL-UPDATE-REPORT.md` | `3349b8b317edc674d09dbc14dcc3d05d453c401f6b5408b84a1c0799c032aeea` | 15525 | Governance |
| 45 | `governance/DISCOVERY-CLOSURE.md` | `38a7fd221b4773f59b70b868c985d6ae350497f34aae105a91c968d614884cb1` | 36718 | Governance |
| 46 | `governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md` | `aa4f2cded2f1b917dd23098df63c8db649fa6cfb760f1fb075550706b1b0b45a` | 38186 | Governance |
| 47 | `governance/FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md` | `128459465c6a84bdd92f5d660d22788a40b2b2aef05f0084038278a44b35de97` | 43174 | Governance |
| 48 | `governance/FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md` | `0f625e66d9f6b35a0569854a71ac482de28d0cc2686f5e9676dd1b93d1fc91ce` | 67039 | Governance |
| 49 | `governance/FOUNDATIONAL-DECISIONS-BRIEF.md` | `47ca0be904cdbcb54e536d9c06cb307b5f2a1303f278751f2406223ef37f3c07` | 68529 | Governance |
| 50 | `governance/SECOND-ORDER-ARCHITECTURE-REVIEW.md` | `dc2e37f8cdc76a14a61bece90eb68f67e65637af0c9befdbb45d111d6176a6cc` | 75337 | Governance |
| 51 | `product-experience/FIRST-VERTICAL-SLICE-UI.md` | `a1b3e5dd59e48a7ab173bd3139020be51428c335990f5148fc2fd76dd694e9ba` | 55015 | Product Experience |
| 52 | `product-experience/FIRST-VERTICAL-SLICE-UX.md` | `9bab280b9983c6225af616da0de7a8a66a042bdb701b6141466eda8bc33b928b` | 51755 | Product Experience |
| 53 | `product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md` | `2a6c92175b94cc4936591ac321fb357e4878c885d18c651051eeb8863e7158f5` | 92691 | Product Experience |
| 54 | `product-experience/PRODUCT-EXPERIENCE-DISCOVERY.md` | `c1b7d7aeec13283a87a4104c37d43cd1a686b9bced49dc6fe10f012f30b29d34` | 63696 | Product Experience |

---

## Verification

All SHA-256 hashes recomputed on 2026-08-19 after V4.1 remediation (OKLCH theming with Sky/Cyan/Teal/Emerald palette, dark mode, Refactoring UI principles, auth stack & UI boundary mandates, organization portal pending revision workflow, Laravel Fortify + Flux Pro auth). Every file is plain text Markdown. No binary content embedded.
