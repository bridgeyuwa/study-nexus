# StudyNexus — Pre-Implementation Baseline v2

**Version:** 2.0
**Date:** 2026-08-17
**Status:** FROZEN — Immutable implementation reference
**Supersedes:** PRE-IMPLEMENTATION-BASELINE v1 (2026-08-08)

---

## What This Is

This is the **frozen pre-implementation baseline v2** for StudyNexus, a Nigeria-first, search-first education discovery platform. It captures the architectural state after all canonical amendments from the review and resolution process (adversarial review → second-order review → ADR-DL1 → hostile schema review → lineage semantics resolution → canonical amendment).

This baseline is the **single authoritative reference** for implementation. Where any other document conflicts with this baseline, this baseline prevails.

## What Changed From v1

The v1 baseline (2026-08-08) captured the initial frozen state before the deep architectural review process. The v2 baseline reflects:

- **BD-1**: Uniform BIGINT PKs for all canonical tables (disciplines, cut_off_marks converted from UUID)
- **BD-3**: PhaseSequence JSONB + stable phase IDs for AdmissionCycle (replaces timestamp-based phases)
- **BD-5**: Generic external_identifiers model (no jamb_code/nuc_code columns on entities)
- **ND-5**: InformationSource as independent aggregate root (no institution_id, nullable authority_id)
- **ND-4**: Hybrid provenance model (entity-level JSONB + field_provenance 80/20, Category A=5, Category B=6)
- **Concurrency**: lockForUpdate() for AdmissionCycle phase transitions
- **Enum alignment**: All 16 enums consistent across canonical documents
- **Migration readiness**: ON DELETE behaviors, CHECK constraints, index specifications, partial unique indexes fully specified
- **Source-reference semantics**: source_id ON DELETE distinction documented (RESTRICT for provenance/identifiers, SET NULL for attribution)

## Directory Structure

```
PRE-IMPLEMENTATION-BASELINE-V2/
├── README.md                              (this file)
├── MANIFEST.md                            (file inventory with SHA-256 hashes)
├── PRE-IMPLEMENTATION-BASELINE-V2-REPORT.md (baseline creation report)
├── canonical/                             (6 canonical documents — AUTHORITATIVE)
│   ├── 01-business.md
│   ├── 02-decisions.md
│   ├── 03-domain.md
│   ├── 04-architecture.md
│   ├── 05-implementation.md
│   └── 06-data-acquisition.md
├── product-experience/                    (4 product experience documents)
│   ├── PRODUCT-EXPERIENCE-DISCOVERY.md
│   ├── PRODUCT-EXPERIENCE-ARCHITECTURE.md
│   ├── FIRST-VERTICAL-SLICE-UX.md
│   └── FIRST-VERTICAL-SLICE-UI.md
├── governance/                            (ADR, review, and amendment records)
│   ├── DISCOVERY-CLOSURE.md
│   ├── CANONICAL-UPDATE-REPORT.md
│   ├── FINAL-LINEAGE-SEMANTICS-RESOLUTION.md
│   ├── FINAL-TARGETED-SCHEMA-PROVENANCE-HOSTILE-REVIEW.md
│   ├── FOUNDATIONAL-DECISIONS-ADVERSARIAL-REVIEW.md
│   ├── ADVERSARIAL-DECISION-REVIEW.md
│   ├── FOUNDATIONAL-DECISIONS-BRIEF.md
│   ├── SECOND-ORDER-ARCHITECTURE-REVIEW.md
│   ├── CANONICAL-AMENDMENT-REPORT.md
│   └── CANONICAL-CONSISTENCY-AUDIT.md
└── archive/                               (historical — NON-AUTHORITATIVE)
    └── ... (21 historical discovery/review documents)
```

## How To Use This Baseline

1. **Read the canonical documents first.** They are the source of truth for the domain model, architecture, and implementation blueprint.
2. **Read governance/FINAL-LINEAGE-SEMANTICS-RESOLUTION.md** to understand the semantic decisions that shaped the final architecture.
3. **Read governance/CANONICAL-AMENDMENT-REPORT.md** to understand exactly what changed from v1.
4. **Do NOT treat archive/ as authoritative.** Archive documents are historical evidence of the discovery process, not current specifications.
5. **Write migrations** using the canonical documents as your guide. All schema-level decisions are resolved.

## Technology Baseline

| Component | Version |
|-----------|---------|
| PHP | 8.5+ |
| Laravel | ^13.0 |
| PostgreSQL | 16+ |
| Redis | 7+ |
| Filament | v5 |
| Livewire | v4 |

## Canonical Counts

| Concept | Count |
|---------|-------|
| Domain Entities | 11 (5 AR + 3 child + 3 supporting) |
| Infrastructure Entities | 2 (ExternalIdentifier, FieldProvenance) |
| Value Objects | 28 (12 non-enum + 16 enums) |
| Enums | 16 |
| Domain Events | 29 |
| Actions | 20 |
| RBAC Roles | 11 |
| Database Tables | 58 |
| Category A Provenance Fields | 5 |
| Category B Provenance Fields | 6 |
| Total Provenance-Whitelisted Fields | 11 |
