# StudyNexus — Architecture

> **Canonical source.** This document consolidates the StudyNexus architecture from the frozen domain baseline, platform reviews, build-vs-buy analysis, final audit, and RBAC decision record. All version numbers, role names, and package references are corrected to canonical form.

---

## 1. Architectural Principles

The architecture of StudyNexus is governed by principles derived from Laravel Beyond CRUD, the domain discovery process, and the project's global-first ambitions. These principles are decision criteria — when two approaches conflict, the higher-priority principle wins.

**P1: Domain Accuracy Over Theoretical Purity.** The code structure must reflect the StudyNexus domain as discovered through domain analysis. This means aggregate boundaries, domain operations, and invariants must be expressible and enforceable in code. It does NOT mean every domain concept needs a dedicated class, interface, or abstraction. The question is always: "Does this code structure make it easy to see and protect the business rules?" — not "Does this code structure conform to a DDD textbook?"

**P2: Pragmatic Laravel Idioms.** When Laravel provides a convention that adequately serves the domain, use it. Do not introduce repositories, services, or abstractions merely because they are "proper DDD." Introduce them when they express genuine domain concepts or protect meaningful business rules. Eloquent models are the default persistence mechanism. Actions are the default command mechanism. Events are the default integration mechanism.

**P3: Invariant Protection at Aggregate Boundaries.** The five aggregate roots exist because they protect real business invariants (22 invariants discovered in Behaviour Discovery). The architecture must make it difficult to violate these invariants. Aggregate roots are the entry points for state changes. Child entities are not independently modifiable. Cross-aggregate references use identity, not object references.

**P4: Separate Domain from Application from Presentation.** Domain objects (entities, value objects, domain events, invariants) contain business rules that would exist regardless of Laravel. Application objects (actions, queries, DTOs, event listeners) orchestrate use cases. Presentation objects (Livewire components, Blade templates, Filament resources) render and capture interaction. The dependency direction is Presentation to Application to Domain. Never the reverse.

**P5: Global-First, Nigeria-First-Dataset.** Nigeria is the first dataset, not the architectural boundary. Nigerian concepts (JAMB, WAEC, NUC, UTME) are instances of universal concepts (Education Authority, Qualification, Admission Pathway). The architecture must not hardcode Nigerian assumptions into entity names, aggregate rules, value objects, enums, services, or workflows. At the same time, do not over-generalize merely because global expansion is planned. Generalize where genuinely universal; configure where the variation is data; defer where future variation is speculative.

**P6: TALL Stack — No SPA.** StudyNexus uses Laravel + Blade + Livewire v4 + Flux Pro + Tailwind CSS for all user-facing interfaces. Laravel Fortify provides backend authentication; Livewire + Flux Pro renders auth UI. Filament v5 is the admin panel (Internal Admin only). There is no React, Next.js, Vue, or separate frontend application. Server-rendered HTML with Livewire interactivity is the architecture. This is not a limitation — it is a deliberate choice for SEO, simplicity, and team velocity.

**P7: Proven Packages Before Reinvention.** Spatie packages are evaluated for every requirement they cover. However, a package must never dictate the domain model. Model the domain correctly first; then determine whether a package provides appropriate infrastructure. Rejection of a package is as important as adoption — every rejection is documented with rationale.

**P8: Evolvable Without Rewrite.** The architecture must support expansion from Nigeria to Africa to global education without requiring a rewrite. Bounded contexts can be extracted later; new aggregate roots can be added; supporting entities can be promoted when invariant justification emerges; read models can evolve independently. The architecture must not be a distributed system today, but must not preclude one tomorrow.

**Supplementary Principles (from final audit):** P9 (PostgreSQL Is Source of Truth — PostgreSQL FTS is the initial search engine for MVP; Typesense is a deferred projection per ADR-6, triggered only when FTS latency exceeds 200ms at 10k programmes; Redis is a cache), P10 (Honest Scope — build what users need now, defer what they might need later), P11 (No Premature Abstraction — do not abstract until three concrete instances with verified shared behaviour exist), P12 (Eloquent Is the Repository — no repository abstraction, no persistence interface). When principles conflict, domain primacy (P1) wins over extensibility, and honest scope (P10) wins over future-proofing.

---

## 2. Technology Stack

### Runtime and Framework

| Component | Version | Purpose |
|---|---|---|
| PHP | 8.5 | Runtime language |
| Laravel | ^13.0 | Application framework |
| PostgreSQL | 16+ | Primary data store (authoritative) |
| Redis | 7+ | Cache, session, queue backend |

### Frontend: TALL Stack

| Component | Version | Purpose |
|---|---|---|
| Tailwind CSS | ^4.0 | Utility-first styling |
| Alpine.js | ^3.0 | Lightweight client-side interactivity (service workers, UI toggles) |
| Livewire | ^4.0 | Server-driven reactive UI components |
| Laravel | ^13.0 | Backend framework, Blade templating, routing |
| Flux Pro | Latest | Official Livewire UI component library (modals, tables, forms) |
| Blade | Built-in | Server-rendered HTML templates |
| Laravel Fortify | ^13.0 | Backend authentication service (login, 2FA, password reset, email verification) |

### Admin Panel

| Component | Version | Purpose |
|---|---|---|
| Filament | v5 | Admin panel for domain and content management |
| bezhansalleh/filament-shield | v3 | Filament + Spatie Permission integration; auto-generates policies and permission-seeded resources |
| pxlrbt/filament-activity-log | v3.1.1 | Activity log integration for Filament admin |

### Search

| Component | Purpose |
|---|---|
| Typesense | Search engine (in-memory, typo-tolerant, faceted) — **deferred per ADR-6, post-MVP** |
| Laravel Scout | Search abstraction (built-in); `database` driver for MVP, Typesense driver post-MVP |
| typesense/typesense-php | Typesense PHP client (v4+) — **post-MVP only** |
| devloop1024/laravel-typesense | Scout driver for Typesense — **post-MVP only** |

### Canonical Stack Summary

```
PHP 8.5 + Laravel ^13.0 + PostgreSQL 16+ + Redis 7+
TALL: Tailwind CSS ^4.0 + Alpine.js ^3.0 + Livewire ^4.0 + Flux Pro + Laravel ^13.0
Auth: Laravel Fortify (backend) + Livewire + Flux Pro (UI)
Admin: Filament v5 + filament-shield + filament-activity-log
Search: PostgreSQL FTS (MVP) → Typesense (post-MVP per ADR-6)
Philosophy: Laravel Beyond CRUD (Pragmatic DDD)
```

**Explicitly excluded:** React, Next.js, Vue, Inertia, SPA patterns, event sourcing, CQRS framework, repository abstraction, Filament on public site, Filament on user portals, Livewire in admin panel, direct self-publishing by institution reps.

---

## 3. Application Architecture

### Laravel Beyond CRUD Folder Structure

StudyNexus follows the Laravel Beyond CRUD pattern (Brent Roose and Freek Van der Herten) — pragmatic Domain-Driven Design organized within a single Laravel application. The folder structure reflects the layering principle (Presentation to Application to Domain, never reverse) and the namespace dependency rules that enforce it.

### Domain Layer

The domain layer contains the frozen domain model: 5 aggregate roots, 4 child entities, 4 supporting entities, 28 value objects (12 immutable PHP objects + 17 PHP Backed Enums), 29 domain events, 20 Application Actions, and 1 domain service. It has zero knowledge of authorization, engagement, notifications, search, SEO, or content. Additionally, two reference/query models (Discipline, CutOffMark) exist in the domain namespace but are not domain entities — they have no lifecycle, invariants, or domain operations. Two infrastructure entities (ExternalIdentifier, FieldProvenance) exist in the infrastructure layer for data lineage and provenance tracking. InformationSource is an independent aggregate root (ND-5/ADR-22) — no institution_id FK; nullable authority_id FK → education_authorities. ProgrammeInstance is a child entity of Programme representing concrete offerings per campus/mode/year. Campus is a supporting entity of Institution enabling multi-campus support.

```
app/Domain/
    Models/           — Eloquent models as aggregate roots + child/supporting entities
        Institution.php, Programme.php, Scholarship.php,
        AdmissionCycle.php, InformationSource.php,
        AdmissionPolicy.php, EligibilityPolicy.php, AccreditationRecord.php,
        ProgrammeInstance.php,
        Qualification.php, ScholarshipProvider.php, EducationAuthority.php,
        Campus.php,
        OrganizationMember.php (application pivot, in Domain\Models for namespace consistency),
        Discipline.php (reference data, not domain entity),
        CutOffMark.php (query model, not domain entity)
    ValueObjects/     — 12 immutable PHP objects (AdmissionRule, EligibilityRule, SubjectCombination,
                        QualificationThreshold, ValidityPeriod, MonetaryAmount, Duration, Location,
                        AuthorityJurisdiction, PhaseSequence, TrustSignal [computed], AdmissionPathway [demoted])
    Enums/            — 17 PHP Backed Enums (InstitutionType, AwardLevel, AdmissionMode,
                        AccreditationStatus, PolicyStatus, ProgrammeStatus, ScholarshipStatus,
                        InstitutionStatus, SourceReliability, InformationCategory, AuthorityType,
                        ProviderType, OwnershipType, DeliveryMode, QualificationStatus, CoverageType,
                        CampusStatus)
    Events/           — 29 domain events (plain PHP classes, no shared interface)
    Actions/          — 20 Application Actions (one class per use case)
    Queries/          — Domain read-model queries
    Services/         — InstitutionMerger (the only domain service)
    Exceptions/       — Domain exception classes
app/Infrastructure/
    Models/
        ExternalIdentifier.php  — Generic external identifiers (BD-5/ADR-21)
        FieldProvenance.php     — Field-level provenance (ND-4/ADR-23)
```

### Action Classes

Actions are single-purpose classes representing one application use case. An Action is worth having when the operation involves multi-step orchestration, multi-entry-point reuse, significant cascade, or authorization plus complex validation. Search index updates handled by event listeners do NOT justify an Action. Authorization alone does NOT justify an Action (Laravel Policies handle that at the controller level).

The 20 canonical Actions are: CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, PublishAdmissionPolicy, RecordAccreditation, CreateProgramme, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships (batch). Simple operations (rename, suspendAdmission, resumeAdmission, closeApplications, withdraw, archive, deprecate) call domain methods directly from controllers or Livewire components, with event listeners handling side effects.

### Domain Events and Listeners

Domain events are plain PHP classes with constructor-injected payload. There is no shared DomainEvent interface, no shared trait, and no event store. Events are dispatched from aggregate root methods via Laravel's native event system and consumed by application-layer listeners:

```
Aggregate Root → Domain Event → Listeners:
    ├── UpdateSearchIndex  (Scout abstraction — PostgreSQL FTS for MVP, Typesense post-MVP)
    ├── DispatchNotifications  (Laravel Notification facade)
    ├── RecalculateTrustSignal  (read model update)
    ├── LogActivity  (Spatie activitylog)
    └── UpdateReadModel  (cross-aggregate read projections)
```

### Read Models and Query Classes

Seven domain read-model queries (isAdmitting, isApplicableTo, isReliable, isAdmissionOpen, getTrustSignal, getAccreditationStatus, getCurrentActivePolicy) derive answers from multiple aggregates' current state. They are eventually consistent and optimized for read performance. Each lives in `App\Queries\` as a dedicated class, keeping query logic out of domain models.

### Content Layer

Four content models with shared traits form the content/information layer that surrounds the frozen domain. The dependency is unidirectional: Content references Domain; Domain never references Content.

```
app/Content/
    Models/          — Article, Guide, GuideSection, EducationalResource, ExamPreparation
    Concerns/        — HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections
    Actions/         — Create/Publish actions for each content model
    Queries/         — Get-by-slug, get-by-category, get-by-type queries
    Enums/           — ContentStatus, ResourceType, PrepType
```

### Additional Modules

- **Community** (`App\Community\`): Stack Overflow + Reddit hybrid Q&A module. Feature-flagged. Separate evolution from frozen domain.
- **StudyAbroad** (`App\StudyAbroad\`): Read-only composition module. No Actions, no Models, no Events. Uses existing Institution/Programme models + reference data.
- **Reference** (`App\Reference\Models\`): Simple Eloquent models for reference data (Country, Currency, QualificationEquivalency, TuitionFeeRange, CostOfLivingIndex, VisaRequirementSummary). No domain invariants.

### Namespace Dependency Rules

| Namespace | May Import From | May NOT Import From |
|---|---|---|
| Domain | Domain only | Content, Community, StudyAbroad, Product, Search, SEO |
| Content | Content, Domain, Reference | Community, StudyAbroad, Product, Search, SEO |
| Community | Community, Domain | Content, StudyAbroad, Product, Search, SEO |
| Product | Product, Domain, Content, Reference | Community, Search, SEO |
| Search | Search, Domain, Content | Community, Product, SEO |
| SEO | SEO, Domain, Content | Community, Product, Search |
| Admin | All | — (admin can see everything) |

---

## 4. RBAC Architecture

### The 11-Role Model

StudyNexus uses 11 roles across three scopes. This model is canonical per the RBAC decision record and supersedes all prior role references.

**Platform Roles (4) — Global via Spatie Permission:**

| Role | Scope | Key Permissions |
|---|---|---|
| `platform-admin` | Platform (global) | All permissions. Full system access. |
| `platform-moderator` | Platform (global) | Verify sources, moderate content, review community posts, handle reports. |
| `content-admin` | Platform (global) | CRUD all domain entities and content types. Publish/unpublish. |
| `content-editor` | Platform (global) | Create/edit/publish content. Cannot delete or manage domain entities. |

**Institution-Scoped Roles (5) — Via OrganizationMember pivot:**

| Role | Scope | Key Permissions |
|---|---|---|
| `institution-owner` | Institution-scoped | Full control of institution + manage members + transfer ownership. |
| `institution-admin` | Institution-scoped | Manage institution data, programmes, admissions, scholarships. Cannot transfer ownership. |
| `institution-admissions` | Institution-scoped | Manage admission policies, cycles, deadlines. Read-only on other areas. |
| `institution-editor` | Institution-scoped | Edit descriptions, media, programme details. No status changes or admissions. |
| `institution-viewer` | Institution-scoped | View internal data and reports. No write access. |

**User-Level Roles (2) — Global via Spatie Permission:**

| Role | Scope | Key Permissions |
|---|---|---|
| `registered-user` | User-level | Save, follow, like, compare, community participation (post, answer, vote). |
| `guest` | User-level | Browse only. No write access. |

### Mechanism

| Layer | Mechanism | Storage | Package |
|---|---|---|---|
| Global platform roles | Spatie Permission | `model_has_roles`, `model_has_permissions` | `spatie/laravel-permission` |
| Institution-scoped roles | OrganizationMember pivot | `organization_members.role` (**string** column) | Custom |
| Admin panel resource auth | Filament Shield | Auto-generated policies | `bezhansalleh/filament-shield` |
| API token auth | Laravel Sanctum | `personal_access_tokens` | `laravel/sanctum` |
| Object-level checks | Laravel Policies | Policy classes | First-party |

### OrganizationMember Pivot Model

The OrganizationMember pivot is the custom layer that enables scoped authorization. The same user can be owner of Institution A and viewer of Institution B. Roles are scoped to the organization.

```php
class OrganizationMember extends Pivot
{
    // organization_members table columns:
    // - organization_type (morph: 'institution', 'scholarship_provider', 'education_authority' via Relation::morphMap)
    // - organization_id
    // - user_id
    // - role (string: 'owner', 'admin', 'admissions', 'editor', 'viewer')
    // - created_at, updated_at
}
```

**Critical:** `organization_members.role` is a **string** column, NOT a foreign key to the Spatie `roles` table. Organization-scoped roles are a separate concept from global Spatie roles. New roles can be added as data without code changes, because roles are strings, not enums.

### Policy Check Pattern

```php
// Example: Can user edit this institution's programmes?
public function updateProgramme(User $user, Institution $institution): bool
{
    return $user->hasRole('platform-admin')
        || $user->hasRole('content-admin')
        || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
}
```

Platform-level checks use Spatie Permission's `hasRole()` and `can()`. Organization-scoped checks use the custom `isOrganizationMember()` method on the User model, which queries the OrganizationMember pivot. Filament Shield generates policy scaffolding for admin resources, consuming the same Policy classes that protect Livewire and Blade.

### What Is NOT Built

- No ABAC (Attribute-Based Access Control) — over-engineered for scoped entity roles.
- No permission inheritance tree — permissions are flat within a role.
- No full multi-tenancy package (e.g., `stancl/tenancy`) — StudyNexus is single-tenant with organization-scoped authorization.
- No `role_id` FK on OrganizationMember — org-scoped role is a string concept, not a FK to Spatie roles.
- No `super-admin` role name — canonical name is `platform-admin`.

---

## 5. Search Architecture

### Core Principle

**PostgreSQL is the authoritative system of record.** Per ADR-6, PostgreSQL FTS is the initial search engine for MVP. Typesense is a deferred search/discovery projection, to be introduced only when PostgreSQL FTS latency exceeds 200ms at 10k programmes or faceted search response exceeds 100ms. Typesense never holds data that cannot be reconstructed from PostgreSQL. If Typesense goes down (post-MVP), the application still functions with degraded search (fallback to PostgreSQL FTS). If PostgreSQL goes down, the application is down.

### Three Data Representations

| Representation | Technology | Purpose | Update Mechanism |
|---|---|---|---|
| Authoritative domain | PostgreSQL + Eloquent | Source of truth; invariants; transactions | Domain operations on aggregate roots |
| Search projection (MVP) | PostgreSQL FTS + GIN indexes | Full-text search, faceted filtering, ranking | Generated tsvector columns always consistent with row data |
| Search projection (post-MVP) | Typesense | Full-text search, faceting, autocomplete, typo tolerance | Domain events to `UpdateSearchIndex` listener to queued Scout job |
| SEO/public representation | Blade + Livewire | Crawlable HTML, meta tags, structured data, canonical URLs | Server-rendered from Eloquent (detail pages) or search engine (listing pages) |

These must not be collapsed. The search document is denormalized for search performance. The Eloquent model is normalized for domain integrity. The Blade template is optimized for SEO and user experience.

### Search Document Design (Post-MVP: Typesense Denormalization)

> **MVP note:** During the PostgreSQL FTS phase, search is served directly from PostgreSQL using tsvector columns and GIN indexes. The denormalization strategy below applies to the post-MVP Typesense migration per ADR-6.

Each Typesense document includes: direct attributes from the aggregate (name, status, type), parent attributes for filtering (institution_name and institution_type on programme documents), computed attributes for faceting (is_admitting, programme_count, disciplines array), and sort attributes (sort_name for alphabetical, sort_relevance for ranking). Denormalization trades write complexity (updating parent data on child documents when parent changes) for read performance (single document per result). When an institution's name changes, the `InstitutionRenamed` event triggers updates to the institution document AND all related programme documents in a single queued job.

### Detail Page vs Search/List Data Source

| Page Type | Data Source | Reason |
|-----------|------------|--------|
| Search results / faceted lists | **PostgreSQL FTS (MVP)** → **Typesense (post-MVP)** | MVP: PostgreSQL FTS with GIN indexes + application-level faceting. Post-MVP: Typesense faceting, ranking, typo tolerance, autocomplete |
| Programme detail | **PostgreSQL/Eloquent** | Full entity graph: programme + programme instances + institution + admission policies + accreditation records + cut-off marks + related scholarships. |
| Institution detail | **PostgreSQL/Eloquent** | Full entity graph: institution + campuses + programmes (eager-loaded) + accreditation records + admission cycles. Programme list within institution is Eloquent (scoped to one institution). |

**This distinction is locked for MVP.** Per ADR-6, PostgreSQL FTS is the sole MVP search engine for all list/search/browse surfaces. PostgreSQL/Eloquent is the serving layer for all detail pages. The programme list within an institution detail page is served from Eloquent — scoped to a single institution with eager loading. No dual-read complexity. No external search engine for detail pages. PostgreSQL is authoritative and always serves the current canonical state. Typesense is deferred until PostgreSQL FTS latency exceeds 200ms at 10k programmes or faceted search response exceeds 100ms (ADR-6 trigger).

**Search projection fields** (tuition_min, tuition_max, is_admission_open, discipline, discipline_slug, is_published) are computed search attributes. In MVP (PostgreSQL FTS), these are stored as materialized columns on the respective tables. In post-MVP (Typesense), they are computed by `toSearchableArray()` and stored only in Typesense documents. They are not domain properties.

### Typesense Collections (Post-MVP Design per ADR-6)

> **Note:** Typesense is deferred per ADR-6. The following collection design is the post-MVP target, to be implemented when PostgreSQL FTS latency exceeds 200ms at 10k programmes or faceted search response exceeds 100ms.

Seven collections, one per searchable model: institutions, programmes, scholarships, articles, guides, educational_resources, exam_preparations. Each is configured with Typesense-specific schema (field types, facet fields, sort fields, typo-tolerance settings).

### Synchronization Strategy

| Event | Action | Mechanism |
|---|---|---|
| Domain event modifying searchable data | Upsert affected document | `UpdateSearchIndex` listener, queued Scout job |
| Relationship change (e.g., programme added to institution) | Re-index both institution and programme documents | Listener with related-entity awareness |
| Bulk import | Queue bulk indexing job | `ImportInstitutionData` action |
| Full re-index | `scout:import` Artisan command | Scheduled or manual; zero-downtime via Typesense alias swapping |
| Deletion | Delete from Typesense | Scout `unsearchable()` |

Search documents are eventually consistent. After a domain operation commits, the listener queues a Scout job. A search document may be stale for up to 5 seconds after a domain change — acceptable for a discovery platform. Schema changes use zero-downtime collection alias swapping.

### Faceted Search for Discovery

Typesense provides faceted search across institution type, country, programme level, scholarship amount, discipline, delivery mode, and ownership type. Facet counts are returned with every search response, enabling instant filter feedback in listing pages. The Livewire component binds filter state to URL query string parameters via the `#[Url]` attribute, producing SEO-friendly URLs for every filter state.

### PostgreSQL FTS Implementation (MVP per ADR-6)

PostgreSQL full-text search is the MVP search engine. Implementation details:

- **tsvector columns:** `search_vector` GENERATED ALWAYS STORED column on `programmes`, `institutions`, and `scholarships` tables. Always consistent with row data — no trigger or Eloquent event synchronization required. GIN indexes on search_vector for sub-millisecond FTS.
- **GIN indexes:** `CREATE INDEX idx_programmes_search ON programmes USING GIN (search_vector)` (and equivalent for institutions, scholarships) for sub-millisecond full-text search
- **Faceted search:** Application-level filtering via `spatie/laravel-query-builder` with WHERE clauses for facet fields (award_level, discipline, institution_type, country, delivery_mode, campus, ownership_type, coverage_type). Facet counts computed via aggregate queries (COUNT + GROUP BY) cached per request
- **Search query construction:** `to_tsvector('english', name || ' ' || description)` for search vectors; `plainto_tsquery('english', ?)` for user queries; `ts_rank_cd` for relevance ranking
- **Scout abstraction layer:** Laravel Scout configured with the `database` driver for MVP. `toSearchableArray()` maps model attributes uniformly. When Typesense is introduced post-MVP, only the Scout driver configuration changes — no domain or application code changes required
- **Autocomplete:** PostgreSQL trigram indexes (`pg_trgm` extension) on name columns for prefix/fuzzy matching, sufficient for MVP scale
- **Performance monitoring:** ADR-6 trigger metrics (FTS latency at 10k programmes, faceted search response time) tracked via `laravel/pulse` to determine when Typesense migration is warranted

---

## 5.5 Publication/Visibility Model

Publication visibility is an application/product concern that is orthogonal to domain lifecycle. It applies to three domain entities: Institution, Programme, and Scholarship.

**Model:** `is_published` boolean (default false) + `published_at` nullable timestamp.

**Search visibility rule for public queries:**

```php
$isSearchVisible = $entity->is_published
    && !in_array($entity->status, [
        InstitutionStatus::Closed,
        ProgrammeStatus::Discontinued,
        ScholarshipStatus::Withdrawn,
        ScholarshipStatus::Expired,
    ]);
```

An entity must be both published (`is_published = true`) AND in a lifecycle state that allows **search index** inclusion. A Closed institution is excluded from search results even if `is_published = true`. A Discontinued programme is excluded from search results even if `is_published = true`.

**URL accessibility rule (distinct from search visibility):**

Discontinued programmes and Closed institutions remain **accessible via their canonical URL** even though they are excluded from search results. This is a critical distinction:

- **Search-visible** → appears in Typesense index, on-site search, faceted browse, and sitemap
- **URL-accessible** → detail page renders at canonical URL with appropriate notice badge

```php
// Search visibility: excluded from index
$isSearchVisible = $entity->is_published && !in_array($entity->status, [/*terminal states*/]);

// URL accessibility: page renders if published (even for terminal states)
$isUrlAccessible = $entity->is_published;
```

**SEO/trust rationale:** Returning a 404 for previously-indexed Discontinued programme pages damages site authority. Rendering the page with a "Discontinued" notice preserves the URL, maintains SEO authority, and is more honest than making the programme disappear. Users who bookmarked or shared the link still receive value. See PRODUCT-EXPERIENCE-ARCHITECTURE.md §11.3 and §15.3 for the product experience specification.

**Republishing semantics:** `published_at` represents the **first publication date** and is set once (when `is_published` transitions from `false` with `published_at = NULL` to `true`). It is never changed on subsequent publication cycles. If an entity is unpublished and later republished, `published_at` retains its original value.

| Transition | `is_published` | `published_at` | Activity Log |
|------------|:-------------:|:--------------:|-------------|
| Entity created | `false` | `NULL` | — |
| First publish | `true` | `NOW()` | "Published by [user]" |
| Unpublish | `false` | unchanged | "Unpublished by [user]" |
| Republish | `true` | unchanged | "Republished by [user]" |

**Publication history** is provided by `spatie/laravel-activitylog`. Every `is_published` change is logged with who, when, old value, and new value. No separate publication-history subsystem. No `publication_status` enum. No publication state machine. If a richer publication history UI is needed in future, the activity log already contains the data.

**Search indexing:** Only published entities (where `is_published = true` AND lifecycle allows) are indexed in the public-facing search (PostgreSQL FTS in MVP; Typesense collection post-MVP). Admin search includes all entities regardless of publication status.

**Content models** (Article, Guide, EducationalResource, ExamPreparation) use the existing `IsPublishable` trait with `published_at` column. Domain entities use `is_published` + `published_at` directly on the table — the `IsPublishable` content trait is not applied to domain models because domain publication semantics differ from content publication semantics (domain publication is gated by lifecycle status; content publication is not).

---

## 6. SEO Architecture

### Server-Rendered Principle

Every public page must produce meaningful crawlable HTML on initial load. This is non-negotiable for a discovery platform that depends on organic search traffic. Search is queried server-side via Scout (PostgreSQL FTS for MVP, Typesense post-MVP); Blade renders full HTML with results, filters, facet counts, SEO meta tags, canonical URLs, and structured data. Livewire provides interactive filter updates without full page reloads.

### Three Page Types

| Page Type | Rendering | SEO Strategy |
|---|---|---|
| Detail pages (e.g., `/institutions/university-of-lagos`) | Blade server-rendered | Full SEO: canonical URL, Schema.org JSON-LD, Open Graph, meta description, breadcrumbs |
| Listing pages (e.g., `/programmes`) | Blade + Livewire + Scout (PostgreSQL FTS MVP / Typesense post-MVP) | SEO-friendly filters via Livewire query string binding; canonical URL management; ItemList structured data |
| SEO landing pages (e.g., `/programmes/computer-science`) | Blade server-rendered | Curated SEO content + search engine results; intentionally created for high-value targets; NOT auto-generated from every filter combination |

### URL Strategy

| Entity | URL Pattern | Example |
|---|---|---|
| Institution | `/institutions/{institution-slug}` | `/institutions/university-of-lagos` |
| Programme | `/institutions/{inst-slug}/programmes/{prog-slug}` | `/institutions/university-of-lagas/programmes/computer-science-bsc` |
| Scholarship | `/scholarships/{scholarship-slug}` | `/scholarships/ptdf-scholarship` |
| Article (news) | `/news/{article-slug}` | `/news/unilag-increases-post-utme-cutoff` |
| Guide | `/guides/{guide-slug}` | `/guides/how-to-choose-the-right-programme` |
| Educational Resource | `/resources/{resource-slug}` | `/resources/computer-science-project-topics` |
| Exam Preparation | `/exam-prep/{exam-prep-slug}` | `/exam-prep/jamb-mathematics-past-questions-2024` |
| Study Abroad | `/study-abroad/{country-slug}` | `/study-abroad/canada` |

Programme URLs are institution-scoped because a Programme is not globally unique — the same programme name exists at multiple institutions. The programme slug is unique within an institution: composite unique index on `(institution_id, slug)`.

### Controlled Indexation (Faceted URL Strategy)

Faceted search creates an exponential number of URL combinations. The strategy limits indexable URLs:

- **Indexable:** `/programmes`, `/programmes?discipline={slug}`, `/programmes?discipline={slug}&country={code}`, `/institutions?country={code}`, `/institutions?country={code}&type={type}`.
- **Not indexable (noindex, follow):** Any URL with more than 3 filter parameters, or combinations not in the curated list.
- **Canonical URLs:** Every listing page has a canonical URL pointing to the most generic version.
- **Sitemap:** Includes detail pages, curated SEO landing pages, and main listing pages. Does NOT include parameterized filter URLs.

### Sitemap Generation

Sitemaps are partitioned to stay under the 50,000 URL limit per sitemap file: sitemap-institutions.xml (weekly), sitemap-programmes.xml (weekly), sitemap-scholarships.xml (daily), sitemap-articles.xml (daily), sitemap-guides.xml (monthly), sitemap-resources.xml (monthly), sitemap-exam-prep.xml (monthly). Generated by `spatie/laravel-sitemap`.

### Structured Data (JSON-LD)

| Model | Schema.org Type | Key Properties |
|---|---|---|
| Institution | `CollegeOrUniversity` | name, address, telephone, url, sameAs |
| Programme | `EducationalOccupationalProgram` | name, provider, educationalProgramMode, timeToComplete, offers (ProgrammeInstance) |
| Scholarship | `DatedMoneySpecification` | amount, currency, validFrom, validThrough |
| Article | `NewsArticle` | headline, datePublished, dateModified, author, image |
| Guide | `Article` | headline, articleSection, dateModified |
| EducationalResource | `LearningResource` | name, educationalLevel, learningResourceType |
| ExamPreparation | `LearningResource` | name, educationalLevel, assesses |

### Canonical URL Management

Every publishable entity has a canonical URL. If a slug changes, the old URL returns a 301 redirect via a `url_redirects` table. Open Graph metadata ensures rich previews when StudyNexus URLs are shared on any platform.

### Search/SEO Separation (ADR-30)

Scout (PostgreSQL FTS for MVP, Typesense post-MVP) is the search engine for user discovery. Blade is the rendering engine for SEO. Neither dictates the other's URL structure, rendering strategy, or data model. Search results link to Blade-rendered pages. SEO changes do not affect search relevance. Post-MVP, Typesense outages fall back to PostgreSQL FTS. PostgreSQL FTS outages do not affect SEO (server-rendered Blade still renders).

---

## 7. Content Architecture

### Content Model Resolution: Separate Models + Shared Traits

Four content models serve the StudyNexus content layer. Each model with genuinely distinct behaviour gets its own table, Actions, Queries, and Blade views. Shared behaviour comes from traits, not inheritance.

| Model | Table | Contents | Distinct Behaviour |
|---|---|---|---|
| `Article` | `articles` | News, announcements, institution updates | Time-sensitive publishing, news source attribution, Google News sitemap, breaking flag, chronological feed |
| `Guide` | `guides` | How-to guides, career guides, education guides, study-abroad guides | Structured sections with TOC, reading time calculation, section navigation, evergreen content lifecycle |
| `EducationalResource` | `educational_resources` | Project topics, seminar topics, research materials, study resources | Standard publishing + `resource_type` enum (ProjectTopic, SeminarTopic, ResearchMaterial, StudyResource, Other) + discipline + academic level + download tracking |
| `ExamPreparation` | `exam_preparations` | Past questions, exam tips, subject reviews, study packs | Standard publishing + `prep_type` enum (PastQuestion, ExamTip, SubjectReview, StudyPack) + exam body + year + subject + download tracking |

### Shared Traits

| Trait | Responsibility | Used By |
|---|---|---|
| `HasSlug` | Auto-generate URL slug from title on creation | All four models |
| `IsPublishable` | Draft/published/archived status, published_at, publish()/unpublish() | All four models |
| `HasSeoMeta` | SEO title, description, canonical URL, Open Graph, noindex/nofollow | All four models |
| `HasMedia` | Spatie Media Library integration for attachments/images | All four models |
| `HasProvenance` | Author attribution, source URL, institution association (optional) | All four models |
| `IsSearchable` | Scout integration for search projection (PostgreSQL FTS for MVP, Typesense post-MVP) | All four models |
| `HasTags` | Spatie Tags integration for taxonomy/categorisation | All four models |
| `HasSections` | Ordered content sections with titles and body | Guide only |

### Content to Domain Relationships

Content references domain entities; domain entities do NOT reference content. This unidirectional dependency is non-negotiable. An Article can belong to an Institution (optional FK: `institution_id`). An EducationalResource can belong to a Programme. But an Institution has no `articles()` relationship — the relationship is defined on the content side, queried via dedicated Query classes (e.g., `GetArticlesForInstitution`). For the general case (an article about any domain entity), polymorphic relationships (`domain_entity_type`, `domain_entity_id`) are used. For hot paths (Article to Institution), an explicit `institution_id` FK is also maintained for query performance.

### Media Handling

| Content Model | Media Collections | Conversions |
|---|---|---|
| Article | `hero-image`, `gallery`, `attachments` | hero: 1200x630, thumb: 400x210 |
| Guide | `hero-image`, `section-images` | hero: 1200x630, thumb: 400x210 |
| EducationalResource | `attachments`, `preview-image` | thumb: 400x210 |
| ExamPreparation | `attachments`, `solutions` | original only |

Domain models also use Spatie Media Library for institution logos, programme brochures, and accreditation document attachments.

### Institution Information Architecture

The institution detail page is the most complex page, serving as both a domain data page and a content hub. Sections include: hero banner (eager, cacheable 24h), accreditation summary (eager, cacheable until accreditation change event), programme listing (lazy via Livewire), active admission cycles (eager), available scholarships (lazy), latest news/articles (lazy, cacheable 5 min), related guides (lazy, cacheable 1h), and community Q&A (lazy). Tabbed navigation provides: Overview, Programmes, Admissions, Scholarships, News, Resources, Community.

---

## 8. Notification Architecture

### Decision: Laravel Native Notifications

StudyNexus uses Laravel's native notification system. No custom notification framework, no digest engine, no priority queue, no template editor. Laravel's notification system provides notifiable entities, multiple channels, queue support, notification events, and per-user preferences — all of which are sufficient.

### Notification Channels

| Channel | Driver | When Used |
|---|---|---|
| In-app (database) | Laravel database notifications | All notifications (baseline) |
| Email | Laravel Mail + queue | Important: admission deadlines, scholarship reminders |
| Web Push | `laravel-notification-channels/webpush` | Opt-in: new programme, admission opening, deadline alerts |
| SMS | Custom channel class (via Termii for Nigeria, Twilio for global) | Opt-in: critical deadline reminders only |

### Notification Flow

```
Aggregate Root → Domain Event → Event Listener:
    determines who should be notified → Laravel Notification facade:
        Notification Class → toDatabase() / toMail() / toWebPush() / toSms()
```

Notifications originate from domain events, not from aggregate roots. Aggregate roots dispatch events; listeners determine who to notify and dispatch Laravel notifications. This keeps notification logic out of the domain model. Notification classes live in `App\Notifications\` (application layer, not domain).

### Notification Types

| Notification | Trigger | Default Channels |
|---|---|---|
| AdmissionCycleOpened | `AdmissionCycleActivated` event | Database + Email + WebPush |
| ScholarshipDeadlineApproaching | Scheduled check (7 days / 1 day before) | Database + Email + SMS (if opted in) |
| NewArticlePublished | Followed institution publishes article | Database + WebPush |
| CommunityAnswerReceived | User's question gets answered | Database + Email |
| ProgrammeAdmissionStatusChanged | Programme admission status changes | Database + Email |
| InstitutionUpdated | Institution domain events | Database |
| AccreditationStatusChanged | Accreditation domain events | Database |

### Notification Preferences

Per-user, per-category, per-channel preferences stored in a `notification_preferences` table (user_id, category, email boolean, in_app boolean, web_push boolean, sms boolean, digest_frequency nullable). Users control their own notification preferences. Notification classes check preferences in the `via()` method to determine which channels to use for each notifiable.

### Anti-Over-Engineering Rules

No digest engine until daily notification volume exceeds 20 per user. No notification preferences UI beyond channel opt-in/out until users request it. No notification template editor — templates are Blade views, version-controlled. No priority queue — all notifications use the default queue with standard retry logic. Unsubscribe links in every email notification. One-click unsubscribe for WebPush.

---

## 9. User Engagement Architecture

### Classification

| Capability | Classification | Persisted? | Rationale |
|---|---|---|---|
| Save/Bookmark | Application + Product | Yes | User wants to return to a resource. Must survive across sessions. |
| Follow | Application | Yes | User wants notifications on changes. Must be queryable for notification dispatch. |
| Like | Product | Yes (minimal) | Lightweight engagement signal for personalization. |
| Compare | Product + Session | Ephemeral (anonymous), Persisted (authenticated) | Comparison sets are temporary during a session. Authenticated users may save them. |
| Share | Product | No (client-side) | Sharing is client-side. No server-side tracking. |
| Alert/Watchlist | Application | Yes | User defines conditions for notification triggers. |

### Implementation: Polymorphic Eloquent Relationships

Each engagement type with distinct semantics gets its own model and table. A generic `UserInteraction` entity is explicitly rejected — it would create a god table with heterogeneous columns, obscure distinct semantics, and make querying specific types slower.

- **SavedResource** (`saves` table): `user_id`, `saveable_type`, `saveable_id`, `collection_name`, timestamps. Polymorphic: user can save institutions, programmes, scholarships, articles, guides, resources.
- **FollowedResource** (`follows` table): `user_id`, `followable_type`, `followable_id`, timestamps. Polymorphic. Save and Follow are distinct: Save = "I want to return to this." Follow = "Tell me when something changes."
- **LikedResource** (`likes` table): `user_id`, `likeable_type`, `likeable_id`, timestamps. Lightweight. Likes are NOT used as domain signals — they do not affect trust, accreditation, or eligibility.
- **UserAlert** (`user_alerts` table): `user_id`, `alert_type`, `criteria` (JSON), `is_active`, `last_triggered_at`. Application-layer construct defining conditions that trigger notifications.

Engagement counts (save_count, follow_count, like_count) are stored as counter cache columns on target models, updated by event listeners, avoiding COUNT queries on every page load.

### Comparison Architecture

Comparison is a product/presentation capability, NOT a domain concept. There is no Comparison entity, no invariants, no domain operations, no domain events. Anonymous users store comparison sets in session; authenticated users may persist them in a `comparison_sets` table. The `CompareProgrammes` Livewire component fetches selected items via `CompareProgrammesQuery` and renders a side-by-side table. Comparable entities: Institution (4 max), Programme (4 max), Scholarship (4 max). Cross-type comparison is NOT supported initially. The `EducationalOpportunity` read model provides a future unified view if needed.

### Community Module

A separate module (`App\Community\`) implementing a Stack Overflow + Reddit hybrid. Entities: Question, Answer, Comment, Vote. Tagged with domain entities via polymorphic relationships. Feature-flagged off by default (Phase 2). No reputation system until 1000+ active users. No badge system until reputation is implemented. Custom implementation justified — no existing Laravel package provides the required hybrid model.

---

## 10. Admin Panel Architecture

### Filament v5 Panel Configuration

Filament v5 serves as the admin panel for domain entity management and content management. It is NOT used on the public-facing site. The public site uses the TALL stack exclusively. There is no Filament in the public site and no standalone Livewire in the admin panel (Filament has its own rendering).

### Admin vs Public Site Separation

The admin panel (Filament) and public site (TALL) share domain models, database, Actions, domain events, Query classes, and validation rules — but have completely separate routing, middleware, layout, and UI concerns. Per the Auth Stack & UI Boundary Mandates (§10), there are three strict surfaces:

| Aspect | Admin (Filament) | Public Site (TALL) | User Portals (TALL) |
|---|---|---|---|
| Routes | `routes/filament.php` (auto-generated) | `routes/web.php` (manual) | `routes/web.php` (manual, `auth` group) |
| Middleware | `web`, `auth`, `verified`, `filament` | `web`, `verified` (optional for guest browse) | `web`, `auth`, `verified` |
| Layout | Filament panel layout | Custom Blade layout with Tailwind | Custom Blade layout with Tailwind |
| UI Components | Filament resources, forms, tables, widgets | Livewire components, Blade templates, Flux Pro | Livewire components, Blade templates, Flux Pro |
| Auth | Required (Filament auth guard, platform staff only) | Optional (guest can browse) | Required (Laravel Fortify + Livewire + Flux Pro) |
| Access | super_admin, content_manager, data_analyst, support_agent | All users (including guests) | Students + Institution reps (never Filament) |

### Filament Resources

| Filament Resource | Domain Model | Actions Invoked |
|---|---|---|
| InstitutionResource | Institution | CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions |
| ProgrammeResource | Programme | CreateProgramme, PublishAdmissionPolicy, RecordAccreditation, DiscontinueProgramme |
| ProgrammeInstanceResource | ProgrammeInstance | (managed within ProgrammeResource; no independent Actions) |
| CampusResource | Campus | (supporting entity; Filament CRUD) |
| ScholarshipResource | Scholarship | AnnounceScholarship, OpenScholarshipApplications, TargetScholarshipProgrammes |
| AdmissionCycleResource | AdmissionCycle | AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase |
| InformationSourceResource | InformationSource | RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable |
| OrganizationMemberResource | OrganizationMember | AddOrganizationMember, RemoveOrganizationMember |
| ArticleResource | Article | CreateArticle, PublishArticle |
| GuideResource | Guide | CreateGuide, PublishGuide |
| EducationalResourceResource | EducationalResource | CreateEducationalResource, PublishEducationalResource |
| ExamPreparationResource | ExamPreparation | CreateExamPreparation, PublishExamPreparation |

Supporting entities (Qualification, ScholarshipProvider, EducationAuthority) use direct CRUD via Filament — no custom Actions needed. Infrastructure entities (ExternalIdentifier, FieldProvenance) are managed programmatically by the provenance and data-acquisition subsystems — no Filament resources needed.

### Resource Authorization

Every Filament Resource uses Laravel Policies. The same `InstitutionPolicy` that protects the public API and Livewire components protects Filament. Filament is NOT the authorization system — it is a consumer of the same application-wide Policy classes. Filament Shield (`bezhansalleh/filament-shield`) generates policy scaffolding and permission-seeded resources, saving approximately 500 lines of repetitive authorization boilerplate.

Business logic is never in Filament Resource hooks. Filament Resources invoke Actions, which orchestrate domain operations, authorization, and side effects. This preserves the layering principle: Filament (Presentation) delegates to Actions (Application) which delegate to Models (Domain).

### Auth Stack & UI Boundary Mandates

These mandates define the strict boundaries between the three UI surfaces of StudyNexus. Violating any boundary is an architectural error equivalent to bypassing authorization.

**Auth Stack:** Laravel Fortify is the backend authentication service (rate-limited login, password reset, email verification, two-factor authentication). All auth-facing UI routes (Login, Registration, 2FA, Password Reset, Email Verification) are rendered using Livewire + Flux Pro components — not Filament, not custom Blade forms. Fortify handles the backend logic; Livewire + Flux Pro handles the frontend interaction. This combination provides server-driven, SEO-compatible auth flows with zero JavaScript framework dependencies.

**Strict UI Boundary Mandate — Three Surfaces:**

| Surface | Auth Required | Technology | Purpose | Filament? |
|---|---|---|---|---|
| **Public Site** | No (guest browse) | Livewire v4 + Flux Pro + Blade + Tailwind | Homepage, Search, Programme/Institution/Scholarship detail pages. SEO-optimized, server-side rendered. | **NEVER** |
| **User Portals** | Yes | Livewire v4 + Flux Pro + Blade + Tailwind | Student Panel (saved programmes, preferences, comparison sets, alerts) and Organization Panel (institution rep dashboards, programme editing, data submission). | **NEVER** |
| **Internal Admin** | Yes (platform staff only) | Filament v5 + filament-shield | Global user management, data ingestion queues, review/approval workflows, system settings, content management. | **Exclusively** |

**Boundary enforcement:**
1. **Public Site routes** (`routes/web.php`) use `web` middleware only. No `auth` middleware on browse/search/detail routes. Guest users can access all discovery surfaces.
2. **User Portal routes** (`routes/web.php`, `auth` middleware group) use Livewire components + Flux Pro for all interactive UI. Filament resources are NOT accessible to institution reps or students. The Organization Panel and Student Panel are Livewire + Flux Pro applications, not Filament panels.
3. **Admin routes** (auto-generated by Filament) use `web`, `auth`, `verified`, `filament` middleware. Only platform staff with admin-assigned roles (super_admin, content_manager, data_analyst, support_agent) can access. Institution reps and students are NEVER granted Filament access.
4. **No shared layouts** between Filament admin and Livewire public/portals. Each surface has its own layout system, navigation, and component library. The only shared code is domain models, Actions, Query classes, and validation rules.

**Organization Portal Workflow — Pending Revision Gate:**

Institution representatives may edit their institution's programmes and data via the Organization Portal (Livewire + Flux Pro), but they **MUST NOT** be able to directly publish their edits to the live site. This is a hard trust boundary:

1. **Rep edits programme** → saves as **"Pending Revision"** state (not published). The programme record's `is_published` flag remains unchanged. The pending revision is stored as a draft (either in a `pending_revisions` table or via spatie/laravel-activitylog's `pending_revision` subject type).
2. **Pending revision appears** in a **Filament v5 Review Queue** accessible only to Internal Admin staff (content_manager, super_admin roles). The queue shows: institution name, programme name, revision timestamp, diff summary, rep who submitted.
3. **Admin reviews** the revision: Approve → pending revision is applied to the canonical record, `is_published` is updated, and the change goes live. Reject → revision is marked rejected with a reason, rep is notified.
4. **All actions tracked** by `spatie/laravel-activitylog`: revision submitted, revision approved, revision rejected. Activity log entries include the rep's user ID, the admin's user ID, timestamps, and the before/after state.

**Rationale for Pending Revision Gate:** StudyNexus is a trust-grounded education discovery platform. Institution reps have a financial incentive to present their programmes favorably (inflating cut-off marks, omitting admission requirements, misrepresenting accreditation status). Direct self-publishing would undermine the platform's trust model. The review gate ensures every data change from an institution rep is verified by platform staff before it affects the public site, while `spatie/laravel-activitylog` provides a complete audit trail for accountability and regulatory compliance.

---

## 11. Package Ecosystem

### Spatie Packages — Adopt Now

| Package | Version | Purpose |
|---|---|---|
| `spatie/laravel-permission` | ^6.0 | RBAC foundation: roles, permissions, assignment, caching |
| `spatie/laravel-backup` | ^9.0 | Automated database and file backups (production requirement) |
| `spatie/laravel-activitylog` | ^4.0 | Audit trail for admin actions and status changes |
| `spatie/laravel-medialibrary` | ^11.0 | File and media management (institution logos, programme brochures, content images) |
| `spatie/laravel-data` | ^4.0 | Type-safe DTOs, form objects, API resources, validation |
| `spatie/laravel-sluggable` | ^3.0 | SEO-friendly URL slug generation for all aggregate roots and content models |
| `spatie/laravel-query-builder` | ^3.0 | Structured API filtering, sorting, inclusion |
| `spatie/laravel-webhook-client` | ^3.0 | Incoming webhook ingestion for Information Source integrations |
| `spatie/laravel-personal-data-export` | ^1.0 | GDPR Article 20 + Nigerian NDPR data export compliance |

### Spatie Packages — Adopt When Needed

| Package | Purpose | Trigger |
|---|---|---|
| `spatie/laravel-tags` | User-generated tags for community content and programme taxonomy | Community Phase 2 |
| `spatie/laravel-sitemap` | XML sitemap generation for search engines | Public UI build |
| `spatie/schema-org` | Schema.org structured data for rich snippets | Public UI build |
| `spatie/laravel-markdown` | Markdown rendering for community posts | Community Phase 2 |
| `spatie/laravel-responsecache` | HTTP response caching for read-heavy listing pages | Traffic volume justifies |
| `spatie/laravel-settings` | Application-level settings (feature flags, thresholds) | Admin settings UI |
| `spatie/laravel-translation-loader` | Database-backed translations for Africa expansion (French, Portuguese, Arabic) | Multi-language content |
| `spatie/laravel-webhook-server` | Outbound webhooks for partner platform push | Partner integrations |
| `spatie/browsershot` | PDF/image generation for comparison exports | PDF export feature |

### Spatie Packages — Rejected

| Package | Rejection Rationale |
|---|---|
| `spatie/laravel-event-sourcing` | Over-engineering. Forces CQRS. Contradicts frozen baseline. |
| `spatie/laravel-model-states` | PHP enums + guard clauses in domain methods are simpler, more idiomatic for LBC. |
| `spatie/laravel-comments` | Commercial license. Community architecture is custom (SO+Reddit hybrid). |
| `spatie/laravel-newsletter` | Mailchimp-only. Use Laravel Notifications + queue for multi-provider. |
| `spatie/laravel-view-models` | Superseded by `laravel-data`. |
| `spatie/laravel-fractal` | Superseded by `laravel-data`. |
| `spatie/valuestore` | Superseded by `laravel-settings`. |
| `spatie/laravel-geocoder` | Premature. Location search handled by PostgreSQL FTS geo filter (MVP) / Typesense geo filter (post-MVP). |
| `spatie/laravel-menu` | Superseded by Blade components and Livewire navigation. |
| `spatie/laravel-feeds` | Near-zero relevance for an education discovery platform. |
| `spatie/laravel-ray` | Development-only debugging tool. Never a production dependency. |

### Filament Plugins

| Package | Purpose |
|---|---|
| `bezhansalleh/filament-shield` | Integrates Spatie Permission with Filament. Generates permission-seeded resources, policy scaffolding, and role-based widget visibility. |
| `pxlrbt/filament-activity-log` | Activity log resource for Filament admin, displaying Spatie activitylog entries in the admin panel. Version 3.1.1. |

### Other Adopted Packages

| Package | Purpose |
|---|---|
| `laravel/socialite` | Social login (Google for students, Microsoft for institution admins) |
| `laravel-notification-channels/webpush` | Web Push notification channel for browser push alerts |
| `maatwebsite/excel` | Bulk import of institutions, programmes, qualifications from CSV/Excel (validation, chunked processing, queued imports) |
| `laravel/pulse` | First-party performance monitoring (slow queries, slow endpoints, job failures) |
| `laravel/sanctum` | API token authentication for mobile app (built-in) |
| `typesense/typesense-php` | Typesense PHP client — **post-MVP only, per ADR-6** |
| `devloop1024/laravel-typesense` | Laravel Scout driver for Typesense — **post-MVP only, per ADR-6** |

### Custom Implementation (5 components)

| Component | Why Custom |
|---|---|
| OrganizationMember pivot | Scoped membership model (BookStack-inspired); no package provides org-scoped roles with polymorphic membership |
| Community module | No Laravel package provides SO+Reddit hybrid with voting and entity tagging |
| Search projection sync | PostgreSQL FTS tsvector/trigger pipeline for MVP; Typesense-specific indexing pipeline with denormalization strategy for post-MVP |
| Provenance subsystem | Hybrid provenance (entity-level JSONB + field_provenance) with 80/20 field model; no package provides field-level selective provenance with source attribution |
| SEO faceted URL strategy | Controlled indexation rules are domain-specific; no package provides facet-level indexation control |

### Concurrency

AdmissionCycle phase transitions use explicit pessimistic locking via `lockForUpdate()` inside a database transaction (BD-3/ADR-20). This prevents race conditions when concurrent requests attempt to advance the phase. Domain events are dispatched after the transaction successfully commits (not inside the transaction), ensuring that side effects (search index updates, notifications) only occur for durably committed state changes.

### Infrastructure Package Mandates

The following infrastructure concerns have mandated Laravel ecosystem packages. **Custom solutions for these areas are forbidden** — the mandated packages are battle-tested, actively maintained, and community-verified. Replacing them with custom code wastes implementation time and introduces untested edge cases.

| Concern | Mandated Package | Version | Scope | Rationale |
|---------|-----------------|---------|-------|-----------|
| Admin panel & CRUD | `filament/filament` | ^5.0 | All admin UI, resource CRUD, navigation, widgets, forms | Provides full admin panel with zero custom infrastructure. 11-role RBAC integration via filament-shield. Custom solutions are forbidden — Filament's plugin ecosystem covers all admin needs. |
| RBAC (11 roles) | `spatie/laravel-permission` | ^6.0 | 4 platform-global + 5 institution-scoped + 2 user-level roles | Canonical RBAC per ADR-19. Role column is string on OrganizationMember pivot (not FK). Custom RBAC solutions are forbidden. |
| Data provenance & audit trail | `spatie/laravel-activitylog` | ^4.0 | All model change tracking (old vs new values, who changed it, when), publication history, provenance audit | **Event Sourcing is explicitly rejected; audit trails and data provenance are handled via Spatie Activitylog.** This provides old/new value tracking on every model change without the overhead, complexity, and CQRS imposition of event sourcing. The rejected `spatie/laravel-event-sourcing` package (see Rejected table) forces CQRS and contradicts the frozen baseline (ADR-02). Activitylog gives the audit trail the business requires without the architectural ceremony event sourcing demands. Custom audit trail implementations are forbidden. |
| Value Objects & DTOs | `spatie/laravel-data` | ^4.0 | API resources, Value Object casting, form objects, Data Transfer Objects between import pipeline and domain Actions | Provides type-safe data structures with validation, casting, and transformation. Supersedes both `spatie/laravel-fractal` and `spatie/laravel-view-models` (see Rejected table). Custom DTO/VO wrapper classes in the Application layer are forbidden — use laravel-data. |
| Media & assets | `spatie/laravel-medialibrary` | ^11.0 | Institution logos, campus photos, programme brochures, content images, guide attachments | Handles file uploads, conversions, responsive images, and media associations via the `HasMedia` trait. Custom file upload/management solutions are forbidden. |

**Event Sourcing rejection — explicit rationale:** StudyNexus domain events (29 events, plain PHP classes dispatched via Laravel's event dispatcher per ADR-3/ADR-16) are integration events, not stored events. They trigger side effects (search index updates, notifications, activity logging) but are not the source of truth. The source of truth is PostgreSQL via Eloquent models. Event sourcing would introduce: (1) an event store (additional infrastructure), (2) CQRS (read models separate from write models — contradicts the Laravel Beyond CRUD philosophy), (3) projection rebuilds on schema changes (operational burden), and (4) debugging complexity (state is derived, not queryable). Activitylog provides the audit requirement without any of these costs. This decision is immutable per the frozen baseline.

**Stable phase IDs (ADR-20):** Phase IDs are application-generated string slugs (e.g., "registration", "examination", "result_release") defined at AdmissionCycle creation time, immutable after activation. They are NOT UUIDs, NOT auto-increment integers, NOT hashes. They are meaningful string identifiers chosen by the content team, ensuring phase references remain stable across deployments and data migrations.

### Provenance Architecture (ND-4/ADR-23)

StudyNexus uses a hybrid provenance model:

1. **Entity-level provenance JSONB** on every domain entity for lightweight whole-entity source metadata. Does NOT include import_batch_id (staging is ephemeral).

2. **field_provenance table** for selective field-level source attribution, conflict tracking, and value history. 80/20 model:
   - **Category A** (5 fields): Always provenance — every observation recorded (name, type, status, accreditation_status, cut_off_mark).
   - **Category B** (6 fields): Provenance on conflict — record when sources disagree (founded_year, location, website, admission_requirements, application_deadline, amount).
   - **Category C** (all others): No field_provenance tracking.

3. **ExternalIdentifier** (BD-5/ADR-21) for authority-assigned codes (JAMB codes, NUC codes, etc.) — no per-entity code columns on canonical entities.

No primary_source_id on entities. No is_active on field_provenance (derive from superseded_at IS NULL). No value_hash. No is_verified boolean (use verification_status enum). ON DELETE RESTRICT for source references in provenance records.

### Fabricated/Invalid Packages

`minimolabs/laravel-webpush` is INVALID and does not exist. The canonical web push package is `laravel-notification-channels/webpush`. No package reference in this architecture uses fabricated or non-existent packages.

---

## 12. Future-Proofing

### Multi-Country Expansion Path

Adding a new country (e.g., Ghana) requires: (1) add country to `CountrySeeder` (ISO 3166-1) — data only; (2) add country-specific EducationAuthority records — data only; (3) add country-specific Qualification records — data only; (4) add country-specific AdmissionPathway reference data — data only; (5) possibly add new InstitutionType or AwardLevel enum cases — code change only if new types needed (ADR-15 trigger); (6) add SEO landing pages for the country — presentation-layer work; (7) configure Typesense facets for country-specific filters — data-driven, no code change. External identifiers for the new country's authority codes are added to the `external_identifiers` table — no schema migration (BD-5/ADR-21).

Steps 1-4 and 7 are data-only. The domain model is untouched. This was validated against nine countries and thirteen education types with zero structural changes to the core domain.

### Study Abroad Integration (Stage 2)

Study abroad is a read-only application/product module, NOT a domain redesign. The existing domain already supports international institutions (Institution with any country, Programme with any institution, Scholarship targeting international institutions, Qualification with no nationality constraint). Study Abroad composes existing domain entities with content (Guides for "Studying in Canada", Articles for study-abroad news) and reference data (qualification equivalencies, tuition fee ranges, cost of living indices, visa requirement summaries). No new aggregates, no new invariants, no new events.

### Community Module (Stage 2)

Feature-flagged. Separate module with separate evolution velocity. Phase 1: Ask/Answer questions, Upvote/Downvote, Accept answer, Tag with domain entities. Phase 2: Comments, Reputation/karma, Moderation tools. Phase 3: Badges. Deferred: Bounty system. The community module must be DISABLEABLE via a feature flag without affecting the core platform.

### Capability Integration Points

| Future Capability | Architecture Impact | Effort |
|---|---|---|
| Multi-language content | Add `spatie/laravel-translatable` on content models. Schema + trait. | Medium |
| AI-powered recommendations | Read-only service consuming Scout search + engagement data. No model changes. | Medium |
| Paid listings/promotion | New `Promotion` model. Flag on Institution. | Small |
| API for third parties | New route group + API resources. Same Actions and Queries. | Medium |
| Mobile app | Same API via Sanctum. No backend changes. | Large (frontend only) |
| User reviews/ratings | New `Review` model in Product namespace. Polymorphic to domain entities. | Medium |
| New content types sharing behaviour | Add enum value to ResourceType or PrepType. No schema migration. | Trivial |
| New content types with distinct behaviour | New model + migration + traits + Actions + Queries + Blade. | Medium |

### Geographic Neutrality Test

No domain entity is Nigeria-specific. JAMB, WAEC, and Post-UTME are enum values (AdmissionPathway::UTME, QualificationType::OLevel, AdmissionPathway::PostUTME), not entities. Any country's education system is represented through the same enums plus reference data. The `Other` variant with text description handles anything not explicitly enumerated. StudyNexus can represent Nigerian UTME, UK UCAS, and US Common App admissions with the same domain model.

### Canonical Domain Model Summary

| Concept | Count | Composition |
|---|---|---|
| Entities | 13 | 5 aggregate roots + 4 child entities + 4 supporting entities |
| Value Objects | 28 | 12 immutable PHP objects (including 1 computed + 1 demoted-from-entity) + 17 PHP Backed Enums |
| Domain Events | 29 | Plain PHP classes, no shared interface |
| Application Actions | 20 | Each with explicit Action Criterion justification |
| Enums | 17 | 3 behavioural + 14 pure |
| RBAC Roles | 11 | 4 platform-global + 5 institution-scoped + 2 user-level |
| Database Tables | 60 | Across 10 layers (see 05-implementation.md Section 4) |

The domain model is frozen. All platform capabilities (authorization, engagement, notifications, search, SEO, content) are additive layers that surround the domain without modifying it. The architecture earns its 8.1/10 score: the simplest design that serves the expanded scope, and no simpler design would serve it correctly.
