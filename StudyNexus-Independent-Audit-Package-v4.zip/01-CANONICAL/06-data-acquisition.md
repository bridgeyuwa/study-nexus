# Data Acquisition & Ingestion Pipeline

**Date:** 2026-08-08
**Status:** Canonical design -- addresses audit finding S17.3 (most business-critical capability, least architected)
**Authority:** Derived from Business Capability #1 ("Acquire Educational Information"), OQ2-5 resolution, and domain architecture (`21-domain-architecture-frozen-baseline.md`)
**Platform baseline:** Laravel ^13.0 + PHP 8.5 + Filament v5 + Livewire v4

---

## 1. Design Principles

1. **Source of truth is the domain model.** Ingestion writes to domain aggregates through their public API (Actions, domain methods). Never bypass aggregate invariants by writing directly to tables.
2. **Ingestion does not modify canonical data without verification.** Every imported record enters a staging workflow. Only verified records update the canonical store.
3. **The system does not depend on active data feeds from agencies.** Per OQ2-5, information is primarily aggregated from public and official sources. Direct feeds are future enhancements.
4. **Idempotency is mandatory.** Re-running the same import must produce the same result. No duplicate entities, no double-counting, no side effects on re-import.
5. **Provenance follows the 80/20 model.** Entity-level provenance JSONB provides lightweight whole-entity source metadata. Field-level provenance (field_provenance table) is recorded selectively: Category A fields (5 fields: name, type, status, accreditation_status, cut_off_mark) always get provenance; Category B fields (6 fields: founded_year, location, website, admission_requirements, application_deadline, amount) get provenance only on conflict; Category C fields (all others) have no field-level provenance. This 80/20 model focuses effort on the fields that matter most.

---

## 2. Source Taxonomy

| Source Type | Examples | Access Method | Trust Level | Priority |
|-------------|----------|---------------|-------------|----------|
| **Official Registry** | JAMB, WAEC, NECO, NABTEB, NBTE, NUC | Public website, PDF reports, occasional API | High (Official) | P0 -- day one |
| **Institution Website** | University of Lagos, UNIBEN, OAU, etc. | Web scraping (with rate limiting and respect for robots.txt) | Medium (Unverified -> Verified after check) | P0 -- day one |
| **Accreditation Body** | NUC, NBTE, NCCE | Published accreditation lists | High (Official) | P0 -- day one |
| **Government Open Data** | FME, State MOE, UBEC | PDF, CSV, occasional portal | Medium-High (Official, may be stale) | P1 -- post-MVP |
| **Scholarship Provider** | PTDF, Shell, MTN Foundation, State governments | Provider websites, press releases | Medium (Unverified initially) | P1 -- post-MVP |
| **Community Contribution** | User reports, corrections | User submission via reporting workflow (OQ4-2) | Low (Community-Contributed) | P2 -- when user accounts exist |
| **Data Partner (future)** | Direct API from institutions/agencies | Authenticated API, SFTP, webhook | High (Verified) | P3 -- when partnerships exist |

---

## 3. Architecture Overview

```
+---------------------------------------------------------------------+
|                     EXTERNAL SOURCES                                |
|  JAMB  WAEC  NUC  Institution Sites  Scholarship Sites  ...        |
+------+------+------+----------+--------------+----------------------+
       |      |      |          |              |
+------v------v------v----------v--------------v----------------------+
|                    ADAPTER LAYER                                    |
|  +-------------+  +--------------+  +---------------+             |
|  | PDF Parser  |  | Web Scraper  |  | CSV/JSON Parser|             |
|  | (smalot/pdf)|  | (spatie/crawler)  | (maatwebsite/excel)|       |
|  +------+------+  +------+-------+  +------+--------+             |
|         |                |                  |                       |
|         +----------------+------------------+                       |
|                          v                                          |
|               +----------------------+                              |
|               |  Normalized DTO      |                              |
|               |  (Source-agnostic)   |                              |
|               +----------+-----------+                              |
+--------------------------+------------------------------------------+
                           v
+---------------------------------------------------------------------+
|                    STAGING LAYER                                    |
|  +----------------------+  +---------------------+                |
|  |  pending_imports     |  |  import_batches      |                |
|  |  (raw + normalized)  |  |  (batch tracking)    |                |
|  +----------+-----------+  +----------+----------+                |
|             |                         |                             |
|  +----------v-------------------------v----------+                 |
|  |         VERIFICATION ENGINE                   |                 |
|  |  - Duplicate detection (fuzzy matching)       |                 |
|  |  - Cross-source consistency check              |                 |
|  |  - Schema validation (domain rules)            |                 |
|  |  - Conflict detection & flagging               |                 |
|  +----------+------------------------------------+                 |
+-------------+-------------------------------------------------------+
              |
              v  (verified records only)
+---------------------------------------------------------------------+
|                    DOMAIN LAYER (existing)                          |
|  ImportInstitutionData Action -> Institution::establish()           |
|  RecordAccreditation Action    -> Institution::recordAccreditation()|
|  RegisterInformationSource     -> InformationSource::register()     |
|  VerifyInformationSource       -> InformationSource::verify()       |
|                                                                     |
|  Events emitted: InstitutionEstablished, InstitutionAccredited,    |
|  InformationSourceVerified, etc. -> UpdateSearchIndex               |
+---------------------------------------------------------------------+
```

---

## 4. Staging Schema

### 4.1 `import_batches`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Batch identity |
| `source_type` | string | Source taxonomy entry (e.g., "jamb_official", "institution_website") |
| `source_url` | string, nullable | URL or file path of the source |
| `adapter_class` | string | Fully qualified adapter class name |
| `status` | enum | `pending`, `parsing`, `parsed`, `verifying`, `verified`, `applying`, `completed`, `failed` |
| `total_records` | int | Records found in source |
| `verified_records` | int | Records that passed verification |
| `rejected_records` | int | Records that failed verification |
| `conflict_records` | int | Records that conflict with existing data |
| `applied_records` | int | Records successfully applied to domain |
| `started_at` | timestamp | When processing began |
| `completed_at` | timestamp, nullable | When processing completed |
| `error_log` | json, nullable | Structured error details |
| `metadata` | json | Source-specific metadata (scrape headers, PDF page count, etc.) |
| `created_by` | string | User or system process that initiated the import |
| `created_at` | timestamp | Partition key for monthly partitioning |

**Partitioning:** The `import_batches` table is partitioned by `created_at` using PostgreSQL range partitioning (monthly partitions). This allows instant dropping of old failed batches via `DROP TABLE import_batches_y2026m07` without VACUUM overhead. Each monthly partition is created automatically by a scheduled job (`CreateMonthlyPartitionJob`) that runs on the 1st of each month, creating the partition for the next month. Retention policy: partitions older than 6 months are dropped automatically unless they contain records with `status` in (`completed`, `failed`) that have not been archived. Partitions are named `import_batches_y{year}m{month:02d}`.

### 4.2 `pending_imports`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | UUID | Record identity |
| `batch_id` | UUID (FK) | Parent batch |
| `entity_type` | string | Target domain entity (Institution, Programme, Scholarship, etc.) |
| `raw_data` | json | Raw data from source (before normalization) |
| `normalized_data` | json | Normalized, source-agnostic DTO |
| `verification_status` | enum | `pending`, `verified`, `rejected`, `conflict`, `duplicate` |
| `verification_notes` | json, nullable | Structured verification results |
| `matching_entity_id` | BIGINT, nullable | If matched to existing entity (for updates/duplicates) |
| `match_confidence` | float, nullable | Fuzzy match confidence score (0.0-1.0) |
| `applied_at` | timestamp, nullable | When record was applied to domain |
| `provenance` | json | Source, acquired_at, trust_level, verification_history |
| `created_at` | timestamp | Partition key for monthly partitioning |

**Partitioning:** The `pending_imports` table is partitioned by `created_at` using PostgreSQL range partitioning (monthly partitions), following the same pattern as `import_batches`. Since `pending_imports` are ephemeral (resolved records are either applied to the domain or rejected), retention is shorter: partitions older than 3 months are dropped automatically. Partitions are named `pending_imports_y{year}m{month:02d}`.

---

## 5. Adapter Pattern

Each source type gets a dedicated adapter that implements a common interface:

```php
interface SourceAdapter
{
    /**
     * Fetch raw data from the external source.
     */
    public function fetch(SourceConfiguration $config): RawSourceData;

    /**
     * Normalize raw data into source-agnostic DTOs.
     */
    public function normalize(RawSourceData $raw): Collection; // Collection<NormalizedInstitutionDTO>

    /**
     * Validate a normalized record against domain rules.
     */
    public function validate(NormalizedDTO $dto): ValidationResult;
}
```

### Adapter Implementations

| Adapter | Source | Fetch Method | Key Challenges |
|---------|--------|-------------|----------------|
| `JambOfficialAdapter` | JAMB brochure/site | PDF download + parse | PDF structure varies by year; programme names differ from institutional names |
| `NucAccreditationAdapter` | NUC accreditation list | PDF/HTML parse | Accreditation status is time-bounded; must match to existing institutions |
| `InstitutionWebsiteAdapter` | Individual institution sites | Web scrape (spatie/crawler) | No standard schema; rate limiting; robots.txt compliance; structure changes |
| `ScholarshipProviderAdapter` | Provider websites | Web scrape | Press releases are unstructured; deadlines change frequently |
| `WaecResultAdapter` | WAEC official data | PDF/CSV parse | Subject code mapping; qualification equivalence |
| `CsvBulkImportAdapter` | Any CSV source | File upload + maatwebsite/excel | Column mapping; encoding; delimiter detection |

---

## 6. Verification Engine

### 6.1 Duplicate Detection

When a normalized record matches an existing entity:

| Match Confidence | Action |
|:---------------:|--------|
| >= 0.95 | **Auto-merge**: Update existing entity with new data (fields that changed only) |
| 0.80-0.94 | **Flag for review**: Present both records to a content admin for manual merge decision |
| 0.50-0.79 | **Likely different**: Create as new entity, but flag for spot-check |
| < 0.50 | **Distinct**: Create as new entity |

**Fuzzy matching strategy** (for institutions):
1. Exact match on JAMB code or NUC code (if available) -> confidence = 1.0
2. Normalized name similarity (Levenshtein/TF-IDF) + same state + same type -> confidence 0.80-0.95
3. Name similarity alone -> confidence 0.50-0.79

### 6.2 Cross-Source Consistency

When two sources disagree on the same fact:

| Scenario | Resolution |
|----------|-----------|
| Official source says X, unofficial says Y | **Official wins.** Record unofficial as `InformationSource(MarkedUnreliable)` if contradiction is material. |
| Two official sources disagree | **Priority-weighted resolution.** The source with the higher `information_sources.priority` value wins. If priorities are equal, flag as conflict and present to content admin. Both sources retain their provenance. |
| New data contradicts verified existing data | **Flag for review.** Do not overwrite verified data without explicit admin approval. |

**Source Authority Weighting:** The `information_sources.priority` integer column (default 0) provides deterministic conflict resolution. When the pipeline detects that two sources are updating the same field, the domain Action automatically defers to the source with the higher priority value. Only when priorities are equal does the conflict escalate to human review. Priority values are assigned by the content admin via Filament and reflect the authoritative weight of each source (e.g., NUC direct accreditation list = priority 100, JAMB brochure = priority 90, institution website = priority 50, community report = priority 10). This eliminates the "two official sources" ambiguity and reduces the volume of records requiring manual conflict resolution.

### 6.3 Schema Validation

Before a record enters the domain, validate it against the aggregate's invariants:
- Required fields present and non-empty
- Enum values are valid members of the target PHP enum
- Monetary amounts >= 0
- Dates are parseable and within reasonable ranges
- Location data has valid ISO 3166-1 country code (NG for Nigeria in MVP)
- Admission rule structure matches the expected rule type

---

## 7. Import Workflow

### 7.1 Automated Import (scheduled)

```
1. Scheduler triggers ImportJob for a configured source
2. ImportJob::handle()
   a. Create import_batches record (status: pending)
   b. Adapter::fetch() -- retrieve raw data
   c. Update batch: status = parsing
   d. Adapter::normalize() -- convert to DTOs
   e. Write to pending_imports (status: pending)
   f. Update batch: status = parsed, total_records = count
3. VerificationJob::handle()
   a. Update batch: status = verifying
   b. For each pending_import:
      - Duplicate detection -> match_confidence, matching_entity_id
      - Cross-source consistency check
      - Schema validation
      - Set verification_status (verified/rejected/conflict/duplicate)
   c. Update batch counters
4. ApplicationJob::handle()
   a. Update batch: status = applying
   b. For each verified record:
      - Dispatch domain Action (ImportInstitutionData, etc.)
      - Action invokes aggregate method -> emits domain event
   c. Update batch: status = completed, applied_records
```

### 7.2 Manual Import (admin-initiated)

1. Admin uploads a CSV/PDF via Filament admin panel
2. System creates an `import_batches` record with the uploaded file
3. Admin reviews the batch: sees total records, can preview normalized data
4. Admin triggers verification -> same VerificationJob
5. Admin reviews flagged records (conflicts, low-confidence matches)
6. Admin resolves conflicts manually (merge, reject, create new)
7. Admin approves and applies -> same ApplicationJob

---

## 8. Provenance Model

Every entity in the canonical store carries entity-level provenance metadata (JSONB), and selective field-level provenance is recorded in the `field_provenance` table per the 80/20 model (ND-4/ADR-23):

```php
// On every domain entity (via HasProvenance trait) - entity-level JSONB:
[
    'provenance' => [
        'source_type'       => 'jamb_official',
        'source_url'        => 'https://jamb.gov.ng/2026-brochure.pdf',
        'acquired_at'       => '2026-08-08T10:00:00Z',
        'last_verified_at'  => '2026-08-08T10:00:00Z',
        'trust_level'       => InformationCategory::Official,  // Official, Verified, Historical, CommunityContributed
        'verification_status' => SourceReliability::Verified,
    ]
]
// NOTE: import_batch_id is NOT included in provenance JSONB — staging is ephemeral by design.
```

**Field-level provenance** (field_provenance table) is recorded selectively:
- **Category A (5 fields)**: Always provenance — name, type, status, accreditation_status, cut_off_mark
- **Category B (6 fields)**: Provenance on conflict — founded_year, location, website, admission_requirements, application_deadline, amount
- **Category C (all others)**: No field-level provenance

**External identifiers** (external_identifiers table per BD-5/ADR-21) store authority-assigned codes (JAMB codes, NUC codes, etc.) generically — no per-entity code columns on canonical entities.

**Provenance is immutable once recorded.** If a field is updated from a different source, the old provenance is archived (not overwritten) and the new source is recorded. This provides a full audit trail of where every data point originated. Entity-level provenance JSONB does NOT include import_batch_id (staging is ephemeral by design). Field-level provenance (field_provenance) uses superseded_at/superseded_by_id for archival — no is_active column; derive active from superseded_at IS NULL. verification_status enum (not is_verified boolean). No value_hash. No primary_source_id on entities.

---

## 9. Scheduling & Operations

| Job | Schedule | Source | Queue |
|-----|----------|--------|-------|
| `JambBrochureImportJob` | Monthly (or on-demand when new brochure detected) | JAMB | `imports` |
| `NucAccreditationImportJob` | Quarterly (accreditation updates are periodic) | NUC | `imports` |
| `InstitutionWebsiteCrawlJob` | Weekly (detect changes to programme listings) | Institution sites | `imports` (rate-limited) |
| `ScholarshipProviderCrawlJob` | Weekly (detect new/changed scholarships) | Provider sites | `imports` (rate-limited) |
| `StaleDataDetectionJob` | Daily (flag entities not updated within threshold) | Internal | `maintenance` |
| `SearchIndexRebuildJob` | After each successful batch | Internal | `search` |
| `CreateMonthlyPartitionJob` | Monthly (1st of month, creates next month's partitions) | Internal | `maintenance` |
| `DropExpiredPartitionsJob` | Monthly (1st of month, drops partitions past retention) | Internal | `maintenance` |

**Rate limiting:** All web-scraping jobs respect per-domain rate limits (configurable, default: 1 request/second per domain). Uses `spatie/laravel-rate-limited-job-middleware` for queue job rate limiting and Laravel's `RateLimiter` facade for HTTP-level throttling. Respects `robots.txt`.

**Failure handling:** If a source becomes unavailable or returns unexpected data, the batch fails gracefully. The error is logged in `import_batches.error_log`. No partial data is applied -- a batch is atomic: either all verified records are applied, or none are (with manual override available for partial application after admin review).

---

## 10. Required Packages

| Package | Version | Purpose | Already in Stack? |
|---------|---------|---------|:-----------------:|
| `spatie/crawler` | ^1.0 | Web scraping with rate limiting and robots.txt support | **NEW** |
| `smalot/pdfparser` | ^2.0 | PDF parsing for official brochures/lists | **NEW** |
| `maatwebsite/excel` | ^3.1 | CSV/Excel import for bulk data | Yes |
| `laravel/scout` | ^4.0 | Search index management after imports | Yes |
| `spatie/laravel-activitylog` | ^5.0 | Backend audit trail for all import operations | Yes |
| `pxlrbt/filament-activity-log` | ^2.0 | Filament v5 UI integration for activity log display | Yes |
| `spatie/laravel-rate-limited-job-middleware` | ^1.0 | Queue job rate limiting for crawl jobs | **NEW** |

**No fabricated packages.** All new additions are verified real packages from established vendors (Spatie, Smalot, pxlrbt). The `spatie/laravel-activitylog` version is pinned to ^5.0 for Laravel 13 compatibility. The `pxlrbt/filament-activity-log` package provides the Filament v5 admin panel integration for viewing activity log entries generated by the Spatie backend.

---

## 11. Admin UI (Filament v5)

| Resource | Purpose |
|----------|---------|
| `ImportBatchResource` | View all import batches, status, counts, error logs. Trigger re-runs. |
| `PendingImportResource` | View/resolve individual pending records. Manual merge/reject/approve. |
| `InformationSourceResource` | Manage source registry (add/edit/disable sources, configure adapters). |

**Authorization:** Only `platform-admin` and `content-admin` can initiate imports. `content-editor` can view batches and resolve conflicts but not apply changes. Institution-scoped users cannot modify imports (imports are a platform-level operation). RBAC is enforced via `bezhansalleh/filament-shield` with the 11-role model using a string `role` column on the users table.

---

## 12. Integration with Existing Domain Architecture

This pipeline integrates with the existing domain through the **already-defined Actions**:

| Pipeline Step | Domain Action Invoked | Aggregate Method |
|---------------|----------------------|-----------------|
| New institution from import | `CreateInstitution` | `Institution::establish()` |
| Accreditation from import | `RecordAccreditation` | `Institution::recordAccreditation()` or `Programme::recordAccreditation()` |
| New programme from import | `CreateProgramme` | `Programme::introduce()` |
| Source verification | `VerifyInformationSource` | `InformationSource::verify()` |
| Source flagged unreliable | `MarkSourceUnreliable` | `InformationSource::markUnreliable()` |
| Batch data import | `ImportInstitutionData` | Orchestrates multiple creates/updates |

**No new domain Actions are introduced.** The ingestion pipeline is an application-layer orchestration that feeds data through the existing domain API.

---

*This document resolves audit finding S17.3. The data-acquisition pipeline is now architected to the same depth as the domain core and search/SEO layers.*
