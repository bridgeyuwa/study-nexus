# StudyNexus — Canonical Authority (Tier 1)

## What This Contains

These six documents constitute the **frozen canonical authority** for StudyNexus. They are the V2 baseline, remediated through multiple waves of independent audit, adversarial review, and surgical correction.

## The Documents

| # | Document | Purpose |
|---|----------|---------|
| 1 | `01-business.md` | Business context, product vision, users, market, competitors, monetisation |
| 2 | `02-decisions.md` | All architectural decisions (ADRs), foundational decisions, canonical counts |
| 3 | `03-domain.md` | Domain model: entities, VOs, enums, invariants, aggregate roots, events |
| 4 | `04-architecture.md` | Technology stack, application architecture, auth, admin, search, SEO, RBAC |
| 5 | `05-implementation.md` | Implementation blueprint: migrations, phases, packages, schema, search |
| 6 | `06-data-acquisition.md` | Data acquisition pipeline: sources, staging, provenance, import architecture |

## Authority Rules

1. **These documents override ALL other documents.** Where a product experience document, governance document, or historical document conflicts with these, these prevail.
2. **V2 is immutable.** No modifications are permitted. If an independent audit finds errors, they must be documented as findings against the canonical baseline, not silently corrected.
3. **The implementation plan** (05-implementation.md) IS canonical. It is not a suggestion — it is the frozen execution blueprint.
4. **No other document may introduce** new entities, new VOs, new enums, new tables, new packages, or new architectural decisions that contradict these documents.

## Relationship to Other Tiers

- **Tier 2 (Product Experience):** Constrained by Tier 1. The UX must be implementable within the architecture defined here.
- **Tier 3 (Implementation Plan):** IS Tier 1 (05-implementation.md is canonical).
- **Tier 4 (Governance):** Explains HOW Tier 1 reached its current state. Does not override it.
- **Tier 5 (Research):** Informs but does not constrain. Competitor features are NOT requirements.
- **Tier 6 (Historical):** Superseded. Preserved for traceability only.

## V4.1 Remediation State

This V2 baseline has been remediated through four waves:
1. **Wave 1:** Canonical amendment (enum reconciliation, ADR-6 enforcement, ProgrammeInstance/Campus)
2. **Wave 2:** Database synchronization (VO count 28→29, JSONB deconstruction, public_ids, tsvector/GIN, source priority, staging partitioning)
3. **Wave 3:** UI theming (OKLCH Sky/Cyan/Teal/Emerald palette, dark mode, Refactoring UI rules) + Laravel ecosystem package mandates + Event Sourcing rejection
4. **Wave 4:** Auth stack & UI boundary mandates (Fortify + Flux Pro, three-surface boundary, organization portal pending revision gate)
