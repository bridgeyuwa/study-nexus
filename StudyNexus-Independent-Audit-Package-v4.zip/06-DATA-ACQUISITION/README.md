# StudyNexus — Data Acquisition Research

## Contents

- **30-data-acquisition-pipeline-HISTORICAL.md** — Historical data acquisition pipeline design from the original pre-implementation baseline. Superseded by the canonical `06-data-acquisition.md` in Tier 1, but preserved for context on how the pipeline design evolved.

## Key Data Sources (from canonical 06-data-acquisition.md)

- **JAMB** — Joint Admissions and Matriculation Board (UTME results, cut-off marks)
- **IBASS** — Institutional Based Admission Screening System
- **NUC** — National Universities Commission (accreditation, programme approval)
- **NBTE** — National Board for Technical Education (polytechnic accreditation)
- **NCCE** — National Commission for Colleges of Education
- **Institutional websites** — Direct institutional data sources
- **Manual entry** — Platform staff data entry

## Provenance Model

The canonical provenance model (ND-4/ADR-23) uses:
- Entity-level JSONB `metadata` for lightweight source tracking
- `field_provenance` table for Category A fields (80/20 model)
- `information_sources` table with `priority` for conflict resolution
- `external_identifiers` table (BD-5/ADR-21) for authority-assigned codes
