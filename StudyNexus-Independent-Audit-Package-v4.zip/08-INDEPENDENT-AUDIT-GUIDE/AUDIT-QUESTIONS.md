# StudyNexus — Audit Questions

Structured independent challenge framework for the StudyNexus independent audit.

---

## Product

- Is the product model coherent? Does "search-first, information-rich, trust-grounded" actually constrain the architecture meaningfully, or is it aspirational branding?
- Is programme-first discovery actually the right foundation? Would institution-first or discipline-first be more natural for the Nigerian market?
- Are long-term product capabilities (rankings, maps, AI recommendations, B2B) adequately accommodated by the current architecture, or do they require architectural changes that will be painful later?
- Are there obvious strategic gaps? (e.g., mobile app, offline access, SMS-first interaction for low-data users)
- Is the "no applications" boundary defensible long-term? Will StudyNexus inevitably need to handle application workflows?

## Domain

- Are the aggregate boundaries correct? Is Programme truly an aggregate root, or should ProgrammeInstance be? Is Scholarship really an aggregate root with only 2 invariants?
- Are relationships semantically correct? Is Campus a "supporting entity" of Institution, or is it an aggregate root in its own right (with its own address, facilities, programmes)?
- Are lifecycle models complete? Institution has 5 lifecycle states — is this sufficient? What happens when an institution loses accreditation?
- Are Value Objects appropriate? Is Money a VO or should it be two columns (tuition_amount + currency_code)? Is Address a VO or should it be deconstructed columns?
- Are there hidden EAV patterns? Does the generic `external_identifiers` table risk becoming an EAV store? Does `field_provenance` risk the same?
- Are supporting entities actually justified by behaviour, or merely by data? (Qualification, EducationAuthority, ScholarshipProvider)

## Identity

- Are BIGINT canonical PKs appropriate for a platform that may need multi-database sharding at scale?
- Are UUID `public_id` columns correctly bounded? (5 entities have them — should there be more or fewer?)
- Are external identifiers modelled correctly? Is the generic `external_identifiers` table with `authority_id` nullable FK sufficient, or should JAMB codes, NUC codes etc. have dedicated columns for query performance?
- Is slug/public identity independent from DB identity? Can slugs change without breaking URLs?

## Data Lineage

- Is the SOURCE → OBSERVATION → RECONCILIATION → CANONICAL ASSERTION → PUBLICATION model coherent? Is every step implementable?
- Is provenance sufficient? Can you actually answer "who changed this field and why?" for every Category A field?
- Is the 80/20 field-provenance strategy defensible? Which 5 Category A fields are tracked, and are they the RIGHT 5?
- Can `field_provenance` become a hidden EAV architecture if too many fields are added?
- Are information-loss decisions acceptable? What data is discarded during reconciliation that cannot be recovered?

## InformationSource / EducationAuthority

- Are their semantics correct? Is InformationSource truly an aggregate root (ND-5)? Should it have `authority_id` as nullable FK?
- Can all important source types be represented? (JAMB brochure, NUC directory, institutional website, IBASS, Wikipedia, manual entry)
- Is the `priority` column on `information_sources` sufficient for conflict resolution, or does it need a more sophisticated authority weighting model?

## AdmissionCycle

- Is `PhaseSequence` JSONB correct? Are stable phase IDs sufficient for concurrent access?
- Is `current_phase` genuinely authoritative? What happens if two admins advance the phase simultaneously?
- Are concurrency guarantees implementable with the current model?

## Search / Typesense

- Is PostgreSQL correctly the source of truth? Is the `search_vector` GENERATED ALWAYS STORED column correctly defined?
- Is Typesense appropriately scoped? (deferred per ADR-6, only when FTS latency > 200ms)
- Are facet/search needs supported by the current schema? (geographic facets, tuition range, award level, discipline)
- Is search architecture compatible with a future recommendation engine? Does the tsvector design leave room for vector similarity search?

## Product Experience

- Does the domain model support the UX? Are there data dependencies in the UX that aren't in the domain?
- Does the implementation plan faithfully implement the UI/UX documents?
- Are there missing data dependencies? (e.g., does the programme detail page need data that isn't in the Programme entity?)
- Is the OKLCH theming architecture implementable? Are there browser support issues with OKLCH?

## SEO

- Does the architecture support the intended SEO universe? (programme × institution × location × award-level combinations)
- Are there safeguards against thin programmatic SEO? (pages with insufficient unique content)
- Are slugs, redirects, canonical URLs and projections sufficiently supported?
- Is the `is_published` + `published_at` model sufficient for SEO, or does it need a more sophisticated publishing workflow?

## Implementation

- Does IMPLEMENTATION-PLAN.md faithfully map the architecture? Are there entities in the domain model that have no migration in the plan?
- Are migration dependencies correct? (e.g., `programme_instances` before `programmes`? or after?)
- Is the phase sequencing sensible? Is Phase 0 too large? Should it be split?
- Is anything unnecessarily complex? (e.g., the provenance model, the organization-scoped authorization)
- Is anything missing? (e.g., seed data, test factories, CI/CD configuration)

## Competitive Strategy

- Does the current architecture leave room for useful capabilities discovered from competitors? (Bachelorsportal: programme comparison; educations.com: scholarship matching; IDP: application tracking)
- Which competitor-derived capabilities are genuinely important for the Nigerian market?
- Which should NOT influence the architecture? (e.g., application processing, payment gateways)
- Are there likely future moats the current design accidentally prevents? (e.g., would adding applications later require a fundamental architecture change?)

## Auth & UI Boundaries

- Is the three-surface boundary (Public / User Portals / Admin) correct? Should there be a fourth surface (e.g., API for mobile)?
- Is the Organization Portal Pending Revision Gate implementable without significant additional complexity?
- Is Laravel Fortify + Livewire + Flux Pro the right auth stack, or would Laravel Breeze be simpler for MVP?
- Are the 11 RBAC roles correct? Are some unnecessary? Are some missing?

## Blind Spots

> **What important thing would a competent architect reviewing StudyNexus independently notice that the original authors may have missed?**

The reviewer is explicitly encouraged to identify omissions not listed in this brief. Potential areas:
- Internationalization/i18n architecture (Nigeria → Africa expansion)
- Rate limiting and abuse prevention
- Content moderation workflow (beyond the Pending Revision Gate)
- Data export compliance (NDPR/GDPR) implementation
- Disaster recovery and business continuity
- Observability and monitoring strategy
- API versioning strategy (for future mobile app)
- Multi-tenancy concerns (institution-scoped data isolation)
- Performance budget and loading strategy for mobile-first users
- Accessibility (WCAG) compliance
