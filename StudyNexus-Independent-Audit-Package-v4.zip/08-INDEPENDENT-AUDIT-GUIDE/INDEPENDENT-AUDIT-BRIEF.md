# StudyNexus — Independent Audit Brief

**Document purpose:** Orient the independent reviewer. This document contains NO conclusions.

---

## Current State

- **Discovery is closed.** Domain discovery, product discovery, and business discovery are all frozen.
- **V2 architecture is frozen.** The canonical documents (01–06) are immutable.
- **Implementation plan is ready.** 05-implementation.md is the canonical blueprint.
- **No code has been written.** No Laravel project has been scaffolded.
- **No migrations have been written.** Phase 0 has not begun.
- **The V2 baseline has been remediated** through 4 waves of surgical correction based on independent audit findings.

## What StudyNexus Is

StudyNexus is a **Nigeria-first, search-first education discovery platform**. It helps Nigerian students find, compare, and understand educational programmes and institutions. It is NOT an application platform — it does not process admissions. It is a trust-grounded information platform that moves users from question to informed decision.

**Core job-to-be-done:** A secondary school student in Nigeria types "Computer Science" into a search engine and finds verified programmes with admission status, cut-off marks, and requirements — from a single trusted source.

## First Vertical Slice

```
Homepage → Programme Search → Faceted Results → Programme Detail → Institution Detail → Admission Information
```

## Authority Hierarchy (Summary)

1. **Tier 1 — Canonical (01-CANONICAL/):** Frozen V2 baseline. Overrides everything.
2. **Tier 2 — Product Experience (02-PRODUCT-EXPERIENCE/):** UX/UI authority. Constrained by Tier 1.
3. **Tier 3 — Implementation (03-IMPLEMENTATION/):** Plan + audit reports. Explanatory.
4. **Tier 4 — Governance (04-GOVERNANCE/):** Decision evidence. Traceability, not authority.
5. **Tier 5 — Product Strategy (05-PRODUCT-STRATEGY/):** Competitive research. NON-AUTHORITATIVE.
6. **Tier 6 — Historical (07-HISTORICAL/):** Superseded. Traceability only.

## Important Cautions

### ⚠️ DO NOT assume previous GLM audits are correct.
Multiple GLM-based audits declared "GO" and still left severe internal inconsistencies (VO count 28 vs 29, domain table count 12 vs 16, missing ProgrammeInstance/Campus entities, stale ADR-6 references). The V4.1 remediation corrected these, but **you must independently verify**.

### ⚠️ DO NOT assume the architecture is correct merely because multiple audits say GO.
Audits can share the same blind spots. An independent reviewer must check primary source documents, not just audit conclusions.

### ⚠️ DO NOT treat competitor features as requirements.
PRODUCT-DISCOVERY-CHALLENGE.md catalogues features from global competitors (Bachelorsportal, Mastersportal, educations.com, IDP) and Nigerian competitors (Academics.ng, MySchoolGist). These are research inputs, NOT requirements. The canonical architecture decides what StudyNexus builds.

### ⚠️ DO NOT trust count claims without verification.
Canonical counts (13 entities, 29 VOs, 17 enums, 60 tables) have been verified multiple times but have been wrong before. Cross-check 03-domain.md entity/VO/enum definitions against 05-implementation.md table definitions.

## Key Architectural Boundaries to Verify

1. **BIGINT PKs (no UUID PKs)** — ADR-19 mandates this. Verify no UUID PK has crept in.
2. **PostgreSQL FTS for MVP (no Typesense day-one)** — ADR-6 mandates this. Verify implementation plan doesn't prematurely introduce Typesense.
3. **Three-surface UI boundary** — Public Site (Livewire+Flux), User Portals (Livewire+Flux), Admin (Filament only). Verify no Filament on public site or user portals.
4. **Organization Portal Pending Revision Gate** — Institution reps cannot directly publish. Verify this workflow is consistently documented.
5. **Event Sourcing rejected** — Verify no Event Sourcing patterns have been introduced.
6. **OKLCH color space** — Verify no HEX/HSL color definitions remain in architecture docs.
7. **spatie/laravel-activitylog for audit trails** — Verify this is consistently used instead of Event Sourcing.
