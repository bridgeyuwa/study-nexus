# StudyNexus — Canonical Update Report

**Date:** 2026-08-10
**Authority:** Approved discovery closure (DISCOVERY-CLOSURE.md) — 12 canonical changes
**Scope:** Canonical correction only — no new decisions, no architecture redesign, no code

---

## 1. The 12 Changes Applied

| # | Document | Section | Change | Reason |
|---|----------|---------|--------|--------|
| 1 | 03-domain.md | Programme entity behaviours | Added publication attributes: `is_published` boolean (default false), `published_at` nullable timestamp. Added classification attribute: `discipline_id` UUID FK nullable referencing `disciplines` reference table. | Publication visibility is orthogonal to domain lifecycle. Discipline classification is needed for programme discovery. |
| 2 | 03-domain.md | Institution entity behaviours | Added publication attributes: `is_published` boolean (default false), `published_at` nullable timestamp. | Same publication requirement as Programme. |
| 3 | 03-domain.md | Scholarship entity behaviours | Added publication attributes: `is_published` boolean (default false), `published_at` nullable timestamp. | Consistent publication model across all user-facing entities, even though scholarship public pages are Phase 2. |
| 4 | 03-domain.md | New Section 12: Reference Data | Added `disciplines` reference table definition: id, name, slug, description, sort_order. Documented design decisions: flat for MVP, single discipline per programme, not an enum, managed via Filament CRUD, external source mapping in adapter config. | Programme discipline classification is required for faceted search and SEO landing pages. |
| 5 | 03-domain.md | New Section 13: Cut-Off Mark History | Added `cut_off_marks` query model definition: programme_id, admission_cycle_id, pathway, value, source_id. Documented cross-cycle history (Scenario A) and intra-cycle corrections (Scenario B). Explicitly stated: no generic versioning framework, no event sourcing, no polymorphic history. | Historical cut-off display is a core user need for MVP. This is the smallest correct model. |
| 6 | 05-implementation.md | Database schema — programmes table; Section 3.1 Programme | Fixed ProgrammeStatus enum values from (Draft, Published, Archived, Suspended) to (Prospective, Admitting, Suspended, Discontinued). Added columns: `is_published` boolean default false, `published_at` timestamp nullable, `discipline_id` UUID FK nullable references disciplines(id). Replaced `discipline` string column with `discipline_id` FK. | Align implementation with canonical domain model. Publication is separate from lifecycle. |
| 7 | 05-implementation.md | Database schema — institutions table; Section 3.1 Institution | Fixed InstitutionStatus enum values from (Draft, Published, Archived) to (Provisional, Operational, Suspended, Closed). Added columns: `is_published` boolean default false, `published_at` timestamp nullable. | Align implementation with canonical domain model. |
| 8 | 05-implementation.md | Database schema — scholarships table; Section 3.1 Scholarship | Added columns: `is_published` boolean default false, `published_at` timestamp nullable. | Consistent publication model across all user-facing entities. |
| 9 | 05-implementation.md | Database schema — new tables | Added `disciplines` table (id, name, slug, description, sort_order, created_at, updated_at). Added `cut_off_marks` table (id, programme_id FK, admission_cycle_id FK, pathway varchar(50), value integer, source_id FK nullable, created_at, updated_at, UNIQUE programme_id+admission_cycle_id+pathway). Updated table count from 54 to 56. Updated domain layer count from 10 to 12. | Discipline taxonomy and cut-off history are MVP requirements. |
| 10 | 05-implementation.md | Typesense collections — programmes | Added `discipline`, `discipline_slug`, `is_published`, `tuition_min`, `tuition_max`, `is_admission_open` to the programmes Typesense collection. Documented search projection fields and their computation via toSearchableArray(). | Discipline is a primary facet. Publication controls search indexing. Tuition range and admission status are search projection fields. |
| 11 | 04-architecture.md | Search architecture — new subsection | Added "Detail Page vs Search/List Data Source" subsection making explicit: (1) Typesense is the serving layer for all list/search/browse surfaces. (2) PostgreSQL/Eloquent is the serving layer for all detail pages. (3) Programme list within institution detail is Eloquent. (4) Search projection fields exist only in Typesense. | Product experience reveals Typesense as primary read path for discovery. Detail pages need full entity graph from PostgreSQL. |
| 12 | 04-architecture.md | New Section 5.5: Publication/Visibility Model | Added section defining: `is_published` boolean + `published_at` nullable timestamp on Institution, Programme, Scholarship. Publication is orthogonal to domain lifecycle. Visibility rule: `is_published = true` AND lifecycle status allows. `published_at` = first publication date (set once, never changed). Publication history via spatie/laravel-activitylog. No publication_status enum. No publication state machine. Content trait distinction documented. | Publication is an application/product concern not in original architecture document. |

---

## 2. Documents Affected

| Document | Changes | Sections Modified/Added |
|----------|---------|------------------------|
| 03-domain.md | 5 changes | Section 8 (Institution, Programme, Scholarship entity behaviours); Section 10 (Entity Relationships — added Programme-Discipline); New Section 12 (Reference Data: Disciplines); New Section 13 (Cut-Off Mark History) |
| 05-implementation.md | 5 changes | Section 3.1 (Aggregate Root descriptions); Section 3.4 (Enum table — InstitutionStatus, ProgrammeStatus); Section 4.1 (Table inventory); Section 4.3 (Domain table schemas); Section 4.6 (Migration dependencies); Section 8.2 (Typesense collections); Section 8.3 (Search projection fields); Section 10.1 (Phase 1b); Trailing summary |
| 04-architecture.md | 2 changes | Section 3 (Domain layer description and model listing); Section 5 (Search architecture — new Detail Page subsection); New Section 5.5 (Publication/Visibility Model) |

**Documents NOT modified:** 01-business.md, 02-decisions.md, 06-data-acquisition.md

---

## 3. Cross-References Updated

| Cross-Reference | Change |
|----------------|--------|
| Programme → Discipline relationship | Added to 03-domain.md Section 10 and 05-implementation.md Section 3.1 |
| `discipline` string column → `discipline_id` FK | Replaced in 05-implementation.md programmes table schema |
| Table count 54 → 56 | Updated in 05-implementation.md (section header, inventory, trailing summary) |
| Domain layer table count 10 → 12 | Updated in 05-implementation.md table inventory |
| Phase 1b "10 domain tables" → "12 domain tables" | Updated in 05-implementation.md implementation order |
| InstitutionStatus enum values | Corrected in 05-implementation.md Section 3.4 and table schemas |
| ProgrammeStatus enum values | Corrected in 05-implementation.md Section 3.4 and table schemas |
| Discipline/CutOffMark models | Added to 04-architecture.md domain layer model listing and 05-implementation.md project structure |
| Cut-off marks and disciplines | Referenced from 05-implementation.md table schemas to 03-domain.md Sections 12 and 13 |

---

## 4. Final Canonical Counts

| Concept | Count | Composition | Status |
|---------|-------|-------------|--------|
| Entities | 11 | 5 aggregate roots + 3 child entities + 3 supporting entities | Unchanged — frozen |
| Value Objects | 28 | 12 immutable PHP objects + 16 PHP Backed Enums | Unchanged — frozen |
| Domain Events | 29 | Plain PHP classes, no shared interface | Unchanged — frozen |
| Application Actions | 20 | Each with explicit Action Criterion justification | Unchanged — frozen |
| Enums | 16 | 3 behavioural + 13 pure | Unchanged — frozen |
| RBAC Roles | 11 | 4 platform + 5 institution-scoped + 2 user | Unchanged — frozen |
| Reference/Query Models | 2 | Discipline (reference data) + CutOffMark (query model) | **New** — not domain entities |
| Database Tables | 56 | 12 domain + 7 reference + 5 content + 9 auth/RBAC + 4 engagement + 5 community + 1 notification + 3 settings + 1 SEO + 9 infrastructure | Updated from 54 |
| Typesense Collections | 7 | institutions, programmes, scholarships, articles, guides, educational_resources, exam_preparations | Unchanged — programme fields expanded |

---

## 5. Final Platform Versions

| Component | Version | Status |
|-----------|---------|--------|
| PHP | 8.5+ | Canonical — no fallback |
| Laravel | ^13.0 | Canonical — no Laravel 12 |
| PostgreSQL | 16+ | Canonical — source of truth |
| Redis | 7+ | Cache + queue |
| Typesense | 29.x+ | Search projection |
| Filament | v5 | Admin panel |
| Livewire | v4 | Public UI |
| Tailwind CSS | ^4.0 | Styling |
| Node.js | 22 LTS | Asset compilation |

---

## 6. Final Product Scope

| Scope | Description |
|-------|-------------|
| First vertical slice | Programme discovery: Home → Programme search → Faceted results → Programme detail → Institution detail → Admission information |
| Scholarship in first slice | Entity + admin CRUD + inline related-content on programme detail. No public landing/detail/search pages. |
| Phase 2+ | Scholarship public discovery, comparison, eligibility assessment, tuition versioning, discipline hierarchy, content models, user accounts, community, notifications, examination/resource discovery |

---

## 7. Final Acquisition Boundary

**External system (outside StudyNexus):**
```
scrape → extract → clean → reconcile → compare → human review → approved dataset
```

**StudyNexus (inside boundary):**
```
approved dataset → import → validate → apply → canonical state → history/provenance → events → projections → Typesense → cache
```

The handoff contract is implementation-neutral. It defines the information StudyNexus needs to safely process an approved release without assuming a specific external system, scraper, programming language, or deployment.

---

## 8. Final Historical-Data Policy

| Data Point | Mechanism | Versioning |
|------------|-----------|------------|
| Cut-off marks | `cut_off_marks` table — one row per programme per cycle per pathway | Cross-cycle: multiple rows. Intra-cycle: UPDATE + activity log. No generic versioning. |
| Accreditation | `AccreditationRecord` — immutable append-only | Each record is a historical fact. Current status derived from sequence. |
| Policies | Supersession model: Draft → Published → Superseded → Withdrawn | Old policy remains; new policy supersedes. |
| Tuition | Current value on Programme (MonetaryAmount VO) | Phase 2 for versioning. Activity log for audit. |
| General field changes | `spatie/laravel-activitylog` | Audit trail for all changes. Not a user-facing timeline. |

**Explicit boundary:** MVP audit history (via activity log) is not the same as a user-facing timeline of historical values. If future product requirements require users to see effective historical values (e.g., intra-cycle cut-off revisions), that can be introduced as explicit domain-specific versioning without a generic framework.

---

## 9. Verification Results

### Domain Model
- [x] 11 entities (5 aggregate roots + 3 child + 3 supporting)
- [x] 28 Value Objects (12 genuine + 16 enums)
- [x] 29 domain events
- [x] 20 Actions
- [x] 16 enums
- [x] Admission Pathway is Value Object (not entity)
- [x] ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued (consistent across 03-domain.md, 04-architecture.md, 05-implementation.md)
- [x] InstitutionStatus: Provisional, Operational, Suspended, Closed (consistent across 03-domain.md, 04-architecture.md, 05-implementation.md)
- [x] Publication model: `is_published` + `published_at` (orthogonal to lifecycle, documented in all three affected docs)

### RBAC
- [x] 11 roles (4 platform + 5 institution-scoped + 2 user)
- [x] String `role` column on OrganizationMember pivot
- [x] No `role_id` FK
- [x] `platform-admin` naming (not `super-admin`)

### Platform
- [x] Laravel ^13.0
- [x] PHP 8.5
- [x] Filament v5
- [x] Livewire v4
- [x] No Laravel 12 instructions in canonical docs
- [x] No Filament v3 instructions in canonical docs

### Search
- [x] PostgreSQL!Eloquent canonical (source of truth)
- [x] Typesense projection/search layer
- [x] Detail pages from PostgreSQL/Eloquent
- [x] List/search from Typesense
- [x] Programme list within institution detail from Eloquent
- [x] Search projection fields (tuition_min/max, is_admission_open, discipline, is_published) exist only in Typesense

### Data Acquisition
- [x] External acquisition (scrape → approved dataset)
- [x] Internal canonical ingestion/release (approved dataset → import → validate → apply → canonical → events → projections)
- [x] Handoff contract is implementation-neutral

### Lifecycle/Publication
- [x] Lifecycle states remain canonical (ProgrammeStatus, InstitutionStatus per 03-domain.md)
- [x] Publication is orthogonal (is_published + published_at)
- [x] `published_at` = first publication date, never rewritten
- [x] Publication history via activity log, no separate subsystem
- [x] No publication_status enum
- [x] No publication state machine

### Historical Data
- [x] `cut_off_marks` table supports admission-cycle values (Scenario A: cross-cycle)
- [x] Intra-cycle corrections: UPDATE + activity log (Scenario B)
- [x] No generic versioning framework
- [x] Audit history remains available

### Product Scope
- [x] Programme discovery = first vertical slice
- [x] Scholarship public discovery = Phase 2
- [x] Examination/resource discovery = later
- [x] Scholarship entity + admin CRUD in first slice; public pages Phase 2

---

## 10. Remaining Non-Blocking Issues

| Issue | Status | Resolution |
|-------|--------|------------|
| Discipline seed values not yet defined | Non-blocking | Table structure is defined; values are seed data populated during implementation when first programme data is imported |
| Handoff contract field details may need refinement during import pipeline implementation | Non-blocking | Boundary is decided; contract fields can be adjusted during implementation without schema rework |
| `spatie/laravel-activitylog` version in 06-data-acquisition.md shows ^5.0 while 05-implementation.md shows ^4.0 | Non-blocking | Minor version inconsistency in a non-canonical detail; resolve during implementation by using the version compatible with Laravel 13 |
| ScholarshipStatus values differ between 03-domain.md (Draft, Announced, Open, Closed, Expired, Withdrawn) and 05-implementation.md (Active, Closed, Upcoming) | Non-blocking | Domain model (03-domain.md) is canonical for lifecycle; 05-implementation.md ScholarshipStatus values need correction to match domain model during implementation |
| 01-business.md and 02-decisions.md not updated for publication/discipline/cut-off | Non-blocking | These documents establish business vision and decisions; the specific schema/model additions don't change business decisions — they are implementation details within approved decision boundaries |

---

*Canonical update complete. All 12 approved changes applied. No new decisions made. No architecture redesigned. No code written. No migrations created. Discovery is closed. The project is discovery-complete and implementation-ready.*
