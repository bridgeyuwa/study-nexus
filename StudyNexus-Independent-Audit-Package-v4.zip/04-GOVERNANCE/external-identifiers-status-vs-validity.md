# HOSTILE ARCHITECTURE REVIEW: external_identifiers status vs. validity

**Target:** `external_identifiers` schema — `status` column vs. `valid_from`/`valid_until` temporal interval
**Review Type:** Adversarial state analysis
**Date:** 2026-08-18
**Verdict:** DESIGN DEFECT — overlapping concepts with no coupling invariants

---

## 1. Current Schema (ADR-DL1 Final)

```sql
CREATE TABLE external_identifiers (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entity_type     VARCHAR(255) NOT NULL,
  entity_id       BIGINT NOT NULL,
  authority_id    BIGINT NOT NULL,
  identifier_type VARCHAR(100) NOT NULL,
  identifier      VARCHAR(255) NOT NULL,
  status          VARCHAR(50) NOT NULL DEFAULT 'active',  -- 'active','retired','superseded'
  valid_from      TIMESTAMP NOT NULL DEFAULT NOW(),
  valid_until     TIMESTAMP,                               -- null = still valid or unknown
  source_id       BIGINT,
  metadata        JSONB,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW()
);

-- Partial unique indexes
CREATE UNIQUE INDEX ext_ident_authority_unique
  ON external_identifiers (authority_id, identifier_type, identifier)
  WHERE status = 'active';

CREATE UNIQUE INDEX ext_ident_entity_unique
  ON external_identifiers (entity_type, entity_id, authority_id, identifier_type)
  WHERE status = 'active';
```

**ADR-DL1 stated design intent (Section 3.2):**
> "Use status column as the primary active indicator. valid_from and valid_to remain as **temporal metadata** (when the identifier was known to be in use), but uniqueness is enforced on status, not on valid_to."

---

## 2. Exact Column Semantics (As-Designed vs. As-Needed)

| Column | ADR-DL1 Stated Semantics | Actual Semantics Needed | Problem |
|--------|--------------------------|-------------------------|---------|
| `status` | Primary lifecycle indicator: active/retired/superseded | Primary lifecycle indicator | Correct intent, but no coupling to temporal columns |
| `valid_from` | "When the identifier was known to be in use" (temporal metadata) | "When the authority assigned this identifier to this entity" | Acceptable if immutable (Q18 says it is) |
| `valid_until` | "When the identifier stopped being in use" (temporal metadata) | **MUST be the timestamp of the status transition to retired/superseded** | Currently independent of status — can diverge |

**The critical gap:** The ADR-DL1 acknowledges that `status` and `valid_until` both express lifecycle state, but treats them as **independently mutable** columns with no enforced relationship. "Temporal metadata" is a handwave — in practice, `valid_until` is set simultaneously with status changes (Q14: `status = 'retired', valid_until = NOW()`), which means it is NOT independent metadata; it is the **timestamp of the status transition**.

---

## 3. Adversarial State Construction

### State 1: `status='active'`, `valid_until` in the past

```
id=1, authority=JAMB, identifier=01001, status='active', valid_from=2020-01-01, valid_until=2023-06-15
```

| Aspect | Analysis |
|--------|----------|
| **Partial unique index** | This record IS constrained by `WHERE status = 'active'`. It occupies the uniqueness slot. |
| **Domain interpretation** | Is this identifier active or expired? The status says "active" but the validity period ended 3 years ago. **Two contradictory answers.** |
| **Import matching** | An import pipeline that matches on `WHERE status = 'active'` will match this record — and apply data to an entity whose identifier has actually lapsed. |
| **Business impact** | An institution whose JAMB code expired 3 years ago would still receive data imports matched to it. Stale entity gets updated. |
| **Severity** | **HIGH** — produces incorrect data matching |

### State 2: `status='retired'`, `valid_until=NULL`

```
id=1, authority=JAMB, identifier=01001, status='retired', valid_from=2020-01-01, valid_until=NULL
```

| Aspect | Analysis |
|--------|----------|
| **Partial unique index** | Not constrained (status ≠ 'active'). A new active record for the same identifier IS allowed. |
| **Domain interpretation** | Retired but no end date. The ADR-DL1 says `valid_until=NULL` means "still valid or unknown." This directly contradicts `status='retired'`. |
| **Temporal gap** | If this identifier is later reassigned (INV-EI3), the new record has a `valid_from` but the old record has no `valid_until`. There is no way to determine whether the reassignment overlapped with the old assignment. **The audit trail is broken.** |
| **Business impact** | Historical queries ("when was this code retired?") return no answer. Regulatory reporting fails. |
| **Severity** | **HIGH** — breaks audit trail and temporal ordering |

### State 3: `status='superseded'`, `valid_until` in the future

```
id=1, authority=JAMB, identifier=01001, status='superseded', valid_from=2020-01-01, valid_until=2027-12-31
id=2, authority=JAMB, identifier=01002, status='active',    valid_from=2026-01-01, valid_until=NULL
```

| Aspect | Analysis |
|--------|----------|
| **Domain interpretation** | "Superseded" means a new identifier has replaced this one. But the old identifier's validity period hasn't ended yet. During 2026-01-01 to 2027-12-31, which identifier is authoritative? |
| **Real-world scenario** | JAMB transitions codes over an admission cycle. Old code accepted until December, new code active from January. This is a **legitimate use case** that the schema cannot express correctly because `status='superseded'` implies the identifier is no longer authoritative, but `valid_until` in the future implies it still is. |
| **Business impact** | During the overlap period, import matching is ambiguous. Two JAMB codes could both match incoming data. |
| **Severity** | **MEDIUM** — reveals a real use case (transition periods) that the model cannot handle |

### State 4: `status='active'`, `valid_from` in the future

```
id=1, authority=JAMB, identifier=01001, status='active', valid_from=2027-01-01, valid_until=NULL
```

| Aspect | Analysis |
|--------|----------|
| **Partial unique index** | This record IS constrained by `WHERE status = 'active'`. It occupies the uniqueness slot NOW for an identifier that won't be valid until next year. |
| **Domain interpretation** | Active but not yet valid. No other entity can claim this identifier in the interim — even though it isn't in use yet. |
| **Business impact** | Prevents legitimate use of the identifier by another entity during the pre-valid period. The uniqueness constraint fires prematurely. |
| **Severity** | **MEDIUM** — incorrect uniqueness enforcement window |

### State 5: Retired identifier later reused by same authority

```
-- Original assignment (institution A)
id=1, authority=JAMB, identifier=01001, entity_type='institution', entity_id=42,
     status='retired', valid_from=2020-01-01, valid_until=2024-06-01

-- Reassignment to institution B (JAMB reuses codes)
id=2, authority=JAMB, identifier=01001, entity_type='institution', entity_id=87,
     status='active', valid_from=2024-06-01, valid_until=NULL
```

| Aspect | Analysis |
|--------|----------|
| **Partial unique index** | Works correctly. Record 1 is excluded (status='retired'). Record 2 is constrained (status='active'). No conflict. |
| **Temporal continuity** | `valid_until` of record 1 = `valid_from` of record 2. Clean handoff. **This is the ONLY adversarial state that works correctly**, and it works precisely because both columns are correctly coupled. |
| **But if coupling breaks** | If record 1 has `valid_until=NULL` (State 2), we cannot verify the handoff. If record 2 has `valid_from` before record 1's `valid_until`, we have an overlap. |
| **Severity** | **PASS** — but only when invariants are maintained |

### State 6: Identifier reassigned from institution A to institution B (JAMB reassigns codes)

```
-- Before reassignment
id=1, authority=JAMB, identifier=01001, entity_id=42 (Institution A), status='active'

-- After reassignment
id=1, status='retired', valid_until=NOW()
id=2, authority=JAMB, identifier=01001, entity_id=87 (Institution B), status='active', valid_from=NOW()
```

| Aspect | Analysis |
|--------|----------|
| **Uniqueness** | Works: partial index only constrains status='active'. |
| **Audit trail** | Both records preserved. Correct. |
| **Temporal gap risk** | If the admin sets `status='retired'` but forgets `valid_until` (State 2), or sets `valid_until` but forgets `status` (State 1), the reassignment is semantically broken. |
| **Application-level risk** | The `RetireExternalIdentifier` Action sets both simultaneously — but raw SQL, migration scripts, or admin UI bugs can set one without the other. |
| **Severity** | **MEDIUM** — works in happy path, fragile at the application boundary |

### State 7: Institution merge — A merges into B

```
-- Before merge: A has JAMB/01001, B has JAMB/02002
id=1, entity_id=A, identifier=01001, status='active'
id=2, entity_id=B, identifier=02002, status='active'

-- After merge (per design)
id=1, entity_id=A, identifier=01001, status='retired', valid_until=merge_date
id=2, entity_id=B, identifier=02002, status='active'  -- B survives
id=3, entity_id=B, identifier=03003, status='active'  -- new merged JAMB code (if assigned)
```

| Aspect | Analysis |
|--------|----------|
| **What if JAMB does NOT assign a new code?** | The merged institution B has its original code 02002. A's code 01001 is retired. No active identifier from JAMB for A's legacy. This is correct — the merged entity IS B. |
| **What if merge operation only sets `status` without `valid_until`?** | State 2 — A's identifier is retired but no end date. Audit trail broken. |
| **What if merge operation only sets `valid_until` without `status`?** | State 1 — A's identifier is "active" with an expired validity period. The partial index still considers it active. B cannot claim A's code. **The merge is blocked by the uniqueness constraint.** |
| **Severity** | **HIGH** — incorrect partial-update ordering can deadlock the merge operation |

### State 8: Institution split — A splits into B and C

```
-- Before split: A has JAMB/01001
id=1, entity_id=A, identifier=01001, status='active'

-- After split (per design)
id=1, entity_id=A, identifier=01001, status='active'  -- A keeps its identifier
id=2, entity_id=B, identifier=02002, status='active'  -- new code for B
id=3, entity_id=C, identifier=02003, status='active'  -- new code for C
```

| Aspect | Analysis |
|--------|----------|
| **What if JAMB retires A's code and assigns new codes to B and C?** | A's identifier must be retired. But A might still exist (e.g., as a holding entity). This requires: `id=1, status='retired', valid_until=split_date`. Then A needs a new identifier if it survives, or A is itself retired. |
| **What if A's identifier should transfer to B (the primary successor)?** | This is identifier reassignment (State 6), not a special case. The same coupling risks apply. |
| **The design says split is "rare and manual"** | Manual operations are EXACTLY where coupling invariants break — humans forget to set both columns. |
| **Severity** | **MEDIUM** — the model supports the happy path, but manual operations increase the probability of States 1-4 |

---

## 4. Are `status` and `valid_from`/`valid_until` Independent or Overlapping?

**Verdict: OVERLAPPING — they represent the same lifecycle concept through different mechanisms.**

| Concept | `status` Expression | `valid_from`/`valid_until` Expression |
|---------|---------------------|---------------------------------------|
| Identifier is currently in use | `status = 'active'` | `valid_from <= NOW() AND valid_until IS NULL` |
| Identifier was retired | `status = 'retired'` | `valid_until IS NOT NULL AND valid_until <= NOW()` |
| Identifier was superseded | `status = 'superseded'` | `valid_until IS NOT NULL AND valid_until <= NOW()` (same as retired — temporal interval CANNOT distinguish these) |

The temporal interval **cannot** distinguish retired from superseded. This is the ADR-DL1's correct argument for keeping `status`. But `status` **already implies** what `valid_until` should be, making `valid_until` redundant for lifecycle queries.

**The relationship is:**
- `status` → **discrete lifecycle state** (the "what")
- `valid_until` → **timestamp of the last state transition** (the "when")
- `valid_from` → **timestamp of the initial state** (immutable per Q18)

`valid_until` is NOT an independent validity window — it is the **timestamp complement of status**. Setting `status='retired'` without setting `valid_until` is like recording an event type without recording when it happened. Setting `valid_until` without changing `status` is like recording when something happened without recording what happened.

---

## 5. Required Invariants

The current schema enforces only INV-EI1 and INV-EI2 (uniqueness). The following invariants are **missing but required**:

### INV-EI5: Status-temporal coupling

```sql
-- An active identifier has no end date
CHECK (
  status = 'active' AND valid_until IS NULL
  OR
  status IN ('retired', 'superseded') AND valid_until IS NOT NULL
)
```

**Rationale:** If the identifier is active, its validity period is open. If retired or superseded, the transition has a timestamp. This eliminates States 1 and 2.

### INV-EI6: No future-dated active identifiers

```sql
-- An active identifier's valid_from must be <= NOW()
-- (Cannot be enforced as a CHECK constraint since NOW() is not immutable in PostgreSQL)
-- Enforced at application layer in RegisterExternalIdentifier Action
```

**Rationale:** Eliminates State 4. Note: PostgreSQL CHECK constraints with NOW() are evaluated at INSERT/UPDATE time and WOULD work initially, but could become stale. Application-layer enforcement is preferred.

### INV-EI7: valid_until chronological ordering

```sql
-- valid_until, if set, must be after valid_from
CHECK (valid_until IS NULL OR valid_until > valid_from)
```

**Rationale:** Prevents zero-length or inverted validity periods.

### INV-EI8: Supersession chain integrity

```sql
-- If status = 'superseded', there MUST exist another active identifier
-- for the same (entity, authority, identifier_type)
-- (Cannot be enforced as a CHECK constraint — requires cross-row validation)
-- Enforced at application layer in SupersedeExternalIdentifier Action
```

**Rationale:** "Superseded" means "replaced by a new identifier." If no replacement exists, the correct status is "retired," not "superseded." Prevents orphaned superseded records.

### INV-EI9: Reassignment temporal continuity (soft)

```
-- When identifier X is reassigned from entity A to entity B:
-- A's record: valid_until <= B's record: valid_from
-- (Cannot be enforced as a CHECK constraint — requires cross-row validation)
-- Enforced at application layer; validated by RetireExternalIdentifier Action
```

**Rationale:** Prevents overlap periods where the same identifier is active for two entities. The partial unique index prevents simultaneous active claims, but if status updates are applied in the wrong order (A's status set to retired AFTER B's active record is created), there's a brief window where the uniqueness constraint could fail on B's insert.

---

## 6. Is the Partial Unique Index on `status='active'` Sufficient?

**No. It is sufficient for INV-EI1 and INV-EI2 (uniqueness), but insufficient for INV-EI5 through INV-EI9 (semantic coupling).**

| Invariant | Enforced By | Current | Required |
|-----------|-------------|---------|----------|
| INV-EI1: One active entity per (authority, type, identifier) | Partial unique index | ✅ | ✅ |
| INV-EI2: One active identifier per (entity, authority, type) | Partial unique index | ✅ | ✅ |
| INV-EI3: Reassignment after explicit retirement | Partial unique index + application logic | ✅ | ✅ |
| INV-EI4: Historical retention | Application policy + CASCADE | ✅ | ✅ |
| **INV-EI5: Status-temporal coupling** | **CHECK constraint** | **❌** | **✅** |
| **INV-EI6: No future-dated active identifiers** | **Application logic** | **❌** | **✅** |
| **INV-EI7: Chronological ordering** | **CHECK constraint** | **❌** | **✅** |
| **INV-EI8: Supersession chain integrity** | **Application logic** | **❌** | **✅** |
| **INV-EI9: Reassignment temporal continuity** | **Application logic** | **❌** | **✅ (soft)** |

---

## 7. What Happens When Status Changes Without valid_until (or Vice Versa)?

| Mutation | Result | Adversarial State | Impact |
|----------|--------|-------------------|--------|
| `status` changed to 'retired', `valid_until` NOT set | Record is retired but appears to have no end date | **State 2** | Audit trail broken; temporal ordering of reassignment lost |
| `valid_until` set to past, `status` NOT changed | Record is "active" with expired validity | **State 1** | Stale entity receives import matches; data corruption |
| `status` changed to 'superseded', `valid_until` NOT set | Superseded with no transition timestamp | **State 2** variant | Cannot determine when supersession occurred |
| `valid_until` set to future, `status` NOT changed | Active record with future end date | Subtle variant | Appears active now but will "silently" expire without status change |
| `status` changed to 'active', `valid_from` set to future | Active but not yet valid | **State 4** | Occupies uniqueness slot prematurely |

**The key insight:** Every status change MUST be accompanied by a corresponding `valid_until` update, and vice versa. They are not independently meaningful — they are two projections of the same event. The schema currently allows them to be mutated independently, which is the root cause of all eight adversarial states.

---

## 8. Recommendation

### The model should be simplified by making `valid_until` a **status transition timestamp**, not an independent temporal interval endpoint.

**Proposed schema amendment:**

```sql
CREATE TABLE external_identifiers (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entity_type     VARCHAR(255) NOT NULL,
  entity_id       BIGINT NOT NULL,
  authority_id    BIGINT NOT NULL,
  identifier_type VARCHAR(100) NOT NULL,
  identifier      VARCHAR(255) NOT NULL,
  status          VARCHAR(50) NOT NULL DEFAULT 'active',
  valid_from      TIMESTAMP NOT NULL DEFAULT NOW(),  -- IMMUTABLE: when authority assigned this code
  valid_until     TIMESTAMP,                          -- Timestamp of status transition to retired/superseded
  source_id       BIGINT,
  metadata        JSONB,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),

  -- INV-EI5: status-temporal coupling
  CONSTRAINT chk_ei_status_temporal CHECK (
    (status = 'active' AND valid_until IS NULL) OR
    (status IN ('retired', 'superseded') AND valid_until IS NOT NULL)
  ),

  -- INV-EI7: chronological ordering
  CONSTRAINT chk_ei_chronology CHECK (
    valid_until IS NULL OR valid_until > valid_from
  )
);

-- INV-EI1: One active entity per (authority, type, identifier)
CREATE UNIQUE INDEX ext_ident_authority_unique
  ON external_identifiers (authority_id, identifier_type, identifier)
  WHERE status = 'active';

-- INV-EI2: One active identifier per entity per authority per type
CREATE UNIQUE INDEX ext_ident_entity_unique
  ON external_identifiers (entity_type, entity_id, authority_id, identifier_type)
  WHERE status = 'active';
```

**Application-layer invariants (enforced in Actions, not CHECK constraints):**

| Action | Invariant Enforced |
|--------|-------------------|
| `RegisterExternalIdentifier` | INV-EI6: `valid_from <= NOW()` |
| `RetireExternalIdentifier` | INV-EI5: sets both `status='retired'` and `valid_until=NOW()` atomically |
| `SupersedeExternalIdentifier` | INV-EI5 + INV-EI8: sets both `status='superseded'` and `valid_until=NOW()` on old record; creates new active record for same entity |

**Domain Actions must use DB transactions:**

```php
// RetireExternalIdentifier — ATOMIC
DB::transaction(function () use ($identifier) {
    $identifier->update([
        'status'      => 'retired',
        'valid_until' => now(),
    ]);
    // Activity log entry created within same transaction
});
```

### Why this is a simplification, not a complication:

1. **Eliminates 4 of 8 adversarial states at the schema level** (States 1, 2, 3, and the variant of State 4 involving inverted chronology) via CHECK constraints
2. **Makes `valid_until` semantics explicit**: it is `retired_at` / `superseded_at`, NOT an independent validity window
3. **No schema migration impact**: the CHECK constraints are additive and non-breaking on existing data (assuming existing data already satisfies them, which it must if the Actions are correct)
4. **The ADR-DL1's stated intent is preserved**: status remains the primary active indicator; temporal columns remain as metadata; but now the "metadata" is **guaranteed consistent** with the status

### What this does NOT address (intentionally deferred):

1. **Transition periods** (State 3 legitimate use case): When JAMB accepts both old and new codes during an admission cycle overlap, the current model cannot express this. A future enhancement could add `grace_period_until TIMESTAMP` or a `transitioning` status. For MVP, the CHECK constraint forces a clean cutover — no overlap. This is acceptable because JAMB code changes are admin-initiated and can be timed precisely.

2. **Future-dated identifiers** (State 4): INV-EI6 is application-enforced because PostgreSQL CHECK with NOW() is a mutable evaluation. The `RegisterExternalIdentifier` Action must reject `valid_from > NOW()`.

3. **Entity split identifier reassignment**: The current "manual admin work" approach is retained. Split is rare. The coupling invariants protect the admin from creating States 1-4.

---

## 9. Summary

| Finding | Severity | Resolution |
|---------|----------|------------|
| `status` and `valid_until` are independently mutable but semantically coupled | **HIGH** | Add CHECK constraint INV-EI5 |
| State 1 (active + past valid_until) causes incorrect import matching | **HIGH** | Eliminated by INV-EI5 |
| State 2 (retired + NULL valid_until) breaks audit trail | **HIGH** | Eliminated by INV-EI5 |
| State 4 (active + future valid_from) causes premature uniqueness lock | **MEDIUM** | Application-enforced INV-EI6 |
| State 3 (superseded + future valid_until) reveals transition period gap | **MEDIUM** | Deferred to future enhancement |
| No CHECK constraint prevents inverted chronology | **MEDIUM** | Add CHECK constraint INV-EI7 |
| Superseded status has no cross-row integrity check | **LOW** | Application-enforced INV-EI8 |
| ADR-DL1 Section 3.2 claim that "status=retired + valid_to=NULL is unambiguous" is WRONG | **HIGH** | The claim is that status makes it unambiguous, but valid_until=NULL for a retired record means "we don't know when it was retired" — this IS ambiguous for audit and temporal ordering |

**Bottom line:** The `status` column is the correct design choice over `valid_to IS NULL` for active detection. But adding `status` without coupling it to `valid_until` via CHECK constraints creates a **dual-source-of-truth** defect. The fix is two CHECK constraints (INV-EI5, INV-EI7) and one application invariant (INV-EI6). This is additive, non-breaking, and preserves all existing design decisions.
