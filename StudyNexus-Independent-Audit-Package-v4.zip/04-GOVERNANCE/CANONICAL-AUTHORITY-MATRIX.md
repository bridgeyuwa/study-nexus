# Canonical Authority Matrix

**Date:** 2026-03-04  
**Purpose:** Define which document is authoritative for each category of concern, establishing clear governance to resolve contradictions.

---

## Governing Principle

> **When 05-implementation.md contradicts 03-domain.md on a DOMAIN concept (entity, value object, enum, lifecycle, event, action, invariant, relationship), 03-domain.md is authoritative.** 05-implementation.md governs only implementation details (table column types, index strategies, migration ordering, framework-specific patterns) that do not redefine domain semantics.

This principle derives from the document hierarchy established in 02-decisions.md: the domain model is the canonical expression of the problem space; the implementation blueprint is a projection of that model into a specific technology stack.

---

## Authority Assignments

### Tier 1: Primary Authority (Single Document Governs)

| Category | Authority | Rationale |
|----------|-----------|-----------|
| **Business vision, users, goals** | 01-business.md | Primary business discovery document. Defines who the system serves and what problems it solves. |
| **Architectural decisions (ADRs)** | 02-decisions.md | Consolidated decision log. All decisions flow through ADRs recorded here. |
| **Domain entities** | 03-domain.md | Canonical domain model. Defines entity identity, lifecycle, relationships, invariants. |
| **Domain value objects** | 03-domain.md | Canonical domain model. Defines VO structure, equality semantics, composition. |
| **Domain enums** | 03-domain.md | Canonical domain model. Defines enumeration values and their domain meaning. |
| **Domain events** | 03-domain.md | Canonical domain model. Defines event names, payloads, and what they signify in the domain. |
| **Domain actions (use cases)** | 03-domain.md | Canonical domain model. Defines operation names, preconditions, effects. |
| **Domain invariants & rules** | 03-domain.md | Canonical domain model. Defines business rules that must always hold. |
| **Domain relationships** | 03-domain.md | Canonical domain model. Defines aggregate boundaries, ownership, references. |
| **Architecture principles** | 04-architecture.md | Architecture consolidation. Defines system-level principles (P1-P12). |
| **Persistence architecture** | 04-architecture.md | Defines ORM strategy, aggregate persistence, projection patterns. |
| **Search architecture** | 04-architecture.md | Defines search engine choice, projection model, indexing strategy. |
| **RBAC model** | 04-architecture.md | Defines role structure, permissions, scoping. (Validated against 02-decisions.md ADRs.) |
| **Versioning model** | 04-architecture.md | Defines how entity versioning and publication work at architecture level. |
| **Data acquisition pipeline** | 06-data-acquisition.md | Defines import adapters, verification engine, batch processing. |
| **UX behavior & interactions** | FIRST-VERTICAL-SLICE-UX.md | UX specification. Defines user-facing behavior. |
| **UI visual design** | FIRST-VERTICAL-SLICE-UI.md | UI specification. Defines visual design, layout, components. |
| **Product experience** | PRODUCT-EXPERIENCE-ARCHITECTURE.md | Product architecture. Defines cross-cutting product patterns. |

### Tier 2: Subordinate Authority (Governed by Tier 1 for Domain Concepts)

| Category | Authority | Governed By | Rationale |
|----------|-----------|-------------|-----------|
| **Table schemas** | 05-implementation.md | 03-domain.md for domain tables | Implementation blueprint governs column types, indexes, constraints — but entity identity, relationships, and lifecycle columns must match 03-domain.md. |
| **Migration ordering** | 05-implementation.md | — | Pure implementation concern. |
| **Framework patterns** | 05-implementation.md | — | Laravel-specific patterns (Eloquent, Spatie, etc.) are 05's scope. |
| **API route definitions** | 05-implementation.md | 03-domain.md for action names | Routes must map to canonical Actions from 03-domain.md. |
| **Content model tables** | 05-implementation.md | — | Content-layer tables (articles, guides, etc.) are implementation scope, not domain. |
| **Infrastructure tables** | 05-implementation.md | — | Jobs, caches, sessions, etc. are implementation scope. |
| **Auth/engagement tables** | 05-implementation.md | 04-architecture.md for RBAC | Table structure must support the 11-role model from 04-architecture.md. |
| **Typesense collection schemas** | 05-implementation.md | 04-architecture.md for search architecture | Collections must be projections per 04-architecture.md. |

---

## Conflict Resolution Protocol

When a contradiction is found between documents:

### Step 1: Identify the Category
Determine which category the contradiction falls into (Entity, VO, Enum, Action, Event, Schema, etc.).

### Step 2: Check Authority Matrix
Look up the primary authority for that category.

### Step 3: Apply the Rule

| Situation | Resolution |
|-----------|------------|
| 05 contradicts 03 on a domain concept | 03 wins. 05 must be corrected. |
| 05 contradicts 04 on architecture | 04 wins. 05 must be corrected. |
| 05 contradicts 02 on a decision | 02 wins. 05 must be corrected. |
| 05 adds a concept not in 03/04 | Evaluate: if it's implementation-only (content model, infrastructure), 05 is valid. If it changes domain semantics, it requires an ADR in 02-decisions.md. |
| 03 contradicts 04 | Escalate. This should not happen if both are canonical. If it does, 03 governs domain concepts, 04 governs architecture. |
| 02 contradicts 03 | Escalate. 02 governs decisions, 03 governs domain model. If a decision changes the domain, 03 must be updated. |

### Step 4: Classify the Change

| Classification | Meaning | Process |
|----------------|---------|---------|
| **A** | Pure sync correction | Update 05 to match 03/04. No judgment needed. |
| **B** | Clarification | Document the resolution of an ambiguity. No fundamental disagreement. |
| **C** | Architectural decision required | Neither position is clearly wrong. Requires human judgment, possibly a new ADR. |
| **D** | New scope | 05 added something not in 03/04. Needs explicit acceptance (add to 03) or rejection (remove from 05). |

---

## Specific Authority Determinations for Identified Contradictions

| Finding | Category | Authority | Reason |
|---------|----------|-----------|--------|
| F-C01: ScholarshipStatus | Enum | 03-domain.md | Domain lifecycle definition |
| F-C02: InformationSource lifecycle | Entity | 03-domain.md | Domain entity lifecycle |
| F-C03: EligibilityPolicy ownership | Entity | 03-domain.md | Domain relationship |
| F-C04: AdmissionCycle ownership | Entity | 03-domain.md | Domain relationship (C: significant impact, validate) |
| F-C05: AccreditationRecord ownership | Entity | 03-domain.md | Domain relationship (polymorphic) |
| F-C06: InformationSource ownership | Entity | 03-domain.md | Domain aggregate boundary |
| F-C07: Action inventory | Action | 03-domain.md | Domain actions |
| F-H01: InstitutionType | Enum | 03-domain.md | Domain enum values |
| F-H02: AwardLevel | Enum | 03-domain.md | Domain enum definition |
| F-H03: DeliveryMode | Enum | 03-domain.md | Domain enum naming |
| F-H04: PolicyStatus | Enum | 03-domain.md | Domain enum values |
| F-H05: AdmissionPathway | VO | 03-domain.md | Domain VO classification |
| F-H06: ProviderType | Enum | 03-domain.md | Domain enum values |
| F-H07: AuthorityType | Enum | 03-domain.md | Domain enum values |
| F-H08: VO inventory | VO | 03-domain.md | Domain VO definitions |
| F-H09: Event names | Event | 03-domain.md | Domain event definitions |
| F-H10: Scholarship provider | Entity | 03-domain.md | Domain relationship |
| F-H11: Location vs Address | VO | 03-domain.md | Domain VO naming |
| F-H12: MonetaryAmount | VO | 03-domain.md | Domain VO definition |
| F-H13: Missing VOs | VO | 03-domain.md | Domain VO inventory |
| F-H14: New VOs in 05 | VO | 03-domain.md (governs acceptance) | New domain concepts need canonical approval |
| F-M03: Content enums | Enum | 05-implementation.md | Content layer, not domain |
| F-M06: HasProvenance | Provenance | 03-domain.md | Domain provenance model |
| F-M08: 56 tables | Schema | 05-implementation.md | Implementation scope |
| F-M11: morphTo authority | Entity | 03-domain.md | Domain relationship |
| F-M13: OrganizationMember | Schema | 04-architecture.md | RBAC implementation |

---

## Document Dependency Graph

```
01-business.md
    └── 02-decisions.md (ADRs reference business goals)
        ├── 03-domain.md (domain model validates decisions)
        ├── 04-architecture.md (architecture implements decisions)
        │   └── 05-implementation.md (blueprint implements architecture)
        ├── 05-implementation.md (blueprint implements domain model)
        └── 06-data-acquisition.md (pipeline uses domain actions)
```

**Rule:** Information flows DOWN the graph. A lower document never redefines a concept established by a higher document. It can only:
1. Project a domain concept into implementation (e.g., entity → table)
2. Add implementation-only concerns (e.g., indexes, framework patterns)
3. Extend with non-domain concepts (e.g., content model, infrastructure) — but these must be clearly separated from domain projections
