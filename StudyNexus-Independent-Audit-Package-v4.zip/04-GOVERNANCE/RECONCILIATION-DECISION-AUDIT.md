# Reconciliation Decision Audit — Second-Order Analysis

**Date:** 2026-08-10
**Scope:** Second-order decision audit of reconciliation deliverables, with focus on persistence, identity, and hidden decisions
**Status:** ANALYSIS COMPLETE — awaiting human review
**Constraint:** No canonical documents modified. No baseline modified. No code produced.

---

## 1. Primary-Key / Identity Audit

### 1.1 Are canonical entity primary keys defined?

**Partially, with contradictions.**

| Table | 03-domain.md | 05-implementation.md | 06-data-acquisition.md | PRODUCT-EXPERIENCE | Reconciliation deliverable |
|-------|-------------|---------------------|----------------------|-------------------|---------------------------|
| institutions | ❌ unstated | ❌ `id` untyped | N/A | "Institution UUID" (doc ID) | `bigint PK` |
| programmes | ❌ unstated | ❌ `id` untyped; `discipline_id UUID FK` | N/A | "Programme UUID" (doc ID) | `bigint PK` |
| scholarships | ❌ unstated | ❌ `id` untyped | N/A | N/A | `bigint PK` |
| admission_cycles | ❌ unstated | ❌ `id` untyped | N/A | N/A | `bigint PK` |
| information_sources | ❌ unstated | ❌ `id` untyped | N/A | N/A | `bigint PK` |
| disciplines | ✅ `UUID PK` | ❌ `id` untyped | N/A | N/A | `bigint PK` |
| cut_off_marks | ✅ `UUID PK` | ❌ `id` untyped; UUID FKs | N/A | N/A | not addressed |
| import_batches | N/A | N/A | ✅ `UUID PK` | N/A | N/A |
| pending_imports | N/A | N/A | ✅ `UUID PK` | N/A | N/A |
| organization_members | N/A | ✅ `bigint PK` | N/A | N/A | N/A |
| Qualification | "auto-increment PK" | ❌ untyped | N/A | N/A | `bigint PK` |
| ScholarshipProvider | "auto-increment PK" | ❌ untyped | N/A | N/A | `bigint PK` |
| EducationAuthority | "auto-increment PK" | ❌ untyped | N/A | N/A | `bigint PK` |

### 1.2 Is the strategy bigint, UUID, ULID, natural key, or something else?

**There are three conflicting signals across the authoritative documentation:**

1. **03-domain.md** declares UUID PKs for `disciplines` and `cut_off_marks`, UUID FKs in `cut_off_marks`, and "auto-increment PK" for supporting entities. Aggregate root PK types are **unstated**.
2. **06-data-acquisition.md** uses UUID for ALL staging layer IDs and FKs, including `matching_entity_id` (UUID) which references domain entities — implying domain PKs are UUID.
3. **PRODUCT-EXPERIENCE-ARCHITECTURE.md** states Typesense document `id` = "Programme UUID" / "Institution UUID" — confirming UUID at the search layer.
4. **The reconciliation deliverable** (IMPLEMENTATION-MODEL-RECONCILIATION.md) declares `bigint PK` for ALL tables — contradicting signals 1, 2, and 3.
5. **05-implementation.md** leaves `id` type ambiguous for 12 of 13 domain tables; only `organization_members` explicitly says `bigint PK`.

**No ADR exists for PK strategy.** ADR-1 through ADR-18 cover every other architectural decision. This is the single most significant gap in the entire baseline.

### 1.3 Is there a distinction between internal database identity and public-facing identifiers?

**Yes.** The distinction is clear:

- **Internal identity**: Primary key (type ambiguous) — used for FK relationships, internal queries, event payloads.
- **Public-facing identifier**: **Slug** — used for ALL public URLs and route model binding.
  - `/institutions/{institution-slug}`
  - `/institutions/{inst-slug}/programmes/{prog-slug}`
  - `/scholarships/{scholarship-slug}`
  - Content: `/news/{article-slug}`, `/guides/{guide-slug}`, etc.
  - Discipline landing: `/programmes?discipline={slug}`

PK values are never exposed in URLs. Slug changes trigger 301 redirects via `url_redirects` table.

### 1.4 Are external/source identifiers being used as canonical identity anywhere?

**No.** External source codes (JAMB code, NUC code, WAEC number) serve as **natural keys for deduplication during import** (06-data-acquisition.md: exact match → confidence 1.0), but they are NOT stored as PKs. They are matching attributes, not identity columns.

However, whether they are stored as **dedicated columns** on the Institution model (e.g., `jamb_code`, `nuc_code`) is **undefined**. The 05-implementation migration has no such columns. If they are the primary identity matchers for import, they need columns.

### 1.5 How are external acquisition IDs mapped to canonical entities?

Via `pending_imports.matching_entity_id` (UUID, nullable) — links a staged record to an existing domain entity after fuzzy matching. Match confidence thresholds govern auto-merge vs manual review.

**But ADR-18 (Data Ingestion Architecture) is DEFERRED.** The full matching strategy is only designed for institutions. Programme, scholarship, and authority matching strategies are **undefined**.

### 1.6 What IDs are used in foreign keys?

**Contradictory:**

- **cut_off_marks** (03-domain.md): All FKs are UUID (`programme_id UUID`, `admission_cycle_id UUID`, `source_id UUID`).
- **programmes** (05-implementation.md): `discipline_id UUID FK` — but `institution_id` type is unstated.
- **All other FKs** in 05-implementation.md are untyped.
- **Reconciliation deliverable**: All FKs are `bigint`.
- **organization_members** (05-implementation.md): `user_id bigint FK`, `organization_id bigint (morph)`.

If FK targets are UUID, the PKs they reference must also be UUID. But this is never stated. The reconciliation silently converted all FKs to bigint without acknowledging the UUID FKs in 03-domain.md.

### 1.7 What IDs are used as Typesense document IDs?

**UUID (as string).** PRODUCT-EXPERIENCE-ARCHITECTURE.md explicitly states: document `id` = "Programme UUID" / "Institution UUID", typed as `string`. Slug is carried as a separate field for URL construction.

If the PK strategy changes to bigint, Typesense document IDs must change accordingly, and the PRODUCT-EXPERIENCE-ARCHITECTURE.md document must be updated.

### 1.8 Does supersession/versioning depend on identity?

**Yes.** Policy supersession (Draft → Published → Superseded) is identity-dependent: the "one active per cycle" invariant requires that the system can distinguish which policy instance is the current one. If policies are immutable (append-only), identity is the only way to track the chain. See Section 3.3 below.

### 1.9 Would changing the PK strategy require changes to...?

**Yes — to ALL of these:**

| Affected Area | If PK changes from UUID → bigint | If PK changes from bigint → UUID |
|---------------|----------------------------------|----------------------------------|
| Domain model | Update event payloads (sourceId type) | Update event payloads |
| Implementation blueprint | Re-type all `id` columns; re-type FK columns | Re-type all `id` columns; re-type FK columns |
| Migrations | Every migration file regenerated | Every migration file regenerated |
| Relationships | All FK declarations change type | All FK declarations change type |
| Imports | `matching_entity_id` in pending_imports changes type | `import_batches.id` and `pending_imports.id` must align |
| Typesense projections | Document IDs change from UUID to bigint string | Document IDs change |
| URLs/slugs | Not affected (slug-based) | Not affected (slug-based) |
| Tests | All factory IDs, assertions, FK references | All factory IDs, assertions, FK references |
| Polymorphic morph IDs | `governable_id`, `accreditable_id` change type | Same |

### 1.10 Does any of the 45 proposed reconciliation changes implicitly assume a particular PK strategy?

**Yes.** The IMPLEMENTATION-MODEL-RECONCILIATION.md assumes `bigint PK` everywhere without debate. Changes that add or modify FK columns (Changes 4, 5, 6, 27, 31, 32, 38) all specify `bigint FK`. Change 5 (AccreditationRecord polymorphic) specifies `accreditable_id bigint (morph)`. These changes are **written assuming bigint** — they would need rework if the PK strategy is UUID.

### 1.11 Primary-Key Status

> ## **OPEN DECISION — IMPLEMENTATION BLOCKER**
>
> **No ADR governs PK type.** Three documents signal UUID; the reconciliation deliverable assumes bigint. The 45 proposed changes assume bigint. This decision affects every migration, every FK, every Typesense document, and every import mapping. It must be resolved before any migration can be written.

---

## 2. Audit of the Four D Decisions

### D1 — AdmissionCycle Ownership

| Aspect | Detail |
|--------|--------|
| **What is unresolved** | Does AdmissionCycle belong to EducationAuthority (03-domain.md) or Institution (05-implementation.md)? |
| **03-domain.md position** | `AdmissionCycle belongsTo EducationAuthority`. An admission cycle is defined by an education authority (e.g., JAMB defines the national UTME cycle). Method: `announce(period, authorityId, phaseSequence, startDate, endDate)`. |
| **05-implementation.md position** | `AdmissionCycle belongsTo Institution` via `institution_id FK`. Cycles are per-institution. |
| **Downstream consequences** | **Schema**: If EducationAuthority, FK is `education_authority_id`; if Institution, FK is `institution_id`. **RBAC**: If EducationAuthority, cycle management requires platform-level or authority-scoped admin. If Institution, institution-scoped admins manage cycles. **UX**: Current UX assumes institution-scoped cycle management. **Search**: Typesense programme document denormalizes cycle state; the authority vs institution ownership changes what data is available for denormalization. **Import**: JAMB imports create authority-scoped cycles; institution imports create institution-scoped cycles. |
| **Proposed classification** | C (architectural decision required) |
| **Is the classification correct?** | **Yes.** This is not a mechanical sync — it has real product implications. An EducationAuthority-scoped cycle models the Nigerian regulatory reality (JAMB defines the national cycle). An Institution-scoped cycle models institution-level admission windows. Both are valid in different contexts. |
| **Can it be resolved mechanically from existing authoritative material?** | **No.** 03-domain.md is clear (EducationAuthority), but the UX was designed assuming institution-scoped cycles. Resolving this requires deciding whether the UX or the domain model governs on this specific point. |
| **Does it require a human product/domain decision?** | **Yes.** The question is: "In Nigeria, are admission cycles defined by JAMB (authority) or by individual institutions?" The answer is **both** — JAMB defines the national UTME window, but institutions define their own Post-UTME and Direct Entry windows. The domain model may need to accommodate both, which is a product decision. |

### D2 — InformationSource Ownership

| Aspect | Detail |
|--------|--------|
| **What is unresolved** | Is InformationSource a standalone aggregate (03-domain.md) or owned by Institution (05-implementation.md)? |
| **03-domain.md position** | InformationSource is a standalone aggregate root. Referenced by Institution/Programme/AdmissionPolicy via `information_source_id` (nullable FK). Lifecycle: Registered → Verified ↔ Unreliable → Deprecated. |
| **05-implementation.md position** | `InformationSource belongsTo Institution` via `institution_id FK`. Sources are per-institution. |
| **Downstream consequences** | **Schema**: If standalone, `information_sources` has no `institution_id`; entities have `information_source_id` FK. If institution-owned, `information_sources` has `institution_id`; entities don't need a separate FK. **Provenance**: Standalone sources enable cross-entity provenance — the same source can provide data to multiple institutions/programmes. Institution-owned sources limit provenance to one institution. **Trust signal**: Standalone enables global trust computation per source. Institution-owned limits trust to institutional scope. **Admin UX**: Standalone sources are managed in a global registry. Institution-owned sources are managed within each institution's admin. **Import**: External sources (JAMB, NUC) serve ALL institutions. If institution-owned, the same JAMB source must be duplicated for every institution that references it. |
| **Proposed classification** | C (architectural decision required) |
| **Is the classification correct?** | **Borderline A/C.** 03-domain.md's position is strongly justified: JAMB and NUC are sources that provide data across ALL institutions. Duplicating them per-institution is clearly wrong for the Nigerian data model. However, there is a legitimate question about whether institution-specific sources (e.g., a particular university's website) should be modeled differently from global sources. |
| **Can it be resolved mechanically from existing authoritative material?** | **Mostly yes.** 03-domain.md's standalone model is the correct position for the Nigerian regulatory context. The only question is whether to ALSO support institution-scoped source references (which is an extension, not a contradiction). |
| **Does it require a human product/domain decision?** | **No, not really.** The domain model is correct. 05-implementation.md's institution-owned model is a pragmatic simplification that breaks provenance. The decision should default to 03-domain.md. However, because the reconciliation classified it as C, it should be explicitly confirmed. |

### D3 — Scholarship Provider Relationship

| Aspect | Detail |
|--------|--------|
| **What is unresolved** | Is Scholarship→Provider a direct FK to ScholarshipProvider (03-domain.md) or a polymorphic morphTo (05-implementation.md)? |
| **03-domain.md position** | `Scholarship belongsTo ScholarshipProvider` via `scholarship_provider_id FK`. INV-S1: "A Scholarship has exactly one Provider." ProviderType enum: Government, Corporate, NGO, Institution. |
| **05-implementation.md position** | `Scholarship morphTo provider` (provider_type + provider_id). This allows a Scholarship's provider to be either a ScholarshipProvider OR an Institution. |
| **Downstream consequences** | **Schema**: Direct FK = `scholarship_provider_id bigint/UUID`. Polymorphic = `provider_type string + provider_id bigint/UUID`. **Invariant INV-S1**: With direct FK, INV-S1 is trivially enforced by the FK constraint. With polymorphic, INV-S1 is loosened — a Scholarship can have a provider of any morph type, and "exactly one" is enforced by the morph columns, but the PROVIDER must be a ScholarshipProvider specifically. If an Institution is the provider via morph,=, that contradicts INV-S1 as defined. **Admin UX**: Direct FK = simple dropdown of ScholarshipProviders. Polymorphic = dual selection (type + entity). **Import**: Direct FK = scholarship imports reference a provider. Polymorphic = scholarship imports must determine if the provider is a ScholarshipProvider or Institution. |
| **Proposed classification** | C (architectural decision required) |
| **Is the classification correct?** | **Yes.** There is a legitimate question: Can an Institution directly offer scholarships without creating a ScholarshipProvider record? 03-domain.md says no (INV-S1 enforces ScholarshipProvider). But in practice, universities do offer their own scholarships, and forcing them to also have a ScholarshipProvider record (of type Institution) adds a step. |
| **Can it be resolved mechanically from existing authoritative material?** | **No.** 03-domain.md already considered this and chose direct FK. The question is whether that decision should be revisited. |
| **Does it require a human product/domain decision?** | **Yes.** The trade-off is: simpler schema + stronger invariant (direct FK) vs. flexibility for institutions to be direct scholarship providers (polymorphic). 03-domain.md chose simplicity; 05-implementation.md chose flexibility. Both are defensible. |

### D4 — AccreditationRecord Authority Relationship

| Aspect | Detail |
|--------|--------|
| **What is unresolved** | Is AccreditationRecord→authority a direct FK to EducationAuthority (03-domain.md) or a polymorphic morphTo (05-implementation.md)? |
| **03-domain.md position** | `AccreditationRecord belongsTo EducationAuthority` via `education_authority_id FK`. The authority that granted the accreditation. INV-2: "Granted by exactly one Education Authority." |
| **05-implementation.md position** | `AccreditationRecord morphTo authority` (authority_type + authority_id). Allows any entity type to be the accrediting authority. |
| **Downstream consequences** | **Schema**: Direct FK = `education_authority_id`. Polymorphic = `authority_type + authority_id`. **Invariant INV-2**: With direct FK, "exactly one Education Authority" is enforced by FK. With polymorphic, any entity can be an authority, which contradicts INV-2. **Domain correctness**: In Nigeria, NUC accredits universities, NBTE accredits polytechnics. These are EducationAuthority entities. Allowing arbitrary entity types as accrediting authorities has no current use case. **Future extensibility**: A polymorphic relationship could allow international accreditation bodies (ABET, QAA) that are not yet EducationAuthority entities — but these SHOULD be EducationAuthority entities per the domain model. |
| **Proposed classification** | C (architectural decision required) |
| **Is the classification correct?** | **Borderline A/C.** 03-domain.md's position is strongly justified: accrediting authorities ARE EducationAuthority entities by definition. A polymorphic relationship here adds flexibility with no current use case and weakens INV-2. This is closer to a sync correction (A) than a true architectural decision. |
| **Can it be resolved mechanically from existing authoritative material?** | **Mostly yes.** 03-domain.md defines INV-2 explicitly: "granted by exactly one Education Authority." The polymorphic option contradicts this invariant. The mechanical resolution is direct FK. |
| **Does it require a human product/domain decision?** | **No, not really.** The domain model is clear. The polymorphic option should be rejected unless someone presents a concrete use case where a non-EducationAuthority entity grants accreditation — which would be a new scope item (D). |

---

## 3. Hidden Decisions

### HD-1: Polymorphic Morph Type String Values — **CRITICAL**

**What's unresolved:** Are morph type strings fully qualified class names (`App\Domain\Models\Institution`) or short aliases (`institution`, `programme`)?

**Why it matters:** These values are written into the database at creation time. Two developers using different conventions produce incompatible data. Queries, Typesense indexing, and pivot lookups all break.

**Evidence:** 05-implementation.md shows short strings for OrganizationMember (`'institution'`). 04-architecture.md shows FQCN (`App\Domain\Models\Institution`). No `Relation::enforceMorphMap()` configuration is specified.

**Classification:** Implementation blocker. Must be decided before first migration.

---

### HD-2: AdmissionPolicy Polymorphic Schema — **CRITICAL**

**What's unresolved:** Does an Institution-level AdmissionPolicy have the exact same columns as a Programme-level one? ADR-11 says "identical structure" but this is asserted, not justified. The uniqueness constraint formulation `(governable_type, governable_id, admission_cycle_id) WHERE status = 'Published'` requires a PostgreSQL partial unique index, which is not documented.

**Why it matters:** The migration, model, and invariant enforcement all depend on this.

**Classification:** Implementation blocker. Must be decided before AdmissionPolicy migration.

---

### HD-3: AdmissionCycle Phase Storage — **CRITICAL**

**What's unresolved:** Where is PhaseSequence stored? Where is `current_phase` stored? Are phase dates in the PhaseSequence JSON column or as separate timestamp columns (`opens_at`, `closes_at`, `results_at`)?

**Evidence:** 03-domain.md defines PhaseSequence as a VO (JSON cast). 05-implementation.md has `opens_at`, `closes_at`, `results_at` as separate columns with no PhaseSequence or `current_phase` column.

**Why it matters:** The migration schema is materially different. JSON column vs 3+ timestamp columns changes how `advancePhase()` works, how phase dates are queried, and how the admin UI presents phase management.

**Classification:** Implementation blocker. Must be decided before AdmissionCycle migration.

---

### HD-4: Deletion Cascade Strategy — **HIGH**

**What's unresolved:** What happens when an entity is hard-deleted from the database (not domain-closed, but admin-deleted)? No document defines FK `ON DELETE` behavior for the core domain relationships.

**Evidence:** 05-implementation.md defines `ON DELETE CASCADE` for `@cut_off_marks` and `nullOnDelete` for `articles.institution_id`. All other FKs have no cascade rule. The domain model only defines domain-level "close" operations, not data-level deletion.

**Why it matters:** Without explicit rules, a developer will choose arbitrarily. `RESTRICT` everywhere breaks admin workflows. `CASCADE` everywhere loses data. No constraints risks referential integrity.

**Classification:** Must be decided before migrations are written. Affects every FK declaration.

---

### HD-5: Import Identity Mapping — **HIGH**

**What's unresolved:** ADR-18 (Data Ingestion) is DEFERRED, but 06-data-acquisition.md specifies a full pipeline. Programme, scholarship, and authority matching strategies are undefined. The `registrationIdentifier` from 03-domain.md's `establish()` method has no column in the migration schema.

**Why it matters:** Without identity matching, the first JAMB import creates duplicate institutions. The `matching_entity_id` FK type depends on PK strategy. This is the platform's primary data source.

**Classification:** Must be decided before Phase 1b (domain layer). Cannot defer if the import pipeline is to be functional.

---

### HD-6: TrustSignal Algorithm — **HIGH**

**What's unresolved:** What is the TrustSignal computation? "Derived from source verification status and provenance metadata" is a description, not a formula. No document defines the output type (score? grade? boolean?) or the algorithm.

**Why it matters:** Trust signal is a key UX feature. Without an algorithm, a developer will either implement a trivial boolean (useless) or over-engineer a Bayesian system (wasteful).

**Classification:** Must be decided before Phase 1d (public site). Affects how data quality is displayed to users.

---

### HD-7: Soft Deletes Policy — **MEDIUM**

**What's unresolved:** Zero mentions of `deleted_at`, `SoftDeletes`, or soft deletes in any document. The domain uses explicit status-based lifecycle (Closed, Discontinued, Withdrawn, Deprecated). But content entities, user accounts, and pivot records may need different deletion behavior.

**Why it matters:** Adding SoftDeletes where not intended breaks FK constraints and query assumptions. Not adding it where needed loses data recovery.

**Classification:** Should be decided before migrations. Not a day-1 blocker but affects migration design.

---

### HD-8: Supersession Mechanics — **MEDIUM**

**What's unresolved:** How does policy supersession work mechanically? Is there a `superseded_by_id` FK? Is it purely status-based? How is the "one Published per (owner, cycle)" invariant enforced — partial unique index, application-level, or both? What about concurrent publishes?

**Why it matters:** Two developers build different concurrency models and data structures for the policy chain.

**Classification:** Should be decided before AdmissionPolicy implementation. Partial unique index vs application-only enforcement changes migration design.

---

### HD-9: Slug Lifecycle — **MEDIUM**

**What's unresolved:** Are slugs human-editable? What happens on collision? What happens when `rename()` is called — does the slug change? If so, `url_redirects` entry logic is needed. What about programme reassignment (InstitutionMerger)?

**Evidence:** `spatie/laravel-sluggable` auto-generates on creation. `rename()` is a domain method. The interaction is undefined.

**Classification:** Should be decided before Phase 1d. Affects SEO and URL stability.

---

### HD-10: Cut-Off Marks vs QualificationThreshold — **MEDIUM**

**What's unresolved:** QualificationThreshold is a VO (JSON on AdmissionPolicy) representing "what's required." `cut_off_marks` is a separate table representing "what actually happened" historically. The normalization F11 says "absorbed" but both exist. The relationship between them is unstated.

**Why it matters:** A developer reading only the VO list stores cut-offs as JSON. A developer reading Section 13 builds the" the separate table. Both are partially right.

**Classification:** Should be clarified during Phase 1b. Both should coexist: VO for requirements, table for historical data.

---

### HD-11: Dual Provenance Model — **MEDIUM**

**What's unresolved:** There's both (a) an `information_source_id` FK pointing to the InformationSource aggregate, AND (b) a `provenance` JSON column on every entity with inline source metadata (06-data-acquisition.md). Are these redundant? Which is canonical? What happens when they disagree?

**Classification:** Should be clarified during Phase 1b. The FK is authoritative; the JSON is denormalized for read performance.

---

### HD-12: Discipline Seeding — **MEDIUM**

**What's unresolved:** The initial discipline list, JAMB-to-StudyNexus mapping, and runtime management are all undefined. "During implementation" is not a specification.

**Classification:** Needed before Phase 1d (search) and Phase 1b (first import). Not a schema blocker but a data blocker.

---

### HD-13: Scholarship→Programme Pivot Columns — **LOW-MEDIUM**

**What's unresolved:** Pivot table `scholarship_programme` has only `(scholarship_id, programme_id)` specified. No timestamps, no provenance. 05-implementation.md is missing both pivot tables entirely.

**Classification:** Can be resolved during Phase 1b. Low impact on divergence.

---

### HD-14: Event Payload Completeness — **LOW**

**What's unresolved:** Some events have minimal payloads (e.g., `InstitutionSuspended` = `institutionId, occurredAt`). If UpdateSearchIndex needs to know what changed, it must reload the aggregate. The documents say events should carry "sufficient information for the reaction without requiring the consumer to reload the aggregate" — but several events violate this.

**Classification:** Can be refined during Phase 1b. Low divergence risk.

---

### HD-15: Typesense Document ID — **LOW**

**What's unresolved:** Which value is used as the Typesense document ID? UUID PK (Scout default) or slug? PRODUCT-EXPERIENCE says UUID. Scout default is `getScoutKey()` = PK. If PK is bigint, document IDs change.

**Classification:** Low. Scout default will work. Document to prevent divergence.

---

## 4. Dependency Analysis

```
PK Strategy (UUID vs bigint)                    ← IMPLEMENTATION BLOCKER
    │
    ├── FK Column Types                          ← Depends on PK strategy
    │       │
    │       ├── Import identity mapping           ← matching_entity_id type depends on PK
    │       │       │
    │       │       └── First data import         ← Cannot run without matching
    │       │
    │       ├── Typesense document ID             ← Must match PK type
    │       │
    │       └── All 45 reconciliation changes     ← Changes 4,5,6,27,31,32 assume bigint
    │
    ├── Morph type string values (HD-1)          ← Depends on PK strategy for morph_id type
    │       │
    │       └── AdmissionPolicy migration (HD-2) ← Needs morph values + PK type
    │               │
    │               └── Supersession mechanics (HD-8) ← Needs AdmissionPolicy schema
    │
    ├── D1: AdmissionCycle ownership              ← Affects FK direction
    │       │
    │       └── HD-3: Phase storage               ← Cycle schema depends on ownership
    │               │
    │               └── AdmissionCycle migration  ← Cannot be written without both
    │
    ├── D2: InformationSource ownership           ← Affects FK direction
    │       │
    │       └── HD-11: Dual provenance model      ← Depends on source ownership
    │               │
    │               └── Import provenance         ← Cannot write import without provenance
    │
    ├── D3: Scholarship provider relationship     ← Affects scholarships FK/morph
    │       │
    │       └── Scholarship migration             ← Cannot be written without D3
    │
    ├── D4: AccreditationRecord authority          ← Affects accreditation FK/morph
    │       │
    │       └── AccreditationRecord migration     ← Cannot be written without D4
    │
    ├── HD-4: Deletion cascade strategy           ← Affects ALL FK declarations
    │       │
    │       └── Every migration                   ← All FKs need ON DELETE rules
    │
    ├── HD-5: Import identity mapping             ← Affects data acquisition pipeline
    │       │
    │       └── First JAMB import                ← Cannot run without matching
    │
    ├── HD-6: TrustSignal algorithm               ← Affects UX display
    │       │
    │       └── Programme detail page             ← Must show trust signals
    │
    ├── HD-7: Soft deletes policy                 ← Affects migration design
    │       │
    │       └── Every migration                   ← deleted_at columns if needed
    │
    ├── HD-9: Slug lifecycle                      ← Affects SEO + url_redirects
    │       │
    │       └── Public site pages                 ← Slug-based routing
    │
    └── HD-10: Cut-off marks vs QualThreshold     ← Affects schema design
            │
            └── AdmissionPolicy + cut_off_marks migrations
```

### Critical Path (must be resolved before ANY migration)

1. **PK Strategy** → determines FK types → determines whether the 45 reconciliation changes need rework
2. **Morph type values** (HD-1) → determines polymorphic column values
3. **Deletion cascade strategy** (HD-4) → determines FK constraint declarations

### Near-Critical Path (must be resolved before domain entity migrations)

4. **D1** (AdmissionCycle ownership) + **HD-3** (phase storage) → determines admission_cycles migration
5. **D2** (InformationSource ownership) → determines information_sources migration + provenance FKs
6. **D3** (Scholarship provider) → determines scholarships migration
7. **D4** (AccreditationRecord authority) → determines accreditation_records migration
8. **HD-2** (AdmissionPolicy schema) → determines admission_policies migration

### Important but Not Migration-Blocking

9. **HD-5** (Import identity mapping) → blocks first data import, not schema
10. **HD-6** (TrustSignal algorithm) → blocks UX display, not schema
11. **HD-7** (Soft deletes) → affects migration design but can be decided per-table
12. **HD-8** (Supersession) → affects AdmissionPolicy unique constraint
13. **HD-9** (Slug lifecycle) → affects rename/redirect logic
14. **HD-10** (Cut-off vs QualThreshold) → clarifies dual representation
15. **HD-12** (Discipline seeding) → blocks first import, not schema

---

## 5. Reconciliation Readiness

### Classification: **C — Stop reconciliation until foundational decisions are resolved**

### Rationale

The reconciliation deliverables are **high-quality** and the 44 findings are **correctly identified**. However, the reconciliation is **not ready for execution** because:

1. **PK Strategy is an unresolved implementation blocker** that the reconciliation deliverables silently assumed (bigint everywhere). This assumption permeates 6+ of the 45 proposed changes. If PK strategy is UUID (as signaled by 3 of 5 authoritative documents), those changes need rework.

2. **Three hidden CRITICAL decisions** (HD-1 morph values, HD-2 AdmissionPolicy schema, HD-3 phase storage) were not identified by the reconciliation. These affect migrations and cannot be deferred.

3. **The four D decisions (D1-D4)** are correctly identified as requiring human judgment, but the analysis above shows that D2 and D4 are closer to mechanical corrections (A) than true architectural decisions. D1 and D3 are genuine C-class decisions. This reclassification affects the execution plan.

4. **Deletion cascade strategy (HD-4)** and **import identity mapping (HD-5)** are high-severity hidden decisions that must be resolved before migrations can be written.

### Minimum decisions required before reconciliation execution can proceed

| # | Decision | Blocks | Default from Documents |
|---|----------|--------|----------------------|
| **BD-1** | **PK Strategy (UUID vs bigint)** | All migrations, all FKs, all 45 changes, Typesense IDs, import mapping | 3 of 5 docs signal UUID; reconciliation assumed bigint; **no ADR exists** |
| **BD-2** | **Morph type string convention** (FQCN vs short alias) | All polymorphic migrations | Laravel default = FQCN; best practice = short alias via `Relation::enforceMorphMap()` |
| **BD-3** | **AdmissionCycle phase storage** (JSON vs separate columns) | admission_cycles migration | 03-domain.md = PhaseSequence VO (JSON); 05-implementation = 3 timestamp columns |
| **BD-4** | **Deletion cascade strategy** (domain close vs hard delete, FK ON DELETE rules) | All FK declarations in all migrations | No document specifies |
| **D1** | **AdmissionCycle ownership** (EducationAuthority vs Institution) | admission_cycles FK direction | 03-domain.md = EducationAuthority |
| **D3** | **Scholarship provider** (direct FK vs polymorphic) | scholarships FK/morph | 03-domain.md = direct FK |

### Decisions that can be defaulted from existing authority

| # | Decision | Default | Rationale |
|---|----------|---------|-----------|
| D2 | InformationSource ownership | Standalone (03-domain.md) | JAMB/NUC serve all institutions; institution-owned breaks provenance |
| D4 | AccreditationRecord authority | Direct FK (03-domain.md) | INV-2 says "exactly one Education Authority"; polymorphic contradicts this |

---

## 6. Confirmed Decisions

The following are fully decided and require no further action:

| Decision | Authority | Status |
|----------|-----------|--------|
| 11 entities (5 AR + 3 child + 3 supporting) | 02-decisions.md, 03-domain.md | ✅ Confirmed |
| 28 Value Objects (12 genuine + 16 enums) | 02-decisions.md, 03-domain.md | ✅ Confirmed |
| 16 enums with canonical values | 03-domain.md | ✅ Confirmed (per reconciliation) |
| 29 domain events with canonical names | 03-domain.md | ✅ Confirmed (per reconciliation) |
| 20 Actions with canonical names | 03-domain.md | ✅ Confirmed (per reconciliation) |
| 11 RBAC roles (4 global + 5 institution-scoped + 2 user) | 02-decisions.md, 04-architecture.md | ✅ Confirmed |
| OrganizationMember.role is string column | 02-decisions.md, 04-architecture.md | ✅ Confirmed |
| PostgreSQL is authoritative data store | ADR-01, 04-architecture.md | ✅ Confirmed |
| Typesense is search projection, not authoritative | ADR-06, 04-architecture.md | ✅ Confirmed |
| Detail pages read PostgreSQL, search pages read Typesense | 04-architecture.md= | ✅ Confirmed |
| Slug is public-facing identifier, PK is internal | 04-architecture.md | ✅ Confirmed |
| url_redirects for slug changes | 04-architecture.md | ✅ Confirmed |
| Eloquent IS the repository (no abstraction) | ADR-01, ADR-12 | ✅ Confirmed |
| Polymorphic for AdmissionPolicy and AccreditationRecord | ADR-11 | ✅ Confirmed (but morph values undefined — HD-1) |
| Publication model: is_published + published_at | 03-domain.md | ✅ Confirmed |
| No event sourcing, no event store | ADR-03 | ✅ Confirmed |
| History via spatie/laravel-activitylog | 04-architecture.md | ✅ Confirmed |
| External acquisition separated from application ingestion | 06-data-acquisition.md | ✅ Confirmed |
| 05-implementation.md is primary correction target | Reconciliation | ✅ Confirmed |
| Canonical cluster {01,02,03,04,06} is internally consistent | Reconciliation | ✅ Confirmed |

---

## 7. Recommended Decision Order

```
Step 1: PK STRATEGY (BD-1)                        ← BLOCKS EVERYTHING
        │
Step 2: MORPH CONVENTION (BD-2)                   ← BLOCKS POLYMORPHIC MIGRATIONS
        │
Step 3: DELETION CASCADE STRATEGY (BD-4)          ← BLOCKS ALL FK DECLARATIONS
        │
Step 4: ADMISSION CYCLE PHASES (BD-3) + D1        ← BLOCKS ADMISSION CYCLE MIGRATION
        │
Step 5: D3 (Scholarship provider)                  ← BLOCKS SCHOLARSHIP MIGRATION
        │
Step 6: Default D2 and D4 from 03-domain.md       ← NO JUDGMENT NEEDED
        │
Step 7: Execute all Classification A changes       ← 22 mechanical sync corrections
        │         (with PK strategy now known, re-type all FKs)
        │
Step 8: Resolve HD-2 (AdmissionPolicy schema)      ← BEFORE ADMISSION POLICY MIGRATION
        │
Step 9: Resolve HD-5 (Import identity mapping)     ← BEFORE FIRST DATA IMPORT
        │
Step 10: Resolve HD-6 (TrustSignal algorithm)      ← BEFORE PUBLIC SITE
        │
Step 11: Resolve HD-7, HD-8, HD-9, HD-10, HD-12   ← DURING PHASE 1
        │
Step 12: Execute remaining B and D changes          ← CLARIFICATIONS + NEW SCOPE
        │
        IMPLEMENTATION UNBLOCKED
```

---

## 8. Impact on Reconciliation Deliverables

The reconciliation deliverables require the following corrections before they can be considered approval-ready:

| Deliverable | Issue | Correction Needed |
|-------------|-------|-------------------|
| IMPLEMENTATION-MODEL-RECONCILIATION.md | Assumes `bigint PK` everywhere without ADR | Add PK strategy as OPEN DECISION; re-examine all table schemas |
| 05-implementation-RECONCILIATION-PROPOSAL.md | Changes 4,5,6,27,31,32 assume bigint FK | Add note: "FK type depends on BD-1 resolution" |
| RECONCILIATION-EXECUTIVE-SUMMARY.md | Says "implementation unblocked" after D1-D4 | Correct: implementation blocked until BD-1 through BD-4 resolved |
| BASELINE-RECONCILIATION-AUDIT.md | Did not identify PK strategy as a finding | Add finding: PK strategy is OPEN DECISION — IMPLEMENTATION BLOCKER |
| CANONICAL-AUTHORITY-MATRIX.md | No authority assigned for PK strategy | Add: PK strategy requires new ADR (no current document governs) |

---

## 9. Summary

| Category | Count |
|----------|-------|
| **Confirmed decisions** | 19 |
| **Unresolved decisions — implementation blockers** | 6 (BD-1 through BD-4, D1, D3) |
| **Unresolved decisions — can be defaulted** | 2 (D2, D4) |
| **Hidden decisions — CRITICAL** | 3 (HD-1, HD-2, HD-3) |
| **Hidden decisions — HIGH** | 3 (HD-4, HD-5, HD-6) |
| **Hidden decisions — MEDIUM** | 6 (HD-7 through HD-12) |
| **Hidden decisions — LOW** | 3 (HD-13, HD-14, HD-15) |
| **Primary-key status** | **OPEN DECISION — IMPLEMENTATION BLOCKER** |
| **Readiness classification** | **C — Stop until foundational decisions resolved** |
| **Minimum decisions before execution** | 6 (BD-1, BD-2, BD-3, BD-4, D1, D3) |

**Bottom line:** The reconciliation correctly identified 44 contradictions and proposed a coherent correction plan, but it silently assumed a PK strategy (bigint) that contradicts 3 of 5 authoritative documents, and it missed 3 CRITICAL and 3 HIGH hidden decisions. Until these 6+1 decisions are resolved, the reconciliation cannot be safely executed — two developers working from the corrected 05-implementation.md would still build materially different systems.
