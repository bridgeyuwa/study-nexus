# Hostile Architecture Review: field_provenance EAV Risk

**Review Date:** 2026-08-18
**Review Type:** HOSTILE — Adversarial, Evidence-Based, Willing to Overturn
**Subject:** `field_provenance` table schema and its classification within the StudyNexus data lineage architecture
**Evidence Base:** ADR-DL1, Second-Order Architecture Review, Previous Audit (prev-audit-extracted.txt), 03-domain.md, 05-implementation.md, 06-data-acquisition.md

---

## 3A. Is field_provenance secretly EAV?

### 3A.1 Why field_provenance is NOT canonical EAV

**Verdict: It is not canonical EAV, but it occupies an adjacent position on the EAV spectrum that demands explicit architectural guardrails.**

Canonical EAV (Entity-Attribute-Value) has three defining properties:
1. **E** — The entity is a generic row; no dedicated table per entity type
2. **A** — The attribute name is a string; no declared schema or type
3. **V** — The value is a single untyped column (typically TEXT); all domain types are projected into one representation

`field_provenance` violates property (E). It does NOT store entity fields as rows. Each canonical entity (institutions, programmes, scholarships, admission_cycles) has a dedicated table with declared, typed columns. The canonical columns are the source of truth. `field_provenance` is a **meta-table** that records *about* fields — it describes provenance metadata (source, confidence, verification status, supersession history) and incidentally carries the observed value for conflict display.

**The precise architectural distinction:** In EAV, the value column IS the data — it replaces typed columns. In `field_provenance`, the value column is AUDIT METADATA — it records what a source said. The canonical value lives in the typed entity column. Q6 in ADR-DL1 states this explicitly: *"The canonical entity field value IS the assertion. It is NOT stored as a separate record."* The entity field on `institutions.name` or `programmes.tuition` is the authoritative value; `field_provenance.observed_value` is a historical witness.

However, `field_provenance` retains properties (A) and (V) from EAV:
- `field_name VARCHAR(255)` is an unrestricted string — the "attribute" axis
- `observed_value TEXT` is a single untyped column — the "value" axis

This makes it **EAV-adjacent**: a meta-table with EAV-shaped columns, but one that is architecturally subordinate to typed canonical columns. The risk is not that it *is* EAV today, but that the EAV-shaped columns create gravitational pull toward EAV usage patterns.

### 3A.2 What operations are allowed to read from it?

**Verdict: ADR-DL1 specifies read paths but does NOT explicitly prohibit canonical business logic from reading observed_value. This is a gap.**

From the evidence:

**Explicitly documented read paths:**
1. **Admin conflict display UI** — "Admin sees both values and chooses" (ADR-DL1 Case C/D, §6). This is the PRIMARY intended consumer of `observed_value`.
2. **Trust signal display** — "Source: NUC accreditation list · Verified ✓" (Second-Order Review §8, scenario 7/8). This reads `source_id → information_sources` and `verification_status`, NOT `observed_value`.
3. **Source deprecation cascade** — `field_provenance WHERE source_id = deprecated_source_id` (ADR-DL1 Q11). Reads `verification_status` and `is_active`, NOT `observed_value`.
4. **Staleness detection** — `StaleDataDetectionJob` reads `provenance.last_verified_at` from entity-level JSONB, NOT from `field_provenance`.
5. **Filament RelationManager** — "RelationManager on Institution for external_identifiers and field_provenance" (ADR-DL1 stress test scenario 15). Admin-only.

**Critical gap:** Nowhere does ADR-DL1 state: *"Canonical business logic MUST NOT read observed_value as a substitute for the entity field."* The document says entity fields ARE assertions (Q6), but this positive statement does not constitute a prohibition. A developer could write:

```php
// WRONG but not architecturally prohibited
$tuition = FieldProvenance::where('entity_type', 'Institution')
    ->where('entity_id', $id)
    ->where('field_name', 'tuition')
    ->where('is_active', true)
    ->value('observed_value');
```

**Required fix:** ADR-DL1 must include an explicit read-path constraint:
> `field_provenance.observed_value` is readable ONLY by: (1) admin conflict resolution UI, (2) provenance audit/display components. Canonical business logic, API responses, search projections, and frontend display MUST read from the typed entity column. `observed_value` is NEVER a substitute for the canonical field.

### 3A.3 Can it become a second source of truth?

**Verdict: YES — this is the most dangerous latent risk in the entire architecture.**

The mechanism is straightforward:
1. `observed_value TEXT` stores the same data as the canonical field (ADR-DL1 §4.1: *"observed_value contains the same data already stored on the canonical entity"*)
2. For active (non-superseded) records, `observed_value` should equal the canonical field value
3. If a developer reads `observed_value` instead of the canonical column (see 3A.2), they have created a second source of truth
4. If the canonical column is updated without updating `field_provenance` (e.g., direct SQL update, a bug in the Action class), the two sources diverge silently

**AGR-DL1 provides NO runtime invariant checking that `observed_value` matches the canonical field for active records.** The second-order review's `value_hash` design (SHA-256 of the canonical value) at least allowed stale-detection ("If the hash doesn't match the current field's hash, the provenance is stale"). ADR-DL1 removed `value_hash` in favor of `observed_value TEXT` for UI display reasons — but removed the staleness-detection mechanism in the process.

**Required fixes:**
1. **Application-level invariant:** The `SupersedeProvenance` Action must verify that the active `observed_value` matches the canonical field value. If it doesn't, flag as `verification_status = 'stale'`.
2. **Staleness detection job:** Periodically check active `field_provenance` records against their canonical fields. This was part of the original design intent but is NOT specified for `field_provenance` specifically — only for entity-level provenance.
3. **Code-level guard:** The `FieldProvenance` Eloquent model should NOT expose `observed_value` via a `__toString()` or implicit cast that makes it interchangeable with the canonical value.

### 3A.4 Does field_name need an application/domain-level whitelist?

**Verdict: YES — this is a mandatory guardrail, not optional.**

Current state: `field_name VARCHAR(255) NOT NULL` with no constraint beyond VARCHAR(255). The ADR-DL1 comment says `-- e.g., 'name', 'tuition'` but this is illustrative, not restrictive.

INV-FP4 states: *"field_provenance is created only for Category A (always) and Category B (on conflict/multi-source) fields. Category C fields never receive field_provenance. Application-level enforcement (Action class)."*

This means:
- There are exactly **13 fields** that can legitimately appear in `field_name` (7 Category A + 6 Category B)
- Any other `field_name` value is a bug — it means either: (a) a Category C field leaked into provenance, (b) a typo, or (c) a new field was added without updating the Category classification

Without a whitelist, the following pathological scenarios are possible:
- `field_name = 'tuition_fee'` (variant spelling) alongside `field_name = 'tuition'` — silent duplication
- `field_name = 'is_published'` — Category C field leaking into provenance
- `field_name = 'some_random_column'` — no validation, no error

**Required fix:** Implement a domain-level whitelist as a PHP Backed Enum:

```php
enum ProvenanceField: string
{
    // Category A (always)
    case INSTITUTION_NAME = 'institution.name';
    case INSTITUTION_TYPE = 'institution.type';
    case INSTITUTION_VERIFICATION_STATUS = 'institution.verification_status';
    case PROGRAMME_NAME = 'programme.name';
    case PROGRAMME_ACCREDITATION_STATUS = 'programme.accreditation_status';
    case PROGRAMME_CUT_OFF_MARK = 'programme.cut_off_mark';
    case ADMISSION_CYCLE_CURRENT_PHASE = 'admission_cycle.current_phase';

    // Category B (on conflict)
    case INSTITUTION_TUITION = 'institution.tuition';
    case INSTITUTION_LOCATION = 'institution.location';
    case PROGRAMME_DURATION = 'programme.duration';
    case PROGRAMME_ADMISSION_REQUIREMENTS = 'programme.admission_requirements';
    case SCHOLARSHIP_ELIGIBILITY_CRITERIA = 'scholarship.eligibility_criteria';
    case SCHOLARSHIP_AMOUNT = 'scholarship.amount';
}
```

The `CreateFieldProvenance` Action must validate `field_name` against this enum. Invalid values throw a domain exception. This also solves the naming convention problem (dots vs underscores vs camelCase) by making the canonical string representation explicit.

### 3A.5 How are typed values represented?

**Verdict: TEXT creates a type-erasure problem that ADR-DL1 does not address. This is a MEDIUM-severity gap.**

The canonical fields that feed into `field_provenance` span these domain types:

| Field | Canonical Type | TEXT Representation | Risk |
|-------|---------------|---------------------|------|
| Institution.name | VARCHAR | Direct string — lossless | None |
| Institution.type | InstitutionType (Backed Enum) | Enum value string — lossless | Low |
| Institution.verification_status | VARCHAR/Enum | String — lossless | Low |
| Programme.name | VARCHAR | Direct string — lossless | None |
| Programme.accreditation_status | Enum | Enum value string — lossless | Low |
| Programme.cut_off_mark | integer | Numeric as text — parseable | Low |
| AdmissionCycle.current_phase | string | Direct string — lossless | None |
| Institution.tuition | **MonetaryAmount VO** (amount + currency, JSON) | **???** | **HIGH** |
| Institution.location | **Location VO** (country + region + city, JSON) | **???** | **MEDIUM** |
| Programme.duration | **Duration VO** (value + unit, JSON) | **???** | **MEDIUM** |
| Programme.admission_requirements | **JSON/complex structure** | **???** | **MEDIUM** |
| Scholarship.eligibility_criteria | **EligibilityRule VO** (JSON) | **???** | **MEDIUM** |
| Scholarship.amount | **ScholarshipAmount VO** (JSON) | **???** | **MEDIUM** |

For simple scalar fields (name, type, cut_off_mark), `TEXT` works: the value is a single scalar that can be losslessly stored as a string and compared as a string.

For **Value Objects stored as JSON** (MonetaryAmount, Duration, Location, EligibilityRule, ScholarshipAmount), `observed_value TEXT` must store the JSON representation. But:
1. **Comparison is broken.** Two JSON strings with different key ordering (`{"amount":150000,"currency":"NGN"}` vs `{"currency":"NGN","amount":150000}`) are TEXT-unequal but semantically equal. The conflict detection logic cannot do a simple string comparison on `observed_value` for JSON fields.
2. **Display is ambiguous.** Should the admin UI show raw JSON or a formatted representation? ADR-DL1 says the admin needs to "SEE both values" — but `"{"amount":180000,"currency":"NGN"}"` is not a human-readable conflict display.
3. **Parsing is required.** Any code that reads `observed_value` for a JSON-typed field must parse it back into the domain type, which requires knowing which field this is and what its type is. This is exactly the EAV type-erasure problem.

For **numeric fields** (tuition as integer, cut_off_mark as integer), `TEXT` requires parsing back to numeric for comparison. `"150000"` vs `150000` — the string comparison happens to work for same-length integers, but fails for `"150000"` vs `"15000"` (prefix match would incorrectly report similarity).

For **enum/status fields**, TEXT storage of the enum backing value is lossless, but there's no validation that the stored string is a valid enum member. If an enum member is renamed or removed, `observed_value` retains a stale string.

**Required fix:** Add a `value_type` column or use the `ProvenanceField` enum (from 3A.4) to determine the type at read time. The `CreateFieldProvenance` Action must serialize VOs as canonical JSON (sorted keys, consistent formatting). The admin UI must deserialize `observed_value` based on `field_name` → type mapping for display.

### 3A.6 What happens if the canonical field representation changes?

**Verdict: This is an UNRESOLVED risk. ADR-DL1 is silent on schema evolution of observed_value.**

Scenario: `Institution.tuition` is currently stored as `MonetaryAmount` VO (JSON with `amount` + `currency`). In a future version, it changes to a `Money` VO with different structure (`cents` + `currency` + `locale`).

- All existing `field_provenance` records have `observed_value = '{"amount":150000,"currency":"NGN"}'`
- New provenance records would have `observed_value = '{"cents":15000000,"currency":"NGN","locale":"en_NG"}'`
- The supersession chain now links records with incompatible serializations
- The admin UI cannot meaningfully display old records without version-aware deserialization

This is the classic EAV schema-evolution problem. In canonical EAV, it's catastrophic because values are the data. In `field_provenance`, it's mitigated because the canonical field holds the current representation and `observed_value` is audit metadata — but it still breaks historical display.

**Required fix:** Either:
1. **Add `schema_version` column** — increment when a field's VO representation changes, allowing versioned deserialization
2. **Normalize VOs to a stable text representation** — e.g., `MonetaryAmount` always serializes as `"NGN 150,000"` regardless of internal structure. This is display-oriented and stable across internal refactorings
3. **Accept the limitation explicitly** — document that `observed_value` for VO fields may become unparseable after schema changes, and old records should display raw text with a staleness indicator

### 3A.7 Is TEXT creating unacceptable semantic ambiguity?

**Verdict: TEXT is the correct column type for the use case, but it creates semantic ambiguity that must be addressed at the application layer.**

ADR-DL1's decision to use `observed_value TEXT` instead of `value_hash` is justified (§4.1): the admin UI needs to display what the source said, and a hash is irreversible. This is a sound decision.

The semantic ambiguity is NOT in the column type — it's in the **lack of type metadata**. `observed_value = "150000"` could mean:
- tuition = ₦150,000 (integer stored as text)
- cut_off_mark = 150,000 (integer stored as text)
- some field where "150000" is a string code

The disambiguation key is `field_name`. If `field_name = 'tuition'`, then "150000" is a MonetaryAmount. If `field_name = 'cut_off_mark'`, then "150000" is an integer. This works IF AND ONLY IF `field_name` is constrained to a known whitelist (3A.4) AND the application knows the type mapping for each field (3A.5).

**Summary:** TEXT is acceptable. The ambiguity is not in the type but in the missing type-lookup metadata, which must be provided by the `ProvenanceField` enum + type mapping.

---

## 3B. What does field_provenance actually mean?

### Verdict: Option 4 — Selective Conflict/Trust Provenance (NOT a complete historical observation log)

**The precise semantic definition:**

> `field_provenance` records the SOURCE ATTRIBUTION and CONFLICT STATE for selected fields of canonical entities. It answers: "Which source supports this field's current value? What did other sources say that disagreed? Has this been verified?" It is NOT a complete history of every observation ever made.

**Evidence that it is NOT a complete historical observation log:**

1. **Category C fields are excluded entirely** — derived/administrative fields like `slug`, `description`, `is_published`, `created_at` never appear in `field_provenance`. A complete log would include all fields.

2. **Category B fields are excluded when no conflict exists** — ADR-DL1 §5.2 trigger rules: *"Import: Category B field, value matches canonical → No field_provenance created. Single-source, no conflict."* If JAMB provides tuition=150000 and no other source disagrees, NO provenance record is created. The observation that JAMB said 150000 exists only in staging (`pending_imports`), which may be purged. This observation is then **permanently lost**.

3. **Staging is ephemeral** — ADR-DL1 Q23: *"import_batches and pending_imports [...] may be purged after successful import application."* The complete observation history is not retained.

4. **ADR-DL1 Q7** defines it as: *"A record that a specific field of a specific canonical entity is supported by a specific source, with the value that source provided and the current verification status of that support. Field provenance exists primarily for multi-source fields and conflict resolution, not for every field of every entity."*

5. **The second-order review §9** confirms: *"No persistent observations table."*

**It is also NOT Option 2 (Only conflict/reconciliation provenance)** because:
- Category A fields get provenance even without a conflict (ADR-DL1 §5.2: *"ALWAYS create field_provenance"*). The purpose is trust attribution, not just conflict recording.

**It is also NOT Option 3 (Canonical assertion lineage)** because:
- ADR-DL1 Q6: *"The canonical entity field value IS the assertion."* `field_provenance` records the provenance OF the assertion, not the assertion itself.

**The closest definition is:**

> **Selective Source Attribution Provenance** — A sparse table that records which source supports a canonical field value (for trust-critical and multi-source fields), what alternative values were observed (for conflict resolution), and the verification/supersession lifecycle of that attribution. It is populated by an 80/20 strategy that excludes low-value fields and single-source non-conflicting fields.

### Does ADR-DL1 communicate this clearly enough?

**Verdict: NO — ADR-DL1 communicates the mechanism (Category A/B/C, trigger rules) but does not clearly state the semantic identity.**

The document's title is "Data Lineage Architecture," which implies comprehensive tracking. The 06-data-acquisition.md document states (§1, principle 5): *"Provenance is recorded for every data point."* This is **contradicted** by the 80/20 model — Category B fields without conflict have NO provenance, and Category C fields NEVER have provenance.

**Required amendment:**
1. 06-data-acquisition.md principle 5 must be corrected to: *"Provenance is recorded for every data point that requires source attribution (Category A) or conflict tracking (Category B on conflict). Single-source, low-trust-sensitivity fields (Category C) and non-conflicting Category B fields do not receive field-level provenance."*
2. ADR-DL1 must include an explicit semantic definition section stating what `field_provenance` IS and IS NOT, using the definition above.

---

## 3C. Retroactive Provenance Problem

### Scenario Analysis

```
T=0:  JAMB provides tuition = 150000
T=1:  StudyNexus stores 150000 in institutions.tuition
T=2:  No field_provenance created (Category B, no conflict)
      --- THREE MONTHS PASS ---
T=3:  Another source provides 180000
T=4:  Conflict detected
T=5:  System creates provenance records for BOTH 150000 and 180000
```

At T=5, the provenance record for 150000 is **retroactively fabricated**. It was not created at the time of observation (T=0). The system must reconstruct what JAMB said three months ago.

### What information is fabricated or unavailable?

| Data Point | Available? | Evidence |
|-----------|-----------|----------|
| **observed_at** | **FABRICATED** | The system must set `observed_at` to the time of the original observation. But the original import time is NOT in `field_provenance` (it didn't exist). It could be approximated from `institutions.provenance JSONB.acquired_at` or from `import_batches.completed_at` — if the batch hasn't been purged. If staging is purged, `observed_at` must be set to the entity's `updated_at`, which may be inaccurate (if other fields were updated between T=0 and T=3). |
| **import_batch** | **UNAVAILABLE** | ADR-DL1 explicitly removed `import_batch_id` from the schema: *"Operational provenance, not canonical. Derivable via source_id → information_source → import_batches. Admin overrides have no import batch."* But if staging is purged, the import batch may no longer exist. Even if it exists, `source_id → information_sources` gives ONE source, but a source can produce MANY import batches — which specific batch? Without `import_batch_id`, the linkage is ambiguous. |
| **confidence** | **FABRICATED** | The original confidence score was computed at import time based on match quality, source reliability, etc. Three months later, this computation cannot be replayed. The system must either: (a) use a default (100 — the schema default), which is misleading; (b) derive from `information_sources` trust metadata, which is an approximation; or (c) mark as `NULL`, but `confidence SMALLINT NOT NULL DEFAULT 100` — it's NOT nullable. |
| **source metadata** | **PARTIALLY AVAILABLE** | `source_id` can point to the `information_sources` record for JAMB. This gives source name, type, and current verification status. But source metadata at the time of the original observation (which may have been different — JAMB could have been unverified then) is NOT captured. |
| **exact original observation** | **ASSUMED from canonical** | For the retroactive record, `observed_value` is set to the CURRENT canonical value (150000). This is correct IF AND ONLY IF no other update changed tuition between T=0 and T=3. If tuition was updated to 155000 by an admin at T=1.5, the retroactive record incorrectly records JAMB as saying 155000. |
| **acquisition context** | **UNAVAILABLE** | The adapter class, raw data, normalization steps, and fuzzy match details from the original import are in staging, which may be purged. |

### Is this acceptable?

**Verdict: CONDITIONALLY ACCEPTABLE, but the limitations must be made explicit and one minimum change is required.**

**Rationale:** The retroactive provenance problem is inherent to the 80/20 model. Category B fields exist specifically to avoid provenance overhead for single-source non-conflicting fields. The moment a conflict appears, you NEED provenance for both sources — but one source's provenance was never created. This is a deliberate tradeoff: storage efficiency in the common case at the cost of incomplete metadata in the conflict case.

**The alternative is to always create provenance for Category B fields** (making them equivalent to Category A), which defeats the 80/20 model and is explicitly rejected by ADR-DL1.

**Minimum required change:**

1. **Make `confidence` nullable.** The retroactive record CANNOT have a meaningful confidence score. Setting it to the default (100) is semantically wrong — it implies "we're very confident about this observation" when the truth is "we don't know the original confidence." Change: `confidence SMALLINT` (nullable). Retroactive records get `confidence = NULL`. The admin UI displays "confidence: unknown (retroactive)".

2. **Add a `retroactive BOOLEAN NOT NULL DEFAULT FALSE` column.** This flags records that were created after-the-fact. It serves multiple purposes:
   - The admin UI can display: *"This provenance was reconstructed from the canonical value at the time of conflict. Original import metadata is unavailable."*
   - Audit reviewers can distinguish genuine observations from retroactive reconstructions
   - The staleness-detection job can skip `retroactive = TRUE` records (their `observed_at` is approximate)

3. **Document the `observed_at` approximation.** For retroactive records, `observed_at` should be set to the earliest reliable timestamp available:
   - `institutions.provenance JSONB.acquired_at` (if available)
   - `institutions.updated_at` (fallback)
   - The admin UI must display: *"Observation date: ~[date] (approximate, retroactive)"*

**What is NOT required (rejected alternatives):**

- **Always-create provenance for Category B:** This collapses the 80/20 model. ADR-DL1's estimate of 50,000-100,000 `field_provenance` rows in steady state assumes Category B fields are sparse. Making all Category B fields always-provenance would multiply this by 5-10x.
- **Persistent observations table:** Already rejected by both ADR-DL1 and the second-order review. Staging is ephemeral by design.
- **import_batch_id on field_provenance:** Already rejected by ADR-DL1 §4.3 with valid reasoning. The retroactive problem does not change this — the import batch is operational metadata, not canonical provenance.

---

## Summary Verdicts

| Question | Verdict | Severity |
|----------|---------|----------|
| 3A.1 Is it EAV? | Not canonical EAV, but EAV-adjacent. The (A,V) columns create gravitational pull. | MEDIUM |
| 3A.2 Who can read it? | Read paths documented but NO explicit prohibition against canonical business logic reading observed_value. | **HIGH** |
| 3A.3 Second source of truth? | YES — latent risk. No runtime invariant checking active observed_value vs canonical field. | **HIGH** |
| 3A.4 field_name whitelist? | MANDATORY. Only 13 fields are valid. VARCHAR(255) with no constraint is an open door. | **HIGH** |
| 3A.5 Typed values? | TEXT causes type-erasure for VOs (MonetaryAmount, Duration, Location). JSON comparison and display broken. | MEDIUM |
| 3A.6 Schema evolution? | UNRESOLVED. observed_value for VOs may become unparseable after representation change. | MEDIUM |
| 3A.7 TEXT ambiguity? | TEXT is correct type, but ambiguity must be resolved via ProvenanceField enum + type mapping. | LOW |
| 3B Semantic definition | Selective Source Attribution Provenance. NOT a complete log. ADR-DL1 does not state this clearly. | MEDIUM |
| 3C Retroactive provenance | Conditionally acceptable. Minimum changes: nullable confidence + retroactive flag + documented approximations. | MEDIUM |

### Required Changes (Priority Order)

1. **[HIGH] Add explicit read-path constraint to ADR-DL1** — canonical business logic MUST NOT read observed_value as a substitute for entity field values.
2. **[HIGH] Implement ProvenanceField enum** — domain-level whitelist for field_name; CreateFieldProvenance Action validates against it.
3. **[HIGH] Add staleness-detection for field_provenance** — active observed_value must match canonical field; flag mismatches as verification_status = 'stale'.
4. **[MEDIUM] Make confidence nullable** — retroactive records cannot have meaningful confidence.
5. **[MEDIUM] Add retroactive BOOLEAN column** — flags after-the-fact provenance records.
6. **[MEDIUM] Add type-mapping for observed_value display** — admin UI must deserialize based on ProvenanceField enum, not display raw TEXT/JSON.
7. **[MEDIUM] Correct 06-data-acquisition.md principle 5** — provenance is NOT recorded for every data point.
8. **[MEDIUM] Document observed_at approximation** — for retroactive records, display approximate date with disclaimer.
9. **[LOW] Consider schema_version column** — for future VO representation changes (can defer to post-MVP).
