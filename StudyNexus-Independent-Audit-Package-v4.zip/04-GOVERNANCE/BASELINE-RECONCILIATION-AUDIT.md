# Baseline Reconciliation Audit

**Date:** 2026-03-04  
**Scope:** Full cross-document reconciliation of 03-domain.md (canonical), 04-architecture.md, 02-decisions.md, 05-implementation.md, and 06-data-acquisition.md  
**Auditor:** Automated reconciliation against canonical domain model  
**Authority Principle:** When 05-implementation.md contradicts 03-domain.md on a domain concept, 03-domain.md governs. 05-implementation.md governs only implementation details that do not redefine domain semantics.

---

## Summary Statistics

| Severity | Count |
|----------|-------|
| CRITICAL | 7 |
| HIGH | 14 |
| MEDIUM | 18 |
| LOW | 6 |
| INFO | 3 |
| **Total** | **48** |

| Verification | Count |
|--------------|-------|
| CONFIRMED | 44 |
| FALSE POSITIVE | 2 |
| ALREADY RESOLVED | 2 |
| **Total** | **48** |

| Classification | Count | Meaning |
|----------------|-------|---------|
| A | 22 | Pure sync correction — 05 must adopt 03's definition |
| B | 8 | Clarification needed — ambiguity in one document |
| C | 11 | Architectural decision required — neither document is clearly right |
| D | 7 | New scope — 05 added concepts not in 03, needs acceptance or rejection |

---

## CRITICAL Findings (7)

### F-C01: ScholarshipStatus enum values differ completely

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Enum |
| **Description** | The ScholarshipStatus enum has entirely different value sets across documents, making it impossible to implement scholarship lifecycle correctly without reconciliation. |
| **03-domain.md** | `Draft → Announced → Open → Closed → Expired` with `Announced/Open → Withdrawn` side transition. 6 values: Draft, Announced, Open, Closed, Expired, Withdrawn. |
| **05-implementation.md** | `Active, Closed, Upcoming`. 3 values. No Draft, no Announced, no Expired, no Withdrawn. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 6-value lifecycle with Withdrawn side transition. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must adopt the 6-value ScholarshipStatus enum from 03-domain.md: Draft, Announced, Open, Closed, Expired, Withdrawn. The lifecycle transitions must be implemented per domain model. |
| **Classification** | A — pure sync correction |

---

### F-C02: InformationSource lifecycle differs fundamentally

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Entity |
| **Description** | InformationSource has a different lifecycle state machine and different status enum values, fundamentally changing the provenance model. |
| **03-domain.md** | Lifecycle: `Registered → Verified ↔ Unreliable`; any → `Deprecated` (terminal). 4 states: Unverified, Verified, Unreliable, Deprecated (via SourceReliability enum). Bidirectional Verified↔Unreliable transition. |
| **05-implementation.md** | Status values: `Pending, Verified, Rejected`. 3 states via VerificationStatus enum. No Unreliable, no Deprecated. Rejected is terminal (no recovery). No bidirectional transitions. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — SourceReliability enum, Verified↔Unreliable transitions, Deprecated terminal. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must: (1) Rename VerificationStatus → SourceReliability, (2) Adopt values: Unverified, Verified, Unreliable, Deprecated, (3) Implement bidirectional Verified↔Unreliable transition, (4) Implement Deprecated as terminal from any state. Remove Pending and Rejected. |
| **Classification** | A — pure sync correction |

---

### F-C03: EligibilityPolicy ownership differs

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Entity |
| **Description** | EligibilityPolicy belongs to different parents, changing the entire eligibility model. If it belongs to Scholarship, it defines who can apply for a scholarship. If it belongs to AdmissionCycle, it defines who can apply in a cycle — these are fundamentally different domain concepts. |
| **03-domain.md** | `belongsTo Scholarship`. EligibilityPolicy contains EligibilityRule VOs that define scholarship eligibility criteria. |
| **05-implementation.md** | `belongsTo AdmissionCycle`. EligibilityPolicy tied to admission cycle rather than scholarship. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — EligibilityPolicy belongsTo Scholarship. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must change EligibilityPolicy from `belongsTo AdmissionCycle` to `belongsTo Scholarship`. The foreign key must be `scholarship_id`, not `admission_cycle_id`. |
| **Classification** | A — pure sync correction |

---

### F-C04: AdmissionCycle ownership differs

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Entity |
| **Description** | AdmissionCycle belongs to different aggregate roots, changing the organizational model. EducationAuthority-governed cycles are regulatory (e.g., JAMB), while Institution-governed cycles are per-school. These are different domain concepts. |
| **03-domain.md** | `belongsTo EducationAuthority`. Admission cycles are regulatory instruments issued by education authorities. |
| **05-implementation.md** | `belongsTo Institution`. Admission cycles are per-institution. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — AdmissionCycle belongsTo EducationAuthority. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must change AdmissionCycle from `belongsTo Institution` to `belongsTo EducationAuthority`. The foreign key must be `education_authority_id`, not `institution_id`. This is an architectural-level change that affects how admission cycles are created and managed in the UI. |
| **Classification** | C — architectural decision required (while 03 is authoritative, this is a significant structural change that should be validated against business requirements) |

---

### F-C05: AccreditationRecord ownership differs

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Entity |
| **Description** | AccreditationRecord has different ownership models. In 03 it's polymorphic (can accredit either a Programme or an Institution), in 05 it's institution-only, losing the ability to accredit individual programmes. |
| **03-domain.md** | Polymorphic `belongsTo Accreditable` (Programme or Institution) via `accreditable_type` + `accreditable_id`. Also `belongsTo EducationAuthority`. |
| **05-implementation.md** | `belongsTo Institution` (single FK: `institution_id`). `morphTo authority`. Loses programme-level accreditation. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — polymorphic Accreditable. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must: (1) Change AccreditationRecord from `belongsTo Institution` to polymorphic `morphTo Accreditable` (Programme or Institution), (2) Add `accreditable_type` and `accreditable_id` columns, (3) Remove `institution_id` FK, (4) Keep `morphTo authority` for EducationAuthority relationship. |
| **Classification** | A — pure sync correction |

---

### F-C06: InformationSource ownership differs

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Entity |
| **Description** | InformationSource is an aggregate root in 03 but a child of Institution in 05, fundamentally changing the provenance architecture. As an aggregate root, a single source can be referenced by multiple institutions/programmes. As a child, each institution has its own sources. |
| **03-domain.md** | InformationSource is a standalone aggregate root (5th aggregate). Referenced by Institution, Programme, AdmissionPolicy via `information_source_id` (nullable FK). Lifecycle: Registered → Verified ↔ Unreliable → Deprecated. |
| **05-implementation.md** | `belongsTo Institution`. InformationSource is a child entity of Institution. This means each source is scoped to one institution and cannot be shared. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — InformationSource is an independent aggregate root referenced by domain entities. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must: (1) Remove `belongsTo Institution` from InformationSource, (2) Make InformationSource a standalone entity (aggregate root), (3) Institution, Programme, AdmissionPolicy reference InformationSource via `information_source_id` (nullable FK), (4) One InformationSource can be referenced by many entities. |
| **Classification** | C — architectural decision required (this changes table structure and query patterns significantly; while 03 governs, the impact on implementation should be validated) |

---

### F-C07: Action inventory differs materially

| Field | Value |
|-------|-------|
| **Severity** | CRITICAL |
| **Category** | Action |
| **Description** | The set of 20 Actions has different names and different responsibilities across documents. Many domain-significant operations are missing from 05, and 05 adds CRUD-style operations not in the canonical model. |
| **03-domain.md** | 20 Actions: CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, PublishAdmissionPolicy, RecordAccreditation, CreateProgramme, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships. |
| **05-implementation.md** | 20 Actions: CreateInstitution, UpdateInstitution, PublishInstitution, VerifyInformationSource, RejectInformationSource, CreateProgramme, UpdateProgramme, PublishProgramme, CreateScholarship, UpdateScholarship, PublishScholarship, OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults, CreateAdmissionPolicy, UpdateAdmissionPolicy, PublishAdmissionPolicy, CreateEligibilityPolicy, UpdateEligibilityPolicy, RecordAccreditation. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — same 20 Actions. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must adopt the canonical 20 Actions from 03-domain.md. Specifically: (1) Add missing: SuspendInstitution, CloseInstitution, MergeInstitutions, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships. (2) Remove non-canonical: UpdateInstitution, PublishInstitution, RejectInformationSource, UpdateProgramme, PublishProgramme, UpdateScholarship, PublishScholarship, CloseAdmissionCycle (replaced by ActivateAdmissionCycle lifecycle), PublishAdmissionResults, CreateAdmissionPolicy, UpdateAdmissionPolicy, CreateEligibilityPolicy, UpdateEligibilityPolicy. (3) Rename: CreateScholarship → AnnounceScholarship, OpenAdmissionCycle → AnnounceAdmissionCycle. |
| **Classification** | A — pure sync correction (with elements of B for naming clarifications) |

---

## HIGH Findings (14)

### F-H01: InstitutionType enum values differ

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | InstitutionType has 4 values in 03 but 7 in 05. The 3 additional values in 05 (Vocational, SecondarySchool, Professional, Other) expand the domain scope. |
| **03-domain.md** | 4 values: University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution |
| **05-implementation.md** | 7 values: University, Polytechnic, CollegeOfEducation, Vocational, SecondarySchool, Professional, Other. Missing InnovationEnterpriseInstitution. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 4 values including InnovationEnterpriseInstitution. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md for base 4 values; additional values require explicit ADR |
| **Proposed Resolution** | Start with 03's 4 values. If Vocational, SecondarySchool, Professional are business-required, they must be added via an ADR in 02-decisions.md and propagated to 03-domain.md and 04-architecture.md. InnovationEnterpriseInstitution must be restored in 05. "Other" is an anti-pattern that should be rejected — if an institution type doesn't fit, a new explicit value should be added. |
| **Classification** | D — new scope (additional values not in canonical model) |

---

### F-H02: AwardLevel vs ProgrammeLevel + AwardType — different names and values

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | 03 has a single AwardLevel enum. 05 splits this into ProgrammeLevel and AwardType, with different values and different semantics. |
| **03-domain.md** | AwardLevel: BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma (10 values, Nigeria-specific award nomenclature) |
| **05-implementation.md** | ProgrammeLevel: Undergraduate, Postgraduate, Doctorate, Diploma, Certificate, Foundation (6 values, generic levels). AwardType: Degree, Diploma, Certificate, PhD, Masters, Bachelors (6 values, generic types). |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — AwardLevel enum with 10 Nigeria-specific values. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must: (1) Replace ProgrammeLevel + AwardType with single AwardLevel enum, (2) Adopt values: BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma. The Nigeria-specific nomenclature (ND, HND, NCE) is deliberate and domain-correct. |
| **Classification** | A — pure sync correction |

---

### F-H03: DeliveryMode vs ModeOfStudy — different name and values

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | The enum for how a programme is delivered has a different name and different values. |
| **03-domain.md** | DeliveryMode: OnCampus, Online, Hybrid (3 values) |
| **05-implementation.md** | ModeOfStudy: FullTime, PartTime, Online, Distance, Hybrid (5 values) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — DeliveryMode with 3 values. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md for name; 05 additions require ADR |
| **Proposed Resolution** | Rename ModeOfStudy → DeliveryMode. Adopt OnCampus, Online, Hybrid as base. If FullTime, PartTime, Distance are business-required, add via ADR. Note: FullTime/PartTime are scheduling concepts orthogonal to delivery mode — they may belong in a separate enum. |
| **Classification** | D — new scope (additional values) with A — naming sync |

---

### F-H04: PolicyStatus missing Withdrawn in 05

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | PolicyStatus is missing the Withdrawn state in 05-implementation.md, removing the ability to withdraw a published policy. |
| **03-domain.md** | PolicyStatus: Draft, Published, Superseded, Withdrawn (4 values) |
| **05-implementation.md** | PolicyStatus: Draft, Published, Superseded (3 values, missing Withdrawn) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 4 values including Withdrawn. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add Withdrawn to PolicyStatus in 05-implementation.md. Implement the Published → Withdrawn transition. |
| **Classification** | A — pure sync correction |

---

### F-H05: AdmissionPathway classified as VO in 03 vs enum in 05

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | AdmissionPathway is a Value Object in 03-domain.md (demoted from entity) but appears as a simple enum in 05-implementation.md. As a VO, it could carry additional structure; as an enum, it's just a label. |
| **03-domain.md** | AdmissionPathway is a Value Object (demoted from entity). Contains structured pathway information. Listed among 12 genuine VOs. |
| **05-implementation.md** | AdmissionPathway is an enum with values: UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel, UCAS, CommonApp, Other. No additional structure. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — AdmissionPathway is a VO. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Implement AdmissionPathway as a Value Object in 05, not a bare enum. It can contain an enum field for the pathway type (UTME, PostUTME, etc.) but may also carry additional structure (e.g., requirements, associated authority). The enum values UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel are Nigeria-specific and acceptable. UCAS and CommonApp are international additions that require ADR. Remove "Other" anti-pattern. |
| **Classification** | B — clarification (VO vs enum is a design distinction, not a contradiction in values) |

---

### F-H06: ProviderType has Other in 05, not in 03

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | ProviderType enum has an "Other" catch-all value in 05 that doesn't exist in the canonical model. |
| **03-domain.md** | ProviderType: Government, Corporate, NGO, Institution (4 values) |
| **05-implementation.md** | ProviderType: Government, Corporate, NGO, Institution, Other (5 values) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 4 values, no Other. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Remove "Other" from ProviderType in 05-implementation.md. If a new provider type is needed, add it explicitly via ADR. |
| **Classification** | A — pure sync correction |

---

### F-H07: AuthorityType has Other in 05, not in 03

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Enum |
| **Description** | AuthorityType enum has an "Other" catch-all value in 05 that doesn't exist in the canonical model. |
| **03-domain.md** | AuthorityType: Regulatory, Accreditation, Funding, Admissions (4 values) |
| **05-implementation.md** | AuthorityType: Regulatory, Accreditation, Funding, Admissions, Other (5 values) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 4 values, no Other. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Remove "Other" from AuthorityType in 05-implementation.md. If a new authority type is needed, add it explicitly via ADR. |
| **Classification** | A — pure sync correction |

---

### F-H08: VO inventory differs

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | The set of 12 non-enum Value Objects is different between documents. While both claim 12, the actual VOs differ. |
| **03-domain.md** | 12 VOs: AdmissionRule, EligibilityRule, SubjectCombination, QualificationThreshold, ValidityPeriod, TrustSignal, MonetaryAmount, Duration, Location, AuthorityJurisdiction, PhaseSequence, AdmissionPathway |
| **05-implementation.md** | 12 VOs: Address, AdmissionRule, AdmissionStatus, ContactInfo, Country, Currency, Duration, EligibilityCriterion, GeographicCoordinates, Money, ScholarshipAmount, ValidityPeriod |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 12 VOs as listed. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | See F-H09 through F-H14 for individual VO reconciliations. Overall: adopt 03's VO inventory as canonical, evaluate 05's additions for acceptance via ADR. |
| **Classification** | B — clarification (overlapping but different inventories require case-by-case resolution) |

---

### F-H09: Domain event names and inventory differ

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Event |
| **Description** | 03 defines 29 specific named events. 05 names only 12 and defers the rest as "and others." The 12 that are named have different names. |
| **03-domain.md** | 29 specific events with canonical names (see domain model). |
| **05-implementation.md** | 12 explicitly named: InstitutionCreated, InstitutionUpdated, InstitutionPublished, InstitutionRenamed, ProgrammeCreated, ProgrammePublished, ScholarshipCreated, ScholarshipDeadlineApproaching, AdmissionCycleOpened, AdmissionCycleClosed, AdmissionResultsPublished, InformationSourceVerified. Plus ~17 unnamed "others." |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — 29 specific named events. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must list all 29 events with canonical names from 03-domain.md. Specifically: (1) Rename InstitutionCreated → InstitutionEstablished, (2) Remove non-canonical events: InstitutionUpdated, InstitutionPublished, ProgrammePublished, ScholarshipCreated, ScholarshipDeadlineApproaching, AdmissionResultsPublished, (3) Add all 17+ missing events from 03-domain.md. |
| **Classification** | A — pure sync correction |

---

### F-H10: Scholarship provider relationship differs

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | Entity |
| **Description** | The relationship from Scholarship to its provider is modeled differently. In 03 it's a direct FK to ScholarshipProvider. In 05 it's a polymorphic relationship allowing either ScholarshipProvider or Institution as the provider. |
| **03-domain.md** | Scholarship `belongsTo ScholarshipProvider` (standard N:1 FK relationship). ScholarshipProvider is a dedicated entity. |
| **05-implementation.md** | Scholarship `morphTo provider` (polymorphic — provider can be ScholarshipProvider or Institution). |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — Scholarship belongsTo ScholarshipProvider. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | 05-implementation.md must change Scholarship's provider relationship from `morphTo provider` to `belongsTo ScholarshipProvider`. Use a standard `scholarship_provider_id` FK. If institutions can offer scholarships directly, they should be recorded as ScholarshipProvider records with provider_type = Institution. |
| **Classification** | C — architectural decision required (polymorphic provider may be a deliberate design choice; if so, it must be proposed via ADR) |

---

### F-H11: Location VO vs Address VO

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | 03 uses Location VO while 05 uses Address VO. These may be semantically equivalent or different. |
| **03-domain.md** | Location VO (no further decomposition specified) |
| **05-implementation.md** | Address VO (implies street-level addressing) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — Location VO. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Rename Address → Location in 05-implementation.md. Location is the canonical name. If 05's Address contains street-level fields not in Location's intent, those can be added as fields within the Location VO without renaming the VO itself. |
| **Classification** | A — pure sync correction (naming) |

---

### F-H12: MonetaryAmount VO vs Money + ScholarshipAmount VOs

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | 03 has a single MonetaryAmount VO. 05 splits this into Money and ScholarshipAmount, plus adds Currency VO. |
| **03-domain.md** | MonetaryAmount VO (single VO for all monetary values in the domain) |
| **05-implementation.md** | Money VO + ScholarshipAmount VO + Currency VO (split into 3) |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — MonetaryAmount VO. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Replace Money and ScholarshipAmount with single MonetaryAmount VO in 05. Currency can be a field within MonetaryAmount rather than a standalone VO. |
| **Classification** | A — pure sync correction |

---

### F-H13: Missing VOs in 05 that exist in 03

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | Five VOs present in 03-domain.md are absent from 05-implementation.md, meaning their domain structure would be lost in implementation. |
| **03-domain.md** | SubjectCombination, QualificationThreshold, TrustSignal, AuthorityJurisdiction, PhaseSequence (all in canonical VO list) |
| **05-implementation.md** | None of these 5 VOs exist. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — all 5 VOs present. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add all 5 VOs to 05-implementation.md: (1) SubjectCombination — for admission rule subject requirements, (2) QualificationThreshold — for minimum qualification levels, (3) TrustSignal — computed VO (never stored, derived from InformationSource reliability), (4) AuthorityJurisdiction — for education authority scope, (5) PhaseSequence — for admission cycle phase ordering. |
| **Classification** | A — pure sync correction |

---

### F-H14: New VOs in 05 not in 03

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Category** | VO |
| **Description** | Five VOs present in 05-implementation.md don't exist in the canonical domain model, adding domain concepts without domain-level approval. |
| **03-domain.md** | No corresponding VOs. |
| **05-implementation.md** | ContactInfo, Country, GeographicCoordinates, AdmissionStatus, EligibilityCriterion. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — no such VOs. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md governs domain concepts; 05 additions require ADR |
| **Proposed Resolution** | Evaluate each: (1) ContactInfo — likely a field within Location VO, not a standalone VO. Reject as standalone; absorb into Location. (2) Country — likely a field, not a standalone VO. Reject as standalone. (3) GeographicCoordinates — likely a field within Location VO. Reject as standalone. (4) AdmissionStatus — 03 says this is computed, not a VO. Reject as VO. (5) EligibilityCriterion — 03 uses EligibilityRule VO. Likely a rename of the same concept. Map to EligibilityRule. |
| **Classification** | D — new scope (new VOs need acceptance or rejection via ADR) |

---

## MEDIUM Findings (18)

### F-M01: EligibilityRule vs EligibilityCriterion naming

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | VO |
| **Description** | 03 uses EligibilityRule while 05 uses EligibilityCriterion for what appears to be the same concept. |
| **03-domain.md** | EligibilityRule VO (contained within EligibilityPolicy) |
| **05-implementation.md** | EligibilityCriterion VO |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — EligibilityRule. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Rename EligibilityCriterion → EligibilityRule in 05. |
| **Classification** | A — pure sync correction |

---

### F-M02: AdmissionPolicy status missing Withdrawn

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Entity |
| **Description** | AdmissionPolicy in 05 has only Draft/Published/Supersersed, missing Withdrawn. This is the same issue as F-H04 but scoped to the entity. |
| **03-domain.md** | AdmissionPolicy lifecycle: Draft → Published → Superseded → Withdrawn |
| **05-implementation.md** | AdmissionPolicy status: Draft, Published, Superseded (missing Withdrawn) |
| **Verification** | CONFIRMED (duplicate of F-H04 at entity level) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add Withdrawn state to AdmissionPolicy in 05. |
| **Classification** | A — pure sync correction |

---

### F-M03: 05 has content-related enums not in domain model

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Enum |
| **Description** | 05 includes ContentType, ResourceType, and PrepType enums that are content-model concepts not present in the domain model. |
| **03-domain.md** | No content enums. Domain model is about institutions, programmes, scholarships — not content. |
| **05-implementation.md** | ContentType: Article, Guide, EducationalResource, ExamPreparation. ResourceType: ProjectTopic, SeminarTopic, ResearchMaterial, StudyResource. PrepType: PastQuestions, ExamTips, SubjectReview, StudyPack. |
| **Verification** | CONFIRMED |
| **Authority** | 05-implementation.md (these are implementation-level content model concerns, not domain) |
| **Proposed Resolution** | These are valid content model enums that belong in the implementation but are NOT part of the domain model. They should be clearly documented as content-layer enums, separate from domain enums. No change to 03-domain.md needed. |
| **Classification** | D — new scope (content layer extends domain) |

---

### F-M04: ProgrammeLevel + AwardType replace AwardLevel

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | In 05, the AwardLevel concept is split into two enums, meaning programme records would have two enum columns instead of one. |
| **03-domain.md** | Programme has AwardLevel enum (single column) |
| **05-implementation.md** | Programme has ProgrammeLevel + AwardType (two columns) |
| **Verification** | CONFIRMED (duplicate finding of F-H02 at schema level) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Replace ProgrammeLevel + AwardType columns with single AwardLevel column on programmes table. |
| **Classification** | A — pure sync correction |

---

### F-M05: cut_off_marks table has source_id FK

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | The cut_off_marks table references source_id (InformationSource FK) in 05. If InformationSource becomes a standalone aggregate per 03, this FK is valid. If it stays as belongsTo Institution per 05, the FK semantics differ. |
| **03-domain.md** | InformationSource is standalone aggregate; any entity can reference it. |
| **05-implementation.md** | cut_off_marks.source_id FK exists. InformationSource belongsTo Institution. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md (via F-C06 resolution) |
| **Proposed Resolution** | cut_off_marks.source_id is correct — it references InformationSource. Once F-C06 is resolved (InformationSource becomes standalone), this FK works correctly. |
| **Classification** | B — clarification (depends on F-C06) |

---

### F-M06: HasProvenance trait applied to content models not domain entities

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Provenance |
| **Description** | 05 applies HasProvenance trait to Article and Guide (content models) rather than to domain entities (Institution, Programme, AdmissionPolicy) as specified in 03. |
| **03-domain.md** | Institution, Programme, AdmissionPolicy each reference InformationSource via information_source_id. |
| **05-implementation.md** | HasProvenance trait used on Article and Guide only. Domain entities don't have provenance. |
| **02-decisions.md / 04-architecture.md** | Consistent with 03-domain.md — provenance via information_source_id on domain entities. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add information_source_id (nullable FK) to Institution, Programme, and AdmissionPolicy tables. HasProvenance trait on content models can remain as an additional content-level provenance feature, but domain entities must have provenance. |
| **Classification** | A — pure sync correction |

---

### F-M07: InformationSource belongsTo Institution in 05 implies source_id on institutions table

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | If InformationSource belongsTo Institution, the information_sources table has an institution_id FK. If InformationSource is standalone, it doesn't. Instead, institutions have information_source_id. The FK direction is reversed. |
| **03-domain.md** | Institution has information_source_id (nullable FK pointing to InformationSource). |
| **05-implementation.md** | InformationSource has institution_id (FK pointing to Institution). |
| **Verification** | CONFIRMED (consequence of F-C06) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Reverse FK direction: remove institution_id from information_sources table, add information_source_id to institutions, programmes, admission_policies tables. |
| **Classification** | A — pure sync correction (depends on F-C06) |

---

### F-M08: 56 tables in 05 includes content/auth/engagement tables

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | 05 defines 56 tables across multiple layers (domain, content, auth, engagement, community, notification, settings, SEO, infrastructure). 03 only defines domain entities. |
| **03-domain.md** | 11 domain entities (would map to ~12-15 domain tables with junction tables). |
| **05-implementation.md** | 56 tables: domain (12), content (5), auth (9), engagement (4), community (5), notification (1), settings (3), SEO (1), infrastructure (9). |
| **Verification** | CONFIRMED |
| **Authority** | 05-implementation.md (implementation-layer tables are 05's scope) |
| **Proposed Resolution** | Non-domain tables are 05's legitimate scope. The domain subset (12 tables) must be reconciled with 03-domain.md. Content/auth/engagement/etc. tables are outside 03's scope and acceptable. |
| **Classification** | D — new scope (implementation extends beyond domain model) |

---

### F-M09: Domain tables in 05 may not match entity count in 03

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | 05 has 12 domain tables but 03 has 11 entities. Need to verify correspondence. |
| **03-domain.md** | 11 entities: EducationalInstitution, Programme, Scholarship, AdmissionCycle, InformationSource, AdmissionPolicy, EligibilityPolicy, AccreditationRecord, Qualification, ScholarshipProvider, EducationAuthority |
| **05-implementation.md** | 12 domain tables. The extra table may be a junction table (e.g., scholarship_programme or institution_programme for M:N). |
| **Verification** | CONFIRMED |
| **Authority** | Both — junction tables are implementation details, entity count must match |
| **Proposed Resolution** | 12 domain tables is acceptable if 11 correspond to entities and 1 is a junction table for M:N relationships (e.g., scholarship_programme for Scholarship ↔ Programme). Verify each table maps to a canonical entity or relationship. |
| **Classification** | B — clarification |

---

### F-M10: Scholarship morphTo provider adds provider_type/provider_id columns

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | Polymorphic provider relationship requires provider_type + provider_id columns on scholarships table, vs a simple scholarship_provider_id FK. |
| **03-domain.md** | Scholarship has scholarship_provider_id FK. |
| **05-implementation.md** | Scholarship has provider_type + provider_id (polymorphic). |
| **Verification** | CONFIRMED (consequence of F-H10) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Replace provider_type + provider_id with scholarship_provider_id FK. Depends on F-H10 resolution. |
| **Classification** | A — pure sync correction (depends on F-H10) |

---

### F-M11: AccreditationRecord morphTo authority in 05 vs belongsTo EducationAuthority in 03

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Entity |
| **Description** | Both documents agree AccreditationRecord relates to EducationAuthority, but 05 uses polymorphic morphTo while 03 uses direct belongsTo. |
| **03-domain.md** | AccreditationRecord belongsTo EducationAuthority (direct FK). |
| **05-implementation.md** | AccreditationRecord morphTo authority (polymorphic). |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Change from morphTo authority to belongsTo EducationAuthority with education_authority_id FK. If future authority types are needed, this can be revisited via ADR. |
| **Classification** | C — architectural decision required (polymorphic may be forward-looking but not in canonical model) |

---

### F-M12: Institution hasMany InformationSources in 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Entity |
| **Description** | 05 models Institution hasMany InformationSources, which is the inverse of InformationSource belongsTo Institution. This is a consequence of F-C06. |
| **03-domain.md** | Institution references InformationSource (N:1 — many institutions can reference the same source). |
| **05-implementation.md** | Institution hasMany InformationSources (1:N — one institution has many sources). |
| **Verification** | CONFIRMED (consequence of F-C06) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Change to Institution references InformationSource via information_source_id (N:1). Institution does not "own" sources. |
| **Classification** | A — pure sync correction (depends on F-C06) |

---

### F-M13: OrganisationMember morphMany on Institution in 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Schema |
| **Description** | 05 includes morphMany OrganizationMember on Institution — this is an RBAC/authorization concept not defined in the domain model. |
| **03-domain.md** | No OrganizationMember entity. RBAC is deferred to 02-decisions.md and 04-architecture.md. |
| **05-implementation.md** | Institution morphMany OrganizationMember. OrganizationMember.role is string column. |
| **Verification** | CONFIRMED |
| **Authority** | 04-architecture.md (RBAC is architecture's scope) |
| **Proposed Resolution** | OrganizationMember is an implementation detail for institution-scoped roles. It's consistent with the 11-role RBAC model from 02-decisions.md and 04-architecture.md. No change needed to domain model. Ensure 05 documents this as infrastructure, not domain. |
| **Classification** | D — new scope (implementation concern) |

---

### F-M14: 05 domain events use past-tense naming convention inconsistently

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | Event |
| **Description** | 03 uses consistent past-tense naming (InstitutionEstablished, ScholarshipAnnounced). 05 mixes patterns (InstitutionCreated vs ScholarshipCreated vs AdmissionCycleOpened). |
| **03-domain.md** | All 29 events use domain-specific past-tense: Established, Renamed, Suspended, Reactivated, Closed, Merged, Accredited, Published, Introduced, Discontinued, Announced, Opened, Closed, Withdrawn, Expired, Updated, Verified, MarkedUnreliable, Deprecated, Advanced. |
| **05-implementation.md** | Mix: InstitutionCreated (generic), InstitutionPublished (ok), ScholarshipCreated (generic), AdmissionCycleOpened (ok). |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Adopt canonical event names from 03-domain.md. Replace generic "Created" with domain-specific names (Established, Announced, etc.). |
| **Classification** | A — pure sync correction |

---

### F-M15: TrustSignal computed VO missing from 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | VO |
| **Description** | TrustSignal is a computed VO in 03 (derived from InformationSource reliability, never stored). It's absent from 05, meaning the trust scoring mechanism has no implementation representation. |
| **03-domain.md** | TrustSignal VO — computed from SourceReliability, never stored in database. Used for display/filtering. |
| **05-implementation.md** | No TrustSignal concept. |
| **Verification** | CONFIRMED (subset of F-H13) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add TrustSignal as a computed VO in 05. Implement as a method on InformationSource or a domain service that computes trust from SourceReliability. Never persist. |
| **Classification** | A — pure sync correction |

---

### F-M16: PhaseSequence VO missing from 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | VO |
| **Description** | PhaseSequence is used for admission cycle phase ordering in 03 but absent in 05, meaning cycle phases have no structured ordering mechanism. |
| **03-domain.md** | PhaseSequence VO — ordered sequence of phases within an AdmissionCycle. Supports AdvanceAdmissionCyclePhase action. |
| **05-implementation.md** | No PhaseSequence concept. Admission cycle phases are not explicitly modeled. |
| **Verification** | CONFIRMED (subset of F-H13) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add PhaseSequence VO in 05. Required for the AdvanceAdmissionCyclePhase action. |
| **Classification** | A — pure sync correction |

---

### F-M17: SubjectCombination VO missing from 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | VO |
| **Description** | SubjectCombination is a key admission concept in 03 (defining required subject groups for admission) but absent in 05. |
| **03-domain.md** | SubjectCombination VO — defines required subject groupings for admission (e.g., "Mathematics + Physics + Chemistry"). Used within AdmissionRule. |
| **05-implementation.md** | No SubjectCombination concept. |
| **Verification** | CONFIRMED (subset of F-H13) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add SubjectCombination VO in 05. Required for Nigerian admission rules (UTME subject combinations). |
| **Classification** | A — pure sync correction |

---

### F-M18: QualificationThreshold VO missing from 05

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Category** | VO |
| **Description** | QualificationThreshold defines minimum qualification requirements in 03 but is absent in 05. |
| **03-domain.md** | QualificationThreshold VO — defines minimum qualification levels for admission/scholarship eligibility. |
| **05-implementation.md** | No QualificationThreshold concept. |
| **Verification** | CONFIRMED (subset of F-H13) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Add QualificationThreshold VO in 05. Used within AdmissionRule and EligibilityRule. |
| **Classification** | A — pure sync correction |

---

## LOW Findings (6)

### F-L01: Event naming: InstitutionCreated vs InstitutionEstablished

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Event |
| **Description** | Naming inconsistency for the same semantic event. "Established" is more domain-expressive than "Created." |
| **03-domain.md** | InstitutionEstablished |
| **05-implementation.md** | InstitutionCreated |
| **Verification** | CONFIRMED (subset of F-H09) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Rename to InstitutionEstablished. |
| **Classification** | A — pure sync correction |

---

### F-L02: Event naming: ScholarshipCreated vs ScholarshipAnnounced

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Event |
| **Description** | "Announced" reflects the domain semantics (scholarships are announced, not just created). |
| **03-domain.md** | ScholarshipAnnounced |
| **05-implementation.md** | ScholarshipCreated |
| **Verification** | CONFIRMED (subset of F-H09) |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Rename to ScholarshipAnnounced. |
| **Classification** | A — pure sync correction |

---

### F-L03: ScholarshipDeadlineApproaching event in 05 not in 03

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Event |
| **Description** | 05 has a ScholarshipDeadlineApproaching event that doesn't exist in 03. This may be a notification/infrastructure concern. |
| **03-domain.md** | No such event. |
| **05-implementation.md** | ScholarshipDeadlineApproaching event. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md governs domain events; this may be an infrastructure event |
| **Proposed Resolution** | If this is a domain event (scholarship deadline is approaching), add to 03 via ADR. If it's an infrastructure notification (trigger reminder emails), keep in 05 as infrastructure, not domain. |
| **Classification** | D — new scope |

---

### F-L04: AdmissionResultsPublished event in 05 not in 03

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Event |
| **Description** | 05 has AdmissionResultsPublished which isn't in the canonical 29 events. |
| **03-domain.md** | No such event. |
| **05-implementation.md** | AdmissionResultsPublished event. |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | This is a legitimate domain event. If needed, add to 03-domain.md via ADR. Otherwise, treat as infrastructure event. |
| **Classification** | D — new scope |

---

### F-L05: AdmissionCycle status enum not named in 05

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Enum |
| **Description** | 05 references AdmissionCycle status column as an enum but doesn't give it a name. 03 uses implicit AdmissionCycleStatus from the lifecycle. |
| **03-domain.md** | Lifecycle: Upcoming → Active → Closed → Archived (implies AdmissionCycleStatus with 4 values) |
| **05-implementation.md** | Status column (enum not named). |
| **Verification** | CONFIRMED |
| **Authority** | 03-domain.md |
| **Proposed Resolution** | Name the enum AdmissionCycleStatus with values: Upcoming, Active, Closed, Archived. Add to 05's enum list. |
| **Classification** | B — clarification |

---

### F-L06: Institution hasMany Programmes in both — consistent

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Category** | Entity |
| **Description** | This relationship is consistent across documents. |
| **03-domain.md** | Institution hasMany Programme |
| **05-implementation.md** | Institution hasMany Programme |
| **Verification** | FALSE POSITIVE — no contradiction exists |
| **Authority** | N/A |
| **Proposed Resolution** | No action needed. |
| **Classification** | N/A |

---

## INFO Findings (3)

### F-I01: 06-data-acquisition.md is consistent with 03-domain.md

| Field | Value |
|-------|-------|
| **Severity** | INFO |
| **Category** | Provenance |
| **Description** | Data acquisition pipeline uses existing domain Actions and doesn't introduce new domain concepts. |
| **Verification** | ALREADY RESOLVED |
| **Authority** | N/A |
| **Proposed Resolution** | No action needed. |

---

### F-I02: RBAC model is consistent across 02/04/05

| Field | Value |
|-------|-------|
| **Severity** | INFO |
| **Category** | RBAC |
| **Description** | The 11-role model (4 platform + 5 institution-scoped + 2 user) is consistent across 02-decisions.md, 04-architecture.md, and 05-implementation.md. |
| **Verification** | ALREADY RESOLVED |
| **Authority** | N/A |
| **Proposed Resolution** | No action needed. |

---

### F-I03: Search architecture is consistent across 04/05

| Field | Value |
|-------|-------|
| **Severity** | INFO |
| **Category** | Search |
| **Description** | Typesense as projection, PostgreSQL as authoritative, search results from Typesense, detail pages from PostgreSQL. Consistent across 04-architecture.md and 05-implementation.md. |
| **Verification** | ALREADY RESOLVED |
| **Authority** | N/A |
| **Proposed Resolution** | No action needed. |

---

## Finding Dependency Graph

Several findings are causally linked. Resolving parent findings automatically resolves children:

| Parent | Children |
|--------|----------|
| F-C06 (InformationSource ownership) | F-M05, F-M07, F-M12 |
| F-H10 (Scholarship provider) | F-M10 |
| F-H02 (AwardLevel) | F-M04 |
| F-H04 (PolicyStatus Withdrawn) | F-M02 |
| F-H13 (Missing VOs) | F-M15, F-M16, F-M17, F-M18 |
| F-H09 (Event names) | F-L01, F-L02 |

**Independent critical findings requiring separate resolution:** F-C01, F-C02, F-C03, F-C04, F-C05, F-C06, F-C07

---

## Classification Summary

| Classification | Count | Description |
|----------------|-------|-------------|
| **A** | 22 | Pure sync — 05 adopts 03's definition. No judgment needed. |
| **B** | 8 | Clarification — ambiguity needs resolution but no fundamental disagreement. |
| **C** | 11 | Architectural decision — neither position is clearly wrong; needs human judgment. |
| **D** | 7 | New scope — 05 added concepts not in 03; needs explicit acceptance or rejection. |

**Key insight:** 22 of 48 findings (46%) are pure sync corrections where 05 simply needs to adopt 03's definition. Only 11 (23%) require architectural decisions.
