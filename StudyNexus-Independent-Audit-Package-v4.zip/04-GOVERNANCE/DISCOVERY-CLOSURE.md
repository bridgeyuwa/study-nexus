# StudyNexus — Final Discovery Closure & Implementation Readiness Gate

**Date:** 2026-08-10
**Status:** CLOSURE — awaiting human approval for canonical updates
**Authority:** 6 canonical documents (01–06) + PRODUCT-EXPERIENCE-DISCOVERY.md + PRODUCT-DISCOVERY-CHALLENGE.md
**Constraint:** No canonical documents modified. No code written. No additional discovery documents.

---

# 1. Final Decision Triage

Every unresolved item from PRODUCT-DISCOVERY-CHALLENGE.md, classified by whether implementation of the first vertical slice becomes materially wrong if the item remains undecided.

| ID | Question | Class | Recommendation | Why |
|----|----------|:-----:|---------------|-----|
| T-01 | Publication model on domain entities | **A** | `is_published` boolean + `published_at` nullable timestamp | Affects schema, public queries, admin UI, search indexing. Wrong choice requires schema migration and rework of every public query. |
| T-02 | ProgrammeStatus/InstitutionStatus inconsistency in 05-implementation.md | **A** | Correct to domain lifecycle values; add `is_published` separately | Wrong enum values produce wrong domain methods, wrong admin UI, wrong invariants. Must be fixed before any code is written against these enums. |
| T-03 | Cut-off mark history mechanism | **A** | `cut_off_marks` table (programme_id, admission_cycle_id, pathway, value, source_id) | Affects schema, import pipeline, detail page rendering. Without it, the programme detail page cannot show the information students need most. |
| T-04 | Discipline taxonomy structure | **A** | `disciplines` reference table + `discipline_id` FK on Programme (single, not M:N) | Affects schema, search index, SEO URLs, faceted search. The FK must exist before programmes can be imported. |
| T-05 | Detail page data source | **A** | PostgreSQL/Eloquent for detail; Typesense for lists/search | Affects Livewire component design, caching strategy, query architecture. Must be locked before implementation. |
| T-06 | Minimum data completeness threshold | **A** | Soft advisory check in admin UI (not hard validation) | Affects publication workflow and admin UX. Content team needs guidance before first data import. |
| T-07 | Scholarship public pages in MVP | **B** | Phase 2 for public pages; entity + admin CRUD in first vertical slice | Does not affect the programme-discovery core. Scholarship rows in PostgreSQL and admin CRUD are needed; public pages are not. |
| T-08 | Handoff contract details | **B** | Adopt contract from challenge report; refine during import implementation | The boundary is decided. Contract fields can be adjusted during import pipeline implementation without schema rework. |
| T-09 | Homepage default search scope | **B** | Default to programme search | Affects one Livewire component. Trivial to reverse. No architectural impact. |
| T-10 | Draft/unpublished entities in admin search | **B** | Include all entities in admin search regardless of publication status | Filament resource configuration. Trivial. |
| T-11 | URL structure for discipline landing pages | **B** | `/programmes?discipline={slug}` (query parameter, not path segment) | Routing config. Can change without schema impact. Matches existing SEO faceted URL strategy. |
| T-12 | Partial/incomplete data display | **B** | Show available info; mark missing sections "Not yet available" | Blade template logic. No architectural impact. |
| T-13 | Last-updated indicator on detail pages | **B** | Show `updated_at` as "Updated X days ago" | Computed field. Trivial. |
| T-14 | Source marked unreliable — display treatment | **B** | Show "Source under review" notice; don't hide data | Display logic only. |
| T-15 | Programme-institution relationship change communication | **C** | Defer to Phase 2+ | Merger scenario is rare. URL redirects via existing `url_redirects` table handle bookmarks. |
| T-16 | Tuition versioning | **C** | Phase 2 | Current value sufficient for MVP. Activity log provides audit. |
| T-17 | Discipline hierarchy | **C** | Phase 2 | Flat taxonomy sufficient. `parent_id` column can be added later. |
| T-18 | Discipline initial values | **B** | Seed during implementation when first data is imported | Table structure is A-class (must exist). Values are data, not schema. |

---

# 2. Publication Modeling — Final Check

## State Separation (Explicit)

| Dimension | Model | Stored Where | Values/Type |
|-----------|-------|-------------|-------------|
| **Lifecycle** | Domain model | `status` column on entity | InstitutionStatus: Provisional, Operational, Suspended, Closed. ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued. ScholarshipStatus: Draft, Announced, Open, Closed, Expired, Withdrawn. |
| **Publication visibility** | Application model | `is_published` boolean + `published_at` nullable timestamp | Binary: visible or not visible on public site. `published_at` provides Draft vs Unpublished distinction. |
| **Verification** | Domain model | `SourceReliability` enum on `InformationSource` | Unverified, Verified, Unreliable, Deprecated |
| **Acquisition/import state** | Application model | `import_batches.status` + `pending_imports.verification_status` | pending → parsing → parsed → verifying → verified → applying → completed / failed |
| **Canonical status** | Implicit | N/A — all data in PostgreSQL IS canonical | No field needed. StudyNexus is the canonical store. |
| **Supersession** | Domain model | `PolicyStatus::Superseded` on AdmissionPolicy, EligibilityPolicy | Draft → Published → Superseded → Withdrawn. Not applicable to other entities in MVP. |

**These are six orthogonal dimensions. None collapse into any other.**

## Republishing Semantics

> If an entity is unpublished and later republished, what does `published_at` mean?

`published_at` = **original/first publication date.** It is set once (when `is_published` transitions from `false` with `published_at = NULL` to `true`) and never changed. This is the conventional CMS semantic.

| Transition | `is_published` | `published_at` | Activity Log |
|------------|:-------------:|:--------------:|-------------|
| Entity created | `false` | `NULL` | — |
| First publish | `true` | `NOW()` | "Published by [user]" |
| Unpublish | `false` | unchanged | "Unpublished by [user]" |
| Republish | `true` | unchanged | "Republished by [user]" |
| Republish after unpublish | `true` | original date | "Republished by [user]" |

**Publication history is provided by spatie/laravel-activitylog.** Every `is_published` change is logged with: who, when, old value, new value. No separate publication-history subsystem is needed. If in future a richer publication history is required (e.g., "show all publication events in a timeline"), the activity log already contains this data — it just needs a UI.

## Verdict: APPROVE

`is_published` boolean + `published_at` nullable timestamp is sufficient for MVP. No enum. No state machine. No separate history table. Activity log provides full audit trail.

---

# 3. Cut-Off History — Final Check

## Scenario Analysis

### Scenario A: Cross-cycle history

```
2024/2025 cycle → cut-off 150
2025/2026 cycle → cut-off 180
2026/2027 cycle → cut-off 200
```

This is the **common case.** JAMB/institutions set a new cut-off each admission cycle. Students use previous years' cut-offs to estimate their chances for the upcoming cycle.

The `cut_off_marks` table handles this naturally: one row per (programme, admission_cycle, pathway). Display shows the current cycle's cut-off prominently, previous cycles' values collapsed below.

### Scenario B: Intra-cycle revision

```
2026/2027 cycle:
    Cut-off initially announced as 150
    Revised to 180 (institution adjustment)
    Revised again to 200 (JAMB correction)
```

This is **unusual.** It occurs when:
- An institution adjusts its departmental cut-off after initial release
- JAMB issues a correction to an official cut-off
- StudyNexus imported incorrect data and corrected it

**Does StudyNexus need to model Scenario B for MVP?**

No. Here's why:

1. **Users don't need intra-cycle revisions.** A student asking "What was the cut-off for UNILAG Computer Science in 2026?" needs one answer, not a revision history within that cycle.

2. **Intra-cycle changes are corrections, not historical facts.** When JAMB corrects a cut-off from 150 to 200, the correct value is 200. The fact that it was briefly 150 is an error, not meaningful data.

3. **Activity log captures corrections.** If a cut-off is updated within a cycle, `spatie/laravel-activitylog` records who changed it, when, from what value, and to what value. This satisfies auditability.

4. **The `cut_off_marks` table uses UPDATE, not INSERT, for intra-cycle changes.** There is one row per (programme, cycle, pathway). If the value changes within a cycle, the row is updated. The old value goes to the activity log.

### If Scenario B becomes important later

The smallest addition is:

```sql
ALTER TABLE cut_off_marks ADD COLUMN previous_value INTEGER nullable;
-- On update: store old value in previous_value before overwriting
```

This gives one level of intra-cycle history (current + previous) without a full version table. But this is NOT needed for MVP.

## Verdict: The `cut_off_marks` table is the smallest correct model

```sql
CREATE TABLE cut_off_marks (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    programme_id        UUID NOT NULL REFERENCES programmes(id) ON DELETE CASCADE,
    admission_cycle_id  UUID NOT NULL REFERENCES admission_cycles(id) ON DELETE CASCADE,
    pathway             VARCHAR(50) NOT NULL,  -- AdmissionPathway VO: 'utme', 'direct_entry', 'ijmb', 'jupeb'
    value               INTEGER NOT NULL,       -- The cut-off score
    source_id           UUID REFERENCES information_sources(id) ON DELETE SET NULL,
    created_at          TIMESTAMP(0) NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP(0) NOT NULL DEFAULT NOW(),
    UNIQUE (programme_id, admission_cycle_id, pathway)
);
```

One row per programme per cycle per pathway. Cross-cycle history: multiple rows. Intra-cycle corrections: update the row, activity log captures the change. No versioning framework. No event sourcing. No polymorphic table.

---

# 4. Discipline Taxonomy — Final Check

## Multi-discipline?

**One discipline per programme in MVP.** Rationale:

- Nigerian programmes have one primary classification: "Computer Science" is ICT, not also Engineering.
- Multi-discipline (M:N) adds: a pivot table, complex faceting logic ("show programmes in Engineering AND Sciences"), ambiguous SEO URLs, and admin complexity.
- Interdisciplinary programmes pick their primary discipline. Secondary classifications can use Spatie tags (Phase 2).
- The FK is `discipline_id` on `programmes`, not a M:N pivot.

## Canonical or search classification?

**Search classification treated as controlled reference data.** It is not a domain entity — it has no lifecycle, invariants, or business operations. However, once established it becomes de facto canonical because it drives:
- Faceted search (the most important browse dimension)
- SEO landing pages (`/programmes?discipline=engineering`)
- Programme organisation in admin
- External source mapping

It should be managed by the content team via Filament CRUD, not hard-coded.

## External source mapping?

**YES, but as import-adapter configuration, not a database table for MVP.** The JAMB adapter maps JAMB's "Engineering & Technology" to StudyNexus's "Engineering". This mapping lives in the adapter code/config. If the number of sources grows, a `source_discipline_mappings` table can be added in Phase 2.

## Flat for MVP?

**YES.** Hierarchy adds complexity without proportional user value:
- Nigerian students search for "Engineering", not "Engineering → Civil Engineering"
- Programme names provide specificity ("Civil Engineering")
- `parent_id` column can be added to `disciplines` table in Phase 2 without breaking changes

## Initial values needed before implementation?

**NO.** The table structure (schema) must exist before implementation. The actual values are seed/admin data that can be populated during implementation when the first data is imported and classification decisions are made against real programme data.

## Verdict: APPROVE structure; values are implementation-time data

```sql
CREATE TABLE disciplines (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(100) NOT NULL,
    slug        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMP(0) NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP(0) NOT NULL DEFAULT NOW()
);

-- On programmes table:
ALTER TABLE programmes ADD COLUMN discipline_id UUID REFERENCES disciplines(id) ON DELETE SET NULL;
CREATE INDEX idx_programmes_discipline ON programmes(discipline_id);
```

---

# 5. Scholarship MVP — Final Check

**Does including scholarship public pages strengthen the programme-discovery vertical slice?**

No. The programme-discovery vertical slice validates: "A student can find a programme, see admission requirements, navigate to the institution, and assess information reliability." Scholarships are not part of this loop.

**However, scholarships ARE part of the evaluation context.** When a student is evaluating a programme, financial information (tuition, available scholarships) is relevant. The question is how this information reaches the user.

**Minimum viable approach for the first vertical slice:**

1. Scholarship aggregate root + admin CRUD exist (domain model requires it)
2. Programme detail page shows related scholarships as an **inline list** (Eloquent query, not Typesense)
3. Each scholarship in the inline list shows: name, provider, coverage type, deadline
4. No link to a dedicated scholarship detail page — instead, link to the provider's website or show "Details coming soon"
5. No `/scholarships` landing page
6. No scholarship Typesense collection
7. No scholarship faceted search

**Why this is correct for MVP:**

- The vertical slice proves the core hypothesis (programme discovery) without scholarship pages
- Scholarship data quality is uncertain at launch — inline display with "coming soon" is honest
- Full scholarship pages (landing, detail, search) can be added in Phase 2 once data quality is validated
- This keeps the vertical slice focused and minimal

**Verdict: Scholarship public pages are Phase 2. Scholarship entity + admin CRUD + inline related-content on programme detail are in the first vertical slice.**

---

# 6. Acquisition Handoff Contract — Final Check

## What the external system must provide

| Field | Type | Required | Purpose |
|-------|------|:--------:|---------|
| `entity_type` | string | Yes | Target domain entity: `institution`, `programme`, `accreditation_record`, `cut_off_mark`, etc. |
| `operation` | enum | Yes | `create`, `update`, `retire` — declares intent |
| `match_keys` | object | Yes | Identifiers for entity matching: `{jamb_code?, nuc_code?, name, state?, type?}` — populated as available |
| `data` | object | Yes | Normalized, source-agnostic field values for the target entity |
| `changed_fields` | string[] | For updates | Which fields changed vs last observation (advisory, not authoritative) |
| `previous_values` | object | Recommended | Previous values of changed fields (advisory — StudyNexus validates against its own canonical data) |
| `source` | object | Yes | `{type: string, url: string, acquired_at: timestamp, trust_level: string}` |
| `effective_date` | date | For temporal data | Which admission cycle/session this data applies to |
| `observation_date` | date | Yes | When the external system observed this data |
| `batch_id` | string | Yes | Groups records from the same acquisition run |

## What StudyNexus must calculate internally

| Calculation | Mechanism |
|------------|-----------|
| Entity matching and resolution | Fuzzy match on `match_keys` against PostgreSQL (Levenshtein, JAMB/NUC code exact match) |
| Conflict detection | Compare `previous_values` (if provided) to current canonical; flag if they disagree |
| Change detection | Compare incoming `data` to current canonical field values; identify actual deltas |
| History recording | For cut-off marks: create row in `cut_off_marks` for new cycles. For other fields: activity log. |
| Provenance enrichment | Add StudyNexus-specific provenance: `applied_at`, `applied_by`, `import_batch_id`, `release_id` |
| Canonical timestamp | `applied_at` = when the change was committed to PostgreSQL |
| Search projection updates | Dispatch Scout queued jobs after successful apply |
| Cache invalidation | Tag-based cache flush on modified entities |
| Batch transactionality | All records in a batch applied atomically (or with manual partial-apply override) |

**Key principle: `previous_values` from the external system is advisory, not authoritative.** StudyNexus MUST verify against its own canonical data. The external system's view of "previous" may not match StudyNexus's canonical state.

**The contract is implementation-neutral.** It references no specific external system (AutoClaw, scraper, manual CSV). Any system producing conforming datasets can feed StudyNexus.

## Verdict: APPROVE

---

# 7. Minimum Data Completeness — Final Check

## Separation of Concerns

| Level | Institution | Programme |
|-------|-------------|-----------|
| **Required for canonical existence** (enforced by domain invariants) | name, type (InstitutionType), country (ISO 3166-1: NG) | name, institution_id, award_level (AwardLevel) |
| **Required for publication** (soft check, admin warning) | name, type, state_province, slug | name, institution, award_level, discipline_id, slug |
| **Required for search indexing** (same as publication) | Same as publication — unpublished entities are not indexed | Same as publication |
| **Optional** | city, website, founded_year, description, logo, contact_info, coordinates | duration, tuition, delivery_mode, description, career_prospts, admission_requirements |

## Implementation approach

**No formal validation framework.** A Filament form's `beforeSave` hook checks publication-requirement fields and sets a `publication_readiness` computed attribute displayed in admin. The content team can publish any entity regardless — the check is advisory, not blocking.

Why no hard block:
- "Useful" is subjective. An institution with only name + type + state is thin but not misleading if missing sections show "Not yet available."
- The content team needs the flexibility to publish incomplete data during initial data population (catch-22: you can't get user feedback without publishing, but you can't publish without complete data).
- Hard validation creates friction in the import pipeline — imported records would need all optional fields populated before publication, which may not be possible.

## Verdict: Soft advisory check in admin UI. No formal framework.

---

# 8. Detail Page Data Source — Locked

| Page Type | Data Source | Reason |
|-----------|------------|--------|
| Search results / faceted lists | **Typesense** | Faceting, ranking, typo tolerance, autocomplete — Typesense's core capabilities |
| Programme detail | **PostgreSQL/Eloquent** | Full entity graph: programme + institution + admission policies + accreditation records + cut-off marks + related scholarships. Typesense documents are denormalized projections that cannot serve this. |
| Institution detail | **PostgreSQL/Eloquent** | Full entity graph: institution + programmes (eager-loaded) + accreditation records + admission cycles. Programme list within institution is Eloquent (scoped to one institution), not Typesense. |

**This is locked for MVP.** No dual-read complexity. No Typesense for detail pages. PostgreSQL is authoritative and always serves the current canonical state.

---

# 9. Homepage Scope

**Classification: B — implementation-time decision.**

**Recommendation: Homepage defaults to programme search.** The search bar is programme-scoped with a tab bar for switching to Institutions or Scholarships. Rationale:

- The primary persona (SS3 student) arrives to find programmes, not institutions
- The core value proposition is programme discovery → admission information
- Programme search is the highest-value SEO entry point
- Trivial to reverse: if data shows users search equally for institutions, adjust the default tab

---

# 10. First Vertical Slice — Minimum Implementation Boundary

```text
Home (programme search entry)
  ↓
Programme search with faceted results (Typesense)
  ↓
Programme detail page (PostgreSQL/Eloquent)
  - Admission requirements (from AdmissionPolicy)
  - Cut-off marks current + historical (from cut_off_marks table)
  - Tuition & fees (from Programme MonetaryAmount VO)
  - Accreditation (from AccreditationRecord)
  - Provenance/trust signals (from InformationSource)
  - Related scholarships inline (Eloquent query, no detail page link)
  ↓
Institution detail page (PostgreSQL/Eloquent)
  - Institution profile
  - Programme list (Eloquent, eager-loaded)
  - Accreditation summary
  - Contact information
  ↓
Admin panel (Filament v5)
  - Institution CRUD + publish/unpublish
  - Programme CRUD + publish/unpublish
  - Discipline management (CRUD)
  - Data import (JAMB brochure)
  - Information source management
  ↓
Data acquisition
  - JAMB brochure import (at least one real import)
  - CSV manual import
  ↓
SEO
  - Programme/institution detail page meta + JSON-LD
  - Sitemaps
  - Canonical URLs
```

**What this validates end-to-end:**

| Capability | How |
|------------|-----|
| Canonical data | PostgreSQL stores all entities; Eloquent models enforce invariants |
| Eloquent | Domain models, relationships, eager loading, custom casts |
| Ingestion | JAMB import → staging → verify → apply → events → search index |
| Cut-off history | `cut_off_marks` table queried on programme detail; cross-cycle display |
| Typesense | Programme index with facets, autocomplete, ranking |
| Facets | Discipline, qualification, state, institution type, ownership, admission pathway, tuition range |
| SEO | Detail pages, sitemaps, JSON-LD, canonical URLs |
| Public rendering | Livewire v4 + Blade, mobile-first |
| Provenance/trust | Verification badges, source attribution on detail pages |
| Publication | `is_published` controls public visibility; admin workflow |
| Institution/programme relationship | FK, bidirectional navigation, eager-loaded programme list |

---

# 11. Three Lists: MVP Scope Boundary

## MUST EXIST BEFORE FIRST PUBLIC PROGRAMME PAGE

1. `institutions` table with InstitutionStatus enum: Provisional, Operational, Suspended, Closed
2. `programmes` table with ProgrammeStatus enum: Prospective, Admitting, Suspended, Discontinued
3. `is_published` boolean + `published_at` nullable timestamp on `institutions` and `programmes`
4. `disciplines` reference table (structure; values seeded during implementation)
5. `discipline_id` FK on `programmes` referencing `disciplines`
6. `cut_off_marks` table (programme_id, admission_cycle_id, pathway, value, source_id)
7. `admission_cycles` and `admission_policies` tables
8. `accreditation_records` table
9. `information_sources` table
10. `import_batches` and `pending_imports` tables (staging layer)
11. Typesense `programmes` collection with facet configuration
12. Programme search Livewire component with faceted results
13. Programme detail Blade page
14. Institution detail Blade page
15. Filament admin: Institution/Programme CRUD, publish/unpublish, discipline management
16. Publication visibility logic in public queries (`is_published = true` AND lifecycle allows)
17. At least one JAMB data import proving the pipeline end-to-end
18. Sitemap generation for programme/institution detail pages
19. JSON-LD structured data on detail pages

## CAN BE IMPLEMENTED DURING FIRST VERTICAL SLICE

1. Global search autocomplete (Typesense multi-collection)
2. Discipline seed data (populated as data is imported and classified)
3. Scholarship entity + admin CRUD (for inline related-content on programme detail)
4. Minimum data completeness advisory warnings in admin
5. spatie/laravel-activitylog configuration for audit trail
6. HTTP cache headers for public pages
7. Mobile-specific UI refinements (bottom sheet filters, tab navigation)
8. "Related programmes" section on programme detail
9. Facet count display in search sidebar
10. Sort options beyond relevance (tuition, name, cut-off)
11. "Updated X days ago" indicator on detail pages
12. Programme detail page: collapsible historical cut-offs section
13. Provenance display: "Verified by StudyNexus" badge, source attribution, last-verified date
14. Empty/partial data handling: "Not yet available" for missing sections

## PHASE 2+

1. Scholarship public pages (landing + detail + faceted search)
2. Comparison view
3. Eligibility assessment (WF4)
4. Tuition versioning
5. Discipline hierarchy (`parent_id` on `disciplines`)
6. Content models (Article, Guide, EducationalResource, ExamPreparation)
7. User accounts + saved searches + favourites
8. Community features (questions, answers, reports)
9. Notifications
10. Examination/resource discovery
11. Study abroad module
12. Institution self-service admin
13. Public API
14. Intra-cycle cut-off revision history (if needed)
15. External source discipline mapping table (if source count grows)

---

# 12. Architecture Sanity Check

| Anti-pattern | Required? | Why Not |
|-------------|:---------:|---------|
| Microservices | NO | Laravel monolith handles this scale. ADR-9 confirmed. |
| `nwidart/laravel-modules` | NO | Namespace separation (`App\Domain\`, `App\Actions\`, etc.) is sufficient. |
| Event sourcing | NO | ADR-3: events are fire-and-forget. Activity log for audit. |
| Generic polymorphic versioning | NO | `cut_off_marks` is a specific table for a specific need. Accreditation uses append-only records. Policies use supersession. |
| Generic publication state machine | NO | `is_published` boolean is sufficient. No transitions to guard beyond true/false. |
| Typesense as canonical storage | NO | PostgreSQL is source of truth. Typesense is projection. P9 confirmed. |
| Scraper logic inside Laravel | NO | External acquisition boundary is decided. StudyNexus starts at the approved dataset. |
| Universal data abstraction layer | NO | Eloquent IS the data layer. ADR-12: no repositories. |
| EAV | NO | Structured columns on structured tables. JSON only where the VO genuinely varies (e.g., MonetaryAmount with indigene/non-indigene). |
| Repositories everywhere | NO | ADR-12: Eloquent IS the repository. InstitutionMerger is the known seam. |
| Unnecessary domain classes | NO | Pragmatic Beyond CRUD per constraint. Domain classes exist where they protect invariants. |
| Another documentation hierarchy | NO | This IS the closure document. No further discovery documents. |

**All confirmed unnecessary for MVP.**

---

# 13. Canonical Document Changes Required

### Change 1
**Document:** 03-domain.md
**Section:** Programme entity attributes
**Change:** Add `is_published` boolean (default false) and `published_at` nullable timestamp to Programme's persistence attributes. Add `discipline_id` FK to Programme's attributes. Add `cut_off_marks` as a new query table in the domain model (not an entity — a structured query model for cross-cycle cut-off data).
**Reason:** Product requirement: publication visibility is orthogonal to domain lifecycle. Discipline classification is needed for programme discovery. Cut-off history is a core user need.

### Change 2
**Document:** 03-domain.md
**Section:** Institution entity attributes
**Change:** Add `is_published` boolean (default false) and `published_at` nullable timestamp to Institution's persistence attributes.
**Reason:** Same publication requirement as Programme.

### Change 3
**Document:** 03-domain.md
**Section:** Scholarship entity attributes
**Change:** Add `is_published` boolean (default false) and `published_at` nullable timestamp to Scholarship's persistence attributes.
**Reason:** Same publication requirement. Even though scholarship public pages are Phase 2, the publication model should be consistent across all user-facing entities.

### Change 4
**Document:** 03-domain.md
**Section:** New section after entities — Reference Data
**Change:** Add `disciplines` as a reference data table in the domain model: id, name, slug, description, sort_order. Note that discipline is search/product classification, not a domain entity with lifecycle.
**Reason:** Programme discipline classification is required for faceted search and SEO landing pages.

### Change 5
**Document:** 03-domain.md
**Section:** New section — Cut-Off Mark History
**Change:** Add `cut_off_marks` as a domain query model: programme_id, admission_cycle_id, pathway, value, source_id. One row per programme per cycle per admission pathway. Not an entity — a structured history table for cross-cycle cut-off data.
**Reason:** Historical cut-off display is a core user need for MVP. This is the smallest correct model.

### Change 6
**Document:** 05-implementation.md
**Section:** Database schema — programmes table
**Change:** Fix ProgrammeStatus enum values from (Draft, Published, Archived, Suspended) to (Prospective, Admitting, Suspended, Discontinued). Add columns: `is_published` boolean default false, `published_at` timestamp nullable, `discipline_id` UUID FK nullable references disciplines(id).
**Reason:** Align implementation with canonical domain model. Publication is a separate concern from lifecycle.

### Change 7
**Document:** 05-implementation.md
**Section:** Database schema — institutions table
**Change:** Fix InstitutionStatus enum values from (Draft, Published, Archived) to (Provisional, Operational, Suspended, Closed). Add columns: `is_published` boolean default false, `published_at` timestamp nullable.
**Reason:** Align implementation with canonical domain model.

### Change 8
**Document:** 05-implementation.md
**Section:** Database schema — scholarships table
**Change:** Add columns: `is_published` boolean default false, `published_at` timestamp nullable.
**Reason:** Consistent publication model across all user-facing entities.

### Change 9
**Document:** 05-implementation.md
**Section:** Database schema — new tables
**Change:** Add `disciplines` table (id, name, slug, description, sort_order, created_at, updated_at). Add `cut_off_marks` table (id, programme_id FK, admission_cycle_id FK, pathway varchar(50), value integer, source_id FK nullable, created_at, updated_at, UNIQUE programme_id+admission_cycle_id+pathway).
**Reason:** Discipline taxonomy and cut-off history are MVP requirements.

### Change 10
**Document:** 05-implementation.md
**Section:** Typesense collections — programmes
**Change:** Add `discipline` and `discipline_slug` to the programmes Typesense collection fields. Add `is_published` as a filter field (only published programmes are indexed). Add `tuition_min` and `tuition_max` as int32 fields (computed from MonetaryAmount VO). Add `is_admission_open` as a boolean field (computed from lifecycle + cycle + policy).
**Reason:** Discipline is a primary facet. Publication controls search indexing. Tuition range and admission status are search projection fields.

### Change 11
**Document:** 04-architecture.md
**Section:** Read model / search architecture
**Change:** Make explicit: (1) Typesense is the serving layer for all list/search/browse surfaces. (2) PostgreSQL/Eloquent is the serving layer for all detail pages. (3) The programme list within an institution detail page is served from Eloquent (not Typesense) — scoped to a single institution with eager loading. (4) Search projection fields (tuition_min/max, is_admission_open) exist only in Typesense, computed by toSearchableArray().
**Reason:** The product experience reveals Typesense as the primary read path for discovery. Detail pages need the full entity graph from PostgreSQL. This distinction must be explicit.

### Change 12
**Document:** 04-architecture.md
**Section:** Publication/visibility model
**Change:** Add section defining the publication model: `is_published` boolean + `published_at` nullable timestamp on Institution, Programme, Scholarship. Publication is orthogonal to domain lifecycle. Visibility rule for public queries: `is_published = true` AND lifecycle status allows. `published_at` = first publication date (set once, never changed). Publication history via spatie/laravel-activitylog.
**Reason:** Publication is an application/product concern that was not in the original architecture document.

---

# 14. Recommended Implementation Starting Point

```text
First vertical slice:

1.  Create Laravel 13 project with PHP 8.5 baseline
2.  Install core dependencies (Filament v5, Livewire v4, Spatie packages, Scout + Typesense driver)
3.  Write migrations: institutions, programmes, disciplines, cut_off_marks,
    admission_cycles, admission_policies, accreditation_records, information_sources,
    scholarship_providers, education_authorities, qualifications,
    import_batches, pending_imports
    + is_published + published_at on institutions, programmes, scholarships
    + discipline_id FK on programmes
4.  Write Eloquent models with domain methods, custom casts for VOs,
    and correct enum values (ProgrammeStatus: Prospective/Admitting/Suspended/Discontinued,
    InstitutionStatus: Provisional/Operational/Suspended/Closed)
5.  Write is_published scope: PublishedScope global scope that filters
    is_published = true AND status not in (Closed, Discontinued, Withdrawn, Expired)
6.  Seed disciplines table with initial Nigerian values
7.  Configure Typesense: programmes collection with facets
    (discipline, qualification, state, institution_type, ownership, admission_pathway, tuition_range)
    + computed fields (tuition_min, tuition_max, is_admission_open)
8.  Build public Livewire components:
    - ProgrammeSearch (faceted search, URL query string binding)
    - GlobalSearch (autocomplete)
9.  Build public Blade pages:
    - Home (programme search entry)
    - Programme detail (full entity graph, cut-off history, provenance)
    - Institution detail (profile, programme list, accreditation, contact)
10. Build Filament admin resources:
    - InstitutionResource (CRUD + publish/unpublish + completeness warnings)
    - ProgrammeResource (CRUD + publish/unpublish + completeness warnings)
    - DisciplineResource (CRUD for reference data)
    - ImportBatchResource (view/import batches)
    - InformationSourceResource (manage sources)
11. Build data import pipeline:
    - JambBrochureImport adapter (PDF parse → normalize → staging → verify → apply)
    - CsvBulkImport adapter
    - Verification engine (duplicate detection, cross-source consistency, schema validation)
    - Application layer (dispatch domain actions, emit events, queue Scout updates)
12. Build SEO infrastructure:
    - Sitemap generation (partitioned: institutions, programmes)
    - JSON-LD structured data on detail pages
    - Canonical URL management
    - Meta tags + Open Graph
13. Configure spatie/laravel-activitylog for audit trail
14. Write domain tests: invariants, state transitions, VO equality
15. Write feature tests: search results, detail pages, import pipeline, publication visibility
```

---

# 15. Final Readiness Verdict

## READY FOR CANONICAL UPDATE AND IMPLEMENTATION

**No blockers remain.** Every A-classified decision has a clear, bounded recommendation:

- Publication model: `is_published` + `published_at` — APPROVED
- Enum inconsistency: Correct to domain values — CLEAR FIX
- Cut-off history: `cut_off_marks` table — SMALLEST CORRECT MODEL
- Discipline taxonomy: Flat reference table + single FK — STRUCTURE APPROVED, VALUES ARE SEED DATA
- Detail page source: PostgreSQL for detail, Typesense for lists — LOCKED
- Minimum completeness: Soft advisory check — NO FRAMEWORK NEEDED

The discipline taxonomy values are the only data that could be considered "unknown," but they are implementation-time seed data — not a schema decision. The table structure is defined; values are populated during implementation when the first programme data is imported and classified.

**Discovery is closed. The next step is canonical document updates, then implementation.**

---

*Final Discovery Closure complete. Awaiting human approval of the 12 canonical document changes and the implementation starting point. No additional discovery documents will be produced.*
