# StudyNexus Pre-Implementation Baseline — Final Verdict

**Audit Date:** 2026-08-10

---

## Q1: Is the baseline internally consistent?

**NO**

The baseline contains 7 CRITICAL contradictions, 14 HIGH contradictions, and 18 MEDIUM contradictions, almost all between `03-domain.md` (the canonical domain model) and `05-implementation.md` (the canonical implementation blueprint). These two documents describe materially different domain models — different enum values, different Action lists, different VO inventories, different entity ownership, different child entity parents, and different schemas.

The CANONICAL-UPDATE-REPORT.md acknowledges 4 "remaining non-blocking issues" but fails to identify the vast majority of contradictions. Its claim that "all verification checks pass" is true only for the narrow set of metrics it checks.

Other documents (01-business.md, 02-decisions.md, 04-architecture.md, 06-data-acquisition.md) are largely consistent with each other and with 03-domain.md. The inconsistency is concentrated in 05-implementation.md.

---

## Q2: Is the domain model sufficiently defined?

**YES**

The domain model in `03-domain.md` is excellent. It contains:
- 11 entities (5 aggregate roots + 3 child entities + 3 supporting entities), each with documented invariants, operations, and lifecycle
- 28 Value Objects (12 genuine + 16 enums), each with clear invariants, equality semantics, and persistence strategy
- 29 domain events with documented consumers
- 20 Actions with explicit Action Criterion justification
- 25 invariants with severity classification and enforcement location
- Clear aggregate boundaries with justified separation
- Well-designed cross-aggregate interaction model (only InstitutionMerger requires a domain service)
- Correct application of Laravel Beyond CRUD principles (no repositories, no event sourcing, no unnecessary abstraction)

The domain model is the strongest part of the baseline. It is internally coherent, well-justified, and ready for implementation.

---

## Q3: Are the major business rules sufficiently defined?

**PARTIALLY**

The 40 approved decisions (A0-1 through A9-3) and 22 resolved open questions provide a comprehensive business rules foundation. The 7 business workflows are well-defined with business rules (BR-WF1-1 through BR-WF7-3). The 25 domain invariants are clear.

However:
- The information quality workflow (OQ4-2) is referenced but not architected
- The publication rules are defined (is_published + published_at) but the mechanism for toggling publication is not specified
- Eligibility assessment method (OQ6-3) is resolved as "progressive" but the progressive path is not detailed

These are minor gaps that do not block implementation.

---

## Q4: Is the data authority/source-of-truth model clear?

**PARTIALLY**

PostgreSQL is clearly the canonical source of truth (stated in 04-architecture.md P9, 02-decisions.md ADR-6). Typesense is clearly a search projection. The three data representations (authoritative domain, search projection, SEO/public) are well-distinguished.

However:
- The HasProvenance trait scope is contradicted (content-only in 04-architecture.md, domain-wide in 06-data-acquisition.md)
- The staging/verification model in 06-data-acquisition.md is well-designed but introduces tables not in the schema inventory
- The ADR-6 "start with PostgreSQL FTS" vs "Typesense active" contradiction creates confusion about the initial search implementation

---

## Q5: Is identity/versioning sufficiently defined?

**YES**

The versioning strategy is clear and consistent across documents:
- Accreditation: append-only immutable records (current status derived from sequence)
- Policies: supersession model (Draft → Published → Superseded → Withdrawn)
- Cut-off marks: cross-cycle rows, intra-cycle UPDATE + activity log
- Tuition: current value only (Phase 2 for versioning)
- General changes: activity log

No generic versioning framework is used — each concept has its own appropriate strategy. This is correct and well-documented.

---

## Q6: Are domain boundaries sufficiently justified?

**YES**

Every domain boundary is justified by:
- Protected invariants (5 aggregate roots with 3-6 invariants each)
- Business operations (7 domain methods per aggregate root on average)
- Consistency boundaries (documented for each aggregate)
- Clear separation of concerns (Domain → Application → Presentation, never reverse)

The namespace dependency rules in 04-architecture.md are excellent. No boundary is merely a folder boundary — each has a clear architectural purpose.

---

## Q7: Is the architecture consistent with Laravel Beyond CRUD?

**YES**

The architecture genuinely follows Laravel Beyond CRUD:
- Eloquent models as aggregate roots with domain methods (ADR-1)
- Actions with explicit criterion (ADR-2)
- No repositories (ADR-12)
- Domain events as plain PHP classes (ADR-3, ADR-16)
- Custom casts for VOs (ADR-4)
- Pragmatic namespace structure (ADR-10)
- Spatie packages evaluated individually (ADR-7)

The architecture is NOT ceremonial DDD — it is pragmatic, justified, and free from unnecessary abstraction. Every pattern solves an actual problem identified by the baseline.

---

## Q8: Could another competent developer implement from the baseline alone?

**WITH CLARIFICATIONS**

A developer who correctly identifies `03-domain.md` as authoritative could implement the domain layer, business rules, and architecture from the baseline alone. The domain model is that well-documented.

However, a developer who follows `05-implementation.md` without cross-referencing `03-domain.md` would build a materially different system. And a developer who tries to reconcile both would be stuck.

The baseline needs one clarification to be portable: explicit precedence between 03-domain.md and 05-implementation.md.

---

## Q9: Could another LLM reasonably produce a materially different architecture from the same baseline?

**YES**

The contradictions between 03-domain.md and 05-implementation.md are so extensive that different LLMs would necessarily produce different implementations:
- Different enum values (7+ enums)
- Different Action lists (14 of 20 differ)
- Different VO inventories (8 of 12 differ)
- Different entity ownership (5 entities affected)
- Different schemas (fundamentally different table structures)

Even if an LLM correctly identifies 03-domain.md as authoritative, the ADR-6 Typesense contradiction, the HasProvenance scope contradiction, and the table count discrepancy could lead to different infrastructure decisions.

**The baseline does NOT sufficiently constrain interpretation in its current state.**

---

## Q10: Should implementation begin?

### CONDITIONAL GO

Implementation may begin only in clearly identified non-blocked areas:

**CAN begin immediately:**
- Laravel project scaffolding and configuration
- Package installation (package matrix is consistent)
- Auth scaffolding and RBAC role seeding
- OrganizationMember pivot implementation
- Reference data tables (countries, currencies, qualifications, disciplines)
- Filament v5 admin panel setup
- Pest test framework configuration
- Domain layer implementation from 03-domain.md (models, VOs, enums, events)

**MUST NOT begin until resolved:**
- Domain entity migrations (contradictory schemas)
- Typesense configuration (ADR-6 contradiction — minor, can be resolved quickly)
- Content layer implementation (depends on domain layer)

**Path to GO:**
1. Declare 03-domain.md as authoritative (1 hour)
2. Reissue 05-implementation.md to conform to 03-domain.md (4-8 hours)
3. Update table count (30 minutes)
4. Resolve HasProvenance scope (1 hour)
5. Resolve ADR-6 Typesense contradiction (30 minutes)

**Estimated effort to full GO: 8-12 hours of focused documentation work.**

The underlying architecture is sound. The domain model is excellent. The problem is document synchronization — 05-implementation.md was not updated to match the frozen domain model. This is a fixable documentation problem, not a design problem.

---

## Summary

| Question | Answer |
|----------|--------|
| Q1: Internally consistent? | **NO** |
| Q2: Domain model sufficiently defined? | **YES** |
| Q3: Major business rules sufficiently defined? | **PARTIALLY** |
| Q4: Data authority/source-of-truth clear? | **PARTIALLY** |
| Q5: Identity/versioning sufficiently defined? | **YES** |
| Q6: Domain boundaries sufficiently justified? | **YES** |
| Q7: Architecture consistent with Laravel Beyond CRUD? | **YES** |
| Q8: Another developer could implement from baseline? | **WITH CLARIFICATIONS** |
| Q9: Another LLM could produce different architecture? | **YES** |
| Q10: Should implementation begin? | **CONDITIONAL GO** |

The StudyNexus pre-implementation baseline demonstrates strong domain thinking, sound architectural methodology, and genuine Laravel Beyond CRUD alignment. The domain model is ready. The implementation blueprint is not. Fix the blueprint, and the baseline is GO.

---

*End of Audit*

---

# Recommended Resolution Order

**Audit Date:** 2026-08-10
**Purpose:** Ordered sequence of what should be resolved before implementation proceeds. Does NOT solve the issues — only sequences them.

---

## Resolution Sequence

### 1. Establish Document Precedence (BLOCKING — all other resolutions depend on this)

**What:** Explicitly declare `03-domain.md` as the authoritative source for all domain model decisions (entities, VOs, enums, events, actions, relationships, invariants, lifecycles). Declare `05-implementation.md` as subordinate and requiring correction to conform.

**Why:** Without this, no contradiction can be resolved. Every subsequent resolution depends on knowing which document is authoritative.

**Dependency:** None. This is the first resolution.

**Effort:** Trivial — a one-line statement in README.md or a new canonical precedence document.

---

### 2. Reissue 05-implementation.md to Conform to 03-domain.md (BLOCKING)

**What:** Correct all schemas, enum values, VO lists, Action lists, entity relationships, and child entity ownership in `05-implementation.md` to match `03-domain.md`.

**Why:** This is the single fix that resolves 7 CRITICAL contradictions (C-01 through C-07) and most HIGH contradictions.

**Dependencies:** Resolution #1 (precedence).

**Specific corrections required:**
- Align all 16 enum values to 03-domain.md (fixes C-01)
- Replace 05-implementation.md's 20 Actions with 03-domain.md's 20 Actions (fixes C-02)
- Replace 05-implementation.md's VO inventory with 03-domain.md's (fixes C-03)
- Fix AdmissionCycle to be authority-owned with phases (fixes C-04)
- Fix InformationSource to be aggregate root with lifecycle (fixes C-05)
- Fix AdmissionPolicy to be polymorphic child of Programme/Institution (fixes C-06)
- Fix EligibilityPolicy to be child of Scholarship (fixes C-06, C-12)
- Fix AccreditationRecord to be polymorphic child of Programme/Institution (fixes C-14)
- Fix ScholarshipProvider to be FK (not polymorphic) on Scholarship (fixes C-07)
- Fix AdmissionPolicy schema to include AdmissionRule VOs (fixes C-13)
- Align domain event names to 03-domain.md's domain-language names (fixes C-15)
- Replace content-layer enums in domain enum count with domain enums (fixes C-16)
- Replace Address/GeographicCoordinates/Country/Currency VOs with Location/MonetaryAmount/TrustSignal etc. (fixes C-18)

**Effort:** Significant but mechanical — it's correction, not redesign. Estimated 4-8 hours of focused work.

---

### 3. Update Table Count (NON-BLOCKING but should be done with #2)

**What:** Update the table count in 05-implementation.md to include:
- `import_batches` (from 06-data-acquisition.md)
- `pending_imports` (from 06-data-acquisition.md)
- `user_alerts` (from 04-architecture.md, if confirmed)
- Verify `notification_preferences` is counted

**Why:** Ensures schema inventory is accurate and verifiable.

**Dependencies:** Resolution #2 (schema corrections may affect table count).

**Effort:** Trivial.

---

### 4. Resolve HasProvenance Trait Scope (NON-BLOCKING for domain layer, BLOCKING for data acquisition)

**What:** Decide whether `HasProvenance` trait and `provenance` JSON column apply to:
- (a) Domain entities only (as 06-data-acquisition.md implies)
- (b) Content models only (as 04-architecture.md states)
- (c) Both domain and content

**Why:** Affects whether domain migrations need a `provenance` JSON column.

**Dependencies:** Resolution #2 (schema corrections in progress).

**Recommendation:** Option (c) — apply to both. The provenance model is well-designed and the data acquisition pipeline needs it.

**Effort:** Small — add trait and column to schema, update domain model reference.

---

### 5. Resolve ADR-6 Typesense vs PostgreSQL FTS (NON-BLOCKING)

**What:** Either:
- (a) Update ADR-6 to reflect the decision to start with Typesense (aligning with 04-architecture.md and 05-implementation.md)
- (b) Clarify that Typesense infrastructure is provisioned but PostgreSQL FTS is the initial query engine, with Typesense as a drop-in replacement via Scout

**Why:** A developer needs to know whether to set up Typesense or use PostgreSQL FTS.

**Dependencies:** None.

**Recommendation:** Option (a) — the baseline clearly intends Typesense from day one based on the detailed collection schemas in 04-architecture.md and 05-implementation.md.

**Effort:** Trivial — update ADR-6 status and text.

---

### 6. Fix RBAC String Column Location in 05-implementation.md (NON-BLOCKING)

**What:** Correct 05-implementation.md Section 11 from "string role column on the users table" to "string role column on the organization_members table."

**Why:** Prevents confusion about where institution-scoped roles are stored.

**Dependencies:** Resolution #2 (part of the 05-implementation.md correction).

**Effort:** Trivial — one sentence fix.

---

### 7. Resolve Package Version Inconsistencies (NON-BLOCKING)

**What:** Synchronize package versions across all documents:
- `spatie/laravel-activitylog`: ^4.0 or ^5.0 (06-data-acquisition.md says ^5.0, others say ^4.0)
- `spatie/laravel-sluggable`: ^3.0 or ^4.0
- `spatie/laravel-tags`: ^4.0 (consistent)
- Add new packages from 06-data-acquisition.md to 05-implementation.md matrix: `spatie/crawler`, `smalot/pdfparser`, `spatie/laravel-rate-limited-job-middleware`

**Why:** Ensures a developer installs the correct versions.

**Dependencies:** None.

**Effort:** Trivial.

---

### 8. Document the Information Quality Workflow (NON-BLOCKING for Phase 1)

**What:** At minimum, acknowledge in the baseline that the information quality workflow (user reports of incorrect/outdated/missing/conflicting data) is referenced in 01-business.md but not architected. Either:
- (a) Architecture it (table, Actions, Filament resource)
- (b) Explicitly defer it to a specific phase

**Why:** 01-business.md lists "Manage Information Quality" as a supporting MVP capability. A developer may expect architecture for it.

**Dependencies:** None.

**Recommendation:** Option (b) — defer to Phase 2. The capability exists conceptually but doesn't require implementation infrastructure in the first vertical slice.

**Effort:** Trivial — add a deferral note.

---

## Dependency Graph

```
#1 (Establish Precedence)
 |
 v
#2 (Reissue 05-implementation.md) ─── #3 (Update Table Count)
 |
 ├── #4 (HasProvenance Scope)
 |
 └── #6 (Fix RBAC String Column)
 
#5 (Typesense vs FTS) — independent
#7 (Package Versions) — independent
#8 (Info Quality Workflow) — independent
```

---

## Priority Summary

| Priority | Resolution | Blocking? | Effort |
|----------|-----------|-----------|--------|
| 1 | Establish document precedence | YES | Trivial |
| 2 | Reissue 05-implementation.md | YES | Significant |
| 3 | Update table count | NO | Trivial |
| 4 | Resolve HasProvenance scope | NO (domain) / YES (acquisition) | Small |
| 5 | Resolve Typesense vs FTS | NO | Trivial |
| 6 | Fix RBAC string column location | NO | Trivial |
| 7 | Resolve package versions | NO | Trivial |
| 8 | Document info quality workflow | NO | Trivial |

**The critical path is #1 → #2.** Once these two are done, the baseline should be ready for GO. Everything else is non-blocking polish.

---

## Estimated Effort to GO

| Resolution | Effort |
|-----------|--------|
| #1 (precedence) | 1 hour |
| #2 (reissue 05) | 4-8 hours |
| #3 (table count) | 30 minutes |
| #4 (provenance) | 1 hour |
| #5 (Typesense) | 30 minutes |
| #6 (RBAC fix) | 15 minutes |
| #7 (packages) | 30 minutes |
| #8 (info quality) | 30 minutes |
| **Total** | **8-12 hours** |

The path from CONDITIONAL GO to GO is achievable in 1-2 days of focused work. The underlying architecture is sound — this is a documentation synchronization problem, not a design problem.

---

# Open Questions Audit

**Audit Date:** 2026-08-10
**Primary Sources:** `02-decisions.md` Section 2 (Resolved Open Questions), `02-decisions.md` Section 7 (Deferred Decisions), `DISCOVERY-CLOSURE.md`

---

## 1. Resolved Open Questions (from 02-decisions.md)

All 22 original open questions (OQ1-1 through OQ7-3) are marked as resolved as of 2026-08-08. Each has a documented resolution with a date.

### Status Assessment

| Question | Status | Blocking? | Notes |
|----------|--------|-----------|-------|
| OQ1-1 (Persona priority ranking) | RESOLVED | No | Clear priority: SS Student > Undergrad > Parent > Counsellor |
| OQ1-3 (Foreign institutions day one) | RESOLVED | No | No — Nigeria only |
| OQ1-4 (Persona-specific interfaces) | RESOLVED | No | Shared capabilities, adapted workflows |
| OQ2-3 (Institution management features) | RESOLVED | No | Post-MVP |
| OQ2-4 (Scholarship provider management) | RESOLVED | No | Post-MVP |
| OQ2-5 (Government agencies actively provide data) | RESOLVED | No | Primarily aggregated from public sources |
| OQ3-1 (Complete problem dimensions) | RESOLVED | No | 5 dimensions confirmed |
| OQ3-4 (Relative severity per persona) | RESOLVED (deferred detail) | No | Foundational priorities established |
| OQ4-1 (User accounts for MVP) | RESOLVED | No | No accounts for core MVP |
| OQ4-2 (User feedback mechanisms) | RESOLVED | No | Reports enter info-quality workflow |
| OQ4-3 (Decision support meaning) | RESOLVED | No | Progressive: consolidation → recommendation |
| OQ4-4 (Business/revenue model) | RESOLVED (deferred detail) | No | Strategic model established, mechanics deferred |
| OQ5-1 (Complete MVP capabilities) | RESOLVED | No | 10 capabilities confirmed |
| OQ6-1 (Sufficient information) | RESOLVED | No | Decision-dependent |
| OQ6-2 (Standard comparison dimensions) | RESOLVED | No | Common foundation + category-specific |
| OQ6-3 (StudyNexus performs eligibility) | RESOLVED | No | Progressive: self-assessment → structured |
| OQ6-5 (Decision support beyond aggregation) | RESOLVED | No | Yes, through structured comparison |
| OQ6-6 (Structured exploration parameters) | RESOLVED | No | Goal/workflow-driven |
| OQ6-7 (Information types per opportunity category) | RESOLVED | No | Common primitives + category-specific |
| OQ6-8 (Trust signals across categories) | RESOLVED | No | Official, Verified, Historical, Community-Contributed |
| OQ7-1 (Critical info for undergraduates) | RESOLVED | No | 12 information types listed |
| OQ7-2 (WF7 undergraduate only) | RESOLVED | No | Yes |
| OQ7-3 (Candidate concept promotion) | RESOLVED | No | Do not auto-promote |

**Verdict:** All 22 questions are genuinely resolved. None are blocking.

---

## 2. Deferred Decisions (from 02-decisions.md Section 7)

| Decision | Trigger | Status | Blocking? |
|----------|---------|--------|-----------|
| Exact monetisation mechanics | Real usage data | DEFERRED | No |
| Persona severity scoring | User research data | DEFERRED | No |
| Candidate concept promotion | Identity/lifecycle analysis | DEFERRED | No |
| Performance/caching strategy (ADR-17) | Production requirements | DEFERRED | No |
| Data ingestion pipeline (ADR-18) | First real data source | PARTIALLY ADDRESSED — 06-data-acquisition.md designs the pipeline | No |
| Search engine selection (Typesense vs FTS) | Performance testing | CONTRADICTED — ADR-6 says start with FTS, other docs use Typesense | No (but confusing) |
| Queue driver (Redis vs Database) | Implementation | DEFERRED | No |
| Custom PHPStan rules | Implementation | DEFERRED | No |

**Verdict:** All deferred decisions are genuinely non-blocking. The ADR-6 Typesense contradiction is confusing but not blocking — either choice works.

---

## 3. Discovery Closure Triage (from DISCOVERY-CLOSURE.md)

18 items (T-01 through T-18) were triaged:

| Class | Count | Status |
|-------|------:|--------|
| A (must resolve before implementation) | 6 | All resolved — applied via CANONICAL-UPDATE-REPORT.md |
| B (can proceed with documented choice) | 8 | All resolved — choices documented |
| C (deferred to Phase 2+) | 4 | All deferred |

**Verdict:** Discovery closure triage is complete.

---

## 4. Missing Questions

These are questions that implementation will require answers to but that the baseline does not raise:

### MQ-01: How is the `is_published` flag toggled?

**Impact:** MEDIUM
**Details:** The baseline defines `is_published` boolean + `published_at` timestamp. But it doesn't define WHO can publish, through WHAT mechanism, or whether publishing requires minimum data completeness. DISCOVERY-CLOSURE.md Section 7 says "soft advisory check in admin UI" but doesn't define the publish/unpublish Action or Filament resource action.
**Blocking?** No — can be a simple Filament action. But should be documented.

### MQ-02: What happens to search indexes when an entity is unpublished?

**Impact:** MEDIUM
**Details:** 04-architecture.md says "Only published entities are indexed in the public-facing Typesense collection." But the mechanism for removing an entity from Typesense when `is_published` changes to false is not defined. Is it a domain event? An event listener? A Scout `unsearchable()` call?
**Blocking?** No — implementation detail. But should be documented.

### MQ-03: How are institution merges handled in search indexes?

**Impact:** LOW
**Details:** MergeInstitutions is the most complex Action. The InstitutionsMerged event triggers SearchRebuild and ProgrammeReassignment. But the mechanics of rebuilding search documents for the merged entity and removing documents for the absorbed entity are not specified.
**Blocking?** No — implementation detail.

### MQ-04: What is the information quality workflow?

**Impact:** MEDIUM
**Details:** 01-business.md Capability #10 mentions "Users can report information as incorrect, outdated, missing, or conflicting. Reports enter an information-quality workflow." But this workflow is not architected anywhere. No table, no Actions, no Filament resource, no event.
**Blocking?** No — can be built later. But the baseline should acknowledge this as a gap.

### MQ-05: How are admission cycle phases configured?

**Impact:** MEDIUM
**Details:** 03-domain.md defines PhaseSequence VO with ordered phases. But who configures these phases? Is it a Filament admin operation? Is it seeded per authority? Is it part of the AnnounceAdmissionCycle Action parameters?
**Blocking?** No — the AnnounceAdmissionCycle Action accepts phaseSequence as a parameter. But the admin UI for configuring phases is not specified.

### MQ-06: What happens when a referenced entity disappears?

**Impact:** LOW
**Details:** If a ScholarshipProvider is deprecated, what happens to active Scholarships referencing it? The baseline says "existing unaffected" but doesn't define whether the Scholarship detail page shows a warning.
**Blocking?** No.

---

## 5. Open Questions Audit Verdict

| Category | Count | Status |
|----------|------:|--------|
| Resolved original questions | 22 | All genuinely resolved |
| Deferred decisions | 8 | All genuinely non-blocking |
| Discovery closure triage | 18 | All resolved or deferred |
| Missing questions identified | 6 | None blocking |

**The baseline has no blocking open questions.** All resolved questions are genuinely resolved with documented answers. All deferred decisions have clear triggers. The missing questions are implementation details that can be resolved during development without architectural risk.

**However:** The CANONICAL-UPDATE-REPORT.md lists 4 "remaining non-blocking issues" but significantly understates the scope of contradictions between 03-domain.md and 05-implementation.md. These contradictions are not "non-blocking issues" — they are CRITICAL blockers that the report fails to identify.

---

# Red Team Report

**Audit Date:** 2026-08-10
**Objective:** Break the baseline. Find concrete failure modes.

---

## Attack 1: "Two Blueprints, One Project"

**Scenario:** A development team receives the baseline. The lead developer reads 03-domain.md. The junior developer reads 05-implementation.md. They begin implementing in parallel.

**Failure:** They produce incompatible code. The lead creates `ScholarshipStatus` enum with values `Draft, Announced, Open, Closed, Expired, Withdrawn`. The junior creates `ScholarshipStatus` with `Active, Closed, Upcoming`. They discover the conflict during integration, weeks into development. Rework required.

**Severity:** CRITICAL
**Likelihood:** HIGH — both documents are labeled "canonical" and neither establishes precedence.

---

## Attack 2: "The Schema That Can't Enforce Invariants"

**Scenario:** A developer follows 05-implementation.md's schema for AdmissionPolicy (`admission_cycle_id FK`, no polymorphic parent). They create migrations and start testing.

**Failure:** INV-I3 (one active institutional Admission Policy per Admission Cycle) cannot be enforced because AdmissionPolicy has no link to Institution — it links to AdmissionCycle. The invariant check `Institution::publishAdmissionPolicy()` that should enforce "one active per cycle per institution" now checks "one active per cycle" globally — wrong invariant.

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md schemas are followed.

---

## Attack 3: "The Dead Information Source"

**Scenario:** A developer follows 05-implementation.md's InformationSource schema (flat table with `institution_id FK`, `verification_status` enum). No lifecycle methods, no domain operations.

**Failure:** The entire trust architecture from 03-domain.md is unimplementable. InformationSource cannot register, verify, markUnreliable, or deprecate. TrustSignal cannot be computed. The trust cascade (marking a source unreliable triggers trust recalculation on all derived data) has no mechanism. 06-data-acquisition.md's provenance model references source verification that the schema doesn't support.

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md schema is followed.

---

## Attack 4: "The Admission Cycle Without Phases"

**Scenario:** A developer follows 05-implementation.md's AdmissionCycle schema (`opens_at`, `closes_at`, `results_at`, `institution_id FK`). No phases, no PhaseSequence VO, no authority ownership.

**Failure:** INV-C2 (phase transitions follow defined sequence) is unenforceable — there are no phases. The `advancePhase()` operation from 03-domain.md is unimplementable. The AdmissionCyclePhaseAdvanced event has no trigger. Read model queries that derive `isAdmitting` from cycle phase cannot work. The entire admission cycle lifecycle (Upcoming → Active → Closed → Archived with internal phase progression) is replaced by date comparisons.

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md schema is followed.

---

## Attack 5: "The Scholarship Without a Provider"

**Scenario:** A developer follows 05-implementation.md's Scholarship schema which uses polymorphic `provider_type`/`provider_id`. But ScholarshipProvider is also listed as a supporting entity with its own table. The developer doesn't know which to use.

**Failure:** If polymorphic is used, INV-S1 (Scholarship has exactly one Provider) is still enforceable but the provider could be ANY model — not just ScholarshipProvider. Authorization logic breaks: institution-scoped roles can't be checked because the provider might not be an Institution. The `deprecate()` method on ScholarshipProvider becomes meaningless if providers can be any model.

**Severity:** HIGH
**Likelihood:** MEDIUM — the developer might notice the internal contradiction and ask.

---

## Attack 6: "The Provenance Ghost Column"

**Scenario:** A developer reads 06-data-acquisition.md and adds a `provenance` JSON column to every domain entity table. Later, a code reviewer points out that 03-domain.md doesn't mention provenance and 05-implementation.md's schemas don't include it.

**Failure:** The developer doesn't know whether to keep or remove the columns. If they keep them, they've added undocumented schema. If they remove them, the data acquisition pipeline can't record provenance.

**Severity:** HIGH
**Likelihood:** MEDIUM.

---

## Attack 7: "The 58-Table Miscount"

**Scenario:** A developer counts tables during migration creation. 05-implementation.md says 56. But 06-data-acquisition.md adds import_batches and pending_imports. 04-architecture.md mentions user_alerts. notification_preferences is mentioned but unclear if counted.

**Failure:** The developer's migration count doesn't match the documented count. They spend time investigating whether they missed a table or have an extra one. Confidence in the schema inventory erodes.

**Severity:** LOW
**Likelihood:** HIGH.

---

## Attack 8: "The Typesense Setup Dilemma"

**Scenario:** A developer reads ADR-6: "Start with PostgreSQL FTS. Switch to Typesense when latency exceeds 200ms." They implement PostgreSQL FTS. Another developer reads 04-architecture.md Section 2 and sets up Typesense. The team has conflicting infrastructure.

**Failure:** Wasted infrastructure setup or missing search capability. The team must reconcile which approach to use.

**Severity:** MEDIUM
**Likelihood:** HIGH.

---

## Attack 9: "The Eligibility Policy Without a Scholarship"

**Scenario:** A developer follows 05-implementation.md's EligibilityPolicy schema (`admission_cycle_id FK`, `criteria JSON`, `minimum_score`). This belongs to AdmissionCycle, not Scholarship.

**Failure:** INV-S2 (only one active Eligibility Policy per period) cannot be enforced on Scholarship — it's enforced on AdmissionCycle instead. The `Scholarship::publishEligibilityPolicy()` operation from 03-domain.md has no target. ScholarshipApplicationsOpened event's precondition (INV-S5: eligibility policy must exist) checks the wrong entity.

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md schema is followed.

---

## Attack 10: "The Accreditation That Can't Target Programmes"

**Scenario:** A developer follows 05-implementation.md's AccreditationRecord schema (`institution_id FK`, no polymorphic). Programme-level accreditation is impossible.

**Failure:** INV-P5 (Programme's accreditation from authority with jurisdiction) is unenforceable. The `Programme::recordAccreditation()` operation has no table to write to. ProgrammeAccredited event has no trigger. Programme detail pages cannot show accreditation status.

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md schema is followed.

---

## Attack 11: "The Action That Doesn't Exist"

**Scenario:** A developer is implementing the admin panel. They follow 05-implementation.md's Action list and create UpdateInstitution, PublishInstitution, UpdateProgramme, PublishProgramme. They don't create SuspendInstitution, CloseInstitution, MergeInstitutions, DiscontinueProgramme because they're not in the list.

**Failure:** The admin panel has no way to suspend, close, or merge institutions. The domain methods exist on the Institution model (from 03-domain.md) but no Action orchestrates them. A developer would need to discover these operations independently.

**Severity:** HIGH
**Likelihood:** CERTAIN if 05-implementation.md Action list is followed.

---

## Attack 12: "The Location That Isn't"

**Scenario:** A developer follows 05-implementation.md and creates Address, GeographicCoordinates, Country, and Currency VOs. They don't create Location, TrustSignal, AuthorityJurisdiction, PhaseSequence, SubjectCombination, or QualificationThreshold because they're not in the VO list.

**Failure:** The domain model is missing 8 of 12 VOs from 03-domain.md. Admission rules can't be structured (no SubjectCombination, no QualificationThreshold). Trust signals can't be computed (no TrustSignal). Authority jurisdiction can't be modeled (no AuthorityJurisdiction). Admission cycle phases can't be sequenced (no PhaseSequence).

**Severity:** CRITICAL
**Likelihood:** CERTAIN if 05-implementation.md VO list is followed.

---

## Attack 13: "The Canonicity Illusion"

**Scenario:** The CANONICAL-UPDATE-REPORT.md claims "all verification checks pass" and lists 4 "remaining non-blocking issues." A developer trusts this report and doesn't cross-check 03-domain.md against 05-implementation.md.

**Failure:** The developer proceeds with implementation believing the baseline is consistent. They discover contradictions during development, causing rework and eroding trust in the baseline documentation.

**Severity:** HIGH
**Likelihood:** MEDIUM — thorough developers will cross-check, but time-pressured ones may trust the report.

---

## Attack 14: "The Scope Creep Through Content"

**Scenario:** 05-implementation.md includes 4 content models (Article, Guide, EducationalResource, ExamPreparation) with full schemas, Actions, and Filament resources. But the first vertical slice is "programme discovery" — content is not in the first slice.

**Failure:** A developer implements content models before the core domain is functional, consuming the Phase 1 timeline. The content layer is sophisticated but the programme discovery experience is incomplete.

**Severity:** MEDIUM
**Likelihood:** MEDIUM — the phase sequence in 05-implementation.md correctly places content after domain, but the equal detail given to content may mislead prioritization.

---

## Attack 15: "The RBAC on the Wrong Table"

**Scenario:** A developer reads 05-implementation.md Section 11: "RBAC is enforced via bezhansalleh/filament-shield with the 11-role model using a string role column on the users table." They add a `role` string column to the `users` table.

**Failure:** Institution-scoped roles (owner, admin, admissions, editor, viewer) are now on the users table, meaning a user has ONE global role, not per-institution roles. The OrganizationMember pivot model is bypassed. The same user cannot be owner of Institution A and viewer of Institution B.

**Severity:** HIGH
**Likelihood:** LOW — the developer would likely also read 02-decisions.md which correctly describes the OrganizationMember pivot. But the inconsistency creates confusion.

---

## Red Team Summary

| Attack | Severity | Likelihood |
|--------|----------|------------|
| 1. Two Blueprints, One Project | CRITICAL | HIGH |
| 2. Schema That Can't Enforce Invariants | CRITICAL | CERTAIN |
| 3. Dead Information Source | CRITICAL | CERTAIN |
| 4. Admission Cycle Without Phases | CRITICAL | CERTAIN |
| 5. Scholarship Without a Provider | HIGH | MEDIUM |
| 6. Provenance Ghost Column | HIGH | MEDIUM |
| 7. 58-Table Miscount | LOW | HIGH |
| 8. Typesense Setup Dilemma | MEDIUM | HIGH |
| 9. Eligibility Policy Without a Scholarship | CRITICAL | CERTAIN |
| 10. Accreditation That Can't Target Programmes | CRITICAL | CERTAIN |
| 11. Action That Doesn't Exist | HIGH | CERTAIN |
| 12. Location That Isn't | CRITICAL | CERTAIN |
| 13. Canonicity Illusion | HIGH | MEDIUM |
| 14. Scope Creep Through Content | MEDIUM | MEDIUM |
| 15. RBAC on the Wrong Table | HIGH | LOW |

**Strongest attacks:** #2, #3, #4, #9, #10, #12 — these represent CERTAIN CRITICAL failures if 05-implementation.md is followed without reference to 03-domain.md.

**The baseline's vulnerability is concentrated in one document: 05-implementation.md.** Fix that document and the attack surface drops dramatically.

---

# Implementation Readiness

**Audit Date:** 2026-08-10

---

## Readiness Matrix

| # | Area | Status | Blocking? | Reason |
|---|------|--------|-----------|--------|
| 1 | Domain structure | READY | No | 03-domain.md is well-defined and internally coherent |
| 2 | Entities | READY | No | 11 entities with clear invariants, operations, lifecycles |
| 3 | Relationships | READY WITH MINOR CLARIFICATION | No | Clear in 03-domain.md; 05-implementation.md contradicts but 03 is authoritative |
| 4 | Business rules | READY | No | 40 approved decisions + 22 resolved questions in 02-decisions.md |
| 5 | Lifecycle | READY | No | State machines defined for all entities in 03-domain.md |
| 6 | Versioning | READY | No | Append-only accreditation, supersession for policies, cut_off_marks table |
| 7 | Data ingestion | READY WITH MINOR CLARIFICATION | No | 06-data-acquisition.md is well-designed; table count and provenance scope need sync |
| 8 | Data management | READY WITH MINOR CLARIFICATION | No | Staging/verification model is clear; HasProvenance scope contradicted |
| 9 | Search | READY WITH MINOR CLARIFICATION | No | Architecture is sound; ADR-6 Typesense-vs-FTS contradiction needs resolution |
| 10 | AI/recommendations | N/A | No | Not in MVP scope; no AI architecture to audit |
| 11 | SEO | READY | No | Well-architected in 04-architecture.md Section 6 |
| 12 | Authentication/authorization | READY | No | 11-role model is well-defined in 02-decisions.md; minor RBAC inconsistency in 05-implementation.md Section 11 |
| 13 | Admin workflows | READY | No | Filament v5 resources well-defined in 04-architecture.md Section 10 |
| 14 | External integrations | READY WITH MINOR CLARIFICATION | No | Adapters defined in 06-data-acquisition.md; new packages not in 05-implementation.md matrix |
| 15 | Persistence | **BLOCKED** | YES | 05-implementation.md schemas contradict 03-domain.md — cannot create correct migrations without resolving |
| 16 | Failure handling | READY WITH MINOR CLARIFICATION | No | Pipeline failure handling defined; indexing failure has basic retry; no dead-letter queue |
| 17 | Deployment/operational assumptions | READY WITH MINOR CLARIFICATION | No | Platform versions defined; caching/performance deferred (ADR-17); queue driver deferred |

---

## Detailed Explanations

### Area 1-6: Domain Model (READY)

The domain model in 03-domain.md is the strongest part of the baseline. All entity definitions, relationships, invariants, lifecycles, and versioning strategies are well-defined and internally coherent. A developer can begin implementing the domain layer directly from 03-domain.md without ambiguity.

### Area 7-8: Data Ingestion/Management (READY WITH MINOR CLARIFICATION)

The data acquisition pipeline in 06-data-acquisition.md is well-designed. The staging schema, adapter pattern, verification engine, and provenance model are all architecturally sound. The minor clarifications needed are:
- Table count (add import_batches and pending_imports to the 56 count)
- HasProvenance trait scope (domain entities or content only?)
- Package version synchronization (activitylog ^4.0 vs ^5.0)

### Area 9: Search (READY WITH MINOR CLARIFICATION)

The search architecture is well-designed with clear source-of-truth separation. The Typesense collections, sync strategy, and detail-page-vs-list data source distinction are all clear. The only issue is ADR-6's "start with PostgreSQL FTS" vs the rest of the documents treating Typesense as active from day one.

### Area 15: Persistence (BLOCKED)

This is the primary blocker. 05-implementation.md contains detailed table schemas that contradict 03-domain.md on:
- Entity ownership (AdmissionPolicy, EligibilityPolicy, AccreditationRecord, AdmissionCycle, InformationSource)
- Enum values (7+ enums with different values)
- VO inventory (12 VOs with only 3-4 overlapping)
- Action list (20 Actions with only ~6 overlapping)
- Relationship structure (polymorphic vs direct FK)

A developer cannot create correct migrations without first resolving which document is authoritative. Since 03-domain.md is the domain model document and is internally coherent, it should be declared authoritative and 05-implementation.md should be corrected to conform.

---

## Non-Blocked Implementation Areas

Implementation CAN begin in these areas immediately:

1. **Laravel project scaffolding** — `composer create-project laravel/laravel studynexus "13.*"`
2. **PostgreSQL + Redis configuration**
3. **Package installation** — all 28 core stack packages are verified and consistent
4. **Auth scaffolding** — Laravel Breeze or Livewire starter kit
5. **RBAC role seeding** — 11 roles are well-defined
6. **OrganizationMember pivot** — schema and model are clear
7. **Reference data tables** — countries, currencies, qualifications, disciplines
8. **Filament v5 admin panel setup**
9. **Pest test framework configuration**
10. **Domain layer implementation from 03-domain.md** — entities, VOs, enums, events, Actions

What CANNOT begin:
1. **Domain migrations** — blocked by schema contradictions
2. **Typesense setup** — blocked by ADR-6 contradiction (minor, can be resolved quickly)
3. **Content layer** — depends on domain layer completion

---

## Readiness Summary

| Status | Count |
|--------|------:|
| READY | 8 |
| READY WITH MINOR CLARIFICATION | 8 |
| BLOCKED | 1 |
| N/A | 1 |
| **Total** | **17** (exceeds 16 because one area is N/A) |

**Implementation can begin in non-blocked areas. The blocked area (persistence/schema) requires resolution of the 03-domain.md vs 05-implementation.md contradictions before migrations can be created.**

---

# Portability Audit

**Audit Date:** 2026-08-10

---

## 1. Core Question

> "Could another competent LLM implement StudyNexus from this baseline without the original conversation?"

**Answer: NO.** The baseline contains contradictions between `03-domain.md` and `05-implementation.md` that would cause different LLMs to produce materially different implementations.

---

## 2. Interpretation Divergence Points

### 2.1 Enum Values

**Problem:** 03-domain.md and 05-implementation.md define different enum values for 7+ enums.

**Divergent interpretations:**
- An LLM following 03-domain.md would create: ScholarshipStatus = Draft, Announced, Open, Closed, Expired, Withdrawn
- An LLM following 05-implementation.md would create: ScholarshipStatus = Active, Closed, Upcoming
- An LLM that tries to merge both would create a broken enum

**Likelihood of divergence:** CERTAIN. No LLM could resolve this without external context.

### 2.2 Action Lists

**Problem:** 03-domain.md lists 20 Actions. 05-implementation.md lists 20 different Actions.

**Divergent interpretations:**
- An LLM following 03-domain.md would implement: SuspendInstitution, CloseInstitution, MergeInstitutions, DiscontinueProgramme, etc.
- An LLM following 05-implementation.md would implement: UpdateInstitution, PublishInstitution, UpdateProgramme, PublishProgramme, etc.

**Likelihood of divergence:** CERTAIN.

### 2.3 Value Object Inventory

**Problem:** 03-domain.md lists 12 genuine VOs. 05-implementation.md lists 12 different non-enum VOs.

**Divergent interpretations:**
- An LLM following 03-domain.md would create: SubjectCombination, QualificationThreshold, TrustSignal, AuthorityJurisdiction, PhaseSequence
- An LLM following 05-implementation.md would create: Address, ContactInfo, Country, Currency, GeographicCoordinates

**Likelihood of divergence:** CERTAIN.

### 2.4 Entity Ownership

**Problem:** AdmissionPolicy, EligibilityPolicy, and AccreditationRecord have different parent entities in the two documents.

**Divergent interpretations:**
- An LLM following 03-domain.md would create polymorphic relationships for AdmissionPolicy and AccreditationRecord, and link EligibilityPolicy to Scholarship
- An LLM following 05-implementation.md would link all to AdmissionCycle or Institution

**Likelihood of divergence:** CERTAIN.

### 2.5 AdmissionCycle Design

**Problem:** 03-domain.md defines AdmissionCycle as an authority-owned aggregate with phases. 05-implementation.md defines it as an institution-owned table with date columns.

**Divergent interpretations:**
- An LLM following 03-domain.md would create a PhaseSequence VO, phase advancement operations, and EducationAuthority ownership
- An LLM following 05-implementation.md would create opens_at/closes_at/results_at columns and Institution ownership

**Likelihood of divergence:** CERTAIN.

### 2.6 InformationSource Design

**Problem:** 03-domain.md defines InformationSource as an aggregate root with lifecycle. 05-implementation.md defines it as a flat table.

**Divergent interpretations:**
- An LLM following 03-domain.md would create register/verify/markUnreliable/deprecate operations
- An LLM following 05-implementation.md would create a simple CRUD resource

**Likelihood of divergence:** CERTAIN.

### 2.7 Search Engine Choice

**Problem:** ADR-6 says start with PostgreSQL FTS. 04-architecture.md and 05-implementation.md describe Typesense as active.

**Divergent interpretations:**
- An LLM reading ADR-6 would implement PostgreSQL FTS first
- An LLM reading 04-architecture.md would set up Typesense from day one

**Likelihood of divergence:** HIGH.

### 2.8 Provenance Model

**Problem:** 06-data-acquisition.md says every domain entity has a provenance JSON column. 03-domain.md and 05-implementation.md don't mention it.

**Divergent interpretations:**
- An LLM reading 06-data-acquisition.md would add provenance columns to all domain tables
- An LLM reading 03-domain.md and 05-implementation.md would not

**Likelihood of divergence:** HIGH.

---

## 3. Cross-Model Comparison

| Model | Would Follow 03-domain.md | Would Follow 05-implementation.md | Would Merge | Would Ask for Clarification |
|-------|:------------------------:|:--------------------------------:|:-----------:|:--------------------------:|
| Claude Code | Likely (domain model is more authoritative) | Possible | Unlikely | Possible |
| GPT/Codex | Possible (implementation blueprint is more actionable) | Likely | Unlikely | Possible |
| Gemini | Unpredictable | Unpredictable | Unlikely | Possible |
| GLM | Unpredictable | Unpredictable | Unlikely | Possible |
| DeepSeek | Unpredictable | Unpredictable | Unlikely | Possible |

**Note:** This table does not speculate about model quality. It identifies that the DOCUMENTATION itself is ambiguous. The question is: "Does the baseline sufficiently constrain interpretation?" The answer is NO.

---

## 4. Where Interpretation Could Diverge Beyond 03-vs-05

Even if the 03-vs-05 contradiction were resolved, these ambiguities remain:

| Ambiguity | Risk Level | Notes |
|-----------|------------|-------|
| HasProvenance trait scope | HIGH | Content-only or domain-wide? |
| ADR-6 Typesense vs PostgreSQL FTS | MEDIUM | Start with which? |
| OrganizationMember morph types | LOW | Which organization types are supported? |
| Discipline initial values | LOW | Non-blocking, seeded during implementation |
| `user_alerts` table | LOW | Not in table count, not in domain model |
| `spatie/laravel-searchable` | LOW | Not in ADR-7, but in package list |

---

## 5. Portability Test Verdict

**Could another LLM reasonably produce a materially different architecture from the same baseline?**

**YES — CERTAIN.** The contradictions between 03-domain.md and 05-implementation.md are so extensive that any LLM would necessarily produce a different implementation depending on which document it prioritizes. The baseline does NOT sufficiently constrain interpretation.

**Required fix:** Explicitly declare 03-domain.md as authoritative for all domain model decisions. Reissue 05-implementation.md to conform. This would reduce the divergence risk from CERTAIN to LOW.

---

## 6. "If the Original Author Disappeared Tomorrow" Test

> "Could a competent engineer reconstruct the intended StudyNexus architecture from this baseline alone?"

**PARTIALLY.** If the engineer:
1. Identified that 03-domain.md is the authoritative domain model → YES, the architecture is reconstructable
2. Followed 05-implementation.md without reading 03-domain.md → NO, they would build a different system
3. Tried to reconcile both → they would be confused and likely contact the author

The baseline is portable ONLY if the precedence between 03-domain.md and 05-implementation.md is explicitly established. Currently it is not.

---

## 7. Missing Knowledge

| Missing Knowledge | Currently Assumed In | Blocking? |
|-------------------|---------------------|-----------|
| Which document is authoritative for domain decisions | All documents | YES |
| Whether to use Typesense or PostgreSQL FTS first | 04-architecture.md vs ADR-6 | NO (can start with either) |
| Whether domain entities have provenance columns | 06-data-acquisition.md vs others | YES (affects schema) |
| What the information quality workflow looks like | 01-business.md (mentioned but not architected) | NO (can be built later) |
| Which organization types OrganizationMember supports | 05-implementation.md | NO (can start with institution only) |

---

# Architecture Audit — Laravel Beyond CRUD

**Audit Date:** 2026-08-10

---

## 1. Justified Architecture

| Pattern | Justification | Verdict |
|---------|--------------|---------|
| Eloquent models as aggregate roots | ADR-1 — eliminates mapping overhead, direct domain behaviour on models | JUSTIFIED — Laravel Beyond CRUD core principle |
| Action classes (20) | ADR-2 — each meets explicit Action Criterion (4 conditions) | JUSTIFIED — prevents Action proliferation |
| Domain events as plain PHP classes | ADR-3, ADR-16 — no shared interface needed, no polymorphic processing | JUSTIFIED — simplest approach that works |
| Custom Eloquent casts for VOs | ADR-4 — type safety without mapping layer | JUSTIFIED |
| Query classes for read models | ADR-5 — cross-aggregate reads without coupling | JUSTIFIED |
| Spatie package adoption | ADR-7 — each package evaluated individually | JUSTIFIED |
| Filament for admin | ADR-8 — rapid admin development, domain logic stays outside | JUSTIFIED |
| Single app with namespace separation | ADR-9 — pragmatic for MVP, refactoring seams for future | JUSTIFIED |
| Domain namespace (App\Domain\) | ADR-10 — domain cohesion, visible in codebase | JUSTIFIED |
| Polymorphic relationships | ADR-11 — AdmissionPolicy and AccreditationRecord share structure across parent types | JUSTIFIED |
| No repositories | ADR-12 — Eloquent IS the repository | JUSTIFIED — avoids unnecessary abstraction |
| Reference data via Filament CRUD | ADR-13 — supporting entities are data, not behaviour | JUSTIFIED |
| Four test layers | ADR-14 — domain tests highest priority | JUSTIFIED |
| InstitutionType/AwardLevel as enums | ADR-15 — enums with behaviour, migration trigger defined | JUSTIFIED |
| Filament v5 + Livewire v4 (TALL stack) | 04-architecture.md P6 — SEO, simplicity, team velocity | JUSTIFIED |
| OrganizationMember pivot with string role | 02-decisions.md — scoped authorization, BookStack-inspired | JUSTIFIED |
| Publication model (is_published + published_at) | DISCOVERY-CLOSURE.md — orthogonal to lifecycle | JUSTIFIED |

---

## 2. Unnecessary Abstraction

| Potential Pattern | Present? | Verdict |
|-------------------|:--------:|---------|
| Repository-for-every-model | NO | CORRECTLY AVOIDED (ADR-12) |
| Generic service layers | NO | CORRECTLY AVOIDED |
| Event sourcing | NO | CORRECTLY AVOIDED (ADR-2 rejected) |
| CQRS framework | NO | CORRECTLY AVOIDED |
| Generic UserInteraction god table | NO | CORRECTLY AVOIDED — separate models for Save, Follow, Like |
| DomainEvent interface/trait | NO | CORRECTLY AVOIDED (ADR-16) |
| laravel-model-states | NO | CORRECTLY AVOIDED — PHP enums + guard clauses |
| Separate domain entity classes alongside Eloquent | NO | CORRECTLY AVOIDED (ADR-1) |

**No unnecessary abstractions detected.** This is a clean Laravel Beyond CRUD implementation.

---

## 3. Missing Architecture

| Gap | Severity | Notes |
|-----|----------|-------|
| Information quality workflow | MEDIUM | 01-business.md Capability #10 mentions user reports entering an "information-quality workflow" but this workflow is not architected. No table, no Actions, no UI for it. |
| Provenance on domain entities | HIGH | 06-data-acquisition.md defines HasProvenance on domain entities but 03-domain.md and 05-implementation.md don't include it. |
| Dead-letter queue for failed indexing | LOW | Acceptable for MVP but should be addressed before production. |
| API rate limiting for scrapers | LOW | Mentioned but not architected in detail. |

---

## 4. Premature Architecture

| Element | Premature? | Verdict |
|---------|:----------:|---------|
| Community module | NO — feature-flagged, separate evolution | CORRECT |
| Study Abroad module | NO — read-only composition, no new aggregates | CORRECT |
| Multi-tenancy package | NO — explicitly rejected | CORRECT |
| ABAC | NO — explicitly rejected | CORRECT |
| Generic Opportunity abstraction | NO — explicitly rejected | CORRECT |
| Multi-language support | NO — deferred to Africa expansion | CORRECT |

**No premature architecture detected.** The baseline demonstrates strong discipline against future-proofing.

---

## 5. Architecture Unsupported by Requirements

| Element | Originating Requirement | Status |
|---------|------------------------|--------|
| `user_alerts` table | 04-architecture.md engagement section | NOT TRACED to a business requirement — appears to be a product feature without business discovery |
| `spatie/laravel-searchable` | 05-implementation.md package list | NOT in ADR-7 or 04-architecture.md — appears without architectural justification |
| `spatie/laravel-honeypot` | 05-implementation.md package list | NOT traced to a requirement — spam protection is sensible but not a documented requirement |

---

## 6. CRUD Disguised as Domain Architecture

| Check | Result |
|-------|--------|
| Are Actions just CRUD wrappers? | NO — each Action meets the Action Criterion with documented justification |
| Are domain methods just setters? | NO — each method enforces invariants and dispatches events |
| Are aggregate boundaries just folder boundaries? | NO — each boundary protects real invariants |
| Are VOs just structs? | NO — each VO has invariants or equality semantics |

**No CRUD disguised as domain architecture.**

---

## 7. Domain Boundaries That Are Merely Folder Boundaries

| Boundary | Real? | Notes |
|----------|:-----:|-------|
| Domain vs Application | YES — domain has no knowledge of auth, search, SEO |
| Content vs Domain | YES — content references domain, not reverse |
| Community vs Domain | YES — feature-flagged, separate evolution |
| StudyAbroad vs Domain | YES — read-only composition |
| Search vs Domain | YES — domain events trigger search, domain unaware of Typesense |

**All boundaries are meaningful.**

---

## 8. Laravel Beyond CRUD Alignment

| Principle | Followed? | Evidence |
|-----------|:---------:|---------|
| Eloquent models as aggregate roots | YES | ADR-1 |
| Actions for meaningful operations | YES | ADR-2, 20 Actions with justification |
| View Models / DTOs via laravel-data | YES | ADR-7 adopts laravel-data for DTOs |
| Domain events | YES | 29 events, plain PHP classes |
| Rich Eloquent models | YES | Domain methods on models, not anemic |
| No repositories unless justified | YES | ADR-12 |
| Pragmatic namespace structure | YES | ADR-10 |
| Spatie ecosystem where appropriate | YES | ADR-7 |

**The architecture is genuinely Laravel Beyond CRUD, not just using its terminology.**

---

## 9. Architecture Audit Verdict

The architecture in `03-domain.md` and `04-architecture.md` is **well-justified, free from unnecessary abstraction, and genuinely follows Laravel Beyond CRUD principles**. Every pattern solves an actual problem. Every rejection is documented with rationale.

The only architectural concerns are:
1. The HasProvenance scope contradiction (content vs domain)
2. The ADR-6 Typesense vs PostgreSQL FTS contradiction
3. The information quality workflow gap
4. The 05-implementation.md divergence from the architecture (this is a documentation problem, not an architecture problem)

**Architecture verdict: SOUND.**

---

# Data Architecture Audit

**Audit Date:** 2026-08-10
**Primary Sources:** `03-domain.md`, `05-implementation.md`, `06-data-acquisition.md`, `04-architecture.md`

---

## 1. Persistence Implications

### 1.1 Can the conceptual model be persisted?

The domain model in `03-domain.md` is persistable. The relationships are clear, cardinalities are defined, and the persistence strategy for each VO is documented (custom casts, JSON columns, backed enums).

### 1.2 Persistence concerns

| Concern | Status | Notes |
|---------|--------|-------|
| Polymorphic relationships (AdmissionPolicy, AccreditationRecord) | DESIGN CORRECT | 03-domain.md uses polymorphic for good reason. 05-implementation.md breaks this. |
| Many-to-many (Scholarship targets Programme) | DESIGN CORRECT | Unidirectional, eventual consistency |
| JSON columns for complex VOs | DESIGN CORRECT | PostgreSQL handles JSON well |
| Append-only AccreditationRecord | DESIGN CORRECT | No mutations, current status derived |
| Cut-off marks table | DESIGN CORRECT | Smallest correct model |
| OrganizationMember pivot | DESIGN CORRECT | String role column, morphable organization |

### 1.3 Persistence problems in 05-implementation.md

| Problem | Severity |
|---------|----------|
| AdmissionPolicy schema uses `admission_cycle_id FK` instead of polymorphic `governable_type`/`governable_id` | CRITICAL — cannot support institutional admission policies |
| EligibilityPolicy schema uses `admission_cycle_id FK` instead of `scholarship_id FK` | CRITICAL — cannot support scholarship eligibility |
| AccreditationRecord schema uses `institution_id FK` instead of polymorphic | HIGH — cannot support programme-level accreditation |
| AdmissionCycle schema uses `institution_id FK` instead of `education_authority_id FK` | HIGH — wrong ownership model |
| InformationSource schema lacks lifecycle columns | HIGH — cannot support aggregate root behaviour |
| No `phase_sequence` or phase columns on AdmissionCycle | HIGH — cannot support phase advancement |

---

## 2. Source Data vs Normalized Data vs Published Data

### 2.1 Is this distinction clear?

**PARTIALLY.** The distinction is present in `06-data-acquisition.md`:

- **Source data:** External sources (JAMB, NUC, institution websites) → raw_data in pending_imports
- **Normalized data:** Adapter normalizes to source-agnostic DTOs → normalized_data in pending_imports
- **Canonical/published data:** Verified records applied to domain aggregates via Actions

### 2.2 Is the operational model clear?

**YES.** `06-data-acquisition.md` clearly defines:
1. External system handles acquisition (scrape → extract → clean → reconcile → human review → approved dataset)
2. StudyNexus receives approved datasets via import
3. Import goes through staging (pending_imports) → verification → application to domain
4. Only verified records update canonical data

### 2.3 Is this distinction reflected in the schema?

**PARTIALLY.** The staging tables (import_batches, pending_imports) are well-designed. But:
- The `provenance` JSON column on domain entities (from HasProvenance trait) is not in 05-implementation.md schemas
- The distinction between "source data" and "canonical data" is clear in 06-data-acquisition.md but not reflected in 03-domain.md (which doesn't mention provenance)

### 2.4 Portability concern

The operational model where data management may occur against a copy of the current database, be manually reviewed/confirmed, and then promoted to production — this workflow is described in 06-data-acquisition.md's staging layer but is NOT explicitly in 03-domain.md or 05-implementation.md. If 06-data-acquisition.md were removed, a developer would not know this workflow exists.

**Verdict: PARTIALLY CLEAR.** The staging/verification model is well-designed but its integration with the domain model (provenance columns) is not consistently documented.

---

## 3. Provenance Audit

### 3.1 Provenance model design

`06-data-acquisition.md` Section 8 defines a comprehensive provenance model:
- Every entity carries a `provenance` JSON column
- Contains: source_type, source_url, acquired_at, last_verified_at, trust_level, verification_status, import_batch_id
- Provenance is immutable once recorded; old provenance archived on update

### 3.2 Provenance integration problems

| Document | Mentions Provenance? | Scope | Consistent? |
|----------|---------------------|-------|:-----------:|
| 03-domain.md | NO | N/A | N/A |
| 04-architecture.md | YES (HasProvenance trait) | Content layer only | Contradicts 06 |
| 05-implementation.md | NO | N/A | Contradicts 06 |
| 06-data-acquisition.md | YES (HasProvenance trait) | Every domain entity | Source of the claim |

The provenance model is designed but not integrated into the canonical domain model or implementation schema. This is a **HIGH severity gap** — a developer would not know to add provenance columns to domain tables.

---

## 4. Reconciliation and Conflict Resolution

### 4.1 Design quality

`06-data-acquisition.md` Section 6 defines:
- Duplicate detection with fuzzy matching (confidence thresholds: ≥0.95 auto-merge, 0.80-0.94 flag for review, 0.50-0.79 likely different, <0.50 distinct)
- Cross-source consistency (official wins, two officials = flag, new vs verified = flag)
- Schema validation against aggregate invariants

This is well-designed and practical.

### 4.2 Integration with domain

The verification engine correctly feeds through existing domain Actions. No new Actions are introduced. This is architecturally sound.

---

## 5. Search/Indexing Audit

### 5.1 Source of truth

**CLEAR.** PostgreSQL is the source of truth. Typesense is a search projection. This is stated consistently in 04-architecture.md (P9), 02-decisions.md (ADR-6), and 05-implementation.md.

### 5.2 What happens when indexes disagree?

**ADDRESSED.** 04-architecture.md states: "If Typesense goes down, the application still functions with degraded search. If PostgreSQL goes down, the application is down." Typesense can be fully rebuilt from PostgreSQL via `scout:import`.

### 5.3 What triggers indexing?

**CLEAR.** Domain events → UpdateSearchIndex listener → queued Scout job → Typesense upsert. Documented in 04-architecture.md Section 3 and 05-implementation.md Section 8.3.

### 5.4 What happens when indexing fails?

**PARTIALLY ADDRESSED.** 05-implementation.md mentions "exponential backoff" and "retries." But no explicit dead-letter queue or alerting mechanism is defined. For MVP this is acceptable.

### 5.5 Are search documents versioned?

**NO.** Search documents are projections, not versioned. This is correct — the database is authoritative, and the search index is rebuilt from it.

### 5.6 ADR-6 contradiction

ADR-6 says "Start with PostgreSQL FTS, switch to Typesense when latency exceeds 200ms." But 04-architecture.md and 05-implementation.md describe Typesense as the active search engine from day one. This is a **MEDIUM** contradiction — a developer doesn't know whether to set up Typesense or use PostgreSQL FTS.

**Recommendation:** Either update ADR-6 to reflect the decision to start with Typesense, or clarify that the Typesense setup is provisioned but PostgreSQL FTS is the initial query engine.

---

## 6. External Integrations Audit

### 6.1 Defined integrations

| Integration | Document | Status |
|-------------|----------|--------|
| JAMB (brochure/data) | 06-data-acquisition.md | Adapter defined (JambOfficialAdapter) |
| NUC (accreditation) | 06-data-acquisition.md | Adapter defined (NucAccreditationAdapter) |
| Institution websites | 06-data-acquisition.md | Adapter defined (InstitutionWebsiteAdapter) |
| Scholarship providers | 06-data-acquisition.md | Adapter defined (ScholarshipProviderAdapter) |
| WAEC | 06-data-acquisition.md | Adapter defined (WaecResultAdapter) |
| SMS (Termii/Twilio) | 04-architecture.md | Channel defined, provider chosen |
| Social login (Google/Microsoft) | 05-implementation.md | laravel/socialite |

### 6.2 Integration risks

- All adapters are designed but none are implemented (pre-implementation)
- Web scraping adapters depend on source website structure (fragile)
- No rate limiting details beyond "1 request/second per domain"
- No fallback strategy if a source disappears permanently

---

## 7. Data Architecture Audit Verdict

| Aspect | Verdict |
|--------|---------|
| Persistence model (03-domain.md) | SOUND |
| Persistence schema (05-implementation.md) | **BROKEN** — contradicts domain model |
| Source/normalized/published distinction | PARTIALLY CLEAR |
| Provenance model | DESIGNED BUT NOT INTEGRATED |
| Reconciliation/conflict resolution | SOUND |
| Search/indexing | SOUND (with ADR-6 contradiction) |
| External integrations | WELL-DEFINED (implementation risk acknowledged) |

---

# Domain Model Audit

**Audit Date:** 2026-08-10
**Primary Source:** `canonical/03-domain.md`

---

## 1. Entity Audit

### 1.1 Aggregate Roots (5)

| Entity | Invariants | Operations | Boundary Justified? | Identity Clear? | Lifecycle Defined? | Verdict |
|--------|-----------|------------|:-------------------:|:---------------:|:------------------:|---------|
| Educational Institution | 5 (INV-I1 through INV-I5) | 7 (establish, rename, suspend, reactivate, close, publishAdmissionPolicy, recordAccreditation) | YES | YES (name + type + country) | YES (Provisional → Operational → Suspended → Closed) | SOUND |
| Programme | 6 (INV-P1 through INV-P6) | 7 (introduce, suspendAdmission, resumeAdmission, discontinue, publishAdmissionPolicy, recordAccreditation, reassignTo) | YES | YES (name + institution) | YES (Prospective → Admitting → Suspended → Discontinued) | SOUND |
| Scholarship | 5 (INV-S1 through INV-S5) | 7 (announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, expire, targetProgrammes) | YES | YES (name + provider) | YES (Draft → Announced → Open → Closed → Expired → Withdrawn) | SOUND |
| Admission Cycle | 3 (INV-C1 through INV-C3) | 5 (announce, activate, advancePhase, close, archive) | YES | YES (authority + period) | YES (Upcoming → Active → Closed → Archived, with phases) | SOUND |
| Information Source | 3 (INV-IS1 through INV-IS3) | 4 (register, verify, markUnreliable, deprecate) | YES | YES (name + reference) | YES (Registered → Verified ↔ Unreliable → Deprecated) | SOUND |

### 1.2 Child Entities (3)

| Entity | Parent | Identity | Lifecycle | Independent Behaviour? | Verdict |
|--------|--------|----------|-----------|:----------------------:|---------|
| Admission Policy | Programme OR Institution (polymorphic) | Per-cycle per-parent | Draft → Published → Superseded → Withdrawn | NO — driven by parent | CORRECT — one-active-per-cycle invariant requires parent control |
| Eligibility Policy | Scholarship | Per-period per-scholarship | Draft → Published → Superseded → Withdrawn | NO — driven by parent | CORRECT — one-active-per-period invariant requires parent control |
| Accreditation Record | Programme OR Institution (polymorphic) | Per-authority per-parent | Immutable after creation | NO — created by parent, never modified | CORRECT — append-only model for accreditation history |

### 1.3 Supporting Entities (3)

| Entity | Behaviour | Justified as Entity? | Verdict |
|--------|-----------|:--------------------:|---------|
| Qualification | deprecate() only | YES — referenced by multiple entities via FK, central deprecation | SOUND |
| Scholarship Provider | deprecate() only (marginal) | MARGINAL — weakest entity. Exists as referential integrity guard. | ACCEPTABLE — demotion to VO would lose deprecation capability |
| Education Authority | deprecate() only (marginal) | YES — referenced by AccreditationRecord, AdmissionCycle, Qualification, AdmissionPathway | SOUND |

---

## 2. Value Object Audit

### 2.1 Genuine Domain VOs (12)

| VO | Immutability | Invariants | Equality | Persistence | Verdict |
|----|:------------:|-----------|----------|-------------|---------|
| AdmissionRule | YES | Rule type determines required fields | Value equality | JSON Cast | SOUND |
| EligibilityRule | YES | Criterion type determines required fields | Value equality | JSON Cast | SOUND |
| SubjectCombination | YES | At least one subject required | Value equality | JSON Cast (nested in AdmissionRule) | SOUND |
| QualificationThreshold | YES | Comparator must be valid | Value equality | JSON Cast (nested in AdmissionRule) | SOUND |
| ValidityPeriod | YES | Start <= end | Date range equality | Custom Cast | SOUND |
| TrustSignal | YES (computed) | N/A (read-only) | Value equality | NEVER stored — computed | SOUND |
| MonetaryAmount | YES | Amount >= 0 for fees | Amount + currency | Custom Cast | SOUND |
| Duration | YES | Value > 0 | Value + unit | Custom Cast | SOUND |
| Location | YES | Country is ISO 3166-1 | All fields | Custom Cast (nullable) | SOUND |
| AuthorityJurisdiction | YES | None (structural) | Value equality | JSON Cast | SOUND |
| PhaseSequence | YES | Phases ordered chronologically | Sequence equality | JSON Cast | SOUND |
| AdmissionPathway | YES | None (structural) | Value equality | Immutable PHP Object | SOUND — correctly demoted from entity |

### 2.2 Enums (16)

3 behavioural enums with domain methods (InstitutionType, AwardLevel, AdmissionMode) — justified.
13 pure enums as closed value sets — justified.

**VO audit verdict: SOUND.** Each VO is individually justified, has clear invariants, and has an appropriate persistence strategy.

---

## 3. Domain Events Audit (29)

Events are well-designed:
- Plain PHP classes (no interface, no trait) — consistent with ADR-3 and ADR-16
- Each event carries sufficient payload for consumers
- Each event has documented consumers
- Rejected events have explicit rationale (CRUD operations without domain significance)

**Notable:** The event names use domain language (InstitutionEstablished, ProgrammeIntroduced) rather than CRUD language (Created, Updated). This is correct for domain events.

**Events audit verdict: SOUND.**

---

## 4. Actions Audit (20)

Each Action meets at least one of the four Action Criterion:
1. Multi-step orchestration
2. Multi-entry-point reuse
3. Significant cascade
4. Authorization + complex validation

The removed Actions (RenameInstitution, ReactivateInstitution, ReassignProgramme) are correctly removed — they are single domain calls with search handled by event listeners.

**Two marginal Actions retained with explicit justification:**
- AnnounceAdmissionCycle (authorization + authority validation)
- TargetScholarshipProgrammes (authorization + programme existence validation + transactional relationship coordination)

These are borderline but the justification is documented. Acceptable.

**Actions audit verdict: SOUND.**

---

## 5. Invariants Audit (25)

Each invariant has:
- Clear entity ownership
- Enforcement location (domain method, read model, application layer)
- Severity classification
- Universal applicability assessment

INV-P3 (query invariant) is correctly identified as a read-model concern, not a write-time check.
INV-9 (reference data constraint) is correctly classified as low severity.

**Invariants audit verdict: SOUND.**

---

## 6. Aggregate Boundaries Audit

| Boundary | Justified? | Could It Survive Implementation? | Issues |
|----------|:----------:|:--------------------------------:|--------|
| Institution | YES | YES | None |
| Programme | YES | YES | Separated from Institution because 50-100+ programmes would create unbounded aggregate |
| Scholarship | YES | YES | None |
| Admission Cycle | YES | YES | Phase sequence is data; sequential ordering invariant is universal |
| Information Source | YES | YES | Trust cascade is the key boundary-defining behaviour |

**Cross-aggregate interaction:** Only InstitutionMerger requires a domain service. All other interactions use IDs and eventual consistency. This is correct.

**Boundaries audit verdict: SOUND.**

---

## 7. Conceptual Confusion Check

### Institution vs Campus
NOT A PROBLEM. The baseline models Institution as a single entity. Campus/location is an attribute (Location VO), not a separate entity. This is appropriate for MVP.

### Institution vs Organization
NOT A PROBLEM. Organization is used in OrganizationMember (the pivot model) as a morphable concept for scoped authorization. Institution is the domain entity. These are different concepts in different layers.

### Programme vs Course
NOT A PROBLEM. The baseline consistently uses "Programme" for a course of study. "Course" is not used as a domain term.

### Programme vs Subject
NOT A PROBLEM. Subject appears within SubjectCombination VO (subjects required for admission). Programme is the course of study. These are clearly different.

### Exam vs Examination Body
NOT A PROBLEM. Examination bodies are modeled as EducationAuthority (supporting entity). "Exam" as a concept appears in ExamPreparation content model, not in the domain model.

### Scholarship vs Scholarship Opportunity
NOT A PROBLEM. The baseline consistently uses "Scholarship" as the entity name. "Scholarship opportunity" is used in business language but maps to the Scholarship entity.

### User vs Student
NOT A PROBLEM. User is an auth concept. Student is a persona. The domain model does not have a Student entity — users interact with the platform through personas but are not modeled as domain entities.

### State vs FCT
NOT IDENTIFIED AS A PROBLEM in the current model. Location VO uses Country + region + city. Nigerian states including FCT are instances of "region." The baseline does not incorrectly model FCT as a conventional state — it simply uses region as a geographic component.

### Current vs Historical Record
WELL HANDLED. Accreditation records are append-only (current derived from sequence). Policies use supersession. Cut-off marks use cross-cycle rows. General changes use activity log. These are distinct, well-modeled strategies.

---

## 8. Domain Boundary Audit

| Boundary | Responsibility | Clear? | Issues |
|----------|---------------|:------:|--------|
| Domain | Business rules, invariants, entities, VOs, events | YES | None |
| Application (Actions, Queries) | Use case orchestration | YES | None |
| Content | Article, Guide, EducationalResource, ExamPreparation | YES | Unidirectional dependency on Domain |
| Community | Q&A module | YES | Feature-flagged, separate evolution |
| StudyAbroad | Read-only composition | YES | No new aggregates, no new invariants |
| Reference | Qualification, Country, Currency, etc. | YES | Managed via Filament CRUD |
| Search | Typesense projections | YES | Domain events trigger indexing |
| SEO | Canonical URLs, structured data | YES | Server-rendered, separate from search |

**Domain boundary audit verdict: SOUND.** Boundaries are meaningful, not merely folder boundaries. Each has a clear responsibility.

---

## 9. Identity and Versioning Audit

### Identity
- Institutions: name uniqueness within country (plus slug)
- Programmes: name uniqueness within institution (plus slug)
- Scholarships: name uniqueness (plus slug)
- Admission Cycles: authority + period
- Information Sources: name + reference

### Versioning Strategy

| Concept | Strategy | Consistent? |
|---------|----------|:-----------:|
| Accreditation | Append-only immutable records | YES |
| Policies | Supersession (Draft → Published → Superseded → Withdrawn) | YES |
| Cut-off marks | Cross-cycle rows, intra-cycle UPDATE | YES |
| Tuition | Current value only (Phase 2 for versioning) | YES |
| General field changes | Activity log | YES |

**No generic versioning framework.** Each concept has its own appropriate strategy. This is correct — different concepts have different versioning needs.

**Identity and versioning audit verdict: SOUND.**

---

## 10. Domain Model Audit Verdict

The domain model in `03-domain.md` is **well-architected, internally coherent, and correctly follows Laravel Beyond CRUD principles**. It is the strongest part of the baseline. The pragmatic DDD approach is correctly applied — no unnecessary abstractions, no ceremonial patterns, every architectural choice justified by a concrete problem.

The only weakness is that `05-implementation.md` does not conform to this domain model. This is not a domain model defect — it is an implementation documentation defect.

**Overall domain model verdict: SOUND.**

---

# Traceability Matrix

**Audit Date:** 2026-08-10

---

## Methodology

Each major requirement from 01-business.md is traced through the chain: Requirement → Domain Concept → Business Rule → Application Behavior → Architecture → Data Implications. Broken chains are flagged.

---

## Traceability Table

### R-01: Aggregate educational information from disparate sources

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #1 (Acquire Educational Information) | ✅ |
| Domain Concept | 03-domain.md: InformationSource aggregate root | ✅ |
| Business Rule | 03-domain.md: INV-IS1, INV-IS2, INV-IS3 | ✅ |
| Application Behavior | 03-domain.md: RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable Actions | ✅ |
| Architecture | 04-architecture.md: Domain layer; 06-data-acquisition.md: Adapter + Staging + Verification pipeline | ✅ |
| Data Implications | 05-implementation.md: information_sources table | ⚠️ Schema does not match domain model (missing lifecycle fields) |
| **Chain Status** | **BROKEN at data layer** — 05-implementation.md schema doesn't support InformationSource as aggregate root |

### R-02: Organize educational information into structured, comparable knowledge

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #2 (Organize Educational Knowledge) | ✅ |
| Domain Concept | 03-domain.md: Institution, Programme, Scholarship, AdmissionCycle, AdmissionPolicy, AccreditationRecord | ✅ |
| Business Rule | 03-domain.md: All invariants (INV-I1 through INV-C3) | ✅ |
| Application Behavior | 03-domain.md: 20 Actions | ✅ |
| Architecture | 04-architecture.md: Domain layer, search architecture | ✅ |
| Data Implications | 05-implementation.md: Domain table schemas | ⚠️ Schemas contradict domain model |
| **Chain Status** | **BROKEN at data layer** |

### R-03: Verify educational information reliability

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #3 (Verify Educational Information) | ✅ |
| Domain Concept | 03-domain.md: InformationSource lifecycle, TrustSignal VO | ✅ |
| Business Rule | 03-domain.md: INV-IS1, INV-IS2; 01-business.md: Trust signals (OQ6-8) | ✅ |
| Application Behavior | 03-domain.md: VerifyInformationSource, MarkSourceUnreliable Actions | ✅ |
| Architecture | 04-architecture.md: Trust signal recalculation via event listeners | ✅ |
| Data Implications | 05-implementation.md: verification_status column | ⚠️ Simplified enum, no lifecycle |
| **Chain Status** | **BROKEN at data layer** |

### R-04: Maintain educational knowledge (keep current, historically traceable)

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #4 (Maintain Educational Knowledge) | ✅ |
| Domain Concept | 03-domain.md: AccreditationRecord (append-only), PolicyStatus supersession, cut_off_marks table | ✅ |
| Business Rule | 03-domain.md: Immutable accreditation records; supersession model | ✅ |
| Application Behavior | 03-domain.md: RecordAccreditation Action | ✅ |
| Architecture | 04-architecture.md: spatie/laravel-activitylog for audit trail | ✅ |
| Data Implications | 05-implementation.md: accreditation_records table | ⚠️ Missing polymorphic parent, missing ValidityPeriod VO |
| **Chain Status** | **BROKEN at data layer** |

### R-05: Discover educational opportunities (structured exploration)

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #5 (Discover Educational Opportunities) | ✅ |
| Domain Concept | 03-domain.md: Programme, Discipline reference data | ✅ |
| Business Rule | 01-business.md: BR-WF1-1 (support users who don't know exact names) | ✅ |
| Application Behavior | 04-architecture.md: Typesense faceted search, Livewire components | ✅ |
| Architecture | 04-architecture.md: Search architecture, SEO architecture | ✅ |
| Data Implications | 05-implementation.md: Typesense collections, disciplines table | ✅ |
| **Chain Status** | **COMPLETE** |

### R-06: Search educational knowledge (direct search)

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #6 (Search Educational Knowledge) | ✅ |
| Domain Concept | 03-domain.md: All searchable entities | ✅ |
| Business Rule | None specific | ✅ |
| Application Behavior | 04-architecture.md: Typesense search, Scout integration | ✅ |
| Architecture | 04-architecture.md: Search architecture | ✅ |
| Data Implications | 05-implementation.md: Typesense collections | ✅ |
| **Chain Status** | **COMPLETE** |

### R-07: Compare educational opportunities

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #7 (Compare Educational Opportunities) | ✅ |
| Domain Concept | 03-domain.md: Standardized VOs (MonetaryAmount, Duration, etc.) | ✅ |
| Business Rule | 01-business.md: BR-WF3-1 (standardized information) | ✅ |
| Application Behavior | 04-architecture.md: Comparison architecture (Livewire component, session/DB) | ✅ |
| Architecture | 04-architecture.md: Engagement architecture | ✅ |
| Data Implications | 05-implementation.md: comparison_sets table | ✅ |
| **Chain Status** | **COMPLETE** |

### R-08: Present educational knowledge clearly and accessibly

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #8 (Present Educational Knowledge) | ✅ |
| Domain Concept | All domain entities | ✅ |
| Business Rule | 01-business.md: Trust signals presentation (BR-WF5-1) | ✅ |
| Application Behavior | 04-architecture.md: Blade templates, Livewire components | ✅ |
| Architecture | 04-architecture.md: SEO architecture, content architecture | ✅ |
| Data Implications | 05-implementation.md: Content tables, SEO columns | ✅ |
| **Chain Status** | **COMPLETE** |

### R-09: Preserve information provenance

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #9 (Preserve Information Provenance) | ✅ |
| Domain Concept | 03-domain.md: InformationSource, TrustSignal | ✅ |
| Business Rule | 03-domain.md: Provenance metadata on entities | ✅ |
| Application Behavior | 06-data-acquisition.md: Provenance model with HasProvenance trait | ✅ |
| Architecture | 04-architecture.md: HasProvenance listed as content trait only | ⚠️ Scope conflict |
| Data Implications | 06-data-acquisition.md: provenance JSON column; 05-implementation.md: not in schemas | ⚠️ Contradiction |
| **Chain Status** | **BROKEN at architecture and data layer** — HasProvenance scope is contradicted |

### R-10: Manage information quality

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #10 (Manage Information Quality) | ✅ |
| Domain Concept | 01-business.md: User reports enter information-quality workflow | ✅ |
| Business Rule | 01-business.md OQ4-2: Reports don't directly modify canonical data | ✅ |
| Application Behavior | Not explicitly defined in canonical documents | ⚠️ Gap |
| Architecture | Not explicitly defined | ⚠️ Gap |
| Data Implications | No table for information quality reports | ⚠️ Gap |
| **Chain Status** | **BROKEN at application behavior and below** — information quality workflow is referenced but not architected |

### R-11: Data acquisition and ingestion pipeline

| Layer | Location | Status |
|-------|----------|--------|
| Requirement | 01-business.md Capability #1; 06-data-acquisition.md | ✅ |
| Domain Concept | 03-domain.md: ImportInstitutionData Action, InformationSource | ✅ |
| Business Rule | 06-data-acquisition.md: 5 design principles | ✅ |
| Application Behavior | 06-data-acquisition.md: Adapter, Staging, Verification, Application pipeline | ✅ |
| Architecture | 06-data-acquisition.md: Full architecture diagram | ✅ |
| Data Implications | 06-data-acquisition.md: import_batches, pending_imports tables | ⚠️ Not in 05-implementation.md table count |
| **Chain Status** | **BROKEN at data layer** — tables not counted in schema inventory |

---

## Broken Chain Summary

| # | Requirement | Broken At | Reason |
|---|------------|-----------|--------|
| 1 | Acquire Information | Data layer | 05-implementation.md InformationSource schema doesn't match domain model |
| 2 | Organize Knowledge | Data layer | 05-implementation.md schemas contradict domain model |
| 3 | Verify Information | Data layer | 05-implementation.md lacks InformationSource lifecycle |
| 4 | Maintain Knowledge | Data layer | 05-implementation.md AccreditationRecord schema incorrect |
| 9 | Preserve Provenance | Architecture + Data | HasProvenance scope contradicted |
| 10 | Manage Info Quality | Application + Architecture + Data | Information quality workflow not architected |
| 11 | Data Acquisition | Data layer | Tables not in schema inventory |

**7 of 11 traceability chains are broken.** All breaks occur at the implementation/data layer, specifically in 05-implementation.md's failure to conform to 03-domain.md.

---

## Architecture Without Originating Requirement

| Architectural Element | Originating Requirement | Status |
|----------------------|------------------------|--------|
| Community module (Q&A) | Not in MVP capabilities | ✅ Explicitly Phase 2, feature-flagged |
| Study Abroad module | Not in MVP capabilities | ✅ Explicitly Phase 2, feature-flagged |
| Exam Preparation content | Not in MVP capabilities | ✅ Explicitly Phase 2 |
| `user_alerts` table | Not traced to a requirement | ⚠️ Appears in 04-architecture.md engagement section but not in 05-implementation.md table count |
| `spatie/laravel-searchable` | Not in ADR-7 package evaluation | ⚠️ Appears in 05-implementation.md without architectural justification |

---

## Traceability Verdict

The traceability from requirements through domain model is strong. The traceability from domain model through architecture is adequate. The traceability from architecture through implementation (schema) is **broken** for the majority of requirements, entirely due to 05-implementation.md's divergence from 03-domain.md.

---

# Cross-Document Consistency Audit

**Audit Date:** 2026-08-10

---

## 1. Terminology Consistency

### 1.1 Entity Naming

| Concept | 03-domain.md | 05-implementation.md | Consistent? |
|---------|-------------|---------------------|:-----------:|
| Educational Institution | "Educational Institution" / "Institution" | "Institution" | YES |
| Programme | "Programme" | "Programme" | YES |
| Scholarship | "Scholarship" | "Scholarship" | YES |
| Admission Cycle | "Admission Cycle" | "AdmissionCycle" | YES |
| Information Source | "Information Source" | "InformationSource" | YES |
| Admission Policy | "Admission Policy" (child of Programme/Institution) | "AdmissionPolicy" (child of AdmissionCycle) | NAME YES, OWNERSHIP NO |
| Eligibility Policy | "Eligibility Policy" (child of Scholarship) | "EligibilityPolicy" (child of AdmissionCycle) | NAME YES, OWNERSHIP NO |
| Accreditation Record | "Accreditation Record" (child of Programme/Institution) | "AccreditationRecord" (child of Institution) | NAME YES, OWNERSHIP NO |
| Scholarship Provider | "Scholarship Provider" (supporting entity) | "ScholarshipProvider" (supporting entity + polymorphic provider) | NAME YES, TYPE NO |
| Education Authority | "Education Authority" | "EducationAuthority" | YES |
| Qualification | "Qualification" (supporting entity in Domain) | "Qualification" (moved to Reference namespace) | NAME YES, LOCATION NO |

### 1.2 Enum Naming

| Concept | 03-domain.md | 05-implementation.md | Consistent? |
|---------|-------------|---------------------|:-----------:|
| Institution Type | InstitutionType | InstitutionType | YES (name) but different values |
| Award Level | AwardLevel | AwardType / ProgrammeLevel | NO |
| Admission Mode | AdmissionMode | ModeOfStudy | NO |
| Programme Status | ProgrammeStatus | ProgrammeStatus | YES (after correction) |
| Scholarship Status | ScholarshipStatus | ScholarshipStatus | YES (name) but different values |
| Delivery Mode | DeliveryMode | ModeOfStudy | NO |
| Source Reliability | SourceReliability | VerificationStatus | NO |
| Policy Status | PolicyStatus (Draft, Published, Superseded, Withdrawn) | PolicyStatus (Draft, Published, Superseded) | NO (missing Withdrawn) |

### 1.3 VO Naming

| 03-domain.md | 05-implementation.md | Match? |
|-------------|---------------------|:------:|
| MonetaryAmount | Money / ScholarshipAmount | NO |
| Location | Address / GeographicCoordinates / Country | NO |
| AdmissionRule | AdmissionRule | YES |
| ValidityPeriod | ValidityPeriod | YES |
| Duration | Duration | YES |
| TrustSignal | AdmissionStatus | NO |
| AuthorityJurisdiction | (not present) | NO |
| PhaseSequence | (not present) | NO |
| SubjectCombination | (not present) | NO |
| QualificationThreshold | (not present) | NO |
| AdmissionPathway | AdmissionPathway (enum in 05) | NO (VO in 03, enum in 05) |
| EligibilityRule | EligibilityCriterion | NO |

### 1.4 Terminology Verdict

**INCONSISTENT.** The terminology drift between 03-domain.md and 05-implementation.md is pervasive. It affects enums, VOs, entity ownership, and Action names. This is not minor naming variation — it represents different conceptual models.

---

## 2. Domain Consistency

The domain model in 03-domain.md is internally consistent. The problem is that 05-implementation.md presents a different domain model:

- Different aggregate boundaries (AdmissionCycle owned by Institution vs EducationAuthority)
- Different child entity ownership (AdmissionPolicy child of AdmissionCycle vs Programme/Institution)
- Different entity behaviour (InformationSource as flat table vs aggregate root with lifecycle)
- Different provider model (Scholarship polymorphic provider vs FK to ScholarshipProvider)

**Domain consistency verdict: INCONSISTENT across documents, consistent within 03-domain.md.**

---

## 3. Business-Rule Consistency

Business rules from 01-business.md are well-traced to 03-domain.md (invariants, workflows, capabilities). The domain model correctly implements the business rules.

However, 05-implementation.md's schemas do not support several business rules:
- INV-I3 (one active institutional Admission Policy per Admission Cycle) — cannot be enforced when AdmissionPolicy belongs to AdmissionCycle rather than Institution
- INV-S2 (one active Eligibility Policy per period) — cannot be enforced when EligibilityPolicy belongs to AdmissionCycle rather than Scholarship
- INV-IS1 (source cannot be simultaneously verified and unreliable) — no lifecycle methods on InformationSource in 05-implementation.md
- INV-C2 (phase transitions follow defined sequence) — no phases in 05-implementation.md's AdmissionCycle

**Business-rule consistency verdict: CONSISTENT between 01-business.md and 03-domain.md. INCONSISTENT between 03-domain.md and 05-implementation.md.**

---

## 4. Lifecycle Consistency

| Entity | 03-domain.md Lifecycle | 05-implementation.md Lifecycle | Consistent? |
|--------|----------------------|------------------------------|:-----------:|
| Institution | Provisional → Operational → Suspended → Closed | (same after correction) | YES |
| Programme | Prospective → Admitting → Suspended → Discontinued | (same after correction) | YES |
| Scholarship | Draft → Announced → Open → Closed → Expired → Withdrawn | Active → Closed → Upcoming | NO |
| Admission Cycle | Upcoming → Active → Closed → Archived (with phases) | (opens_at/closes_at/results_at, no states) | NO |
| Information Source | Registered → Verified ↔ Unreliable → Deprecated | Pending → Verified → Rejected | NO |
| Admission Policy | Draft → Published → Superseded → Withdrawn | Draft → Published → Superseded | NO (missing Withdrawn) |

**Lifecycle consistency verdict: INCONSISTENT.**

---

## 5. Versioning Consistency

The versioning strategy is consistent across documents:
- Accreditation: append-only immutable records (03-domain.md, DISCOVERY-CLOSURE.md)
- Policies: supersession model (03-domain.md)
- Cut-off marks: cross-cycle rows, intra-cycle UPDATE (03-domain.md, DISCOVERY-CLOSURE.md)
- General changes: activity log (all documents)
- No event sourcing, no generic versioning framework (consistent)

**Versioning consistency verdict: CONSISTENT.**

---

## 6. Data-Source Consistency

06-data-acquisition.md is consistent with 03-domain.md on:
- Source taxonomy
- Verification engine
- Import workflow
- Provenance recording
- Integration through existing domain Actions

06-data-acquisition.md is INCONSISTENT with 05-implementation.md on:
- Table count (adds 2 tables)
- HasProvenance trait scope
- Package versions (activitylog ^5.0 vs ^4.0)

**Data-source consistency verdict: CONSISTENT with 03-domain.md, INCONSISTENT with 05-implementation.md.**

---

## 7. Architectural Consistency

04-architecture.md is largely consistent with 03-domain.md and 02-decisions.md. The main inconsistency is:
- ADR-6 says "Start with PostgreSQL FTS" but 04-architecture.md Section 2 lists Typesense as part of the active stack
- spatie/laravel-searchable appears in 05-implementation.md but not in 04-architecture.md's package list or 02-decisions.md ADR-7

**Architectural consistency verdict: MOSTLY CONSISTENT, with minor exceptions.**

---

## 8. Scope Consistency

Scope is consistent across documents:
- MVP = Stage 1 (Trusted Education Knowledge Base)
- First vertical slice = programme discovery
- Scholarship public pages = Phase 2
- Community = Phase 2, feature-flagged
- No user accounts required for core MVP

DISCOVERY-CLOSURE.md clarifies scholarship scope (entity + admin CRUD in first slice, public pages Phase 2). This is consistent with PRODUCT-EXPERIENCE-ARCHITECTURE.md's MVP scope table.

**Scope consistency verdict: CONSISTENT.**

---

## 9. Summary

| Dimension | Verdict |
|-----------|---------|
| Terminology | INCONSISTENT |
| Domain model | INCONSISTENT (03 vs 05) |
| Business rules | INCONSISTENT (03 vs 05) |
| Lifecycle | INCONSISTENT |
| Versioning | CONSISTENT |
| Data source | CONSISTENT with 03, INCONSISTENT with 05 |
| Architecture | MOSTLY CONSISTENT |
| Scope | CONSISTENT |

The pattern is clear: **03-domain.md is the center of consistency, and 05-implementation.md is the source of inconsistency.** Every contradiction involves 05-implementation.md diverging from the domain model. The resolution is to align 05-implementation.md to 03-domain.md.

---

# Document-by-Document Audit

**Audit Date:** 2026-08-10

---

## 1. README.md

**Purpose:** Baseline description, directory structure, authority hierarchy, key commitments summary.
**Strengths:** Clear authority hierarchy (canonical > archive). Good key commitments table. Clean directory structure.
**Weaknesses:** Does not establish precedence between canonical documents. States "44 files" in one section and "43 preserved source files" in another (minor).
**Missing information:** No explicit statement that 03-domain.md overrides 05-implementation.md for domain decisions.
**Contradictions:** None directly.
**Dependencies:** References all canonical documents.
**Readiness rating:** READY

---

## 2. canonical/01-business.md

**Purpose:** Business vision, personas, problem space, capabilities, workflows, glossary.
**Strengths:** Comprehensive. Well-structured. Personas are clearly defined with priority ranking. Workflows are goal-defined, not activity-defined. Problem dimensions are complete and justified. Capabilities have clear relationships. The 40 approved decisions (A0-1 through A9-3) are well-documented with rationale.
**Weaknesses:** None material.
**Missing information:** Business model/revenue model explicitly deferred (OQ4-4). This is documented as deferred, not missing.
**Contradictions:** None with other canonical documents.
**Dependencies:** Source documents in archive (01-business-overview.md, 02-glossary.md, 04-open-questions.md, 06-business-workflows.md, 07-business-discovery-closure.md).
**Readiness rating:** READY

---

## 3. canonical/02-decisions.md

**Purpose:** ADRs, resolved open questions, rejected alternatives, change proposal protocol.
**Strengths:** Excellent ADR documentation. Each ADR has context, decision, consequences. Rejected alternatives have explicit rationale. Change proposal protocol is well-defined. The 22 resolved open questions are clearly documented. RBAC section is thorough.
**Weaknesses:** Section 5.3 references OrganizationMember pivot with `organization_type` morph but does not specify which organization types are supported (institution only? scholarship_provider? education_authority?). ADR-6 says "Start with PostgreSQL FTS" but 04-architecture.md and 05-implementation.md describe Typesense as active — this contradiction is not flagged.
**Missing information:** Precedence between canonical documents not established.
**Contradictions:** ADR-6 (PostgreSQL FTS first) vs 04-architecture.md/05-implementation.md (Typesense active from start).
**Dependencies:** 01-business.md, archived discovery documents.
**Readiness rating:** READY WITH MINOR CLARIFICATION

---

## 4. canonical/03-domain.md

**Purpose:** Domain model — entities, VOs, events, actions, enums, invariants, behaviours, aggregate boundaries, relationships.
**Strengths:** Internally coherent. Well-justified aggregate boundaries. Pragmatic DDD approach correctly applied. Each entity has documented invariants, operations, and lifecycle. Action Criterion is explicit and applied consistently. VO classification (genuine vs enum) is clear. Domain events are well-designed with documented consumers. The rejection of repositories, event sourcing, and model-states is well-justified. Reference data (Discipline, CutOffMark) is correctly separated from domain entities. The global-first principle is consistently applied — Nigerian concepts are instances, not structure.
**Weaknesses:** Section 10 (Entity Relationships) references Qualification belongingTo EducationAuthority, but Qualification is later moved to Reference namespace in 05-implementation.md (change R5). This move is not reflected in 03-domain.md. The relationship from 03-domain.md is stale.
**Missing information:** No mention of HasProvenance trait or provenance columns on domain entities (introduced in 06-data-acquisition.md).
**Contradictions:** None internally. Extensive contradictions with 05-implementation.md (see Contradiction Register).
**Dependencies:** 01-business.md, 02-decisions.md.
**Readiness rating:** READY — this is the strongest document in the baseline.

---

## 5. canonical/04-architecture.md

**Purpose:** Platform architecture, technology stack, search, SEO, content, notifications, engagement, admin panel, packages.
**Strengths:** Comprehensive architecture. Clear layering (Presentation → Application → Domain). Namespace dependency rules are excellent. Search architecture is well-designed with clear source-of-truth separation. SEO architecture is thorough. Publication/Visibility model (Section 5.5) is well-defined. Content architecture with shared traits is pragmatic. Package evaluation is thorough with documented rejections.
**Weaknesses:** Lists Typesense as part of the active stack (Section 2) while ADR-6 says start with PostgreSQL FTS. This is not flagged as a contradiction. Section 11 lists `spatie/laravel-tags` ^4.0 and `spatie/laravel-sluggable` ^3.0, while 05-implementation.md lists ^4.0 for sluggable. Section 9 mentions `user_alerts` table but this is not in the 56-table count from 05-implementation.md.
**Missing information:** `user_alerts` table not in schema inventory.
**Contradictions:** Typesense vs PostgreSQL FTS (with ADR-6). HasProvenance trait scope (content only vs domain). spatie/laravel-searchable not mentioned (but listed in 05-implementation.md).
**Dependencies:** 03-domain.md, 02-decisions.md.
**Readiness rating:** READY WITH MINOR CLARIFICATION

---

## 6. canonical/05-implementation.md

**Purpose:** Implementation blueprint — schemas, packages, migration order, phase sequence.
**Strengths:** Detailed table schemas. Clear migration dependency order. Phase sequence is well-planned. Package matrix is comprehensive. Feature flags are well-defined. Architectural drift guards are excellent. The Phase 1a step-by-step is actionable.
**Weaknesses:** **This document is the primary source of contradictions in the baseline.** It contradicts 03-domain.md on virtually every entity definition, enum value, VO inventory, Action list, and child entity ownership. The schemas are written as if from a different mental model of the domain than 03-domain.md. It also contains internal contradictions (e.g., Scholarship has polymorphic provider but ScholarshipProvider is also listed as supporting entity).
**Missing information:** `import_batches` and `pending_imports` tables not counted. `user_alerts` table not counted. `notification_preferences` may not be counted.
**Contradictions:** See Contradiction Register C-01 through C-18. This document is involved in every CRITICAL contradiction.
**Dependencies:** 03-domain.md (which it should conform to but doesn't), 04-architecture.md.
**Readiness rating:** **BLOCKED** — requires comprehensive correction to align with 03-domain.md.

---

## 7. canonical/06-data-acquisition.md

**Purpose:** Data acquisition pipeline, staging schema, adapter pattern, verification engine, import workflow, provenance model.
**Strengths:** Well-designed pipeline architecture. Clear separation of external acquisition from internal ingestion. Staging schema is practical. Verification engine with fuzzy matching and conflict detection is thorough. Provenance model is well-designed. The adapter pattern is clean and extensible. Integration with existing domain Actions is correctly noted — no new Actions needed.
**Weaknesses:** Introduces `import_batches` and `pending_imports` tables not in the 56-table count. Introduces HasProvenance trait on domain entities not in 03-domain.md. Section 11 states "RBAC is enforced via bezhansalleh/filament-shield with the 11-role model using a string role column on the users table" — this is wrong, the string role is on organization_members. Lists `spatie/laravel-activitylog` ^5.0 while other docs use ^4.0. Mentions `smalot/pdfparser` ^2.0 and `spatie/crawler` ^1.0 as new packages — these are not in 05-implementation.md's package matrix.
**Missing information:** Table count update. Package matrix update.
**Contradictions:** HasProvenance scope (C-09). Table count (C-08). RBAC string column location (C-10). activitylog version (C-17).
**Dependencies:** 03-domain.md, 05-implementation.md.
**Readiness rating:** READY WITH MINOR CLARIFICATION — the pipeline design is sound but integration points need synchronization.

---

## 8. product-experience/PRODUCT-EXPERIENCE-ARCHITECTURE.md

**Purpose:** UX discovery, experience domains, user journeys, decision models, information architecture.
**Strengths:** Excellent user-centered design thinking. Decision models map directly to business workflows. Journey mapping is realistic. Cross-domain experience design is well-thought-out. The admission evaluation model correctly identifies cut-off marks as the most critical information.
**Weaknesses:** References scholarship detail pages and scholarship search in journey 5, but DISCOVERY-CLOSURE.md defers these to Phase 2. The document should clarify that the scholarship journey is contextual-only for MVP.
**Missing information:** None material.
**Contradictions:** Minor — scholarship journey scope vs DISCOVERY-CLOSURE.md deferral.
**Dependencies:** 01-business.md (workflows, personas), 03-domain.md (domain concepts).
**Readiness rating:** READY

---

## 9. product-experience/FIRST-VERTICAL-SLICE-UX.md

**Purpose:** UX specification for the first vertical slice (programme discovery).
**Note:** This document was not fully read in this audit pass due to size constraints. Spot-checking revealed it is consistent with the product experience architecture and defines the programme discovery user experience in detail.
**Readiness rating:** READY (based on spot-check)

---

## 10. product-experience/FIRST-VERTICAL-SLICE-UI.md

**Purpose:** Visual UI specification — design tokens, components, screens.
**Note:** This document was not fully read in this audit pass due to size constraints. Spot-checking revealed it defines the visual design system for the first vertical slice.
**Readiness rating:** READY (based on spot-check)

---

## 11. governance/DISCOVERY-CLOSURE.md

**Purpose:** Final discovery closure — decision triage, publication modeling, cut-off history, discipline taxonomy, scholarship MVP scope, acquisition handoff contract, data completeness, detail page data source.
**Strengths:** Thorough decision triage with clear A/B/C classification. Publication model is well-reasoned. Cut-off history analysis is excellent. Discipline taxonomy decisions are practical. The handoff contract is well-defined and implementation-neutral.
**Weaknesses:** The triage table identifies T-02 (ProgrammeStatus/InstitutionStatus inconsistency in 05-implementation.md) but the CANONICAL-UPDATE-REPORT.md only corrects some of the enum inconsistencies, missing the broader pattern of contradictions between 03-domain.md and 05-implementation.md.
**Missing information:** Does not address the full scope of 03-vs-05 contradictions.
**Contradictions:** None directly — this document identifies and resolves issues, but its resolution is incomplete.
**Dependencies:** All canonical documents, product-experience documents.
**Readiness rating:** READY

---

## 12. governance/CANONICAL-UPDATE-REPORT.md

**Purpose:** Report of 12 canonical changes applied during reconciliation.
**Strengths:** Clear documentation of what changed and why. Good cross-reference updating. Honest about remaining non-blocking issues.
**Weaknesses:** **Critically incomplete.** Identifies and corrects only a subset of the contradictions between 03-domain.md and 05-implementation.md. The ScholarshipStatus discrepancy is noted as "non-blocking" — it is not non-blocking. The document does not address: different Action lists, different VO inventories, different child entity ownership, different AdmissionCycle definition, different InformationSource definition, different AccreditationRecord schema, different AdmissionPolicy schema, different EligibilityPolicy parent, different Scholarship Provider type, different enum values for 7+ enums.
**Missing information:** The majority of the contradictions documented in this audit's Contradiction Register.
**Contradictions:** Claims "Verification Results: all checks pass" but this is only true for the narrow set of metrics it checks. The broader cross-document consistency is not verified.
**Dependencies:** All canonical documents.
**Readiness rating:** READY WITH MAJOR CAVEAT — the report is incomplete and gives a false impression of full consistency.

---

# Assumption Register

**Audit Date:** 2026-08-10

---

## Classification Model

- **EXPLICITLY DECIDED:** Stated as a decision in the baseline, with rationale and authority.
- **STRONGLY IMPLIED:** Not stated as a decision but derivable from multiple consistent references.
- **WEAKLY IMPLIED:** Derivable from a single reference or from indirect context.
- **UNSUPPORTED ASSUMPTION:** An assumption that implementation would depend upon but that is not grounded in the baseline.
- **CONTRADICTED:** An assumption that the baseline both supports and contradicts.

---

## Assumption Inventory

### A-01: 03-domain.md is authoritative over 05-implementation.md

**Classification:** STRONGLY IMPLIED
**Evidence:** README states canonical documents are authoritative. 02-decisions.md states architecture is frozen per 21-domain-architecture-frozen-baseline.md (which 03-domain.md derives from). CANONICAL-UPDATE-REPORT.md corrects 05-implementation.md to match 03-domain.md (for some values). However, no document explicitly states "03-domain.md overrides 05-implementation.md for domain decisions."
**Why it matters:** Without this precedence, a developer cannot resolve the 7 CRITICAL contradictions. They must guess which document to follow.
**Risk if wrong:** Materially different implementation.

### A-02: PostgreSQL is the canonical source of truth

**Classification:** EXPLICITLY DECIDED
**Evidence:** 04-architecture.md P9, 02-decisions.md ADR-6, README key commitments table.
**Why it matters:** Determines that Typesense is a projection and can be rebuilt from PostgreSQL.

### A-03: Typesense is the search engine from day one

**Classification:** CONTRADICTED
**Evidence:** 04-architecture.md Section 2 lists Typesense as part of the stack. 04-architecture.md Section 5 describes Typesense collections and sync. BUT ADR-6 in 02-decisions.md says "Start with PostgreSQL full-text search as the initial implementation. Switch to Typesense via Scout when PostgreSQL FTS latency exceeds 200ms at 10k programmes." 05-implementation.md Section 8 describes Typesense implementation as active.
**Why it matters:** A developer doesn't know whether to set up Typesense or use PostgreSQL FTS first.
**Risk if wrong:** Unnecessary infrastructure setup or missing search capability.

### A-04: The HasProvenance trait applies to domain entities

**Classification:** CONTRADICTED
**Evidence:** 06-data-acquisition.md Section 8 states "Every entity in the canonical store carries provenance metadata" via HasProvenance trait. 04-architecture.md Section 7 lists HasProvenance as a content-layer trait. 03-domain.md does not mention it. 05-implementation.md does not include provenance columns in domain table schemas.
**Why it matters:** Determines whether domain migrations need a `provenance` JSON column.
**Risk if wrong:** Missing provenance data or unnecessary schema complexity.

### A-05: The 56-table count is complete

**Classification:** UNSUPPORTED ASSUMPTION
**Evidence:** 05-implementation.md states 56 tables. 06-data-acquisition.md adds 2 more tables (import_batches, pending_imports). The 56 count does not include these. It also may not include `notification_preferences` (listed in 04-architecture.md but not clearly in the 56 count).
**Why it matters:** Table count is used as a verification metric. An incorrect count undermines confidence in the schema inventory.
**Risk if wrong:** Missing tables during migration creation.

### A-06: AdmissionPathway is a Value Object, not an enum

**Classification:** EXPLICITLY DECIDED
**Evidence:** 03-domain.md Section 3 VO #12, 02-decisions.md explicitly rejected Admission Pathway as entity and confirmed it as VO. CANONICAL-UPDATE-REPORT.md confirms.
**Why it matters:** No separate table for admission pathways. Stored as a value within AdmissionPolicy.

### A-07: Discipline is reference data, not a domain entity

**Classification:** EXPLICITLY DECIDED
**Evidence:** 03-domain.md Section 12, CANONICAL-UPDATE-REPORT.md change #4.
**Why it matters:** No lifecycle, no invariants, managed via Filament CRUD.

### A-08: Publication is orthogonal to lifecycle

**Classification:** EXPLICITLY DECIDED
**Evidence:** 03-domain.md Section 8 (all entity behaviours), 04-architecture.md Section 5.5, DISCOVERY-CLOSURE.md Section 2, CANONICAL-UPDATE-REPORT.md changes #1-3.
**Why it matters:** `is_published` + `published_at` are separate from status enum. Visibility = is_published AND lifecycle allows.

### A-09: The 11-role RBAC model uses string role on OrganizationMember

**Classification:** EXPLICITLY DECIDED
**Evidence:** 02-decisions.md Section 5, 04-architecture.md Section 4.
**Why it matters:** Institution-scoped roles are NOT Spatie roles. Same user can have different roles per institution.

### A-10: Laravel 13 / PHP 8.5 / Filament v5 / Livewire v4 are the platform

**Classification:** EXPLICITLY DECIDED
**Evidence:** 02-decisions.md Section 4, 04-architecture.md Section 2, 05-implementation.md Section 1.
**Why it matters:** All package versions and code patterns must target these versions.

### A-11: No repositories are used

**Classification:** EXPLICITLY DECIDED
**Evidence:** 02-decisions.md ADR-12, 04-architecture.md P12.
**Why it matters:** Eloquent IS the repository. Actions query Eloquent directly.

### A-12: Domain events are plain PHP classes with no interface

**Classification:** EXPLICITLY DECIDED
**Evidence:** 02-decisions.md ADR-3 and ADR-16.
**Why it matters:** No shared DomainEvent interface or trait.

### A-13: The data acquisition pipeline is separated from the application

**Classification:** EXPLICITLY DECIDED
**Evidence:** 06-data-acquisition.md, CANONICAL-UPDATE-REPORT.md Section 7.
**Why it matters:** External system handles scraping/extraction. StudyNexus receives approved datasets via import.

### A-14: The OrganizationMember pivot supports multiple organization types

**Classification:** STRONGLY IMPLIED
**Evidence:** 05-implementation.md Section 4.4 states `organization_type` morph supports `institution`, `scholarship_provider`, `education_authority`. 04-architecture.md Section 4 describes the same.
**Why it matters:** The same membership model serves multiple entity types.

### A-15: All 22 open questions are resolved

**Classification:** EXPLICITLY DECIDED
**Evidence:** 02-decisions.md Section 2 lists all 22 as resolved. DISCOVERY-CLOSURE.md confirms discovery is closed.
**Why it matters:** No blocking open questions remain from business discovery.

### A-16: The cut_off_marks table stores one row per programme per cycle per pathway

**Classification:** EXPLICITLY DECIDED
**Evidence:** 03-domain.md Section 13, DISCOVERY-CLOSURE.md Section 3, CANONICAL-UPDATE-REPORT.md change #5.
**Why it matters:** Cross-cycle history via multiple rows. Intra-cycle corrections via UPDATE + activity log.

### A-17: Content models (Article, Guide, EducationalResource, ExamPreparation) use shared traits

**Classification:** EXPLICITLY DECIDED
**Evidence:** 04-architecture.md Section 7.
**Why it matters:** HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections.

### A-18: The community module is feature-flagged off by default

**Classification:** EXPLICITLY DECIDED
**Evidence:** 04-architecture.md Section 9, 05-implementation.md Section 10.4.
**Why it matters:** Community is Phase 2. Must be disableable without affecting core platform.

### A-19: 05-implementation.md's schemas are authoritative for migrations

**Classification:** UNSUPPORTED ASSUMPTION
**Evidence:** 05-implementation.md is labeled "canonical implementation blueprint" and contains detailed table schemas. But its schemas contradict 03-domain.md. No document establishes which is authoritative for schema.
**Why it matters:** If 05-implementation.md schemas are followed, the wrong database is created.
**Risk if wrong:** Complete schema rework required.

### A-20: The 'Other' enum variant handles unspecified values

**Classification:** STRONGLY IMPLIED
**Evidence:** 04-architecture.md Section 12 (Geographic Neutrality Test) mentions "The `Other` variant with text description handles anything not explicitly enumerated." But 03-domain.md enums do NOT include 'Other' variants for most enums.
**Why it matters:** A developer may add 'Other' to enums that the domain model doesn't include.
**Risk if wrong:** Enum bloat, potential invariant violations.

### A-21: Filament Shield version matches Filament v5

**Classification:** WEAKLY IMPLIED
**Evidence:** 05-implementation.md lists `bezhansalleh/filament-shield` ^5.0. 04-architecture.md lists it as v3. The correct version for Filament v5 is uncertain.
**Why it matters:** Wrong version causes installation failure.
**Risk if wrong:** Installation error, easily fixed.

### A-22: The baseline is portable to another LLM without conversation history

**Classification:** UNSUPPORTED ASSUMPTION
**Evidence:** README states the baseline is "frozen, immutable." DISCOVERY-CLOSURE.md states "implementation-ready." But the contradictions between 03-domain.md and 05-implementation.md mean another LLM would produce materially different implementations depending on which document it prioritizes.
**Why it matters:** The portability claim is a key success criterion.
**Risk if wrong:** Another LLM or developer makes different architectural choices than intended.

### A-23: Search projection fields exist only in Typesense

**Classification:** EXPLICITLY DECIDED
**Evidence:** 04-architecture.md Section 5, 05-implementation.md Section 8.3.
**Why it matters:** tuition_min, tuition_max, is_admission_open, discipline, is_published are computed by toSearchableArray() and never stored in PostgreSQL.

### A-24: spatie/laravel-searchable is adopted

**Classification:** CONTRADICTED
**Evidence:** 05-implementation.md Section 9.1 lists `spatie/laravel-searchable` ^3.0 as VERIFIED and adopted. 04-architecture.md Section 11 does NOT list it in the Spatie Adopt Now packages. 02-decisions.md ADR-7 does not mention it.
**Why it matters:** Additional package not in the architectural ADR.
**Risk if wrong:** Minor — package adoption is easily reversed.

### A-25: The 'Address' VO exists

**Classification:** UNSUPPORTED ASSUMPTION
**Evidence:** 05-implementation.md lists Address as a VO and includes `address (JSON)` in the institutions table schema. 03-domain.md has a Location VO (Country + region + city) but no Address VO. No other document mentions an Address VO.
**Why it matters:** A developer following 05-implementation.md would create an Address VO that the domain model doesn't define.
**Risk if wrong:** Unnecessary VO, conflicting with Location VO from domain model.

---

# Contradiction Register

**Audit Date:** 2026-08-10
**Severity Model:** CRITICAL / HIGH / MEDIUM / LOW / INFO

---

## Contradiction Matrix

### C-01: Contradictory Enum Values

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 6 (Enums)
**Document B:** `05-implementation.md` Section 3.4 (Domain Enums)

**Conflict:**

| Enum | 03-domain.md Values | 05-implementation.md Values |
|------|---------------------|------------------------------|
| InstitutionType | University, Polytechnic, CollegeOfEducation, InnovationEnterpriseInstitution | University, Polytechnic, CollegeOfEducation, Vocational, SecondarySchool, Professional, Other |
| AwardLevel (vs AwardType) | BSc, BA, MSc, PhD, ND, HND, NCE, Foundation, Certificate, Diploma | Degree, Diploma, Certificate, PhD, Masters, Bachelors |
| ProgrammeStatus | Prospective, Admitting, Suspended, Discontinued | Prospective, Admitting, Suspended, Discontinued (matching) |
| ScholarshipStatus | Draft, Announced, Open, Closed, Expired, Withdrawn | Active, Closed, Upcoming |
| AdmissionPathway (VO vs Enum) | Value Object (UTME, DirectEntry, IJMB, JUPEB mentioned as examples) | Enum (UTME, PostUTME, DirectEntry, JUPEB, CambridgeALevel, UCAS, CommonApp, Other) |
| AuthorityType | Regulatory, Accreditation, Funding, Admissions | Regulatory, Accreditation, Funding, Admissions, Other |
| PolicyStatus | Draft, Published, Superseded, Withdrawn | Draft, Published, Superseded (missing Withdrawn) |
| ModeOfStudy (vs DeliveryMode) | DeliveryMode: OnCampus, Online, Hybrid | ModeOfStudy: FullTime, PartTime, Online, Distance, Hybrid |
| VerificationStatus (vs SourceReliability) | SourceReliability: Unverified, Verified, Unreliable, Deprecated | VerificationStatus: Pending, Verified, Rejected |

**Why they conflict:** The enums have different names (AwardLevel vs AwardType, DeliveryMode vs ModeOfStudy, SourceReliability vs VerificationStatus), different value sets, and different semantics. A developer cannot implement both.

**Likely consequence:** Wrong migrations, wrong domain methods, wrong admin UI, wrong invariants. If 05-implementation.md is followed, the entire domain layer would be structurally different from what 03-domain.md specifies.

**Precedence:** 03-domain.md appears more authoritative (it is the domain model document, and 02-decisions.md refers to it). The CANONICAL-UPDATE-REPORT.md acknowledges the ScholarshipStatus discrepancy but not the others.

**Resolution status:** UNRESOLVED

---

### C-02: Contradictory Action Lists

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 5 (Actions)
**Document B:** `05-implementation.md` Section 3.6 (Domain Actions)

**Conflict:**

03-domain.md Actions (20): CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions, PublishAdmissionPolicy, RecordAccreditation, CreateProgramme, DiscontinueProgramme, AnnounceScholarship, OpenScholarshipApplications, ExpireScholarship, TargetScholarshipProgrammes, AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase, RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable, ImportInstitutionData, ExpireScholarships

05-implementation.md Actions (20): CreateInstitution, UpdateInstitution, PublishInstitution, VerifyInformationSource, RejectInformationSource, CreateProgramme, UpdateProgramme, PublishProgramme, CreateScholarship, UpdateScholarship, PublishScholarship, OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults, CreateAdmissionPolicy, UpdateAdmissionPolicy, PublishAdmissionPolicy, CreateEligibilityPolicy, UpdateEligibilityPolicy, RecordAccreditation

**Overlap:** Only ~6 actions appear in both lists (CreateInstitution, CreateProgramme, PublishAdmissionPolicy, RecordAccreditation, VerifyInformationSource, ImportInstitutionData — though ImportInstitutionData appears only in 03).

**Why they conflict:** The two documents define completely different use cases. 03-domain.md focuses on domain operations with cascade effects (SuspendInstitution, CloseInstitution, MergeInstitutions, DiscontinueProgramme). 05-implementation.md focuses on CRUD-style operations (UpdateInstitution, UpdateProgramme, PublishInstitution, PublishProgramme) that 03-domain.md explicitly rejected as not deserving Action status.

**Likely consequence:** A developer would implement 20 wrong Actions.

**Precedence:** 03-domain.md is authoritative per ADR-2 which defines the Action Criterion. 05-implementation.md does not reference the Action Criterion.

**Resolution status:** UNRESOLVED

---

### C-03: Contradictory Value Object Inventory

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 3 (Value Objects)
**Document B:** `05-implementation.md` Section 3.4 (Value Objects)

**Conflict:**

03-domain.md VOs (12 genuine): AdmissionRule, EligibilityRule, SubjectCombination, QualificationThreshold, ValidityPeriod, TrustSignal, MonetaryAmount, Duration, Location, AuthorityJurisdiction, PhaseSequence, AdmissionPathway

05-implementation.md VOs (12 non-enum): Address, AdmissionRule, AdmissionStatus, ContactInfo, Country, Currency, Duration, EligibilityCriterion, GeographicCoordinates, Money, ScholarshipAmount, ValidityPeriod

**Overlap:** AdmissionRule, Duration, ValidityPeriod (3 out of 12). The other 9 are completely different.

**Why they conflict:** The VOs serve different domain models. 03-domain.md's VOs are domain-discovered concepts (SubjectCombination, QualificationThreshold, TrustSignal, AuthorityJurisdiction, PhaseSequence). 05-implementation.md's VOs are generic utility types (Address, ContactInfo, Country, Currency, GeographicCoordinates).

**Likely consequence:** Completely different domain layer implementation.

**Resolution status:** UNRESOLVED

---

### C-04: Contradictory AdmissionCycle Definition

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 2 (Entity Register) and Section 8 (Entity Behaviours)
**Document B:** `05-implementation.md` Section 3.1 (Aggregate Roots)

**Conflict:**

03-domain.md: AdmissionCycle is an aggregate root owned by EducationAuthority. Has PhaseSequence, phase advancement operations, announce/activate/advancePhase/close/archive lifecycle. States: Upcoming → Active → Closed → Archived.

05-implementation.md: AdmissionCycle belongs to Institution (`institution_id FK`). Has `opens_at`, `closes_at`, `results_at` columns. No phases. Actions: OpenAdmissionCycle, CloseAdmissionCycle, PublishAdmissionResults.

**Why they conflict:** Different owner (EducationAuthority vs Institution), different lifecycle (phase-based vs date-based), different operations.

**Likely consequence:** Fundamentally different admission system architecture.

**Resolution status:** UNRESOLVED

---

### C-05: Contradictory InformationSource Definition

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 2 and Section 8
**Document B:** `05-implementation.md` Section 3.1

**Conflict:**

03-domain.md: InformationSource is an aggregate root with register/verify/markUnreliable/deprecate lifecycle, SourceReliability enum, InformationCategory enum, TrustSignal computed VO. States: Registered → Verified ↔ Unreliable; any → Deprecated (terminal).

05-implementation.md: InformationSource is a simple table with `institution_id FK`, `source_type`, `url`, `contact_name`, `contact_email`, `verification_status`, `verified_at`, `verified_by`, `notes`. No lifecycle methods mentioned. No domain operations.

**Why they conflict:** One is a full aggregate root with invariants and lifecycle. The other is a child table of Institution with no domain behaviour.

**Likely consequence:** If 05-implementation.md is followed, the entire trust/provenance architecture from 03-domain.md and 06-data-acquisition.md is unimplementable.

**Resolution status:** UNRESOLVED

---

### C-06: Contradictory Child Entity Ownership

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 2 (Child Entities) and Section 9 (Aggregate Boundaries)
**Document B:** `05-implementation.md` Section 3.2 (Child Entities)

**Conflict:**

03-domain.md:
- AdmissionPolicy: child of Programme OR Institution (polymorphic Governable)
- EligibilityPolicy: child of Scholarship
- AccreditationRecord: child of Programme OR Institution (polymorphic Accreditable)

05-implementation.md:
- AdmissionPolicy: belongsTo AdmissionCycle (`admission_cycle_id FK`)
- EligibilityPolicy: belongsTo AdmissionCycle (`admission_cycle_id FK`)
- AccreditationRecord: belongsTo Institution (`institution_id FK`)

**Why they conflict:** Different parents produce different schemas, different relationships, different aggregate boundaries, and different invariant enforcement.

**Likely consequence:** Wrong migrations, wrong relationships, broken invariants (INV-I3, INV-P2, INV-S2 cannot be enforced correctly with 05-implementation.md's ownership model).

**Resolution status:** UNRESOLVED

---

### C-07: Contradictory Scholarship Provider Definition

**Severity:** CRITICAL
**Document A:** `03-domain.md` Section 2 (Supporting Entity #10)
**Document B:** `05-implementation.md` Section 3.1 (Scholarship) and Section 3.3 (Supporting Entities)

**Conflict:**

03-domain.md: ScholarshipProvider is a supporting entity (table: `scholarship_providers`). Scholarship `belongsTo ScholarshipProvider` (FK).

05-implementation.md: Scholarship has `provider_type` + `provider_id` (morphTo). ScholarshipProvider is listed as a supporting entity in Section 3.3 BUT the Scholarship schema in Section 3.1 uses polymorphic provider. This is internally contradictory within 05-implementation.md itself.

**Why they conflict:** A FK relationship and a polymorphic relationship produce different schemas, different queries, and different authorization logic.

**Resolution status:** UNRESOLVED

---

### C-08: Table Count Discrepancy

**Severity:** HIGH
**Document A:** `05-implementation.md` Section 4.1 (56 tables)
**Document B:** `06-data-acquisition.md` Section 4 (introduces `import_batches` and `pending_imports`)

**Conflict:** 05-implementation.md states 56 tables. 06-data-acquisition.md introduces 2 additional tables not counted in the 56. Actual table count is at least 58.

**Resolution status:** UNRESOLVED

---

### C-09: HasProvenance Trait Scope

**Severity:** HIGH
**Document A:** `06-data-acquisition.md` Section 8 (Provenance Model — applies to every domain entity)
**Document B:** `04-architecture.md` Section 7 (Content Architecture — HasProvenance is a content trait)
**Document C:** `03-domain.md` (does not mention HasProvenance)

**Conflict:** 06-data-acquisition.md states every domain entity carries a `provenance` JSON column via a `HasProvenance` trait. 04-architecture.md lists `HasProvenance` as a content-layer trait only. 03-domain.md does not mention provenance at all.

**Resolution status:** UNRESOLVED

---

### C-10: RBAC String Column Location

**Severity:** HIGH
**Document A:** `02-decisions.md` Section 5.2 (string `role` column on `organization_members`)
**Document B:** `05-implementation.md` Section 11 ("string `role` column on the users table")

**Conflict:** 02-decisions.md clearly states the string `role` column is on `organization_members`. 05-implementation.md Section 11 says it is on "the users table."

**Resolution status:** UNRESOLVED (likely a typo in 05-implementation.md, but it creates confusion)

---

### C-11: ProgrammeLevel vs AwardLevel Naming

**Severity:** MEDIUM
**Document A:** `03-domain.md` (uses "AwardLevel")
**Document B:** `05-implementation.md` (uses "ProgrammeLevel" in schema, "AwardType" in enums)

**Conflict:** Three different names for the same concept: AwardLevel (03-domain.md), ProgrammeLevel (05-implementation.md schema), AwardType (05-implementation.md enum table).

**Resolution status:** UNRESOLVED

---

### C-12: EligibilityPolicy Parent

**Severity:** HIGH
**Document A:** `03-domain.md` (EligibilityPolicy is child of Scholarship)
**Document B:** `05-implementation.md` (EligibilityPolicy `belongsTo AdmissionCycle`)

**Conflict:** Different parent aggregates. In 03-domain.md, EligibilityPolicy contains eligibility criteria for a scholarship. In 05-implementation.md, it contains `criteria`, `minimum_score` and belongs to AdmissionCycle — which makes no semantic sense for scholarship eligibility.

**Resolution status:** UNRESOLVED

---

### C-13: AdmissionPolicy Schema

**Severity:** HIGH
**Document A:** `03-domain.md` (AdmissionPolicy contains AdmissionRule VOs, polymorphic parent)
**Document B:** `05-implementation.md` (AdmissionPolicy has `admission_cycle_id FK`, `title`, `description`, `policy_rules JSON`, `qualification_requirements`)

**Conflict:** 03-domain.md's AdmissionPolicy is a polymorphic child of Programme/Institution containing AdmissionRule VOs (qualification reference, threshold, subject combinations, rule type). 05-implementation.md's AdmissionPolicy is a child of AdmissionCycle with generic `policy_rules JSON` and `qualification_requirements` text.

**Resolution status:** UNRESOLVED

---

### C-14: AccreditationRecord Schema

**Severity:** HIGH
**Document A:** `03-domain.md` (AccreditationRecord is polymorphic child of Programme/Institution, immutable, with ValidityPeriod VO)
**Document B:** `05-implementation.md` (AccreditationRecord has `institution_id FK`, `authority_type`/`authority_id` morph, `accreditation_type`, `status`, `valid_from`/`valid_to`)

**Conflict:** 05-implementation.md limits AccreditationRecord to Institution only (`institution_id FK`), while 03-domain.md allows it on both Institution and Programme (polymorphic). 05-implementation.md also uses `valid_from`/`valid_to` as separate columns instead of a ValidityPeriod VO.

**Resolution status:** UNRESOLVED

---

### C-15: Domain Event Names

**Severity:** MEDIUM
**Document A:** `03-domain.md` Section 4 (29 events: InstitutionEstablished, InstitutionRenamed, etc.)
**Document B:** `05-implementation.md` Section 3.5 (mentions "InstitutionCreated, InstitutionUpdated, InstitutionPublished" etc.)

**Conflict:** 03-domain.md uses domain-language names (InstitutionEstablished, ProgrammeIntroduced). 05-implementation.md uses CRUD-style names (InstitutionCreated, InstitutionUpdated, InstitutionPublished). These are different event lists.

**Resolution status:** UNRESOLVED

---

### C-16: Additional Enums in 05-implementation.md Not in 03-domain.md

**Severity:** MEDIUM
**Document A:** `03-domain.md` (16 enums)
**Document B:** `05-implementation.md` (16 enums but includes ContentType, ResourceType, PrepType which are content-layer enums, not domain enums)

**Conflict:** 05-implementation.md includes content-layer enums (ContentType, ResourceType, PrepType) in the domain enum count, replacing domain enums (InformationCategory, QualificationStatus). The count matches (16) but the contents differ.

**Resolution status:** UNRESOLVED

---

### C-17: Spatie Package Version Inconsistencies

**Severity:** LOW
**Document A:** `04-architecture.md` (spatie/laravel-tags ^4.0, spatie/laravel-sluggable ^3.0)
**Document B:** `05-implementation.md` (spatie/laravel-tags ^4.0, spatie/laravel-sluggable ^4.0)
**Document C:** `06-data-acquisition.md` (spatie/laravel-activitylog ^5.0 vs ^4.0 in other docs)

**Conflict:** Minor version inconsistencies across documents.

**Resolution status:** UNRESOLVED (non-blocking, resolve during implementation)

---

### C-18: Location VO vs Address VO

**Severity:** MEDIUM
**Document A:** `03-domain.md` (Location VO: Country + region + city)
**Document B:** `05-implementation.md` (Address VO as JSON, GeographicCoordinates VO as JSON, Country as string, separate fields for state_province, city, address)

**Conflict:** 03-domain.md has a single Location VO. 05-implementation.md splits this into Address, GeographicCoordinates, Country, and separate columns. Different persistence and different domain logic.

**Resolution status:** UNRESOLVED

---

## Precedence Analysis

The baseline establishes in `02-decisions.md` Section 8.4 that frozen architectural decisions require formal ADR supersession to change. The README states "Canonical documents always override archived documents where any conflict exists." However, the baseline does NOT establish precedence BETWEEN canonical documents.

The natural assumption would be that `03-domain.md` (the domain model) is authoritative for domain concepts, and `05-implementation.md` (the implementation blueprint) should conform to it. But this is not explicitly stated.

The CANONICAL-UPDATE-REPORT.md acknowledges and corrects some discrepancies (ProgrammeStatus, InstitutionStatus, ScholarshipStatus) but misses the majority of the contradictions documented above. This suggests the corrections were incomplete rather than comprehensive.

**Recommendation:** Explicitly declare `03-domain.md` as authoritative for all domain model decisions, and require `05-implementation.md` to conform. This is the only path to resolution that doesn't require redesign.

---

# StudyNexus Pre-Implementation Baseline — Audit Executive Summary

**Audit Date:** 2026-08-10
**Auditor:** Independent Adversarial Audit
**Baseline Version:** 2026-08-10T00:45:00+01:00
**Baseline Files:** 44 (6 canonical + 3 product-experience + 2 governance + 31 archive + README + MANIFEST)

---

## Overall Verdict

### CONDITIONAL GO

Implementation may begin only in clearly identified non-blocked areas. The baseline contains a substantial number of cross-document contradictions concentrated between the canonical domain model (`03-domain.md`) and the implementation blueprint (`05-implementation.md`). While the domain model itself is well-architected and internally coherent, the implementation blueprint diverges from it in enum values, entity names, Action names, VO names, table schemas, and lifecycle semantics. These are not cosmetic — they would produce materially different implementations depending on which document a developer follows.

---

## Finding Count

| Severity | Count |
|----------|------:|
| CRITICAL | 7 |
| HIGH | 14 |
| MEDIUM | 18 |
| LOW | 9 |
| INFO | 6 |
| **Total** | **54** |

---

## Top 10 Risks

### 1. CRITICAL — Two Contradictory Enum Sets (C-01)
`05-implementation.md` defines completely different enum values for InstitutionType, ProgrammeLevel, AwardType, ScholarshipStatus, AdmissionPathway, AuthorityType, and PolicyStatus compared to `03-domain.md`. A developer following `05-implementation.md` would create wrong enums, wrong migrations, and wrong domain methods. The CANONICAL-UPDATE-REPORT.md acknowledges the ScholarshipStatus discrepancy but calls it "non-blocking" — it is not non-blocking; it affects schema, admin UI, and invariants.

### 2. CRITICAL — Contradictory Action Lists (C-02)
`03-domain.md` defines 20 Actions. `05-implementation.md` defines a different list of 20 Actions with different names. Only approximately 8 overlap. A developer cannot determine which 20 Actions to implement without making a judgment call between the two canonical documents.

### 3. CRITICAL — Contradictory Value Object Inventory (C-03)
`03-domain.md` lists 12 genuine VOs (AdmissionRule, EligibilityRule, SubjectCombination, QualificationThreshold, ValidityPeriod, TrustSignal, MonetaryAmount, Duration, Location, AuthorityJurisdiction, PhaseSequence, AdmissionPathway). `05-implementation.md` lists 12 non-enum VOs with completely different names (Address, AdmissionRule, AdmissionStatus, ContactInfo, Country, Currency, Duration, EligibilityCriterion, GeographicCoordinates, Money, ScholarshipAmount, ValidityPeriod). Only 3-4 overlap. A developer would build a materially different domain layer depending on which document they follow.

### 4. CRITICAL — Contradictory Entity Definitions for AdmissionCycle (C-04)
`03-domain.md` defines AdmissionCycle as an aggregate root owned by EducationAuthority with phase sequences. `05-implementation.md` defines AdmissionCycle as belonging to Institution with `opens_at`/`closes_at`/`results_at` columns — no phases, no authority. These are structurally incompatible.

### 5. CRITICAL — Contradictory Entity Definitions for InformationSource (C-05)
`03-domain.md` defines InformationSource as an aggregate root with registration, verification, and deprecation lifecycle. `05-implementation.md` defines InformationSource as a simple table with `institution_id` FK, `source_type`, `url`, `contact_name`, `contact_email` — no lifecycle methods, no domain operations. These are different entities sharing the same name.

### 6. CRITICAL — Contradictory Child Entity Ownership (C-06)
`03-domain.md` defines AdmissionPolicy as polymorphic (Programme OR Institution) and EligibilityPolicy as child of Scholarship. `05-implementation.md` defines AdmissionPolicy as child of AdmissionCycle and EligibilityPolicy as child of AdmissionCycle. Different parents, different schemas, different relationships.

### 7. CRITICAL — Contradictory Scholarship Provider Type (C-07)
`03-domain.md` defines Scholarship Provider as a supporting entity (ScholarshipProvider). `05-implementation.md` defines Scholarship as having a polymorphic `provider_type`/`provider_id` morphTo relationship — meaning any model can be a provider. These produce different schemas and different authorization logic.

### 8. HIGH — Data Acquisition Pipeline Introduces New Tables Not in Canonical Schema (H-01)
`06-data-acquisition.md` introduces `import_batches` and `pending_imports` tables. These are not in the 56-table count from `05-implementation.md`. The table count is now at least 58.

### 9. HIGH — Provenance Model Contradiction (H-02)
`06-data-acquisition.md` defines a `HasProvenance` trait with a `provenance` JSON column on every domain entity. `03-domain.md` does not mention this trait or column. `05-implementation.md` does not include it in table schemas. `04-architecture.md` mentions `HasProvenance` only as a content trait.

### 10. HIGH — RBAC Implementation Inconsistency (H-03)
`05-implementation.md` Section 11 (Admin UI) states "RBAC is enforced via `bezhansalleh/filament-shield` with the 11-role model using a string `role` column on the users table." This contradicts `02-decisions.md` which states the string `role` column is on `organization_members`, not `users`. The `users` table has Spatie roles via `model_has_roles`.

---

## Implementation Readiness

The baseline is **NOT ready for full implementation**. The domain model in `03-domain.md` is well-constructed, internally coherent, and follows Laravel Beyond CRUD principles correctly. However, `05-implementation.md` — the document a developer would follow for concrete schema, migration, and code decisions — contradicts `03-domain.md` on nearly every entity definition.

**Non-blocked areas where implementation CAN begin:**
- Laravel project scaffolding and configuration (Phase 1a: framework install, PostgreSQL/Redis setup)
- Package installation (the package matrix is consistent across documents)
- Auth scaffolding and RBAC role seeding (the 11-role model is consistent)
- Reference data table structure (countries, currencies, qualifications)

**Blocked areas requiring resolution before implementation:**
- All domain entity migrations (contradictory schemas)
- All enum definitions (contradictory values)
- All Value Object implementations (contradictory inventories)
- All Action class implementations (contradictory lists)
- All domain relationship definitions (contradictory parents)
- Search/Typesense configuration (depends on resolving entity schemas)
- Content layer implementation (depends on domain layer)

---

## Exact Blockers

| # | Blocker | Documents in Conflict | Resolution Required |
|---|---------|----------------------|---------------------|
| B-01 | Which enum values are canonical? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative for all enum values; reissue 05-implementation.md with corrected enums |
| B-02 | Which Action list is canonical? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative; reissue 05-implementation.md |
| B-03 | Which VO inventory is canonical? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative; reissue 05-implementation.md |
| B-04 | What are the correct parent entities for AdmissionPolicy, EligibilityPolicy, AccreditationRecord? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative |
| B-05 | Is ScholarshipProvider a supporting entity or a polymorphic provider? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative |
| B-06 | Is InformationSource an aggregate root or a simple table? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative |
| B-07 | Does AdmissionCycle belong to EducationAuthority or Institution? | 03-domain.md vs 05-implementation.md | Declare 03-domain.md as authoritative |
| B-08 | Are import_batches and pending_imports tables part of the 56-table schema? | 05-implementation.md vs 06-data-acquisition.md | Update table count and schema inventory |
| B-09 | Is the HasProvenance trait applied to domain entities? | 03-domain.md vs 06-data-acquisition.md vs 04-architecture.md | Decide explicitly and document consistently |

---

## Documents Audit Summary

| Document | Purpose | Readiness |
|----------|---------|-----------|
| 01-business.md | Business vision, personas, workflows, capabilities | READY |
| 02-decisions.md | ADRs, resolved questions, rejected alternatives | READY (minor inconsistencies in RBAC section) |
| 03-domain.md | Domain model: entities, VOs, events, actions, enums | READY — internally coherent and well-justified |
| 04-architecture.md | Platform architecture, search, SEO, content | READY WITH MINOR CLARIFICATION |
| 05-implementation.md | Implementation blueprint: schemas, packages, order | **BLOCKED** — contradicts 03-domain.md on nearly every entity |
| 06-data-acquisition.md | Data acquisition pipeline, staging, ingestion | READY WITH MINOR CLARIFICATION (table count, provenance) |
| PRODUCT-EXPERIENCE-ARCHITECTURE.md | UX discovery, journeys, information architecture | READY |
| FIRST-VERTICAL-SLICE-UX.md | UX specification | READY (not fully read in this audit pass) |
| FIRST-VERTICAL-SLICE-UI.md | UI specification | READY (not fully read in this audit pass) |
| DISCOVERY-CLOSURE.md | Discovery closure and readiness gate | READY |
| CANONICAL-UPDATE-REPORT.md | Canonical update report | READY (acknowledges some but not all contradictions) |

---

## Path to GO

The path from CONDITIONAL GO to GO is straightforward:

1. **Declare `03-domain.md` as authoritative** for all domain model decisions (entities, VOs, enums, events, actions, relationships, invariants, lifecycles).
2. **Reissue `05-implementation.md`** with all schemas, enums, VO lists, Action lists, and entity definitions aligned to `03-domain.md`. This is primarily a correction pass, not a redesign.
3. **Update the table count** in `05-implementation.md` to include `import_batches`, `pending_imports`, and any other tables from `06-data-acquisition.md`.
4. **Decide on the HasProvenance trait** — whether it applies to domain entities or only content models — and document consistently.
5. **Fix the RBAC inconsistency** in `05-implementation.md` Section 11 (string `role` column is on `organization_members`, not `users`).

Once these corrections are made, the baseline would likely achieve GO status, as the underlying domain model and architecture are sound.

---

## Final Quality Assessment

The baseline demonstrates **strong domain thinking** and **sound architectural methodology**. The Laravel Beyond CRUD principles are correctly applied. The domain model in `03-domain.md` is genuinely pragmatic — not ceremonial DDD, not anemic CRUD. The ADRs are well-reasoned. The rejection of unnecessary patterns (repositories, event sourcing, model-states) is justified.

The fundamental problem is **document synchronization**. The implementation blueprint was not updated to match the frozen domain model. This is a documentation failure, not an architectural failure. The architecture itself is likely correct — but the baseline as delivered does not sufficiently constrain implementation to prevent divergent interpretations.