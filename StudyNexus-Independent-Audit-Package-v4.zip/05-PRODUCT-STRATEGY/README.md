# StudyNexus — Product Strategy & Competitive Research

**⚠️ NON-AUTHORITATIVE PRODUCT RESEARCH**

This section contains competitive intelligence, product discovery challenges, and feature synthesis that INFORMED but does NOT CONSTRAIN the StudyNexus architecture.

## Contents

- **PRODUCT-DISCOVERY-CHALLENGE.md** (60K) — Comprehensive competitive research across global platforms (Bachelorsportal, Mastersportal, PhDportal, educations.com, IDP, ApplyBoard, Study.eu) and Nigerian/African platforms (Academics.ng, MySchoolGist, UniAssist Africa). Includes feature synthesis, gap analysis, and product challenge framing.
- **MERGED-AUDIT-OF-STUDYNEXUS-PLAN.md** (144K) — Merged audit document from earlier review cycles, containing cross-cutting architectural and implementation concerns.

## How to Use This Material

1. Read PRODUCT-DISCOVERY-CHALLENGE.md to understand the competitive landscape.
2. Evaluate whether the current canonical architecture (Tier 1) sufficiently supports the strategically relevant long-term product capabilities.
3. Identify gaps between what competitors offer and what StudyNexus plans to build.
4. **DO NOT** treat competitor features as StudyNexus requirements. The canonical architecture decides what StudyNexus builds.
5. **DO NOT** use this material to override Tier 1 canonical decisions.

## Key Competitors Researched

### Global
- Bachelorsportal / Mastersportal / PhDportal (Studyportals)
- educations.com
- IDP Education
- ApplyBoard
- Study.eu

### Africa / Nigeria
- Academics.ng
- MySchoolGist
- SchoolNews
- UniAssist Africa
