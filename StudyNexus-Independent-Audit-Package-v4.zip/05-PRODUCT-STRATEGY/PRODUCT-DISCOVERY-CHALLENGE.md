# StudyNexus — Product Discovery Challenge & Canonical Boundary Review

**Date:** 2026-08-10
**Status:** CHALLENGE REVIEW — awaiting human approval
**Authoritative baseline:** 6 canonical documents (01–06) + PRODUCT-EXPERIENCE-DISCOVERY.md
**Constraint:** No canonical documents modified. No implementation code produced. No new discovery document created.

---

# 1. Critical Inconsistency Discovered

Before addressing the GAPs, a material inconsistency exists between canonical documents that must be resolved first.

## 1.1 ProgrammeStatus / InstitutionStatus Mismatch

**03-domain.md (canonical domain model):**

| Enum | Values |
|------|--------|
| ProgrammeStatus | **Prospective**, **Admitting**, Suspended, Discontinued |
| InstitutionStatus | **Provisional**, **Operational**, Suspended, Closed |

**05-implementation.md (canonical implementation blueprint):**

| Enum | Values |
|------|--------|
| ProgrammeStatus | **Draft**, **Published**, Archived, Suspended |
| InstitutionStatus | **Draft**, **Published**, Archived |

These are fundamentally different semantic models. The domain model defines **lifecycle states** (a programme transitions from Prospective → Admitting → Suspended/Discontinued based on business operations). The implementation schema defines **publication-like states** (Draft → Published → Archived).

**This is not a trivial naming difference.** "Prospective" and "Draft" mean different things. "Admitting" and "Published" mean different things. The domain model's states are guarded by invariants and transitioned by domain methods (`introduce()`, `suspendAdmission()`, `discontinue()`). The implementation schema's states describe visibility, not business lifecycle.

**Root cause:** The implementation schema conflated domain lifecycle status with publication status — exactly the confusion that GAP-1 in the PED identifies but then perpetuates by recommending a separate `publication_status` enum that includes the same problematic values (Draft, Published, Unpublished, Archived).

**Resolution required:** The domain model (03-domain.md) is the canonical source for domain semantics. The implementation schema must be corrected to use the domain model's lifecycle statuses, and publication concerns must be addressed separately (see Section 5 below).

---

# 2. Confirmed Architectural Constraints

These are treated as hard constraints per the directive:

1. **Laravel monolith** — no microservices, no `nwidart/laravel-modules` for boundaries. Pragmatic Laravel. Beyond CRUD principles used where they improve code, not as rigid methodology.
2. **External data acquisition boundary** — scraping/crawling/parsing external to StudyNexus. Boundary already decided.
3. **Canonical ingestion pipeline must remain** — StudyNexus needs controlled bridge from approved external data to canonical data. This is NOT a scraper pipeline.
4. **Canonical data ≠ latest external observation** — StudyNexus decides when/how changes become canonical.
5. **No event sourcing** — ADR-3 is explicit: events are fire-and-forget business facts.

---

# 3. Challenge GAP-1: Publication Status

The PED identified:

> GAP-1 (HIGH): No publication/status model — entities need `publication_status` (Draft, Published, Unpublished, Archived).

## 3.1 Analysis of Distinct State Concepts

The following are genuinely distinct concepts:

| Concept | Meaning | Already Modeled? | Where |
|---------|---------|:----------------:|-------|
| **Lifecycle state** | Business state of the entity (e.g., institution is Operational, programme is Admitting) | ✅ Yes | InstitutionStatus, ProgrammeStatus, ScholarshipStatus on domain entities |
| **Verification state** | Whether information has been cross-referenced against official sources | ✅ Yes | SourceReliability enum on InformationSource; TrustSignal computed VO |
| **Acquisition state** | Whether data has been obtained from an external source | ✅ Yes | Import batch workflow in 06-data-acquisition.md (pending → parsed → verified → applied) |
| **Publication state** | Whether an entity should appear on the public website | ❌ No | Not modeled on any domain entity |
| **Supersession state** | Whether this version replaces a previous version | ✅ Partially | PolicyStatus::Superseded on Admission/EligibilityPolicy; not on other entities |
| **Canonical state** | Whether this is the authoritative version of the data | ✅ Implicit | StudyNexus IS the canonical store; all data in PostgreSQL is canonical by definition |

## 3.2 Why These Must Not Collapse Into One Field

Consider a real scenario: The University of Lagos is **Operational** (lifecycle). Its data has been **Verified** (verification). It was imported from the **JAMB brochure** (acquisition). But it is **not yet published** (publication) because the content team hasn't reviewed the imported programme data for completeness. Meanwhile, an old admission policy is **Superseded** (supersession) by a newly published one.

These are orthogonal dimensions. Putting them in one `status` field requires choosing which dimension takes precedence, which leads to the exact confusion visible in the 05-implementation.md inconsistency. An entity cannot be simultaneously "Operational" (lifecycle) and "Draft" (publication) in a single field.

## 3.3 Smallest Correct Model

The product requirement is: **some entities exist in the database but should not appear on the public site.** The reasons vary (incomplete data, awaiting review, intentionally hidden, permanently removed), but the public-facing question is always binary: visible or not visible.

**Recommendation: `is_published` boolean + `published_at` nullable timestamp.**

| State | `is_published` | `published_at` | Semantic |
|-------|:-------------:|:--------------:|----------|
| Never published (draft) | `false` | `NULL` | Entity exists but has never been made public |
| Currently published | `true` | `2026-08-10` | Visible on public site |
| Unpublished (was visible, now hidden) | `false` | `2026-08-10` | Was published, temporarily hidden |
| Permanently removed | Covered by lifecycle | — | Institution::Closed, Programme::Discontinued, Scholarship::Withdrawn |

**Visibility rule for public queries:**

```php
// An entity appears on the public site when:
$isVisible = $entity->is_published
    && !in_array($entity->status, [InstitutionStatus::Closed, ProgrammeStatus::Discontinued, ...]);
```

**Why not a `publication_status` enum?**

1. The four-state enum (Draft/Published/Unpublished/Archived) adds semantic richness that the public site doesn't need — on the public site, visibility is binary.
2. "Archived" overlaps with domain lifecycle states (Closed, Discontinued, Withdrawn) — this creates ambiguity about which field controls permanent removal.
3. The enum requires a state machine (Draft → Published → Unpublished → Published → Archived) with transition guards. A boolean doesn't.
4. `published_at` provides the Draft/Unpublished distinction without an enum: `is_published=false + published_at=NULL` = draft; `is_published=false + published_at≠NULL` = unpublished.
5. This pattern already exists in the codebase: the `IsPublishable` trait on content models uses `published_at` + `status`. We can apply the same pattern to domain entities with a simpler boolean.

**What this adds to the canonical model:**

| Entity | Columns Added |
|--------|--------------|
| Institution | `is_published` boolean (default false), `published_at` nullable timestamp |
| Programme | `is_published` boolean (default false), `published_at` nullable timestamp |
| Scholarship | `is_published` boolean (default false), `published_at` nullable timestamp |

**No new enum. No new state machine. Orthogonal to domain lifecycle.**

---

# 4. Challenge GAP-2: Historical Versioning

The PED identified:

> GAP-2 (MEDIUM): No historical versioning for cut-offs/tuition — deferred to Phase 2.

## 4.1 Field-by-Field Analysis

### 4.1.1 Admission Cut-off Changes

**Example:** JAMB cut-off for Computer Science at UNILAG changes from 180 (2024/2025) to 200 (2025/2026).

| Criterion | Assessment |
|-----------|------------|
| History required for MVP? | **YES** — students explicitly use previous cut-offs to estimate admission chances. This is not an edge case; it is the primary use case for the programme detail page. |
| User-visible? | **YES** — "Previous cut-off: 180 (2024/2025)" shown on programme detail page per PED Section 7.1. |
| Required for auditability? | **YES** — need to verify when and from what source the value changed. |
| Required for provenance? | **YES** — each year's cut-off has a different source (JAMB 2025 brochure vs JAMB 2026 brochure). |
| Required for data correction? | **YES** — if a wrong cut-off is imported, history allows correction without losing the record. |
| Effective dating required? | **YES** — cut-off 180 applies to 2024/2025 session; 200 applies to 2025/2026. The effective date is the admission cycle, not just a timestamp. |
| Can ordinary relational history solve it? | **YES** — a `cut_off_marks` table with (programme_id, admission_cycle_id, value, source_id, created_at) is simple and sufficient. |
| Can defer? | **NO** — this is a core user need directly supporting the primary user journey (Journey 1: Programme Discovery). Without it, the programme detail page is materially less useful. |

**Verdict: MUST be in MVP.** The PED's recommendation to defer this is incorrect. Cut-off history is not a nice-to-have — it is how students estimate their chances.

### 4.1.2 Tuition Changes

**Example:** Tuition for Computer Science at UNILAG increases from ₦150,000 to ₦200,000 per session.

| Criterion | Assessment |
|-----------|------------|
| History required for MVP? | **NO** — current tuition is sufficient for the primary decision. "How much does it cost NOW?" is the question students and parents need answered. |
| User-visible? | **USEFUL** — "Tuition increased 33% this year" is informative but not essential. |
| Required for auditability? | **YES** — but activity log (spatie/laravel-activitylog) provides this without structural versioning. |
| Required for provenance? | **Partial** — provenance of the current value is needed (source + verification); provenance of previous values is useful but not essential. |
| Effective dating required? | **YES** — tuition applies per academic session. But for MVP, displaying "as of 2025/2026 session" on the current value is sufficient. |
| Can ordinary relational history solve it? | **YES** — same pattern as cut-offs. |
| Can defer? | **YES** — current tuition is sufficient for the product to be useful. Historical tuition can be added in Phase 2 when the versioning mechanism is proven with cut-offs. |

**Verdict: Defer to Phase 2.** The activity log provides auditability. Historical tuition display adds value but is not essential for launch.

### 4.1.3 Admission Requirements Changes

**Example:** Subject combination for Medicine changes from {English, Biology, Chemistry, Physics} to {English, Biology, Chemistry, Any Science}.

| Criterion | Assessment |
|-----------|------------|
| Already handled? | **YES** — AdmissionPolicy has PolicyStatus with `Superseded` state. Publishing a new policy for the same cycle atomically supersedes the previous one (INV-I3, INV-P2). Previous policies are retained in the database. |

**Verdict: Already modeled. No action needed.**

### 4.1.4 Programme Availability Changes

**Example:** A programme is discontinued or a new programme is introduced.

| Criterion | Assessment |
|-----------|------------|
| Already handled? | **YES** — ProgrammeStatus::Discontinued + ProgrammeDiscontinued event. ProgrammeStatus::Prospective for new programmes. |

**Verdict: Already modeled. No action needed.**

### 4.1.5 Accreditation Changes

**Example:** NUC accreditation changes from Full to Interim.

| Criterion | Assessment |
|-----------|------------|
| Already handled? | **YES** — AccreditationRecord is an **immutable append-only** entity. Each `recordAccreditation()` call creates a new record. Current status is derived from the record sequence. This is explicitly described as "the event-sourcing pattern applied to accreditation — we append, we never mutate." |

**Verdict: Already modeled. No action needed.**

### 4.1.6 Institution/Programme Relationship Changes

**Example:** A programme is reassigned to a different institution after a merger.

| Criterion | Assessment |
|-----------|------------|
| Already handled? | **YES** — InstitutionMerger domain service calls `Programme::reassignTo()`. InstitutionsMerged event emitted. |

**Verdict: Already modeled. No action needed.**

## 4.2 Summary: What Actually Needs Versioning

| Data Point | MVP? | Mechanism |
|------------|:----:|-----------|
| Admission cut-off marks | **YES** | `cut_off_marks` table: programme_id, admission_cycle_id, value, source_id, created_at |
| Tuition | No (Phase 2) | Activity log for audit; structural versioning later |
| Admission requirements | Already handled | Policy supersession model |
| Programme availability | Already handled | Domain lifecycle events |
| Accreditation | Already handled | Append-only AccreditationRecord |
| Entity relationships | Already handled | InstitutionMerger + events |

**The PED's conclusion that ALL versioning can be deferred to Phase 2 is incorrect.** Cut-off mark history is a core product requirement for MVP. The domain already models history for four of the six data points. Only cut-offs and tuition need new mechanisms, and only cut-offs need it in MVP.

## 4.3 Proposed Cut-off Mark Schema

```sql
CREATE TABLE cut_off_marks (
    id              UUID PRIMARY KEY,
    programme_id    UUID NOT NULL REFERENCES programmes(id),
    admission_cycle_id UUID NOT NULL REFERENCES admission_cycles(id),
    pathway         VARCHAR NOT NULL,  -- AdmissionPathway VO value (e.g., 'utme', 'direct_entry')
    value           INTEGER NOT NULL,  -- The cut-off score
    source_id       UUID REFERENCES information_sources(id),
    created_at      TIMESTAMP NOT NULL,
    updated_at      TIMESTAMP NOT NULL,
    UNIQUE (programme_id, admission_cycle_id, pathway)
);
```

This is a **simple relational table**, not event sourcing, not a polymorphic version table, not a JSON history column. It stores one row per programme per cycle per pathway. The current cut-off is the row matching the current/active admission cycle. Previous cut-offs are the rows matching previous cycles. No special query logic needed — just `ORDER BY admission_cycle_id`.

---

# 5. Challenge GAP-3: Programme Discipline Taxonomy

The PED identified no discipline taxonomy for programmes.

## 5.1 Domain Gap vs Search/Product Taxonomy Gap

**This is primarily a search/product taxonomy gap, not a domain gap.** Here's why:

1. The domain model does not have a Discipline entity because discipline is not a domain concept with its own lifecycle, invariants, or business operations. "Engineering" doesn't have state transitions. "Medicine" doesn't enforce rules. Discipline is a **classification** applied to programmes for the purpose of search, browsing, and organisation.

2. The domain model already classifies programmes through **structured attributes** that serve domain purposes:
   - `AwardLevel` (BSc, MSc, HND, ND, NCE) — determines admission pathways and eligibility
   - `InstitutionType` (University, Polytechnic, CoE, IEI) — determines jurisdiction and valid award levels
   - `AdmissionMode` (Cyclic, Rolling, MultipleIntake) — determines admission timing
   - `DeliveryMode` (OnCampus, Online, Hybrid) — determines programme format

3. Discipline fills a different need: **"I want to study Engineering"** — this is a discovery/browsing need, not a domain invariant.

## 5.2 Classification Landscape

| Classification Source | Nature | Coverage | Stability | Suitability |
|----------------------|--------|----------|-----------|-------------|
| JAMB subject grouping | Exam-centric | Partial (UTME only) | Annual | Low — maps subjects, not disciplines |
| NUC accreditation category | Accreditation-centric | Universities only | Stable | Medium — too narrow for polytechnics/CoE |
| Institution faculty/department | Institution-specific | Per institution | Varies | Low — inconsistent naming across institutions |
| Common usage (Engineering, Medicine, Law, etc.) | Cultural/social | Broad | Very stable | High — this is what users actually search for |
| International frameworks (ISCED, CIP) | International standard | Very broad | Very stable | Future — over-engineered for Nigeria MVP |

## 5.3 Recommendation

**Flat reference table with admin-managed values. Not an enum. Not hierarchical for MVP.**

```sql
CREATE TABLE disciplines (
    id          UUID PRIMARY KEY,
    name        VARCHAR NOT NULL,       -- "Engineering"
    slug        VARCHAR NOT NULL UNIQUE, -- "engineering"
    description TEXT,
    sort_order  INTEGER NOT NULL,
    created_at  TIMESTAMP,
    updated_at  TIMESTAMP
);

-- Programme table already has discipline column in 05-implementation.md
-- Change from free-text string to FK:
ALTER TABLE programmes ADD COLUMN discipline_id UUID REFERENCES disciplines(id);
```

**Why a table, not an enum:**

1. ADR-15 establishes the migration trigger: "when adding 4th+ country requires 3+ new values that don't fit existing enum." Nigeria alone has ~15-20 discipline categories. This exceeds the comfort threshold for an enum.
2. New disciplines can be added by admin without code deployment.
3. External source mappings can be managed as data (JAMB's "Engineering & Technology" → StudyNexus's "Engineering").
4. Future hierarchy (Engineering → Civil, Mechanical, Electrical) adds a `parent_id` column. Not needed now.

**Why NOT hierarchical for MVP:**

1. A two-level hierarchy (Engineering → sub-disciplines) adds complexity to faceting, search URLs, and admin UI.
2. Nigerian students search for "Engineering" or "Medicine" — they rarely drill down to "Civil Engineering" as a browse dimension.
3. The programme name already contains the specific discipline ("Civil Engineering", "Computer Science").
4. Hierarchy can be added in Phase 2 without migration — just add `parent_id` to the `disciplines` table.

**Initial taxonomy for Nigeria (flat, ~15 values):**

Engineering, Medicine/Health Sciences, Law, Business/Administration, Sciences, Arts/Humanities, Education, Agriculture, Environmental Design, Social Sciences, ICT/Computer Science, Pharmacy, Veterinary Medicine, Theology/Religious Studies, Mass Communication

**Why NOT Spatie tags for this:**

Tags are free-form, lack controlled vocabulary, and cannot enforce that every programme has exactly one discipline. Tags are appropriate for supplementary keywords (Phase 2), not for the primary classification that drives faceted search and SEO landing pages.

---

# 6. Challenge GAP-4 / GAP-5: Search Denormalization

## 6.1 GAP-4: Tuition Range for Search Faceting

| Aspect | Assessment |
|--------|------------|
| Is tuition a canonical domain field? | **YES** — `MonetaryAmount` VO on Programme (possibly multiple values: indigene vs non-indigene, per level) |
| Is `tuition_min`/`tuition_max` canonical? | **NO** — these are computed from the canonical VO |
| Is it a search projection field? | **YES** — Typesense needs numeric fields for range filtering |
| Is it a cached value? | No — recomputed when programme data changes |
| Is it a derived value? | **YES** — derived from the MonetaryAmount VO by the `toSearchableArray()` method |

**Recommendation:** `tuition_min` and `tuition_max` exist **only in the Typesense programme document**, computed by `Programme::toSearchableArray()`. They never exist in PostgreSQL. The detail page shows the full tuition breakdown from the canonical `MonetaryAmount` VO.

**Canonical data (PostgreSQL):** `tuition` JSON column with structured MonetaryAmount data (indigene/non-indigene/per-level amounts).

**Search projection (Typesense):** `tuition_min` int32, `tuition_max` int32 — computed from the JSON on index.

**No domain change. No new column. Clear separation.**

## 6.2 GAP-5: Admission Open/Closed for Search

| Aspect | Assessment |
|--------|------------|
| Is admission status a canonical domain concept? | **YES** — ProgrammeStatus::Admitting + AdmissionCycle phase + AdmissionPolicy existence (INV-P3) |
| Is `is_admission_open` canonical? | **NO** — it's a derived boolean from multiple canonical sources |
| Is it a search projection field? | **YES** — Typesense needs a boolean for result card rendering and filtering |
| Is it a cached value? | Effectively yes — stored in Typesense and updated when underlying data changes |
| Is it a derived value? | **YES** — computed by a Query class and stored in the search index |

**Recommendation:** `is_admission_open` exists **only in the Typesense programme document**, computed by a Query class that evaluates ProgrammeStatus + AdmissionCycle current phase + AdmissionPolicy existence. It is recomputed and stored in Typesense when any of the underlying data changes (triggered by domain events: ProgrammeAdmissionResumed, AdmissionCyclePhaseAdvanced, ProgrammeAdmissionPolicyPublished, etc.).

**Canonical data (PostgreSQL):** The three source fields remain authoritative. `is_admission_open` is never stored in PostgreSQL.

**Search projection (Typesense):** `is_admission_open` boolean — computed on index, updated by event listeners.

**No domain change. No new column. Clear separation.**

## 6.3 Principle Established

**Search denormalization is a read-model concern, not a domain concern.** The architecture already has the correct separation:

```
PostgreSQL (canonical, normalized)
      ↓ toSearchableArray() on model save
Typesense (projection, denormalized)
      ↓
Public site (renders from Typesense for lists, PostgreSQL for detail)
```

No canonical business data is duplicated merely because Typesense needs a searchable field. Projection fields in Typesense are always computable from canonical PostgreSQL data and are never treated as authoritative.

---

# 7. Challenge the Proposed MVP

## 7.1 Programme Discovery as First Vertical Slice

**Why this is the best first vertical slice:**

1. **Primary persona alignment:** The SS3 student's #1 need is discovering what they can study with their subject combination. This is StudyNexus's raison d'être (A0-1, A0-3).
2. **Full-stack validation:** Exercises PostgreSQL, Eloquent, Typesense, SEO, Filament admin, Livewire public UI, data import pipeline, provenance display.
3. **Highest SEO value:** ~10,000 programme detail pages + discipline landing pages + state landing pages. This is the largest indexable surface and the primary Google entry point.
4. **Core workflow coverage:** Covers WF1 (Explore), WF2 (Evaluate), WF5 (Assess Reliability) — three of the six canonical workflows.
5. **Data dependency:** Programme depends on Institution (FK). Implementing programme discovery necessarily implements institution profiles. The dependency works in our favour.

**What business value it proves:**

A student can: search for programmes → filter by discipline, location, qualification → see admission requirements and cut-offs (including historical) → navigate to the institution → assess information reliability. This replaces hours of manual research across JAMB, institution websites, and social media.

**What absolutely must exist for it to be usable:**

| Must-Have | Reason |
|-----------|--------|
| Programme with name, discipline, qualification, duration | Minimum viable result card |
| Institution with name, type, location | Context for every programme |
| Programme-Institution relationship | A programme always belongs to an institution |
| Discipline taxonomy | Primary browse/filter dimension |
| Cut-off marks with history | Core decision factor; must show current + previous |
| Publication control (is_published) | Not all imported data is ready for public display |
| Typesense programme index with facets | Search/faceting is the primary interaction |
| Programme detail page | The destination of every search result |
| Institution detail page | Navigated from programme detail |
| Basic admin CRUD | Content team must manage data |
| At least one data import (JAMB) | No product without data |

**What can be excluded from the vertical slice:**

| Can Wait | Reason |
|----------|--------|
| Comparison view | Users can open multiple tabs; high value but not prerequisite |
| Full scholarship search | Scholarships as related content on programme pages is sufficient |
| Eligibility assessment | Requires structured admission rules; Phase 2 |
| User accounts | OQ4-1: no account required for core MVP |
| Community features | Stage 3 |
| Content models (Article, Guide, etc.) | Separate from domain discovery; Phase 1c/1e |

## 7.2 Scholarships

**Recommendation: Basic scholarship presence in MVP (Decision 5 Option C).**

| Option | Assessment |
|--------|------------|
| Full scholarship search + detail in MVP | Over-scoped. Scholarship data is harder to acquire reliably. Full faceted search requires sufficient data volume to justify the facets. |
| Scholarships only as related content | Under-scoped. Scholarships are high-value content that attracts users and SEO. A student searching for "Computer Science scholarships" should land on StudyNexus. |
| **Basic landing + detail, no full faceted search** | **Correct balance.** A `/scholarships` page with a simple list/filter (by deadline, provider) plus scholarship detail pages provides SEO surface and user value without requiring the full search infrastructure. Scholarships also appear as related content on programme and institution detail pages. |

**Why scholarships should be in MVP:**

1. Scholarship is already an aggregate root in the domain model. The entity, its relationships, and its admin CRUD need to be built regardless. The marginal cost of basic public pages is low.
2. Scholarship detail pages are SEO-valuable (~200 pages with stable URLs).
3. Scholarships are a core part of the "compare educational opportunities" value proposition (WF3).
4. Scholarship data quality issues don't prevent basic display — unverified scholarships can show with "Awaiting verification" notice (Product State: Unverified data).

## 7.3 Examination/Resource Discovery

**The PED's conclusion is correct: examination/resource discovery is not MVP.**

Validation against business documents:

1. **No workflow covers it.** WF1–WF7 do not include exam preparation. The closest is WF2 (Evaluate), but that evaluates institutions/programmes/scholarships, not exam resources.
2. **Distinct content domain.** Exam resources (past questions, syllabi, study guides) require different data acquisition (content licensing, WAEC/NECO cooperation), different content models, and different product interactions.
3. **Does not exercise core architecture.** An exam resource page doesn't demonstrate faceted programme search, cross-entity navigation, or admission data presentation.
4. **Not removed from vision.** The implementation blueprint includes `ExamPreparation` as a content model and Phase 2d. The domain is not forgotten — just properly sequenced.

---

# 8. Scraper Deployment Boundary — Handoff Contract

The boundary is already decided. The question is: **what must an approved dataset contain** for StudyNexus to safely consume it?

## 8.1 Handoff Contract

An approved dataset delivered to StudyNexus must contain, for each record:

| Field | Type | Purpose | Required? |
|-------|------|---------|:---------:|
| `entity_type` | string | Target domain entity: `institution`, `programme`, `scholarship`, `accreditation_record`, etc. | Yes |
| `operation` | enum | `create`, `update`, `retire` | Yes |
| `match_keys` | object | Identifiers for matching to existing entities: `{jamb_code, nuc_code, name, state, type}` (populated as available) | Yes |
| `data` | object | Normalized, source-agnostic field values for the target entity | Yes |
| `changed_fields` | string[] | Which fields changed compared to last observation (enables selective history recording) | For updates |
| `previous_values` | object | Previous values of changed fields (enables StudyNexus to record history without re-querying) | Recommended |
| `source` | object | `{type, url, acquired_at, trust_level}` — provenance metadata | Yes |
| `effective_date` | date | When this data becomes/became effective (e.g., which admission cycle) | For temporal data |
| `observation_date` | date | When the external system observed this data | Yes |
| `batch_id` | string | Groups records from the same acquisition run | Yes |

## 8.2 What This Enables

| StudyNexus Capability | How the Contract Supports It |
|----------------------|----------------------------|
| Identify records | `match_keys` provide JAMB code, NUC code, name+state+type for fuzzy matching |
| Identify creates/updates/removals | `operation` field explicitly declares intent |
| Apply changes | `data` contains normalized field values; `changed_fields` enables selective update |
| Preserve history | `previous_values` + `changed_fields` allow recording what changed without re-querying PostgreSQL |
| Preserve provenance | `source` object on every record provides full provenance chain |
| Detect conflicts | If `previous_values` doesn't match current canonical, flag as conflict |
| Support rollback/recovery | `batch_id` + transactional apply = atomic batch; all changes in a batch can be reversed |
| Reproduce a release | `batch_id` + idempotent operations = re-running produces same result |
| Update search projections | Domain events dispatched after apply → Scout queue → Typesense |

## 8.3 What This Does NOT Define

- How the external system scrapes, parses, or normalizes data
- The external system's internal architecture or deployment
- The API/transport mechanism between external system and StudyNexus (could be file drop, API call, shared database, message queue)
- The external system's scheduling or monitoring

These are implementation details of the external acquisition system, not StudyNexus's concern.

---

# 9. Acquisition vs History Relationship

## 9.1 Responsibility Boundary

```text
EXTERNAL SYSTEM                          STUDYNEXUS
─────────────────                        ──────────
Observes:                                Records:
  "JAMB's 2026 brochure                    "Canonical cut-off for
   says cut-off is 200"                    UNILAG CS changed from
                                           180 to 200, effective
                                           2025/2026 session,
                                           applied via release #42"

Knows:                                   Knows:
  - Source observation timestamp           - When the change was applied to canonical
  - Source URL/file                        - Who approved the release
  - Raw source format                      - Previous canonical value
  - Source-specific normalization           - Effective date in StudyNexus context
                                           - Provenance chain (source → import → verify → apply)
                                           - Impact on search projections
                                           - Domain events dispatched
```

**Key distinction:** The external system knows *when it observed* a change. StudyNexus knows *when it applied* a change. These are different timestamps serving different purposes:

| Timestamp | Owner | Purpose |
|-----------|-------|---------|
| `observation_date` | External system | "When did the source data change?" |
| `acquired_at` | External system | "When did we scrape/download this?" |
| `applied_at` | StudyNexus | "When did this become canonical in StudyNexus?" |
| `effective_date` | Both (must agree) | "For which admission cycle/session does this apply?" |

## 9.2 History Recording Responsibility

**StudyNexus records canonical history, not observation history.**

When StudyNexus applies a change from an approved dataset:

1. It compares the incoming value to the current canonical value.
2. If different, it records the change in the appropriate history mechanism (e.g., `cut_off_marks` table for cut-offs, activity log for audit).
3. The history record includes: previous value, new value, effective date, provenance (which import, which source), applied_at timestamp.
4. Domain events are dispatched (e.g., `ProgrammeAdmissionPolicyPublished` if cut-off changed via new policy).

**The external system does NOT tell StudyNexus what the "previous value" was in StudyNexus's canonical store.** The external system may include `previous_values` in the handoff contract (what IT observed as the previous value), but StudyNexus validates this against its own canonical data. If they disagree, it's a conflict flag.

---

# 10. Events Review

## 10.1 Evaluation Against Criteria

| Event | Meaningful business event? | Consumed? | Needed for projections? | Needed for audit/history? | Verdict |
|-------|:-------------------------:|:---------:|:-----------------------:|:-------------------------:|---------|
| InstitutionEstablished | Yes | UpdateSearchIndex, LogActivity | Yes | Yes | **Keep** |
| InstitutionRenamed | Yes | UpdateSearchIndex, LogActivity | Yes | Yes | **Keep** |
| InstitutionSuspended | Yes | UpdateSearchIndex, cascade | Yes | Yes | **Keep** |
| InstitutionReactivated | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| InstitutionClosed | Yes | UpdateSearchIndex, cascade | Yes | Yes | **Keep** |
| InstitutionsMerged | Yes | SearchRebuild, reassignment | Yes | Yes | **Keep** |
| InstitutionAccredited | Yes | TrustSignal, UpdateSearchIndex | Yes | Yes | **Keep** |
| InstitutionalAdmissionPolicyPublished | Yes | UpdateSearchIndex, OpportunityFeed | Yes | Yes | **Keep** |
| ProgrammeIntroduced | Yes | UpdateSearchIndex, LogActivity | Yes | Yes | **Keep** |
| ProgrammeAdmissionPolicyPublished | Yes | UpdateSearchIndex, OpportunityFeed | Yes | Yes | **Keep** |
| ProgrammeAdmissionSuspended | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| ProgrammeAdmissionResumed | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| ProgrammeDiscontinued | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| ProgrammeAccredited | Yes | TrustSignal, UpdateSearchIndex | Yes | Yes | **Keep** |
| ScholarshipAnnounced | Yes | UpdateSearchIndex, notification | Yes | Yes | **Keep** |
| ScholarshipEligibilityPolicyPublished | Yes | EligibleCandidateRecalc | Yes | Yes | **Keep** |
| ScholarshipApplicationsOpened | Yes | UpdateSearchIndex, notification | Yes | Yes | **Keep** |
| ScholarshipApplicationsClosed | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| ScholarshipWithdrawn | Yes | UpdateSearchIndex, notification | Yes | Yes | **Keep** |
| ScholarshipExpired | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| ScholarshipTargetsUpdated | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| AdmissionCycleAnnounced | Yes | UpdateSearchIndex | Yes | Yes | **Keep** |
| AdmissionCycleActivated | Yes | ReadModelUpdate | Yes | Yes | **Keep** |
| AdmissionCyclePhaseAdvanced | Yes | ReadModelUpdate, notification | Yes | Yes | **Keep** |
| AdmissionCycleClosed | Yes | ReadModelUpdate | Yes | Yes | **Keep** |
| InformationSourceVerified | Yes | TrustSignalRecalc | Yes | Yes | **Keep** |
| InformationSourceMarkedUnreliable | Yes | TrustSignalRecalc | Yes | Yes | **Keep** |
| InformationSourceDeprecated | Yes | TrustSignalCascade | Yes | Yes | **Keep** |
| QualificationDeprecated | Yes | PolicyCreationGuard | No (guard) | Yes | **Keep** |

**Verdict: All 29 events are justified.** Each represents a meaningful business state change, has identified consumers, and is needed for either search projections, audit, or domain coordination.

## 10.2 What About CRUD Updates?

The domain model correctly **rejected** events like `InstitutionUpdated`, `ProgrammeUpdated`, `ProgrammeDescriptionUpdated` — these are CRUD operations with no domain significance beyond search index projection. They are handled by:

1. **spatie/laravel-activitylog** for audit trail (who changed what, when).
2. **Laravel Scout** for search index updates (model `saved` event triggers `toSearchableArray()`).
3. **No domain event** because no business rule is triggered by a description change.

This is correct. Domain events should represent business facts, not data mutations.

## 10.3 Application-Level Events for Publication

When we add `is_published` to entities, we need to handle the publication transition. Should this be a domain event?

**No.** Publishing is an application/product concern, not a domain concern. It doesn't affect domain invariants. The search index update is handled by Scout (model saved → reindex). The audit trail is handled by activity log.

However, if a programme is published and this should trigger notifications ("New programme added!"), that notification is an application event, not a domain event. This can be handled by a listener on the Eloquent model's `saved` event that checks if `is_published` changed from `false` to `true`.

---

# 11. Audit of PRODUCT-EXPERIENCE-DISCOVERY.md

## 11.1 Confirmed Findings (supported by canonical documents)

| Finding | Evidence |
|---------|----------|
| StudyNexus is search-first, information-rich, SEO-driven | A0-3 (search, discover, compare, verify); A5-1 (Discover, Search capabilities); WF1 primary workflow |
| Programme discovery is the primary user journey | A1-1 (SS3 student is primary persona); Cut-off marks, admission requirements are top needs |
| Only 3 of 11 entities need user-facing pages | Domain model analysis: Institution, Programme, Scholarship are aggregate roots with public content; remaining 8 are supporting or admin-only |
| Typesense is critical for discovery | ADR-6 (search engine selection); Architecture defines 3 data representations |
| No user accounts in MVP | OQ4-1 (no account required for core MVP) |
| Mobile-first requirement | Nigerian internet usage context; A3-5 (Accessibility pain) |
| Admission Pathway is VO, not entity | ADR rejected Admission Pathway as Entity; confirmed as VO in domain model |
| Examination/resource discovery not MVP | No workflow covers it; distinct content domain; Phase 2d in implementation blueprint |
| Institution self-service post-MVP | A2-3, OQ2-3 |
| Laravel monolith confirmed | ADR-9 (single Laravel application with namespace separation) |
| Provenance model is sound | InformationSource entity; TrustSignal VO; Capability #9 (Preserve Information Provenance) |
| Detail page information hierarchy is well-designed | Aligns with WF2 (Evaluate) steps; provenance display design matches OQ6-8 trust signals |

## 11.2 Reasonable Product Assumptions (plausible but not yet approved)

| Assumption | Why Reasonable | Risk |
|------------|---------------|------|
| Scholarship discovery as secondary to programme/institution | Scholarship data harder to acquire; lower volume; but high user value | Could undervalue scholarship SEO potential |
| Comparison as Phase 2 | Users can open multiple tabs; comparison adds significant UI complexity | May delay a key differentiator |
| Programme discipline as most important browse dimension | Users search "Engineering" not "B.Sc."; this matches A3-3 (Structured Exploration) | Depends on taxonomy being correct |
| SEO landing pages for pre-composed filter combinations | Standard SEO practice for faceted content; matches architecture doc strategy | Requires discipline taxonomy to be settled first |
| Facet counts displayed per value | Standard UX for faceted search; helps users understand filter landscape | None |
| Historical cut-offs shown collapsed by default | Good UX — shows current prominently, history on demand | Requires versioning mechanism |
| Session-based comparison (no user accounts) | Acceptable for MVP per OQ4-1 | Limited to single device |

## 11.3 Unsupported Assumptions (introduced without sufficient evidence)

| Assumption | Issue | Correct View |
|------------|-------|-------------|
| `publication_status` enum (Draft, Published, Unpublished, Archived) | Over-engineered; conflates with domain lifecycle; creates state machine overhead | `is_published` boolean + `published_at` timestamp is sufficient |
| `data_versions` polymorphic table for ALL attributes | Over-generalized; domain already models history for 4 of 6 data points | Only cut-offs need a new table; tuition deferred |
| Typesense as primary read path for ALL discovery surfaces | Over-stated; detail pages should query PostgreSQL for full entity graph | Lists/search from Typesense; detail pages from PostgreSQL |
| Institution detail programme list from Typesense | Unnecessary coupling; Eloquent with eager loading is performant for a single institution's programmes | Eloquent for institution-scoped lists; Typesense for cross-institution search |
| Decision 6: External acquisition deployment boundary needs approval | Boundary is already decided per user directive | The contract at the boundary needs definition, not the boundary itself |
| All historical versioning deferred to Phase 2 | Cut-off marks are a core user need for MVP | Cut-offs need versioning in MVP; tuition can defer |

## 11.4 Missing Product Questions

| Question | Why Important | Impact |
|----------|---------------|--------|
| What is the minimum data completeness threshold for publishing? | Without this, the content team has no guidance on when an entity is "ready" for public display | Affects publication workflow, admin UI, data quality |
| Should draft/unpublished entities appear in admin search? | Content team needs to find and manage unpublished entities | Affects admin Filament resources, search scope |
| How should programme-institution relationship changes be communicated to users? | If a programme moves institutions (merger), how do we handle bookmarks/SEO? | Affects URL redirect strategy, user communication |
| What happens to public display when an entity's source is marked unreliable? | If JAMB data is marked unreliable, should programmes sourced from JAMB show differently? | Affects provenance display, trust signal rendering |
| Should there be a "last updated" indicator on detail pages? | Users value recency signals ("Updated 2 days ago" vs "Updated 6 months ago") | Affects detail page design, cache invalidation |
| How should partial/incomplete data be displayed? | Many institutions have incomplete data (missing tuition, no admission requirements) | Affects detail page design, empty state handling |
| What URL structure for discipline landing pages? | `/programmes/engineering` vs `/disciplines/engineering/programmes` — affects SEO | Affects routing, sitemap, internal linking |
| Should the search default scope be "all" or "programmes"? | PQ-1 from PED; affects home page design, default search behaviour | Affects home page UX, search implementation |

---

# 12. Decision Matrix

| ID | Finding | Category | Evidence | Recommendation | MVP? | Needs Approval? |
|----|---------|----------|----------|---------------|:----:|:---------------:|
| DM-01 | Publication model needed on domain entities | Product | Product requires unpublished data not shown on public site | `is_published` boolean + `published_at` timestamp on Institution, Programme, Scholarship | Yes | **Yes** |
| DM-02 | ProgrammeStatus/InstitutionStatus inconsistency between 03-domain.md and 05-implementation.md | Data | Domain says (Prospective, Admitting, Suspended, Discontinued); Implementation says (Draft, Published, Archived, Suspended) | Correct 05-implementation.md to use domain lifecycle statuses; add `is_published` separately | Yes | **Yes** |
| DM-03 | Cut-off mark history required for MVP | Historical/versioning | Students use previous cut-offs to estimate chances; directly user-visible on programme detail page | `cut_off_marks` table (programme_id, admission_cycle_id, pathway, value, source_id) | Yes | **Yes** |
| DM-04 | Tuition history not required for MVP | Historical/versioning | Current tuition sufficient for primary decision; activity log provides audit | Defer to Phase 2 | No | No |
| DM-05 | Discipline taxonomy needed for programme search | Search | No classification exists; users search by discipline not qualification | `disciplines` reference table + FK on Programme; flat for MVP | Yes | **Yes** |
| DM-06 | Tuition denormalization for search is projection-only | Search | Typesense needs numeric range; MonetaryAmount VO is canonical | `tuition_min`/`tuition_max` in Typesense only via `toSearchableArray()` | Yes | No |
| DM-07 | Admission open/closed is projection-only | Search | Derived from ProgrammeStatus + AdmissionCycle + AdmissionPolicy | `is_admission_open` boolean in Typesense only; computed by Query | Yes | No |
| DM-08 | Programme discovery as first MVP vertical slice | Product | Primary persona need; exercises full stack; highest SEO value | Confirm | Yes | **Yes** |
| DM-09 | Basic scholarship pages in MVP | Product | Scholarship is aggregate root; low marginal cost; SEO valuable | `/scholarships` landing + detail pages; no full faceted search | Yes | **Yes** |
| DM-10 | Examination/resource discovery NOT in MVP | Product | No workflow covers it; distinct content domain; Phase 2d planned | Confirm defer | No | No |
| DM-11 | Comparison view deferred | UX | Users can open multiple tabs; not prerequisite for product utility | Phase 2 | No | No |
| DM-12 | Handoff contract at acquisition boundary | Acquisition boundary | External system must provide structured data for StudyNexus to safely import | Define contract (Section 8 above); do NOT redesign boundary | Yes | **Yes** |
| DM-13 | Canonical history ≠ observation history | Historical/versioning | StudyNexus records when change became canonical; external system records when it observed change | Keep separate; both timestamps stored for different purposes | Yes | No |
| DM-14 | All 29 domain events justified | Architecture | Each has business meaning, consumers, and projection/audit need | No changes to event model | Yes | No |
| DM-15 | Detail pages query PostgreSQL, not Typesense | Architecture | Full entity graph with relationships needed; Typesense is denormalized projection | Lists/search from Typesense; detail from PostgreSQL | Yes | **Yes** |
| DM-16 | Institution programme list from Eloquent, not Typesense | Architecture | Single institution scope; eager loading is performant; avoids Typesense coupling | Eloquent with eager loading for institution-scoped lists | Yes | No |
| DM-17 | No event sourcing | Architecture | ADR-3 explicit; events are fire-and-forget | Confirm | Yes | No |
| DM-18 | Discipline taxonomy is reference data, not domain entity | Domain | No lifecycle, no invariants, no business operations; purely classification | `disciplines` table in Reference namespace, not Domain | Yes | No |
| DM-19 | Policy supersession handles admission requirement history | Historical/versioning | PolicyStatus::Superseded; previous policies retained; atomic supersession | No new mechanism needed | Yes | No |
| DM-20 | Accreditation append-only handles accreditation history | Historical/versioning | AccreditationRecord is immutable; status derived from record sequence | No new mechanism needed | Yes | No |
| DM-21 | Minimum data completeness threshold undefined | Product | Content team needs guidance on when to publish | Define threshold per entity type | Yes | **Yes** |
| DM-22 | No `publication_status` enum needed | Product | Boolean + timestamp sufficient; avoids state machine; avoids overlap with domain lifecycle | Reject enum approach; use boolean + timestamp | Yes | No |

---

# 13. Revised Recommendation

## A. What Is Now Settled

1. **StudyNexus is a search-first, information-rich, SEO-driven education discovery platform.** (Confirmed by canonical documents.)
2. **Programme discovery is the first MVP vertical slice.** (Primary persona, full-stack validation, highest SEO value.)
3. **11 entities are correct.** Only 3 need user-facing pages. (Domain model confirmed by UX.)
4. **Admission Pathway is a Value Object.** (Confirmed by UX — it's a facet value, not a page.)
5. **Typesense for search/faceting.** (ADR-6 confirmed; search projections from domain events.)
6. **Laravel monolith.** (ADR-9 confirmed; no microservices needed.)
7. **No user accounts in MVP.** (OQ4-1 confirmed.)
8. **Examination/resource discovery is Phase 2.** (No workflow, distinct domain, already planned.)
9. **Comparison view is Phase 2.** (Not prerequisite; high value but deferrable.)
10. **All 29 domain events are justified.** (Each has business meaning and consumers.)
11. **No event sourcing.** (ADR-3 confirmed.)
12. **Search denormalization is projection-only.** (tuition_min/max, is_admission_open exist only in Typesense.)
13. **Canonical data ≠ latest external observation.** (StudyNexus decides when changes become canonical.)
14. **External acquisition boundary is decided.** (Scraper/crawler external; ingestion pipeline internal.)
15. **Accreditation history is already modeled.** (Append-only AccreditationRecord.)
16. **Admission requirement history is already modeled.** (Policy supersession.)
17. **Basic scholarship pages should be in MVP.** (Low marginal cost, SEO valuable, entity already exists.)

## B. What Is Genuinely Unresolved

1. **Publication model:** `is_published` boolean + `published_at` timestamp, or something else? (Recommended: boolean + timestamp. Needs approval.)
2. **ProgrammeStatus/InstitutionStatus inconsistency:** 05-implementation.md has wrong enum values. Must be corrected to match 03-domain.md.
3. **Cut-off mark versioning mechanism:** `cut_off_marks` table recommended for MVP. Needs approval.
4. **Discipline taxonomy:** `disciplines` reference table recommended. Initial values need approval.
5. **Minimum data completeness threshold:** What makes an entity "ready to publish"? Needs product decision.
6. **Detail page data source:** PostgreSQL for detail, Typesense for lists. Needs confirmation.
7. **Scholarship MVP scope:** Basic pages (landing + detail, no full faceted search). Needs approval.
8. **Handoff contract details:** Section 8 defines the proposed contract. Needs approval.
9. **Home page default scope:** Programme search as default, or balanced three-category display? (PQ-1 from PED.)

## C. What Should Be Added to the Canonical Model

| Addition | Where | Justification |
|----------|-------|---------------|
| `is_published` boolean + `published_at` timestamp | Institution, Programme, Scholarship | Product requirement: control public visibility independently of domain lifecycle |
| `cut_off_marks` table | New domain table | MVP requirement: historical cut-off display on programme detail |
| `disciplines` reference table + `discipline_id` FK on Programme | Reference namespace | Search/product requirement: primary browse dimension for programme discovery |
| Correct ProgrammeStatus values in 05-implementation.md | ProgrammeStatus: Prospective, Admitting, Suspended, Discontinued | Align implementation with canonical domain model |
| Correct InstitutionStatus values in 05-implementation.md | InstitutionStatus: Provisional, Operational, Suspended, Closed | Align implementation with canonical domain model |

## D. What Should NOT Be Added

| Rejected Addition | Reason |
|-------------------|--------|
| `publication_status` enum (Draft, Published, Unpublished, Archived) | Over-engineered; `is_published` boolean + `published_at` timestamp is sufficient; avoids state machine; avoids overlap with domain lifecycle |
| `data_versions` polymorphic table | Over-generalized; domain already models history for 4 of 6 data points; only cut-offs need a new table |
| Discipline hierarchy (parent_id) for MVP | Unnecessary complexity for Nigeria; flat taxonomy sufficient; can add later without migration |
| Discipline as PHP enum | ADR-15 migration trigger: ~15-20 values exceeds comfort threshold for enum; new disciplines should be admin-manageable |
| `tuition_min`/`tuition_max` columns in PostgreSQL | These are search projection fields; belong only in Typesense `toSearchableArray()` |
| `is_admission_open` column in PostgreSQL | Derived value; belongs only in Typesense as computed projection |
| Typesense as data source for detail pages | Detail pages need full entity graph with relationships; PostgreSQL is authoritative |
| Programme list on institution detail from Typesense | Single-institution scope; Eloquent with eager loading is performant; avoids unnecessary Typesense coupling |
| Event sourcing | ADR-3 explicitly rejected; domain events are fire-and-forget |
| `nwidart/laravel-modules` | Monolith with namespace separation is sufficient (ADR-9) |

## E. What Should Be MVP

**MVP Vertical Slice: Programme Discovery**

| Component | Scope |
|-----------|-------|
| Public pages | Home (search entry), Programme search/results, Programme detail, Institution detail, Scholarship landing + detail (basic) |
| Search | Programme search with facets (state, type, ownership, qualification, discipline, admission pathway, tuition range). Institution search (basic). Global autocomplete. |
| Detail pages | Programme detail with admission requirements, cut-off marks (current + historical), tuition, accreditation. Institution detail with programme list, accreditation, contact. |
| Provenance | Verification badges, source attribution, last-verified dates |
| Publication control | `is_published` on entities; admin publish/unpublish workflow |
| Discipline taxonomy | Flat reference table; admin-managed; ~15 initial values |
| Admin | Institution/Programme CRUD, publication control, data import review, information source management, discipline management |
| Data acquisition | JAMB brochure import, NUC accreditation import, CSV manual import |
| SEO | Indexable landing pages, entity detail pages, sitemaps, JSON-LD |
| Cut-off mark history | `cut_off_marks` table; display on programme detail page |
| Architecture | PostgreSQL, Eloquent, Typesense, Livewire v4, Filament v5, Redis cache |

## F. What Should Be Deferred

| Feature | Phase | Reason |
|---------|-------|--------|
| Comparison view | Phase 2 | High value, not prerequisite for product utility |
| Full scholarship faceted search | Phase 2 | Data volume/quality may not justify at launch |
| Tuition history/versioning | Phase 2 | Current value sufficient; activity log provides audit |
| Eligibility assessment (WF4) | Phase 2 | Requires structured admission rules |
| Institution-scoped admin | Phase 2+ | Post-MVP per A2-3 |
| User accounts | Phase 2 | OQ4-1: not needed for core MVP |
| Saved searches / favourites | Phase 2 | Requires user accounts |
| Community corrections | Stage 3 | Requires user accounts and moderation |
| Examination/resource discovery | Phase 2+ | Separate content domain |
| Discipline hierarchy | Phase 2 | Flat taxonomy sufficient for Nigeria MVP |
| Content models (Article, Guide, etc.) | Phase 1c/1e | Separate from domain discovery vertical |
| Notifications | Stage 2 | Depends on user accounts |
| Study abroad | Phase 2b | Depends on domain pages + content |

## G. What Requires Explicit Approval

| # | Decision | Options | Recommendation | Why | Impact |
|---|----------|---------|---------------|-----|--------|
| 1 | Publication model for domain entities | A) `is_published` boolean + `published_at` timestamp<br>B) `publication_status` enum (Draft, Published, Unpublished, Archived)<br>C) No publication control (show all Active entities) | **A** | Simplest model that correctly separates publication from domain lifecycle. Boolean + timestamp avoids state machine and provides Draft/Unpublished distinction via NULL/non-NULL published_at. | Affects public queries, admin workflow, search indexing, 3 entities |
| 2 | Fix ProgrammeStatus/InstitutionStatus in 05-implementation.md | A) Correct to domain model values (Prospective/Admitting/Suspended/Discontinued, Provisional/Operational/Suspended/Closed) + add `is_published`<br>B) Keep implementation values and update domain model | **A** | Domain model is canonical for domain semantics. Implementation doc has publication values in a lifecycle enum — this conflates two concepts. | Affects 2 enums, implementation schema, domain methods, admin UI |
| 3 | Cut-off mark history in MVP | A) `cut_off_marks` table in MVP (programme_id, admission_cycle_id, pathway, value, source_id)<br>B) Defer all versioning to Phase 2<br>C) JSON `attribute_history` column | **A** | Cut-off history is a core user need directly supporting the primary journey. Students use previous cut-offs to estimate chances. A simple relational table is the lightest correct mechanism. | Affects data model, import pipeline, detail page, search index |
| 4 | Discipline taxonomy approach | A) `disciplines` reference table + FK on Programme (flat, admin-managed)<br>B) Discipline as PHP enum (~15 values)<br>C) Spatie tags (free-form) | **A** | ~15-20 values exceeds enum comfort threshold (ADR-15). Admin-manageable without code deployment. External source mappings as data. Flat is sufficient for MVP; hierarchy can be added later. | Affects programme model, search index, SEO landing pages, admin UI |
| 5 | Scholarship pages in MVP | A) Full scholarship search + detail in MVP<br>B) Scholarships only as related content (no dedicated page)<br>C) Basic scholarship landing + detail, no full faceted search | **C** | Scholarship is already an aggregate root. Basic pages have low marginal cost and provide SEO value. Full faceted search requires data volume/quality that may not exist at launch. | Affects data acquisition priority, search index scope, SEO surface |
| 6 | Handoff contract at acquisition boundary | A) Adopt the contract defined in Section 8 above<br>B) Define a different contract | **A** | The contract provides all fields StudyNexus needs for safe import, history preservation, provenance, conflict detection, and rollback. It does NOT specify external system internals. | Affects ingestion pipeline, import workflow, provenance model |
| 7 | Minimum data completeness threshold for publishing | A) Define per-entity minimums (e.g., institution: name + type + location; programme: name + institution + qualification + discipline)<br>B) No threshold — admin decides case by case<br>C) All required fields must be populated | **A** | Some guidance is needed or the public site will show embarrassingly incomplete entities. A minimum set per entity type gives the content team a clear checklist. | Affects publication workflow, admin UI, content strategy |

## H. Recommended Next Phase

**Are we ready to begin designing/building the first vertical slice?**

**Almost.** One specific discovery step is required first, but it is narrow and bounded:

### Exact Question That Must Be Answered

**The discipline taxonomy initial values must be defined.** This is not an open-ended discovery task — it is a specific, bounded decision: "What are the ~15 discipline categories for Nigerian tertiary programmes?" This can be answered by:

1. Reviewing JAMB's programme categorisation in the current brochure
2. Reviewing NUC's accreditation categories
3. Cross-referencing with the most common search terms Nigerian students use
4. Producing a flat list of ~15 values with slugs

**This can be completed in one session.** It does not require another discovery document or architecture loop.

### After That Decision

Once the 7 decisions above are approved and the initial discipline values are defined, we are ready to:

1. **Update canonical documents** with the approved changes:
   - 03-domain.md: Add `is_published` + `published_at` to entity descriptions; add `cut_off_marks` to domain model; add `discipline_id` FK to Programme
   - 05-implementation.md: Fix ProgrammeStatus/InstitutionStatus values; add new columns/tables to schema; add `disciplines` table
   - 04-architecture.md: Confirm detail pages from PostgreSQL, lists from Typesense

2. **Begin implementation planning** for the MVP vertical slice:
   - Sprint breakdown for the programme discovery vertical
   - Technical proof-of-concept order (Typesense integration, data import pipeline)
   - Migration generation order

**No further discovery is required.** The product is sufficiently defined to begin building.

---

*Product Discovery Challenge complete. Awaiting human approval of the 7 decisions and the initial discipline taxonomy values before canonical documents are updated or implementation planning begins.*
